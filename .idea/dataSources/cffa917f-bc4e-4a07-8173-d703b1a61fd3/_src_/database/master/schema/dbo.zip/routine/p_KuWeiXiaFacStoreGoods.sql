 
create proc [dbo].[p_KuWeiXiaFacStoreGoods]
@cStoreNo varchar(32),
@cTermID varchar(32),
@cOpertNo varchar(32),
@cOpertName varchar(32)
as
begin
       if (select OBJECT_ID('tempdb..#temp_cGoodsKuWei'))is not null  drop table #temp_cGoodsKuWei
       create table #temp_cGoodsKuWei(cGoodsNo varchar(32),cStoreNo varchar(32))
 
        
       exec('
          insert into #temp_cGoodsKuWei(cGoodsNo,cStoreNo)
          select a.cGoodsNo,a.cStoreNo
          from U_key.dbo.temp_GoodsKuWei'+@cTermID+' a left join t_cStoreGoods b
          on a.cGoodsNo=b.cGoodsNo and b.cStoreNo=a.cStoreNo
          where isnull(b.cGoodsNo,'''')=''''          
        ')
         
        if (select OBJECT_ID('tempdb..#temp_cGoodsKuWeiList'))is not null  drop table #temp_cGoodsKuWeiList
        select a.cGoodsNo,a.cSupNo,b.cStoreNo
        into #temp_cGoodsKuWeiList
        from t_Goods a,#temp_cGoodsKuWei b
        where a.cGoodsNo=b.cGoodsNO
        
        if (select OBJECT_ID('tempdb..#temp_cGoodsSuperList'))is not null  drop table #temp_cGoodsSuperList
        select  a.cGoodsNo,b.cSupNoMain,b.cStoreNo,b.cStoreName,b.cSupNo, b.cSupName
        into #temp_cGoodsSuperList
        from #temp_cGoodsKuWeiList a,t_SupplierStore b
        where  a.cStoreNO=b.cStoreNo
        and a.cSupNo=b.cSupNoMain
  
        insert into t_cStoreGoods(
		cGoodsNo, cStoreNo, cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fVipPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, fPreservationUp, fPreservationDown, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		fVipScore, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		cSupNo, cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, dUpdate, dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		)
		select a.cGoodsNo, b.cStoreNo,b.cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fNormalPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, 0, 0, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		a.fNormalPrice, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		b.cSupNo, b.cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, GETDATE(), dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		from t_Goods a,#temp_cGoodsSuperList b
		where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNoMain
     


		insert into t_ChangeGoods(cGoodsNo,cStoreNo)
		select a.cGoodsNo,b.cStoreNo
		from t_Goods a,#temp_cGoodsSuperList b
		where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNoMain

        ---插入日志
         
		 ---写入日志
		declare @opertion varchar(256)
        set @opertion=dbo.getDayStr(GETDATE())+'库位添加 发商品编号信息到门店'
 
		exec p_Log @cOpertNo,@cOpertName,@opertion,'下发到门店'
		
           
end
GO
