 

/*
  　1.高库存（购销，库存天数>标准天数+20天，库存金额>500元，库存数量≥4×订货倍数，已30日未进货。）
　　2.负库存（库存量<0）
　　3.负毛利（毛利<0）
　　4.应销未订货（库存0，且超过7天未销售，未订货；有无在途可选）
　　5.畅销缺货（0≤可销天数≤3天   DMS选择：百货≥1，杂货≥2）
　　6.0销售（库存>0，百货≥20天，杂货≥15天未销售）~~
　　7.150N (商品状态：0、正常商品，1、即将删除商品，2、已经删除商品，3、暂停进货商品，4、厂商缺货商品，5、过季商品。
            可销售状态：Y、可销售，N、不可销售。)
 
if (select object_id('tempdb..#temp_GoodsTypeNo'))is not null drop table #temp_GoodsTypeNo
select cgoodstypeno into #temp_GoodsTypeNo from t_Goods 
where cgoodstypeno like '2%'
    
if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null    
 drop table #temp_GetKuCunMaoli_wei
Create Table #temp_GetKuCunMaoli_wei (
cGoodsTypeno varchar(32),cGoodsTypename varchar(32),
销售数量 money,销售金额 money,特价销售数量 money,特价销售金额 money,正价销售数量 money,正价销售金额 money,
fMoney_cost money,fml money,fPrice_Avg money,期初库存 money,期末库存 money,
当前库存 money,当前库存金额 money,在途数量 money,会员销售数量 money,会员销售金额 money,会员来客数 money,
来客数 money,库存状态 varchar(32),畅销状态 varchar(32),毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(32),
最后销售日 varchar(32),Sys可销天数 money)
    
exec p_GetGoodsTypeKuCumMaoliSaleDay '2015-5-5','2015-5-5','02' 
 
*/
--------------月结表中取。。。。。
CREATE proc [dbo].[p_GetGoodsTypeKuCumMaoliSaleDay_ERp]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32) ,
@key varchar(32)
as
begin
    if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null  drop table  #temp_GoodsTypeNo
create table #temp_GoodsTypeNo(cGoodsTypeno varchar(32))

 
 
exec(' 
if  (select object_id(''Temp_SupKey.dbo.temp_type'+@key+''')) is  null
select cGoodsTypeno into Temp_SupKey.dbo.temp_type'+@key+' from t_Goodstype where 1<>1

insert into #temp_GoodsTypeNo(cGoodsTypeno) select cGoodsTypeno from Temp_SupKey.dbo.temp_type'+@key+' 

')
	if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
	drop table #temp_GetKuCunMaoli_wei
	Create Table #temp_GetKuCunMaoli_wei ( 
	 cGoodsTypeno varchar(32),cGoodsTypename varchar(32), 
	 销售数量 money,销售金额 money,特价销售数量 money,特价销售金额 money,正价销售数量 money,正价销售金额 money, 
	 fMoney_cost money,fml money,fPrice_Avg money,期初库存 money,期末库存 money, 
	 当前库存 money,当前库存金额 money,在途数量 money,会员销售数量 money,会员销售金额 money,会员来客数 money, 
	 来客数 money,库存状态 varchar(32),畅销状态 varchar(32),毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(32), 
	 最后销售日 varchar(32),Sys可销天数 money)
 
 
    declare @dDate1 varchar(32)
    declare @dDate2 varchar(32)
    declare @DbName varchar(32)
    set @DbName=(select Pos_WH_Form from t_WareHouse where ISNULL(bMainSale,0)=1 and cWhNo=@cWhno)
  
    set @dDate1=dbo.getdaystr(@dDateBgn-1)
    set @dDate2=dbo.getdaystr(@dDateEnd)
   
    if (select object_id('tempdb..#temp_WhFromGoods'))is not null drop table #temp_WhFromGoods
	select distinct [cGoodsTypeNo] into #temp_WhFromGoods 
	from #temp_GoodsTypeNo
	
	CREATE INDEX IX_tmp_WhFromGoods  ON #temp_WhFromGoods(cGoodsTypeNo)
   
	if(select object_id('tempdb..#temp_WhFromheji_Month')) is not null drop table #temp_WhFromheji_Month
	CREATE TABLE #temp_WhFromheji_Month ([cGoodsTypeNo] [varchar](32) NOT NULL,cGoodsTypename varchar(64),[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(32) null,
	期初库存 money,期末库存 money,期末库存金额 money,当前库存 money,当前库存金额 money,在途数量 money,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money,
	会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money,
	库存状态 varchar(16),应销未订货 varchar(16),畅销状态 varchar(16),
	毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(16),最后销售日 datetime,Sys可销天数 money)
	
	if(select object_id('tempdb..#temp_WhFromendheji_Month')) is not null drop table #temp_WhFromendheji_Month
	CREATE TABLE #temp_WhFromendheji_Month ([cGoodsTypeNo] [varchar](32) NOT NULL,cGoodsTypename varchar(64),[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(32) null,
	期初库存 money,期末库存 money,期末库存金额 money,当前库存 money,当前库存金额 money,在途数量 money,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money,
	会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money,
	库存状态 varchar(16),应销未订货 varchar(16),畅销状态 varchar(16),
	毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(16),最后销售日 datetime,Sys可销天数 money)
	
	------获取会员情况----
    if(select object_id('tempdb..#temp_WhFromVIP')) is not null drop table #temp_WhFromVIP
    CREATE TABLE #temp_WhFromVIP ([cGoodsTypeNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
--print dbo.getTimeStr(GETDATE())
--print 2   
 -------获取时间段内的进销存-------

exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_heji_month''))is not null  drop table #temp_Wh_Goods_heji_month
	select a.[cGoodsTypeNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额,b.期末库存,b.期初库存
	,b.fMoney_cost,b.fPrice_in,b.fml,b.Sys可销天数
	into #temp_Wh_Goods_heji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Type_Day b
	with(nolock)
	where dDateBgn='''+@dDate1+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_monthheji''))is not null  drop table #temp_SumWh_Goods_monthheji
	select cGoodsTypeNo,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),	
	期末库存=sum(期末库存),期初库存=sum(期初库存),
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in),Sys可销天数
	into #temp_SumWh_Goods_monthheji
	from  #temp_Wh_Goods_heji_month
	group by cGoodsTypeNo,Sys可销天数
				
	insert into #temp_WhFromheji_Month(
	       [cGoodsTypeNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml,Sys可销天数)
 	select [cGoodsTypeNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml,Sys可销天数
	from #temp_SumWh_Goods_monthheji    

')
 
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endheji_month''))is not null  drop table #temp_Wh_Goods_endheji_month
	select a.[cGoodsTypeNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额,b.期末库存,b.期初库存
	,b.fMoney_cost,b.fPrice_in,b.fml,b.Sys可销天数
	into #temp_Wh_Goods_endheji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Type_Day b
	where dDateBgn='''+@dDate2+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endmonthheji''))is not null  drop table #temp_SumWh_Goods_endmonthheji
	select cGoodsTypeNo,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),		
	期末库存=sum(期末库存),期初库存=sum(期初库存),	  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in),Sys可销天数
	into #temp_SumWh_Goods_endmonthheji
	from  #temp_Wh_Goods_endheji_month
	group by cGoodsTypeNo,Sys可销天数
				
	insert into #temp_WhFromendheji_Month(
	       [cGoodsTypeNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml,Sys可销天数)
	select [cGoodsTypeNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml,Sys可销天数
	from #temp_SumWh_Goods_endmonthheji    

    ------------获取会员情况。     
	  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_vip_month''))is not null  drop table #temp_Wh_Goods_vip_month
	  select distinct b.cGoodsTypeNo,b.当日会员销售数量,b.当日会员销售金额,b.当日会员来客数,b.来客数
	  into #temp_Wh_Goods_vip_month
	  from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Type_Day b
	  with(nolock)
	  where dDateBgn='''+@dDate1+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 
	 
	  insert into #temp_WhFromVIP(cGoodsTypeNo,会员销售数量,会员销售金额,会员来客数,来客数 )
	  select cGoodsTypeNo,会员销售数量=sum(当日会员销售数量),会员销售金额=sum(当日会员销售金额),会员来客数=sum(当日会员来客数),来客数=sum(来客数)
	  from #temp_Wh_Goods_vip_month   
	  group by cGoodsTypeNo
	  
') 

--print dbo.getTimeStr(GETDATE())
--print 3

update a
set a.销售数量=isnull(a.销售数量,0)-isnull(b.销售数量,0),a.销售金额=isnull(a.销售金额,0)-isnull(b.销售金额,0),
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
a.fMoney_cost=isnull(a.fMoney_cost,0)-isnull(b.fMoney_cost,0),a.fml=isnull(a.fml,0)-isnull(b.fml,0),
a.期初库存=ISNULL(b.期末库存,0),
a.期末库存=ISNULL(a.期末库存,0)
from #temp_WhFromendheji_Month a,#temp_WhFromheji_Month b
where a.cGoodsTypeNo=b.cGoodsTypeNo

--print dbo.getTimeStr(GETDATE())
--print 4

if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select a.cGoodsTypeNo,a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,
a.fMoney_Cost,a.fml,a.fPrice_Avg,
a.期初库存,a.期末库存,当前库存=CAST(0 as money),当前库存金额=CAST(0 as money),在途数量=CAST(0 as money),
b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数,
a.库存状态,a.应销未订货,a.畅销状态,
a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日,a.Sys可销天数,a.cGoodsTypename,
上月销售金额=CAST(null as money),上月销售数量=CAST(null as money) ,上月成本金额=CAST(null as money)
into #temp_goodsKuCunml
from #temp_WhFromendheji_Month a,#temp_WhFromVIP b
where a.cGoodsTypeNo=b.cGoodsTypeNo

CREATE INDEX IX_temp_goodsKuCunml  ON #temp_goodsKuCunml(cGoodsTypeNo)

-----------获取当前库存------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
declare @dDate date
set @dDate=CONVERT (date, GETDATE())

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null  drop table #temp_Goods
select a.cGoodsNo into #temp_Goods
from t_Goods a,#temp_WhFromGoods b
where a.cGoodsTypeno=b.cGoodsTypeno

 
exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDate,@dDate,@cWhno  
 
--print dbo.getTimeStr(GETDATE())
--print 5 
  
CREATE INDEX IX_temp_goodsKuCurQty  ON #temp_goodsKuCurQty(cGoodsNo)


if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty1'))is not null  drop table #temp_goodsKuCurQty1
select b.cGoodsTypeno,EndQty=sum(EndQty),Endmoney=SUM(Endmoney)--,b.cGoodsTypename
into #temp_goodsKuCurQty1 from 
#temp_goodsKuCurQty a,t_Goods b
where a.cGoodsNo=b.cGoodsNo
group by b.cGoodsTypeno--,b.cGoodsTypename

---------获取上个月的正月销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cgoodsno varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fMoney_Cost money)
declare @ddatebgn1 datetime
declare @lastBgn1 datetime
declare @lastEnd1 datetime
set @ddatebgn1=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
set @lastBgn1=DATEADD(MONTH,-1,@ddatebgn1)
set @lastEnd1=DATEADD(DAY,-1,@ddatebgn1) 

declare @day int
set @day=DATEDIFF (DAY,@lastBgn1,@lastEnd1)+1

--  print '13002    '+dbo.getTimeStr(GETDATE())

exec p_GetLastMonthSale_wei @lastBgn1,@lastEnd1,@cWHno,@DbName

 -- print '13003    '+dbo.getTimeStr(GETDATE())
 if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty1Type'))is not null  drop table #temp_goodsKuCurQty1Type
select b.cGoodsTypeno,EndQty=sum(xsQty),Endmoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost)
into #temp_goodsKuCurQty1Type from 
#temp_GetLastMonthSale_wei a,t_Goods b
where a.cGoodsNo=b.cGoodsNo
group by b.cGoodsTypeno
 

update a
set a.上月销售数量=b.EndQty,a.上月销售金额=b.Endmoney,a.上月成本金额=b.fMoney_Cost
from #temp_goodsKuCunml a,#temp_goodsKuCurQty1Type b
where a.cGoodsTypeno=b.cGoodsTypeno
 
 /*
 update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月销售数量,0)<>0 
then ISNULL(b.EndQty,0)*@day/ISNULL(a.上月销售数量,0) 
else case when ISNULL(a.上月销售数量,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end  end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_goodsKuCunml a left join #temp_goodsKuCurQty1 b
on  a.cGoodsTypeNo=b.cGoodsTypeNo
*/
 update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月成本金额,0)<>0 
then ISNULL(b.Endmoney,0)*@day/ISNULL(a.上月成本金额,0) 
else case when ISNULL(a.上月成本金额,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end  end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_goodsKuCunml a left join #temp_goodsKuCurQty1 b
on  a.cGoodsTypeNo=b.cGoodsTypeNo


--print dbo.getTimeStr(GETDATE())
--print 6
-----
update #temp_goodsKuCunml
set 畅销状态='畅销商品',库存状态='低库存'--,商品状态='正常'
where 可销天数>=0 and 可销天数<=3

update #temp_goodsKuCunml
set 畅销状态='一般商品',库存状态='正常'--,商品状态='正常'
where 可销天数>3 and 可销天数<=15

update #temp_goodsKuCunml
set 畅销状态='滞销商品',库存状态='高库存'--,商品状态='正常'
where 可销天数>15

update #temp_goodsKuCunml
set  库存状态='零库存'--,商品状态='待进货'
   ,畅销状态='一般商品'
where isnull(当前库存,0)=0

update #temp_goodsKuCunml
set 库存状态='负库存',畅销状态='一般商品'--,商品状态='待进货'
where 当前库存<0


update  a
set a.cGoodsTypename=b.cGoodsTypename
from #temp_goodsKuCunml a,t_Goodstype b
where a.cGoodsTypeNo=b.cGoodsTypeno and ISNULL(a.cGoodsTypename,'')=''


if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
begin
    insert into #temp_GetKuCunMaoli_wei(
	cGoodsTypeno,cGoodsTypename,销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,会员销售占比
	--,商品状态,最后销售日
	)
	select cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,
	fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,
	会员销售占比=case when isnull(销售金额,0)<>0 then (会员销售金额/销售金额)*100 else 0 end
	--,a.商品状态,最后销售日=ISNULL(CONVERT(VARCHAR(100),a.最后销售日,23),'30日内未销售')
	 from #temp_goodsKuCunml 
	 union all
	select cGoodsTypeno='合计:',cGoodsTypename=null,
	销售数量=SUM(销售数量),销售金额=SUM(销售金额),特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),
	正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),fMoney_cost=SUM(fMoney_cost),fml=SUM(fml),
	fPrice_Avg=null,期初库存=SUM(期初库存),期末库存=SUM(期末库存),
	当前库存=SUM(当前库存),当前库存金额=SUM(当前库存金额),在途数量=SUM(在途数量),会员销售数量=SUM(会员销售数量),
	会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),
	来客数=SUM(来客数),库存状态=null,畅销状态=null,毛利状态=null,可销天数=null,
	会员销售占比=null 
	 from #temp_goodsKuCunml  
	 order by cGoodsTypeno
	 
	 
	 exec('
  if (select object_id(''U_key.dbo.s_'+@Key+'''))is not null 
  drop table U_key.dbo.s_'+@Key+'

		  	 select cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,会员销售占比
			into  U_key.dbo.s_'+@Key+'
			from #temp_GetKuCunMaoli_wei 
	 
   ')
end else
begin
 select 
	 cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,
	fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,
	会员销售占比=case when isnull(销售金额,0)<>0 then (会员销售金额/销售金额)*100 else 0 end
	--,a.商品状态,最后销售日=ISNULL(CONVERT(VARCHAR(100),a.最后销售日,23),'30日内未销售')
	 from #temp_goodsKuCunml 
	 union all
	 select cGoodsTypeno='合计:',cGoodsTypename=null,
	销售数量=SUM(销售数量),销售金额=SUM(销售金额),特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),
	正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),fMoney_cost=SUM(fMoney_cost),fml=SUM(fml),
	fPrice_Avg=null,期初库存=SUM(期初库存),期末库存=SUM(期末库存),
	当前库存=SUM(当前库存),当前库存金额=SUM(当前库存金额),在途数量=SUM(在途数量),会员销售数量=SUM(会员销售数量),
	会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),
	来客数=SUM(来客数),库存状态=null,畅销状态=null,毛利状态=null,可销天数=null,
	会员销售占比=null 
	 from #temp_goodsKuCunml  
	 order by cGoodsTypeno
end
end
GO
