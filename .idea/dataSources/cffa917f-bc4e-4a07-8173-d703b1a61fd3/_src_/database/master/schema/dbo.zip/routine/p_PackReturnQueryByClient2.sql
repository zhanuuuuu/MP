
/*
计算某段时间返还供应商包装的情况
exec p_PackReturnQueryByClient2 delphi_Goods,'2008-12-10','2009-12-12'

*/
create proc [dbo].[p_PackReturnQueryByClient2]
@delphiTable varchar(32),
@date1 datetime,
@date2 datetime
as
begin
exec('

    if (select object_id(''tempdb..#temp_PackHistory''))is not null
    drop table #temp_PackHistory
    if (select object_id(''tempdb..#temp_PackHistory2''))is not null
    drop table #temp_PackHistory2
    if (select object_id(''tempdb..#temp_Last''))is not null
    drop table #temp_Last
	create table #temp_PackHistory
	(
	 cSupNo varchar(32),
	 cSupName varchar(64),
	 cPackNo varchar(32),
	 cPackName varchar(64),
	 fPrice money,
	 fQty_In money,
	 fMoney_In money,
     fQty_Ret money,
     fMoney_Ret money,
	 fQty_Lost money,
     fMoney_Lost money,
     fQty_Des money,
     fMoney_Des money,
	 fQty_NoRet money,
     fMoney_NoRet money,
     fQty_Normal money,--正常包装数
     fMoney_Normal money,
     fQty_whole money,--返还的包装总数
     fMoney_Whole money
	)
	create table #temp_PackHistory2
	(
	 cSupNo varchar(32),
	 cSupName varchar(64),
	 cPackNo varchar(32),
	 cPackName varchar(64),
	 fPrice money,
	 fQty_In money,
	 fMoney_In money,
     fQty_Ret money,
     fMoney_Ret money,
	 fQty_Lost money,
     fMoney_Lost money,
     fQty_Des money,
     fMoney_Des money,
	 fQty_NoRet money,
     fMoney_NoRet money,
     fQty_Normal money,--正常包装数
     fMoney_Normal money,
     fQty_whole money,--返还的包装总数
     fMoney_Whole money
	)

	declare @MinDate datetime
	select @Mindate=Min(dDate) from dbo.t_PackOutWarehouse

	insert into #temp_PackHistory
	exec p_PackReturnQueryByClient '''+@delphiTable+''','''+@date1+''','''+@date2+'''

	insert into #temp_PackHistory2
	exec p_PackReturnQueryByClient '''+@delphiTable+''',@Mindate,'''+@date2+'''

    select a.cSupNo,a.cSupName,a.cPackNo,a.cPackName,a.fPrice,a.fQty_In,a.fMoney_In,a.fQty_Ret,a.fMoney_Ret,
    a.fQty_Lost,a.fMoney_Lost,a.fQty_Des,a.fMoney_Des,b.fQty_NoRet,b.fMoney_NoRet,a.fQty_Normal,a.fMoney_Normal,
    a.fQty_whole,a.fMoney_Whole
    into #temp_Last
	from #temp_PackHistory a,#temp_PackHistory2 b
	where a.cSupNo=b.cSupNo and a.cPackNo=b.cPackNo
    order by a.cSupNo
    
    select cSupNo,cSupName,cPackNo,cPackName,fPrice,fQty_In,fMoney_In,fQty_Ret,fMoney_Ret,
    fQty_Lost,fMoney_Lost,fQty_Des,fMoney_Des,fQty_NoRet,fMoney_NoRet,fQty_Normal,fMoney_Normal,
    fQty_whole,fMoney_Whole
    from #temp_Last    
    union all
    select cSupNo,cSupName,cPackNo=''合计'',cPackName=''ZZZZZZZZZZZ'',fPrice='''',
    fQty_In=sum(fQty_In),fMoney_In=sum(fMoney_In),fQty_Ret=sum(fQty_Ret),fMoney_Ret=sum(fMoney_Ret),
    fQty_Lost=sum(fQty_Lost),fMoney_Lost=sum(fMoney_Lost),fQty_Des=sum(fQty_Des),fMoney_Des=sum(fMoney_Des),
    fQty_NoRet=sum(fQty_NoRet),fMoney_NoRet=sum(fMoney_NoRet),fQty_Normal=sum(fQty_Normal),fMoney_Normal=sum(fMoney_Normal),
    fQty_whole=sum(fQty_whole),fMoney_Whole=sum(fMoney_Whole)
    from #temp_Last
    group by cSupNo,cSupName
    order by cSupNo,cPackNo


')
end

--cSupNo,cSupName,cPackNo,cPackName,fPrice,QtyIn,fMoneyIn,QtyRet,fMoneyRet,QtyLost,fMoneyLost,
--QtyDes,fMoneyDes,QtyNoRet,fMoneyNoRet,QtyNormal,fMoneyNormal,QtyWhole,fMoneyWhose


GO
