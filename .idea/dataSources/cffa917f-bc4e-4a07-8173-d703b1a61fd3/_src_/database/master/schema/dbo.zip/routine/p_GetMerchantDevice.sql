 
/*

 
 exec  [p_GetMerchantOneDevice] '2016031916515465095992','自动售货机%20TSO001-北京-001','',''
 
*/

/*
   1：设备名称   【posname】
   2：投放地址    【cAddRess】
   3：投放日期区间 【dCreateDate】
   4：设备类型      【iType】
   5：设备描述       【cDescription】
   5：故障类型        【暂时没有】
   6：故障描述         【暂时没有】
   7：营业额区间        【暂时没有】
 
*/
 
create  proc [dbo].[p_GetMerchantDevice]
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@strWhere varchar(8000)
as
begin   
   if @strWhere='' 
   BEGIN
     set @strWhere='1=1'
   end
   exec('
   select posname as name,posid,iType,cAddRess as address,cMapLocation as MapLocation,
   cDescription as Description,dCreateDate as deployDate
   from t_posstation where cStoreNo='''+@Merchantid+''' and  '+@strWhere+'
   ')
   
end
 
--201512081042459907426
--2016031852549-10007
GO
