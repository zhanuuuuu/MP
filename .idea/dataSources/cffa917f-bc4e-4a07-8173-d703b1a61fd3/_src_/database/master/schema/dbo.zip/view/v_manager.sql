/*
select * from v_manager
*/

CREATE view v_manager
as
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='盘点单',remark=null,
tablename='wh_CheckWh',tablename_detail='wh_CheckWhDetail'
from dbo.wh_CheckWh
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='溢出单',remark=null,
tablename='wh_EffusionWh',tablename_detail='wh_EffusionWhDetail'
from dbo.wh_EffusionWh
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='兑奖单',remark=null,
tablename='wh_Exchange',tablename_detail='wh_ExchangeDetail'
from dbo.wh_Exchange
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='入库单/上货单',remark=null,
tablename='wh_InWarehouse',tablename_detail='wh_InWarehouseDetail'
from dbo.wh_InWarehouse
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='报损单',remark=null,
tablename='wh_LossWarehouse',tablename_detail='wh_LossWarehouseDetail'
from dbo.wh_LossWarehouse
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='出库单',remark=null,
tablename='wh_OutWarehouse',tablename_detail='wh_OutWarehouseDetail'
from dbo.wh_OutWarehouse
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='返厂单',remark=null,
tablename='wh_RbdWarehouse',tablename_detail='wh_RbdWarehouseDetail'
from dbo.wh_RbdWarehouse
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='客退单',remark=null,
tablename='WH_ReturnGoods',tablename_detail='WH_ReturnGoodsDetail'
from dbo.WH_ReturnGoods
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,remark='采购单',remark=null,
tablename='WH_Stock',tablename_detail='WH_StockDetail'
from dbo.WH_Stock
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='收货单',remark=null,
tablename='wh_StockVerify',tablename_detail='wh_StockVerifyDetail'
from dbo.wh_StockVerify
union all
select cSheetno,cOperatorNo,cOperator,dFillin,cFillinTime,cManagerNo,cManager,
bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,sheetname='调拨单',remark=null,
tablename='wh_TfrWarehouse',tablename_detail='wh_TfrWarehouseDetail'
from dbo.wh_TfrWarehouse
union all
select cSheetno=jiesuanno,
cOperatorNo=substring(caiwu,1,
											case when patindex('%-%',caiwu)-1>0 
														then patindex('%-%',caiwu)-1 
														else 0 
											end),
cOperator=substring(caiwu,
											case when patindex('%-%',caiwu)>0 
														then patindex('%-%',caiwu)+1
														else 32 
											end,32),
dFillin=jiesuanriqi,cFillinTime=null,
cManagerNo=null,cManager=null,
bAgree=null,cExaminerNo=null,cExaminer=null,bExamin=null,
cWhNo,cWh,sheetname='商户结算单',remark=dbo.getdaystr(riqi1)+'至' +dbo.getdaystr(riqi2),
tablename='t_supplier_jiesuan',tablename_detail=null
from dbo.t_supplier_jiesuan
GO
