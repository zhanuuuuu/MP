
CREATE procedure P_Z_subtractScoreTo_t_vip
 @cVipno varchar(16),
 @score money
as
begin
	declare @curValue money
	select @curValue=fCurValue
	from t_Vip
	where cVipno=@cVipno
  
  update t_Vip
  set fCurValue=isnull(@curValue,0)-isnull(@score,0)
  where cVipno=@cVipno
end

GO
