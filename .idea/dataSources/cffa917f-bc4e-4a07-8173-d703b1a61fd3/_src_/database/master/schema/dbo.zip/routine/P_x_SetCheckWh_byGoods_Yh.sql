/*
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select distinct cGoodsNo into #temp_Goods from t_Goods  where cGoodsNo='11001'
declare @bJiaGong bit
exec [P_x_SetCheckWh_byGoods_Yh]
'2013-05-13','2013-05-13','02',@bJiaGong,'32300'
*/
/*按商品信息查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_byGoods_Yh]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32),/*是仓库No*/
@bJiaGong bit,
@cGoodsNo varchar(32)
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-06-26' set @dDateEnd='2012-06-26' set @cWhNo='01' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods where cGoodsNo='7100018'

declare @dDateBgn1 datetime
set @dDateBgn1=@dDateBgn-7

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo  into #temp_Goods  from t_Goods where cBarcode=@cGoodsNo or 
cGoodsNo=@cGoodsNo or cGoodsNo=(select cGoodsNo_parent from t_Goods_Union where cBarcode=@cGoodsNo)


if (select OBJECT_ID('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select * into #tmpCostGoodsList from #temp_Goods

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname,@cWhNo=cWhNo from dbo.t_WareHouse --where cWhNo=@cWHno
where bMainSale=1




if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin ([dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,
[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,
[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,
[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,
[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)
CREATE TABLE #temp_end (  
[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,
[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,
[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,
[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,
[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)

if (select OBJECT_ID('tempdb..#FindGoodsList0'))is not null drop table #FindGoodsList0
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #FindGoodsList0
from t_goods a, #tmpCostGoodsList b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1
--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#FindGoodsList1'))is not null drop table #FindGoodsList1
select cGoodsNO
into #FindGoodsList1
from #tmpCostGoodsList
union all
select cGoodsNo_MinPackage
from #FindGoodsList0
where ISNULL(bIsPack,0)=1
union all
select b.cGoodsNo
from #FindGoodsList0 a,t_goods b
where ISNULL(a.bIsPack,0)=0
and a.cGoodsNo=b.cGoodsNo_minPackage

if (select OBJECT_ID('tempdb..#t_FindGoods'))is not null drop table #t_FindGoods
select distinct cGoodsNO,cSupNO,bStorage
into #t_FindGoods
from t_goods
where cGoodsNo in(select cgoodsno from #FindGoodsList1)

--取商品(管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
select distinct cGoodsNo,cSupNo
into #tmpPloyOfGoodsinfo
from #t_FindGoods 
where isnull(bStorage,0)=1

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='+@cWHno+''
insert into #temp_date exec (@SQLstr)
select @date=isnull(MaxDate,'2000-01-01') from #temp_date


--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)
if(@date>=@dDateBgn1-1)
	begin
		if (@date<@dDateEnd)    
			begin
					set @date1=@date+1
					set @date2=@dDateEnd
			end
		else
			begin
					set @date1=''
					set @date2=''
					set @date=@dDateEnd
			end
	end
else
	begin 
		set @date1=@date+1
		set @date2=@dDateEnd 
	end

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDateBgn1,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
insert into #temp_end  ([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDateEnd,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
			a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
			a.Ratio=b.Ratio,a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@dDateBgn1-1)+''' and b.cWHno='+@cWHno+'
             '
set @SQLstr1='update a
                       set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
            
							a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
							a.Ratio=b.Ratio,a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='+@cWHno+'
            '
exec (@SQLstr+@SQLstr1)

--以上计算期末库存

if (select OBJECT_ID('tempdb..#temp_ready'))is not null drop table #temp_ready
if (select OBJECT_ID('tempdb..#temp_ready1'))is not null drop table #temp_ready1
select 
GoodsNo_Pdt=a.cGoodsNo,cUnitedNo=null,cGoodsName=null,cBarcode=null,BeginDate=@dDateBgn1,BeginQty=isnull(b.fQuantity,0),EndDate=@dDateEnd,
EndQty=isnull(a.fQuantity,0),
xsQty=-(isnull(a.total_Sale0,0)-isnull(b.total_Sale0,0)+isnull(a.total_Sale1,0)-isnull(b.total_Sale1,0)),

fCKPrice=CAST(0 as money),fNormalPrice=CAST(0 as money),avgInPrice=isnull(a.fPrice_Avg,0),
fCKPriceMoney=CAST(0 as money),
fNormalPriceMoney=CAST(0 as money),avgInPriceMoney=CAST(0 as money)
into #temp_ready
from #temp_end a left join #temp_begin b 
on a.cGoodsNo=b.cGoodsNo

---包装转单品
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

update a
set a.GoodsNo_Pdt=b.cGoodsNO_minPackage,
    a.BeginQty=a.BeginQty*b.fQty_minPackage,
    a.EndQty=a.EndQty*b.fQty_minPackage,
   
	a.xsQty=a.xsQty*b.fQty_minPackage
from #temp_ready a,#tmpPackGoodsList b
where a.GoodsNo_Pdt=b.cGoodsNo

if (select OBJECT_ID('tempdb..#temp_readyFor1'))is not null drop table #temp_readyFor1
select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,BeginDate,
BeginQty=SUM(BeginQty),EndDate,EndQty=SUM(EndQty),xsQty=SUM(xsQty),
fCKPrice,fNormalPrice,avgInPrice,fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney
into #temp_readyFor1
from #temp_ready
group by GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,BeginDate,
EndDate,fCKPrice,fNormalPrice,avgInPrice,fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney

/*
select * from #tmpPloyOfGoodsinfo
select * from #temp_readyFor1
select * from #temp_ready
select * from #temp_ready1
*/
select GoodsNo_Pdt=a.cGoodsNo,cUnitedNo=b.cUnitedNo,cGoodsName=b.cGoodsName,cBarcode=b.cBarcode,
BeginDate,BeginQty,EndDate,EndQty,fCKPrice=b.fCKPrice,fNormalPrice=b.fNormalPrice,avgInPrice,xsQty,
fCKPriceMoney=EndQty*ISNULL(b.fCKPrice,0),fNormalPriceMoney=EndQty*ISNULL(b.fNormalPrice,0),avgInPriceMoney=EndQty*ISNULL(c.avgInPrice,0)
into #temp_ready1
from #tmpPloyOfGoodsinfo a left join #temp_readyFor1 c on c.GoodsNo_Pdt=a.cGoodsNo
,t_goods b 
where a.cGoodsNo=b.cGoodsNo

--update #temp_ready1 set BeginDate=@dDateBgn,EndDate=@date

--盘点信息
	-------期末前最新盘点日期-----------------------------------------------------
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	select a.cGoodsNo,dDate=MAX(b.dDate)
	into #templast_pd0
	from wh_CheckWhDetail a left join wh_CheckWh b
	on a.cSheetno=b.cSheetno 
	where dDate between @date1 and @date2 
	and isnull(bExamin,0)=1 
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmpPloyOfGoodsinfo)
	group by a.cGoodsNo order by a.cGoodsNo
	--select * from #templast_pd0
	-------期末前最新盘点日期+数量------------------------------------------------
	if(select object_id('tempdb..#templast_pd_num0')) is not null drop table #templast_pd_num0
	select a.cGoodsNO,a.dDate,fQuantity=sum(isnull(b.fQuantity,0)),fMoney=sum(isnull(b.fMoney,0))---wh_CheckWhDetail.fMoney在盘点单中为空，应该从成本分配表中取
	into #templast_pd_num0
	from #templast_pd0 a,
	(
		select x.cGoodsNO,x.fQuantity,x.fMoney,y.dDate
		from wh_CheckWhDetail x,wh_CheckWh y
		where x.cSheetno=y.cSheetno and y.cWhNo=@cWHno
	) b
	where a.dDate=b.dDate and a.cGoodsNo=b.cGoodsNo
	group by  a.cGoodsNO,a.dDate

	---日期、数量组合一起
	if(select object_id('tempdb..#templast_pd')) is not null drop table #templast_pd
	select a.*,fQuantity=isnull(b.fQuantity,0),dDateEnd=@date2,b.fMoney
	into #templast_pd
	from #templast_pd0 a left join #templast_pd_num0 b 
	on a.cGoodsNo=b.cGoodsNo and a.dDate=b.dDate
--select * from #templast_pd


if (select OBJECT_ID('tempdb..#temp_Max30'))is not null drop table #temp_Max30
create table #temp_Max30 (GoodsNo_Pdt varchar(32),xsQty money,fNormalPriceMoney money,fckMoney money)  
declare @dDateBgn2 datetime
set @dDateBgn2=@dDateBgn-30


if(@date>=@dDateEnd)
begin
		--select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,
		--BeginDate,BeginQty,EndDate,EndQty,xsQty,
	
		--fCKPrice,fNormalPrice,avgInPrice,
		--fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney
		--from #temp_ready1
		--where BeginDate is not null
		
		select GoodsNo_Pdt,cUnitedNo,
cGoodsName,cBarcode,
BeginDate,BeginQty,EndDate,EndQty,
xsQty,
fCKPrice,fNormalPrice,avgInPrice,
fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
fNormalPriceMoney7=isnull(fNormalPrice,0)*isnull(xsQty,0),
fckpriceMoney7=isnull(fCKPrice,0)*isnull(xsQty,0)
--,fEndQuantity_Diff 
into #temp_Min7_z
from #temp_ready1
where BeginDate is not null



 exec [P_x_SetCheckWh_byGoods_Yh30]
@dDateBgn2,@dDateEnd,@cWhNo,@bJiaGong,@cGoodsNo

select a.GoodsNo_Pdt,a.cGoodsName,a.cBarcode,a.EndQty,xsQty7=a.xsQty,
a.fNormalPriceMoney7,
a.fckpriceMoney7,
mult7= case  when a.fNormalPriceMoney7>0 then (fNormalPriceMoney7-fckpriceMoney7)/fNormalPriceMoney7*100
       else 0 end,
xsQty30=b.xsQty,fNormalPriceMoney30=b.fNormalPriceMoney,fckpriceMoney30=b.fckMoney,
mult30=case  when b.fNormalPriceMoney>0 then (b.fNormalPriceMoney-b.fckMoney)/b.fNormalPriceMoney*100
       else 0 end
from #temp_Min7_z a,#temp_Max30 b
where a.GoodsNo_Pdt=b.GoodsNo_Pdt

end
		
if (@date<@dDateEnd )    
begin
	
    declare @dMaxDailyDate datetime
    set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1
    --if (@dMaxDailyDate-1)>=@date2 set @dMaxDailyDate=@date2+1
---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
		if (select OBJECT_ID('tempdb..#temp_SaleSheet_day'))is not null drop table #temp_SaleSheet_day
 		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),
 		a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day
		from #tmpPloyOfGoodsinfo a,t_SaleSheet_Day b 
		where b.dSaleDate between @date1 and @date2
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo
		union all
		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),
		a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b
		where b.dSaleDate between @dMaxDailyDate and @date2 
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo
		----正价销售iAttribute=20,特价21
		select dDateTime=b.dSaleDate,a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo

		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day

		--入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

	    union all
		select @date2,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
/*		select * from #GoodsCurStorageList where cGoodsNo='15525'
*/
		--以上计算期末库存
		/*---包装转单品*/
		--if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
		--select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
		--into #tmpPackGoodsList
		--from t_goods
		--where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,BeginQty=cast(null as money),EndQty=cast(null as money),
		cGoodsName=cast(null as varchar(64)),cUnitedNo=cast(null as varchar(32)),
		cBarcode=cast(null as varchar(32)),
        fNormalPrice=cast(null as money),
		BeginDate=cast(null as datetime),EndDate=cast(null as datetime),
		xsQty=cast(0 as money),fCKPrice=cast(0 as money),avgInPrice=cast(0 as money),
		fCKPriceMoney=cast(0 as money),fNormalPriceMoney=cast(0 as money),
		avgInPriceMoney=cast(0 as money)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsNo,cWhNo
		

		update a
		set a.cBarcode=b.cBarcode,a.fNormalPrice=b.fNormalPrice,a.EndDate=@date2,a.fCKPrice=b.fCKPrice,
		a.cGoodsName=b.cGoodsName
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo 


		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo
		

		--更新销售数量
		update a
		set a.xsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDateBgn1 and @date2 and (iAttribute=20 or iAttribute=21)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo


--计算最新成本
      update a
	    set a.fMoney=a.fQuantity*b.fPrice_Avg
	    from #GoodsCurStorageList a,#temp_end b
	    where a.cGoodsNo=b.cGoodsNo

		update a
		set a.fMoney=ISNULL(a.fQuantity,0)*ISNULL(b.fCKPrice,0)
		from #GoodsCurStorageList a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and a.fMoney is null
		

		
		if(@date<@dDateBgn1-1)
			Begin
			  update a
				set a.BeginQty=ISNULL(a.BeginQty,0)+isnull(b.EndQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0),
				a.avgInPrice=isnull(b.avgInPrice,0)--,a.fEndQuantity_Diff=isnull(b.fEndQuantity_Diff,0)
				from #tmpGoodsListInfo_1 a,#temp_ready1 b
				where a.cGoodsNo=b.GoodsNo_Pdt 
				
				update a
				set a.EndQty=isnull(b.fqty,0)
				from #tmpGoodsListInfo_1 a,
				(
					select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
					from (
						   select cGoodsNo,fQuantity from #templast_pd 
						   union all 
						   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
						   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
						 ) x
					group by cGoodsNo
				)b
				where a.cGoodsNo=b.cGoodsNo 
				
				update #tmpGoodsListInfo_1
				set cWHno=@cWhNo,BeginDate=@dDateBgn1,EndDate=@dDateEnd,BeginQty=ISNULL(BeginQty,0),EndQty=isnull(EndQty,0)
				   -- ,fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)

			end
		else
			Begin
			  update a
				set a.BeginQty=ISNULL(a.BeginQty,0)+isnull(b.BeginQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0),
			
				a.xsQty=isnull(a.xsQty,0)+isnull(b.xsQty,0),

				a.avgInPrice=isnull(b.avgInPrice,0)
				from #tmpGoodsListInfo_1 a,#temp_ready1 b
				where a.cGoodsNo=b.GoodsNo_Pdt 
				
				update a
				set a.EndQty=isnull(b.fqty,0)
				from #tmpGoodsListInfo_1 a,
				(
					select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
					from (
						   select cGoodsNo,fQuantity from #templast_pd 
						   union all 
						   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
						   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
						 ) x
					group by cGoodsNo
				)b
				where a.cGoodsNo=b.cGoodsNo 
				
				update #tmpGoodsListInfo_1
				set cWHno=@cWhNo,BeginDate=@dDateBgn1,EndDate=@dDateEnd,BeginQty=ISNULL(BeginQty,0),EndQty=isnull(EndQty,0)
				    --,fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
		
			end
	
			update #tmpGoodsListInfo_1
			set fCkPriceMoney=isnull(EndQty,0)*isnull(fCkPrice,0),
				fNormalPriceMoney=isnull(EndQty,0)*isnull(fNormalPrice,0),
				avgInPriceMoney=isnull(EndQty,0)*isnull(avginPrice,0)

select GoodsNo_Pdt=cGoodsNo,cUnitedNo,
cGoodsName,cBarcode,
BeginDate,BeginQty,EndDate,EndQty,
xsQty,
fCKPrice,fNormalPrice,avgInPrice,
fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney
--,fEndQuantity_Diff 
into #temp_Min7
from #tmpGoodsListInfo_1
where BeginDate is not null



 exec [P_x_SetCheckWh_byGoods_Yh30]
@dDateBgn2,@dDateEnd,@cWhNo,@bJiaGong,@cGoodsNo

select a.GoodsNo_Pdt,a.cGoodsName,a.cBarcode,a.EndQty,xsQty7=a.xsQty,
fNormalPriceMoney7=isnull(a.fNormalPrice,0)*isnull(a.xsQty,0),
fckpriceMoney7=isnull(a.fCKPrice,0)*isnull(a.xsQty,0),
mult7= case  when a.xsQty>0 then (isnull(a.fNormalPrice,0)*isnull(a.xsQty,0)-isnull(a.fCKPrice,0)*isnull(a.xsQty,0))/isnull(a.fNormalPrice,0)*isnull(a.xsQty,0)*100
       else 0 end,
xsQty30=b.xsQty,fNormalPriceMoney30=b.fNormalPriceMoney,fckpriceMoney30=b.fckMoney,
mult30=case  when b.fNormalPriceMoney>0 then (b.fNormalPriceMoney-b.fckMoney)/b.fNormalPriceMoney*100
       else 0 end
from #temp_Min7 a,#temp_Max30 b
where a.GoodsNo_Pdt=b.GoodsNo_Pdt


end
GO
