/*
p_GetStorage_SaleSheet_Day '2009-10-10'
*/

CREATE procedure p_GetStorage_SaleSheet_Day
@dDate datetime
as
begin

  if(select object_id('tempdb..#temp_Goods')) is not null
  begin
	  drop table #temp_Goods
  end
  select cGoodsNo into #temp_Goods from t_Goods

	select distinct a.cGoodsNo,a.fQty_CurWH,a.dSaleDate,fQty_noDaily=cast(0 as money)
  into #temp_SaleSheet_Day
  from t_SaleSheet_Day a,
  (
   
		select  cGoodsNo,dSaleDate_last=max(dSaleDate)
		from dbo.t_SaleSheet_Day
    where cGoodsNo in (select cGoodsNo from #temp_Goods)
		group by cGoodsNo
  ) b
  where a.dSaleDate=b.dSaleDate_last and a.cGoodsNo=b.cGoodsNo
  
  declare @dDate_Maxdaily datetime
  declare @dDate_now datetime
  select @dDate_Maxdaily=isnull(max(dDate),'2000-01-01') from dbo.t_Daily_history
  set @dDate_now=cast(dbo.getdaystr(getdate()) as datetime)

  update a set a.fQty_CurWH=a.fQty_CurWH-b.fQty,a.fQty_noDaily=b.fQty
  from #temp_SaleSheet_Day a,
  (
  select cGoodsNo,fQty=sum(fQuantity)
  from t_SaleSheetDetail
  where dSaleDate between @dDate_Maxdaily and @dDate_now
  group by cGoodsNo
  ) b
	where a.cGoodsNo=b.cGoodsNo
  select * from #temp_SaleSheet_Day


end
GO
