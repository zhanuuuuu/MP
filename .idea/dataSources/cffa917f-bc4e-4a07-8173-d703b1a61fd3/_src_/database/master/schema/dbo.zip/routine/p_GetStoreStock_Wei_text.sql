/*

select * from tem
 
select cStoreNo into U_Key.dbo.temp_Store from t_Store where cStoreNo<>'000'

exec [p_GetStoreStock_Wei_text] '2017-2-14','2017-2-14',''

 */
CREATE proc [dbo].[p_GetStoreStock_Wei_text]
@dDate1 datetime,
@dDate2 datetime,
@cTermID varchar(32)
as
begin
    if (select object_id('tempdb..#tmp_Store'))is not null drop table #tmp_Store
	create table #tmp_Store(cStoreNo varchar(32),cStoreName varchar(64))
	
	insert into #tmp_Store(cStoreNo,cStoreName) values('1','合计')
	
	exec('
	   insert into #tmp_Store(cStoreNo,cStoreName)
	  select distinct a.cStoreNo,b.cStoreName+''''+a.cStoreNo
	  --  select distinct a.cStoreNo,''a''+a.cStoreNo+'''' 
	   from U_Key.dbo.temp_Store'+@cTermID+' a,t_Store b
	   where a.cStoreNo=b.cStoreNo   
	')
 
	
	update #tmp_Store set cStoreName=replace(cStoreName,'路发万家-','')
	
	if (select object_id('tempdb..#tmp_ShipSheet'))is not null drop table #tmp_ShipSheet

	select a.dDate,cStoreNo,b.cGoodsNo,fQuantity,b.cGoodsName
	into #tmp_ShipSheet
	from WH_BhApply a,WH_BhApplyDetail b
	where dDate between @dDate1 and @dDate2 
	and a.cSheetno=b.cSheetno
	and ISNULL(bfresh,0)=1
	and ISNULL(MbExamin,0)=1

	
    if (select object_id('tempdb..#tmp_StoreSortGoods'))is not null drop table #tmp_StoreSortGoods
	select a.cStoreNo,b.cStoreName,fQty=sum(a.fQuantity),a.cGoodsNo,a.cGoodsName
	into #tmp_StoreSortGoods
	from #tmp_ShipSheet a,#tmp_Store b
	where a.cStoreNo=b.cStoreNo
	group by a.cStoreNo,b.cStoreName,a.cGoodsNo,a.cGoodsName
 
 
	if (select object_id('tempdb..#tmp_StoreOutGoods0'))is not null drop table #tmp_StoreOutGoods0
	select cStoreName=replace(cStoreName,'路发万家-',''),fQty,cGoodsNo,cGoodsName 
	into #tmp_StoreOutGoods0
	from #tmp_StoreSortGoods
	union all
	select '合计',fQty=SUM(fQty),cGoodsNo,cGoodsName 
	from #tmp_StoreSortGoods
	group by cGoodsNo,cGoodsName 
	
	select * from #tmp_StoreOutGoods0
 
 
DECLARE @sql VARCHAR(8000)
DECLARE @sql1 VARCHAR(8000)
DECLARE @sql2 VARCHAR(8000)

SET @sql=''  --初始化变量 @sql
SET @sql1=''  --初始化变量 @sql
SET @sql2=''  --初始化变量 @sql

 

SELECT @sql= @sql+',' +cStoreName ,
@sql1= @sql1+',' +cStoreName+'=isnull('+cStoreName+',0)',
@sql2= @sql2+',' +cStoreName+'=sum(isnull('+cStoreName+',0))'
FROM #tmp_Store GROUP BY cStoreNo,cStoreName --变量多值赋值
order by cStoreNo

--SELECT @sql= @sql+',' +cStoreName ,
--@sql1= @sql1+',' +cStoreName+'=isnull(['+cStoreName+'],0)',
--@sql2= @sql2+',' +cStoreName+'=sum(isnull(['+cStoreName+'],0))'
--FROM #tmp_Store GROUP BY cStoreNo,cStoreName --变量多值赋值
--order by cStoreNo


SET @sql= replace(STUFF(@sql,1,1,''),'-','')--去掉首个','
SET @sql1= replace(STUFF(@sql1,1,1,''),'-','')--去掉首个','
SET @sql2= replace(STUFF(@sql2,1,1,''),'-','')--去掉首个','
 
 select @sql
 
exec('
 select  cGoodsNo as 商品编号,cGoodsName as 商品名称,'+@sql1+' 
 from   #tmp_StoreOutGoods0 t
 PIVOT
 (sum(fQty) FOR  cStoreName IN ('+@sql+') )  a
  union all 
 select  cGoodsNo=null,cGoodsName=''合计'','+@sql2+' 
 from   #tmp_StoreOutGoods0 t
 PIVOT
 (sum(fQty) FOR  cStoreName IN ('+@sql+') )  a
 ')
 
end
GO
