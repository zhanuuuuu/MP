/*
  exec p_cPloyShenHeMen_Wei '2013080801a','pos_test'
*/
create proc p_cPloyShenHeMen_Wei
@cPloyNo varchar(32), --- 策略编号
@MenPosName varchar(32) --- 门店数据库名称
as
begin
  exec(
  '
    if (select OBJECT_ID(''tempdb..#temp_cPloyTypeNo''))is not null drop table #temp_cPloyTypeNo
	select distinct cPloyTypeNo,cPloyNo into #temp_cPloyTypeNo from t_PloyOfSale 
	where cPloyNo='''+@cPloyNo+'''
	
	if (select OBJECT_ID(''tempdb..#temp_cPloyType''))is not null drop table #temp_cPloyType
	select b.cPloyTypeNo,b.cPloyNo into #temp_cPloyType 
	from '+@MenPosName+'.dbo.t_PloyType a right join #temp_cPloyTypeNo b on
	a.cPloyTypeNo=b.cPloyTypeNo 
	where ISNULL(a.cPloyTypeNo,'''')=''''

	-------- 插入策略类别
	insert into  '+@MenPosName+'.dbo.t_PloyType
	(cPloyTypeNo,cPloyTypeName,cDetail,bExchange,
	 fOverMoney,fAddMoney,bPresent,dDate1,dDate2,fVipCardRatio,bVipCardRatio)
	 select a.cPloyTypeNo,cPloyTypeName,cDetail,bExchange,fOverMoney,fAddMoney,bPresent,
	 dDate1,dDate2,fVipCardRatio,bVipCardRatio 
	 from t_PloyType a,#temp_cPloyType b
	 where a.cPloyTypeNo=b.cPloyTypeNo
	 
	----获取本策略下的策略商品----
	if (select OBJECT_ID(''tempdb..#temp_cPloyGoodsNO''))is not null drop table #temp_cPloyGoodsNO
	select distinct cPloyNo,cGoodsNo into #temp_cPloyGoodsNO from t_PloyOfSale 
	where cPloyNo='''+@cPloyNo+'''
	
	
	
	-------获取分店该策略下已经存在的商品
	if (select OBJECT_ID(''tempdb..#temp_IncGoodsNO''))is not null drop table #temp_IncGoodsNO
	select b.cPloyNo,b.cGoodsNo into #temp_IncGoodsNO 
	from '+@MenPosName+'.dbo.[t_PloyOfSale] a,#temp_cPloyGoodsNO b
	where a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo
	

	
	------------- 修改分店策略下存在的商品
	if (select OBJECT_ID(''tempdb..#temp_GoodsNo1''))is not null drop table #temp_GoodsNo1
	SELECT a.[cPloyNo],a.[cGoodsNo],[cGoodsName],[fQuantity_Ploy],[fInPrice],[fPrice_SO],[dDateStart],[cTimeStart]
      ,[dDateEnd],[cTimeEnd],[iPriority],[bSO],[bPresent],[cPresentPloyNo],[cPloyTypeNo],[cPloyTypeName],[bEnabled]
      ,[Week1],[Week2],[Week3],[Week4],[Week5],[Week6],[Week7]
      ,[Hour0],[Hour1],[Hour2],[Hour3],[Hour4],[Hour5],[Hour6],[Hour7],[Hour8],[Hour9]
      ,[Hour10],[Hour11],[Hour12],[Hour13],[Hour14],[Hour15],[Hour16],[Hour17],[Hour18],[Hour19]
      ,[Hour20],[Hour21],[Hour22],[Hour23],[fSupRatio],[fVipValue],[bMult]
      ,[bLimitQty],[fLimitQty],[fRatio_JiOu],[bJiOu],[fQty_Ji],[fPrice_ji],[fQty_Ou],[fPrice_Ou]
      ,[bSuspend],[cSuspendMan],[dSuspend],[fPrice_SO_old],[cUpdateMan],[dUpdate],[bDownLoad]
      into #temp_GoodsNo1
  FROM [posmanagement].[dbo].[t_PloyOfSale] a,#temp_IncGoodsNO b
  where a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo
  
  UPDATE a set a.[fQuantity_Ploy]=b.fQuantity_Ploy,a.[fInPrice]=b.fInPrice,[fPrice_SO]=b.[fPrice_SO],[dDateStart]=b.[dDateStart]
      ,[cTimeStart]=b.[cTimeStart]
      ,[dDateEnd]=b.[dDateEnd],[cTimeEnd]=b.[cTimeEnd],[iPriority]=b.[iPriority],[bSO]=b.[bSO],[bPresent]=b.[bPresent]
      ,[cPresentPloyNo]=b.[cPresentPloyNo],[cPloyTypeNo]=b.[cPloyTypeNo],[cPloyTypeName]=b.[cPloyTypeName],[bEnabled]=b.[bEnabled]
      ,[Week1]=b.[Week1],[Week2]=b.[Week2],[Week3]=b.[Week3],[Week4]=b.[Week4],[Week5]=b.[Week5]
      ,[Week6]=b.[Week6],[Week7]=b.[Week7]
      ,[Hour0]=b.[Hour0],[Hour1]=b.[Hour1],[Hour2]=b.[Hour2],[Hour3]=b.[Hour3],[Hour4]=b.[Hour4]
      ,[Hour5]=b.[Hour5],[Hour6]=b.[Hour6],[Hour7]=b.[Hour7],[Hour8]=b.[Hour8],[Hour9]=b.[Hour9]
      ,[Hour10]=b.[Hour10],[Hour11]=b.[Hour11],[Hour12]=b.[Hour12],[Hour13]=b.[Hour13],[Hour14]=b.[Hour14]
      ,[Hour15]=b.[Hour15],[Hour16]=b.[Hour16],[Hour17]=b.[Hour17],[Hour18]=b.[Hour18],[Hour19]=b.[Hour19]
      ,[Hour20]=b.[Hour20],[Hour21]=b.[Hour21],[Hour22]=b.[Hour22],[Hour23]=b.[Hour23],[fSupRatio]=b.[fSupRatio]
      ,[fVipValue]=b.[fVipValue],[bMult]=b.[bMult],[bLimitQty]=b.[bLimitQty]
      ,[fLimitQty]=b.[fLimitQty],[fRatio_JiOu]=b.[fRatio_JiOu],[bJiOu]=b.[bJiOu],[fQty_Ji]=b.[fQty_Ji]
      ,[fPrice_ji]=b.[fPrice_ji],[fQty_Ou]=b.[fQty_Ou],[fPrice_Ou]=b.[fPrice_Ou]
      ,[bSuspend]=b.[bSuspend],[cSuspendMan]=b.[cSuspendMan],[dSuspend]=b.[dSuspend]
      ,[fPrice_SO_old]=b.[fPrice_SO_old],[cUpdateMan]=b.[cUpdateMan]
  FROM '+@MenPosName+'.[dbo].[t_PloyOfSale] a,#temp_GoodsNo1 b
  where a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo
  
  ------------ 获取那些没有的商品
   ---------- 删除那些已经存在的商品。。 
  delete a from 
  #temp_cPloyGoodsNO a,#temp_IncGoodsNO b
  where a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo
	insert into '+@MenPosName+'.dbo.t_PloyOfSale(
	[cPloyNo],[cGoodsNo],[cGoodsName],[fQuantity_Ploy],[fInPrice],[fPrice_SO],[dDateStart],[cTimeStart]
      ,[dDateEnd],[cTimeEnd],[iPriority],[bSO],[bPresent],[cPresentPloyNo],[cPloyTypeNo],[cPloyTypeName],[bEnabled]
      ,[Week1],[Week2],[Week3],[Week4],[Week5],[Week6],[Week7]
      ,[Hour0],[Hour1],[Hour2],[Hour3],[Hour4],[Hour5],[Hour6],[Hour7],[Hour8],[Hour9]
      ,[Hour10],[Hour11],[Hour12],[Hour13],[Hour14],[Hour15],[Hour16],[Hour17],[Hour18],[Hour19]
      ,[Hour20],[Hour21],[Hour22],[Hour23],[fSupRatio],[fVipValue],[bMult]
      ,[bLimitQty],[fLimitQty],[fRatio_JiOu],[bJiOu],[fQty_Ji],[fPrice_ji],[fQty_Ou],[fPrice_Ou]
      ,[bSuspend],[cSuspendMan],[dSuspend],[fPrice_SO_old],[cUpdateMan],[dUpdate]
	)
	SELECT a.[cPloyNo],a.[cGoodsNo],[cGoodsName],[fQuantity_Ploy],[fInPrice],[fPrice_SO],[dDateStart],[cTimeStart]
      ,[dDateEnd],[cTimeEnd],[iPriority],[bSO],[bPresent],[cPresentPloyNo],[cPloyTypeNo],[cPloyTypeName],[bEnabled]
      ,[Week1],[Week2],[Week3],[Week4],[Week5],[Week6],[Week7]
      ,[Hour0],[Hour1],[Hour2],[Hour3],[Hour4],[Hour5],[Hour6],[Hour7],[Hour8],[Hour9]
      ,[Hour10],[Hour11],[Hour12],[Hour13],[Hour14],[Hour15],[Hour16],[Hour17],[Hour18],[Hour19]
      ,[Hour20],[Hour21],[Hour22],[Hour23],[fSupRatio],[fVipValue],[bMult]
      ,[bLimitQty],[fLimitQty],[fRatio_JiOu],[bJiOu],[fQty_Ji],[fPrice_ji],[fQty_Ou],[fPrice_Ou]
      ,[bSuspend],[cSuspendMan],[dSuspend],[fPrice_SO_old],[cUpdateMan],[dUpdate]
      FROM [posmanagement].[dbo].[t_PloyOfSale] a,#temp_cPloyGoodsNO b
     where a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo
    
  ')
end
GO
