  

/*
   [p_RestcStoreOutSheet_test] '2017-03-21','1001','STYH20171001-000109','201703211001-001'
*/

CREATE proc [dbo].[p_RestcStoreOutSheet_test]
@dDate datetime,
@cStoreNo varchar(32),
@cSheetNo varchar(32),  --- 配送验货出库单号
@cOutSerNo varchar(32)  --- 配送出库批次号
as
begin 

	declare @cWhNo varchar(32)
	declare @cWh varchar(32)

	select top 1 @cWhNo=a.cWhNo,@cWh=a.cWh from t_WareHouse a,t_Store b
	where a.cStoreNo=b.cStoreNo
	and b.cParentNo='--'
	------------------备份。。 

	/*
	  判断当前批次中是否有后期追加的未分拣配送出库单：	  
	*/
    declare @cOunt int
    select @cOunt=COUNT(*) from wh_cStoreOutWarehouse
    --where dDate=dbo.getDayStr(GETDATE()) and cOutSerNo=@cOutSerNo 
    where dDate=@dDate and cOutSerNo=@cOutSerNo 
   and ISNULL(iliucheng,0)=0
 
    
 
    
     
    
	--delete a 
	--from wh_cStoreOutWarehouseDetail_Delete a,wh_cStoreOutWarehouse_Delete b
	--where dDate>GETDATE()-15 and a.cSheetNo=b.cSheetNo and b.cOutSerNo=@cOutSerNo
	
	declare @YYYY1 varchar(8)
	declare @MM1 varchar(8)
	declare @DD1 varchar(8)
	set @YYYY1=datename(YYYY,@dDate)
	set @MM1=datename(MM,@dDate)
	set @DD1=datename(DD,@dDate)
	
	if LEN(@MM1)=1 
	begin
	  set @MM1='0'+@MM1
	end
	if LEN(@DD1)=1 
	begin
	 set @DD1='0'+@DD1
	end
	
	declare @YMD varchar(32)
	set @YMD=@YYYY1+@MM1+@DD1+CAST(cast( floor(rand()*100) as int) as varchar)
	
    
 
	insert into wh_cStoreOutWarehouse_Delete(dDate, cSheetno, cCustomerNo, cCustomer, cOperatorNo, 
	cOperator, cFillEmpNo, cFillEmp, dFillin, cFillinTime, cStockDptno, cStockDpt, 
	fMoney, cManagerNo, cManager, bAgree, cExaminerNo, cExaminer, bExamin, cWhNo, cWh, 
	bPost, cTime, cReason, bBalance, jiesuanno, tag_daily, bLocked, bAccount, cBeizhu1,
	 cBeizhu2, cOperator_FinanceCheck, bReason_FinanceCheck, cReason_FinanceCheck, 
	 dDate_FinanceCheck, cOperatorNo_FinanceCheck, bDownLoad, bAccount_log, b_ftp, bReceive, 
	 cStoreNo, cStoreName, StoreInSheetNo, bfresh, bShip, bOutYH, fMoney_Old, cOutSerNo,isprint)
	select  dDate, cSheetno+'_'+@YMD, cCustomerNo, cCustomer, cOperatorNo, 
	cOperator, cFillEmpNo, cFillEmp, dFillin, cFillinTime, cStockDptno, cStockDpt, 
	fMoney, cManagerNo, cManager, bAgree, cExaminerNo, cExaminer, bExamin, cWhNo, cWh, 
	bPost, cTime, cReason, bBalance, jiesuanno, tag_daily, bLocked, bAccount, cBeizhu1,
	 cBeizhu2, cOperator_FinanceCheck, bReason_FinanceCheck, cReason_FinanceCheck, 
	 dDate_FinanceCheck, cOperatorNo_FinanceCheck, bDownLoad, bAccount_log, b_ftp, bReceive, 
	 cStoreNo, cStoreName, StoreInSheetNo, bfresh, bShip, bOutYH, fMoney_Old, cOutSerNo,isprint 
	 from wh_cStoreOutWarehouse 
	 where dDate>GETDATE()-15 and cOutSerNo='201703211001-001'
	  and ISNULL(bfresh,0)=0  
	 and ISNULL(iliucheng,0)=0
	  
	 
	  
	if (select object_id('tempdb..#temp_cStoreOutPrice'))is not null
    drop table #temp_cStoreOutPrice
    
    select  a.iLineNo, a.cGoodsNo,a.fInPrice into #temp_cStoreOutPrice
	from wh_cStoreOutWarehouseDetail a,wh_cStoreOutWarehouse b
	where dDate>GETDATE()-15 and a.cSheetNo=b.cSheetNo and b.cOutSerNo=@cOutSerNo
	and ISNULL(bfresh,0)=0 and  ISNULL(iliucheng,0)=0
    

	insert into dbo.wh_cStoreOutWarehouseDetail_Delete(
	 cSheetno, iLineNo, cGoodsNo, cGoodsName, cBarcode, cUnitedNo, fQuantity, fInPrice, 
	 fInMoney, fTaxrate, bTax, fTaxPrice, fTaxMoney, fNoTaxPrice, fNoTaxMoney, dProduct, fTimes, 
	 cProductSerno, bPost, bChecked, cCheckNo, dCheck, cUnit, cSpec, bBalance, jiesuanno, tag_daily, 
	 fPrice_SO, cDetail, fPacks, cSupNo, cSupName, fQuantity_Old, fPrice_Old, fInMoney_Old, fQty_Cur,cBeizhu
	)
	select  a.cSheetno+'_'+@YMD, a.iLineNo, a.cGoodsNo, a.cGoodsName, a.cBarcode, a.cUnitedNo, a.fQuantity, a.fInPrice, 
	 a.fInMoney, a.fTaxrate, a.bTax, a.fTaxPrice, fTaxMoney, fNoTaxPrice, fNoTaxMoney, dProduct, fTimes, 
	 cProductSerno, a.bPost, bChecked, cCheckNo, dCheck, cUnit, cSpec, a.bBalance, a.jiesuanno, a.tag_daily, 
	 fPrice_SO, cDetail, fPacks, cSupNo, cSupName, fQuantity_Old, fPrice_Old, fInMoney_Old, fQty_Cur,cBeizhu
	from wh_cStoreOutWarehouseDetail a,wh_cStoreOutWarehouse b
	where dDate>GETDATE()-15 and a.cSheetNo=b.cSheetNo and b.cOutSerNo=@cOutSerNo
	 and ISNULL(bfresh,0)=0  
	 and  ISNULL(iliucheng,0)=0
    
    /*统一处理发出成本价：防止生成了 分拣单之后  配送价有调整情况*/
    -------
    if (select object_id('tempdb..#temp_cStoreOutSheetNo'))is not null
     drop table #temp_cStoreOutSheetNo
     select cSheetno,dDate
     into #temp_cStoreOutSheetNo
	 from wh_cStoreOutWarehouse 
	 where dDate>GETDATE()-15 and cOutSerNo=@cOutSerNo
	 and ISNULL(bfresh,0)=0  
	 and  ISNULL(iliucheng,0)=0
    
    ----获取出库单里面对应的分拣单 wh_cStoreOutWarehouse_Sort_Out
    if (select object_id('tempdb..#temp_cStoreOutSheetNo_Sort'))is not null
    drop table #temp_cStoreOutSheetNo_Sort
    select a.dDate,a.cSheetNo 
    into #temp_cStoreOutSheetNo_Sort
    from wh_cStoreOutWarehouse_Sort_Out a,#temp_cStoreOutSheetNo b
    where a.dDate=b.dDate and a.cSheetNo_Out=b.cSheetno
    
    ---获取分拣单详情
    if (select object_id('tempdb..#temp_cStoreOutSheetNoDetail_Sort'))is not null
    drop table #temp_cStoreOutSheetNoDetail_Sort
    select a.cSheetno,a.cGoodsNo,fqty=SUM(fQuantity)
    into #temp_cStoreOutSheetNoDetail_Sort
    from wh_cStoreOutWarehouseDetail_Sort a,#temp_cStoreOutSheetNo_Sort b
    where a.cSheetno=b.cSheetNo
    group by a.cSheetno,a.cGoodsNo
    
    ---重新读取当前配送价
    if (select object_id('tempdb..#temp_cStoreOutSheetNoDetailGoods_Sort'))is not null
    drop table #temp_cStoreOutSheetNoDetailGoods_Sort
    
    select a.cGoodsNo,a.cSheetno,fInPrice=case when ISNULL(b.fPsprice,0)=0 
	then case when ISNULL(b.fCKPrice,0)=0 
	then case when ISNULL(b.fPrice_Contract,0)=0 
	then fNormalPrice else fPrice_Contract 
	end else b.fCKPrice end else b.fPsprice end,a.fqty
	into #temp_cStoreOutSheetNoDetailGoods_Sort
	from #temp_cStoreOutSheetNoDetail_Sort a,t_Goods b
	where cSheetno=@cSheetNo  and a.cGoodsNo=b.cGoodsNo
    
    ---重置分拣单配送价。。
    
    update a
    set a.fInPrice=b.fInPrice,a.fInMoney=a.fQuantity*b.fInPrice
    from wh_cStoreOutWarehouseDetail_Sort a,#temp_cStoreOutSheetNoDetailGoods_Sort b
    where a.cSheetno=b.cSheetno and a.cGoodsNo=b.cGoodsNo
    
    ---重置单据金额
    
    update a
    set a.fMoney=b.fInMoney
    from wh_cStoreOutWarehouse_Sort a,
    (select cSheetno,fInMoney=sum(fqty*fInPrice) from #temp_cStoreOutSheetNoDetailGoods_Sort group by cSheetno) b
    where a.cSheetno=b.cSheetno 
    
	---------------------移除同一出库批次出库单数据
	
	delete a 
	from wh_cStoreOutWarehouseDetail a,wh_cStoreOutWarehouse b
	where dDate>GETDATE()-15 and a.cSheetNo=b.cSheetNo 
	and b.cOutSerNo=@cOutSerNo and ISNULL(bfresh,0)=0  
	 and  ISNULL(iliucheng,0)=0
	 
	delete wh_cStoreOutWarehouse  where dDate>GETDATE()-15 and cOutSerNo=@cOutSerNo
	and ISNULL(bfresh,0)=0  
	 and  ISNULL(iliucheng,0)=0
	
	-------------------- 根据同一批次配送出库验货单  同步到配送出库单中
	 
	declare @cSheetNo_Out varchar(32)
	declare @cYear int
	set @cYear=YEAR(@dDate)
	set @cSheetNo_Out=(select dbo.[f_GencStoreOutsheetno](cast(@cYear as varchar),@cStoreNo))
	
	------回填老单号
	
	update a
	set a.cSheetno_Old=b.cSheetno
	from wh_cStoreOutWarehouse_Delete a,#temp_cStoreOutSheetNo b
	where a.cSheetno=b.cSheetno+'_'+@YMD
	
	
	--insert into wh_cStoreOutWarehouse(dDate,cSheetno,cCustomerNo,cCustomer,cOperatorNo,cOperator,
	--cFillEmpNo,cFillEmp,dFillin,cFillinTime,cStockDpt,
	--cStockDptno,fMoney,cExaminer,cExaminerNo,bExamin,cWhNo,cWh,bPost,cTime,cStoreNo,cStoreName,bOutYH,cOutSerNo,bShip,isPrint,bRestOut,iLiucheng)
	select dDate,@cSheetNo_Out,cCustomerNo,cCustomer,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,dFillin,cFillinTime,cStockDpt,
	cStockDptno,fMoney,cExaminer,cExaminerNo,bExamin,@cWhNo,@cWh,bPost,cTime,cStoreNo,cStoreName,1,cOutSerNo,1,1,1,1
	from wh_cStoreOutVerifySheet 
	where cSheetno=@cSheetNo and cOutSerNo=@cOutSerNo
	
	if (select object_id('tempdb..#temp_cStoreOutPriceVerify'))is not null
    drop table #temp_cStoreOutPriceVerify
   
	/*取配送价：配送价为空，取进价，进价为空，取合同价，合同价为空、取总部零售价*/
	
	select cSheetNo=@cSheetNo_Out,iLineNo,a.cGoodsNo,a.cGoodsName,a.cBarcode,b.cUnitedNo,
	fQuantity,fInPrice=case when ISNULL(b.fPsprice,0)=0 
	then case when ISNULL(b.fCKPrice,0)=0 
	then case when ISNULL(b.fPrice_Contract,0)=0 
	then fNormalPrice else fPrice_Contract 
	end else b.fCKPrice end else b.fPsprice end ,
	fInMoney,fTaxrate,bTax,fTaxPrice,
	fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,bChecked=1,cOutiLineNo,b.cUnit,b.cSpec,
	cBeizhu=CAST(null as varchar(80)),c.fPSRate
	into #temp_cStoreOutPriceVerify
	from wh_cStoreOutVerifySheetDetail a,t_Goods b,t_GoodsType c
	where cSheetno=@cSheetNo  and a.cGoodsNo=b.cGoodsNo
	and b.cGoodsTypeno=c.cGoodsTypeno
		
	/*
	update a set a.fInPrice=b.fInPrice 
	from #temp_cStoreOutPriceVerify a,#temp_cStoreOutPrice b
	where a.cGoodsNo=b.cGoodsNo and a.cOutiLineNo=b.iLineNo
	*/
    
 
	--根据大件系数：修改cBeizhu  显示几件零几个。
	
	   update a
	   set   cBeizhu=cast(cast(ROUND(a.fQuantity/ISNULL(b.fPackRatio,1), 0, 1) as int) as varchar)+'.'
	   +CAST(a.fQuantity-(ROUND(a.fQuantity/ISNULL(b.fPackRatio,1), 0, 1))*ISNULL(b.fPackRatio,1) as varchar)
	   from #temp_cStoreOutPriceVerify a,t_Goods b
	   where   a.cGoodsNo=b.cGoodsNo 
	   and ISNULL(a.fQuantity,0)>0 and ISNULL(b.fPackRatio,1)>1
	

	--insert into wh_cStoreOutWarehouseDetail(cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,
	--fQuantity,fInPrice,fInMoney,fTaxrate,bTax,fTaxPrice,
	--fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,bChecked,cUnit,cSpec, cBeizhu,fPsRatio)
	select @cSheetNo_Out,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,
	fQuantity,fInPrice,fInMoney=fQuantity*fInPrice,fTaxrate,bTax,fTaxPrice,
	fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,1,cUnit,cSpec,cBeizhu,fPSRate
	from #temp_cStoreOutPriceVerify
	where ISNULL(fQuantity,0)<>0
	

    
end
GO
