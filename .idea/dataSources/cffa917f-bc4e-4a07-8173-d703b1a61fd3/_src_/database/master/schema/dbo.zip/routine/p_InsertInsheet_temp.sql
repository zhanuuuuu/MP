




CREATE     procedure [dbo].[p_InsertInsheet_temp]
@TempTableName varchar(128)
as
begin
exec(
'
  declare @maxLineNo int
  set @maxLineNo=isnull(
                         (select max(iLineNo) from '+@TempTableName+'
                           where  iLineNo<>999999 
                         ) 
                      ,0)
  
  set @maxLineNo=@maxLineNo+1
  insert into '+@TempTableName+'
    (fTimes,cProductSerno,cGoodsNo,cGoodsName,cUnit,cSpec,cSheetno,iLineNo,fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,fNoTaxPrice,fNoTaxMoney)
  values
    (0,Null,Null,Null,'''','''','''',@maxLineNo,0,0,0,0,0,0,0,0)
')
end


GO
