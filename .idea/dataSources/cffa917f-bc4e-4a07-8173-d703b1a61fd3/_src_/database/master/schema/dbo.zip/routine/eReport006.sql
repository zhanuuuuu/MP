CREATE procedure [dbo].[eReport006]
@date1 datetime,
@date2 datetime,
@cWhNo varchar(32)
as
begin
/*
eReport006
@date1='2012-06-01',@date2='2012-06-30',@cWhNo='01'
*/
----获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @cWhNo varchar(32)
--select @date1='2011-05-01',@date2='2011-06-17',@cWhNo='01'

if(select object_id('tempdb..#tempLeaf')) is not null 	drop table 	#tempLeaf
select cGoodsTypeNo,cGoodsTypeName,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) into #tempLeaf
from t_GoodsType
where cGoodsTypeno in 
(
select * from #admin_tgoodstype
--select cGoodsTypeno from t_GoodsType
)
update #tempLeaf set cpath=cParentNo+'.'+cGoodsTypeNo

declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #tempLeaf a left join #tempLeaf b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
end
select cGoodsTypeNo,cGoodsTypename,cPath,iLevel
into #tempGoodsTypePath
from #tempLeaf 

/*以上形成类别列表*/
if (select object_id('tempdb..#TmpGoodsLevel'))is not null drop table #TmpGoodsLevel
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel
if (select object_id('tempdb..#GoodsType'))is not null drop table #GoodsType
select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
--where cPath=cPath_leaf

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null

update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null

declare @dDate_daily datetime  --日结日期
declare @dDate_account datetime  --日结日期

select @dDate_daily=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history
where isnull(cWhNo,'')=@cWhNo

select @dDate_account=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history 
where ISNULL(bAccount,0)=1 and isnull(cWhNo,'')=@cWhNo

if (select object_id('tempdb..#tmpPloyOfGoods_Money1'))is not null drop table #tmpPloyOfGoods_Money1
if (select object_id('tempdb..#tmpPloyOfGoods_Money0'))is not null drop table #tmpPloyOfGoods_Money0

-----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    
  if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fPrice money,fLastSettle money ,bAuditing bit,cWHno varchar(32))
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fNormalPrice money ,fLastSettle money ,bAuditing bit,bStorage bit,cWHno varchar(32))

  exec p_SaleDetail_Ref @date1,@date2,@cWhNo


select b.dSaleDate,cSupNo=null,a.cGoodsNo,b.iSeed,fLastSettle=isnull(b.fLastSettle,0)
into #tmpPloyOfGoods_Money1
from t_goods a left join 
--t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo 
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between @date1 and @date2 and b.dSaleDate>=@dDate_account+1 and b.dSaleDate<=@dDate_daily
union all  --未日结的商品从销售单中取
select b.dSaleDate,cSupNo=null,a.cGoodsNo,b.iSeed,fLastSettle=isnull(b.fLastSettle,0)
from t_goods a left join --- t_SaleSheetDetail b
#temp_salesheetDetail b
on  a.cGoodsNo=b.cGoodsNo
where b.dSaleDate between @date1 and @date2
union all --未记账顾客退货
select c.dDate,cSupNo=null,a.cGoodsNo,b.iLineNo,fLastSettle=-isnull(b.fInMoney,0)
from t_goods a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
where c.dDate between @date1 and @date2
union all --前台销售退货
select b.dDateTime,cSupNo=null,a.cGoodsNo,b.iLineNo,-c.fLastSettle
from t_goods a left join T_WH_Form b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=13 
left join -----t_SaleSheet_Day c
#temp_SaleSheet_Day c
on b.dDateTime=c.dSaleDate and b.iLineNo=c.iSeed and b.cGoodsNo=c.cGoodsNo
and b.cWhNo=c.cWHno
where b.dDateTime  between @date1 and @date2
and b.dDateTime<=@dDate_account
union all --未记账顾客退货
select c.dDate,null,a.cGoodsNo,b.iLineNo,fLastSettle=-isnull(b.fInMoney,0)
from t_goods a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
where c.dDate between @date1 and @date2 and isnull(c.baccount,0)=0

select dSaleDate,cSupNo=null,cGoodsNo,iSeed=0,fLastSettle=SUM(fLastSettle)
into #tmpPloyOfGoods_Money0
from #tmpPloyOfGoods_Money1
group by dSaleDate,cGoodsNo

if (select OBJECT_ID('tempdb..#TmpGoodsBaseInfo'))is not null drop table #TmpGoodsBaseInfo
select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypeName,fLastSettle=sum(a.fLastSettle)
into #TmpGoodsBaseInfo  --drop table #TmpGoodsBaseInfo
from #tmpPloyOfGoods_Money0 a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypeName

      declare @ilv int ,@ilv_m int
select @ilv=MIN(iLevel),@ilv_m=MAX(iLevel) from  #tempGoodsTypePath where cgoodstypeno in 
(--'81002','8100201','8100202','8100203','8100204','8100205','8100206','8100207','8100208'
select * from #admin_tgoodstype
--select cgoodstypeno  from t_GoodsType
)
--if (@ilv+1<=@ilv_m) begin set @ilv=@ilv+1 end
select distinct cGoodsTypeNo,cGoodsTypename from #tempGoodsTypePath where iLevel=@ilv
--select top(11) cGoodsTypeno from t_GoodsType 

	  if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null
	  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=@ilv
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select cGoodsTypeNo=b.BaseGoodsTypeNo,a.fLastSettle,a.dSaleDate
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo

if (select object_id('tempdb..#last'))is not null
	drop table #last 
select cGoodsTypeNo,fLastSettle=SUM(fLastSettle),dSaleDate 
into #last
from  #tmpGoods_byLevel
group by cGoodsTypeNo,dSaleDate 
order by cGoodsTypeNo,dSaleDate 

select a.cGoodsTypeNo,b.cGoodsTypename,a.fLastSettle,a.dSaleDate 
from #last a ,t_GoodsType b where a.cGoodsTypeNo=b.cGoodsTypeno
end
GO
