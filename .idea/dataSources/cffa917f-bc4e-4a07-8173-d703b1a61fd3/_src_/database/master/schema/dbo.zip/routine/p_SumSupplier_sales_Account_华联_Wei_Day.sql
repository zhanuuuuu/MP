/*
	if(select object_id('tempdb..#temp_Goods')) is not null
	begin
		drop table 	#temp_Goods
	end 	
	select cGoodsNo into #temp_Goods from t_Goods
	where csupno='1001' --and cGoodsNo in ('415531','415537')
 
declare @return int
exec p_SumSupplier_sales_Account_华联_wei_Day '1001','JS20151001-0001','2014-12-28','2015-01-31',@return
select @return

 
*/

CREATE  procedure [dbo].[p_SumSupplier_sales_Account_华联_Wei_Day]
@supNo varchar(64),
@jiesuanNo varchar(64),
@dDate1 datetime,
@dDate2 datetime,
@return int output
as
begin
declare @dDateBgn datetime
declare @dDateEnd datetime
set @dDateBgn=@dDate1
set @dDateEnd=@dDate2

declare @maxWhdDate datetime
  
  declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse --where cWhNo=@cWHno


if(select object_id('tempdb..#temp_WhFrombgn')) is not null drop table #temp_WhFrombgn

CREATE TABLE #temp_WhFrombgn   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money,差价数量 money, Pos客退数量1 money,
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,扣率金额 money,当日销售 money,特价扣率金额 money,
  fPrice_In money,fmoney_Cost money,fmoney_cost0 money,fmoney_cost1 money)

if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend

CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money,差价数量 money, Pos客退数量1 money,
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,扣率金额 money,当日销售 money,特价扣率金额 money,
  fPrice_In money,fmoney_Cost money,fmoney_cost0 money,fmoney_cost1 money)
  
 -- 	print '00 '+dbo.gettimestr(getdate())
 
insert into #temp_WhFrombgn  ([cGoodsNo],cSupplierNo) 
select cGoodsNo,@supNo from  #temp_Goods 

insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo) 
select cGoodsNo,@supNo from  #temp_Goods 
	
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateEnd)
set @Day1=day(@dDateEnd)
set @Y1=YEAR(@dDateEnd)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
 
	   
	
 exec('
    --------期初销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginQty
	from #temp_WhFrombgn a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and a.cGoodsNo=b.cGoodsNo   and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo   
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginSale					
	from #temp_WhFrombgn a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo  and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo 


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_beginQty
	from  #temp_Wh_Goods_beginQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_beginSale
	from  #temp_Wh_Goods_beginSale
	group by cgoodsno,cSupplierNo
	 
 
    update a 
	set a.销售数量0=b.fQty, 
	a.特价销售数量=b.fQtytj,
	a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
	from #temp_WhFrombgn a ,#temp_SumWh_Goods_beginQty b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFrombgn a ,#temp_SumWh_Goods_beginSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
    ----------期初成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_beginCost
	from #temp_WhFrombgn a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo  and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_beginCost
	from  #temp_Wh_Goods_beginCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney,
	a.fPrice_In=case when isnull(b.fQty,0)<>0 then b.fMoney/b.fQty else 0 end
	from #temp_WhFrombgn a ,#temp_Wh_Goods_beginCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
 
     update #temp_WhFrombgn set fmoney_cost1=特价销售金额*fPrice_In
    ,fmoney_cost0=isnull(fmoney_cost,0)-特价销售金额*fPrice_In
	
 ') 
	 
exec('
	--------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
	into #temp_Wh_Goods_endQty
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo  and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
	into #temp_Wh_Goods_endSale					
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo  and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo 


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
 
	 
	update a 
	set a.销售数量0=b.fQty, 
	a.特价销售数量=b.fQtytj,
	a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
    ----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
	into #temp_Wh_Goods_endCost
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo  and b.cSupNo='''+@supNo+''' and a.cSupplierNo=b.cSupNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney,
	a.fPrice_In=case when isnull(b.fQty,0)<>0 then b.fMoney/b.fQty else 0 end		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	
	update #temp_WhFromend set fmoney_cost1=特价销售金额*fPrice_In,fmoney_cost0=isnull(fmoney_cost,0)-特价销售金额*fPrice_In
 ')

 

 
 
	
	update a set a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
	a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
	a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
	a.fmoney_Cost=isnull(a.fmoney_Cost,0)-isnull(b.fmoney_Cost,0),
	a.fmoney_Cost1=isnull(a.fmoney_Cost1,0)-isnull(b.fmoney_Cost1,0),
	a.fmoney_Cost0=isnull(a.fmoney_Cost0,0)-isnull(b.fmoney_Cost0,0) 
	from #temp_WhFromend a,#temp_WhFrombgn b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	 
 
	
select	fMoney_Cost=sum(isnull(fMoney_Cost,0)),
fMoney_Profit_sum=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
xsMoney=sum(isnull(销售金额0,0)),fML=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),fMoney_0=sum(isnull(正价销售金额,0)),
fProfit=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
fProfit_0=sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0)),
fMoney_1=sum(isnull(特价销售金额,0)),fProfit_1=sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
fProfit_Ratio=case when sum(isnull(销售金额0,0))<>0 
then  (sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0))*100/sum(isnull(销售金额0,0))) else 0 end,
fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
fmoney_cost0=SUM(isnull(fmoney_cost0,0)),
fmoney_cost1=SUM(isnull(fmoney_cost1,0))
into #temp_WhFromend_Output
from #temp_WhFromend
	
--	print '02 '+dbo.gettimestr(getdate())

if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend

declare @iPeriodDays int

set @iPeriodDays=datediff(day,@dDate1,@dDate2)+1


select a.*
into #temp_SupplierRatio
from 
(
select cSupNo=a.guizuno,fMoney1=-99999999,fMoney2=0,fRatio=b.fRatio,b.iDays
from
(
select guizuno,fMoney1=min(fMoney1)
from dbo.t_Supplier_Contract_Ratio
group by guizuno
) a,t_Supplier_Contract_Ratio b
where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
union all
select cSupNo=guizuno,fMoney1=fMoney1*@iPeriodDays/iDays,
fMoney2=case when fMoney2=999999999 then fMoney2 else fMoney2*@iPeriodDays/iDays end,
fRatio,iDays
from dbo.t_Supplier_Contract_Ratio
) a
where a.cSupNo=@supNo


--	print '03 '+dbo.gettimestr(getdate())


if(select object_id('tempdb..#temp_SupplierSales')) is not null drop table #temp_SupplierSales

select cSupNo=@supNo,fMoney_sale=fMoney_0
into #temp_SupplierSales
from #temp_WhFromend_Output


if(select object_id('tempdb..#temp_SupplierSales_ratio')) is not null drop table #temp_SupplierSales_ratio

select a.cSupNo,a.fMoney1,a.fMoney2,a.fRatio,b.fMoney_sale,
fMoney_Exe=cast(0 as money),fMoney_Ref=cast(0 as money)
into #temp_SupplierSales_ratio
from #temp_SupplierRatio a,#temp_SupplierSales b
where a.cSupNo=b.cSupNo

update #temp_SupplierSales_ratio
set fMoney_Ref=fMoney2-fMoney1

update #temp_SupplierSales_ratio
set fMoney_Ref=fMoney_sale-fMoney1
where fMoney1<fMoney_sale and fMoney_sale<=fMoney2

update #temp_SupplierSales_ratio
set fMoney_Ref=0
where fMoney1<=-99999999

update #temp_SupplierSales_ratio
set fMoney_Ref=0
where fMoney1>fMoney_sale

update #temp_SupplierSales_ratio
set fMoney_Exe=fMoney_Ref
	
--print '04 '+dbo.gettimestr(getdate())

declare @正价扣款 money

set  @正价扣款=(select round(SUM(fMoney_Exe*fRatio/100),2)	from #temp_SupplierSales_ratio)	
/*	
fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
*/
update #temp_WhFromend_Output
set fProfit_Ratio_0=@正价扣款,fProfit_Ratio_koudian=@正价扣款+fProfit_Ratio_1
select 
fMoney_Cost,
fMoney_Profit_sum,
xsMoney,fML,fMoney_0,
fProfit,
fProfit_0,
fMoney_1,fProfit_1,
fProfit_Ratio,
fProfit_Ratio_0,
fProfit_Ratio_1,
fProfit_Ratio_koudian,
fmoney_cost0,
fmoney_cost1
from #temp_WhFromend_Output

--print '05 '+dbo.gettimestr(getdate())
   	
/*
	 select	fMoney_Cost=sum(isnull(销售金额0,0))-sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0))-sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
	 fMoney_Profit_sum=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
	xsMoney=sum(isnull(销售金额0,0)),fML=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),fMoney_0=sum(isnull(正价销售金额,0)),
    fProfit=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
	fProfit_0=sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0)),
	fMoney_1=sum(isnull(特价销售金额,0)),fProfit_1=sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
    fProfit_Ratio=case when sum(isnull(销售金额0,0))<>0 
	then  (sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0))*100/sum(isnull(销售金额0,0))) else 0 end,
    fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
    fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
    fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
    fmoney_cost0=SUM(isnull(fmoney_cost0,0)),
    fmoney_cost1=SUM(isnull(fmoney_cost1,0))
  into #temp_WhFromend_Output
	from #temp_WhFromend

*/	
	

    return 1


	
end


GO
