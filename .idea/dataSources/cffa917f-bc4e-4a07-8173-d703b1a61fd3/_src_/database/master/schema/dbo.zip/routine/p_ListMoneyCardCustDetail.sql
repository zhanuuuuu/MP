
CREATE  procedure p_ListMoneyCardCustDetail
@cCardNo varchar(32)
as
begin
		select CustPlace='超市',sheetno,detail,shishou,jstype,CardNo=substring(jstype,4,16),jstime,zdriqi,
					 orientmoney,leftmoney
		into #tempListMoneyCardCustDetail 
		from posManagement.dbo.jiesuan
		where jstype like '%储值卡%'
		union all
		select CustPlace='商场',sheetno,detail,shishou,jstype,CardNo=substring(jstype,4,16),jstime,zdriqi, 
					 orientmoney,leftmoney
		from supermarket.dbo.jiesuan
		where jstype like '%储值卡%'

    select a.CustPlace,a.sheetno,a.detail,a.shishou,a.jstype,a.CardNo,a.jstime,a.zdriqi, 
					 a.orientmoney,a.leftmoney,orientmoney_card=b.orientmoney,custmoney_b=b.orientmoney,
					 leftmoney_b=b.leftmoney
		from #tempListMoneyCardCustDetail a left join supermarket.dbo.Moneycard b
		on a.cardno=b.cardno
		where a.CardNo=@cCardNo
end

GO
