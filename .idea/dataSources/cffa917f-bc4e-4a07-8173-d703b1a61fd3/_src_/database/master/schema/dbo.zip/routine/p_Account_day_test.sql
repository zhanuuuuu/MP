/*
  p_Account_day '2012-04-01','2012-04-30'
*/
CREATE     procedure [dbo].[p_Account_day_test]
@cStoreNo varchar(32),
@date1 datetime,
@date2 datetime
as
begin
  /*生成报表的列*/

    if (select OBJECT_ID('tempdb..#temp_Jiesuan'))is not null drop table #temp_Jiesuan
    create table #temp_Jiesuan(zdriqi datetime,detail varchar(32),theyear varchar(32),themonth varchar(32),
	mianzhi money,zhaoling money,shishou money,
	shouyinyuanno varchar(32),shouyinyuanmc varchar(32),sheetno varchar(32),jiaozhang money,jstime datetime)

  
     
     insert into #temp_Jiesuan(zdriqi,theyear,themonth,detail,
	mianzhi,zhaoling,shishou,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime)
		select zdriqi,theyear=cast(year(zdriqi) as varchar(4)),themonth=cast(month(zdriqi) as varchar(2)),detail,
	sum(mianzhi),sum(zhaoling),sum(shishou),shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime
	from jiesuan
	where zdriqi between @date1 and  @date2
	 and ( cStoreNo=@cStoreNo)
		 
	group by  cast(year(zdriqi) as varchar(4)),cast(month(zdriqi) as varchar(2)),detail,
	zdriqi,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime
   

  
  select fMoney_Save=sum(isnull(fMoney_Save,0)),cOpertorNo,cOperName,dSaleDate
	into #temp_t_Vip_Save
	from t_Vip_Save
  where dSaleDate between @date1 and  @date2
   and  cStoreNo=@cStoreNo 
  group by cOpertorNo,cOperName,dSaleDate
  

  
  select detail,sum(shishou) shishou 
  into #jiesuan_detail0
	--from jiesuan
	from #temp_Jiesuan
  where  zdriqi between @date1 and  @date2
  group by detail  having sum(shishou)<>0
  union all
  select detail='服务台退货',shishou=-sum(fMoney)  
  from WH_ReturnGoods
  where  dDate between @date1 and  @date2
   and ( cStoreNo=@cStoreNo)

  select detail,shishou 
  into #jiesuan_detail
  from #jiesuan_detail0
	union all
  select detail='电子钱包',shishou=sum(isnull(fMoney_Save,0))
  from #temp_t_Vip_Save
--  where ISNULL(bZeng,0)=0

  --select * from #jiesuan_detail
 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     日期 varchar(32)
	)

  declare @cAddFields varchar(2000)
  set @cAddFields=''
  declare @strtmp varchar(2000)
  set @strtmp=''
  declare @strtmp_group varchar(2000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(2000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(sum(cast(合计 as money)) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

	select theDate=dbo.getDayStr(zdriqi),detail,
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,sum(shishou) shishou
    into #jiesuan
	--from jiesuan
	from #temp_Jiesuan
	where zdriqi between @date1 and  @date2
	  and ISNULL(dbo.trim(detail),'')<>''
	group by  zdriqi,detail  having sum(shishou)<>0
--	order by zdriqi
  union all
	select theDate=dbo.getDayStr(dSaleDate),detail='电子钱包',
	sum(fMoney_Save) mianzhi,zhaoling=0,sum(fMoney_Save) shishou
	from #temp_t_Vip_Save
	where dSaleDate between @date1 and  @date2
	group by  dSaleDate
  union all
	select theDate=dbo.getdaystr(dDate),detail='服务台退货',
	mianzhi=-sum(fMoney),zhaoling=0.00,shishou=-sum(fMoney) 
	from WH_ReturnGoods
	where dDate between @date1 and  @date2
	 and (  cStoreNo=@cStoreNo)
	group by  dDate
	 
  
  
  declare jiesuan_cursor cursor
  for
  select theDate,detail,shishou=cast(shishou as char(32))
  from #jiesuan
  order by theDate,detail
 
  select theDate,shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  group by theDate
  


  declare @theDate varchar(32)
 -- declare @themonth varchar(32)
 -- declare @detail varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @theDate,@detail,@shishou

  while @@fetch_status=0
  begin
		if (select 日期 from #account_detail 
				where 日期=@theDate) is null
    begin
      exec('insert into #account_detail select '''+@theDate+''','+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 日期='''+@theDate+'''')

    fetch next from jiesuan_cursor
    into @theDate,@detail,@shishou
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.日期=b.theDate


 
  exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 日期=''总计'','+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select * from #account_detail_last')

end


GO
