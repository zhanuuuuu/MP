 
 
 

/*
  if (select OBJECT_ID('tempdb..#temp_SupplierNo'))is not null drop table #temp_SupplierNo
 
 select cSupplierNo=cSupNo into #temp_SupplierNo
	from t_Supplier where cSupNo='0006'
	
 exec p_Supplier_InOut_Account
'2000-01-01',
'2016-2-24',
'01',
'001'

*/
CREATE procedure [dbo].[p_Supplier_InOut_Account]
@dDate1 datetime,
@dDate2 datetime,
@cWhNo varchar(32),
@cStoreNo varchar(32)
as
begin
/*
	select *
	from t_Supplier
	where cSupNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
*/
	declare @fInMoney money
	declare @fRbdMoney money
	declare @fDifMoney money
		
		 -----可结算金额，库存可销天数，年至今销售额，年销售毛利额，年销售毛利率100%-------
		 
	select a.cSupName,a.cSupNo,a.cHezuoFangshi,b.fInMoney,c.fRbdMoney,d.fDifMoney,e.fMoneyPayout,
	fInMoney_1=CAST(0 as money),fRbdMoney_1=CAST(0 as money),fDifMoney_1=CAST(0 as money),fMoneyPayout_1=CAST(0 as money),
	fInMoney_0=CAST(0 as money),fRbdMoney_0=CAST(0 as money),fDifMoney_0=CAST(0 as money),fMoneyPayout_0=CAST(0 as money),
	fLeft_Qty=CAST(0 as money), ---- 剩余库存数量
	fLeft_Money=CAST(0 as money), -- 剩余库存
	kejisuan=CAST(0 as money),-- 可结算金额
	keDay=CAST(0 as money),--库存可销天数
	XsQty=CAST(0 as money), -- 年销售数量
	XsMoney=CAST(0 as money), --年至今销售额
	XsMLe=CAST(0 as money),-- 年销售毛利额
	fml=CAST(0 as money) --年销售毛利率100%
	
	into #temp_Supplier_InOut_Account0
	from t_Supplier a 
		left join
		(	select cSupplierNo,fInMoney=SUM(fMoney) from wh_InWarehouse 
		where dDate between @dDate1 and @dDate2 and 
		cOpercStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo) and isnull(bExamin,0)=1 and ISNULL(bAccount,0)=1
		group by cSupplierNo) b on a.cSupNo=b.cSupplierNo
		left join
		(	select cSupplierNo,fRbdMoney=SUM(-fMoney) from wh_RbdWarehouse 
		where dDate between @dDate1 and @dDate2 and
		cStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo) and isnull(bExamin,0)=1 and ISNULL(bAccount,0)=1
		group by cSupplierNo) c  on a.cSupNo=c.cSupplierNo
		left join
		(	select cSupplierNo,fDifMoney=SUM(-fMoney_diff) from wh_DiffPriceWarehouse 
		where dDate between @dDate1 and @dDate2 and
		cStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo) and isnull(bExamin,0)=1 ---and ISNULL(bAccount,0)=1
		group by cSupplierNo) d on a.cSupNo=d.cSupplierNo
		left join 
		(	select cSupplierNo,fMoneyPayout=SUM(-feiyongjine) from t_Supplier_Payout
		where riqi2 between @dDate1 and @dDate2 and
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		group by cSupplierNo) e on a.cSupNo=e.cSupplierNo
  where a.cSupNo in (select cSupplierNo from #temp_SupplierNo)
 
 --------------以上获取时间段内入库、返厂、差价、费用----------------
 
	select a.cSupName,a.cSupNo,a.cHezuoFangshi,b.fInMoney,c.fRbdMoney,d.fDifMoney,e.fMoneyPayout
	into #temp_Supplier_InOut_Account1
	from t_Supplier a 
		left join
		(	select cSupplierNo,fInMoney=SUM(fMoney) from wh_InWarehouse 
		where dDate between @dDate1 and @dDate2 and
		cOpercStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		and ISNULL(bBalance,0)=1 and dbo.trim(ISNULL(jiesuanno,''))<>''
		group by cSupplierNo) b on a.cSupNo=b.cSupplierNo
		left join
		(	select cSupplierNo,fRbdMoney=SUM(-fMoney) from wh_RbdWarehouse 
		where dDate between @dDate1 and @dDate2 and
		cStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		and ISNULL(bBalance,0)=1 and dbo.trim(ISNULL(jiesuanno,''))<>''
		group by cSupplierNo) c  on a.cSupNo=c.cSupplierNo
		left join
		(	select cSupplierNo,fDifMoney=SUM(-fMoney_diff) from wh_DiffPriceWarehouse
		where dDate between @dDate1 and @dDate2 and
		cStoreNo=@cStoreNo and 
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		and ISNULL(bBalance,0)=1 and dbo.trim(ISNULL(jiesuanno,''))<>''
		group by cSupplierNo) d on a.cSupNo=d.cSupplierNo
		left join 
		(	select cSupplierNo,fMoneyPayout=SUM(-feiyongjine) from t_Supplier_Payout
		where riqi2 between @dDate1 and @dDate2 and
		cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		and ISNULL(jiesuanover,0)=1 and dbo.trim(ISNULL(jiesuanno,''))<>''
		group by cSupplierNo) e on a.cSupNo=e.cSupplierNo
	where a.cSupNo in (select cSupplierNo from #temp_SupplierNo)
 
 ------------ 以上获取结算过的单子金额
  update a set 
  fInMoney_1=isnull(b.fInMoney,0),fRbdMoney_1=isnull(b.fRbdMoney,0),
  fDifMoney_1=isnull(b.fDifMoney,0),
  fMoneyPayout_1=isnull(b.fMoneyPayout,0),
	fInMoney_0=isnull(a.fInMoney,0)-isnull(b.fInMoney,0),
	fRbdMoney_0=isnull(a.fRbdMoney,0)-isnull(b.fRbdMoney,0),
	fDifMoney_0=isnull(a.fDifMoney,0)-isnull(b.fDifMoney,0), 
  fMoneyPayout_0=isnull(a.fMoneyPayout,0)-isnull(b.fMoneyPayout,0)--isnull(b.fMoneyPayout,0),
  from  #temp_Supplier_InOut_Account0 a,#temp_Supplier_InOut_Account1 b
  where a.cSupNo=b.cSupNo
  
  ------------------- 取t_Wh_form  的剩余库存  和金额
  declare @Pos_Wh_Form varchar(32)
  select @Pos_Wh_Form=Pos_WH_Form from t_WareHouse
  
  if (select OBJECT_ID('tempdb..#temp_Wh_Form'))is not null drop table #temp_Wh_Form
  create table #temp_Wh_Form(fLeft_Qty money,fLeft_Money money,cSupplierNo varchar(32))
 
  if (select OBJECT_ID('tempdb..#temp_Wh_FormMaxDate'))is not null drop table #temp_Wh_FormMaxDate
  create table #temp_Wh_FormMaxDate(dDate datetime)
 
 exec('
    insert into #temp_Wh_FormMaxDate(dDate)
    select max(业务日期) from '+@Pos_Wh_Form+'.dbo.T_WH_Form_log_1 
    where cStoreNo='''+@cStoreNo+''' 
 ')
 
 declare @MaxDAte datetime
 select @MaxDAte=isnull(max(dDate),'2000-01-01') from #temp_Wh_FormMaxDate

declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@MaxDAte)
set @Day1=day(@MaxDAte)
set @Y1=YEAR(@MaxDAte)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
 
declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
exec('
 	 if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select fQty1=sum(fQty_'+@MMDAY1+'),fMoney1=sum(fMoney_'+@MMDAY1+'),cSupNo 		
		into #temp_Wh_Goods_end
		from '+@Pos_Wh_Form+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+'  
		with (nolock) 
		where cYear='''+@Y1+'''
		and cStoreNo='''+@cStoreNo+''' 
		and  cSupNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
		group by cSupNo
		
		insert into #temp_Wh_Form(fLeft_Qty,fLeft_Money,cSupplierNo)
		select fQty1,fMoney1,cSupNo from #temp_Wh_Goods_end
  ')
  
 
  /*
  select fLeft_Qty=SUM(fQty_Left),fLeft_Money=SUM(fMoney_Left),cSupplierNo into #temp_Wh_Form from T_WH_Form
  where cSupplierNo in (select cSupNo=cSupplierNo from #temp_SupplierNo)
  group by cSupplierNo
  */
  update a set 
  fLeft_Qty=isnull(b.fLeft_Qty,0),
  fLeft_Money=isnull(b.fLeft_Money,0)  
  from  #temp_Supplier_InOut_Account0 a,#temp_Wh_Form b
  where a.cSupNo=b.cSupplierNo
  ----------------
   /*------2015-05-30 修改获取期末日期30天之前的销售情况 得出可销天数------*/
  -----可结算金额，库存可销天数，年至今销售额，年销售毛利额，年销售毛利率100%-------

   if (select object_id('tempdb..#temp_cSupXsMonthCost'))is not null
drop table #temp_cSupXsMonthCost
create table  #temp_cSupXsMonthCost(cSupNo varchar(32),
	csupplier varchar(64),cWHno varchar(32),[fQty_Sale] [money] NULL,
	[fMoney_Sale] [money] NULL,[fQty_In] [money] NULL,[fMoney_In] [money] NULL,[fQty_TfrIn] [money] NULL,[fMoney_TfrIn] [money] NULL,
	[fQty_Return] [money] NULL,[fMoney_Return] [money] NULL,[fQty_Effusion] [money] NULL,[fMoney_Effusion] [money] NULL,[fQty_Exchange] [money] NULL,
	[fMoney_Exchange] [money] NULL,[fQty_Divide] [money] NULL,[fMoney_Divide] [money] NULL,[fQty_Pack] [money] NULL,[fMoney_Pack] [money] NULL,
	[fQty_trf] [money] NULL,[fMoney_trf] [money] NULL,[fQty_Rbd] [money] NULL,[fMoney_Rbd] [money] NULL,[fQty_Loss] [money] NULL,
	[fMoney_Loss] [money] NULL,[fQty_out] [money] NULL,[fMoney_out] [money] NULL,[fQty_Diff] [money] NULL,[fMoney_Diff] [money] NULL,
	fmoney_cost money
)

-------- 判断结束日期是否在已经月结的月末.. 
-- set @dDate2=DATEADD(DAY,-1,DATEADD(Month,1,@dDate1))
--CAST((@yyyy+'-'+@MM+'-01') AS DATETIME)
 
declare @d1 datetime
declare @d2 datetime
set @d1=@dDate1
set @d2=@dDate2
 
declare  @CountDay int
-------- 天数。。 
set @CountDay=DATEDIFF(DAY,@dDate1,@dDate2)
if @CountDay=0
begin
  set @CountDay=1
end
if @CountDay>=30 
begin
   --set @CountDay=30
   set @d1=@d2-30
   
   set @CountDay=DATEDIFF(DAY,@d1,@d2)
   
end

 if (select object_id('tempdb..#temp_Super'))is not null
   drop table #temp_Super
select cSupNo=cSupplierNo   into #temp_Super from #temp_SupplierNo
-------------------从快照表取数据
 
--exec P_x_SetCheckWh_bySupplier_InOut_Account_log @dDate1,@dDate2,@cWhNo

exec P_x_SetCheckWh_bySupplier_InOut_Account_log @d1,@d2,@cWhNo

   if (select object_id('tempdb..#temp_cSupXsMonth'))is not null
   drop table #temp_cSupXsMonth	
   select cSupNo,cWHno,fQty_Xs=SUM(fQty_Sale),fMoney_Xs=SUM(fMoney_Sale),
   fQty_In=SUM([fQty_In]),fMoney_In=SUM([fMoney_In]),
   fmoney_cost=SUM(fmoney_cost)
   into #temp_cSupXsMonth
   from #temp_cSupXsMonthCost
   group by cSupNo,cWHno
 
  update a set 
  kejisuan=isnull(a.fInMoney_0+a.fRbdMoney_0+a.fDifMoney_0+a.fMoneyPayout_0,0)-isnull(a.fLeft_Money,0), -- 可结算金额
  keDay=case when isnull(b.fMoney_Xs,0)<>0 then round((isnull(a.fLeft_Money,0)*@CountDay)/b.fMoney_Xs,1) else 1 end,  --库存可销天数
  XsQty=isnull(b.fQty_Xs,0),
  XsMoney=isnull(b.fMoney_Xs,0), 
  XsMLe=isnull(b.fMoney_Xs,0)-isnull(b.fmoney_cost,0),
  fml=case when isnull(b.fMoney_Xs,0)<>0 then ((isnull(b.fMoney_Xs,0)-isnull(b.fmoney_cost,0))/b.fMoney_Xs)*100 else 0 end
  from  #temp_Supplier_InOut_Account0 a,#temp_cSupXsMonth b
  where a.cSupNo=b.cSupNo
 
-- select * from #temp_cSupXsMonth

  select cSupName,cSupNo,cHezuoFangshi,fInMoney,fRbdMoney,fDifMoney,fMoneyPayout,
  fMoney_left=ISNULL(fInMoney,0)+ISNULL(fRbdMoney,0)+ISNULL(fDifMoney,0)+ISNULL(fMoneyPayout,0),
  fInMoney_1,fRbdMoney_1,fDifMoney_1,fMoneyPayout_1,
	fInMoney_0,fRbdMoney_0,fDifMoney_0,fMoneyPayout_0,
	fMeoney_left_waiting=fInMoney_0+fRbdMoney_0+fDifMoney_0+fMoneyPayout_0,
	fLeft_Qty,fLeft_Money,kejisuan,keDay,XsQty,XsMoney,XsMLe,fml
  from #temp_Supplier_InOut_Account0
	union all
  select cSupName=null,cSupNo='合计:',cHezuoFangshi=null,
  fInMoney=SUM(ISNULL(fInMoney,0)),fRbdMoney=SUM(ISNULL(fRbdMoney,0)),
  fDifMoney=SUM(ISNULL(fDifMoney,0)),fMoneyPayout=SUM(ISNULL(fMoneyPayout,0)),
  fMoney_left=sum(ISNULL(fInMoney,0)+ISNULL(fRbdMoney,0)+ISNULL(fDifMoney,0)+ISNULL(fMoneyPayout,0)),
  fInMoney_1=SUM(ISNULL(fInMoney_1,0)),fRbdMoney_1=SUM(ISNULL(fRbdMoney_1,0)),
  fDifMoney_1=SUM(ISNULL(fDifMoney_1,0)),fMoneyPayout_1=SUM(ISNULL(fMoneyPayout_1,0)),
	fInMoney_0=SUM(ISNULL(fInMoney_0,0)),fRbdMoney_0=SUM(ISNULL(fRbdMoney_0,0)),
	fDifMoney_0=SUM(ISNULL(fDifMoney_0,0)),fMoneyPayout_0=SUM(ISNULL(fMoneyPayout_0,0)),
	fMeoney_left_waiting=sum(fInMoney_0+fRbdMoney_0+fDifMoney_0+fMoneyPayout_0),
	fLeft_Qty=SUM(ISNULL(fLeft_Qty,0)),fLeft_Money=SUM(ISNULL(fLeft_Money,0)),
	kejisuan=SUM(ISNULL(kejisuan,0)),keDay=SUM(ISNULL(keDay,0)),XsQty=SUM(ISNULL(XsQty,0)),
	XsMoney=SUM(ISNULL(XsMoney,0)),XsMLe=SUM(ISNULL(XsMLe,0)),fml=SUM(ISNULL(fml,0))
  from #temp_Supplier_InOut_Account0
  
end
GO
