/*
       create table U_key.dbo.temp_GoodsKuWei(cStoreNo varchar(32),cStoreName varchar(64),cGoodsNo varchar(32),
     cGoodsName varchar(64),cBarcode varchar(32),
       cUnit varchar(32),cSpec varchar(32),fPreservationDown money,
	   fPreservationUp money,fPreservation_soft  money,
	   cGoodsTypeno varchar(32),cGoodsTypename varchar(64),fQty_Avg money,
	   cSupNo varchar(32),cSupName varchar(64),fUp money,fDown money,fPaimian money)
	   
  p_SavecStoreGoodsKuWei '1001','','',''
*/
CREATE proc p_SavecStoreGoodsKuWei
@cStoreNo varchar(32),
@cTermID varchar(32),
@cOpertionNo varchar(32),
@cOpertionName varchar(32)
as
begin
         declare @dDate datetime
         set @dDate=GETDATE()
         
        if (select OBJECT_ID('tempdb..#temp_cGoodsKuWei'))is not null  drop table #temp_cGoodsKuWei
        create table #temp_cGoodsKuWei(cStoreNo varchar(32),cGoodsNo varchar(32),fPreservationDown money,
        fPreservationUp money,fPreservation_soft  money,
            fQty_Avg money,fUp money,fDown money,fPaimian money,cSupNo varchar(32),AnQuan_Xs money,Songhuo_Tianshu money)
        exec('
         insert into #temp_cGoodsKuWei
         (
           cStoreNo,cGoodsNo,fPreservationDown,fPreservationUp,fPreservation_soft,
            fQty_Avg,fUp,fDown,fPaimian,AnQuan_Xs,Songhuo_Tianshu
         )
		    select cStoreNo,cGoodsNo,fPreservationDown,fPreservationUp,fPreservation_soft,
            fQty_Avg,fUp,fDown,fPaimian,AnQuan_Xs,Songhuo_Tianshu
		    from U_key.dbo.temp_GoodsKuWei'+@cTermID+'
       ')
        ----修改库位
        update a
        set a.fPreservationDown=b.fPreservationDown,
        a.fPreservationUp=b.fPreservationUp,
        a.fPreservation_soft=b.fPreservation_soft,
        a.fQty_Avg=b.fQty_Avg,
        a.fPuPjy=b.fUp,
        a.fPDownjy=b.fDown,
        a.fPreserPaimian=b.fPaimian,
        a.dUpdate=@dDate,
        a.fPreservationDown_Old=a.fPreservationDown,
        a.fPreservationUp_Old=a.fPreservationUp,
        a.fPreservation_soft_Old=a.fPreservation_soft,
        a.AnQuan_Xs=b.AnQuan_Xs,
        a.Songhuo_Tianshu=b.Songhuo_Tianshu
        from t_cStoreGoodsKuwei a,#temp_cGoodsKuWei b
        where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo
        
 
 
        ---添加库位
        insert into t_cStoreGoodsKuwei
        ( cStoreNo,cGoodsNo,fPreservationDown,fPreservationUp,fPreservation_soft,
            fQty_Avg,fPuPjy,fPDownjy,fPreserPaimian,dUpdate,AnQuan_Xs,Songhuo_Tianshu)
        select cStoreNo,cGoodsNo,fPreservationDown,fPreservationUp,fPreservation_soft,
            fQty_Avg,fUp,fDown,fPaimian,@dDate,AnQuan_Xs,Songhuo_Tianshu 
            from #temp_cGoodsKuWei where cGoodsNo not in (
          select cGoodsNo from t_cStoreGoodsKuwei where cStoreNo=@cStoreNo
        )
        
        
        --- 修改主表t_Goods
        
        declare @cStoreNoPa varchar(32)
        set @cStoreNoPa=(select cStoreNo from t_Store where cParentNo='--')
        
        if @cStoreNoPa=@cStoreNo
        begin
        
				update a
				set a.fPreservationDown=b.fPreservationDown,
				a.fPreservationUp=b.fPreservationUp,
				a.fPreservation_soft=b.fPreservation_soft          
				from t_cStoreGoods a,#temp_cGoodsKuWei b
				where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo 
				
				update a
				set a.fPreservationDown=b.fPreservationDown,
				a.fPreservationUp=b.fPreservationUp,
				a.fPreservation_soft=b.fPreservation_soft          
				from t_Goods a,#temp_cGoodsKuWei b
				where a.cGoodsNo=b.cGoodsNo 
				
        end else
        begin
                update a
				set a.fPreservationDown=b.fPreservationDown,
				a.fPreservationUp=b.fPreservationUp,
				a.fPreservation_soft=b.fPreservation_soft          
				from t_cStoreGoods a,#temp_cGoodsKuWei b
				where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo 
        end
        
        
        
        -------判断库位临时表中 在门店商品表中不存在的
        if (select OBJECT_ID('tempdb..#temp_cGoodsKuWeiNullStore'))is not null  drop table #temp_cGoodsKuWeiNullStore
        select b.cGoodsNo,b.cSupNo,b.cStoreNo,a.fPreservationUp,a.fPreservationDown,a.fPreservation_soft
        into #temp_cGoodsKuWeiNullStore
        from #temp_cGoodsKuWei b left join t_cStoreGoods a
        on a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo 
        where ISNULL(a.cGoodsNo,'')=''
        
        --------判断库位临时表供应商信息门店是否存在
        if (select OBJECT_ID('tempdb..#temp_cGoodsKuWeiNullStoreSup'))is not null  drop table #temp_cGoodsKuWeiNullStoreSup
        
        select distinct a.cGoodsNo,a.cStoreNo,a.cSupNo 
        into #temp_cGoodsKuWeiNullStoreSup
        from #temp_cGoodsKuWeiNullStore a left join t_SupplierStore  b
        on a.cStoreNo=b.cStoreNo and a.cSupNo=b.cSupNoMain
        where ISNULL(b.cSupNo,'')=''
        
        
		---插入门店供应商表    
		insert into t_SupplierStore(cSupNo, cSupName, cSupAbbName, cContractNo, cTrade, cAddress, cPostCode, cRegCode, 
		cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson, cBP, cMobile, cPPerson, iDisRate, 
		iCreGrade, iCreLine, iCreDate, cPayCond, cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, iAPMoney, 
		dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, cRegNo, cPassword, 
		cHezuoFangshi, cHelpCode, SecDogNo, bContractPrice, bLastPrice, bRatio_without_Rbd, bCaredEndDate, 
		bInPricePlan, iPre_Days, iOver_Days, b_NoStorage, bChange, bChangedDate, bFresh, cStoreNo, cStoreName, 
		cSupNoMain, bUpDatePrice)
		select a.cSupNo+(CAST(b.iLineNo as varchar)),a.cSupName, 
		a.cSupAbbName, a.cContractNo, a.cTrade, a.cAddress, a.cPostCode, a.cRegCode, 
		a.cBank, a.cAccount, a.dDevDate, a.cLPerson, a.cPhone, a.cFax, a.cEmail, a.cSupPerson, a.cBP, a.cMobile, a.cPPerson, a.iDisRate, 
		a.iCreGrade, a.iCreLine, a.iCreDate, a.cPayCond, a.cSupIAddress, a.cSupIType, a.cSupHeadCode, a.cSupDepart, a.iAPMoney, 
		dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, a.cRegNo, cPassword, 
		a.cHezuoFangshi, a.cHelpCode, a.SecDogNo, a.bContractPrice, a.bLastPrice, a.bRatio_without_Rbd, a.bCaredEndDate, 
		a.bInPricePlan, a.iPre_Days, a.iOver_Days, a.b_NoStorage, a.bChange, a.bChangedDate, a.bFresh, c.cStoreNo, b.cStoreName, 
		a.cSupNo,0 
		from #temp_cGoodsKuWeiNullStoreSup c,t_Store b,t_Supplier a
		where c.cStoreNo=b.cStoreNo and a.cSupNo=c.cSupNo 
       ---插入合同表
	   insert into t_Supplier_Contract(
		   cSupNo, cSupName, cSupAbbName, cTrade, cAddress, cPostCode,
		   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
			cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
			 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
		   cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate
		)
		select a.cSupNo+(CAST(b.iLineNo as varchar)),a.cSupName, 
		a.cSupAbbName,  cTrade, cAddress, cPostCode,
		   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
			cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
			 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
		   a.cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate
		from #temp_cGoodsKuWeiNullStoreSup c,t_Store b,t_Supplier a
		where c.cStoreNo=b.cStoreNo and a.cSupNo=c.cSupNo 
		
		
		insert into t_cStoreGoods(
		cGoodsNo, cStoreNo, cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fVipPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, fPreservationUp, fPreservationDown, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		fVipScore, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		cSupNo, cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, dUpdate, dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		)
		select a.cGoodsNo, c.cStoreNo,c.cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fNormalPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, b.fPreservationUp, b.fPreservationDown, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		a.fNormalPrice, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		a.cSupNo+(CAST(c.iLineNo as varchar)), cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, a.cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, b.fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, dUpdate, dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, a.bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, a.bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		from t_Goods a,#temp_cGoodsKuWeiNullStore b,t_Store c
		where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=b.cStoreNo

		delete a
		from t_ChangeGoods a,#temp_cGoodsKuWeiNullStore b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo

		insert into t_ChangeGoods(cGoodsNo,cStoreNo)
		select a.cGoodsNo,b.cStoreNo
		from t_Goods a,#temp_cGoodsKuWeiNullStore b
		where a.cGoodsNo=b.cGoodsNo
      
        ---插入日志
         
		 ---写入日志
		 declare @opertion varchar(256)
        set @opertion=dbo.getDayStr(@dDate)+'调整店铺编号:'+@cStoreNo+' 库位信息'
 
		exec p_Log cOpertionNo,@cOpertionName,@opertion,'调整'
		
       
end

GO
