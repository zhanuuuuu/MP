--select * from wh_cStoreOutWarehouse_Sort
--select * from wh_cStoreOutWarehouse
 
CREATE proc p_GetNotSortOutGoods
@dDate datetime,
@cOutSerno varchar(32),
@cSheetNo_Sort varchar(32)
as
begin
	--select a.cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,fTaxrate,bTax,fTaxPrice,
	--fTaxMoney,fNoTaxPrice,dProduct,cProductSerno,a.bPost,bChecked,a.cUnit,a.cSpec,a.jiesuanno,fPrice_SO
	-- from wh_cStoreOutWarehouseDetail_Sort a,wh_cStoreOutWarehouse_Sort b
	--where a.csheetNo=b.cSheetNo and b.cOutSerNo='20161123000-001'
	
	declare @maxIline int
 
	select @maxIline=MAX(iLineNo)
	from wh_cStoreOutWarehouseDetail_Sort
	where cSheetno=@cSheetNo_Sort
	
    if (select object_id('tempdb..#tmp_cStoreNotSortGoodsPc'))is not null drop table #tmp_cStoreNotSortGoodsPc
	select  iSeed=IDENTITY(int,1,1),a.cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,
	cUnitedNo,fQuantity,fInPrice,fInMoney,fTaxrate,bTax,fTaxPrice,
	fTaxMoney,fNoTaxPrice,dProduct,cProductSerno,a.bPost,bChecked,cUnit,cSpec,a.jiesuanno,fPrice_SO 
	into #tmp_cStoreNotSortGoodsPc
	from wh_cStoreOutWarehouseDetail a,wh_cStoreOutWarehouse b
	where b.dDate=@dDate and a.cSheetno=b.cSheetno  and ISNULL(bChecked,0)=0  
	and ISNULL(b.bfresh,0)=0
	and b.cOutSerNo=@cOutSerno
	
	update a set bChecked=1,bPost=1 
	from wh_cStoreOutWarehouseDetail a,wh_cStoreOutWarehouse b
	where b.dDate=@dDate and a.cSheetno=b.cSheetno and ISNULL(bChecked,0)=0  
	and ISNULL(b.bfresh,0)=0
	and b.cOutSerNo=@cOutSerno
	
 
	insert into wh_cStoreOutWarehouseDetail_Sort(cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,
	fQuantity,fInPrice,fInMoney,fTaxrate,bTax,fTaxPrice,
	fTaxMoney,fNoTaxPrice,dProduct,cProductSerno,bPost,bChecked,cUnit,cSpec,jiesuanno,fPrice_SO,cOutiLineNo)
	select @cSheetNo_Sort,iSeed+@maxIline,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,
	0,fInPrice,0,fTaxrate=0,bTax=0,fTaxPrice,0,fNoTaxPrice,dProduct,cProductSerno,bPost,
	bChecked,cUnit,cSpec,cSheetno,fQuantity,iLineNo from
	#tmp_cStoreNotSortGoodsPc
	
	
end
GO
