
create view v_Fee
as

	select cFeeNo,cFee,fFeePrice,iFeeStyle,cFeeStyle,cType,cTypeNo
	from dbo.t_Fee_Convey --搬运费
    union all
	select cFeeNo,cFee,fFeePrice,iFeeStyle,cFeeStyle,cType,cTypeNo
	from t_Fee_Dining --用餐费
    union all
	select cFeeNo,cFee,fFeePrice,iFeeStyle,cFeeStyle,cType,cTypeNo
	from t_Fee_truck  --运输费

GO
