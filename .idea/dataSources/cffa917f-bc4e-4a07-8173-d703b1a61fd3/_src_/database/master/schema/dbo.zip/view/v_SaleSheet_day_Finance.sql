
CREATE view v_SaleSheet_day_Finance
as
select b.cYear,b.cYearEnd,b.cMonth,b.iHolidays,b.fRight,b.iDays,
a.dSaleDate,a.iSeed,a.cGoodsNo,a.bAuditing,a.fVipScore,a.fQuantity,a.fLastSettle,
a.fCostPrice,a.cSaleTime,a.cCooperate
from dbo.t_SaleSheet_Day a,dbo.t_MonthsOfYearSerno b
where a.dSaleDate between b.dDate1 and b.dDate2

/*
select * from v_SaleSheet_day_Finance

select * from t_MonthsOfYearSerno
*/

GO
