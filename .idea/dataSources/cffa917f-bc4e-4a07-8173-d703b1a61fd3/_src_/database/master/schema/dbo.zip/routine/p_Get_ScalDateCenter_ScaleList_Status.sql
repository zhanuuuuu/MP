/*

p_Get_ScalDateCenter_ScaleList_Status '00','1001',0

*/
CREATE procedure p_Get_ScalDateCenter_ScaleList_Status
@cStoreNo varchar(32),
@cComputerNo varchar(32),
@iStatus smallint  
/*@iStatus=1 正在称重；@iStatus=2 称重完毕；@iStatus=0 空闲；@iStatus=-1 维修中  */
/*iStatus_Qty=1 毛重；iStatus_Qty=2 皮重；iStatus_Qty=0 净重  */
as
begin
  select a.cStoreNo, a.cScaleNo, a.cPort, a.cComputerName, a.cComputerNo,
  b.cSheetno, b.iLineNo, b.cGoodsNo, b.cGoodsName, 
  iStatus=isnull(a.iStatus,0),iStatus_Mass=isnull(a.iStatus_Mass,0), 
  iStatus_Tare=isnull(a.iStatus_Tare,0),iStatus_Net=isnull(a.iStatus_Net,0),
  b.cUnit,b.fQty_Net,b.fQty_Mass,b.fQty_Tare,
   b.dDatetime_Ready, b.dDatetime_Scale, 
  b.cPort, b.cStoreName, b.cComputerName,
  b.cComputerNo,iStatus_Qty=isnull(a.iStatus_Qty,1)
  from 
  dbo.t_ScaleDataCenter_ScaleList a left join dbo.t_ScaleDataCenter b
       on a.cStoreNo=b.cStoreNo and a.cScaleNo=b.cScaleNo
  where a.cStoreNo=@cStoreNo and a.cComputerNo=@cComputerNo and 
  (isnull(a.iStatus,0)=@iStatus or @iStatus=99)
   
end
GO
