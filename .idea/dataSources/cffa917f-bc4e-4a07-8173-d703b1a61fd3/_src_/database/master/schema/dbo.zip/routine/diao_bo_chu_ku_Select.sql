CREATE proc [dbo].[diao_bo_chu_ku_Select]

@cStoreno varchar(10)
as
 select a.cSheetno,a.cWhNo,cWh,a.cFillEmp,a.cFillEmpNo,a.fMoney,a.cInWh,a.cInWhNo,a.cStoreNo,a.cStoreName,a.cInStoreNo,a.cInStoreName,
        b.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,b.fQuantity,b.fInPrice,b.fInMoney,b.dProduct,b.cUnit,b.cSpec
   
  from wh_TfrWarehouse a,wh_TfrWarehouseDetail b 
      
 
 where a.cSheetno=b.cSheetno 
 and ISNULL (bExamin,0)=1 and bReceive='0' and cInStoreNo=@cStoreno
GO
