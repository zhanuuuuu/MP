



CREATE     procedure p_FindGoodsMultSupplier
as
begin
	select f.* 
	into #GoodsMultSupplier_WithoutEstop
	from
	(
	
	select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
	a.cSpec,a.cProductUnit,a.fVipScore,a.fNormalPrice,a.fVipPrice,
	b.cSupNo,b.cSupName,b.fInMoney 
	from  t_Goods a 
	right join t_Supplier_goods b on a.cGoodsNo=b.cGoodsNo
	
	union 
	
	select e.cGoodsNo,e.cGoodsName,e.cBarcode,e.cUnit,
	e.cSpec,e.cProductUnit,e.fVipScore,e.fNormalPrice,e.fVipPrice,
	e.cSupNo,e.cSupName,e.fInMoney 
	from  
	(select distinct c.cGoodsNo,c.cGoodsName,
					c.cBarcode,c.fInPrice as fInMoney,c.cUnit,c.cSpec,c.cProductUnit,c.fVipScore,c.fNormalPrice,c.fVipPrice,
					wh_InWarehouse.cSupplierNo as cSupNo,wh_InWarehouse.cSupplier as cSupName,c.cHelpCode
		from 
				(select distinct wh_InWarehouseDetail.cSheetno,wh_InWarehouseDetail.cGoodsNo,wh_InWarehouseDetail.cGoodsName,
					wh_InWarehouseDetail.cBarcode,wh_InWarehouseDetail.fInPrice,
					t_Goods.cHelpCode,t_Goods.cUnit,t_Goods.cSpec,t_Goods.cProductUnit,
					t_Goods.fVipScore,t_Goods.fNormalPrice,t_Goods.fVipPrice
					from wh_InWarehouseDetail 
	 				left join t_Goods  on wh_InWarehouseDetail.cGoodsNo=t_Goods.cGoodsNo
				) c
		right join wh_InWarehouse on c.cSheetno=wh_InWarehouse.cSheetno
	) e 
	) f
	where f.cGoodsno is not null
	order by f.cSupNo,f.cGoodsNo	 

	select g.cGoodsNo,g.cSupNo
 
  into #GoodsMultSupplier
	from
	(
		select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
		a.cSpec,a.fVipScore,a.fNormalPrice,a.fVipPrice,
		a.cSupNo,a.cSupName,a.fInMoney,cGoodsNo_eStop=b.cGoodsNo   
		from #GoodsMultSupplier_WithoutEstop a
		left join t_Supplier_goods_eStop b on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
	) g
	where g.cGoodsNo_eStop is null
	group by g.cGoodsNo,g.cSupNo

	select cGoodsNo,iCount=count(cGoodsNo)
	into #GoodsMult_only
	from #GoodsMultSupplier
	group by cGoodsNo

  select a.cGoodsNo,c.cGoodsName,c.cGoodsTypeno,c.cGoodsTypename,c.cBarcode,c.cUnit,c.cSpec,
	c.fNormalPrice,c.fVipPrice,c.fVipScore,
	a.cSupNo,b.cSupName from #GoodsMultSupplier a
	left join dbo.t_Supplier b on a.cSupNo=b.cSupNo
	left join dbo.t_Goods c on a.cGoodsNo=c.cGoodsNo
	where a.cGoodsNo in (select cGoodsNo from #GoodsMult_only where iCount>1)
				--and b.cSupNo is not null
  order by a.cGoodsNo
end


GO
