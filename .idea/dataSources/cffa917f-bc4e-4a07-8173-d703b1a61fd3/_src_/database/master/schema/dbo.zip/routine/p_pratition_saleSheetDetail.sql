--创建分区时间
/*
exec p_pratition_saleSheetDetail '2006'
exec p_pratition_saleSheetDetail '2007'
exec p_pratition_saleSheetDetail '2009'
*/
create proc p_pratition_saleSheetDetail
@setDatetime char(4)
as
begin
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_01]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-01-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_02]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-02-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_03]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-03-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_04]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-04-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_05]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-05-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_06]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-06-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_07]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-07-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_08]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-08-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_09]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-09-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_10]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-10-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_11]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-11-01')
	alter partition scheme saleSheetDetailPartScheme
	next used [saleSheetDetail_12]
	alter partition function saleSheetDetailPartFun()
	split range(@setDatetime+'-12-01')

end


GO
