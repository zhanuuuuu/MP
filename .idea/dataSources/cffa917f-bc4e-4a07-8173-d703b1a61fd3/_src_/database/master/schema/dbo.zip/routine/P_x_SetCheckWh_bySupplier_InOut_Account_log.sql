 
/*

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods    where       csupno='1040'
union all
select cGoodsNo,cSupplierNo='6013' from t_Goods    where       cgoodsno='210122'

if (select object_id('tempdb..#temp_Super')) is not null
    drop table #temp_Super
 
    select cSupNo into #temp_Super from t_supplier  where cSupNo='1001'
  
--- drop table ##temp_Kucun
declare @bJiaGong bit
exec [P_x_SetCheckWh_bySupplier_InOut_Account_log]
'2012-12-01','2015-5-29','01'

*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_bySupplier_InOut_Account_log]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32)/*是仓库No*/
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-04-02' set @dDateEnd='2012-04-02'  set @cWhNo='02' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods 
 
  if (select object_id('tempdb..#temp_Goods')) is not null
   drop table #temp_Goods
  Create Table #temp_Goods (cGoodsNo varchar(128),cProductNo varchar(128),cSupplierNo varchar(128))
   insert into #temp_Goods (cGoodsNo,cSupplierNo)
    select distinct a.cGoodsNo,b.cSupplierNo from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno where b.cSupplierNo in(select cSupNo from #temp_Super )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupNo from #temp_Super ))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_goods a
    where a.bStorage=1 and a.cSupno in(select cSupNo from #temp_Super )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupNo from #temp_Super ))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where isnull(a.bStorage,0)=1 and a.cSupno in(select cSupNo from #temp_Super )
    

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsNo,cSupplierNo into #tmpCostGoodsList from #temp_Goods


 
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct a.cGoodsNo,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=1 into  #tmp_WhGoodsList  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1
union all
select distinct a.cGoodsNo,a.cSupplierNo ,cGoodsNo_minPackage,fQty_minPackage,bbox=0
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,a.cSupplierNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1
 

 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)


declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money,fMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

/*2014-10-23如果查询期初的时间段超出记账日期时、数量取最后记账的*/
if @maxWhdDate<@dDateBgn 
begin
   set @dDateBgn=@maxWhdDate
   set @dDateEnd=@maxWhdDate
end


declare @dDate1 datetime
declare @dDate2 datetime
declare @i int
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
			        set @i=1
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=1
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 
		set @maxWhdDate=@dDateEnd
		set @dDateBgn=@dDateBgn
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
	--insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 
	--insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 

  if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

	CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
	CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
	   CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
		declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
    set @strDateEnd=dbo.getdaystr(@maxWhdDate)
    set @strBgn=dbo.getdaystr(@dDateBgn)
	--set @SQLstr= '
			exec('	  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
				select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,
				  b.销售数量0, b.销售金额0, 
				 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
					into #temp_Wh_Goods_begin
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo   
				  and b.cWHno='+@cWHno+'				  
				  union all             
				 select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
			 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_left=0
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo  
				  and b.cWHno='+@cWHno+'
  		  
				  			
		             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			         select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
				 
					  本日库存数量=SUM(isnull(本日库存数量,0)), 
					   盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fMoney_left=sum(isnull(fMoney_left,0))
					   into #temp_SumWh_Goods_begin
						from #temp_Wh_Goods_begin
		              group by cgoodsno,cSupplierNo,cWHno		
				  
		 
				    insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,
				  
				  
				  本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fMoney_left)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,				  
				  
				  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fMoney_left
				  from #temp_SumWh_Goods_begin
				  
				 ')
	--set @SQLstr1='
				exec('  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
				  select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,b.销售数量0, b.销售金额0, 
				 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
			     	into #temp_Wh_Goods_end
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateEnd+'''  and a.cGoodsNo=b.cGoodsNo 
				  and b.cWHno='+@cWHno+'				  
				  union all             
				 select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,
				  b.销售数量0, b.销售金额0, 
			 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,			
				   fMoney_left=0
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where  b.业务日期 between '''+@strDateBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo 
				  and b.cWHno='+@cWHno+'  and  b.iAttribute<>20	
				 
	             
	                 if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			         select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
				 
					   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fmoney_left=sum(isnull(fmoney_left,0))					   
					   into #temp_SumWh_Goods_end
						from #temp_Wh_Goods_end
		              group by cgoodsno,cSupplierNo,cWHno		     
	 
	             
	 
	              insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0, 
				  本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fmoney_left)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0, 
				  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fmoney_left
				  from #temp_SumWh_Goods_end
	 
			 
				')
	--exec (@SQLstr+@SQLstr1)

	-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
		 --- 结束日期数据-（开始日期-1）数据 得出时间段数据    
	     
		 --select * from #temp_WhFrombegin
		 --select * from #temp_WhFromend
	     
		 update a 
		 set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		 a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
				 
				  a.期初库存=isnull(b.期初库存,0), 
				  a.期末库存=isnull(a.期末库存,0), 
				  a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
				  a.fPrice_Avg=a.fPrice_Avg,
				  a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
				  a.fMoney_left=ISNULL(a.fMoney_left,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

--select * from #temp_WhFrombegin

--select * from #temp_WhFromend

	/*获取时间段的入库记录 日期以单据日期为判断。*/
 
	----------------上面从快照表中取出库存数据-------------------

  update a set a.cSupplier=b.cSupName
     from #temp_WhFromend a,t_supplier b
	 where a.cSupplierNo=b.cSupNo

 
	 /*2014-10-02修改数量、大小包装*/
	 
	 update a 
	 set a.cGoodsNo=b.cGoodsNo_minPackage,
     a.销售数量0=a.销售数量0*b.fQty_minPackage,
    
     a.本日库存数量=a.本日库存数量*b.fQty_minPackage,
     a.期初库存=a.期初库存*b.fQty_minPackage,
   
     a.期末库存=a.期末库存*b.fQty_minPackage
    
	 from #temp_WhFromend  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
	 where a.cGoodsNo=b.cGoodsNo 
	 
	 
	 if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
     select cGoodsNo,cSupplierNo,cSupName=cSupplier,
		  
		  销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
		 
		  本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 
		  fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost) ,
		  fMoney_Diff=SUM(fMoney_Diff)
         into #temp_goodsKuCun_1
         from   #temp_WhFromend
         group by cGoodsNo,cSupplierNo,cSupplier
	
	
    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
    select a.cGoodsNo,cSupplierNo,
	    销售数量0, 销售金额0, 
	  本日库存数量,  期初库存,期末库存,fMoney_left,fmoney_cost, 
	  fprice_in=case when ISNULL(a.销售数量0,0)=0 
		then b.fPrice_Contract
		else fmoney_cost/销售数量0 end,
		fProfitRatio_avg=case when isnull(销售金额0,0)<>0 then (isnull(销售金额0,0)-isnull(fmoney_cost,0))/isnull(销售金额0,0)*100 else null end ,
         xsQty=isnull(销售数量0,0),xsMoney=isnull(销售金额0,0)
        into  #temp_goodsKuCun
	  from #temp_goodsKuCun_1 a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo  ---and isnull(销售数量0,0)<>0
	  order by a.cGoodsNo
	  
 
 
	  
	  
	--select cGoodsNo,rk=sum(入库数量1), ck=sum(出库数量0), fc=sum(返厂数量0),xs=sum(销售数量0),bgn=sum(期初库存),qend=sum(期末库存)  
	--into ##temp_Kucun
	--from #temp_goodsKuCun
	--  group by cGoodsNo
	 if (select OBJECT_ID('tempdb..#temp_cSupXsMonthCost'))is not null
	 begin
	      insert into #temp_cSupXsMonthCost(cSupNo,cWHno,[fQty_Sale],[fMoney_Sale],fmoney_cost)
			   select  cSupplierNo,@cWhNo,[fQty_Sale]=SUM(销售数量0),[fMoney_Sale]=sum(销售金额0),
			    fmoney_cost=sum(fmoney_cost)
			  from #temp_goodsKuCun
		group by  cSupplierNo 
		order by cSupplierNo
	  
   end else
   begin
        select  cSupplierNo,@cWhNo,[fQty_Sale]=SUM(销售数量0),[fMoney_Sale]=sum(销售金额0),
			 fmoney_cost=sum(fmoney_cost)
			  from #temp_goodsKuCun
		group by  cSupplierNo 
		order by cSupplierNo
   end
	 /*删除临时表*/
	  	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
      
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	       if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
/*
select cGoodsNo,cSupplierNo,
	  入库数量1, 入库金额1, 
	   Pos客退数量1, Pos客退金额1, 
	  --退货入库数量1, 退货入库金额1,   
	  --出库数量0, 出库金额0, 
	  返厂数量0, 返厂金额0, 
	  销售数量0, 销售金额0, 
	  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 
	  本日库存数量,  期初库存,期末库存 --into ##temp1 
	  from #temp_WhFromend 
	--  where cGoodsNo='140797'
*/

--select @dDate1,@dDate2,@maxWhdDate,@dDateEnd


-- where cGoodsNo='140797'
GO
