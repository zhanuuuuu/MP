create        procedure p_SumSupplierZone
@supNo varchar(64),
@date1 datetime,
@date2 datetime
as
begin
	/*计算商户的货区租赁费用*/
	declare @fMoney_zone_history money
	set @fMoney_zone_history=
			isnull((select sum(fHirePriceSum) from dbo.t_Zone_Contract_History
				where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate <= @date2
			),0)
	declare @fMoney_zone money
	set @fMoney_zone=
			isnull((select sum(fHirePriceSum/DATEDIFF(day,dContractDate,dEndDate)
												*dbo.f_getPeriodDays(@date1,@date2,dContractDate,dEndDate)

												) 
							from dbo.t_Zone_Contract
							where  isnull(jiesuanover,0)=0 and cSupNo=@supNo
			),0)
	select fMoney_zong_total=@fMoney_zone_history+@fMoney_zone,fMoney_zone_history=@fMoney_zone_history,
				 fMoney_zone=@fMoney_zone	
	
end


GO
