
CREATE  function [dbo].[f_AccountNo_chen]
(@accountNo varchar(32)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   declare @strTemp varchar(32)
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetNo_Payoff) from t_Client_Account_Payoff
                  where (cSheetno_Account=@accountNo)
                  or (substring(cSheetno_Account,0,PatIndex('%-%',cSheetno_Account))=@accountNo))
   if @cMaxSerno is null 
   begin
     set @strTemp=@accountNo+'-'+'001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,3) as int)+1 as varchar(10))))
     while len(@cMaxSerno)<3 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp=@accountNo+'-'+@cMaxSerno
   end
   return  @strTemp

end
--print dbo.f_AccountNo_chen ('AS200901090005')


GO
