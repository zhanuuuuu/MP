
--创建分区函数，架构，分区表
/*
exec p_pratition_fun_scheme_saleSheetDetail
*/
create proc p_pratition_fun_scheme_saleSheetDetail
as
begin
	create partition function saleSheetDetailPartFun(datetime)
	as
	range right for values(
	'2008-02-01',
	'2008-03-01',
	'2008-04-01',
	'2008-05-01',
	'2008-06-01',
	'2008-07-01',
	'2008-08-01',
	'2008-09-01',
	'2008-10-01',
	'2008-11-01',
	'2008-12-01'

	)


	create partition scheme saleSheetDetailPartScheme
	as
	partition saleSheetDetailPartFun
	to ([saleSheetDetail_01],[saleSheetDetail_02],[saleSheetDetail_03],
		[saleSheetDetail_04],[saleSheetDetail_05],[saleSheetDetail_06],
		[saleSheetDetail_07],[saleSheetDetail_08],[saleSheetDetail_09],
		[saleSheetDetail_10],[saleSheetDetail_11],[saleSheetDetail_12])


	create TABLE [dbo].[t_SaleSheetDetail](
		[dSaleDate] [datetime] NOT NULL,
		[cSaleSheetno] [varchar](32) COLLATE Chinese_PRC_CI_AS NOT NULL,
		[iSeed] [int] NOT NULL,
		[cGoodsNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NOT NULL,
		[cGoodsName] [varchar](64) COLLATE Chinese_PRC_CI_AS NULL,
		[cBarCode] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
		[cOperatorno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cOperatorName] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cVipCardno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[bAuditing] [bit] NULL,
		[cChkOperno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cChkOper] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[bSettle] [bit] NULL,
		[fVipScore] [money] NULL,
		[fPrice] [money] NOT NULL,
		[fNormalSettle] [money] NULL,
		[bVipPrice] [bit] NULL,
		[fVipPrice] [money] NULL,
		[bVipRate] [bit] NULL,
		[fVipRate] [money] NULL,
		[fQuantity] [money] NOT NULL,
		[fAgio] [money] NULL,
		[fLastSettle0] [money] NULL,
		[fLastSettle] [money] NOT NULL,
		[cManager] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cManagerno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cSaleTime] [varchar](16) COLLATE Chinese_PRC_CI_AS NOT NULL,
		[dFinanceDate] [datetime] NOT NULL,
		[cWorkerno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[cWorker] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
		[bPost] [bit] NULL,
		[bChecked] [bit] NULL,
		[cCheckNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
		[dCheck] [datetime] NULL,
		[cVipNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
		[bBalance] [bit] NULL,
		[jiesuanno] [varchar](50) COLLATE Chinese_PRC_CI_AS NULL,
		[cStationNo] [varchar](64) COLLATE Chinese_PRC_CI_AS NULL,
		[tag_daily] [bit] NULL
	 CONSTRAINT [PK_t_SaleSheetDetail] PRIMARY KEY CLUSTERED 
	(
		[dSaleDate] ASC,
		[cSaleSheetno] ASC,
		[iSeed] ASC
	)WITH (IGNORE_DUP_KEY = OFF) ON [FG_saleSheetDetail]
	)
	ON saleSheetDetailPartScheme([dSaleDate])
	

	--select isdate(datename(yyyy,getdate())+'0201')
end
GO
