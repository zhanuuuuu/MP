


CREATE view [dbo].[v_GoodsIN_chen]
as
--入库单
select distinct SheetType='入库单',TypeNo=0,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage,b.cStoreNo
from wh_InWarehouseDetail a,wh_InWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1
union all
select distinct SheetType='调拨入库单',TypeNo=31,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cWhNo+' '+b.cWh,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,cWhNo=b.cInWhNo,c.bStorage,b.cStoreNo
from wh_TfrInWarehouseDetail a,wh_TfrInWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1
--报溢单
union all
select distinct SheetType='报溢单',TypeNo=6,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage,b.cStoreNo
from wh_EffusionWhDetail a,wh_EffusionWh b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1
--客退入库单
union all
select distinct SheetType='客退入库单',TypeNo=3,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cClientNo+' '+b.cClient,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage,b.cStoreNo
from WH_ReturnGoodsDetail a,WH_ReturnGoods b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1
--成品入库单
union all
select distinct SheetType='成品入库单',TypeNo=9,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage,b.cStoreNo
from wh_DivideWhDetail a,wh_Divide b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1
/*
union all
--盘点溢出
select  SheetType='盘点溢出',TypeNo=11,b.dCheckTask,cTime='1900-01-01 23:59:59',sc='-',
cSheetno=a.cCheckTaskNo,iLineNo='',a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from t_CheckTast_GoodsDetail a,t_CheckTast b,t_goods c
where a.cCheckTaskNo=b.cCheckTaskNo
and a.cGoodsNo=c.cGoodsNo
and isnull(b.bAccount,0)<>1 and isnull(a.fQuantity_diff,0)>0
and b.bchecked in(0,1)
*/










GO
