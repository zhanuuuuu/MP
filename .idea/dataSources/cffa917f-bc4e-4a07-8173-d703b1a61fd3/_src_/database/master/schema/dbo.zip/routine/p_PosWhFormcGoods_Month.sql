/*
  p_PosWhFormcGoods_Month '2013-08-01','2013-09-01','01','Pos_Wh_Form'
*/
create proc [dbo].[p_PosWhFormcGoods_Month]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32),
@DbName varchar(32)
as
begin
declare @dDate1 varchar(32)
declare @dDate2 varchar(32)
set @dDate1=dbo.getdaystr(DATEADD(MONTH,-1,@dDateBgn))
set @dDate2=dbo.getdaystr(CAST((cast(YEAR(@dDateEnd) as varchar(16))+'-'+cast(MONTH(@dDateEnd) as varchar(16))+'-01') AS DATETIME))

if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods
select distinct cGoodsNo into #temp_WhFromGoods from #tmp_WhGoodsList

if(select object_id('tempdb..#temp_WhFromBgn_Month')) is not null drop table #temp_WhFromBgn_Month
CREATE TABLE #temp_WhFromBgn_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
正价销售金额 money)
if(select object_id('tempdb..#temp_WhFromEnd_Month')) is not null drop table #temp_WhFromEnd_Month
CREATE TABLE #temp_WhFromEnd_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
正价销售金额 money)
 
exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin_month''))is not null  drop table #temp_Wh_Goods_begin_month
		select a.[cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额
		into #temp_Wh_Goods_begin_month
		from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
		where  b.dDateBgn='''+@dDate1+'''  and a.cGoodsNo=b.cGoodsNo

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_month''))is not null  drop table #temp_SumWh_Goods_month
		select cgoodsno,销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0), 
		特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 
		正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额)
		into #temp_SumWh_Goods_month
		from  #temp_Wh_Goods_begin_month
		group by cgoodsno
						
		insert into #temp_WhFromBgn_Month([cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额)
		select [cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额 from #temp_SumWh_Goods_month           
')
exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_month''))is not null  drop table #temp_Wh_Goods_end_month
		select a.[cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额
		into #temp_Wh_Goods_end_month
		from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
		where dDateBgn='''+@dDate2+'''  and a.cGoodsNo=b.cGoodsNo 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_month1''))is not null  drop table #temp_SumWh_Goods_month1
		select cgoodsno,销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0), 
		特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 
		正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额)
		into #temp_SumWh_Goods_month1
		from  #temp_Wh_Goods_end_month
		group by cgoodsno

		insert into #temp_WhFromEnd_Month([cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额)
		select [cGoodsNo],销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额 from #temp_SumWh_Goods_month1           
')
 
update a
set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0)
from #temp_WhFromEnd_Month a,#temp_WhFromBgn_Month b
where a.cGoodsNo=b.cGoodsNo
   
   
 -------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.销售数量0=a.销售数量0*ISNULL(b.fQty_minPackage,1),
a.特价销售数量=a.特价销售数量*ISNULL(b.fQty_minPackage,1),
a.正价销售数量=a.正价销售数量*ISNULL(b.fQty_minPackage,1) 
from #temp_WhFromEnd_Month a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''



if (select OBJECT_ID('tempdb..#temp_SumcGoodsXS'))is not null drop table #temp_SumcGoodsXS
select [cGoodsNo],[cWHno],销售数量0=SUM(销售数量0),销售金额0=SUM(销售金额0),特价销售数量=SUM(特价销售数量),
特价销售金额=SUM(特价销售金额), 正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额)
into #temp_SumcGoodsXS
from #temp_WhFromEnd_Month
group by [cGoodsNo],[cWHno]

   
if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
BeginDate=@dDateBgn,EndDate=@dDateEnd,xsQty=isnull(销售数量0,0),xsMoney=isnull(销售金额0,0),
tjXsQty=ISNULL(特价销售数量,0),
tjXsMoney=ISNULL(特价销售金额,0), zjXsqty=ISNULL(正价销售数量,0),zjXsMoney=ISNULL(正价销售金额,0)
into  #temp_goodsKuCun
--from #temp_WhFromEnd_Month a,t_Goods b
from #temp_SumcGoodsXS a,t_Goods b
where a.cGoodsNo=b.cGoodsNo 
order by a.cGoodsNo



if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin	  
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select GoodsNo_Pdt=a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,
   a.cGoodsTypename,a.bProducted,a.cProductNo,
		         a.BeginDate,a.EndDate,
		         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),tjXsQty=ISNULL(tjXsQty,0),
      tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
	into #temp_goodsKuCun_last
		  from #temp_goodsKuCun a,#temp_GoodsTypeNo b
  where a.cGoodsTypeno=b.cGoodsTypeno
  
          select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,
          cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),tjXsQty=ISNULL(tjXsQty,0),
      tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
		  from #temp_goodsKuCun_last
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun_last 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun_last
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
end else
begin
    select GoodsNo_Pdt=cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,
  cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),tjXsQty=ISNULL(tjXsQty,0),
      tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
		  from #temp_goodsKuCun
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
end
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	   if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	    if(select object_id('tempdb..#temp_ReadycGoodsHb')) is not null drop table #temp_ReadycGoodsHb
	    if (select OBJECT_ID('tempdb..#temp_SumcGoodsXS'))is not null drop table #temp_SumcGoodsXS	 
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
      
end
GO
