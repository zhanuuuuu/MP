/*
  select cStoreNo into U_Key.dbo.temp_cStore from t_Store  
  where cStoreNo='1008'
  
  [p_GetcStoreOutGoods_test] '2017-2-7','2017-2-7','',1
  
*/
create proc [dbo].[p_GetcStoreOutGoods_20170214]
@dDate1 datetime,
@dDate2 datetime, 
@cTermID varchar(32),
@bFresh int
as
begin
	if (select object_id('tempdb..#tmp_StoreNo'))is not null drop table #tmp_StoreNo
	create table #tmp_StoreNo(cStoreNo varchar(32))

	exec('
	   insert into #tmp_StoreNo(cStoreNo)
	   select cStoreNo from U_Key.dbo.temp_cStore'+@cTermID+'  
	') 

     if (select object_id('tempdb..#tmp_OutGoodsFresh'))is not null drop table #tmp_OutGoodsFresh
     
     if (select object_id('tempdb..#tmp_OutGoods'))is not null drop table #tmp_OutGoods
     
     if (select object_id('tempdb..#tmp_OutGoodsAll'))is not null drop table #tmp_OutGoodsAll
     
	 if @bFresh=1 
	 begin
		 --select a.cCustomerNo,a.cCustomer,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 --into #tmp_OutGoodsFresh
		 --from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b,t_Goods c
		 --where a.dDate between @dDate1 and @dDate2  
		 -- and a.cSheetno=b.cSheetno and b.cGoodsNo=c.cGoodsNo
		 --and ISNULL(a.bExamin,0)=1 and ISNULL(c.bfresh,0)=1
		 --and ISNULL(a.bReceive,0)=1
		 --group by a.cCustomerNo,a.cCustomer,b.cGoodsNo
		 
         select a.cCustomerNo,a.cCustomer,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoodsFresh
		 from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b 
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno  
		 and ISNULL(a.bExamin,0)=1 and ISNULL(a.bfresh,0)=1
		 and ISNULL(a.bReceive,0)=1
		 group by a.cCustomerNo,a.cCustomer,b.cGoodsNo
 
		 if (select object_id('tempdb..#tmp_OutGoodsFreshType'))is not null drop table #tmp_OutGoodsFreshType

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsFreshType
		 from t_Goods a,#tmp_OutGoodsFresh b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
 
		 
		 exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsFreshType
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename,i=1
				 from #tmp_OutGoodsFreshType
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsFreshType
				 group by cStoreNo,cStoreName 
				  order by cStoreNo,cGoodsTypeno,i
				   
			') 
		 
     end else if @bFresh=0 
     begin
              
         select a.cCustomerNo,a.cCustomer,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoods
		 from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1 and ISNULL(a.bfresh,0)=0
		 and ISNULL(a.bReceive,0)=1
		 and isnull(StoreInSheetNo,'') not like 'STIN%'
		 group by a.cCustomerNo,a.cCustomer,b.cGoodsNo
		 
 
		 
		 if (select object_id('tempdb..#tmp_OutGoodsType'))is not null drop table #tmp_OutGoodsType

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType
		 from t_Goods a,#tmp_OutGoods b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
		 

			exec('
			     if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i
			') 

	 
     end else if @bFresh=3 
     begin
         if (select object_id('tempdb..#tmp_OutGoods3'))is not null drop table #tmp_OutGoods3    
         select a.cCustomerNo,a.cCustomer,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoods3
		 from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1 
		 and isnull(StoreInSheetNo,'') like 'STIN%'
		 group by a.cCustomerNo,a.cCustomer,b.cGoodsNo
  
		 if (select object_id('tempdb..#tmp_OutGoodsType3'))is not null drop table #tmp_OutGoodsType3

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType3
		 from t_Goods a,#tmp_OutGoods3 b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
	 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType3
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType3
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType3
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i
				 
				 
				 --select * from U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 
			') 

		 
		 
     end else if @bFresh=4   --报损 
     begin
         if (select object_id('tempdb..#tmp_OutGoods_Loss'))is not null drop table #tmp_OutGoods_Loss   
         select cCustomer=a.cStoreName,cCustomerNo=a.cStoreNo,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fMoney)
		 into #tmp_OutGoods_Loss
		 from wh_LossWarehouse a,wh_LossWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1  
		 group by a.cStoreName,a.cStoreNo,b.cGoodsNo
  
		 if (select object_id('tempdb..#tmp_OutGoodsType_loss'))is not null drop table #tmp_OutGoodsType_loss

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType_loss
		 from t_Goods a,#tmp_OutGoods_Loss b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
	 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType_loss
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType_loss
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType_loss
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i
				 
				 
				 --select * from U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 
			') 

		 
		 
     end else if @bFresh=5   --报溢 
     begin
         if (select object_id('tempdb..#tmp_OutGoods_Eff'))is not null drop table #tmp_OutGoods_Eff 
         select cCustomer=a.cStoreName,cCustomerNo=a.cStoreNo,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoods_Eff
		 from wh_EffusionWh a,wh_EffusionWhDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1  
		 group by a.cStoreName,a.cStoreNo,b.cGoodsNo
  
		 if (select object_id('tempdb..#tmp_OutGoodsType_Eff'))is not null drop table #tmp_OutGoodsType_Eff

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType_Eff
		 from t_Goods a,#tmp_OutGoods_Eff b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
	 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType_Eff
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType_Eff
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType_Eff
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i 
				 
			')  
     end  else if @bFresh=6   --调拨出 
     begin
         if (select object_id('tempdb..#tmp_OutGoods_Tfr'))is not null drop table #tmp_OutGoods_Tfr
         select cCustomer=a.cStoreName,cCustomerNo=a.cStoreNo,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoods_Tfr
		 from wh_TfrWarehouse a,wh_TfrWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1  
		 group by a.cStoreName,a.cStoreNo,b.cGoodsNo
  
		 if (select object_id('tempdb..#tmp_OutGoodsType_Tfr'))is not null drop table #tmp_OutGoodsType_Tfr

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType_Tfr
		 from t_Goods a,#tmp_OutGoods_Tfr b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
	 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType_Tfr
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType_Tfr
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType_Tfr
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i 
				 
			')  
     end  else if @bFresh=7   --调拨入
     begin
         if (select object_id('tempdb..#tmp_OutGoods_TfrIn'))is not null drop table #tmp_OutGoods_TfrIn
         select cCustomer=a.cStoreName,cCustomerNo=a.cStoreNo,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoods_TfrIn
		 from Wh_TfrInWarehouse a,Wh_TfrInWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1  
		 group by a.cStoreName,a.cStoreNo,b.cGoodsNo
  
		 if (select object_id('tempdb..#tmp_OutGoodsType_TfrIn'))is not null drop table #tmp_OutGoodsType_TfrIn

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsType_TfrIn
		 from t_Goods a,#tmp_OutGoods_TfrIn b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
	 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsType_TfrIn
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsType_TfrIn
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsType_TfrIn
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i 
				 
			')  
     end else
     begin
         select a.cCustomerNo,a.cCustomer,b.cGoodsNo,fQty=sum(b.fQuantity),fInMoney=sum(b.fInMoney)
		 into #tmp_OutGoodsAll
		 from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
		 where a.dDate between @dDate1 and @dDate2  
		  and a.cSheetno=b.cSheetno
		 and ISNULL(a.bExamin,0)=1 --and ISNULL(a.bfresh,0)=0
		 and ISNULL(a.bReceive,0)=1
		 and isnull(StoreInSheetNo,'') not like 'STIN%'
		 group by a.cCustomerNo,a.cCustomer,b.cGoodsNo

		 if (select object_id('tempdb..#tmp_OutGoodsTypeAll'))is not null drop table #tmp_OutGoodsTypeAll

		 select cStoreNo=b.cCustomerNo,cStoreName=replace(b.cCustomer,'路发万家',b.cCustomerNo),b.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,
		 b.fQty,b.fInMoney,a.cBarcode,a.cGoodsTypeno,a.cGoodsTypename
		 into #tmp_OutGoodsTypeAll
		 from t_Goods a,#tmp_OutGoodsAll b,#tmp_StoreNo c
		 where a.cGoodsNo=b.cGoodsNo and b.cCustomerNo=c.cStoreNo
		 order by b.cGoodsNo
		 
		 
 

			exec('
			   if (select object_id(''U_Key.dbo.temp_StoreGoods'+@cTermID+' ''))is not null drop table U_Key.dbo.temp_StoreGoods'+@cTermID+'
			   
			     select cStoreNo,cStoreName,cGoodsNo,cGoodsName,cUnit,cSpec,fQty,fInMoney,cBarcode,cGoodsTypeno,cGoodsTypename,i=0
			     into U_Key.dbo.temp_StoreGoods'+@cTermID+'
				 from #tmp_OutGoodsTypeAll
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''合计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno,cGoodsTypename ,i=1
				 from #tmp_OutGoodsTypeAll
				 group by cStoreNo,cStoreName,cGoodsTypeno,cGoodsTypename 
				 union all 
				 select cStoreNo,cStoreName,cGoodsNo=''总计'',cGoodsName=null,
				 cUnit=null,cSpec=null,fQty=SUM(fQty),fInMoney=SUM(fInMoney),cBarcode=null,cGoodsTypeno=''zzzzz'',cGoodsTypename=null ,i=2
				 from #tmp_OutGoodsTypeAll
				 group by cStoreNo,cStoreName
				 order by cStoreNo,cGoodsTypeno,i
			') 
     end
end
GO
