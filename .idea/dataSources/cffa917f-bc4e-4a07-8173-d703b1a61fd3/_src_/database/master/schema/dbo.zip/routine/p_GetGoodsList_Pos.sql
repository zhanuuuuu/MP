/*
if (select object_id('tempdb..#temp_Goods'))is not null
drop table #temp_Goods
select cbarcode=Substring(cBarcode,1,4) into #temp_Goods from t_Goods
where LEN(cBarcode)=13
group by substring(cBarcode,1,4)
having COUNT(*)>500
order by Substring(cBarcode,1,4) asc


select cBarCodeLen='13',cBarCode_01=min(a.cbarcode),cBarCode_02=MAX(a.cBarCode),b.cbarcode 
into t_Goods_XXBarcode
from t_Goods a,#temp_Goods b
where substring(a.cBarcode,1,4)=b.cbarcode
and LEN(a.cBarcode)=13
group by b.cbarcode

select * from t_Goods_XXBarcode

exec p_GetGoodsList_Pos 13,'6903',100,1
go
exec p_GetGoodsList_Pos 13,'6903',99,2

*/
CREATE proc p_GetGoodsList_Pos
@Len int,
@cBarCode4 varchar(16),
@PageSize  int = 100,           -- 每页显示的记录数
@PageIndex int = 1            -- 页码
as
SET NOCOUNT ON --加在as  和声明语句之间 
begin
  
  if (select object_id('tempdb..#temp_GoodsList'))is not null
  drop table #temp_GoodsList
  select a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cGoodsTypeno,a.cGoodsTypename,a.cBarcode,
  a.cUnit,a.cSpec,a.fNormalPrice,a.fVipPrice,a.fVipPrice_Student,a.fVipScore,a.bDeled,a.bWeight,
  a.bHidePrice,a.bHideQty,a.pinpai,a.pinpaino  
  into #temp_GoodsList
  from t_Goods a,t_Goods_XXBarcode b
  where a.cBarcode between b.cBarCode_01 and b.cBarCode_02 
  and b.cbarcode=@cBarCode4 and b.cBarCodeLen=@Len
  order by a.cBarcode
  
  
  
  ALTER TABLE #temp_GoodsList ADD iLineNo int IDENTITY (1,1) 
	
  CREATE INDEX IX_tmpGoodsList ON #temp_GoodsList(iLineNo)
  declare @index0 varchar(32)
  declare @index1 varchar(32)
  set @index0=str((@PageIndex-1)*@PageSize+1)
  set @index1=str(@PageIndex*@PageSize)
  
  exec('
   select  cGoodsNo,cUnitedNo,cGoodsName,cGoodsTypeno,cGoodsTypename,cBarcode,
   cUnit,cSpec,fNormalPrice,fVipPrice,fVipPrice_Student,fVipScore,bDeled,bWeight,
   bHidePrice,bHideQty,pinpai,pinpaino 
   from #temp_GoodsList
   WHERE iLineNo BETWEEN '+@index0+' AND '+@index1+'
  ')
  
end
GO
