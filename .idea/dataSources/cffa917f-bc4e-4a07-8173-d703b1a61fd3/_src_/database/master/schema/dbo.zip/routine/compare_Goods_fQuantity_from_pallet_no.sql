  CREATE proc  compare_Goods_fQuantity_from_pallet_no
  @pallet_no varchar(20)
  as
  select  H.cSheetno , H.cBarcode,H.cUnitedNo, H.cGoodsNo, H.cGoodsName,H.fInMoney,H.fInPrice ,H.fQuantity as Fen_Jian_Num ,
   I.cStoreNo,I.cStoreName,I.fQuantity as Xu_Qiu_Num ,I.cSheetno as Xu_Qiu_no ,J.cSheetno as cSheetNo_Pallet,J.cCustomerNo,J.cCustomer
   from wh_cStoreOutWarehouseDetail_Sort  H,       
   (select b.*, a.cStoreNo,a.cStoreName
   from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
   where a.cSheetno=b.cSheetno )  I,
   wh_PalletSheet  J
    where   H.cGoodsNo=I.cGoodsNo  and H.cSheetno  in 
   (select cDistBoxNo_SortSheetNo from  wh_PalletSheetDetail 
    where cPalletNo =@pallet_no and J.cSheetno=wh_PalletSheetDetail.cSheetno)
  GO
