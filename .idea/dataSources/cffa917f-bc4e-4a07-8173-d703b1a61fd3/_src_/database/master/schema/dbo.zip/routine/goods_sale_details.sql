CREATE proc goods_sale_details
 
 @goods_b_g_n varchar(20),
 @date1  datetime,
 @date2  datetime,
 @cStoreNo varchar(20)
as
select cSaleSheetno,cGoodsNo,cGoodsName,cOperatorno,cOperatorName,fLastSettle,fQuantity,fPrice,cSaleTime from t_SaleSheetDetail
where dSaleDate between @date1 and @date2  and cStoreNo=@cStoreNo 
and (cBarCode=@goods_b_g_n or cGoodsNo=@goods_b_g_n or cGoodsName like '%'+@goods_b_g_n+'%')
order by cSaleSheetno,cSaleTime
GO
