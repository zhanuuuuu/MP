--P_Z_getInWareHouse_wind_MVC_Pro '000084','2017-01-01','0',''
--exec [P_Z_getInWareHouse_wind_MVC_Pro] '1137','2017-03-23','','','1099'
 


CREATE             procedure [dbo].[P_Z_getInWareHouse_wind_MVC_Pro]
  @cSupplierNo varchar(16),
  @EndDate datetime,
	@station varchar(64),
  @cTelMinDate varchar(32),@cStoreNo varchar(32)
as
begin
	declare @strtmp varchar(32)
	set @strtmp=dbo.getDayStr(@EndDate)
	
exec('
	if  (select object_id(''U_key.dbo.TempInRbd_'+@cSupplierNo+''')) is not null 
	drop table U_key.dbo.TempInRbd_'+@cSupplierNo+'
	select cStation='''+@station+''' into U_key.dbo.TempInRbd_'+@cSupplierNo+' 

	if  (select object_id(''U_key.dbo.TempInWareHouse_'+@cSupplierNo+''')) is not null 
	drop table U_key.dbo.TempInWareHouse_'+@cSupplierNo+'

	select cStaion='''+@station+''',c.cStoreNo,c.cStoreName,a.cSheetno,a.cSupplierNo,a.cSupplier,
          a.cOperatorNo,a.cOperator,
          a.cExaminerNo,a.cExaminer,
          a.cWhNo,a.cWh,
          a.fMoney,
          dDate=dbo.getDayStr(a.dDate), 
          bFoot=isnull(a.bInWhBalance,0), 
          bBalance=case when isnull(a.bBalance,0)=1 then 1
                        else 0
                   end,
          bExamin=case when isnull(a.bExamin,0)=1 then 1
                       else 0
                  end,
          bPresent=case when isnull(a.bPresent,0)=1 then 1
                        else 0
                   end,bInWhBalance=isnull(a.bInWhBalance,0),a.StoreInSheetNo
	 into U_key.dbo.TempInWareHouse_'+@cSupplierNo+'
	from wh_InWareHouse a,t_Supplier b,wh_StoreInWareHouse c
	where dbo.getDayStr(a.dDate)<='''+@strtmp+''' and a.cSupplierNo=b.cSupNo
	and a.dDate=c.dDate and a.StoreInSheetNo=c.cSheetno
	and c.cStoreNo='''+@cStoreNo+''' and a.cStoreNo<>c.cStoreNo
        and b.cSupNo='''+@cSupplierNo+''' and isnull(a.bBalance,0)<>1
         and isnull(a.bReason_FinanceCheck,0)=1
        and isnull(a.bInWhBalance,0)=0
         and ISNULL(a.bExamin,0)=1  
        
  ')

end


GO
