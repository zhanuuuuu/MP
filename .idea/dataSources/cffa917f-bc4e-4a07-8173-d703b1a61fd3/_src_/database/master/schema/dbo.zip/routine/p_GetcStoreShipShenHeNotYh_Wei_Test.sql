 CREATE proc  [dbo].[p_GetcStoreShipShenHeNotYh_Wei_Test]
 @dDate datetime, --- 装车单日期
 @cStoreNo varchar(32),  --- 收货门店
 @cCarNo varchar(64)  -- 车牌
 as 
 -- 查询已审、门店未验货商品
 
  if (select object_id('tempdb..#temp_cStoreShip'))is not null
  drop table #temp_cStoreShip
  
  select dDate,cSheetno,cCustomerNo,cCustomer into #temp_cStoreShip from wh_ShipSheet
  where dDate=@dDate and cTruckID=@cCarNo 
  and  ISNULL(bExamin,0)=1 and ISNULL(bReceive,0)=0
 
  
  --- 查询装车单中 、门店对应的出库验货单
  if (select object_id('tempdb..#temp_cStoreShipOutYh'))is not null
  drop table #temp_cStoreShipOutYh
  select  distinct cStoreNo,cStoreName,cSheetNo_Pallet, cCustomerNo,cCustomer 
  ,a.cSheetno as zhuang_che_no,a.cSheetNo_YH
  into #temp_cStoreShipOutYh
  from  wh_ShipOutYhSheetDetail a,#temp_cStoreShip b
  where a.dDate=b.dDate and a.cSheetno=b.cSheetno
  and a.cStoreNo=@cStoreNo and ISNULL(a.bStoreYhShip ,0)=0
  
  --select * from #temp_cStoreShipOutYh
  
  --- 根据托盘单 查询分拣单
  if (select object_id('tempdb..#temp_cStoreShipOutPallet'))is not null
  drop table #temp_cStoreShipOutPallet
  select distinct a.cDistBoxNo_SortSheetNo,b.cStoreNo,b.cStoreName,b.cCustomerNo,b.cCustomer, a.cPalletNo,a.cDistBoxNo
  ,b.zhuang_che_no,b.cSheetNo_Pallet,b.cSheetNo_YH
  into #temp_cStoreShipOutPallet
  from wh_PalletSheetDetail a,#temp_cStoreShipOutYh b
  where a.cSheetno=b.cSheetNo_Pallet
  
  --select * from #temp_cStoreShipOutPallet
  
 
  --- 查询出库单
  if (select object_id('tempdb..#temp_cStoreShipOut_Sort'))is not null
  drop table #temp_cStoreShipOut_Sort
  select distinct a.jiesuanno,a.cWhNo,a.cWh, c.cStoreNo,c.cStoreName,c.cCustomerNo,c.cCustomer,c.cPalletNo,c.cDistBoxNo,c.cDistBoxNo_SortSheetNo
  ,c.zhuang_che_no,c.cSheetNo_Pallet,c.cSheetNo_YH
  into #temp_cStoreShipOut_Sort from 
  wh_cStoreOutWarehouse_Sort a,#temp_cStoreShipOutPallet c
  where a.cSheetno=c.cDistBoxNo_SortSheetNo and a.cCustomerNo=c.cStoreNo
  
  --select * from #temp_cStoreShipOut_Sort
  
  ---查询出库单详情
  
  select DISTINCT  cSheetno=a.jiesuanno,a.iLineNo,a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnitedNo,fQuantity,fInPrice,fInMoney,
  fTaxrate,bTax,fTaxPrice,fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cUnit,cSpec,
  cStoreName=b.cCustomer,cStoreNo=b.cCustomerNo,
  cCustomerNo=b.cStoreNo,cCustomer=b.cStoreName,b.cPalletNo,b.cDistBoxNo,b.cDistBoxNo_SortSheetNo,b.cWhNo,b.cWh
  ,b.zhuang_che_no,b.cSheetNo_Pallet,b.cSheetNo_YH
  from wh_cStoreOutWarehouseDetail_Sort a,#temp_cStoreShipOut_Sort b
  where a.cSheetno=b.cDistBoxNo_SortSheetNo
  
  
 /* 
  select DISTINCT  a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnitedNo,fQuantity,fInPrice,fInMoney,
  fTaxrate,bTax,fTaxPrice,fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cUnit,cSpec,
  cStoreName=b.cCustomer,cStoreNo=b.cCustomerNo,
  cCustomerNo=b.cStoreNo,cCustomer=b.cStoreName,b.cPalletNo,b.cDistBoxNo,b.cDistBoxNo_SortSheetNo,b.cWhNo,b.cWh
  ,b.zhuang_che_no,b.cSheetNo_Pallet,b.cSheetNo_YH
  from wh_cStoreOutWarehouseDetail a,#temp_cStoreShipOut_Sort b
  where a.cSheetno=b.jiesuanno
   */
 GO
