



create   function [dbo].[f_GenJiesuanNo_Pro]
(@cYear varchar(4),@cSupNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int 
	 declare @strRet varchar(32)
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(jiesuanno) from t_Supplier_jiesuan_Pro
/*
                  where cSupNo=@cSupNo
                        and datename(yyyy,jiesuanriqi)=@cYear
*/
                  where (cSupNo=@cSupNo
                        and datename(yyyy,jiesuanriqi)=@cYear)
												or
												(substring(jiesuanno,8,PatIndex('%-%',jiesuanno)-8)=@cSupNo
												 and datename(yyyy,jiesuanriqi)=@cYear	
												)

                 )
   if @cMaxSerno is null 
   begin
     set @strRet=  'PJS'+@cYear+@cSupNo+'-'+'0001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,4) as int)+1 as varchar(10))))
     while len(@cMaxSerno)<4 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strRet=    'PJS'+@cYear+@cSupNo+'-'+@cMaxSerno 
   end

   return @strRet
end


GO
