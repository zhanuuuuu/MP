 
/* 
if (select object_id('tempdb..#temp_GoodsTypeNo'))is not null drop table #temp_GoodsTypeNo
select distinct cgoodstypeno into #temp_GoodsTypeNo from t_Goods 
where cgoodstypeno like '30%'
 
exec [p_FIFO_Pos_Wh_Form_log_PlanTypeDay] '2015-5-18','2015-5-18','01'

*/
create procedure [dbo].[p_FIFO_Pos_Wh_Form_log_PlanTypeDay_Day]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as  --查询某时段 商品销售利润（含顾客退货） 

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 
set @dDateEnd=@dDate2  
 
    /*获取商品信息*/
	if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	select distinct cGoodsNo into #temp_Goods 
	from #temp_GoodsTypeNo a,t_Goods b
	where a.cGoodsTypeNo=b.cGoodsTypeNo
	
	CREATE INDEX IX_tmp_WhFromGoods  ON #temp_Goods(cGoodsNo)
	
--	print '1    '+dbo.getTimeStr(GETDATE())		
	
    if (select object_id('tempdb..#temp_Goods_1'))is not null drop table #temp_Goods_1
    select distinct a.cGoodsNo,b.cSupplierNo into #temp_Goods_1   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where a.cGoodsNo in (select cGoodsNo from #temp_Goods)  
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cGoodsNo in (select cGoodsNo from #temp_Goods))   
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)

--    print '2    '+dbo.getTimeStr(GETDATE())		

	-- if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	--select distinct cGoodsNo,cSupplierNo into #tmpCostGoodsList 
	--from #temp_Goods_1

if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cSupplierNo into  #tmp_WhGoodsList  
from (
	select distinct a.cGoodsNo,a.cSupplierNo  
	--from #tmpCostGoodsList a,t_goods b
	from #temp_Goods_1 a,t_goods b
	where a.cgoodsno=b.cgoodsno 
	union all
	select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
	from #temp_Goods_1 a,t_goods b
	where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
) a

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)


-- print '3    '+dbo.getTimeStr(GETDATE())	

 
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 
  库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money,
  会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 库存标志 bit,
  期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money,
  会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
 -----------创建会员销售和来客数量
if(select object_id('tempdb..#temp_WhFrombeginVIP')) is not null drop table #temp_WhFrombeginVIP
if(select object_id('tempdb..#temp_WhFromendVIP')) is not null drop table #temp_WhFromendVIP
CREATE TABLE #temp_WhFrombeginVIP ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
CREATE TABLE #temp_WhFromendVIP   ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
    
 /*快照表中的最大日期。。。*/

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
 if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

-- print '4    '+dbo.getTimeStr(GETDATE())	

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn) 

declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
exec('
 --------期初销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_beginQty
	from  #temp_Wh_Goods_beginQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_beginSale
	from  #temp_Wh_Goods_beginSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
	from #temp_SumWh_Goods_beginQty
 
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
----------期初成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_beginCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_beginCost
	from  #temp_Wh_Goods_beginCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney		
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	
-------期初库存
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_begin
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_begin
	from  #temp_Wh_Goods_begin
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.期初库存=b.fQty 			
	from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	
-------期初会员销售数量
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQtyVip''))is not null  drop table #temp_Wh_Goods_beginQtyVip
	select a.cgoodsno,fQty=b.fQty_'+@MMDAY_1+' 				 
	into #temp_Wh_Goods_beginQtyVip
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_QtyVip b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
 
    update a 
	set a.会员销售数量=b.fQty 			
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginQtyVip b
	where a.cGoodsNo=b.cGoodsNo  
	
-------会员销售金额
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSaleVip''))is not null  drop table #temp_Wh_Goods_beginSaleVip
	select a.cgoodsno,fMoney=b.Sale_'+@MMDAY_1+' 				 
	into #temp_Wh_Goods_beginSaleVip
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_SaleVip b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
	
 
    update a 
	set a.会员销售金额=b.fMoney 			
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginSaleVip b
	where a.cGoodsNo=b.cGoodsNo  
	
	
	-------会员来客数 和总来客数
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginVipCount''))is not null  drop table #temp_Wh_Goods_beginVipCount
	select a.cgoodsno,fQtyVip=b.Qty_'+@MMDAY_1+',fQty=b.Qtyzs_'+@MMDAY_1+'				 
	into #temp_Wh_Goods_beginVipCount
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_VipCount b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
	
---b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数
    update a 
	set a.会员来客数=b.fQtyVip,a.来客数=b.fQty
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginVipCount b
	where a.cGoodsNo=b.cGoodsNo  
 
')

exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
	into #temp_Wh_Goods_endCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
----------期末库存	
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
	into #temp_Wh_Goods_end
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
  
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_end
	from  #temp_Wh_Goods_end
	group by cgoodsno,cSupplierNo
	 
    update a 
	set a.期末库存=b.fQty, 
	a.fmoney_left=b.fMoney			
	from #temp_WhFromend a ,#temp_SumWh_Goods_end b
	where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
-------期初会员销售数量
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQtyVip''))is not null  drop table #temp_Wh_Goods_beginQtyVip
	select a.cgoodsno,fQty=b.fQty_'+@MMDAY_1+' 				 
	into #temp_Wh_Goods_beginQtyVip
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_QtyVip b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
 
    update a 
	set a.会员销售数量=b.fQty 			
	from #temp_WhFromend a ,#temp_Wh_Goods_beginQtyVip b
	where a.cGoodsNo=b.cGoodsNo  
	
-------会员销售金额
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSaleVip''))is not null  drop table #temp_Wh_Goods_beginSaleVip
	select a.cgoodsno,fMoney=b.Sale_'+@MMDAY_1+' 				 
	into #temp_Wh_Goods_beginSaleVip
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_SaleVip b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
	
 
    update a 
	set a.会员销售金额=b.fMoney 			
	from #temp_WhFromend a ,#temp_Wh_Goods_beginSaleVip b
	where a.cGoodsNo=b.cGoodsNo  
	
	
	-------会员来客数 和总来客数
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginVipCount''))is not null  drop table #temp_Wh_Goods_beginVipCount
	select a.cgoodsno,fQtyVip=b.Qty_'+@MMDAY_1+',fQty=b.Qtyzs_'+@MMDAY_1+'				 
	into #temp_Wh_Goods_beginVipCount
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_VipCount b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
  
	
---b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数
    update a 
	set a.会员来客数=b.fQtyVip,a.来客数=b.fQty
	from #temp_WhFromend a ,#temp_Wh_Goods_beginVipCount b
	where a.cGoodsNo=b.cGoodsNo  
 		
 
')
 
--	print dbo.getTimeStr(GETDATE())
--print 4
-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
--- 结束日期数据-（开始日期-1）数据 得出时间段数据    
 
update a 
set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
a.期初库存=isnull(b.期初库存,0), 
a.期末库存=isnull(a.期末库存,0), 
a.fPrice_Avg=a.fPrice_Avg,
a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0)),
a.会员销售数量=isnull(a.会员销售数量,0)-isnull(b.会员销售数量,0),
a.会员销售金额=isnull(a.会员销售金额,0)-isnull(b.会员销售金额,0),
a.会员来客数=a.会员来客数-b.会员来客数,
a.来客数=a.来客数-b.来客数
from #temp_WhFromend a,#temp_WhFrombegin b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

 

if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select a.cGoodsNo, b.cGoodsTypeno,cSupplierNo,
BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty=SUM(销售数量0),xsMoney=SUM(销售金额0), 	 
fCostPrice=AVG(fPrice_Avg),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),i=0,
特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),
 fmoney_left=SUM(fmoney_left),期初库存=SUM(期初库存), 期末库存=SUM(期末库存),
当月销售数量=SUM(xsQty),当月销售金额=SUM(xsMoney),当月特价销售数量=SUM(特价销售数量),当月特价销售金额=SUM(特价销售金额),
当月正价销售数量=SUM(正价销售数量),当月正价销售金额=SUM(正价销售金额),
会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),来客数=SUM(来客数),
当前库存=CAST(null as money),当前库存金额=CAST(null as money),
最近销售日=CAST(null as date),可销天数=CAST(null as money)
into  #temp_goodsKuCun
from #temp_WhFromend a,t_Goods b
where a.cGoodsNo=b.cGoodsNo   
group by a.cGoodsNo, b.cGoodsTypeno,cSupplierNo
order by a.cGoodsNo

CREATE INDEX IX_temp_emp_goodsKuCun  ON #temp_goodsKuCun(cGoodsNo)

-- print '7    '+dbo.getTimeStr(GETDATE())	
	 
 
---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)

		--------表示当前分配的差价单的供应商在当前的列表中存在
		if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
		drop table #temp_wh_DiffGoodsNo
		select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo
		from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
		where dSaleDate between @dDate1 and @dDate2 
		and a.cGoodsno=b.cGoodsNo 
		group by a.cGoodsno,a.cSupNo
		
 
		CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

		if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1'))is not null  
		drop table #temp_wh_DiffGoodsNo1
		select b.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo1
		from #temp_wh_DiffGoodsNo a,#temp_goodsKuCun b
		where a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
		group by b.cGoodsno,a.cSupNo
		
        CREATE INDEX IX_temp_wh_wh_DiffGoodsNo1  ON #temp_wh_DiffGoodsNo1(cGoodsNo)
        
		update a
		set
		a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
		a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
		from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1 b
		where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo


        if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null'))is not null  
		drop table #temp_wh_DiffGoodsNo1_Null
		select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo1_Null
		from #temp_wh_DiffGoodsNo a left join #temp_goodsKuCun b
		on a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
		where ISNULL(b.cGoodsNo,'')=''
        group by a.cGoodsno,a.cSupNo
        
        CREATE INDEX IX_temp_wh_DiffGoodsNo1_Null  ON #temp_wh_DiffGoodsNo1_Null(cGoodsNo)
        
        if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null0'))is not null  
		drop table #temp_wh_DiffGoodsNo1_Null0
        select b.cGoodsNo,cSupNo=b.cSupplierNo,fqty_Sale=sum(a.fqty_Sale),fMoney_Diff=sum(a.fMoney_Diff),cRows=COUNT(b.cGoodsNo)
        into #temp_wh_DiffGoodsNo1_Null0
        from #temp_wh_DiffGoodsNo1_Null a,#temp_goodsKuCun b
        where a.cGoodsno=b.cGoodsNo and a.cSupNo<>b.cSupplierNo
        group by b.cGoodsNo,b.cSupplierNo
        having COUNT(b.cGoodsNo)=1
 
       update a
	   set 
	   a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
	   a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
	   from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1_Null0 b
	   where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo

-- print '8    '+dbo.getTimeStr(GETDATE())	

/*
 2015-03-11 获取库存调整的商品
*/
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCun

--------获取期末前最新的毛利调整数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fNewPrice=a.NewFckprice,dDateTime=max(dDateTime)--,a.cSupNo
into #tmpGoodsRelationKucun_1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno  
group by a.cGoodsNo,a.NewFckprice 
	
---------修改最近调整成本商品的毛利
update a 
set a.fMoney_Cost=ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fML=isnull(a.xsMoney,0)-ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fCostPrice=b.fNewPrice
from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
where a.cGoodsNo=b.cGoodsNo ---and a.cSupplierNo=b.cSupNo

-- print '9    '+dbo.getTimeStr(GETDATE())
 
-----------获取当前库存------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
declare @dDate date
--set @dDate=CONVERT (date, GETDATE())
set @dDate=@dDate1
  

 exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDate,@dDate,@cWhno  
 
if (select OBJECT_ID('tempdb..#temp_goodsKuCunGroupby'))is not null  drop table #temp_goodsKuCunGroupby
select cGoodsNo,cGoodsTypeno,BeginDate,EndDate,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fML=SUM(fML),
fMoney_Cost=SUM(fMoney_Cost),特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),
fmoney_left=SUM(fmoney_left),期初库存=SUM(期初库存),期末库存=SUM(期末库存),当月销售数量=SUM(当月销售数量),当月销售金额=SUM(当月销售金额),
当月特价销售数量=SUM(当月特价销售数量),当月特价销售金额=SUM(当月特价销售金额),当月正价销售数量=SUM(当月正价销售数量),当月正价销售金额=SUM(当月正价销售金额),
会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),来客数=SUM(来客数),当前库存,当前库存金额,最近销售日,可销天数 
,上月销售金额=CAST(null as money),上月销售数量=CAST(null as money),上月成本金额=CAST(null as money) 
into #temp_goodsKuCunGroupby from #temp_goodsKuCun
group by cGoodsNo,cGoodsTypeno,BeginDate,EndDate,当前库存,当前库存金额,最近销售日,可销天数 

 
 CREATE INDEX IX_temp_goodsKuCunGroupby  ON #temp_goodsKuCunGroupby(cGoodsNo)

insert into #temp_goodsKuCunGroupby(cGoodsNo,cGoodsTypeno,BeginDate,EndDate)
select a1.cGoodsNo,a1.cGoodsTypeno,@dDateBgn,@dDateEnd from t_Goods a1,(
select b.cGoodsNo,b.EndQty,b.Endmoney from #temp_goodsKuCunGroupby  a right join #temp_goodsKuCurQty b on a.cGoodsNo=b.cGoodsNo
where ISNULL(a.cGoodsNo,'')='') b1
where a1.cGoodsNo=b1.cGoodsNo

--print '10    '+dbo.getTimeStr(GETDATE())

 ---------获取上个月的正月销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cgoodsno varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fmoney_cost money)
declare @ddatebgn1 datetime
declare @lastBgn1 datetime
declare @lastEnd1 datetime
set @ddatebgn1=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
set @lastBgn1=DATEADD(MONTH,-1,@ddatebgn1)
set @lastEnd1=DATEADD(DAY,-1,@ddatebgn1) 

declare @day int
set @day=DATEDIFF (DAY,@lastBgn1,@lastEnd1)+1

--  print '13002    '+dbo.getTimeStr(GETDATE())

exec p_GetLastMonthSale_wei @lastBgn1,@lastEnd1,@cWHno,@cdbname

 -- print '13003    '+dbo.getTimeStr(GETDATE())

update a
set a.上月销售数量=b.xsQty,a.上月销售金额=b.xsMoney,上月成本金额=b.fmoney_cost
from #temp_goodsKuCunGroupby a ,#temp_GetLastMonthSale_wei b
where a.cGoodsNo=b.cgoodsno

 
 /*
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月销售数量,0)<>0 
then ISNULL(b.EndQty,0)*@day/ISNULL(a.上月销售数量,0) 
else case when ISNULL(a.上月销售数量,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end  end end 
from #temp_goodsKuCunGroupby a,#temp_goodsKuCurQty b
where a.cGoodsNo=b.cGoodsNo 
*/
 
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月成本金额,0)<>0 
then ISNULL(b.Endmoney,0)*@day/ISNULL(a.上月成本金额,0) 
else case when ISNULL(a.上月成本金额,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end  end end 
from #temp_goodsKuCunGroupby a left join #temp_goodsKuCurQty b
on a.cGoodsNo=b.cGoodsNo 



 --	print '11 '+dbo.gettimestr(getdate())
--------类别品项数
if (select OBJECT_ID('tempdb..#temp_wh_GoodsCount'))is not null  
drop table #temp_wh_GoodsCount
select b.cGoodsTypeno,cGoodsNoCount=COUNT(a.cGoodsNo)
into #temp_wh_GoodsCount
--from #temp_goodsKuCun a,t_Goods b
from #temp_goodsKuCunGroupby a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and b.cBarcode not like '%X%'
group by b.cGoodsTypeno

--------获取类别商品下负库存数。
if (select OBJECT_ID('tempdb..#temp_wh_FuGoodsCount'))is not null  
drop table #temp_wh_FuGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo)
into #temp_wh_FuGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where 当前库存<0
group by cGoodsTypeno


--------获取类别商品下负毛利数。
if (select OBJECT_ID('tempdb..#temp_wh_FumaoliGoodsCount'))is not null  
drop table #temp_wh_FumaoliGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo)
into #temp_wh_FumaoliGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where fML<0
group by cGoodsTypeno
-----------商品的最近销售日
if (select object_id('tempdb..#tmp_GoodsSale30'))is not null drop table #tmp_GoodsSale30
select a.cGoodsNo,dSaleDate=a.last_SaleDate into #tmp_GoodsSale30 from 
--t_GetGoods_InOut a,#temp_goodsKuCun b
t_GetGoods_InOut a,#temp_goodsKuCunGroupby b
with (nolock) 
where a.cgoodsno=b.cgoodsno

update a
set a.最近销售日=b.dSaleDate
--from #temp_goodsKuCun a,#tmp_GoodsSale30 b
from #temp_goodsKuCunGroupby a,#tmp_GoodsSale30 b
where a.cGoodsNo=b.cGoodsno

--------获取类别商品下滞销数。 15天以上未销售。。。 
if (select OBJECT_ID('tempdb..#temp_wh_ZhixiaoGoodsCount'))is not null  
drop table #temp_wh_ZhixiaoGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo),ZxMoney=SUM(当前库存金额)
into #temp_wh_ZhixiaoGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where 当前库存>0 and isnull(最近销售日,'2010-01-01')>=@dDateBgn-15
group by cGoodsTypeno

----应销未订货:库存为0  且超过7天未销售
if (select OBJECT_ID('tempdb..#temp_wh_YInxiaoGoodsCount'))is not null  
drop table #temp_wh_YInxiaoGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo)
into #temp_wh_YInxiaoGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where 当前库存=0 and isnull(最近销售日,'2010-01-01')<@dDateBgn-7
group by cGoodsTypeno

----高库存：可销天数>20
if (select OBJECT_ID('tempdb..#temp_wh_GaokuGoodsCount'))is not null  
drop table #temp_wh_GaokuGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo),GaokuMoney=SUM(当前库存金额)
into #temp_wh_GaokuGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where 可销天数>20 and 当前库存金额>500
group by cGoodsTypeno

----畅销缺货：可销天数>=0 and 可销天数<=5
if (select OBJECT_ID('tempdb..#temp_wh_ChangXiaoGoodsCount'))is not null  
drop table #temp_wh_ChangXiaoGoodsCount
select cGoodsTypeno,cGoodsNoCount=COUNT(cGoodsNo)
into #temp_wh_ChangXiaoGoodsCount
--from #temp_goodsKuCun
from #temp_goodsKuCunGroupby
where 可销天数 between 0 and 5
group by cGoodsTypeno

 --	print '12   '+dbo.gettimestr(getdate())
 

if (select OBJECT_ID('tempdb..#temp_wh_SumUnionGoods'))is not null  
drop table #temp_wh_SumUnionGoods
select BeginDate,EndDate,b.cGoodsTypeno,b.cGoodsTypename,fQty_left=SUM(期末库存),
fprice_left=case when ISNULL(sum(期末库存),0)<>0 then sum(fmoney_left)/sum(期末库存) else 0 end,fmoney_left=SUM(fmoney_left),
期初库存=SUM(期初库存),期末库存=SUM(期末库存),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost), 
 xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),
特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),	 
会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),来客数=SUM(来客数),

--可销天数=SUM(可销天数),
可销天数=case when isnull(SUM(上月成本金额),0)=0 
then 
    case when isnull(SUM(当前库存金额),0)=0 then 0 
    else 99999 end
else SUM(当前库存金额)*@day/SUM(上月成本金额) end,

当前库存=SUM(当前库存),当前库存金额=SUM(当前库存金额),品项数=CAST(null as money),
负库存数=CAST(null as money),负毛利数=CAST(null as money),滞销数=CAST(null as money),滞销金额=CAST(null as money)
,应销未订货=CAST(null as money),高库存数=CAST(null as money),高库存金额=CAST(null as money),畅销缺货=CAST(null as money)
into #temp_wh_SumUnionGoods
from #temp_goodsKuCunGroupby a,t_GoodsType b
where a.cGoodsTypeno=b.cGoodsTypeno
group by BeginDate,EndDate,b.cGoodsTypeno,b.cGoodsTypename

 

update  a
set a.品项数=b.cGoodsNoCount
from #temp_wh_SumUnionGoods a,#temp_wh_GoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno

update  a
set a.负库存数=b.cGoodsNoCount
from #temp_wh_SumUnionGoods a,#temp_wh_FuGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno

update  a
set a.负毛利数=b.cGoodsNoCount
from #temp_wh_SumUnionGoods a,#temp_wh_FumaoliGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno

update  a
set a.滞销数=b.cGoodsNoCount,a.滞销金额=b.ZxMoney
from #temp_wh_SumUnionGoods a,#temp_wh_ZhixiaoGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno

update  a
set a.应销未订货=b.cGoodsNoCount
from #temp_wh_SumUnionGoods a,#temp_wh_YInxiaoGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno


update  a
set a.高库存数=b.cGoodsNoCount,a.高库存金额=b.GaokuMoney
from #temp_wh_SumUnionGoods a,#temp_wh_GaokuGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno

update  a
set a.畅销缺货=b.cGoodsNoCount
from #temp_wh_SumUnionGoods a,#temp_wh_ChangXiaoGoodsCount b
where a.cGoodsTypeno=b.cGoodsTypeno


 --	print '13   '+dbo.gettimestr(getdate())

--------------会员为整个月的。。 -----------------
insert into #temp_WhFromendVIP(cGoodsNo,会员来客数,会员销售数量,会员销售金额,来客数)
select a.cGoodsNo,a.会员来客数,a.会员销售数量,a.会员销售金额,a.来客数
from #temp_WhKouDianVIP a left join #temp_WhFromendVIP b
on a.cGoodsNo=b.cGoodsNo
where ISNULL(b.cGoodsNo,'')=''

    
if (select OBJECT_ID('tempdb..#temp_Type_WhFromendVIP'))is not null  
drop table #temp_Type_WhFromendVIP
select b.cGoodstypeno,会员销售数量=SUM(a.会员销售数量),会员销售金额=SUM(a.会员销售金额),会员来客数=SUM(a.会员来客数),来客数=SUM(a.来客数)	 
into #temp_Type_WhFromendVIP
from #temp_WhFromendVIP a,t_Goods b
where a.cgoodsno=b.cgoodsno
group by b.cGoodstypeno
 

update a set a.会员销售数量=b.会员销售数量,a.会员销售金额=b.会员销售金额,a.会员来客数=b.会员来客数,a.来客数=b.来客数
from #temp_wh_SumUnionGoods  a,#temp_Type_WhFromendVIP b
where  a.cGoodsTypeno=b.cGoodstypeno


 --	print '14   '+dbo.gettimestr(getdate())
------------获取当前天的销售计划
if (select OBJECT_ID('tempdb..#temp_Type_GoodsTypePlan'))is not null  
drop table #temp_Type_GoodsTypePlan
create table #temp_Type_GoodsTypePlan(cGoodsTypeno varchar(32),[销售计划] [money] NULL,[毛利计划] [money] NULL)
insert into #temp_Type_GoodsTypePlan(cGoodsTypeno,[销售计划],[毛利计划])
exec('select  a.cGoodsTypeno,[销售计划],[毛利计划] 
from '+@cdbname+'.dbo.t_GoodsTypePlan a,#temp_GoodsTypeNo b
 with (nolock) 
where a.[dDate]='''+@strBgn+'''  and a.cGoodsTypeno=b.cGoodsTypeno 
')
declare @ZMaoli money
set @ZMaoli=(select SUM(fML) from #temp_wh_SumUnionGoods)

if (select OBJECT_ID('tempdb..#temp_Type_Goods'))is not null  
drop table #temp_Type_Goods
select a.BeginDate,a.EndDate,a.cGoodsTypeno,a.cGoodsTypename,a.fQty_left,a.fprice_left,a.fmoney_left,
a.期初库存,a.期末库存,a.fML,a.fMoney_Cost, 
a.xsQty,a.xsMoney,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额, 
a.会员销售数量,a.会员销售金额,a.会员来客数,a.来客数,b.[销售计划],b.[毛利计划],a.品项数,a.当前库存,a.当前库存金额,
毛利率=case when isnull(a.xsMoney,0)<>0 then (a.fML/a.xsMoney)*100 else 0 end,
占店比=case when isnull(@ZMaoli,0)<>0 then (a.fML/@ZMaoli)*100 else 0 end,
销售达成=case when ISNULL(b.[销售计划],0)<>0 then (a.xsMoney/b.[销售计划])*100 else 100 end,
毛利达成=case when ISNULL(b.[毛利计划],0)<>0 then (a.fML/b.[毛利计划])*100 else 100 end,
正常销售占比=case when isnull(a.xsMoney,0)<>0 then (ISNULL(a.正价销售金额,0)/isnull(a.xsMoney,0))*100 else 0 end,
特价销售占比=case when isnull(a.xsMoney,0)<>0 then (ISNULL(a.特价销售金额,0)/isnull(a.xsMoney,0))*100 else 0 end,
负库存数,负毛利数,滞销数,滞销金额,应销未订货,高库存数,高库存金额,畅销缺货,
客单价=case when isnull(a.来客数,0)<>0 then a.xsMoney/a.来客数 end,可销天数
into #temp_Type_Goods
from  #temp_wh_SumUnionGoods a left join #temp_Type_GoodsTypePlan b
on a.cGoodsTypeno=b.cGoodsTypeno
 
 
  --	print '15   '+dbo.gettimestr(getdate())

select BeginDate,EndDate,a.cGoodsTypeno,a.cGoodsTypename,fQty_left,fprice_left,fmoney_left,
 期初库存,期末库存,fml,fMoney_Cost,xsQty,xsMoney,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
 会员销售数量,会员销售金额,会员来客数,来客数,[销售计划],[毛利计划],品项数,当前库存,当前库存金额,
 毛利率,占店比,销售达成,毛利达成,正常销售占比,特价销售占比,
 负库存数,负毛利数,滞销数,滞销金额,应销未订货,高库存数,高库存金额,畅销缺货,
 客单价,可销天数,i=0
 from #temp_Type_Goods a,#temp_GoodsTypeNo b
 where a.cGoodsTypeno=b.cGoodsTypeno
union all
select BeginDate=null,EndDate=null,cGoodsTypeno='ZZZZZZZ',cGoodsTypename='合计:',sum(fQty_left),fprice_left=null,sum(fmoney_left),
 sum(期初库存),sum(期末库存),sum(fml),sum(fMoney_Cost),sum(xsQty),sum(xsMoney),sum(特价销售数量),sum(特价销售金额),sum(正价销售数量),sum(正价销售金额),
 sum(会员销售数量),sum(会员销售金额),sum(会员来客数),sum(来客数),sum([销售计划]),sum([毛利计划]),sum(品项数),sum(当前库存),sum(当前库存金额),
 毛利率=case when isnull(sum(xsMoney),0)<>0 then (sum(fML)/sum(xsMoney))*100 else 0 end,
 占店比=case when isnull(@ZMaoli,0)<>0 then (sum(fML)/@ZMaoli)*100 else 0 end,
 销售达成=case when ISNULL(sum([销售计划]),0)<>0 then (sum(xsMoney)/sum([销售计划]))*100 else 100 end,
 毛利达成=case when ISNULL(sum([毛利计划]),0)<>0 then (sum(fML)/sum([毛利计划]))*100 else 100 end,
 正常销售占比=case when isnull(sum(xsMoney),0)<>0 then (ISNULL(sum(正价销售金额),0)/isnull(sum(xsMoney),0))*100 else 0 end,
 特价销售占比=case when isnull(sum(xsMoney),0)<>0 then (ISNULL(sum(特价销售金额),0)/isnull(sum(xsMoney),0))*100 else 0 end,
 sum(负库存数),sum(负毛利数),sum(滞销数),sum(滞销金额),sum(应销未订货),sum(高库存数),sum(高库存金额),sum(畅销缺货),
 客单价=null,sum(可销天数),i=1
 from #temp_Type_Goods a,#temp_GoodsTypeNo b
 where a.cGoodsTypeno=b.cGoodsTypeno
order by i,a.cGoodsTypeno

/*获取时间段的入库记录 日期以单据日期为判断。*/

/*删除临时表*/
if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
GO
