/*
先进先出算库存
*/

CREATE proc [dbo].[p_FIFOWhFormOutNum_chen]
@cGoodsNo varchar(50),    --商品名称
@iAttribute int,          --0入库；1出库；2返厂；3顾客退货入库；4调拨；5报损；6报益；7差价单
@cSheetNo varchar(32),    --单据号
@iLine int,               --商品在单据中的行号
@cWhNo varchar(32),
@QtyOut int,              --出库数量 
@Return int output        --返回1：库存不足2:内部错误3:数量为0
as
if @QtyOut<=0 
begin
  set @Return=3 
  return
end
set @Return=0 
--先得出该货物的库存是否够 
if (select object_id('tempdb..#tmpWhForm'))is not null
begin
  drop table #tmpWhForm
end
if (select object_id('tempdb..#tmpSubQty'))is not null
begin
  drop table #tmpSubQty
end

select cGoodsNo,iSerNo,fPrice_In=isnull(fPrice_In,0),fQty_in=isnull(fQty_in,0),fQty_Out=isnull(fQty_Out,0),cWhNo
into #tmpWhForm
from t_wh_form
where cGoodsNo=@cGoodsNo and isnull(fQty_in,0)!=isnull(fQty_Out,0)
and isnull(cWhNo,'')=@cWhNo
order by iSerNo

declare @spare float --剩余库存 
select @spare=sum(fQty_in)-sum(fQty_Out) 
from #tmpWhForm 
where cGoodsNo=@cGoodsNo 
and fQty_in!=fQty_Out
group by cGoodsNo

if(@spare>=@QtyOut) 
begin 
   begin try
     begin tran
		--根据入库日期采用先进先出原则对货物的库存进行处理 
		update a 
		set a.fQty_Out= 
		case when 
			( select @QtyOut-isnull(sum(fQty_in),0)+isnull(sum(fQty_Out),0) 
			  from #tmpWhForm 
			  where cGoodsNo=@cGoodsNo and iSerNo <=a.iSerNo and fQty_in!=fQty_Out
			)>=0 
		then a.fQty_in 
		else 
			case when 
				(select @QtyOut-isnull(sum(fQty_in),0)+isnull(sum(fQty_Out),0) 
				 from #tmpWhForm 
				 where cGoodsNo=@cGoodsNo and iSerNo <a.iSerNo and fQty_in!=fQty_Out
				)<0 then 0 
			else 
			   (select @QtyOut-isnull(sum(fQty_in),0)+isnull(sum(fQty_Out),0)+a.fQty_Out 
				from #tmpWhForm 
				where cGoodsNo=@cGoodsNo and iSerNo <a.iSerNo and fQty_in!=fQty_Out) 
			end 
		end
		from #tmpWhForm a 
		where a.cGoodsNo=@cGoodsNo and a.fQty_in!=a.fQty_Out

		--更新数据
		select a.cGoodsNo,a.iSerNo,a.fPrice_In,SubQty=b.fQty_Out-a.fQty_Out,a.fQty_Left
		into #tmpSubQty
		from t_wh_form a,#tmpWhForm b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cWhNo=b.cWhNo
	   
		update a
		set a.fPrice_Out=a.fPrice_In,a.fQty_Out=b.fQty_Out,a.fMoney_Out=a.fPrice_In*b.fQty_Out,
		a.fPrice_Left=a.fPrice_In,a.fQty_Left=a.fQty_In-b.fQty_Out,a.fMoney_Left=(a.fQty_In-b.fQty_Out)*a.fPrice_In
		from t_wh_form a,#tmpWhForm b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cWhNo=b.cWhNo

--		update a set a.iSerno=b.iMyIdentity  --t_WH_Form中，批次调整后iSerno有可能改变，而iMyIdentity不变
--		from #tmpWhForm a,t_WH_Form b
--		where  a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno


		insert into t_Cost_distribute
		(
		   cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,
		   iAttribute,cSheetNo,iLineNo,fQty
		)
		select a.cGoodsNo,a.iSerno,a.fPrice_In,b.SubQty,a.fPrice_In*b.SubQty,  
		@iAttribute,@cSheetNo,@iLine,b.fQty_Left
		from #tmpWhForm a,#tmpSubQty b
		where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo
		and isnull(b.SubQty,0)!=0

  commit tran
end try
begin catch
 rollback
 set @Return=2  
 return 
end catch

end 
else
begin 
    --raiserror('库存不足',16,1) 
    set @Return=1   
    return 
end


--update t_wh_form set fPrice_Out=0,fQty_out=0,fMoney_out=0,fPrice_left=0,fQty_left=0,fMoney_left=0
--select * from t_wh_form where cGoodsNo='10101'
/*
declare @i int
exec p_FIFOWhFormOutNum_chen '10101',1,'Out20090-000002',1,'04',13,@i output
select @i

declare @i int
exec p_FILOWhFormInNum_chen '10101',2,'iN20090-000002',1,'04',1,@i output
select @i


select * from t_Cost_distribute
delete t_Cost_distribute
*/

GO
