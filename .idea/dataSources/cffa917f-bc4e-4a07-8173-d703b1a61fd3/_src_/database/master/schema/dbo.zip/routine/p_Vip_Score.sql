
CREATE procedure [dbo].[p_Vip_Score]
 @dDate1 datetime,--消费开始日期
 @dDate2 datetime,--消费截止日期
 @iScore_ref int,  ---返分标准
 @fMoney_ref money,---返钱标准
 @dDate_limit1 datetime,--生效日期
 @dDate_limit2 datetime,--失效日期
 @fMoneyLimit_POS money,--超市每单消费指标
 @fMoneyLimit_MP  money,--百货每单消费指标
 @fMoney_PosUsedPer money,--超市每单使用额度
 @fMoney_MPUsedPer money,--百货每单使用额度
 @iOnece bit,---是否是一次性补助
 @bForEver bit----是否永久生效，永久生效则直接叠加到t_vip.fMoney_sum,t_vip.fMoney_left
as
begin
/*
set @dDate1='2011-05-27'
set @dDate2='2011-08-27'
set @iScore_ref=400
set @fMoney_ref=10.00
update t_vip set fmoney_sum=0.1,fMoney_used=0,fMoney_left=0.1
select  fCurValue,fCurValue_Pos from t_vip where fMoneyLimit_POS=166
*/
	if(select object_id('tempdb..#temp_vip_Score_limit')) is not null
	begin
		drop table 	#temp_vip_Score_limit
	end 

	if(select object_id('tempdb..#temp_SaleSheetDetail_limit')) is not null
	begin
		drop table 	#temp_SaleSheetDetail_limit
	end 

	select distinct cVipNo,cSaleSheetno,fVipScore_cur
	into #temp_SaleSheetDetail_limit
	from dbo.t_SaleSheetDetail
	where dSaleDate between @dDate1 and @dDate2  and ltrim(ISNULL(cVipNo,''))<>'' and isnull(bSetMoneyUsed,0)=0
	
	select distinct cVipNo,fVipScore_Sum=sum(isnull(fVipScore_cur,0)),iCount=floor(sum(isnull(fVipScore_cur,0))/@iScore_ref),
	fMoney_ret=case when @iOnece=1 then @fMoney_ref else floor(sum(isnull(fVipScore_cur,0))/@iScore_ref)*@fMoney_ref end
	into #temp_vip_Score_limit
	from #temp_SaleSheetDetail_limit
	group by cVipNo having sum(isnull(fVipScore_cur,0))>@iScore_ref
  if @iScore_ref>0 
  begin
			if @bForEver=0 
			begin
				update a set a.fMoneyLimit_Init=ISNULL(a.fMoneyLimit_Init,0)+b.fMoney_ret,a.fMoneyLimit_Init_Left=ISNULL(a.fMoneyLimit_Init_Left,0)+b.fMoney_ret,
				a.dMoneyLimit1=@dDate_limit1 , a.dMoneyLimit2=@dDate_limit2,
				a.fMoneyLimit_POS=@fMoneyLimit_POS,a.fMoneyLimit_MP=@fMoneyLimit_MP,a.fMoney_PosUsedPer=@fMoney_PosUsedPer,a.fMoney_MpUsedPer=@fMoney_MPUsedPer
				from t_vip a,#temp_vip_Score_limit b
				where a.cVipno=b.cVipNo and 
				( @dDate_limit1 between   a.dMoneyLimit1 and  a.dMoneyLimit2 
				 or @dDate_limit2 between   a.dMoneyLimit1 and  a.dMoneyLimit2
				)
				update a set a.fMoneyLimit_Init=b.fMoney_ret,a.fMoneyLimit_Init_Left=b.fMoney_ret,
				a.dMoneyLimit1=@dDate_limit1 , a.dMoneyLimit2=@dDate_limit2,
				a.fMoneyLimit_POS=@fMoneyLimit_POS,a.fMoneyLimit_MP=@fMoneyLimit_MP,a.fMoney_PosUsedPer=@fMoney_PosUsedPer,a.fMoney_MpUsedPer=@fMoney_MPUsedPer
				from t_vip a,#temp_vip_Score_limit b
				where a.cVipno=b.cVipNo and 
				(a.dMoneyLimit1 < @dDate_limit1 and a.dMoneyLimit2<@dDate_limit1
				)   
				update a set a.bSetMoneyUsed=1
				from dbo.t_SaleSheetDetail a
				where a.dSaleDate between @dDate1 and @dDate2  

			end else
			begin
				update a set a.fMoney_sum=isnull(a.fMoney_sum,0)+b.fMoney_ret,
				a.fMoney_Left=isnull(a.fMoney_Left,0)+b.fMoney_ret
				from t_vip a,#temp_vip_Score_limit b
				where a.cVipno=b.cVipNo 
				update a set a.bSetMoneyUsed=1
				from dbo.t_SaleSheetDetail a
				where a.dSaleDate between @dDate1 and @dDate2  

			end
	end else 
	begin
				update a set a.fMoneyLimit_Init=@fMoney_ref,a.fMoneyLimit_Init_Left=@fMoney_ref,
				a.dMoneyLimit1=@dDate_limit1 , a.dMoneyLimit2=@dDate_limit2,
				a.fMoneyLimit_POS=@fMoneyLimit_POS,a.fMoneyLimit_MP=@fMoneyLimit_MP,
				a.fMoney_PosUsedPer=@fMoney_PosUsedPer,a.fMoney_MpUsedPer=@fMoney_MPUsedPer
				from t_vip a
	  
	end
end
GO
