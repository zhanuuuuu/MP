CREATE     procedure p_SetCheckWh_byZone
 @cShelfNo varchar(64),@dCheckDate datetime
/*
  将按货区盘点的本次盘点设置为当前生效盘点
*/
as
begin
-- drop table #t_ShelfGoods
  /*查询出本货架商品的相关信息*/
  select cShelfNo=a.cZoneNo,cShelfName=a.cZoneName,cShelfPart=' ',
         a.cGoodsNo,b.cGoodsName,b.cBarCode,b.cProductNo,b.cUnitedNo,b.fNormalPrice as fNormalPrice
  into #t_ShelfGoods
  from t_Zone_Goods a
       left Join t_Goods b on a.cGoodsNo=b.cGoodsNo
--  where a.cZoneNo=@cShelfNo
  where a.cZoneNo like @cShelfNo+'%' /*例如@cShelfno='1010',则要统计*/
 
  /*查询出所有存放有该货架商品的货架 主要针对一种商品放在多个货架的情况ShelfNo_associate*/
  select a.cShelfNo,a.cShelfName,a.cShelfPart,a.cGoodsNo,a.cGoodsName,a.cBarCode,
         b.cZoneNo as ShelfNo_associate,b.cZoneName as ShelfName_associate,a.fNormalPrice
  into #t_ShelfGoods_Market          
  From #t_ShelfGoods a
       left join t_Zone_Goods b on a.cGoodsNo=b.cGoodsNo



/*
  将通盘的本次盘点设置为当前生效盘点
  @cCheckRegion 卖场编号
  @bProductSerno 是否按照批次盘点
  dbo.wh_InWarehouseDetail   入库单
  dbo.wh_ExchangeDetail      兑奖单
  dbo.wh_LossWarehouseDetail 报损单
  dbo.wh_OutWarehouseDetail  出库单
  dbo.wh_RbdWarehouseDetail  返厂单
  dbo.wh_TfrWarehouseDetail  调拨单
  dbo.wh_EffusionWhDetail    溢出单 


  dbo.t_SaleSheetDetail          销售单

  dbo.wh_CheckWhDetail       盘点单

*/
/*               生成货架商品的关联信息                                           */
  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  into #t_Goods 
  from #t_ShelfGoods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo

/*                 销售单                     */ 
  select a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bChecked,b.dSaleDate
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      left join t_SaleSheetDetail b
        on a.cGoodsNo=b.cGoodsNo
 
  select cGoodsNo,qty=sum(isnull(fQuantity,0)),LastSettle=sum(isnull(fLastSettle,0))
  into #t_SaleSheetDetail0--计算以前没有经过盘点的销售数量
  from #t_SaleSheetDetail_shelf
  where bChecked<>1 and dSaleDate<=@dCheckDate
  group by cGoodsNo

  drop table #t_SaleSheetDetail_shelf

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #t_SaleSheetDetail    --所有商品的销售数量（含加工）
  from #t_SaleSheetDetail0 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #t_SaleSheetDetail0
  
/*                 盘点单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.cProductSerno,b.fQuantity,
         b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked,fLastSettle=b.fMoney,b.cSheetno
  into #wh_CheckWhDetail_shelf 
  from #t_goods a 
      left join wh_CheckWhDetail b
        on a.cGoodsNo=b.cGoodsNo
 
  select a.cSheetno as Sheetno,a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked as Checked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_CheckWhDetail0  --盘点单
  from #wh_CheckWhDetail_shelf a  
       left join wh_CheckWh b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_CheckWhDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_CheckWhDetail1
  from #wh_CheckWhDetail0 
  where Checked is not null and Checked=0  --Checked=0 上次盘点数量 checked=1过期盘点数量
                                           --checked is null 表示本次盘点数量
  group by cGoodsNo,cUnitedNo 

  drop table #wh_CheckWhDetail0

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_CheckWhDetail    --所有商品的盘点数量（含加工）
  from #wh_CheckWhDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_CheckWhDetail1  
  

/*                 入库单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_InWarehouseDetail_shelf 
  from #t_goods a 
      left join wh_InWarehouseDetail b
        on a.cGoodsNo=b.cGoodsNo

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fInPrice AS fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_InWarehouseDetail0  --入库单
  from #wh_InWarehouseDetail_shelf a  
       left join wh_InWarehouse b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_InWarehouseDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_InWarehouseDetail1  --入库单
  from #wh_InWarehouseDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo

  drop table #wh_InWarehouseDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_InWarehouseDetail    --所有商品的入库数量（含加工）
  from #wh_InWarehouseDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_InWarehouseDetail1  
  

/*                 溢出单                     */ 
--  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fMoney
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked

  into #wh_EffusionWhDetail_shelf 
  from #t_goods a 
      left join wh_EffusionWhDetail b
        on a.cGoodsNo=b.cGoodsNo

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_EffusionWhDetail0  --溢出单
  from #wh_EffusionWhDetail_shelf a  
       left join wh_EffusionWh b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_EffusionWhDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_EffusionWhDetail1  --溢出单
  from #wh_EffusionWhDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  drop table #wh_EffusionWhDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_EffusionWhDetail    --所有商品的溢出数量（含加工）
  from #wh_EffusionWhDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_EffusionWhDetail1  

/*                 出库单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_OutWarehouseDetail_shelf 
  from #t_goods a 
      left join wh_OutWarehouseDetail b
        on a.cGoodsNo=b.cGoodsNo

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_OutWarehouseDetail0  --出库单 
  from #wh_OutWarehouseDetail_shelf a  
       left join wh_OutWarehouse b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_OutWarehouseDetail_shelf


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_OutWarehouseDetail1  --出库单
  from #wh_OutWarehouseDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  drop table #wh_OutWarehouseDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_OutWarehouseDetail    --所有商品的出库数量（含加工）
  from #wh_OutWarehouseDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_OutWarehouseDetail1  


/*                 报损单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_LossWarehouseDetail_shelf 
  from #t_goods a 
      left join wh_LossWarehouseDetail b
        on a.cGoodsNo=b.cGoodsNo


  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_LossWarehouseDetail0 --报损单  
  from #wh_LossWarehouseDetail_shelf a  
       left join wh_LossWarehouse b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1 

  drop table #wh_LossWarehouseDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_LossWarehouseDetail1  --报损单
  from #wh_LossWarehouseDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  drop table #wh_LossWarehouseDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_LossWarehouseDetail    --所有商品的报损数量（含加工）
  from #wh_LossWarehouseDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_LossWarehouseDetail1  


/*                 返厂单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_RbdWarehouseDetail_shelf 
  from #t_goods a 
      left join wh_RbdWarehouseDetail b
        on a.cGoodsNo=b.cGoodsNo


  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_RbdWarehouseDetail0   --返厂单
  from #wh_RbdWarehouseDetail_shelf a  
       left join wh_RbdWarehouse b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_RbdWarehouseDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_RbdWarehouseDetail1  --返厂单
  from #wh_RbdWarehouseDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  drop table #wh_RbdWarehouseDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_RbdWarehouseDetail    --所有商品的返厂数量（含加工）
  from #wh_RbdWarehouseDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_RbdWarehouseDetail1  


/*                 调拨单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_TfrWarehouseDetail_shelf 
  from #t_goods a 
      left join wh_TfrWarehouseDetail b
        on a.cGoodsNo=b.cGoodsNo

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_TfrWarehouseDetail0  --调拨单
  from #wh_TfrWarehouseDetail_shelf a  
       left join wh_TfrWarehouse b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_TfrWarehouseDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_TfrWarehouseDetail1  --调拨单
  from #wh_TfrWarehouseDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 


  drop table #wh_TfrWarehouseDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_TfrWarehouseDetail    --所有商品的调拨数量（含加工）
  from #wh_TfrWarehouseDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_TfrWarehouseDetail1  


/*                 兑奖单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_ExchangeDetail_shelf 
  from #t_goods a 
      left join wh_ExchangeDetail b
        on a.cGoodsNo=b.cGoodsNo

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_ExchangeDetail0  --兑奖单
  from #wh_ExchangeDetail_shelf a  
       left join wh_Exchange b
            on  a.cSheetno =b.cSheetno   
  where a.bChecked<>1

  drop table #wh_ExchangeDetail_shelf


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_ExchangeDetail1  --兑奖单
  from #wh_ExchangeDetail0
  where bChecked<>1 and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  drop table #wh_ExchangeDetail0 

  select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
  into #wh_ExchangeDetail    --所有商品的调拨数量（含加工）
  from #wh_ExchangeDetail1 a
       left join #t_Goods b
            on a.cGoodsNo=b.cGoodsNo 
  drop table #wh_ExchangeDetail1

/*                  合并统计                     */ 
  select a.GoodsNo_Pdt as GoodsNo,a.GoodsName_Pdt as GoodsName,
       isnull(beginWh.Qty,0) as Qty_Begin,--上次盘点数量
       isnull(InWh.Qty,0) as Qty_InWh,--期间入库数量
       isnull(EffusionWh.Qty,0) as Qty_EffusionWh,--期间溢出数量
       isnull(OutWh.Qty,0) as Qty_OutWh,--期间出库数量
       isnull(TfrWh.Qty,0) as Qty_TfrWh,--期间调拨数量
       isnull(RbdWh.Qty,0) as Qty_RbdWh,--期间返厂数量
       isnull(Exchange.Qty,0) as Qty_Exchange,--期间兑奖数量
       isnull(LossWh.Qty,0) as Qty_LossWh,--期间报损数量
       isnull(Sale.Qty,0) as Qty_Sale,--期间销售数量
       (
        isnull(beginWh.Qty,0)+
        isnull(InWh.Qty,0)+
        isnull(EffusionWh.Qty,0)-
        isnull(OutWh.Qty,0)-
        isnull(TfrWh.Qty,0)-
        isnull(RbdWh.Qty,0)-
        isnull(Exchange.Qty,0)-
        isnull(LossWh.Qty,0)-
        isnull(Sale.Qty,0)
       ) as Qry_End--期末数量
  into #ResulWH
  from #t_Goods a
     left join #wh_CheckWhDetail BeginWh  on a.GoodsNo_Pdt=BeginWh.GoodsNo--上次盘点数量
     left join #wh_InWarehouseDetail InWh  on a.GoodsNo_Pdt=InWh.GoodsNo--期间入库数量
     left join #wh_EffusionWhDetail EffusionWh  on a.GoodsNo_Pdt=EffusionWh.GoodsNo--期间溢出数量
     left join #wh_OutWarehouseDetail OutWh  on a.GoodsNo_Pdt=OutWh.GoodsNo--期间出库数量
     left join #wh_TfrWarehouseDetail TfrWh  on a.GoodsNo_Pdt=TfrWh.GoodsNo--期间调拨数量
     left join #wh_RbdWarehouseDetail RbdWh  on a.GoodsNo_Pdt=RbdWh.GoodsNo--期间返厂数量

     left join #wh_ExchangeDetail Exchange  on a.GoodsNo_Pdt=Exchange.GoodsNo--期间兑奖数量
     left join #wh_LossWarehouseDetail LossWh  on a.GoodsNo_Pdt=LossWh.GoodsNo--期间报损数量
     left join #t_SaleSheetDetail Sale  on a.GoodsNo_Pdt=Sale.GoodsNo--期间销售数量
  drop table #wh_CheckWhDetail
  drop table #wh_InWarehouseDetail
  drop table #wh_EffusionWhDetail 
  drop table #wh_OutWarehouseDetail
  drop table #wh_TfrWarehouseDetail
  drop table #wh_RbdWarehouseDetail
  drop table #wh_ExchangeDetail
  drop table #wh_LossWarehouseDetail
  drop table #t_SaleSheetDetail
  drop table #t_Goods

  select GoodsNo,GoodsName,Qty_Begin,Qty_InWh,Qty_EffusionWh,Qty_OutWh,
         Qty_TfrWh,Qty_RbdWh,Qty_Exchange,Qty_LossWh,Qty_Sale,Qry_End
  from #ResulWH

  

end


GO
