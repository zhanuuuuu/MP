/*
eReport005
@date1='2012-04-01',@date2='2012-08-28',@sj1=9,@sj2=13,@No=''

*/
CREATE procedure [dbo].[eReport005]
@date1 datetime,
@date2 datetime,
@sj1 int,@sj2 int,@no varchar(32)
as
begin

--获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @sj1 int
--declare @sj2 int
--declare @No varchar(32)
--select @date1='2011-06-01',@date2='2011-06-07',@sj1=9,@sj2=13,@No=''

if(select object_id('tempdb..#tempLeaf')) is not null 	drop table 	#tempLeaf
select cGoodsTypeNo,cGoodsTypeName,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) into #tempLeaf
from t_GoodsType
update #tempLeaf set cpath=cParentNo+'.'+cGoodsTypeNo

declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #tempLeaf a left join #tempLeaf b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
end
select cGoodsTypeNo,cGoodsTypename,cPath,iLevel
into #tempGoodsTypePath
from #tempLeaf 
--where cpath like '%'+'.'+@No+'%'
/*以上形成类别列表*/
if (select object_id('tempdb..#TmpGoodsLevel'))is not null drop table #TmpGoodsLevel
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

if (select object_id('tempdb..#GoodsType'))is not null drop table #GoodsType
select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
--where cPath=cPath_leaf

--update a
--set bLeaf=1  
--from #TmpGoodsLevel a left join #GoodsType b
--on a.cGoodsTypeNo=b.cGoodsTypeNo
--where b.cGoodsTypeNo is not null
--update #TmpGoodsLevel
--set bLeaf=0
--where bLeaf is null

----////////////////<><<>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<
if(select OBJECT_ID('tempdb..#tmp_SaleSheetDetail')) is not null
drop table #tmp_SaleSheetDetail
create table #tmp_SaleSheetDetail
(dSaleDate datetime,cGoodsNo varchar(32),
fQuantity money,iSeed int ,fPrice money,fLastSettle money,bAuditing bit,cWHno varchar(32),cSaleTime varchar(32))
if (select OBJECT_ID('tempdb..#tmp_SaleSheetInfor'))is not null
drop table #tmp_SaleSheetInfor
create table #tmp_SaleSheetInfor(databasename varchar(32))

     insert into #tmp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName

				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #tmp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('				
					    insert into #tmp_SaleSheetDetail(dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime)
						select dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime 
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@date1+''' and '''+@date2+''' 
					  
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
				  
                insert into #tmp_SaleSheetDetail(dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime)
				select dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime
				from dbo.t_salesheetDetail 
			    where dSaleDate between @date1 and @date2
			    
		
----////////////////

if (select object_id('tempdb..#TmpGoodsBaseInfo'))is not null drop table #TmpGoodsBaseInfo
select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,fLastSettle=sum(a.fLastSettle),sj=datepart(hh,cSaleTime)
into #TmpGoodsBaseInfo
---  from t_SaleSheetDetail a left join t_goods b
from #tmp_SaleSheetDetail a left join t_Goods b
on a.cGoodsNo=b.cGoodsNo
where dSaleDate between @date1 and @date2
and datepart(hh,cSaleTime) between @sj1 and @sj2
group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,datepart(hh,cSaleTime)

	  
if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null
	  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=1
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select a.dSaleDate,b.BaseGoodsTypeNo,cGoodsTypeName=null,fLastSettle=SUM(a.fLastSettle),a.sj
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo
	group by a.dSaleDate,b.BaseGoodsTypeNo,a.sj
	order by a.dSaleDate,b.BaseGoodsTypeNo,a.sj

if (select object_id('tempdb..#last'))is not null drop table #last 
if (select object_id('tempdb..#last1'))is not null drop table #last1 
select a.dSaleDate,a.BaseGoodsTypeNo,b.cGoodsTypename,a.fLastSettle,合计=CAST(null as Money),a.sj
into #last 
from #tmpGoods_byLevel a left join t_GoodsType b 
on a.BaseGoodsTypeNo=b.cGoodsTypeno

select 时间段=convert(varchar(2),@sj1)+'点至'+convert(varchar(2),@sj2+1)+'点',类别NO=BaseGoodsTypeNo,类别名称=cGoodsTypename,
销售金额=sum(fLastSettle),日期=convert(char(10),dSaleDate,120) 
into #last1
from #last 
group by dSaleDate,BaseGoodsTypeNo,cGoodsTypename
order by BaseGoodsTypeNo,dSaleDate

select * from #last1
union all
select '合计:',类别NO,类别名称,SUM(isnull(销售金额,0)),null  from #last1  group by 类别NO,类别名称
union all
select '总计:',null,null,SUM(isnull(销售金额,0)),null  from #last1
order by 类别NO,日期
--declare @date varchar(32)
--declare @TypeNo varchar(32)
--declare @money money
--declare @money1 money
--declare @sj int
--set @money=0
--set @sj=9
--declare c cursor for
--select distinct dSaleDate,BaseGoodsTypeNo from #last

--open c
--fetch next from c
--into @date,@TypeNo
--while @@Fetch_Status=0
--begin
--    while @sj<=(select MAX(sj) from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo)
--	begin 
--		(select @money1=fLastSettle from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo and sj=@sj)
--		set @money =@money + @money1
--		update a set a.合计=@money from #last a 
--		where sj=@sj and dSaleDate=@date and BaseGoodsTypeNo=@TypeNo
--		set @sj=@sj+1 
--	end 
--	fetch next from c
--into @date,@TypeNo
--set @money=0
--set @sj=9
--end
--CLOSE c
--DEALLOCATE c

--select 日期=convert(char(10),dSaleDate,120),类别NO=BaseGoodsTypeNo,类别名称=cGoodsTypename,
--销售金额=fLastSettle,合计,时间=sj from #last
--order by dsaledate,basegoodstypeno,sj

end


GO
