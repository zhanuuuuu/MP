
/*
 储值卡601112
	p_MoneycardCust_qry20130219 '601188'
*/
CREATE procedure [dbo].[p_MoneycardCust_qry]
@cardno varchar(32)
as 
begin
/*
	if dbo.trim(@cardno)<>''
  begin
*/
/*
        if (select OBJECT_ID('tempdb..#temp_Jiesuan'))is not null drop table #temp_Jiesuan
        create table #temp_Jiesuan(sheetno varchar(64),jstime time,shishou money,zdriqi datetime,jstype varchar(32),fLastSettle money)
        
        if (select OBJECT_ID('tempdb..#temp_salesheetdetail'))is not null drop table #temp_salesheetdetail
        create table #temp_salesheetdetail(dSaleDate datetime,cSaleSheetno varchar(32),cGoodsNo varchar(32),cGoodsName varchar(64),
        cBarcode varchar(32),fQuantity money,fPrice money,fLastSettle money,jstime time,cVipNo varchar(32))
         insert into #temp_salesheetdetail(dSaleDate,cSaleSheetno,cGoodsNo,cGoodsName,cBarcode,fQuantity,fPrice,fLastSettle,jstime,cVipNo)
         */
-----------------

		select  a.sheetno,jstime=max(a.jstime),
		fLastSettle=isnull((select sum(shishou) from  dbo.jiesuan where sheetno=a.sheetno),0),
		zdriqi=max(a.zdriqi)
		into #tempJiesuan_POS
		from  dbo.jiesuan a
		where  a.jstype like '储值卡%' and substring(a.jstype,len('储值卡')+1,32)=@cardno
		group by a.sheetno
		
		/*
		exec p_MoneycardCustt_Ref @cardno
		
		select  a.sheetno,jstime=max(a.jstime),
		fLastSettle=isnull((select sum(shishou) from #temp_Jiesuan where sheetno=a.sheetno),0),
		zdriqi=max(a.zdriqi)
		into #tempJiesuan_POS
		from #temp_Jiesuan a
		where  a.jstype like '储值卡%' and substring(a.jstype,len('储值卡')+1,32)=@cardno
		group by a.sheetno
*/

		select a.sheetno,jstime=max(a.jstime),
		fLastSettle=isnull((select sum(shishou) from  dbo.jiesuan where sheetno=a.sheetno),0),zdriqi=max(a.zdriqi)
		into #tempJiesuan_MP
		from supermarket.dbo.jiesuan a
		where a.jstype like '储值卡%' and substring(a.jstype,len('储值卡')+1,32)=@cardno
		group by a.sheetno
		
 -------------------

		select MoneycardNo=@cardno,a.dSaleDate,a.cSaleSheetno,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.fQuantity,a.fPrice,
		a.fLastSettle,cSaleTime=b.jstime,a.cVipNo,cMarket='超市'
		into #tempQryResult
		from
		t_salesheetdetail a ,#tempJiesuan_POS b
		where  a.dSaleDate=b.zdriqi and  a.cSaleSheetno=b.sheetno
 /*
        select MoneycardNo=@cardno,a.dSaleDate,a.cSaleSheetno,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.fQuantity,a.fPrice,
		a.fLastSettle,cSaleTime=b.jstime,a.cVipNo,cMarket='超市'
		into #tempQryResult
		from #temp_salesheetdetail a,#tempJiesuan_POS b
		where  a.dSaleDate=b.zdriqi and  a.cSaleSheetno=b.sheetno
		*/
		union all

		select MoneycardNo=@cardno,dSaleDate=a.lsriqi,cSaleSheetno=a.lsdno,cGoodsNo=a.spno,
		cGoodsName=a.mingcheng,cBarCode=a.tiaoma,fQuantity=a.shuliang,fPrice=a.danjia,
		fLastSettle=a.jine,cSaleTime=b.jstime,cVipNo=a.vipno,cMarket='商场'
		from
			(select f.lsriqi,f.lsdno,f.spno,f.mingcheng,f.tiaoma,f.shuliang,f.danjia,
			f.jine,f.lstime,g.vipno
			from
			supermarket.dbo.lsdsp f,supermarket.dbo.lsd g 
			where  substring(f.lsdno,1,14) in (select sheetno from #tempJiesuan_MP) and f.lsdno=g.lsdno 
			) a,#tempJiesuan_MP b
		where  a.lsriqi=b.zdriqi and substring(a.lsdno,1,14)=b.sheetno --a.lsdno=b.sheetno

		select MoneycardNo,dSaleDate,cSaleTime,cSaleSheetno,cGoodsNo,cGoodsName,cBarCode,fQuantity,fPrice,
		fLastSettle,cVipNo,cMarket
		from #tempQryResult
		union all
		select MoneycardNo='小计',dSaleDate=zdriqi,cSaleTime=jstime,cSaleSheetno=sheetno,cGoodsNo='ZZZZZZ',
		cGoodsName=null,cBarCode=null,fQuantity=null,fPrice=null,fLastSettle,cVipNo=null,cMarket='超市'
      from #tempJiesuan_POS
		union all
		select MoneycardNo='小计',dSaleDate=zdriqi,cSaleTime=jstime,cSaleSheetno=sheetno,cGoodsNo='ZZZZZZ',
		cGoodsName=null,cBarCode=null,fQuantity=null,fPrice=null,fLastSettle,cVipNo=null,cMarket='商场'
    from #tempJiesuan_MP
		order by MoneycardNo,cSaleTime,cSaleSheetno
/*
	end else
	begin
		select b.MoneycardNo,a.dSaleDate,a.cSaleSheetno,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.fQuantity,a.fPrice,
		a.fLastSettle,a.cSaleTime,a.cVipNo,cMarket='超市'
		from
		t_salesheetdetail a ,
		(
		select sheetno,MoneycardNo=substring(jstype,len('储值卡')+1,32),jstype,zdriqi
		from posmanagement.dbo.jiesuan
		where jstype like '储值卡%' 
		) b
		where  a.dSaleDate=b.zdriqi and  a.cSaleSheetno=b.sheetno

		union all
		select b.MoneycardNo,dSaleDate=a.lsriqi,cSaleSheetno=a.lsdno,cGoodsNo=a.spno,
		cGoodsName=a.mingcheng,cBarCode=a.tiaoma,fQuantity=a.shuliang,fPrice=a.danjia,
		fLastSettle=a.jine,cSaleTime=a.lstime,cVipNo=a.vipno,cMarket='超市'
		from
			(select f.lsriqi,f.lsdno,f.spno,f.mingcheng,f.tiaoma,f.shuliang,f.danjia,
			f.jine,f.lstime,g.vipno
			from
			supermarket.dbo.lsdsp f,supermarket.dbo.lsd g where f.lsdno=g.lsdno 
			) a,
			(
			select sheetno,MoneycardNo=substring(jstype,len('储值卡')+1,32),jstype,zdriqi
			from supermarket.dbo.jiesuan
			where jstype like '储值卡%'  
			) b
		where  a.lsriqi=b.zdriqi and  a.lsdno=b.sheetno
	end
*/

end

--select * from #tempMoneycard
GO
