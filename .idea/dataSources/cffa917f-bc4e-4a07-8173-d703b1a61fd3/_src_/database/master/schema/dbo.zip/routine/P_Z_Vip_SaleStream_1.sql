
/*
P_Z_Vip_SaleStream_1 '1001','2012-06-01','2012-10-10'
*/

CREATE    procedure [dbo].[P_Z_Vip_SaleStream_1]
 @cVipNo varchar(32),
 @beginDate datetime,
 @endDate datetime
as
begin
if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

    if (select OBJECT_ID('tempdb..#temp_SaleSheetDetail'))is not null drop table #temp_SaleSheetDetail
    create table #temp_SaleSheetDetail(cSaleSheetno varchar(64),dSaleDate datetime,fVipScore money,cOperatorno varchar(32),
         cOperatorName varchar(64),cGoodsNo varchar(32),cGoodsName varchar(64),cBarCode varchar(32),
              fQuantity money,fLastSettle money,cVipNo varchar(32))

			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@beginDate ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@endDate) b
			where a.DataBaseName=b.DataBaseName
			
	
				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
          insert into #temp_SaleSheetDetail(cSaleSheetno,dSaleDate,fVipScore,cOperatorno,
         cOperatorName,cGoodsNo,cGoodsName,cBarCode,fQuantity,fLastSettle,cVipNo)
		select cSaleSheetno,dSaleDate,fVipScore,cOperatorno,
         cOperatorName,cGoodsNo,cGoodsName,cBarCode,fQuantity,fLastSettle,cVipNo
	from '+@InfoName1+'.dbo.t_SaleSheetDetail
	where dSaleDate between '''+@beginDate+''' and  '''+@endDate+''' and cVipNo='''+@cVipNo+''' 
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
	
		  insert into #temp_SaleSheetDetail(cSaleSheetno,dSaleDate,fVipScore,cOperatorno,
         cOperatorName,cGoodsNo,cGoodsName,cBarCode,fQuantity,fLastSettle,cVipNo)
		select cSaleSheetno,dSaleDate,fVipScore,cOperatorno,
         cOperatorName,cGoodsNo,cGoodsName,cBarCode,fQuantity,fLastSettle,cVipNo
	from t_SaleSheetDetail
	 where dSaleDate  between @beginDate and @endDate  and cVipNo=@cVipNo 
	 


    select t.cSaleSheetno,t.dSaleDate,t.fVipScore,t.cOperatorno,
               t.cOperatorName,t.cGoodsNo,t.cGoodsName,t.cBarCode,
               t.fQuantity,t.fLastSettle,g.cUnit,g.cSpec
  --from t_SaleSheetDetail t , t_Goods g
  from #temp_SaleSheetDetail t , t_Goods g
  where t.cVipNo is not null 
  and t.dSaleDate between @beginDate and @endDate and t.cGoodsNo=g.cGoodsNo
  and   t.cVipNo=@cVipNo 
	               
             
end

GO
