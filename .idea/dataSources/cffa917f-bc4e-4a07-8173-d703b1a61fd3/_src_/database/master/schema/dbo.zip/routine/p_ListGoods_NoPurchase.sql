/*
 select 
cGoodsNo,cGoodsName,cBarcode,cGoodsTypeName,cUnit,cSpec into #t_goods_selected
 from t_Goods
exec p_ListGoods_NoPurchase '2012-04-21','2012-05-21'
*/
CREATE  procedure [dbo].[p_ListGoods_NoPurchase]
@cStoreNo varchar(32),
@date1 datetime,
@date2 datetime
as
begin

        if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	 create table #temp_salesheetDetail(cGoodsNo varchar(32))
   
    if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor


 if (select OBJECT_ID('tempdb..#tempGoodsPurchased'))is not null drop table #tempGoodsPurchased
 create table #tempGoodsPurchased(cGoodsNo varchar(32))
 
	insert into #temp_SaleSheetInfor(databasename)
	        select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName
 
	      declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
						insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fQuantity,fLastSettle,bAuditing,cWHno)
						select  distinct cGoodsNo 
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@date1+''' and '''+@date2+'''
						and cStoreNo='''+@cStoreNo+'''  and fQuantity>0
					
					  
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
				  
			insert into #temp_salesheetDetail(cGoodsNo)
			select  distinct cGoodsNo 
			from dbo.t_salesheetDetail 
			where dSaleDate between @date1 and @date2
			and cStoreNo=@cStoreNo and fQuantity>0
 
 
	
	select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.fVipPrice,a.fCKPrice,
	a.fVipScore,a.cGoodsTypeno,a.cGoodsTypename,a.bDeled
	into #tempGoods
	from t_Goods a right join #t_Goods_selected b 
	on a.cGoodsNo=b.cGoodsNo
	where a.cGoodsNo is not null

	select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.fVipPrice,a.fCKPrice,
	a.fVipScore,a.cGoodsTypeno,a.cGoodsTypename
	from #tempGoods a left join #temp_salesheetDetail b
	on a.cGoodsNo=b.cGoodsNo
	where (a.bDeled is null or a.bDeled=0) and b.cGoodsNo is null
 
end

GO
