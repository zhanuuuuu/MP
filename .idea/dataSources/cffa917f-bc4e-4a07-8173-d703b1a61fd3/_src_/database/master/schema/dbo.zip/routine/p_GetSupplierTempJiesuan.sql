/*
	if(select object_id('tempdb..#temp_Goods')) is not null
	begin
		drop table 	#temp_Goods
	end 	
	select cGoodsNo into #temp_Goods from t_Goods
	where csupno='2001' --and cGoodsNo in ('415531','415537')
	 
	declare @return int
	exec p_SumSupplier_sales_Account_华联_log_wei '2001','JS20141001-0008','2014-08-1','2014-08-24',@return
	select @return

	if(select object_id('tempdb..#temp_Goods')) is not null
	begin
		drop table 	#temp_Goods
	end 	
	select cGoodsNo into #temp_Goods from t_Goods
	where csupno='1002' --and cGoodsNo in ('415531','415537')
	
declare @return int
exec p_GetSupplierTempJiesuan '2015-04-01','2015-04-30','1002',''
 
*/

CREATE  procedure [dbo].[p_GetSupplierTempJiesuan]
@dDate1 datetime,
@dDate2 datetime, 
@supNo varchar(64),
@cWHno varchar(32)
--@return int output
as
begin

/*获取商品信息*/
if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select distinct cGoodsNo into #temp_Goods 
from  t_Goods b
where  cSupNo=@supNo

   declare @dDateBgn datetime
   declare @dDateEnd datetime
   set @dDateBgn=@dDate1
   set @dDateEnd=@dDate2
   declare @jiesuanNo varchar(64)
   set @jiesuanNo=(select sheetno=dbo.f_GenJiesuanNo(CAST(YEAR(@dDate2) as varchar(16)),@supNo))

   declare @maxWhdDate datetime
  
  declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@cWhno=cWhNo from dbo.t_WareHouse  where isnull(bMainSale,0)=1

if(select object_id('tempdb..#temp_WhFrombgn')) is not null drop table #temp_WhFrombgn

CREATE TABLE #temp_WhFrombgn   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money,差价数量 money, Pos客退数量1 money,
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,扣率金额 money,当日销售 money,特价扣率金额 money,
  fPrice_In money,fmoney_Cost money,fmoney_cost0 money,fmoney_cost1 money)

if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend

CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money,差价数量 money, Pos客退数量1 money,
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,扣率金额 money,当日销售 money,特价扣率金额 money,
  fPrice_In money,fmoney_Cost money,fmoney_cost0 money,fmoney_cost1 money)
  
 --print '00 '+dbo.gettimestr(getdate())

insert into #temp_WhFrombgn  ([cGoodsNo],cSupplierNo) 
select cGoodsNo,@supNo from  #temp_Goods 

insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo) 
select cGoodsNo,@supNo from  #temp_Goods 
 
set @SQLstr='
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_bgn''))is not null  drop table #temp_Wh_Goods_bgn
select 业务日期,a.cgoodsno,a.cSupplierNo,a.cWHno,b.dDateTime, b.销售数量0, b.销售金额0, 
b.特价销售数量, b.特价销售金额, b.正价销售数量, b.正价销售金额, 
Pos客退数量1=b.Pos客退数量1, Pos客退金额1=b.Pos客退金额1,入库数量1=b.入库数量1, 入库金额1=b.入库金额1, 					
扣率金额=b.扣率金额,特价扣率金额=b.当日特价销售金额*b.特价扣率/100,				  
fmoney_Cost=(isnull(b.销售数量0,0)*b.fPrice_In),
fmoney_cost0=(isnull(b.正价销售数量,0)*b.fPrice_In),
fmoney_cost1=(isnull(b.特价销售数量,0)*b.fPrice_In)			   
into #temp_Wh_Goods_bgn
from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
 with (nolock) 
where  b.业务日期='''+dbo.getdaystr(@dDateBgn-1)+''' 
and a.cGoodsNo=b.cGoodsNo and b.cSupplierNo='''+@supNo+''' and a.cSupplierNo=b.cSupplierNo  				 
union all             
select 业务日期,a.cgoodsno,a.cSupplierNo,a.cWHno,b.dDateTime,
 b.销售数量0, b.销售金额0, 
b.特价销售数量, b.特价销售金额, 
b.正价销售数量, b.正价销售金额, 
Pos客退数量1=b.Pos客退数量1, Pos客退金额1=b.Pos客退金额1,
入库数量1=b.入库数量1, 入库金额1=b.入库金额1, 					
扣率金额=b.扣率金额,特价扣率金额=b.当日特价销售金额*b.特价扣率/100,				  
fmoney_Cost=(isnull(b.销售数量0,0)*b.fPrice_In),
fmoney_cost0=(isnull(b.正价销售数量,0)*b.fPrice_In),
fmoney_cost1=(isnull(b.特价销售数量,0)*b.fPrice_In)	
from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
 with (nolock) 
where  b.业务日期 between '''+dbo.getdaystr(@dDateBgn-1)+''' and '''+dbo.getdaystr(@dDateBgn-1)+''' 
and a.cGoodsNo=b.cGoodsNo and b.cSupplierNo='''+@supNo+'''
and a.cSupplierNo=b.cSupplierNo  

   
if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
select cgoodsno,cSupplierNo,cWHno,
销售数量=SUM(销售数量0),销售金额=SUM(销售金额0), 
特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额),			
扣率金额=sum(扣率金额),特价扣率金额=sum(特价扣率金额),
fmoney_Cost=SUM(fmoney_cost),
fmoney_cost0=SUM(fmoney_cost0),
fmoney_cost1=SUM(fmoney_cost1)			
into #temp_SumWh_Goods_begin
from #temp_Wh_Goods_bgn
group by cgoodsno,cSupplierNo,cWHno		

update a
set a.销售数量0=isnull(b.销售数量,0), a.销售金额0=isnull(b.销售金额,0),
a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,				
a.扣率金额=b.扣率金额,a.特价扣率金额=b.特价扣率金额,
a.fmoney_Cost=b.fmoney_Cost,
a.fmoney_Cost0=b.fmoney_Cost0,
a.fmoney_Cost1=b.fmoney_Cost1	
from #temp_WhFrombgn a ,#temp_SumWh_Goods_begin b
where a.cGoodsNo=b.cGoodsNo 
and a.cSupplierNo=b.cSupplierNo 

'


set @SQLstr1='
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
select 业务日期,a.cgoodsno,a.cSupplierNo,a.cWHno,b.dDateTime, 
b.销售数量0, b.销售金额0, 
b.特价销售数量, b.特价销售金额, 
b.正价销售数量, b.正价销售金额, 
Pos客退数量1=b.Pos客退数量1, Pos客退金额1=b.Pos客退金额1,
入库数量1=b.入库数量1, 入库金额1=b.入库金额1, 					
扣率金额=b.扣率金额,特价扣率金额=b.当日特价销售金额*b.特价扣率/100,				  
fmoney_Cost=(isnull(b.销售数量0,0)*b.fPrice_In),
fmoney_cost0=(isnull(b.正价销售数量,0)*b.fPrice_In),
fmoney_cost1=(isnull(b.特价销售数量,0)*b.fPrice_In)			   
into #temp_Wh_Goods_end
from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
 with (nolock) 
where  b.业务日期='''+dbo.getdaystr(@dDateEnd)+''' 
and a.cGoodsNo=b.cGoodsNo and b.cSupplierNo='''+@supNo+''' and a.cSupplierNo=b.cSupplierNo  				 
union all             
select 业务日期,a.cgoodsno,a.cSupplierNo,a.cWHno,b.dDateTime,
 b.销售数量0, b.销售金额0, 
b.特价销售数量, b.特价销售金额, 
b.正价销售数量, b.正价销售金额, 
Pos客退数量1=b.Pos客退数量1, Pos客退金额1=b.Pos客退金额1,
入库数量1=b.入库数量1, 入库金额1=b.入库金额1, 					
扣率金额=b.扣率金额,特价扣率金额=b.当日特价销售金额*b.特价扣率/100,				  
fmoney_Cost=(isnull(b.销售数量0,0)*b.fPrice_In),
fmoney_cost0=(isnull(b.正价销售数量,0)*b.fPrice_In),
fmoney_cost1=(isnull(b.特价销售数量,0)*b.fPrice_In)	
from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
 with (nolock) 
where  b.业务日期 between '''+dbo.getdaystr(@dDateBgn-1)+''' and '''+dbo.getdaystr(@dDateEnd)+''' 
and a.cGoodsNo=b.cGoodsNo and b.cSupplierNo='''+@supNo+'''
and a.cSupplierNo=b.cSupplierNo  

   
if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
select cgoodsno,cSupplierNo,cWHno,
销售数量=SUM(销售数量0),销售金额=SUM(销售金额0), 
特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额),			
扣率金额=sum(扣率金额),特价扣率金额=sum(特价扣率金额),
fmoney_Cost=SUM(fmoney_cost),
fmoney_cost0=SUM(fmoney_cost0),
fmoney_cost1=SUM(fmoney_cost1)			
into #temp_SumWh_Goods_end
from #temp_Wh_Goods_end
group by cgoodsno,cSupplierNo,cWHno		

update a
set a.销售数量0=isnull(b.销售数量,0), a.销售金额0=isnull(b.销售金额,0),
a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,				
a.扣率金额=b.扣率金额,a.特价扣率金额=b.特价扣率金额,
a.fmoney_Cost=b.fmoney_Cost,
a.fmoney_Cost0=b.fmoney_Cost0,
a.fmoney_Cost1=b.fmoney_Cost1	
from #temp_WhFromend a ,#temp_SumWh_Goods_end b
where a.cGoodsNo=b.cGoodsNo 
and a.cSupplierNo=b.cSupplierNo 

'

exec (@SQLstr+@SQLstr1)
	
 
update a set a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
a.fmoney_Cost=isnull(a.fmoney_Cost,0)-isnull(b.fmoney_Cost,0),
a.fmoney_Cost1=isnull(a.fmoney_Cost1,0)-isnull(b.fmoney_Cost1,0),
a.fmoney_Cost0=isnull(a.fmoney_Cost0,0)-isnull(b.fmoney_Cost0,0) 
from #temp_WhFromend a,#temp_WhFrombgn b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo



select	fMoney_Cost=sum(isnull(fMoney_Cost,0)),
fMoney_Profit_sum=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
xsMoney=sum(isnull(销售金额0,0)),fML=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),fMoney_0=sum(isnull(正价销售金额,0)),
fProfit=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
fProfit_0=sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0)),
fMoney_1=sum(isnull(特价销售金额,0)),fProfit_1=sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
fProfit_Ratio=case when sum(isnull(销售金额0,0))<>0 
then  (sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0))*100/sum(isnull(销售金额0,0))) else 0 end,
fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
fmoney_cost0=SUM(isnull(fmoney_cost0,0)),
fmoney_cost1=SUM(isnull(fmoney_cost1,0)),
截至期末库存金额=CAST(null as money),可销天数=CAST(null as money),
上月进货金额=CAST(null as money),
未结算进货金额=CAST(null as money),
上月返厂金额=CAST(null as money),
未结算返厂金额=CAST(null as money) ,未结算差价金额=CAST(null as money),
预结算进货金额=CAST(null as money),
预结算金额=CAST(null as money),
截至上月库存=CAST(null as money),
当前库存金额=CAST(null as money),预结算入库单据=CAST(null as varchar(max)),
cSupplierNo=@supNo  
into #temp_WhFromend_Output
from #temp_WhFromend

--	print '02 '+dbo.gettimestr(getdate())

if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend



declare @iPeriodDays int

set @iPeriodDays=datediff(day,@dDate1,@dDate2)+1


select a.*
into #temp_SupplierRatio
from 
(
select cSupNo=a.guizuno,fMoney1=-99999999,fMoney2=0,fRatio=b.fRatio,b.iDays
from
(
select guizuno,fMoney1=min(fMoney1)
from dbo.t_Supplier_Contract_Ratio
group by guizuno
) a,t_Supplier_Contract_Ratio b
where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
union all
select cSupNo=guizuno,fMoney1=fMoney1*@iPeriodDays/iDays,
fMoney2=case when fMoney2=999999999 then fMoney2 else fMoney2*@iPeriodDays/iDays end,
fRatio,iDays
from dbo.t_Supplier_Contract_Ratio
) a
where a.cSupNo=@supNo


--	print '03 '+dbo.gettimestr(getdate())


if(select object_id('tempdb..#temp_SupplierSales')) is not null drop table #temp_SupplierSales

select cSupNo=@supNo,fMoney_sale=fMoney_0
into #temp_SupplierSales
from #temp_WhFromend_Output


if(select object_id('tempdb..#temp_SupplierSales_ratio')) is not null drop table #temp_SupplierSales_ratio

select a.cSupNo,a.fMoney1,a.fMoney2,a.fRatio,b.fMoney_sale,
fMoney_Exe=cast(0 as money),fMoney_Ref=cast(0 as money)
into #temp_SupplierSales_ratio
from #temp_SupplierRatio a,#temp_SupplierSales b
where a.cSupNo=b.cSupNo

update #temp_SupplierSales_ratio
set fMoney_Ref=fMoney2-fMoney1

update #temp_SupplierSales_ratio
set fMoney_Ref=fMoney_sale-fMoney1
where fMoney1<fMoney_sale and fMoney_sale<=fMoney2

update #temp_SupplierSales_ratio
set fMoney_Ref=0
where fMoney1<=-99999999

update #temp_SupplierSales_ratio
set fMoney_Ref=0
where fMoney1>fMoney_sale

update #temp_SupplierSales_ratio
set fMoney_Exe=fMoney_Ref

--print '04 '+dbo.gettimestr(getdate())

declare @正价扣款 money

set  @正价扣款=(select round(SUM(fMoney_Exe*fRatio/100),2)	from #temp_SupplierSales_ratio)	
/*	
fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
*/
update #temp_WhFromend_Output
set fProfit_Ratio_0=@正价扣款,fProfit_Ratio_koudian=@正价扣款+fProfit_Ratio_1

 
/*获取进销存*/

if  (select object_id('tempdb..#TempInWareHouse')) is not null 
drop table #TempInWareHouse

-----------2015-08-13号调整
/*
select a.cSupplierNo,fMoney=sum(fMoney),dDate,cSheetno
into #TempInWareHouse
from wh_InWareHouse a
where a.cSupplierNo=@supNo and dbo.getDayStr(a.dDate)<=@dDate2
and isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1) 
and isnull(a.bPresent,0)=0
group by a.cSupplierNo,dDate,cSheetno
*/
select a.cSupplierNo,fMoney=sum(fMoney),dDate,cSheetno,bBalance,bAccount,bPresent
into #TempInWareHouse
from wh_InWareHouse a
where a.cSupplierNo=@supNo and dbo.getDayStr(a.dDate)<=@dDate2
group by a.cSupplierNo,dDate,cSheetno,bBalance,bAccount,bPresent

update a
set a.未结算进货金额=b.fMoney
from #temp_WhFromend_Output a,
(select cSupplierNo,fMoney=sum(fMoney) 
from #TempInWareHouse where isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1) 
and isnull(bPresent,0)=0 group by cSupplierNo) b
where a.cSupplierNo=b.cSupplierNo

declare @ddatebgn1 datetime
declare @lastBgn1 datetime
declare @lastEnd1 datetime
set @ddatebgn1=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
set @lastBgn1=DATEADD(MONTH,-1,@ddatebgn1)
set @lastEnd1=DATEADD(DAY,-1,@ddatebgn1) 


declare @dDateDq date

set @dDateDq=GETDATE()
 

declare @ShangMonth datetime
declare @ShangMonthBgn datetime
declare @ShangMonthEnd datetime
set @ShangMonth=CAST((cast(YEAR(@dDateDq) as varchar(16))+'-'+cast(MONTH(@dDateDq) as varchar(16))+'-01') AS DATETIME)
set @ShangMonthBgn=DATEADD(MONTH,-1,@ShangMonth)
set @ShangMonthEnd=DATEADD(DAY,-1,@ShangMonth) 

--select @ShangMonth,@ShangMonthBgn,@ShangMonthEnd

update a
set a.上月进货金额=b.fMoney
from #temp_WhFromend_Output a,
(select cSupplierNo,fMoney=sum(fMoney) 
from #TempInWareHouse where  dDate between @ShangMonthBgn and @ShangMonthEnd 
group by cSupplierNo) b
where a.cSupplierNo=b.cSupplierNo
--- 返厂。。 
/*
if(select object_id('tempdb..#TempRbdWareHouse'))is not null
drop table #TempRbdWareHouse 
select  a.cSupplierNo, fMoney=SUM(fMoney),dDate,cSheetno
into #TempRbdWareHouse
from wh_RbdWareHouse a 
where a.cSupplierNo=@supNo and dbo.getDayStr(a.dDate)<=@dDate2
and isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1)
group by a.cSupplierNo,dDate,cSheetno
*/
if(select object_id('tempdb..#TempRbdWareHouse'))is not null
drop table #TempRbdWareHouse 
select  a.cSupplierNo, fMoney=SUM(fMoney),dDate,cSheetno,bBalance,bAccount
into #TempRbdWareHouse
from wh_RbdWareHouse a 
where a.cSupplierNo=@supNo and dbo.getDayStr(a.dDate)<=@dDate2
group by a.cSupplierNo,dDate,cSheetno,bBalance,bAccount



update a
set a.未结算返厂金额=b.fMoney,
a.预结算金额=-b.fMoney
from #temp_WhFromend_Output a,
(select cSupplierNo,fMoney=sum(fMoney) from #TempRbdWareHouse where isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1) group by cSupplierNo) b
where a.cSupplierNo=b.cSupplierNo
 

update a
set a.上月返厂金额=b.fMoney 
from #temp_WhFromend_Output a,
(select cSupplierNo,fMoney=sum(fMoney) from #TempRbdWareHouse where dDate between @ShangMonthBgn and @ShangMonthEnd   group by cSupplierNo) b
where a.cSupplierNo=b.cSupplierNo

--------预结算单号字段制成null --- 重新预结算。。。
update b
set b.tempJiesuanno=null
from #TempRbdWareHouse a,wh_RbdWarehouse b
where a.dDate=b.dDate and a.cSheetno=b.cSheetno

update a
set a.tempJiesuanno=@jiesuanNo
from wh_RbdWarehouse a,#TempRbdWareHouse b
where a.dDate=b.dDate and a.cSupplierNo=b.cSupplierNo and a.cSheetno=b.cSheetno
and isnull(b.bBalance,0)<>1 and (isnull(b.bAccount,0)=1)

------------差价单-----   
if(select object_id('tempdb..#TempDiffWareHouse'))is not null
drop table #TempDiffWareHouse
select  a.cSupplierNo, fMoney=sum(fMoney_diff),dDate,cSheetno   
into #TempDiffWareHouse 
from wh_DiffPriceWarehouse a 
where a.cSupplierNo=@supNo and dbo.getDayStr(a.dDate)<=@dDate2
and isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1)
group by a.cSupplierNo,dDate,cSheetno 

update a
set a.未结算差价金额=b.fMoney,
a.预结算金额=ISNULL(a.预结算金额,0)+ISNULL(-b.fMoney,0)
from #temp_WhFromend_Output a,
(select cSupplierNo, fMoney=sum(fMoney) from #TempDiffWareHouse group by cSupplierNo) b
where a.cSupplierNo=b.cSupplierNo

--------预结算单号字段制成null --- 重新预结算。。。
update a
set a.tempJiesuanno=null
from wh_DiffPriceWarehouse a,#TempDiffWareHouse b
where a.dDate=b.dDate and a.cSheetno=b.cSheetno

update a
set a.tempJiesuanno=@jiesuanNo
from wh_DiffPriceWarehouse a,#TempDiffWareHouse b
where a.dDate=b.dDate and a.cSupplierNo=b.cSupplierNo


if(select object_id('tempdb..#Temp_inWarehouseSheetno'))is not null
drop table #Temp_inWarehouseSheetno
create table  #Temp_inWarehouseSheetno(dDate datetime,cSheetno varchar(32))

--------预结算单号字段制成null --- 重新预结算。。。
update b
set b.tempJiesuanno=null
from #TempInWareHouse a,wh_InWarehouse b
where a.dDate=b.dDate and a.cSheetno=b.cSheetno
 
 

declare @SumXsmong money
declare @SumInWarehMoney money
declare @InMoney money
set @InMoney=0
set @SumInWarehMoney=0

-------时段销售
select @SumXsmong=sum(xsMoney)
from #temp_WhFromend_Output

 
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
 /*
exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDateDq,@dDateDq,@cWhno  

-----------当前库存金额
declare @FlastKucunMoney money
set @FlastKucunMoney=(select SUM(Endmoney) from #temp_goodsKuCurQty)
 
-----------当前库存金额
delete #temp_goodsKuCurQty

exec [P_x_SetCheckWh_byGoodsType_logCurQty] @ShangMonthEnd,@ShangMonthEnd,@cWhno  
 
declare @ShangMonthMoney money
set @ShangMonthMoney=(select SUM(Endmoney) from #temp_goodsKuCurQty)

*/ 
  
  if (select OBJECT_ID('tempdb..#temp_Wh_Form'))is not null drop table #temp_Wh_Form
  create table #temp_Wh_Form(fLeft_Qty money,fLeft_Money money,cSupplierNo varchar(32))
   declare @dDate12 datetime
   set @dDate12=CAST((cast(YEAR(@dDateDq) as varchar(16))+'-'+cast(MONTH(@dDateDq) as varchar(16))+'-12') AS DATETIME)
   if @dDateDq>@dDate12
   begin
       set @dDateDq=@dDate12
   end
  
  exec(' 
      insert into #temp_Wh_Form(fLeft_Qty,fLeft_Money,cSupplierNo)
      select fLeft_Qty=SUM(fQty_Left),fLeft_Money=SUM(fMoney_Left),
      cSupplierNo from '+@cdbname+'.dbo.T_WH_Form_log_1
	  where 业务日期='''+@dDateDq+''' and  cSupplierNo='''+@supNo+'''
	  group by cSupplierNo   
  ')
 
-----------当前库存金额
declare @FlastKucunMoney money
set @FlastKucunMoney=(select SUM(fLeft_Money) from #temp_Wh_Form)

 
-----------当前库存金额
delete #temp_Wh_Form
 
exec(' 
  insert into #temp_Wh_Form(fLeft_Qty,fLeft_Money,cSupplierNo)
  select fLeft_Qty=SUM(fQty_Left),fLeft_Money=SUM(fMoney_Left),
  cSupplierNo from '+@cdbname+'.dbo.T_WH_Form_log_1
  where 业务日期='''+@ShangMonthEnd+''' and  cSupplierNo='''+@supNo+'''
  group by cSupplierNo   
')
 
declare @ShangMonthMoney money
set @ShangMonthMoney=(select SUM(fLeft_Money) from #temp_Wh_Form)


update #temp_WhFromend_Output 
set 当前库存金额=@FlastKucunMoney
 ,截至期末库存金额=@ShangMonthMoney

 set @SumInWarehMoney=(select isnull(未结算进货金额,0)-isnull(@FlastKucunMoney,0) from #temp_WhFromend_Output)
 --set @SumInWarehMoney=ISNULL(@FlastKucunMoney,)
--判断游标是否存在

update #temp_WhFromend_Output 
set 预结算进货金额=@SumInWarehMoney
 ------------2015-08-19注释------------
 /*
if  @SumInWarehMoney>0 
begin

		if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='NegativeInWh_Xsmoney')
		begin
		  close NegativeInWh_Xsmoney
		  deallocate NegativeInWh_Xsmoney
		end 

		declare  NegativeInWh_Xsmoney cursor
		for
		select fMoney,dDate,cSheetno from #TempInWareHouse
		where  isnull(bBalance,0)<>1 and (isnull(bAccount,0)=1) 
		and isnull(bPresent,0)=0
		order by dDate,cSheetno

		open NegativeInWh_Xsmoney
		 
		declare @InWarehMoney money
		declare @indDate datetime
		declare @cSheetno varchar(32)
		select @InWarehMoney=0 
		 
		fetch next from NegativeInWh_Xsmoney into @InWarehMoney,@indDate,@cSheetno

		while @@fetch_status=0
		begin
			if  @SumInWarehMoney<@SumXsmong
			begin     
			  insert into #Temp_inWarehouseSheetno(dDate,cSheetno)values(@indDate,@cSheetno)
			  set  @SumInWarehMoney=isnull(@SumInWarehMoney,0)+@InWarehMoney
			  set @InMoney=@InMoney+@InWarehMoney
			end else if  @SumInWarehMoney>@SumXsmong
			begin
			   delete #Temp_inWarehouseSheetno where cSheetno=@cSheetno
			   set  @SumInWarehMoney=isnull(@SumInWarehMoney,0)-@InWarehMoney
			   set @InMoney=@InMoney-@InWarehMoney
			   break;
			end else
			begin
				break;
			end
		   
			fetch next from NegativeInWh_Xsmoney into @InWarehMoney,@indDate,@cSheetno
		    
		end

		close NegativeInWh_Xsmoney
		deallocate NegativeInWh_Xsmoney

end
*/

 
-----------费用
 
exec p_Supplier_Fee_AutoGen_Pre_InMoney  @supNo,@dDate2,@dDate1,@dDate2,null,'888',@InMoney

----获得费用
if (select object_id('tempdb..#temp_SupplierFee_list'))is not null
drop table #temp_SupplierFee_list
create table #temp_SupplierFee_list
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,riqi1 datetime,riqi2 datetime,serno varchar(32),bJiesuan bit)
insert into #temp_SupplierFee_list(feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno,bJiesuan)

exec p_SumSupplierFee_list @supNo,@dDate1,@dDate2

--update a
--set a.tempJiesuanno=null
--from t_Supplier_fee a,#temp_SupplierFee_list b
--where a.feiyongno=b.feiyongno and a.riqi1=b.riqi1 and a.serno=b.serno

update t_Supplier_fee set tempJiesuanno=null 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

update t_Supplier_fee set tempJiesuanno=@jiesuanNo 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

 
------合并费用
declare @feiyongjine money

set @feiyongjine=(
select feiyongjine=SUM(feiyongjine) from #temp_SupplierFee_list)
 

------------修改入库单中预结算单号
update b
set b.tempJiesuanno=@jiesuanNo
from #Temp_inWarehouseSheetno a,wh_InWarehouse b
where a.dDate=b.dDate and a.cSheetno=b.cSheetno

-------供应商获取租金
declare @feiyongZone money
if (select object_id('tempdb..#temp_Supplier_Zone'))is not null
drop table #temp_Supplier_Zone
create table #temp_Supplier_Zone
(cContractNo varchar(32),cZoneNo varchar(32),cZoneName varchar(64),feiyongjine money,riqi1 datetime,riqi2 datetime)
insert into #temp_Supplier_Zone(cContractNo,cZoneNo,cZoneName,feiyongjine,riqi1,riqi2)
exec p_SumSupplierZone_list @supNo,@dDate1,@dDate2

set @feiyongZone=(select SUM(feiyongjine) from #temp_Supplier_Zone)
 
update dbo.t_Zone_Contract_History  set tempJiesuanno=null 
where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate between @dDate1 and @dDate2

update dbo.t_Zone_Contract  set tempJiesuanno=null  
where  isnull(jiesuanover,0)=0 and cSupNo=@supNo	


update dbo.t_Zone_Contract_History  set tempJiesuanno=@jiesuanNo 
where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate between @dDate1 and @dDate2

update dbo.t_Zone_Contract  set tempJiesuanno=@jiesuanNo  
where  isnull(jiesuanover,0)=0 and cSupNo=@supNo	


----供应商支出
declare @feiyongPayout money
if (select object_id('tempdb..#temp_Supplier_Payout'))is not null
drop table #temp_Supplier_Payout
create table #temp_Supplier_Payout
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,serno varchar(32),riqi1 datetime,riqi2 datetime)

update t_Supplier_Payout set tempJiesuanno=null 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

insert into #temp_Supplier_Payout(feiyongno,feiyong,feiyongjine,serno,riqi1,riqi2)
exec p_SumSupplierPayout_list  @supNo,@dDate1,@dDate2

set @feiyongPayout=(select SUM(feiyongjine) from #temp_Supplier_Payout)

update t_Supplier_Payout set tempJiesuanno=@jiesuanNo 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2
 
--- 供应商进账单

declare @feiyongIncome money
if (select object_id('tempdb..#temp_Supplier_Income'))is not null
drop table #temp_Supplier_Income
create table #temp_Supplier_Income
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,riqi1 datetime,riqi2 datetime,serno varchar(32))

update t_Supplier_Income set tempJiesuanno=null
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

insert into #temp_Supplier_Income(feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno)
exec p_SumSupplierIncome_list  @supNo,@dDate1,@dDate2

set @feiyongIncome=(select SUM(feiyongjine) from #temp_Supplier_Income)

update t_Supplier_Income set tempJiesuanno=@jiesuanNo
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

----------------------------------- 

 ---------获取上个月的正月销售、成本
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cgoodsno varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fmoney_Cost money)


declare @day int
set @day=DATEDIFF (DAY,@lastBgn1,@lastEnd1)+1

--  print '13002    '+dbo.getTimeStr(GETDATE())

exec p_GetLastMonthSale_wei @lastBgn1,@lastEnd1,@cWHno,@cdbname

 -- print '13003    '+dbo.getTimeStr(GETDATE())
-----------上正月的销售、成本。
 
declare @Xsqty money
declare @Xsfmoney_Cost money
select @Xsqty=SUM(xsQty),@Xsfmoney_Cost=SUM(fmoney_Cost) from #temp_GetLastMonthSale_wei
 
---select isnull(@feiyongjine,0),isnull(@feiyongPayout,0),isnull(@feiyongIncome,0),ISNULL(@feiyongZone,0)
  
if (select object_id('tempdb..#temp_SuperListOver'))is not null
begin 
    update a
    set a.jiesuanno=@jiesuanNo,a.xsMoney=b.xsMoney,
    a.截至期末库存金额=b.截至期末库存金额,
     
    a.可销天数=case when isnull(@Xsfmoney_Cost,0)=0 
	then 
		case when isnull(b.当前库存金额,0)=0 then 0 
		else 99999 end
	else b.当前库存金额*@day/@Xsfmoney_Cost end, 
	a.上月进货金额=b.上月进货金额,
	a.未结算进货金额=b.未结算进货金额,
	a.上月返厂金额=b.上月返厂金额,
	a.未结算返厂金额=isnull(b.未结算返厂金额,0),
	a.未结算差价金额=isnull(b.未结算差价金额,0),
	a.feiyongjine=isnull(@feiyongjine,0)+isnull(@feiyongPayout,0)+isnull(@feiyongIncome,0)+ISNULL(@feiyongZone,0),	
	a.销售扣点金额=isnull(fProfit_Ratio_koudian,0), 
	a.预结进货金额=isnull(b.未结算进货金额,0)-isnull(b.当前库存金额,0),
	--a.预结算金额=(isnull(@SumInWarehMoney,0)-isnull(@feiyongjine,0)-isnull(@feiyongPayout,0)-isnull(@feiyongIncome,0)-ISNULL(@feiyongZone,0)),	
	a.预结算金额=(isnull(b.未结算进货金额,0)-isnull(b.当前库存金额,0)-isnull(b.未结算返厂金额,0)-isnull(b.未结算差价金额,0)-isnull(@feiyongjine,0)-isnull(@feiyongPayout,0)-isnull(@feiyongIncome,0)-ISNULL(@feiyongZone,0)),	
    --a.预结算金额=isnull(b.未结算进货金额,0)-isnull(b.当前库存金额,0)-isnull(b.未结算返厂金额,0)-isnull(b.未结算差价金额,0),
	a.当前库存金额=b.当前库存金额,
	a.预结算入库单据=b.预结算入库单据,
	a.xiaoshou_zj=b.fMoney_0,	 
	a.xiaoshou_tj=b.fMoney_1, 
    a.koudina_zj=b.fProfit_Ratio_0,
    a.koudian_tj=b.fProfit_Ratio_1,
    a.payoutMoney=isnull(@feiyongPayout,0),
    a.cZoneMoney=isnull(@feiyongZone,0),
    a.qtMoney=isnull(@feiyongIncome,0)  
    --from #temp_SuperList a,#temp_WhFromend_Output b
    from #temp_SuperListOver a,#temp_WhFromend_Output b
    where a.cSupNo=b.cSupplierNo    

end else
begin
	select jiesuanno=@jiesuanno,BeginDate=@dDate1,EndDate=@dDate2,cSupplierNo,
	fml,fMoney_Cost,xsMoney,截至期末库存金额,
	可销天数=case when isnull(@Xsfmoney_Cost,0)=0 
	then 
		case when isnull(当前库存金额,0)=0 then 0 
		else 99999 end
	else 当前库存金额*@day/@Xsfmoney_Cost end,
	 上月进货金额,上月返厂金额,
	未结算进货金额,未结算返厂金额,未结算差价金额,
	 feiyongjine=isnull(@feiyongjine,0)+isnull(@feiyongPayout,0)+isnull(@feiyongIncome,0)+ISNULL(@feiyongZone,0),
	 销售扣点金额=isnull(fProfit_Ratio_koudian,0),
	预结算金额=(isnull(@SumInWarehMoney,0)-isnull(@feiyongjine,0)-isnull(@feiyongPayout,0)-isnull(@feiyongIncome,0)-ISNULL(@feiyongZone,0)),
	当前库存金额,预结算入库单据,isnull(@feiyongjine,0)
	from #temp_WhFromend_Output  
	
end
 

--print '05 '+dbo.gettimestr(getdate())
   	
/*
	 select	fMoney_Cost=sum(isnull(销售金额0,0))-sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0))-sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
	 fMoney_Profit_sum=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
	xsMoney=sum(isnull(销售金额0,0)),fML=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),fMoney_0=sum(isnull(正价销售金额,0)),
    fProfit=sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0)),
	fProfit_0=sum(isnull(正价销售金额,0)-isnull(fmoney_cost0,0)),
	fMoney_1=sum(isnull(特价销售金额,0)),fProfit_1=sum(isnull(特价销售金额,0)-isnull(fmoney_Cost1,0)),
    fProfit_Ratio=case when sum(isnull(销售金额0,0))<>0 
	then  (sum(isnull(销售金额0,0)-isnull(fmoney_Cost,0))*100/sum(isnull(销售金额0,0))) else 0 end,
    fProfit_Ratio_0=sum(isnull(扣率金额,0)-isnull(特价扣率金额,0)),
    fProfit_Ratio_1=sum(isnull(特价扣率金额,0)),
    fProfit_Ratio_koudian=sum(isnull(扣率金额,0)),
    fmoney_cost0=SUM(isnull(fmoney_cost0,0)),
    fmoney_cost1=SUM(isnull(fmoney_cost1,0))
  into #temp_WhFromend_Output
	from #temp_WhFromend

*/	
	

    return 1


	
end


GO
