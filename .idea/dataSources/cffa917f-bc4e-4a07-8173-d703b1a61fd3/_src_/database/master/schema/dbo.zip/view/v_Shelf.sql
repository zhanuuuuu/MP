
CREATE  view v_Shelf as

select a.cShelfNo,a.cShelfName,a.cZoneNo,a.cZoneName,b.cSalesDeptNo,b.cSalesDept

from dbo.t_Shelf a
     left join dbo.t_Zone b
          on a.cZoneNo=b.cZoneNo


GO
