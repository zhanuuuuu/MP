/*
先进后出算库存(商品退货)
*/

CREATE proc p_FILOWhFormInNum_chen 
@cGoodsNo varchar(50),    --商品名称 
@iAttribute int,          --0入库；1出库；2返厂；3顾客退货入库；4调拨；5报损；6报益；7差价单
@cSheetNo varchar(32),    --单据号
@iLine int,               --商品在单据中的行号
@cWhNo varchar(32),
@QtyOut int,              --返还数量 
@Return int output        --返回1：库存不足2:内部错误3:数量为0错误
as 

if @QtyOut<=0 
begin
  set @Return=3 
  return
end

set @Return=0 
--先得出该货物的库存是否够 


if (select object_id('tempdb..#tmpWhForm'))is not null
begin
  drop table #tmpWhForm
end
if (select object_id('tempdb..#tmpSubQty'))is not null
begin
  drop table #tmpSubQty
end
select cGoodsNo,iSerNo,fPrice_In=isnull(fPrice_In,0),fQty_in=isnull(fQty_in,0),fQty_Out=isnull(fQty_Out,0),cWhNo
into #tmpWhForm
from t_wh_form
where cGoodsNo=@cGoodsNo and isnull(fQty_Out,0)<>0
and isnull(cWhNo,'')=@cWhNo
--order by iSerNo desc

declare @spare float --剩余库存
select @spare=sum(fQty_Out) 
from #tmpWhForm 
where cGoodsNo=@cGoodsNo
and isnull(fQty_Out,0)<>0
group by cGoodsNo


if(@spare>=@QtyOut) 
begin
  begin try
     begin tran 
		--根据入库日期采用先进先出原则对货物的库存进行处理 
		update a 
		set a.fQty_Out= 
		case when 
			( select @QtyOut-isnull(sum(fQty_Out),0) 
			  from #tmpWhForm 
			  where cGoodsNo=@cGoodsNo and iSerNo >=a.iSerNo and fQty_Out<>0
			)>=0 
		then 0
		else 
			case when 
				(select @QtyOut-isnull(sum(fQty_Out),0) 
				 from #tmpWhForm 
				 where cGoodsNo=@cGoodsNo and iSerNo >a.iSerNo and fQty_Out<>0
				)<0 then a.fQty_Out 
			else 
			   (select a.fQty_Out-(@QtyOut-isnull(sum(fQty_Out),0))
				from #tmpWhForm 
				where cGoodsNo=@cGoodsNo and iSerNo >a.iSerNo and fQty_Out<>0) 
			end 
		end
		from #tmpWhForm a 
		where a.cGoodsNo=@cGoodsNo and a.fQty_Out<>0

		--更新数据
		select a.cGoodsNo,a.iSerNo,a.fPrice_In,SubQty=a.fQty_Out-b.fQty_Out,a.fQty_Left
		into #tmpSubQty
		from t_wh_form a,#tmpWhForm b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cWhNo=b.cWhNo

		update a
		set a.fPrice_Out=a.fPrice_In,a.fQty_Out=b.fQty_Out,a.fMoney_Out=a.fPrice_In*b.fQty_Out,
		a.fPrice_Left=a.fPrice_In,a.fQty_Left=a.fQty_In-b.fQty_Out,a.fMoney_Left=(a.fQty_In-b.fQty_Out)*a.fPrice_In
		from t_wh_form a,#tmpWhForm b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cWhNo=b.cWhNo

		insert into t_Cost_distribute
		(
		   cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,
		   iAttribute,cSheetNo,iLineNo,fQty
		)
		select a.cGoodsNo,a.iSerno,a.fPrice_In,b.SubQty,a.fPrice_In*b.SubQty,  
		@iAttribute,@cSheetNo,@iLine,b.fQty_Left
		from #tmpWhForm a,#tmpSubQty b
		where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo
		and isnull(b.SubQty,0)!=0

	  commit tran
	end try
	begin catch
	 rollback
	 set @Return=2  
	 return 
	end catch
end 
else
begin
    set @Return=1 
    --raiserror('库存不足',16,1)    
    return 
end


GO
