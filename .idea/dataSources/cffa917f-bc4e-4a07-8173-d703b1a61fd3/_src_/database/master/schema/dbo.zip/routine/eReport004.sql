CREATE procedure [dbo].[eReport004]
@date1 datetime,
@date2 datetime,
@sj1 int,@sj2 int,@no varchar(32)
as
begin
/*
eReport004
@date1='2012-06-01',@date2='2012-08-20',@sj1=9,@sj2=13,@No=''
*/
--获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @sj1 int
--declare @sj2 int
--declare @No varchar(32)
--select @date1='2011-06-01',@date2='2011-06-07',@sj1=9,@sj2=13,@No=''

if(select object_id('tempdb..#tempLevel1')) is not null drop table #tempLevel1
if(select object_id('tempdb..#tempLevel')) is not null drop table #tempLevel
if(select object_id('tempdb..#tempLeaf')) is not null drop table #tempLeaf
create table #tempLevel1 (cGoodsTypeNo varchar(32),cPath varchar(1024),iLevel int )
 
select a.cGoodsTypeNo,a.cParentNo
into #tempLeaf
from dbo.t_GoodsType a left join t_GoodsType b
on   a.cGoodsTypeNo =b.cParentNo 
where b.cGoodsTypeNo is  null
order by a.cParentNo,a.cGoodsTypeNo

declare @cGoodsTypeNo varchar(32)
declare @cParentNo varchar(32)
declare @cPath varchar(1024)
declare @iPathlevel int
declare @cGoodsTypeNo_var varchar(32)
declare crGoodsTypeNo cursor for
select cGoodsTypeNo,cParentNo from #tempLeaf
order by cParentNo,cGoodsTypeNo
open crGoodsTypeNo
fetch next from crGoodsTypeNo
into @cGoodsTypeNo,@cParentNo
set @cGoodsTypeNo_var=@cGoodsTypeNo
set @cPath=''
set @iPathlevel=1
while @@Fetch_Status=0
begin
	while isnull((select top 1 cParentNo from t_GoodsType 
								where cGoodsTypeNo=@cGoodsTypeNo_var 
											and @cGoodsTypeNo_var is not null
								)
								,''
							)<>'--'
	begin
		set @iPathlevel=@iPathlevel+1
		set @cPath= '.'+@cGoodsTypeNo_var+@cPath
		set @cGoodsTypeNo_var=
						isnull((select top 1 cParentNo from t_GoodsType 
										where cGoodsTypeNo=@cGoodsTypeNo_var 
													and @cGoodsTypeNo_var is not null
										),'')
	end				
	set @cPath='--.'+@cGoodsTypeNo_var+@cPath
	insert into #tempLevel1 (cGoodsTypeNo,cPath,iLevel)
	values (@cGoodsTypeNo,@cPath,@iPathlevel)
	fetch next from crGoodsTypeNo
	into @cGoodsTypeNo,@cParentNo
	set @cGoodsTypeNo_var=@cGoodsTypeNo
	set @cPath=''
	set @iPathlevel=1
end
CLOSE crGoodsTypeNo
DEALLOCATE crGoodsTypeNo

select * 
into #tempLevel
from #tempLevel1 
where cGoodsTypeNo like '%'+@No+'%'

if(select object_id('tempdb..#tempPath')) is not null
begin
	drop table 	#tempPath
end 
create table #tempPath (cGoodsTypeNo varchar(32),cPath varchar(1024),cPath_leaf  varchar(1024),iLevel int )
insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
select cGoodsTypeNo,cPath,cPath,iLevel from #tempLevel
declare @cPath_p varchar(1024)
declare @cPath_leaf varchar(1024)
declare @cMyTypeNo varchar(32)
declare @iLevel int
declare @i int
declare @iLength int
declare @cPath_var int
declare cur_Path cursor for
select cGoodsTypeNo,cPath,iLevel 
from #tempLevel
order by cGoodsTypeNo
open cur_Path
fetch next from cur_Path
into @cGoodsTypeNo,@cPath_leaf,@iLevel
while @@Fetch_Status=0
begin
	set @i=1
	set @cPath=substring(@cPath_leaf,4,datalength(@cPath_leaf)-3)
	set @cPath_p='.'+@cPath+'.'
	while @i<@iLevel
	begin
		set @iLength=patindex('%.%',@cPath)
		set @cMyTypeNo=substring(@cPath,1,@iLength-1)
		delete from #tempPath
		where cGoodsTypeNo=@cMyTypeNo and cPath_leaf=@cPath_leaf
		insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
		values(@cMyTypeNo,
		substring( 
		substring('.'+@cPath_leaf+'.',1,patindex('%.'+@cMyTypeNo+'.%','.'+@cPath_leaf+'.')+datalength(@cMyTypeNo)),
		2,1024), @cPath_leaf,@i	)
		set @cPath=substring(@cPath,@iLength+1,1024)
		set @cPath_p='.'+@cPath+'.'
		set @i=@i+1
	end
	fetch next from cur_Path
	into @cGoodsTypeNo,@cPath_leaf,@iLevel
end
CLOSE cur_Path
DEALLOCATE cur_Path
if (select object_id('tempdb..#tempGoodsTypePath'))is not null drop table #tempGoodsTypePath
select a.cGoodsTypeNo,b.cGoodsTypename,a.cPath,a.cPath_leaf,a.iLevel
into #tempGoodsTypePath
from #tempPath a,t_GoodsType b
where a.cGoodsTypeno=b.cGoodsTypeNo
/*以上形成类别列表*/
if (select object_id('tempdb..#TmpGoodsLevel'))is not null drop table #TmpGoodsLevel
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

if (select object_id('tempdb..#GoodsType'))is not null drop table #GoodsType
select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
where cPath=cPath_leaf

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null
update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null
----////////////////<><<>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<
if(select OBJECT_ID('tempdb..#tmp_SaleSheetDetail')) is not null
drop table #tmp_SaleSheetDetail
create table #tmp_SaleSheetDetail
(dSaleDate datetime,cGoodsNo varchar(32),
fQuantity money,iSeed int ,fPrice money,fLastSettle money,bAuditing bit,cWHno varchar(32),cSaleTime varchar(32))
if (select OBJECT_ID('tempdb..#tmp_SaleSheetInfor'))is not null
drop table #tmp_SaleSheetInfor
create table #tmp_SaleSheetInfor(databasename varchar(32))
             insert into #tmp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName

				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #tmp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('				
					    insert into #tmp_SaleSheetDetail(dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime)
						select dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime 
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@date1+''' and '''+@date2+''' 
					  
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
				  
                insert into #tmp_SaleSheetDetail(dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime)
				select dSaleDate,cGoodsNo,
						fQuantity,iSeed,fPrice,fLastSettle,bAuditing,cWHno,cSaleTime
				from dbo.t_salesheetDetail 
			    where dSaleDate between @date1 and @date2
			    
		
----////////////////
if (select object_id('tempdb..#TmpGoodsBaseInfo'))is not null drop table #TmpGoodsBaseInfo
select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,fLastSettle=sum(a.fLastSettle),sj=datepart(hh,cSaleTime)
into #TmpGoodsBaseInfo
--from t_SaleSheetDetail a left join t_goods b
from #tmp_SaleSheetDetail a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
where dSaleDate between @date1 and @date2
and datepart(hh,cSaleTime) between @sj1 and @sj2
group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,datepart(hh,cSaleTime)


	  
if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null
	  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=1
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select a.dSaleDate,b.BaseGoodsTypeNo,cGoodsTypeName=null,fLastSettle=SUM(a.fLastSettle),a.sj
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo
	group by a.dSaleDate,b.BaseGoodsTypeNo,a.sj
	order by a.dSaleDate,b.BaseGoodsTypeNo,a.sj

if (select object_id('tempdb..#last'))is not null drop table #last 
select a.dSaleDate,a.BaseGoodsTypeNo,b.cGoodsTypename,a.fLastSettle,合计=CAST(null as Money),a.sj
into #last 
from #tmpGoods_byLevel a left join t_GoodsType b 
on a.BaseGoodsTypeNo=b.cGoodsTypeno

declare @date varchar(32)
declare @TypeNo varchar(32)
declare @money money
declare @money1 money
declare @sj int
set @money=0
set @sj=9
declare c cursor for
select distinct dSaleDate,BaseGoodsTypeNo from #last

open c
fetch next from c
into @date,@TypeNo
while @@Fetch_Status=0
begin
    while @sj<=(select MAX(sj) from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo)
	begin 
		(select @money1=fLastSettle from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo and sj=@sj)
		set @money =@money + @money1
		update a set a.合计=@money from #last a 
		where sj=@sj and dSaleDate=@date and BaseGoodsTypeNo=@TypeNo
		set @sj=@sj+1 
	end 
	fetch next from c
into @date,@TypeNo
set @money=0
set @sj=9
end
CLOSE c
DEALLOCATE c

select 日期=convert(char(10),dSaleDate,120),类别NO=BaseGoodsTypeNo,类别名称=cGoodsTypename,
销售金额=fLastSettle,合计,时间=convert(varchar(10),sj)+'点至'+convert(varchar(10),(sj+1))+'点' from #last
order by dsaledate,basegoodstypeno,sj

end

GO
