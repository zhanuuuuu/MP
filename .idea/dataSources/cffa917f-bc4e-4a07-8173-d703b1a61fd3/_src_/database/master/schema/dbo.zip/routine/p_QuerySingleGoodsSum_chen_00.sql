/*
   p_QuerySingleGoodsSum_chen_00 '2015-07-09','115710'
*/
CREATE proc [dbo].[p_QuerySingleGoodsSum_chen_00]
@dDate datetime, --截止日期
@cGoodsNo varchar(100) --查询商品
as

if (select object_id('tempdb..#tmpQuerySingleGoods')) is not null
drop table #tmpQuerySingleGoods
select top 1 cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName,
cSupNo,cSupName,
fNormalPrice,fCkPrice,bStorage=isnull(bStorage,0),
fQtyIn_Account=cast(0 as money),fQtyOut_Account=cast(0 as money),
fQtyIn_NoAccount=cast(0 as money),fQtyOut_NoAccount=cast(0 as money),
fQty=cast(0 as money)
into #tmpQuerySingleGoods
from t_goods
where cGoodsNo=@cGoodsNo

 -----------获取当前库存------------
if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null drop table  #temp_dateBaseForKuCun
 
create table #temp_dateBaseForKuCun(cGoodsNo varchar(64),cGoodsTypeno varchar(64),EndQty money)

declare @bJiaGong int 
 
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select distinct cGoodsNo into #temp_Goods from #tmpQuerySingleGoods --t_goods where cGoodsNo='12009' or cGoodsNo='12260' --

declare @cWhNo varchar(32)
set @cWhNo=(select cWhNo from t_WareHouse where ISNULL(bMainSale,0)=1)

/*
exec [P_x_SetCheckWh_byGoodsType] 
@dDate,@dDate,@cWhNo,@bJiaGong
 
*/ 

if (select OBJECT_ID('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select * into #tmpCostGoodsList from #temp_Goods

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin ([dDateTime] datetime,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL)
CREATE TABLE #temp_end ([dDateTime] datetime,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL)
if (select OBJECT_ID('tempdb..#FindGoodsList0'))is not null drop table #FindGoodsList0
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #FindGoodsList0
from t_goods a, #tmpCostGoodsList b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1
--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#FindGoodsList1'))is not null drop table #FindGoodsList1
select cGoodsNO
into #FindGoodsList1
from #tmpCostGoodsList
union all
select cGoodsNo_MinPackage
from #FindGoodsList0
where ISNULL(bIsPack,0)=1
union all
select b.cGoodsNo
from #FindGoodsList0 a,t_goods b
where ISNULL(a.bIsPack,0)=0
and a.cGoodsNo=b.cGoodsNo_minPackage

if (select OBJECT_ID('tempdb..#t_FindGoods'))is not null drop table #t_FindGoods
select distinct cGoodsNO,cSupNO,bStorage
into #t_FindGoods
from t_goods
where cGoodsNo in(select cgoodsno from #FindGoodsList1)

--取商品(管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
select distinct cGoodsNo,cSupNo
into #tmpPloyOfGoodsinfo
from #t_FindGoods 
where isnull(bStorage,0)=1

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='''+@cWHno+''''
insert into #temp_date exec (@SQLstr)
select @date=isnull(MaxDate,'2000-01-01') from #temp_date
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   
if(@date>=@dDate-1)
	begin
		if (@date<@dDate)    
			begin
					set @date1=@date+1
					set @date2=@dDate
			end
		else
			begin
					set @date1=''
					set @date2=''
					set @date=@dDate
			end
	end
else
	begin 
		set @date1=@date+1
		set @date2=@dDate 
	end

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDate,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
insert into #temp_end  ([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDate,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity 
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@dDate-1)+''' and b.cWHno='''+@cWHno+'''
             '
set @SQLstr1=' update a
              set a.fQuantity=b.fQuantity 
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='''+@cWHno+'''
            '
exec (@SQLstr+@SQLstr1)

--以上计算期末库存

if (select OBJECT_ID('tempdb..#temp_ready'))is not null drop table #temp_ready
if (select OBJECT_ID('tempdb..#temp_ready1'))is not null drop table #temp_ready1
select 
GoodsNo_Pdt=a.cGoodsNo,BeginQty=isnull(b.fQuantity,0),EndDate=@dDate,
EndQty=isnull(a.fQuantity,0)  
into #temp_ready
from #temp_end a left join #temp_begin b 
on a.cGoodsNo=b.cGoodsNo


---包装转单品
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

update a
set a.GoodsNo_Pdt=b.cGoodsNO_minPackage,
    a.BeginQty=a.BeginQty*b.fQty_minPackage,
    a.EndQty=a.EndQty*b.fQty_minPackage 
from #temp_ready a,#tmpPackGoodsList b
where a.GoodsNo_Pdt=b.cGoodsNo

if (select OBJECT_ID('tempdb..#temp_readyFor1'))is not null drop table #temp_readyFor1
select GoodsNo_Pdt, 
BeginQty=SUM(BeginQty),EndDate,EndQty=SUM(EndQty) 
into #temp_readyFor1
from #temp_ready
group by GoodsNo_Pdt,EndDate

--select * from #temp_ready
select GoodsNo_Pdt=a.cGoodsNo,BeginQty,EndDate,EndQty
into #temp_ready1
from #tmpPloyOfGoodsinfo a left join #temp_readyFor1 c on c.GoodsNo_Pdt=a.cGoodsNo
,t_goods b 
where a.cGoodsNo=b.cGoodsNo
/*
select * from #tmpPloyOfGoodsinfo
select * from #temp_readyFor1
select * from #temp_ready
select * from #temp_ready1
*/
if(@date>=@date2)
begin 
	if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null 
	begin 
			insert into #temp_dateBaseForKuCun
			(cGoodsNo,EndQty)
			select GoodsNo_Pdt,EndQty=isnull(EndQty,0)
			from #temp_ready1 
	end

end
if (@date<@dDate )    
begin
--盘点信息
	-------期末前最新盘点日期-----------------------------------------------------
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	select a.cGoodsNo,dDate=MAX(b.dDate)
	into #templast_pd0
	from wh_CheckWhDetail a left join wh_CheckWh b
	on a.cSheetno=b.cSheetno 
	where dDate between @date1 and @date2 
	and isnull(bExamin,0)=1 
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmpPloyOfGoodsinfo)
	group by a.cGoodsNo order by a.cGoodsNo
	--select * from #templast_pd0
	-------期末前最新盘点日期+数量------------------------------------------------
	if(select object_id('tempdb..#templast_pd_num0')) is not null drop table #templast_pd_num0
	select a.cGoodsNO,a.dDate,fQuantity=sum(isnull(b.fQuantity,0)),fMoney=sum(isnull(b.fMoney,0))---wh_CheckWhDetail.fMoney在盘点单中为空，应该从成本分配表中取
	into #templast_pd_num0
	from #templast_pd0 a,
	(
		select x.cGoodsNO,x.fQuantity,x.fMoney,y.dDate
		from wh_CheckWhDetail x,wh_CheckWh y
		where x.cSheetno=y.cSheetno and y.cWhNo=@cWHno
	) b
	where a.dDate=b.dDate and a.cGoodsNo=b.cGoodsNo
	group by  a.cGoodsNO,a.dDate

	---日期、数量组合一起
	if(select object_id('tempdb..#templast_pd')) is not null drop table #templast_pd
	select a.*,fQuantity=isnull(b.fQuantity,0),dDateEnd=@date2,b.fMoney
	into #templast_pd
	from #templast_pd0 a left join #templast_pd_num0 b 
	on a.cGoodsNo=b.cGoodsNo and a.dDate=b.dDate

    declare @dMaxDailyDate datetime
    set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1
   -- if (@dMaxDailyDate-1)>=@date2 set @dMaxDailyDate=@date2+1

---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
--print  '01 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
/*	已日结商品t_SaleSheet_Day中取，未日结商品t_SaleSheetDetail中取*/

    -----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    
 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))


	 
	 exec p_x_salesABC_bySupplier_chen_WH_Ref @date1,@date2,@dMaxDailyDate,@cWHno
----------------**************************--------------------	 
	
 		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,
		---t_SaleSheet_Day b 
		#temp_SaleSheet_Day b
		where b.dSaleDate between @date1 and @date2
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo
		union all
		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		--from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b
		from #tmpPloyOfGoodsinfo a,#temp_salesheetDetail b
		where b.dSaleDate between @dMaxDailyDate and @date2 
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo

--print  '02 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		
		----正价销售iAttribute=20,特价21
		select dDateTime=b.dSaleDate,a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo
--select * from #temp_jiesuan_for_day

--print  '03 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
--select * from #GoodsCurStorageList

		--入库单统计开始 select * from wh_InWarehouse
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

	    union all
		select @date2,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
/*			select * from #GoodsCurStorageList where cGoodsNo='15525'
*/
--print  '04 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' ' +datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		--以上计算期末库存
/*---包装转单品*/
		--if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
		--select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
		--into #tmpPackGoodsList
		--from t_goods
		--where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money)		 
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsNo,cWhNo

  
 
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 
	 
 
if(@date<@dDate-1)
	Begin
	    update a
		set a.BeginQty=ISNULL(a.BeginQty,0)+isnull(b.EndQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0) 
		from #tmpGoodsListInfo_1 a,#temp_ready1 b
		where a.cGoodsNo=b.GoodsNo_Pdt 
				
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
			from (
				   select cGoodsNo,fQuantity from #templast_pd 
				   union all 
				   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
				   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
				 ) x
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		update #tmpGoodsListInfo_1
		set cWHno=@cWhNo,BeginQty=ISNULL(BeginQty,0),
		    EndQty=isnull(EndQty,0) 
		
	 
	end
		else
			Begin
			  update a
				set  a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0) from #tmpGoodsListInfo_1 a,#temp_ready1 b
				where a.cGoodsNo=b.GoodsNo_Pdt 
				
		 update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
			from (
				   select cGoodsNo,fQuantity from #templast_pd 
				   union all 
				   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
				   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
				 ) x
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		update #tmpGoodsListInfo_1
		set cWHno=@cWhNo,BeginQty=ISNULL(BeginQty,0),
		    EndQty=isnull(EndQty,0),
		    fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
 
			end
	 
/*
select sum(beginqty),sum(endqty) from #tmpGoodsListInfo_1
*/
 
	if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null 
	begin 
			insert into #temp_dateBaseForKuCun
			(cGoodsNo,EndQty)
			select cGoodsNo,EndQty=isnull(EndQty,0)
			from #tmpGoodsListInfo_1 
	end

end
 
 
update a
set a.fQty=b.EndQty
from #tmpQuerySingleGoods a,#temp_dateBaseForKuCun b
where a.cGoodsNo=b.cGoodsNo 

if(select object_id('tempdb..#tmpGoodsList')) is not null
begin
		 insert into #tmpGoodsList 
		 ( 
		  cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName, 
		  cSupNo,cSupName,fNormalPrice,fCkPrice,fQty 
		 ) 
		select cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName,cSupNo,cSupName,
		fNormalPrice,fCkPrice,fQty
		from #tmpQuerySingleGoods
end
GO
