
 
/*
--原来毛利脚本
if (select object_id('tempdb..#temp_Goods'))is not null
drop table #temp_Goods
-- 取相应类别下的商品。。。 				
 select cGoodsno into #temp_Goods from t_Goods
 where cGoodsno='01310087'
 
exec [p_x_salesABC_byGoods_log_TermID] '006','2016-9-5','2016-9-5','06',''
go
 
*/
 
CREATE procedure [dbo].[p_x_PloySalesABC_byGoods_log_TermID]
@cPloyNo varchar(64),
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cTermID varchar(32)
as  --查询某时段商品销售利润（含顾客退货）

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

 
if (select object_id('tempdb..#temp_PloyGoodsNo'))is not null drop table #temp_PloyGoodsNo
create table #temp_PloyGoodsNo(cGoodsNo varchar(32))
   insert into #temp_PloyGoodsNo(cGoodsNo)
   select distinct cGoodsNo 
   from t_PloyOfSale 
   where cPloyNo=@cPloyNo and dDateStart=@dDate1
 
 

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsno into #tmpCostGoodsList from t_cStoreGoods 
where cStoreNo=@cStoreNo

 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select  distinct cGoodsno into  #tmp_WhGoodsList  from (
select distinct b.cGoodsno  
from #tmpCostGoodsList a,t_goods b
where a.cGoodsno=b.cGoodsNo_minPackage
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsno  
from #tmpCostGoodsList a,t_goods b
where a.cGoodsno=b.cGoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))=''
union all
select distinct b.cGoodsNo_minPackage  
from #tmpCostGoodsList a,t_goods b
where a.cGoodsno=b.cGoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
) a

 
CREATE INDEX IX_tmp_WhGoodsList ON #tmp_WhGoodsList(cGoodsno)

declare  @cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cStoreNo=@cStoreNo-- cWhNo=@cWHno
 
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsno] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money,cStoreNo varchar(32))
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsno] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money,cStoreNo varchar(32))
  
/*快照表中的最大日期。。。*/
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)
insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock)  where cStoreNo='''+@cStoreNo+'''    ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

/*结转表中取数据*/
  
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd 
		set @maxWhdDate=@dDateBgn-1
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd


declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1  varchar(8)
declare @M_1  varchar(8)
declare @Day_1 varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1

	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
if @dDateBgn<=@maxWhdDate
begin 
		insert into #temp_WhFromend  ([cGoodsno],[cWHno]) 
		select cGoodsno,@cWhNo from  #tmp_WhGoodsList 
		
		CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsno)
		if @Y1<>@Y_1 
		begin
		    declare @bY1 varchar(8)
			declare @eY1  varchar(8)
			 
			set @bY1 =Year(@dDateBgn)
			set @eY1=Year(@maxWhdDate) 
			
			declare @bM1 varchar(8)
			declare @eM1  varchar(8)
			 
			set @bM1 =Month(@dDateBgn)
			set @eM1=Month(@maxWhdDate) 
			if LEN(@bM1)=1 
			begin
			   set @bM1='0'+@bM1
			end
			if LEN(@eM1)=1 
			begin
			   set @eM1='0'+@eM1
			end
			declare @tj varchar(8)
	        set @tj='0'
			if(@bY1<>@eY1)
			begin 
				set @tj='1'
			end else
			begin 
			    if @bM1=@eM1
			    begin
			    exec('		   
	   	            if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
					select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
					fQty0=b.fQty_010131,fQtytj0=b.fQtytj_010131
					into #temp_Wh_Goods_endQty
					from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@bM1+' b,#temp_WhFromend a
					with (nolock) 
					where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and b.cGoodsno=a.cGoodsno 
				 
 
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
					            
					select a.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
					Sale0=b.Sale_010131, Saletj0=b.Saletj_010131
					into #temp_Wh_Goods_endSale					
					from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@bM1+' b,#temp_WhFromend a
					with (nolock) 
					where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
					select cGoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1),fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
					into #temp_SumWh_Goods_endQty
					from  #temp_Wh_Goods_endQty
					group by cGoodsno
					
					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
					select cGoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0)  
					into #temp_SumWh_Goods_endSale
					from  #temp_Wh_Goods_endSale
					group by cGoodsno
					
					

					update a 
					set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
					a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
					a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0)	)				
					from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
					where a.cGoodsno=b.cGoodsno  
					 
					update a 
					set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
					a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
					a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))				     		
					from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
					where a.cGoodsno=b.cGoodsno  		
		         ')
				end else
				begin 
				  set @tj='1'
				end
			end
			if @tj='1'
			begin
			   insert into #temp_WhFrombegin([cGoodsno],[cWHno]) 
				select cGoodsno,@cWhNo from  #tmp_WhGoodsList 
	     		CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsno)
		     	
				exec ('
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
							select a.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
							into #temp_Wh_Goods_beginQty
							from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#temp_WhFrombegin a
							with (nolock) 
							where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno 
						 
		 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
							            
							select a.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
							into #temp_Wh_Goods_beginSale					
							from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#temp_WhFrombegin a
							with (nolock) 
							where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
							select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
							into #temp_SumWh_Goods_beginQty
							from  #temp_Wh_Goods_beginQty
							group by cGoodsno
							
							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
							select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
							into #temp_SumWh_Goods_beginSale
							from  #temp_Wh_Goods_beginSale
							group by cGoodsno
							
							

							update a 
							set a.销售数量0=b.fQty, 
							a.特价销售数量=b.fQtytj,
							a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
							from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
							where a.cGoodsno=b.cGoodsno  
							 
							update a 
							set a.销售金额0=b.Sale, 
							a.特价销售金额=b.Saletj,
							a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
							from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
							where a.cGoodsno=b.cGoodsno  
							')

				exec (' 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
							select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
							into #temp_Wh_Goods_endQty
							from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
							with (nolock) 
							where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno 
						 
		 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
							            
							select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
							into #temp_Wh_Goods_endSale					
							from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
							with (nolock) 
							where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
							select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
							into #temp_SumWh_Goods_endQty
							from  #temp_Wh_Goods_endQty
							group by cGoodsno
							
							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
							select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
							into #temp_SumWh_Goods_endSale
							from  #temp_Wh_Goods_endSale
							group by cGoodsno
							
							

							update a 
							set a.销售数量0=b.fQty, 
							a.特价销售数量=b.fQtytj,
							a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
							from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
							where a.cGoodsno=b.cGoodsno  
							 
							update a 
							set a.销售金额0=b.Sale, 
							a.特价销售金额=b.Saletj,
							a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
							from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
							where a.cGoodsno=b.cGoodsno  		  
				  
					')
				 
				update a 
				set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
				a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
				a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
				a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
				a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
				a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0)
				from #temp_WhFromend a,#temp_WhFrombegin b
				where a.cGoodsno=b.cGoodsno
			end
		end
		else
		begin 
		   if @M1=@M_1
		   begin
		     exec('		   
	   	            if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
					select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
					fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+' 
					into #temp_Wh_Goods_endQty
					from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_WhFromend a
					with (nolock) 
					where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno 
				 
 
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
					            
					select a.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
					Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'  
					into #temp_Wh_Goods_endSale					
					from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_WhFromend a
					with (nolock) 
					where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
					select cGoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1),fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
					into #temp_SumWh_Goods_endQty
					from  #temp_Wh_Goods_endQty
					group by cGoodsno
					
					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
					select cGoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0)  
					into #temp_SumWh_Goods_endSale
					from  #temp_Wh_Goods_endSale
					group by cGoodsno
					
					

					update a 
					set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
					a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
					a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0)	)				
					from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
					where a.cGoodsno=b.cGoodsno  
					 
					update a 
					set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
					a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
					a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))				     		
					from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
					where a.cGoodsno=b.cGoodsno  		
		   ')
		   end else
		   begin
		        insert into #temp_WhFrombegin([cGoodsno],[cWHno]) 
				select cGoodsno,@cWhNo from  #tmp_WhGoodsList 
	     		CREATE INDEX IX_temp_WhFrombegin0  ON #temp_WhFrombegin(cGoodsno)
		     	
				exec ('
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
							select a.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
							into #temp_Wh_Goods_beginQty
							from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#temp_WhFrombegin a
							with (nolock) 
							where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno 
						 
		 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
							            
							select a.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
							into #temp_Wh_Goods_beginSale					
							from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#temp_WhFrombegin a
							with (nolock) 
							where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
							select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
							into #temp_SumWh_Goods_beginQty
							from  #temp_Wh_Goods_beginQty
							group by cGoodsno
							
							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
							select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
							into #temp_SumWh_Goods_beginSale
							from  #temp_Wh_Goods_beginSale
							group by cGoodsno
							
							

							update a 
							set a.销售数量0=b.fQty, 
							a.特价销售数量=b.fQtytj,
							a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
							from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
							where a.cGoodsno=b.cGoodsno  
							 
							update a 
							set a.销售金额0=b.Sale, 
							a.特价销售金额=b.Saletj,
							a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
							from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
							where a.cGoodsno=b.cGoodsno  
							')

				exec (' 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
							select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
							into #temp_Wh_Goods_endQty
							from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
							with (nolock) 
							where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno 
						 
		 
							if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
							            
							select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
							into #temp_Wh_Goods_endSale					
							from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
							with (nolock) 
							where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsno=b.cGoodsno


							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
							select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
							into #temp_SumWh_Goods_endQty
							from  #temp_Wh_Goods_endQty
							group by cGoodsno
							
							if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
							select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
							into #temp_SumWh_Goods_endSale
							from  #temp_Wh_Goods_endSale
							group by cGoodsno
							
							
							update a 
							set a.销售数量0=b.fQty, 
							a.特价销售数量=b.fQtytj,
							a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
							from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
							where a.cGoodsno=b.cGoodsno  
							 
							update a 
							set a.销售金额0=b.Sale, 
							a.特价销售金额=b.Saletj,
							a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
							from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
							where a.cGoodsno=b.cGoodsno  		  
				  
					')
				 
				update a 
				set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
				a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
				a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
				a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
				a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
				a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0)
				from #temp_WhFromend a,#temp_WhFrombegin b
				where a.cGoodsno=b.cGoodsno
		   end
		end
end

	--- 取记账之前的数据... 
if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
create table #temp_ReadyKucun( cGoodsno varchar(32),cUnitedNo varchar(32),
xsQty money,xsMoney money,zxsQty money,zxsMoney money,txsQty money,txsMoney money,cWHno varchar(16))       
if 	@maxWhdDate<@dDateEnd
begin
	declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select isnull(MAX(dDate),'2000-01-01') from t_Daily_history where cStoreNo=@cStoreNo  )
	if @dMaxDailyDate>@dDate_2
	begin
	set @dMaxDailyDate=@dDate_2
	end
	
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
	select dSaleDate,cWHno,a.cGoodsno,iSeed,fQuantity,fLastSettle,bAuditing
	into #temp_cGoodsSaleDate from  t_SaleSheet_Day a,#tmp_WhGoodsList b
	with (nolock) 
	where dSaleDate between @dDate_1 and @dDate_2  and a.cStoreNo=@cStoreNo and a.cGoodsno=b.cGoodsno
	union all
	select dSaleDate,cWHno,a.cGoodsno,iSeed,fQuantity,fLastSettle,bAuditing 
	from t_SaleSheetDetail a,#tmp_WhGoodsList b
	with (nolock) 
	where dSaleDate>=@dDate_1 and dSaleDate between (@dMaxDailyDate+1) and @dDate_2 and a.cGoodsno=b.cGoodsno  
	 and a.cStoreNo=@cStoreNo 
 
	if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
	select a.cGoodsno,a.cGoodsNo_MinPackage,fQty_minPackage=isnull(a.fQty_minPackage,1)
	into #tmpPackGoodsList
	from t_goods a,#temp_cGoodsSaleDate b
	where a.cGoodsno=b.cGoodsno and a.cGoodsno<>isnull(a.cGoodsNo_minPackage,a.cGoodsno) 


	update a set a.cGoodsno=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
	from #temp_cGoodsSaleDate a,#tmpPackGoodsList b
	where a.cGoodsno=b.cGoodsno
	
 

	if (select OBJECT_ID('tempdb..#temp01'))is not null  drop table #temp01
	select cGoodsno,fqty=SUM(fQuantity),fmoney=SUM(fLastSettle),bAuditing into #temp01 
	from #temp_cGoodsSaleDate 
	group by cGoodsno,bAuditing

	insert into #temp_ReadyKucun(cGoodsno,xsQty,xsMoney,cWHno)
	select cGoodsno,fqty=SUM(fqty),fmoney=SUM(fmoney),@cWHno from #temp01 
	group by cGoodsno
		
    update a  set a.zxsQty=b.fqty,a.zxsMoney=b.fmoney
    from #temp_ReadyKucun a,#temp01 b
    where a.cGoodsno=b.cGoodsno and ISNULL(b.bAuditing,0)=0
    
     update a  set a.txsQty=b.fqty,a.txsMoney=b.fmoney
    from #temp_ReadyKucun a,#temp01 b
    where a.cGoodsno=b.cGoodsno and ISNULL(b.bAuditing,0)=1 
    
end
 
if (select OBJECT_ID('tempdb..#temp_ReadycGoodsHb'))is not null drop table #temp_ReadycGoodsHb
select [cGoodsno],[cWHno],xsQty=销售数量0,xsMoney=销售金额0,tjXsQty=特价销售数量,tjXsMoney=特价销售金额,
zjXsqty=正价销售数量,zjXsmoney=正价销售金额
into #temp_ReadycGoodsHb
from #temp_WhFromend	
union all
select cGoodsno,cWHno,xsQty,xsMoney,txsQty,txsMoney ,zxsQty,zxsMoney 
from #temp_ReadyKucun
 
-------2015-05-16----包装转换-------
update a
set a.cGoodsno=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1),
a.tjXsQty=a.tjXsQty*ISNULL(b.fQty_minPackage,1),
a.zjXsqty=a.zjXsqty*ISNULL(b.fQty_minPackage,1) 
from #temp_ReadycGoodsHb a,t_Goods b
where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''


if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null drop table #temp_goodsKuCun
select a.cGoodsNo,b.cGoodsName,b.fNormalPrice,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename,
xsQty=ISNULL(SUM(xsQty),0),xsMoney=ISNULL(SUM(xsMoney),0),tjXsQty=ISNULL(SUM(tjXsQty),0),
tjXsMoney=ISNULL(SUM(tjXsMoney),0), zjXsqty=ISNULL(SUM(zjXsqty),0),zjXsMoney=ISNULL(SUM(zjXsMoney),0),
BeginDate=@dDateBgn,EndDate=@dDateEnd,cGroupTypeNo=CAST(null as varchar(32)),cGroupTypeName=CAST(null as varchar(64)),
TypeZhanbi=CAST(null as money),GroupZhanbi=CAST(null as money),ZongZhanbi=CAST(null as money)
into #temp_goodsKuCun
from #temp_ReadycGoodsHb a,t_cStoreGoods b
where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
group by a.cGoodsNo,b.cGoodsName,b.fNormalPrice,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename

--策略时间段：总销售
declare @SalSumMoney money
set @SalSumMoney=(select SUM(xsMoney) from #temp_goodsKuCun)

-- #temp_PloyGoodsNo
if (select OBJECT_ID('tempdb..#temp_TypegoodsKuCun'))is not null drop table #temp_TypegoodsKuCun
select a.cGoodsNo,a.cGoodsTypeno,a.cGoodsTypename 
into #temp_TypegoodsKuCun
from t_Goods a,#temp_PloyGoodsNo b
where a.cGoodsNo=b.cGoodsNo

---获取类别总销售销售
if (select OBJECT_ID('tempdb..#temp_TypegoodsKuCunSale'))is not null drop table #temp_TypegoodsKuCunSale
select b.cGoodsTypeno,xsQty=ISNULL(SUM(xsQty),0),xsMoney=ISNULL(SUM(xsMoney),0) 
into #temp_TypegoodsKuCunSale
from #temp_goodsKuCun a,#temp_TypegoodsKuCun b
where a.cGoodsNo=b.cGoodsNo
group by b.cGoodsTypeno

--- 类别占比
update a
set a.TypeZhanbi=case when isnull(b.xsMoney,0)<>0 then (a.xsMoney/b.xsMoney)*100 else null end
from #temp_goodsKuCun a,#temp_TypegoodsKuCunSale b
where a.cGoodsTypeno=b.cGoodsTypeNo



--获取部组
-- #temp_PloyGoodsNo
if (select OBJECT_ID('tempdb..#temp_GroupTypegoodsKuCun'))is not null drop table #temp_GroupTypegoodsKuCun
select b.cGoodsNo,a.cGoodsTypeno,a.cGoodsTypename,a.cGroupTypeNo,a.cGroupTypeName
into #temp_GroupTypegoodsKuCun
from T_GroupType_GoodsType a,#temp_TypegoodsKuCun b
where a.cGoodsTypeNo=b.cGoodsTypeno


update a
set a.cGroupTypeNo=b.cGroupTypeNo,a.cGroupTypeName=b.cGroupTypeName
from #temp_goodsKuCun a,#temp_GroupTypegoodsKuCun b
where a.cGoodsTypeno=b.cGoodsTypeNo


if (select OBJECT_ID('tempdb..#temp_GroupTypegoodsKuCunSale'))is not null drop table #temp_GroupTypegoodsKuCunSale
select b.cGroupTypeNo,b.cGroupTypeName,xsQty=ISNULL(SUM(xsQty),0),xsMoney=ISNULL(SUM(xsMoney),0) 
into #temp_GroupTypegoodsKuCunSale
from #temp_goodsKuCun a,#temp_GroupTypegoodsKuCun b 
where a.cGoodsNo=b.cGoodsNo  
group by b.cGroupTypeNo,b.cGroupTypeName

--- 部组占比
update a
set a.GroupZhanbi=case when isnull(b.xsMoney,0)<>0 then (a.xsMoney/b.xsMoney)*100 else null end
from #temp_goodsKuCun a,#temp_GroupTypegoodsKuCunSale b
where a.cGroupTypeNo=b.cGroupTypeNo

--总占比
update #temp_goodsKuCun set  ZongZhanbi=case when isnull(@SalSumMoney,0)<>0 then (xsMoney/@SalSumMoney)*100 else null end

if (select OBJECT_ID('tempdb..#temp_GroupPloySale'))is not null drop table #temp_GroupPloySale
select a.cGoodsNo,a.cGoodsName,a.fNormalPrice,a.cBarcode,a.cUnit,a.cSpec,a.cGoodsTypeno,a.cGoodsTypename,
xsQty,xsMoney, 
BeginDate=@dDateBgn,EndDate=@dDateEnd,cGroupTypeNo,cGroupTypeName,TypeZhanbi,GroupZhanbi,ZongZhanbi
into #temp_GroupPloySale
from #temp_goodsKuCun a,#temp_PloyGoodsNo b
where a.cGoodsno=b.cGoodsNo
--@cPloyNo

select  a.cGoodsNo,a.cGoodsName,a.fNormalPrice,a.cBarcode,a.cUnit,a.cSpec,a.cGoodsTypeno,a.cGoodsTypename,
xsQty,xsMoney, 
b.dDateStart,b.dDateEnd,cGroupTypeNo,cGroupTypeName,TypeZhanbi,GroupZhanbi,ZongZhanbi,
b.fPrice_SO,ZXSMoney=@SalSumMoney
from #temp_GroupPloySale a,t_PloyOfSale b
where b.cPloyNo=@cPloyNo and a.cGoodsno=b.cGoodsNo


GO
