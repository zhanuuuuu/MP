
/*
use posmanagement
select * from dbo.v_LastCostOfGoods
*/
CREATE view v_LastCostOfGoods
as
select a.dDate,a.cGoodsNo,a.fProfitsRatio,a.fCurSalePrice,a.fCurCostPrice,a.cCooperate
from t_Goods_PRatio a,
		(
		select  cGoodsNo,lastDate=max(dDate) 
		from t_Goods_PRatio 
		group by cGoodsNo 
		) b
where a.cGoodsNo=b.cGoodsNo and a.dDate=b.lastDate

GO
