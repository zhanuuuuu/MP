/*
 
   update Posmanagement.dbo.temp_Goods_Vip_Sales
   set fQuantity=0,fLastSettle=0,vipCount=0,LkCount=0,dDate=null
   
   declare @return int
   exec p_GetGoodsCostSales_wei_Day_test '2016-1-24','11102608',@return output
   select @return
  
*/
CREATE  proc [dbo].[p_GetGoodsCostSales_wei_Day]
@dDate datetime,
@cGoodsNo varchar(32),
@return int output
as
begin
/*获取会员销售明细*/
 if Year(GETDATE()-3)=Year(@dDate)
 begin
   if MONTH(@dDate)<>MONTH(GETDATE()-3)
   begin
      -- print '不能调1'
      set @return=2
      
   end else
   begin
    --   print '可以调1'
  declare @dDateLog datetime
 set @dDateLog=(select MAX(dDate) from t_Daily_history where ISNULL(bAccount,0)=1)
 if  @dDate>@dDateLog
 begin
   set @return=2
 end else
 begin
declare @dDatebgn datetime
declare @dDateend datetime
set @dDatebgn=@dDate
set @dDateend=@dDate
if(select object_id('tempdb..#tmpGoodsRelationPrice')) is not null 
drop table #tmpGoodsRelationPrice
select cGoodsNO,cSupNo,NewFckprice
into #tmpGoodsRelationPrice
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice
where dDatetime=@dDate  and cGoodsNO=@cGoodsNo
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDatebgn-1)
set @strDateEnd=dbo.getdaystr(@dDateend)
set @strBgn=dbo.getdaystr(@dDatebgn)
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateend)
set @Day1=day(@dDateend)
set @Y1=YEAR(@dDateend)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDatebgn-1)
set @M_1=MONTH(@dDatebgn-1)
set @Day_1=day(@dDatebgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1

declare  @cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([cGoodsNo] [varchar](32) NOT NULL, 
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money,fmoney_cost money)
CREATE TABLE #temp_WhFromend   ([cGoodsNo] [varchar](32) NOT NULL, 
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money,fmoney_cost money)
  
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmpGoodsRelationPrice 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
  
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDatebgn-1)
	set @eY1=Year(@dDateend) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@dDateend) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
    
	if(@bY1<>@eY1)
	begin
	    set @tj='1'		
    end else
    begin
      if @bM1=@eM1
      begin
      exec('
		--------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+', 
		fQty0=b.fQty_010131
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+',  
		Sale0=b.Sale_010131
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty1=sum(fQty1), 
		fQty0=sum(fQty0)
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale1=sum(Sale1),Sale0=sum(Sale0)  
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0)
		select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0) 
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0)
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
						
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fMoney0=b.fMoneyIn_010131 	 					  					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fMoney1=sum(fMoney1),fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

		')
	  end else
	  begin 
	    set @tj='1'
	  end 	
    end
    
--    print dbo.getTimeStr(GETDATE())
--print 3
    if @tj='1'
    begin
        exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+'
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cgoodsno,cSupplierno,fQty=sum(fQty) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale)  
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno,cSupplierNo
			 
			 
			
			insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0)
			select cgoodsno,cSupplierNo,fQty
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale 	
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
							
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  
			drop table #temp_SumWh_Goods_beginCost
			select cgoodsno,cSupplierNo, fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cgoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		 
			') 
--print dbo.getTimeStr(GETDATE())
--print 4
		exec('
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cgoodsno,cSupplierno,fQty=sum(fQty) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno,cSupplierNo
			 
			 
			
			insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0)
			select cgoodsno,cSupplierNo,fQty
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale 				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
							
		----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cgoodsno,cSupplierNo,fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cgoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

			')

		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
		 
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0)
		 
		from #temp_WhFromend a left join #temp_WhFrombegin b
		on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    end
--    print dbo.getTimeStr(GETDATE())
--print 5
end else
begin
    if @M1=@M_1
    begin
	exec('
		--------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+', 
		fQty0=b.fQty_'+@MMDAY_1+' 
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', 
		Sale0=b.Sale_'+@MMDAY_1+' 
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty1=sum(fQty1), 
		fQty0=sum(fQty0) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale1=sum(Sale1),Sale0=sum(Sale0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0)
		select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0) 
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0) 
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
						
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fMoney0=b.fMoneyIn_'+@MMDAY_1+' 	 					  					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fMoney1=sum(fMoney1),fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0) 	
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

		')
	end else
	begin
	   exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+'  
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cgoodsno,cSupplierno,fQty=sum(fQty) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno,cSupplierNo
			 
			 
			
			insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0)
			select cgoodsno,cSupplierNo,fQty
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale 
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
							
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cgoodsno,cSupplierNo,fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cgoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		 
			') 

		exec('
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+'  
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from '+@cdbname+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cgoodsno,cSupplierno,fQty=sum(fQty) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno,cSupplierNo
			 
			 
			
			insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0)
			select cgoodsno,cSupplierNo,fQty
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale 	
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
							
		----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cgoodsno,cSupplierNo=b.cSupNo,fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cgoodsno,cSupplierNo,fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cgoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')

		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 		 
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0)
		from #temp_WhFromend a left join #temp_WhFrombegin b
		on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
		
	end	
end
----2016-01-25 调整
/*
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsNo,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,cSupplierNo
into #temp_goodsKuCunml
from #temp_WhFromend   

if (select OBJECT_ID('tempdb..#temp_goodsKuCunml_Day'))is not null  drop table #temp_goodsKuCunml_Day  
select a.cGoodsNo,a.fmoney_cost,a.xsQty,a.xsMoney,b.cSupNo,
fDiffMoney=ISNULL(a.fmoney_cost,0)-ISNULL(a.xsQty,0)*ISNULL(b.NewFckprice,0) 
into #temp_goodsKuCunml_Day 
from #temp_goodsKuCunml a,#tmpGoodsRelationPrice b
where a.cSupplierNo=b.cSupNo and a.cGoodsNo=b.cGoodsNO
begin try
begin tran

update a
set a.fDiffMoney=b.fDiffMoney,a.fMoney_Cost=b.fmoney_cost,a.fQty=b.xsQty,a.fMoneyxs=b.xsMoney
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#temp_goodsKuCunml_Day b
where a.dDateTime=@dDate and a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo


update a set bfDff=1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationPrice b
where dDateTime=@dDate and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
*/

if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsNo,xsQty=sum(销售数量0), xsMoney=sum(销售金额0),fMoney_Cost=SUM(fMoney_Cost)
into #temp_goodsKuCunml
from #temp_WhFromend   
group by cGoodsNo
/*  2016-01-29 调整
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml_Day'))is not null  drop table #temp_goodsKuCunml_Day  
select a.cGoodsNo,a.fmoney_cost,a.xsQty,a.xsMoney,b.cSupNo,
fDiffMoney=ISNULL(a.fmoney_cost,0)-ISNULL(a.xsQty,0)*ISNULL(b.NewFckprice,0) 
into #temp_goodsKuCunml_Day 
from #temp_goodsKuCunml a,#tmpGoodsRelationPrice b
where a.cGoodsNo=b.cGoodsNO
begin try
begin tran

update a
set a.fDiffMoney=b.fDiffMoney,a.fMoney_Cost=b.fmoney_cost,a.fQty=b.xsQty,a.fMoneyxs=b.xsMoney
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#temp_goodsKuCunml_Day b
where a.dDateTime=@dDate and a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo


update a set bfDff=1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationPrice b
where dDateTime=@dDate and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
update  temp_Goods_Vip_Sales set dDate=@dDate
 */
 if (select OBJECT_ID('tempdb..#temp_goodsKuCunml_Day'))is not null  drop table #temp_goodsKuCunml_Day  
select a.cGoodsNo,a.fmoney_cost,a.xsQty,a.xsMoney,b.cSupNo,
fDiffMoney=ISNULL(a.fmoney_cost,0)-ISNULL(a.xsQty,0)*ISNULL(b.NewFckprice,0) 
into #temp_goodsKuCunml_Day 
from #temp_goodsKuCunml a,#tmpGoodsRelationPrice b
where --a.cSupplierNo=b.cSupNo and 
a.cGoodsNo=b.cGoodsNO
--fDiffMoney money,fMoney_Cost money,fQty money,fMoneyxs money,bfDff bit
begin try
begin tran

update a
set a.fDiffMoney=b.fDiffMoney,a.fMoney_Cost=b.fmoney_cost,a.fQty=b.xsQty,a.fMoneyxs=b.xsMoney
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,
(select cGoodsNo,fDiffMoney=SUM(fDiffMoney),fmoney_cost=SUM(fmoney_cost),xsQty=SUM(xsQty),xsMoney=SUM(xsMoney) from #temp_goodsKuCunml_Day
group by cGoodsNo
) b
where a.dDateTime=@dDate and a.cGoodsNO=b.cGoodsNo --and a.cSupNo=b.cSupNo


update a set bfDff=1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationPrice b
where dDateTime=@dDate and a.cGoodsNO=b.cGoodsNO --and a.cSupNo=b.cSupNo

update  temp_Goods_Vip_Sales set dDate=@dDate

 commit tran
 set @return=1
end try
begin catch
rollback 
 set @return=0
end catch  
   end
 end
 end else
 begin
    set @return=2
 end
  
end
GO
