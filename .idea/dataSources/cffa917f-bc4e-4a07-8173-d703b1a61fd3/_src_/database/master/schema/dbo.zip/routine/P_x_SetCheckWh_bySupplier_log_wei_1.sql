 
/*

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods    where       csupno='1040'
union all
select cGoodsNo,cSupplierNo='6013' from t_Goods    where       cgoodsno='210122'

if (select object_id('tempdb..#temp_Supno')) is not null
    drop table #temp_Supno
 
    select cSupplierNo=cSupNo into #temp_Supno from t_supplier 
  if (select object_id('tempdb..#temp_Goods')) is not null
   drop table #temp_Goods
  Create Table #temp_Goods (cGoodsNo varchar(128),cProductNo varchar(128),cSupplierNo varchar(128))
   insert into #temp_Goods (cGoodsNo,cSupplierNo)
    select distinct a.cGoodsNo,b.cSupplierNo from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno where b.cSupplierNo in(select cSupplierNo from #temp_Supno )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupplierNo from #temp_Supno ))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where b.bStorage=1 and a.cSupno in(select cSupplierNo from #temp_Supno )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupplierNo from #temp_Supno ))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where isnull(a.bStorage,0)=1 and a.cSupno in(select cSupplierNo from #temp_Supno )
    
--- drop table ##temp_Kucun  2706244.7802
declare @bJiaGong bit
exec [P_x_SetCheckWh_bySupplier_log_wei]
'2014-1-1','2014-4-20','02' ,@bJiaGong

exec [P_x_SetCheckWh_bySupplier_log_wei_1]
'2014-2-15','2014-6-15','02' ,0
*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_bySupplier_log_wei_1]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32),/*是仓库No*/
@bJiaGong bit
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-04-02' set @dDateEnd='2012-04-02'  set @cWhNo='02' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods 

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsNo,cSupplierNo into #tmpCostGoodsList from #temp_Goods

/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct a.cGoodsNo,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=1 into  #tmp_WhGoodsList  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1
union all
select distinct a.cGoodsNo,a.cSupplierNo ,cGoodsNo_minPackage,fQty_minPackage,bbox=0
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,a.cSupplierNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1
 

 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)


declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money,fMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

/*2014-10-23如果查询期初的时间段超出记账日期时、数量取最后记账的*/
if @maxWhdDate<@dDateBgn 
begin
   set @dDateBgn=@maxWhdDate
   set @dDateEnd=@maxWhdDate
end


declare @dDate1 datetime
declare @dDate2 datetime
declare @i int
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
			        set @i=1
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=1
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 
		set @maxWhdDate=@dDateEnd
		set @dDateBgn=@dDateBgn
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
	--insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 
	--insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 

  if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

	CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
	CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
	   CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
		declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
    set @strDateEnd=dbo.getdaystr(@maxWhdDate)
    set @strBgn=dbo.getdaystr(@dDateBgn)
	--set @SQLstr= '
			exec('	  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
				select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,
				  b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				  b.Pos客退数量1, b.Pos客退金额1,
				  b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				  b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
					into #temp_Wh_Goods_begin
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo   
				  and b.cWHno='+@cWHno+'				  
				  union all             
				 select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				  b.Pos客退数量1, b.Pos客退金额1,
				  b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				  b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_left=0
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo  
				  and b.cWHno='+@cWHno+'
 
				  --select * from #temp_Wh_Goods_begin			  
				  			
		             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			         select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
					Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
					  本日库存数量=SUM(isnull(本日库存数量,0)), 
					   盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fMoney_left=sum(isnull(fMoney_left,0))
					   into #temp_SumWh_Goods_begin
						from #temp_Wh_Goods_begin
		              group by cgoodsno,cSupplierNo,cWHno		
	              
				  --update a 
				  --set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
				  --a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
				  --a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,
				  --a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
				  --a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
				  --a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
				  --a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
				  --a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
				  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
				  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
				  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
				  --a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
				  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
				  --a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1, 
				  -- a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
				  -- a.期初库存=b.本日库存数量,
				  -- a.fPrice_Avg=b.fPrice_Avg,
				  -- a.fmoney_cost=b.fmoney_cost,
				  -- fMoney_left=b.fMoney_left
				  --from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
				  --where a.cGoodsNo=b.cGoodsNo ---and b.业务日期='''+@strDateBgn+''' 
				  --and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'
				  
				   insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fMoney_left)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fMoney_left
				  from #temp_SumWh_Goods_begin
	 
				  
				 ')
	--set @SQLstr1='
				exec('  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
				  select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				  b.Pos客退数量1, b.Pos客退金额1,
				  b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				  b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
			     	into #temp_Wh_Goods_end
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateEnd+'''  and a.cGoodsNo=b.cGoodsNo 
				  and b.cWHno='+@cWHno+'				  
				  union all             
				 select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,
				 b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				  b.Pos客退数量1, b.Pos客退金额1,
				  b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				  b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,			
				   fMoney_left=0
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where  b.业务日期 between '''+@strDateBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo 
				  and b.cWHno='+@cWHno+'  and  b.iAttribute<>20	
				 
	             
	                 if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			         select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
					Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
					   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fmoney_left=sum(isnull(fmoney_left,0))					   
					   into #temp_SumWh_Goods_end
						from #temp_Wh_Goods_end
		              group by cgoodsno,cSupplierNo,cWHno		     
	 
	             
				  --update a
				  --set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
				  --a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
				  --a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,				 
				  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
				  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
				  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
				  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
				  --a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
				  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 				   
				  --a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
				  --a.期末库存=b.本日库存数量,
				  --a.fPrice_Avg=b.fPrice_Avg,
				  --a.fmoney_cost=b.fmoney_cost,
				  --a.fmoney_left=b.fmoney_left
				  --from #temp_WhFromend a ,#temp_SumWh_Goods_end b
				  --where a.cGoodsNo=b.cGoodsNo 				
				  --and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'
	 
	              insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fmoney_left)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fmoney_left
				  from #temp_SumWh_Goods_end
	 
				  -----------------获取时间段的入库数量--------------------
				  
				  	  if (select OBJECT_ID(''tempdb..#temp_IN_Goods_end''))is not null  drop table #temp_IN_Goods_end
	             select  cgoodsno,cSupplierNo,cWHno, Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  					  
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0))
					  into #temp_IN_Goods_end
	             from #temp_Wh_Goods_end
	             where dDatetime between '''+@strBgn+''' and '''+@strDateEnd+'''
	             group by  cgoodsno,cSupplierNo,cWHno
	                           
	             update a
	            set a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
				  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
				  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
				  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
				  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
				  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
	            from #temp_WhFromend a ,#temp_IN_Goods_end b
				  where a.cGoodsNo=b.cGoodsNo 				
				  and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'             
				')
	--exec (@SQLstr+@SQLstr1)

	-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
		 --- 结束日期数据-（开始日期-1）数据 得出时间段数据    
	     
		 --select * from #temp_WhFrombegin
		 --select * from #temp_WhFromend
	     
		 update a 
		 set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		 a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
				  a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
				  a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
				  a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
				  a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
				  a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
				  a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
				  a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
				  a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),				  
				  a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
				  a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
				  a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
				  a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
				  a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
				  a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
				  a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
				  a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),	
				  a.期初库存=isnull(b.期初库存,0), 
				  a.期末库存=isnull(a.期末库存,0), 
				  a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
				  a.fPrice_Avg=a.fPrice_Avg,
				  a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
				  a.fMoney_left=ISNULL(a.fMoney_left,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

--select * from #temp_WhFrombegin

--select * from #temp_WhFromend

	/*获取时间段的入库记录 日期以单据日期为判断。*/
 
	----------------上面从快照表中取出库存数据-------------------

  update a set a.cSupplier=b.cSupName
     from #temp_WhFromend a,t_supplier b
	 where a.cSupplierNo=b.cSupNo

--盘点信息
	-------期末前最新盘点日期-----------------------------------------------------
	----------期初日期的前的最大盘点日期。
	
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	--select a.cGoodsNo,dDate=MAX(b.dCheckTask)
	select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd0
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo 
	where b.dCheckTask<@dDateBgn
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmp_WhGoodsList)
	group by a.cGoodsNo
	order by a.cGoodsNo	
	
	----------期末日期的前的最大盘点日期。
	if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	--select a.cGoodsNo,dDate=MAX(b.dCheckTask)
	select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd1
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo 
	where b.dCheckTask between @dDateBgn and @dDateEnd
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmp_WhGoodsList)
	group by a.cGoodsNo
	order by a.cGoodsNo
	
	
	if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo=CONVERT(varchar(32),''),cSupName=CONVERT(varchar(32),'')
    into #templast_pdcGoodsNo
    from #templast_pd0
	union all
	select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo=CONVERT(varchar(32),''),cSupName=CONVERT(varchar(32),'')
	from #templast_pd1
	
       ---select * from #templast_pdcGoodsNo
	--select * from #templast_pd0_0
	--select * from #templast_pd1
		----- 修改盘点期初数量
		update a
		set a.BeginQty=b.fQuantity_Diff
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		----- 修改盘点期末数量
		update a
		set a.EndQty=b.fQuantity_Diff,
		a.fmoney_Diff=isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		
		update a
		set a.EndQty=isnull(a.EndQty,0)+isnull(b.fQuantity_Diff,0),
		a.fmoney_Diff=isnull(a.fmoney_Diff,0)+isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd1 b
		where a.cGoodsNo=b.cGoodsNo
		
	--select * from #templast_pdcGoodsNo
	
	   update a
	   set a.cSupplierNo=b.cSupNo,a.cSupName=b.cSupName
	   from #templast_pdcGoodsNo a,t_Goods b
	   where a.cGoodsNo=b.cGoodsNo
	   
	   
	   if(select object_id('tempdb..#temp_SupPdcGoodsno')) is not null drop table #temp_SupPdcGoodsno
	    select a.cGoodsNo,cWhNo=@cWhNo,a.cSupplierNo,a.cSupName,a.BeginQty,a.EndQty ,a.fmoney_Diff
	    into #temp_SupPdcGoodsno
	    from #templast_pdcGoodsNo a, (select distinct cGoodsNo,cSupplierNo from  #tmp_WhGoodsList)  b
	    where a.cSupplierNo=b.cSupplierNo and a.cGoodsNo=b.cGoodsNo
	    
	    
	    update #temp_SupPdcGoodsno set cSupplierNo='XXXXXX',cSupName='超市盘点'

	-------插入表--------
		insert into #temp_WhFromend(cGoodsNo,cWHno,cSupplierNo,cSupplier,期初库存,期末库存,fMoney_left)
		select distinct cGoodsNo,@cWhNo,cSupplierNo,cSupName,BeginQty,EndQty ,fmoney_Diff
		 from #temp_SupPdcGoodsno		
	   --from #templast_pdcGoodsNo		
	--select * from #temp_WhFromend
	
	      /*差价2014-10-18*/
    	 ---------获取时间段内的差价表。。---------
		 if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  
		 drop table #temp_wh_DiffPriceWarehouseDetail
		 select a.cGoodsNo,b.cWhNo,fMoney_diff=sum(a.fMoney_diff),fQuantity=sum(a.fQuantity),b.cSupplierNo
		 into #temp_wh_DiffPriceWarehouseDetail
		 from wh_DiffPriceWarehouseDetail a,wh_DiffPriceWarehouse b
		 where b.dDate<=@dDateEnd  and a.cSheetno=b.cSheetno
		 group by a.cGoodsNo,b.cWhNo ,b.cSupplierNo
		 
		 if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_diff '))is not null  
		 drop table #tmp_WhGoodsList_diff 
		 select distinct cGoodsNo,cSupplierNo,cwhno=@cWhNo into #tmp_WhGoodsList_diff from  #temp_WhFromend 
		
	    if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null  
	    drop table #temp_wh_DiffPricecGoodsNo
		select  a.cGoodsNo,a.cWhNo,a.fMoney_diff,a.fQuantity ,a.cSupplierNo
		into #temp_wh_DiffPricecGoodsNo 
		from #temp_wh_DiffPriceWarehouseDetail a,#tmp_WhGoodsList_diff b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cwhno and a.cSupplierNo=b.cSupplierNo

	update a set a.fMoney_left=a.fMoney_left-b.fMoney_diff
	from #temp_WhFromend a,#temp_wh_DiffPricecGoodsNo b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	
	 /*2014-10-02修改数量、大小包装*/
	 
	 update a 
	 set a.cGoodsNo=b.cGoodsNo_minPackage,
	 a.入库数量1=a.入库数量1*b.fQty_minPackage,a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,
	 a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.销售数量0=a.销售数量0*b.fQty_minPackage,
     a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
     a.本日库存数量=a.本日库存数量*b.fQty_minPackage,a.期初库存=a.期初库存*b.fQty_minPackage,
     a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,
     a.出库数量0=a.出库数量0*b.fQty_minPackage,
     a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
     a.期末库存=a.期末库存*b.fQty_minPackage,
     a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,
     a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage,
     a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage
	 from #temp_WhFromend  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
	 where a.cGoodsNo=b.cGoodsNo 
	 
	 
	 if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
     select cGoodsNo,cSupplierNo,cSupName=cSupplier,
		  入库数量1=SUM(入库数量1), 入库金额1=SUM(入库金额1), 
		   Pos客退数量1=SUM(Pos客退数量1), Pos客退金额1=SUM(Pos客退金额1), 
		  退货入库数量1=SUM(退货入库数量1), 退货入库金额1=SUM(退货入库金额1),   
		  出库数量0=SUM(出库数量0), 出库金额0=SUM(出库金额0), 
		  返厂数量0=SUM(返厂数量0), 返厂金额0=SUM(返厂金额0), 
		  报溢数量1=SUM(报溢数量1), 
		  调拨入库数量1=SUM(调拨入库数量1), 调拨出库数量0=SUM(调拨出库数量0), 
		  原料出库数量0=SUM(原料出库数量0), 报损数量0=SUM(报损数量0), 
		  销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
		  特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
		  正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额), 
		  本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 
		  fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost) ,
		  fMoney_Diff=SUM(fMoney_Diff)
         into #temp_goodsKuCun_1
         from   #temp_WhFromend
         group by cGoodsNo,cSupplierNo,cSupplier
	
	
    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
    select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.fCKPrice,
      b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo,a.cSupName,
      BeginDate=@dDateBgn,EndDate=@dDateEnd,
	  入库数量1, 入库金额1, Pos客退数量1, Pos客退金额1, 退货入库数量1, 退货入库金额1,   
	  报溢数量1,出库数量0, 出库金额0, 返厂数量0, 返厂金额0,  销售数量0, 销售金额0,
	  调拨入库数量1,调拨出库数量0, 原料出库数量0,报损数量0,
	  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 
	  本日库存数量,  期初库存,期末库存,fMoney_left,fmoney_cost, 
	  fprice_in=case when ISNULL(a.销售数量0,0)=0 
		then b.fPrice_Contract
		else fmoney_cost/销售数量0 end,
		fProfitRatio_avg=case when isnull(销售金额0,0)<>0 then (isnull(销售金额0,0)-isnull(fmoney_cost,0))/isnull(销售金额0,0)*100 else null end ,
         xsQty=isnull(销售数量0,0),xsMoney=isnull(销售金额0,0)
        into  #temp_goodsKuCun
	  from #temp_goodsKuCun_1 a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo  ---and isnull(销售数量0,0)<>0
	  order by a.cGoodsNo
	  
	  
	--select cGoodsNo,rk=sum(入库数量1), ck=sum(出库数量0), fc=sum(返厂数量0),xs=sum(销售数量0),bgn=sum(期初库存),qend=sum(期末库存)  
	--into ##temp_Kucun
	--from #temp_goodsKuCun
	--  group by cGoodsNo
	  
if(select object_id('tempdb..#temp_SupplierNo')) is not null 
begin	 
      if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last 
   select GoodsNo_Pdt=a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.fCKPrice,a.cGoodsTypeno,
       a.cGoodsTypename,a.bProducted,a.cProductNo,
       a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
       rkQty=isnull(a.入库数量1,0), rkMoney=isnull(a.入库金额1,0), thrQty=ISNULL(a.Pos客退数量1,0), thrMoney=isnull(a.Pos客退金额1,0), 
	  ckQty=isnull(a.出库数量0,0), ckMoney=isnull(a.出库金额0,0), 
	  fcQty=isnull(a.返厂数量0,0), fcMoney=isnull(a.返厂金额0,0),-- fquanty=isnull(本日库存数量,0),  
	  BeginQty=isnull(a.期初库存,0),EndQty=isnull(a.期末库存,0),a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fprice_in*xsQty,0),
         a.fprice_in,
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,fCostPrice=isnull(a.fprice_in,0),
         fML=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0), fCKPriceMoney=a.fCKPrice*isnull(a.期末库存,0),
         avgInPriceMoney=isnull(a.fMoney_left,0),fNormalPriceMoney=a.fNormalPrice*isnull(a.期末库存,0),i=1
         into #temp_goodsKuCun_last
  from #temp_goodsKuCun a,#temp_SupplierNo b
  where  a.cSupplierNo=b.cSupplierNo 
      
      
   select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,fCKPrice,cGoodsTypeno,
   cGoodsTypename,bProducted,cProductNo,
   BeginDate,EndDate,cSupplierNo,cSupName,xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
    rkQty=isnull(rkQty,0), rkMoney=isnull(rkMoney,0), thrQty=ISNULL(thrQty,0), thrMoney=isnull(thrMoney,0), 
	  ckQty=isnull(ckQty,0), ckMoney=isnull(ckMoney,0), 
	  fcQty=isnull(fcQty,0), fcMoney=isnull(fcMoney,0),-- fquanty=isnull(本日库存数量,0),  
	  BeginQty=isnull(BeginQty,0),EndQty=isnull(EndQty,0),fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(fMoney_Profit_sum,0),
         fProfitRatio_avg,fCostPrice=isnull(fprice_in,0),
         fML=isnull(xsMoney,0)-isnull(fMoney_Cost,0), fCKPriceMoney=isnull(fCKPriceMoney,0),
         avgInPriceMoney=isnull(avgInPriceMoney,0),fNormalPriceMoney=isnull(fNormalPriceMoney,0),i=1
  from #temp_goodsKuCun_last
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,fCKPrice=null,cGoodsTypeno='合计:',
  cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
          rkQty=sum(isnull(rkQty,0)), rkMoney=sum(isnull(rkMoney,0)), 
	   thrktQty=sum(ISNULL(thrQty,0)), thrMoney=sum(isnull(thrMoney,0)), 
	  ckQty=sum(isnull(ckQty,0)), ckMoney=sum(isnull(ckMoney,0)),  
	  fcQty=sum(isnull(fcQty,0)), fcMoney=sum(isnull(fcMoney,0)), 
	  BeginQty=sum(isnull(BeginQty,0)),EndQty=sum(isnull(EndQty,0)),
         fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0)),
         fCKPriceMoney=sum(isnull(fCKPriceMoney,0)),
         avgInPriceMoney=sum(isnull(avgInPriceMoney,0)),
         fNormalPriceMoney=sum(isnull(fNormalPriceMoney,0)),i=2
  from #temp_goodsKuCun_last 
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,fCKPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
         rkQty=sum(isnull(rkQty,0)), rkMoney=sum(isnull(rkMoney,0)), 
	   ktQty=sum(ISNULL(thrQty,0)), ktMoney=sum(isnull(thrMoney,0)), 
	  ckQty=sum(isnull(ckQty,0)), ckMoney=sum(isnull(ckMoney,0)),  
	  fcQty=sum(isnull(fcQty,0)), fcMoney=sum(isnull(fcMoney,0)), 
	  BeginQty=sum(isnull(BeginQty,0)),EndQty=sum(isnull(EndQty,0)),
         fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end , 
         fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0)),
         fCKPriceMoney=sum(isnull(fCKPriceMoney,0)),
         avgInPriceMoney=sum(isnull(avgInPriceMoney,0)),
         fNormalPriceMoney=sum(isnull(fNormalPriceMoney,0)),i=3
  from #temp_goodsKuCun_last
  group by BeginDate,EndDate
  order by cSupplierNo,GoodsNo_Pdt,cGoodsTypeno
end else
begin
      select GoodsNo_Pdt=cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,fCKPrice,cGoodsTypeno,
   cGoodsTypename,bProducted,cProductNo,
   BeginDate,EndDate,cSupplierNo,cSupName,xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
    rkQty=isnull(入库数量1,0), rkMoney=isnull(入库金额1,0), thrQty=ISNULL(Pos客退数量1,0), thrMoney=isnull(Pos客退金额1,0), 
	  ckQty=isnull(出库数量0,0), ckMoney=isnull(出库金额0,0), 
	  fcQty=isnull(返厂数量0,0), fcMoney=isnull(返厂金额0,0),-- fquanty=isnull(本日库存数量,0),  
	  BeginQty=isnull(期初库存,0),EndQty=isnull(期末库存,0),fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fprice_in*xsQty,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,fCostPrice=isnull(fprice_in,0),
         fML=isnull(xsMoney,0)-isnull(fMoney_Cost,0), fCKPriceMoney=fCKPrice*isnull(期末库存,0),
         avgInPriceMoney=isnull(fMoney_left,0),fNormalPriceMoney=fNormalPrice*isnull(期末库存,0),i=1
  from #temp_goodsKuCun
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,fCKPrice=null,cGoodsTypeno='合计:',
  cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
          rkQty=sum(isnull(入库数量1,0)), rkMoney=sum(isnull(入库金额1,0)), 
	   thrktQty=sum(ISNULL(Pos客退数量1,0)), thrMoney=sum(isnull(Pos客退金额1,0)), 
	  ckQty=sum(isnull(出库数量0,0)), ckMoney=sum(isnull(出库金额0,0)),  
	  fcQty=sum(isnull(返厂数量0,0)), fcMoney=sum(isnull(返厂金额0,0)), 
	  BeginQty=sum(isnull(期初库存,0)),EndQty=sum(isnull(期末库存,0)),
         fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0)),
         fCKPriceMoney=sum(fCKPrice*isnull(期末库存,0)),
         avgInPriceMoney=sum(isnull(fMoney_left,0)),
         fNormalPriceMoney=sum(fNormalPrice*isnull(期末库存,0)),i=2
  from #temp_goodsKuCun 
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,fCKPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
         rkQty=sum(isnull(入库数量1,0)), rkMoney=sum(isnull(入库金额1,0)), 
	   ktQty=sum(ISNULL(Pos客退数量1,0)), ktMoney=sum(isnull(Pos客退金额1,0)), 
	  ckQty=sum(isnull(出库数量0,0)), ckMoney=sum(isnull(出库金额0,0)),  
	  fcQty=sum(isnull(返厂数量0,0)), fcMoney=sum(isnull(返厂金额0,0)), 
	  BeginQty=sum(isnull(期初库存,0)),EndQty=sum(isnull(期末库存,0)),
         fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end , 
         fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0)),
         fCKPriceMoney=sum(fCKPrice*isnull(期末库存,0)),
         avgInPriceMoney=sum(isnull(fMoney_left,0)),
         fNormalPriceMoney=sum(fNormalPrice*isnull(期末库存,0)),i=3
  from #temp_goodsKuCun
  --where xsQty<>0 and xsMoney<>0 ----2012-05-04修改,屏蔽无销售
  group by BeginDate,EndDate
  order by cSupplierNo,cGoodsNo,cGoodsTypeno
end

	 /*删除临时表*/
	  	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
      
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	       if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
/*
select cGoodsNo,cSupplierNo,
	  入库数量1, 入库金额1, 
	   Pos客退数量1, Pos客退金额1, 
	  --退货入库数量1, 退货入库金额1,   
	  --出库数量0, 出库金额0, 
	  返厂数量0, 返厂金额0, 
	  销售数量0, 销售金额0, 
	  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 
	  本日库存数量,  期初库存,期末库存 --into ##temp1 
	  from #temp_WhFromend 
	--  where cGoodsNo='140797'
*/

--select @dDate1,@dDate2,@maxWhdDate,@dDateEnd


-- where cGoodsNo='140797'
GO
