
/*
负毛利查询
p_GoodsRatioFind_chen_limit '',''
*/
CREATE proc [dbo].[p_GoodsRatioFind_chen_limit]
@cStoreNo varchar(32),
@Value money
as

 

if @Value is null set @Value=0
if ltrim(rtrim(@Value))='' set @Value=0
if (select OBJECT_ID('tempdb..#tmpGoodsSupRatioHAndL'))is not null
drop table #tmpGoodsSupRatioHAndL
select cGoodsNo,cSupplierNo,fPrice_H=MAX(fPrice_in),fPrice_L=Min(fPrice_in),
fPrice_avg=avg(fPrice_in)
into #tmpGoodsSupRatioHAndL
from T_WH_Form_Log
where cSheetNo=@cStoreNo and
cGoodsNo in (select cGoodsNo from t_Goods where cGoodsTypeNo in (select cGoodsTypeNo from  #tmpGoodstype_list))
group by cGoodsNo,cSupplierNo


select id=ROW_NUMBER()over(order by a.cGoodsNo,a.cSupNo,a.cGoodsTypeno),
a.cGoodsNo,a.cGoodsName,a.cGoodsTypeno,a.cGoodsTypename,
a.cSupNo,a.cSupName,a.cUnit,a.cSpec,a.cBarcode,
a.fNormalPrice,fPrice_h=isnull(b.fPrice_h,a.fCKPrice),fPrice_L=isnull(b.fPrice_L,a.fCKPrice),
fPrice_avg=isnull(b.fPrice_avg,a.fCKPrice)
from t_goods a left join #tmpGoodsSupRatioHAndL b
on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupplierNo
where a.fNormalPrice>0 and (a.fNormalPrice-isnull(b.fPrice_avg,a.fCKPrice))/a.fNormalPrice*100<@Value
or a.fNormalPrice<=0
order by a.cGoodsNo,a.cSupNo,a.cGoodsTypeno
GO
