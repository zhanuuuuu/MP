
/*
[eReport002x]
'2012-08-01','2012-08-30','01'
*/
CREATE procedure [dbo].[eReport002x]
@date1 datetime,
@date2 datetime,
@cWhNo varchar(32)
as

----获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @cWhNo varchar(32)
--select @date1='2011-11-01',@date2='2011-11-30',@cWhNo='01'

declare @strDate varchar(100)
declare @strDatePre varchar(100)
set @strDate=convert(varchar(100),@date1,23)+'至'+convert(varchar(100),@date2,23)

if(select object_id('tempdb..#tempLeaf')) is not null 	drop table 	#tempLeaf
select cGoodsTypeNo,cGoodsTypeName,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) 
into #tempLeaf
from t_GoodsType
update #tempLeaf set cpath=cParentNo+'.'+cGoodsTypeNo

declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #tempLeaf a left join #tempLeaf b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
end
select cGoodsTypeNo,cGoodsTypename,cPath,iLevel
into #tempGoodsTypePath
from #tempLeaf 

/*以上形成类别列表*/
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null
update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null

print  '02 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())

if(select object_id('tempdb..#temp_dateBase')) is not null drop table  #temp_dateBase
if(select object_id('tempdb..#temp_dateFrist')) is not null drop table  #temp_dateFrist
if(select object_id('tempdb..#temp_dateEnd')) is not null drop table  #temp_dateEnd
create table #temp_dateBase
(cGoodsNo varchar(64),cUnitedNo varchar(64),cGoodsName varchar(64),cBarcode varchar(64),cUnit varchar(64),cSpec varchar(64),
fNormalPrice money,cGoodsTypeno varchar(64),cGoodsTypename varchar(64),bProducted bit,cProductNo varchar(64),
BeginDate datetime,EndDate datetime,cSupplierNo varchar(64),cSupName varchar(64),fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money)

--查毛利
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select distinct cGoodsNo into #temp_Goods from t_goods
exec [p_maoli_byGoodsType_for_select] 
@date1,@date2,@cWhNo

select * into #temp_dateFrist
from #temp_dateBase

drop table #temp_dateBase

select dSaleDate=EndDate,cGoodsNo,cGoodsTypeNo,cGoodsTypeName,
fQuantity=xsQty,fLastSettle=xsMoney,fCostPrice,fMoneyCost=fMoney_Cost
into #TmpGoodsBaseInfo
from #temp_dateFrist 


if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null drop table  #temp_dateBaseForKuCun
if(select object_id('tempdb..#temp_ForKuCun')) is not null drop table  #temp_ForKuCun
create table #temp_dateBaseForKuCun
(cGoodsNo varchar(64),cGoodsTypeno varchar(64),EndQty money)
--查库存
declare @bJiaGong bit
exec [p_kucun_byGoodsType_for_select] 
@date1,@date2,@cWhNo

select * into #temp_ForKuCun
from #temp_dateBaseForKuCun

drop table #temp_dateBaseForKuCun

select * 
into #GoodsCurStorageList
from #temp_ForKuCun

print  '03 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())

-------------------------------------------客单价,合计
if(select object_id('tempdb..#kdj')) is not null  drop table #kdj
select period_hour=CAST(datepart(hh,jstime) as varchar(4)),sheet_count=COUNT(distinct sheetno),
shishou_count=SUM(isnull(shishou,0)),
price_PerClient=SUM(isnull(shishou,0))/case when COUNT(distinct sheetno)<>0 then COUNT(distinct sheetno) else null end 
into #kdj
from jiesuan
where zdriqi between @date1 and @date2
group by datepart(hh,jstime)
order by datepart(hh,jstime)

if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null drop table #tmpGoodsType_byLevel
select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
a.iLevel,a.bLeaf
into #tmpGoodsType_byLevel
from #TmpGoodsLevel a,#GoodsType b
where a.iLevel=1
and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null drop table #tmpGoods_byLevel 
select a.dSaleDate,cGoodsTypeNo=b.BaseGoodsTypeNo,cGoodsTypeName=null,jinjia=a.fMoneyCost,a.fLastSettle,
b.iLevel,b.bLeaf,cParentTypeNo=cast(null as varchar(32))
into #tmpGoods_byLevel
from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
where a.cGoodsTypeNo=b.LeafGoodsTypeNo

update a
set a.cParentTypeNo=b.cParentNo
from #tmpGoods_byLevel a,t_goodsType b
where a.cGoodsTypeNo=b.cGoodsTypeNo

if (select object_id('tempdb..#tmpGoods_byLevelOne'))is not null drop table #tmpGoods_byLevelOne
if (select object_id('tempdb..#tmpGoods0'))is not null drop table #tmpGoods0
-------------查询合计(全部)
select dSaleDate=@strDate,cParentTypeNo,jinjia=SUM(ISNULL(jinjia,0)),fLastSettle=sum(isnull(fLastSettle,0))	
into #tmpGoods_byLevelOne
from #tmpGoods_byLevel
where dSaleDate between @date1 and @date2
group by cParentTypeNo
    
---------------select * from #tmpGoods_byLevelOne
--个类别占比
select dSaleDate=@strDate,cGoodsTypeNo,cGoodsTypeName=null,jinjia=SUM(ISNULL(jinjia,0)),
       fLastSettle=sum(isnull(fLastSettle,0)),iLevel,bLeaf,cParentTypeNo
into #tmpGoods0
from #tmpGoods_byLevel
where dSaleDate between @date1 and @date2
group by cGoodsTypeNo,iLevel,bLeaf,cParentTypeNo
    
if (select object_id('tempdb..#tmpGoodsSaleByTypeByPir_1'))is not null drop table #tmpGoodsSaleByTypeByPir_1
select a.dSaleDate,a.cGoodsTypeno,c.cGoodsTypeName,a.jinjia,a.fLastSettle,huanbi=a.iLevel,
       a.iLevel,a.bLeaf,a.cParentTypeNo,maoli=0,zbl=null
into #tmpGoodsSaleByTypeByPir_1
from #tmpGoods0 a left join #tmpGoods_byLevelOne b
on a.dSaleDate=b.dSaleDate and a.dSaleDate=@strDate and a.cParentTypeNo=b.cParentTypeNo 
left join t_goodsType c
on a.cGoodsTypeNo=c.cGoodsTypeno
where a.dSaleDate=@strDate
    
update a
set 
maoli=(isnull(fLastSettle,0) - jinjia),
zbl=(isnull(fLastSettle,0) - jinjia)*100/case when isnull(fLastSettle,0)<>0 then fLastSettle*1.000 else null end
from #tmpGoodsSaleByTypeByPir_1 a

declare @sale_all money
select @sale_all=SUM(fLastSettle) from #tmpGoodsSaleByTypeByPir_1
update a
set a.huanbi=fLastSettle/@sale_all*100
from #tmpGoodsSaleByTypeByPir_1 a
		
if (select object_id('tempdb..#kucun'))is not null drop table #kucun 
select a.cGoodsTypeNo,fQuantity=SUM(fQuantity) 
into #kucun
from (
		  select cGoodsTypeNo=b.BaseGoodsTypeNo,a.fQuantity
		  from (
				 select cGoodsTypeno,fQuantity=SUM(EndQty) 
				 from #GoodsCurStorageList 
                 group by cGoodsTypeno
		 ) a, #tmpGoodsType_byLevel b
		 where a.cGoodsTypeNo=b.LeafGoodsTypeNo
     )a group by cGoodsTypeNo
     
     
if(select object_id('tempdb..#px')) is not null  drop table #px
select a.cGoodsTypeno,a.px,num=cast(b.num as real),品项率=cast(null as real) into #px from 
(
	select a.cGoodsTypeno,px=count(a.cgoodsno)from (
	select distinct a.cGoodsTypeno,a.cgoodsno
	from #TmpGoodsBaseInfo a 
	)a GROUP BY cGoodsTypeno
)a left join (
	select distinct cGoodsTypeno,num=count(cGoodsNo)
	from  t_goods 
	GROUP BY cGoodsTypeno
) b 
on a.cGoodsTypeno=b.cGoodsTypeno
		

if(select object_id('tempdb..#px1')) is not null  drop table #px1
select a.BaseGoodsTypeNo,px=sum(a.px),num=sum(a.num),a.品项率 
into #px1 from (
select b.BaseGoodsTypeNo,a.* from #px a, #tmpGoodsType_byLevel b
where a.cGoodsTypeno=b.LeafGoodsTypeNo
)a group by a.BaseGoodsTypeNo,a.品项率
	    
update a 
set 品项率=round(px/num*100,2)
from #px1 a 
		
	    
if (select object_id('tempdb..#tmpGoodsSaleByTypeByPir_2'))is not null drop table #tmpGoodsSaleByTypeByPir_2 
select d.*,c.num,c.品项率 into #tmpGoodsSaleByTypeByPir_2 from 
(select a.*,fQuantity=cast(b.fQuantity as varchar(32))--,c.num,c.品项率
from #tmpGoodsSaleByTypeByPir_1 a  left join  #kucun b 
on a.cGoodsTypeNo=b.cGoodsTypeNo) d ,
 #px1 c where d.cGoodsTypeNo=c.BaseGoodsTypeNo

if (select object_id('tempdb..#tmpGoodsSaleByTypeByPir_3'))is not null drop table #tmpGoodsSaleByTypeByPir_3
select dSaleDate,cGoodsTypeNo,cGoodsTypename,
jinjia=CAST(round(jinjia,2) as varchar(32)),fLastSettle=CAST(round(fLastSettle,2) as varchar(32)),
huanbi=cast(round(huanbi,2) as varchar(32))+'%',
maoli=CAST(round(maoli,2) as varchar(32)),zbl=cast(round(zbl,2) as varchar(32))+'%',
fQuantity= case when fQuantity IS null then '不管理库存' else CAST(round(fQuantity,2) as varchar(32)) end,
num,品项率=CAST(品项率 as varchar(32))+'%'
into #tmpGoodsSaleByTypeByPir_3
from #tmpGoodsSaleByTypeByPir_2 

if(select OBJECT_ID('tempdb..#temp_jiesuan_Count')) is not null drop table #temp_jiesuan_Count
create table #temp_jiesuan_Count(sheet_Count varchar(32),zdriqi datetime,sheetno varchar(64))

exec p_jiesuan_Num @date1,@date2

select *
from #tmpGoodsSaleByTypeByPir_3 
union all 
--select '','',sheet_count='来客人数：'+cast(COUNT(distinct sheetno) as varchar(32)),'',
--shishou_count='销售金额：'+cast(@sale_all as varchar(32)),
--price_PerClient='客单价：'+cast((@sale_all/case when COUNT(distinct sheetno)<>0 then COUNT(distinct sheetno) else null end) as varchar(32)) 
--,'','','',null,''
--from jiesuan 
--where zdriqi between @date1 and @date2


select '','',sheet_count='来客人数：'+cast(COUNT(distinct sheetno) as varchar(32)),'',
shishou_count='销售金额：'+cast(@sale_all as varchar(32)),
price_PerClient='客单价：'+cast((@sale_all/case when COUNT(distinct sheetno)<>0 then COUNT(distinct sheetno) else null end) as varchar(32)) 
,'','','',null,''
from #temp_jiesuan_Count
where zdriqi between @date1 and @date2

--select SUM(isnull(fLastSettle,0)) from #tmpGoodsSaleByTypeByPir_1
--select cast(COUNT(distinct sheetno) as varchar(32)) from jiesuan where zdriqi between @date1 and @date2

/*
[eReport002]
'2012-01-01','2012-03-31','01'
*/
GO
