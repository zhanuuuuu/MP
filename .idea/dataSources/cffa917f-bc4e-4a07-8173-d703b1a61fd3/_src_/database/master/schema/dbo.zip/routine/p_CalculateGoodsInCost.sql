
CREATE  procedure p_CalculateGoodsInCost
@date_till datetime
as
begin
	select a.cSheetno,a.cGoodsNo,a.fInMoney,a.fQuantity,b.dDate
  into #tempInWarehouseDetail
	from dbo.wh_InWarehouseDetail a
	left join dbo.wh_InWarehouse b
	on a.cSheetno=b.cSheetNo
	where a.cSheetno is not null and b.cSheetno is not null
				and dDate<=@date_till
	union all
	select a.cSheetno,a.cGoodsNo,-a.fInMoney,-a.fQuantity,b.dDate
	from dbo.wh_RbdWarehouseDetail a
	left join dbo.wh_RbdWarehouse b
	on a.cSheetno=b.cSheetNo
	where a.cSheetno is not null and b.cSheetno is not null
				and dDate<=@date_till

  select cGoodsNo,Qty=isnull(sum(isnull(fQuantity,0)),0), fInMoney=isnull(sum(isnull(fInMoney,0)),0)
  into #tempInWarehouseDetail_Sum
  from #tempInWarehouseDetail 
	group by cGoodsNo
--print '1'
  select cGoodsNo,GoodsNo_pdt,Quotiety=Qty
	into #tempGoodsProduct_R
	from v_Goods_Relation
--print '2'
	select a.cGoodsNo,b.GoodsNo_pdt,Qty=isnull(a.Qty*b.Quotiety,0),fInMoney=isnull(a.fInMoney,0)
  into #tempIN_Pdt
	from #tempInWarehouseDetail_Sum a
	left join #tempGoodsProduct_R b
	on a.cGoodsNo=b.cGoodsNo

  select cGoodsNo=GoodsNo_pdt,Qty=isnull(sum(Qty),0),fInMoney=isnull(sum(fInMoney),0),avgCostPrice=CAST(0.00 AS MONEY)
  into #TempIN_Return
	from #tempIN_Pdt
	group by GoodsNo_pdt


  update #TempIN_Return set avgCostPrice=round(fInMoney/case when Qty<>0 then Qty
																									      else 1.0000
																									      end,	
                                              3)
	declare @tempstr varchar(32)

  set @tempstr='##avgCostPrice'+dbo.trim(dbo.getDayStr_noSeparator(@date_till))

  exec('if (select object_id(''tempdb..'+@tempstr+''')) is not null '
			 +'drop table '+@tempstr)
  exec('select cGoodsNo,Qty,fInMoney,avgCostPrice into '
			 +@tempstr+' from #TempIN_Return')
/*返回截止盘点日期,所有上货商品的平均进价,存放在全局临时表##avgCostPrice20070103中*/
	
	
  
end

GO
