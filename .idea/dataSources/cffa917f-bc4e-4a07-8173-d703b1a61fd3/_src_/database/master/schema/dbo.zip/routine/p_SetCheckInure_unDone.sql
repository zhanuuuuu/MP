CREATE       procedure [dbo].[p_SetCheckInure_unDone]
@cCheckTaskno varchar(32),
@dCheckDate datetime
as
begin

  select distinct cTaskNo=cSupplierNo 
	into #tempTaskNo_unDone
	from wh_CheckWh
	where dDate>=@dCheckDate or cSupplierNo=@cCheckTaskno
   
  select distinct cSheetno 
	into #tempSheetno_unDone
	from wh_CheckWh
	where dDate>=@dCheckDate or cSupplierNo=@cCheckTaskno

	update wh_CheckWhDetail set bChecked=null
	where cSheetno  in 
						(select distinct cSheetno from #tempSheetno_unDone)

	update wh_CheckWh set bChecked=null
	where cSupplierNo in (select distinct cTaskNo from #tempTaskNo_unDone)
-------------------------------------------------------------------
  --更新实时库存

	update a
	set a.fQty_Check_Diff=0,a.fQty_checkout=null,
	a.fMoney_checkout=null,
	a.fQty_CurWH=ISNULL(a.fQty_CurWH,0)-ISNULL(a.fQty_Check_Diff,0)
	from t_Goods_CurWH a,t_CheckTast_GoodsDetail b
	where a.cGoodsNo=b.cGoodsNo and a.cWHno=b.cWhNo
	and b.cCheckTaskNo in  (select distinct cTaskNo from #tempTaskNo_unDone)

  -------------------------------------------------------------------
  
  delete from dbo.t_CheckTast_GoodsDetail
	where cCheckTaskNo in  (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_CheckWhDetail set bChecked=0,cCheckNo=null --将原来过期的盘点激活
	where bChecked=1 and cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

--	update wh_CheckWhDetail set bChecked=0,cCheckNo=null/*记录当前即将生效的盘点任务号，以便反操作用*/
--	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_EffusionWhDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_ExchangeDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_InWarehouseDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_LossWarehouseDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_OutWarehouseDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_RbdWarehouseDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update WH_ReturnGoodsDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_TfrWarehouseDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_PackDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update wh_DivideWhDetail set bChecked=0,cCheckNo=null
	where  cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update t_SaleSheet set bChecked=0,cChkOperno=null
	where  cChkOperno in (select distinct cTaskNo from #tempTaskNo_unDone)

	update t_SaleSheetDetail set bChecked=0,cCheckNo=null
	where cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update t_SaleSheet_Day set bChecked=0,cCheckNo=null
	where cCheckNo in (select distinct cTaskNo from #tempTaskNo_unDone)

	update dbo.t_CheckTast set bChecked=null/*将当前盘点任务设置成休眠状态*/
	where cCheckTaskNo=@cCheckTaskno

	update dbo.t_CheckTast set bChecked=null/*将当前盘点任务设置成休眠状态*/
	where cCheckTaskNo<>@cCheckTaskno and dCheckTask>=@dCheckDate
	



 
end


GO
