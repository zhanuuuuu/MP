



CREATE        view v_x_SupplierTree
as
	select cSupplierTypeNo='01',cSupplierTypeName='供货',cParentNo='--'
	
  union all
	
  select cSupplierTypeNo=cSupNo,cSupplierTypeName=cSupName,cParentNo='01' 
    from t_Supplier_Contract where cHezuoFangshi='供货'
	union all
  
  select cSupplierTypeNo='02',cSupplierTypeName='联营',cParentNo='--'
	
  union all
	
  select cSupplierTypeNo=cSupNo,cSupplierTypeName=cSupName,cParentNo='02' 
    from t_Supplier_Contract where cHezuoFangshi='联营'
	
  union all
    select cSupplierTypeNo='03',cSupplierTypeName='租赁',cParentNo='--'
  
  union all
	
  select cSupplierTypeNo=cSupNo,cSupplierTypeName=cSupName,cParentNo='03' 
    from t_Supplier_Contract where cHezuoFangshi='租赁'
	
  union all
    select cSupplierTypeNo='04',cSupplierTypeName='购销',cParentNo='--' 

  union all 

  select cSupplierTypeNo=cSupNo,cSupplierTypeName=cSupName,cParentNo='04' 
    from t_Supplier_Contract where cHezuoFangshi='购销'

  union all
 
  select cSupplierTypeNo='05',cSupplierTypeName='其它',cParentNo='--'

  union all
  
  select cSupplierTypeNo=cSupNo,cSupplierTypeName=cSupName,cParentNo='05' 
    from t_Supplier_Contract where (cHezuoFangshi<>'租赁' and 
                                   cHezuoFangshi<>'联营' and 
                                   cHezuoFangshi<>'供货' and
                                   cHezuoFangshi<>'购销') or cHezuoFangshi is null


GO
