create       procedure p_SumSupplierPayout_list
@supNo varchar(64),
@date1 datetime,
@date2 datetime
as
begin
	select feiyongno,feiyong,feiyongjine,serno,riqi1,riqi2
	from dbo.t_Supplier_Payout
	where isnull(jiesuanover,0)=0 and cSupplierNo=@supNo 
				and riqi2 <= @date2
	
end


GO
