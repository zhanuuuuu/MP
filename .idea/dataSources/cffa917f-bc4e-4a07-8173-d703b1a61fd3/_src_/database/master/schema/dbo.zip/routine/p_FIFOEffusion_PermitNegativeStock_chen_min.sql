/*
入库单据插入成本表中
p_FIFOInWareHouse_PermitNegativeStock_chen 'IN20099044-000004'
select * from dbo.wh_InWarehouseDetail
select * from t_wh_form
*/

create proc p_FIFOEffusion_PermitNegativeStock_chen_min
@cSheetNo varchar(32),
@return int output,
@bPermitNegativeStock int  --(0:不允许负库存 1：允许负库存)
as

begin try
begin tran

if (select object_id('tempdb..#tmpInWareHouse'))is not null
drop table #tmpInWareHouse
if (select object_id('tempdb..#tmpNegativeStock'))is not null
drop table #tmpNegativeStock
--入库

select a.cSheetNo,cGoodsNo_Parent=a.cGoodsNo,cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo),
a.iLineNo,b.cSupplierNo,b.cSupplier,b.dDate,
fInPrice_Parent=isnull(a.fInPrice,0),fQuantity_Parent=isnull(a.fQuantity,0),
fQty_MinPackage=isnull(c.fQty_MinPackage,1),
fInPrice=isnull(a.fInPrice,0),fInMoney=isnull(a.fInMoney,0),b.cWhNo,
fQuantity=case when c.cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo) then isnull(a.fQuantity,0)
          else isnull(a.fQuantity,0)*isnull(c.fQty_MinPackage,1)
          end,
fQty_tmpIn=cast(0 as money),
iOrder=case when c.cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo) then 1
          else 0
          end
into #tmpInWareHouse
from wh_EffusionWhDetail a,wh_EffusionWh b,t_goods c
where a.cSheetNo=b.cSheetNo and a.cGoodsNo=c.cGoodsNo
and a.cSheetNo=@cSheetNo
and a.cGoodsNo in(select cGoodsNO from t_goods where isnull(bStorage,0)=1)
order by a.iLineNo

update #tmpInWareHouse
set finPrice=fInMoney/(fquantity*1.00)
where ISNULL(fquantity,0)<>0


--入库单商品负库存情况
select distinct a.cGoodsNo,a.iSerNo,a.cWhNo,fQtyLeft=a.fQty_Out-a.fQty_in,
iOrder=case when ISNULL(a.cGoodsNo_Parent,a.cGoodsNO)=a.cGoodsNO then 1
        else 0 end
into #tmpNegativeStock
from t_wh_form a,#tmpInWareHouse b
where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo
and a.fQty_Out-a.fQty_in>0

declare  NegativeInWh cursor
for
select  cGoodsNo,iSerNo,cWhNo,fQtyLeft
from #tmpNegativeStock
order by iOrder,iserNo


open NegativeInWh

declare @CurGoodsNo varchar(32)
declare @CurSerno money
declare @CurWhNo varchar(32)
declare @CurFqty money
select @CurGoodsNo='',@CurSerno=0,@CurWhNo='',@CurFqty=0
fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty
--select @CurGoodsNo+'  '+cast(@CurSerno as varchar(10))+'   '+cast(@CurFqty as varchar(10))
while @@fetch_status=0
begin
	declare @spare float --剩余库存 
	select @spare=sum(fQuantity)
	from #tmpInWareHouse 
	where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	group by cGoodsNo

    set @spare=isnull(@spare,0)

   if(@spare>=@CurFqty) 
   begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
		update a 
		set a.fQty_tmpIn= 
		case when 
			( select @CurFqty-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo and iLineNo <=a.iLineNo and cWhNo=@CurWhNo
			)>=0 
		then a.fQuantity
		else 
			case when 
				(select @CurFqty-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo and cWhNo=@CurWhNo
				)<0 then 0 
			else 
			   (select @CurFqty-isnull(sum(fQuantity),0)
				from #tmpInWareHouse 
				where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo  and cWhNo=@CurWhNo
               ) 
			end 
        end
		from #tmpInWareHouse a 
		where a.cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
    end else
    begin
	   --负库存 
	  declare @MaxRow int
	  declare @tmpLeafSum money
	  select @MaxRow=max(iLineNo) from #tmpInWareHouse where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	 -- select @tmpLeafSum=fQuantity from #tmpInWareHouse where cGoodsNo=@cGoodsNo and cWhNo=@CurWhNo and iSerNo=@MaxRow
	 -- if @tmpLeafSum>=0 
	 -- begin
          update a
		  set a.fQty_tmpIn=@CurFqty-(
                                      select isnull(sum(fQuantity),0) 
                                      from #tmpInWareHouse 
                                      where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
                                     )
		  from #tmpInWareHouse a
		  where a.cGoodsNo=@CurGoodsNo and iLineNo=@MaxRow and cWhNo=@CurWhNo

		  update #tmpInWareHouse
		  set fQty_tmpIn=fQuantity  
		  where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
	 -- end else
	 -- begin
	--	 update #tmpWhForm
	--	 set fQty_Out=fQty_Out+@QtyOut
	--	 where cGoodsNo=@cGoodsNo and iSerNo=@MaxRow and cWhNo=@CurWhNo
	--  end
   end
   fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty
end

close NegativeInWh
deallocate NegativeInWh

update a
set a.fQty_Out=a.fQty_in,fMoney_Out=a.fMoney_in,a.fPrice_out=a.fPrice_in,
    a.fQty_left=0,a.fPrice_left=a.fPrice_in,a.fMoney_left=0
from t_wh_form a,#tmpNegativeStock b
where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo and a.cWhNo=b.cWhNo

insert into t_wh_form
(
  cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cSummary,fPrice_in,fQty_in,fMoney_in,
  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
  cSupplierNo,cSupplier,iSerNo,cGoodsNo_Parent,fQty_minPackage,fQty_In_Parent
)
select cGoodsNo,dDate,cSheetNo,iLineNo,6,'报溢单',fInPrice,fQuantity,fInMoney,
fPrice_out=fInPrice,fQty_out=fQty_tmpIn,fMOney_out=fQty_tmpIn*fInPrice,
fInPrice,fQty_left=fQuantity-fQty_tmpIn,fMoney_left=(fQuantity-fQty_tmpIn)*fInPrice,
cWhNo,cSupplierNO,cSupplier,0,cGoodsNO_Parent,fQty_MinPackage,fquantity_Parent
from #tmpInWareHouse 

update t_wh_form
set iSerNo=iMyIdentity
where iAttribute=6 and cSheetNo=@cSheetNo and isnull(iSerNo,0)=0

if @bPermitNegativeStock=1
begin
      --声明一刚插入成本表中行的游标
      declare  CurCostTable cursor
      for
      select cGoodsNo,iSerNo,fPrice_In,cWhNo,fQty_In,iAttribute
      from t_wh_form
      where iAttribute=6 and cSheetNo=@cSheetNo and fQty_in>0 and fQty_out>0
      order by iserNo

      open CurCostTable
      declare @cGoodsNo varchar(32)
      declare @iLineNo int
      declare @fPrice_In Money
      declare @fQty_In_Orient money
      declare @iSerno_Orient bigint
      declare @cWhNo varchar(32)
      declare @iAttribute_orient int

      declare @id bigint
      declare @fQty_Cost money
      declare @fQty_Pre money
      declare @iAttribute int
      declare @dDate_Sheet datetime
      declare @iLineNo_Orient bigint
      declare @fPrice_sale money
      declare @fMoney_sale  money

      declare @fQty_leiji money
      declare @fQty_left money

      declare @tmpMoney money
      declare @tmpMoney2 money
      declare @MaxId int
      declare @SheetNO_supply varchar(64)

      fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
      while @@fetch_status=0 
      begin
        
      --以下解决负库存的成本分配问题
      if (select object_id('tempdb..#temp_Record_Preview'))is not null
      drop table #temp_Record_Preview
      if (select object_id('tempdb..#temp_Record_null'))is not null
      drop table #temp_Record_null

      select id,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,
        fPrice_sale,fMoney_sale
      into #temp_Record_Preview--需要处理的不合法成本分配记录
      from t_cost_distribute
      where isnull(bDone,0)=0 and fQty<fQty_Cost and cWhNo=@cWhNo and cGoodsNo=@cGoodsNo

      select iMyid=identity(int,1,1),id=cast(null as bigint),bDone_set=cast(0 as bit),dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,
        fPrice_sale,fMoney_sale
      into #temp_Record_null--存放已处理完毕待插入成本分配表的  原来不合法成本分配记录
      from t_cost_distribute
      where 1<>1

      set @fQty_leiji=0
      set @fQty_left=@fQty_In_Orient

      declare  Cur_Record_Preview cursor
      for
      select id,fQty_Cost,fQty_Pre=fQty,iAttribute,dDate_Sheet,iLineNo,fPrice_sale,fMoney_sale,cSheetNO
      from #temp_Record_Preview
      order by id

      open Cur_Record_Preview
      fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient,@fPrice_sale,@fMoney_sale,@SheetNO_supply
      while @@fetch_status=0 
      begin
            set @tmpMoney2=0

            if @fQty_Pre>0
            begin                     
              select @tmpMoney2=fPrice_sale*fQty
              from t_cost_distribute a
              where id=@id                      

	        update a
              set fQty_Cost=fQty,fMoney_sale=fPrice_sale*fQty,fMoney_Cost=fPrice_Cost*fQty
              from t_cost_distribute a
              where id=@id 

              
	        insert into #temp_Record_null
	        (id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,fPrice_sale,fMoney_sale)
	        values
	        (@id,0,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost-@fQty_Pre,@fPrice_In*(@fQty_Cost-@fQty_Pre),@iAttribute,@SheetNO_supply,@iLineNo_Orient,@fQty_left,0,@cWhNo,@fPrice_sale,@fPrice_sale*(@fQty_Cost-@fQty_Pre))  
        	      set @fQty_left=@fQty_left-(@fQty_Cost-@fQty_Pre)				
            end else
            begin
		      insert into #temp_Record_null
		      (id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,fPrice_sale,fMoney_sale)
		      values
		      (@id,1,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost,@fPrice_In*@fQty_Cost,@iAttribute,@SheetNO_supply,@iLineNo_Orient,@fQty_left,0,@cWhNo,@fPrice_sale,@fPrice_sale*(@fQty_Cost))
		      set @fQty_left=@fQty_left-@fQty_Cost
            end
         
            --如果分配后的总金额<>@fMoney_sale ，则把误差加到第一条
            set @tmpMoney=0
            set @MaxId=0
            select @tmpMoney=sum(fMoney_sale)+@tmpMoney2 from #temp_Record_null where id=@id
            select @MaxId=min(iMyid) from #temp_Record_null where id=@id
            if @tmpMoney<>@fMoney_sale 
            begin
              update #temp_Record_null
              set fMoney_sale=fMoney_sale+(@fMoney_sale-@tmpMoney)
              where id=@id and iMyid=@MaxId      

            end
            

        fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient,@fPrice_sale,@fMoney_sale,@SheetNO_supply
      end
      close Cur_Record_Preview
      deallocate Cur_Record_Preview

      update a
      set a.bDone=b.bDone_set
      from t_cost_distribute a,#temp_Record_null b
      where a.id=b.id

      insert into t_cost_distribute
      (dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,dDate_Account,cWhNo,fPrice_sale,fMoney_sale)
      select dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,getdate(),cWhNo,fPrice_sale,fMoney_sale
      from #temp_Record_null


      --以上解决负库存的成本分配问题

      fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
      end
      close CurCostTable
      deallocate CurCostTable

end



update wh_EffusionWh
set bAccount=1
where cSheetno=@cSheetNo

commit tran
set @return=0
end try
begin catch
 rollback 
set @return=1
end catch

--select * from #tmpInWareHouse
--select * from t_wh_form
GO
