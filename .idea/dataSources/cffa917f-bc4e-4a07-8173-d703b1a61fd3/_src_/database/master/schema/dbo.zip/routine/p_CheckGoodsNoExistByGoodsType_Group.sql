CREATE proc [dbo].[p_CheckGoodsNoExistByGoodsType_Group]
@dDate datetime,@bcGoodsType bit,@cGoodsTypeNo varchar(32),@cCheckTaskNo varchar(32)
as
if (select OBJECT_ID('tempdb..#tmpDatePdd'))is not null
drop table #tmpDatePdd
select cSheetNo
into #tmpDatePdd
from wh_CheckWh a,t_CheckTast b
where dDate=@dDate and a.cSupplierNO=b.cCheckTaskNo
and b.cCheckTaskNo=@cCheckTaskNo
and 
cSupplierno in
(
select cCheckTaskNo
from t_CheckTast
where  cCheckTaskNo=@cCheckTaskNo and cGoodsTypeNo=@cGoodsTypeNo
)

declare @cStoreNo varchar(32)
set @cStoreNo=(select cStoreNo from t_CheckTast where  cCheckTaskNo=@cCheckTaskNo  )

if (select OBJECT_ID('tempdb..#tmpNoExistGoods'))is not null
drop table #tmpNoExistGoods
select distinct cGoodsNo 
into #tmpNoExistGoods
from wh_CheckWhDetail
where cSheetno in
(
  select cSheetNo
  from #tmpDatePdd
)
/*
declare @cPathParent varchar(64)
set @cPathParent=(select top 1 cGoodsTypeNo from t_CheckTast
		where dCheckTask=@dDate)
*/
if @bcGoodsType=0 
begin
	select fQuantity=0,fInMoney=0,cGoodsNo,cGoodsName,cUnit,cSpec,cBarcode,fNormalPrice
	from t_cStoregoods
	where cStoreNo=@cStoreNo and ISNULL(bStorage,0)=1
	--and ISNULL(bDeled,0)=0 
	and cGoodsNo not in
	(
		select cGoodsNo from #tmpNoExistGoods 
	)
end else
begin
	select fQuantity=0,fInMoney=0,cGoodsNo,cGoodsName,cUnit,cSpec,cBarcode,fNormalPrice
	from t_cStoregoods
	where  cStoreNo=@cStoreNo and ISNULL(bStorage,0)=1
	--and ISNULL(bDeled,0)=0 
	and cGoodstypeNo in 
	(
	   /*
		select cGoodsTypeno
		from t_GoodsType a,
		(
			select cPathChar='.'+cGoodsTypeNo+'.' from t_CheckTast where dbo.trim(isnull(cGoodsTypeNo,''))<>''
			and dCheckTask=@dDate and dbo.trim(isnull(cGoodsTypeNo,''))=@cGoodsTypeNo
		) b
		where a.cPath+'.' like '%'+b.cPathChar+'%'
		and a.cGoodsTypeno not in (select cParentNo from t_GoodsType)
        */
        select cGoodsTypeno
		from T_GroupType_GoodsType a,
		(
			select cPathChar='.'+cGoodsTypeNo+'.' from t_CheckTast where
			  cCheckTaskNo=@cCheckTaskNo and  dbo.trim(isnull(cGoodsTypeNo,''))<>''
			and dCheckTask=@dDate and dbo.trim(isnull(cGoodsTypeNo,''))=@cGoodsTypeNo
		) b
		where a.cPath+'.' like '%'+b.cPathChar+'%'
		and a.cGoodsTypeno not in (select cParentNo from T_GroupType)
 
	)
	and cGoodsNo not in
	(
		select cGoodsNo from #tmpNoExistGoods 
	)
end


GO
