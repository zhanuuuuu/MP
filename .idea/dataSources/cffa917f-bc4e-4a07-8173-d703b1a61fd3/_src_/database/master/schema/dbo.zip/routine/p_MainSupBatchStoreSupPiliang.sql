 --exec  p_MainSupBatchStoreSupPiliang  '05252343522570'
 
CREATE proc [dbo].[p_MainSupBatchStoreSupPiliang]
@cTermID varchar(32)
as
begin
    
    if (select object_id('tempdb..#tmp_SuperTemp'))is not null drop table #tmp_SuperTemp
    create table #tmp_SuperTemp(cSupNo varchar(32))
    
     if (select object_id('tempdb..#tmp_StoreNo'))is not null drop table #tmp_StoreNo
    create table #tmp_StoreNo(cStoreNO varchar(32))
    
    exec('
        insert into #tmp_SuperTemp(cSupNo)
        select cSupNO from U_key.dbo.Datemp_table'+@cTermID+'
        
        insert into #tmp_StoreNo(cStoreNO)
        select cStoreNo from U_key.dbo.temp_cStoreSupXiafa'+@cTermID+'
    ')
   if (select object_id('tempdb..#tmp_StoreNoList'))is not null drop table #tmp_StoreNoList
 
    select a.cStoreNo,iLineNo,cStoreName
    into #tmp_StoreNoList
    from t_Store a,#tmp_StoreNo b
    where a.cStoreNo=b.cStoreNo
    
    if (select object_id('tempdb..#temp_SupList'))is not null drop table #temp_SupList
    select cSupNO,cStoreNo,iLineNo,cStoreName
    into #temp_SupList
    from #tmp_SuperTemp a,#tmp_StoreNoList b
    if (select object_id('tempdb..#temp_SupListNull'))is not null drop table #temp_SupListNull
    select a.cSupNO,a.cStoreNo,a.iLineNo,a.cStoreName
    into #temp_SupListNull
    from #temp_SupList a left JOIN t_SupplierStore b
    on a.cSupNO=b.cSupNoMain and a.cStoreNO=b.cStoreNo
    where isnull(b.cSupNo,'')=''
    
     
    insert into t_SupplierStore(cSupNo, cSupName, cSupAbbName, cContractNo, cTrade, cAddress, cPostCode, cRegCode, 
	cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson, cBP, cMobile, cPPerson, iDisRate, 
	iCreGrade, iCreLine, iCreDate, cPayCond, cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, iAPMoney, 
	dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, cRegNo, cPassword, 
	cHezuoFangshi, cHelpCode, SecDogNo, bContractPrice, bLastPrice, bRatio_without_Rbd, bCaredEndDate, 
	bInPricePlan, iPre_Days, iOver_Days, b_NoStorage, bChange, bChangedDate, bFresh, cStoreNo, cStoreName, 
	cSupNoMain, bUpDatePrice)
	select StorecSupNO=a.cSupNo+cast(b.iLineNo as varchar),a.cSupName, 
	a.cSupAbbName, a.cContractNo, a.cTrade, a.cAddress, a.cPostCode, a.cRegCode, 
	a.cBank, a.cAccount, a.dDevDate, a.cLPerson, a.cPhone, a.cFax, a.cEmail, a.cSupPerson, a.cBP, a.cMobile, a.cPPerson, a.iDisRate, 
	a.iCreGrade, a.iCreLine, a.iCreDate, a.cPayCond, a.cSupIAddress, a.cSupIType, a.cSupHeadCode, a.cSupDepart, a.iAPMoney, 
	dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, cRegNo, cPassword, 
	a.cHezuoFangshi, a.cHelpCode, a.SecDogNo, a.bContractPrice, a.bLastPrice, a.bRatio_without_Rbd, a.bCaredEndDate, 
	a.bInPricePlan, a.iPre_Days, a.iOver_Days, a.b_NoStorage, a.bChange, a.bChangedDate, a.bFresh, cStoreNo, cStoreName, 
	a.cSupNo,0 from t_Supplier a,#temp_SupListNull b
	where a.cSupNo=b.cSupNo
	
	
	insert into t_Supplier_Contract(
		   cSupNo, cSupName, cSupAbbName, cTrade, cAddress, cPostCode,
		   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
			cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
			 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
		   cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate
		)
		select StorecSupNO=a.cSupNo+cast(b.iLineNo as varchar),a.cSupName, 
	     a.cSupAbbName, cTrade, cAddress, cPostCode,
		   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
			cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
			 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
		   cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate 
		   from t_Supplier a,#temp_SupListNull b
	where a.cSupNo=b.cSupNo
	
	
end


 GO
