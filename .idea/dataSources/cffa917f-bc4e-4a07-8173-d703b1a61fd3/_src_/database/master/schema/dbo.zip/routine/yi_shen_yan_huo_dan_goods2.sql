CREATE proc [dbo].[yi_shen_yan_huo_dan_goods2]
  as
  --查询已经审核没有装车的验货单的商品
  
   if (select object_id('tempdb..#temp_yan_huo_dan_goods'))is not null
  drop table #temp_yan_huo_dan_goods
  
  select a.cSheetno,a.cCustomerNo,a.cCustomer,a.cStoreNo,a.cStoreName,a.cWhNo,a.cwh,a.dDate,
         b.cGoodsNo,b.cGoodsName,b.cBarcode ,b.cUnitedNo,b.fQuantity,b.fInPrice,b.fInMoney,b.cUnit,b.dProduct
         into #temp_yan_huo_dan_goods 
         from wh_cStoreOutVerifySheet a ,wh_cStoreOutVerifySheetDetail b
          where a.cSheetno=b.cSheetno 
         and ISNULL(a.bExamin,0)=1 and ISNULL(a.bReceive,0)=0
        

       
 
     ---查询托盘编号
     if(select object_id('tempdb..#temp_StoreOutVerifySheet_Pallet_no'))    is not null
     drop table #temp_StoreOutVerifySheet_Pallet_no
     select distinct a.cSheetno,
     OutcSheetno=b.cSheetno  ---配送验货单号
     into #temp_StoreOutVerifySheet_Pallet_no
     from wh_PalletSheet   a,  (select distinct b.cSheetNo_Pallet,a.cSheetno 
     from #temp_yan_huo_dan_goods a,wh_cStoreOutVerifySheet_Pallet b where a.cSheetno=b.cSheetno) b  
     where b.cSheetNo_Pallet=a.cSheetno  ---and  ISNULL(b.bExamin,0)=1 and ISNULL(b.bReceive,0)=0 
     
    --select * from  #temp_StoreOutVerifySheet_Pallet_no
     --查询托盘单对应的分拣单号
     
      if(select object_id('tempdb..#temp_Store_Pallet_no_below_fenjian_no'))    is not null 
      drop table #temp_Store_Pallet_no_below_fenjian_no
      select a.cPalletNo,a.cDistBoxNo, a.cDistBoxNo_SortSheetNo,b.OutcSheetno,b.cSheetno  as cSheetNo_Pallet
      into #temp_Store_Pallet_no_below_fenjian_no
      from wh_PalletSheetDetail a,#temp_StoreOutVerifySheet_Pallet_no b
       where a.cSheetno=b.cSheetno
       
    -- select * from  #temp_Store_Pallet_no_below_fenjian_no
     
     -- 查询分拣单对应的门店
     if(select object_id('tempdb..#temp_Store_Sort_Goods')) is not null
      drop table #temp_Store_Sort_Goods
     select distinct a.cSheetno,a.cCustomerNo,a.cCustomer,b.cDistBoxNo,b.cPalletNo,b.OutcSheetno ,b.cSheetNo_Pallet
     into #temp_Store_Sort_Goods
     from wh_cStoreOutWarehouse_Sort a,#temp_Store_Pallet_no_below_fenjian_no b
     where a.cSheetno=b.cDistBoxNo_SortSheetNo
     
     --select * from #temp_Store_Sort_Goods
     
      -- 查询门店分拣单对应的商品
     if(select object_id('tempdb..#temp_Store_fen_jian_dan_goods')) is not null
      drop table #temp_Store_fen_jian_dan_goods
     select distinct a.cSheetno as cDistBoxNo_SortSheetNo,a.cCustomerNo,a.cCustomer,a.cSheetNo_Pallet,
     b.cGoodsNo,b.cBarcode,b.jiesuanno,
     a.cDistBoxNo,a.cPalletNo,a.OutcSheetno
     into #temp_Store_fen_jian_dan_goods
     from #temp_Store_Sort_Goods a,wh_cStoreOutWarehouseDetail_Sort b
     where a.cSheetno=b.cSheetno
     
     --select * from #temp_Store_fen_jian_dan_goods

      --分拣单对应的商品信息和 已经审核没有装车的验货单的商品进行关联

      
      select  a.cSheetno,a.cCustomerNo,a.cCustomer,a.cStoreNo,a.cStoreName,a.cWhNo,a.cwh,a.dDate,b.cSheetNo_Pallet  ,
         a.cGoodsNo,a.cGoodsName,a.cBarcode ,a.cUnitedNo,a.fQuantity,a.fInPrice,a.fInMoney,a.cUnit,a.dProduct, 
         b.cDistBoxNo_SortSheetNo,b.jiesuanno,
     b.cDistBoxNo,b.cPalletNo  
      from  #temp_yan_huo_dan_goods a, #temp_Store_fen_jian_dan_goods b
      where a.cGoodsNo=b.cGoodsNo and a.cCustomerNo=b.cCustomerNo and a.cSheetno=b.OutcSheetno


GO
