/*
       create table U_key.dbo.temp_GoodsKuWei(cStoreNo varchar(32),cStoreName varchar(64),cGoodsNo varchar(32),
     cGoodsName varchar(64),cBarcode varchar(32),
       cUnit varchar(32),cSpec varchar(32),fPreservationDown money,
	   fPreservationUp money,fPreservation_soft  money,
	   cGoodsTypeno varchar(32),cGoodsTypename varchar(64),fQty_Avg money,
	   cSupNo varchar(32),cSupName varchar(64),fUp money,fDown money,fPaimian money,fPackRatio money)
	   
  p_GetcStoreGoodsKuWei '1009',7,'',2.5,1,''
  
  select * from U_key.dbo.temp_GoodsKuWei
*/
create proc p_GetcStoreGoodsKuWei_test
@cStoreNo varchar(32),
@iDay int,
@cTermID varchar(32),
@AnQuanxs money,
@ATianshu money,
@cStr varchar(800)
as
begin
       
	   if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo
	   select distinct cGoodsno,fQuantity=CAST(null as money)
	   into #temp_GoodsNo from t_cStoreGoods  
	   where cStoreNo=@cStoreNo  
	   and ISNULL(bWeight,0)=0
	   
	   --update a
	   --set a.fPreservationUp=b.fPreservationUp,a.fPreservationDown=b.fPreservationDown
	   --from t_cStoreGoods  a,t_Goods b
	   --where a.cStoreNo='000' and a.cGoodsNo=b.cGoodsNo
	   
	   
	   declare @dDAteMax datetime	   
	   declare @dDAte datetime
	   
	   declare @dDate1 varchar(32)
	   declare @dDate2  varchar(32)
   
	    set @dDate1=dbo.getDayStr(GETDATE()-@iDay)
	    set @dDate2=dbo.getDayStr(GETDATE()-1)
        
        declare @dOpenDate datetime
        set  @dOpenDate=(select a.dOpenDate from t_OpenDate a,t_WareHouse b where a.cStoreNo=b.cWhNo and b.cStoreNo=@cStoreNo)
        
        if @dOpenDate>@dDate1
        begin
           set @dDate1=@dOpenDate
           set @iDay=DATEDIFF ( day , @dOpenDate , @dDate2 ) 
        end
        if @iDay=0 
        begin
           set  @iDay=1
        end
        
        set @dDAteMax=(select MAX(dDate) from t_Daily_history where cStoreNo=@cStoreNo)
   
   
        declare @dMaxDailyDate datetime
		set @dMaxDailyDate=(select isnull(MAX(dDate),'2000-01-01') from t_Daily_history where cStoreNo=@cStoreNo)
		if @dMaxDailyDate>@dDate2
		begin
		set @dMaxDailyDate=@dDate2
		end
   
        ---时段总销售
        if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
		select dSaleDate,a.cGoodsno,a.fQuantity,fLastSettle,cStoreNo
		into #temp_cGoodsSaleDate from t_SaleSheet_Day a,#temp_GoodsNo b
		with (nolock) 
		where dSaleDate between @dDate1 and @dMaxDailyDate and a.cGoodsNo=b.cGoodsNo
		--and cStoreNo=@cStoreNo
		union all
		select dSaleDate,a.cGoodsno,a.fQuantity,fLastSettle,cStoreNo
		from t_SaleSheetDetail a,#temp_GoodsNo b
		with (nolock) 
		where dSaleDate>=@dDate1 and dSaleDate between (@dMaxDailyDate+1) and @dDate2 and a.cGoodsNo=b.cGoodsNo   
		--and cStoreNo=@cStoreNo
		
		
		---------转小
		 
        update a
        set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
        from #temp_cGoodsSaleDate a,t_Goods b
        where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''
        
		---总公司销售合计
		if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateSum'))is not null  drop table #temp_cGoodsSaleDateSum
		select cGoodsno,fQuantity=SUM(fQuantity)
		into #temp_cGoodsSaleDateSum
		from #temp_cGoodsSaleDate
        group by cGoodsno
        
        ---门店销售合计
        if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateSumStore'))is not null  drop table #temp_cGoodsSaleDateSumStore
		select cGoodsno,fQuantity=SUM(fQuantity)
		into #temp_cGoodsSaleDateSumStore
		from #temp_cGoodsSaleDate
		where cStoreNo=@cStoreNo
        group by cGoodsno
        
        
        
        update a
        set a.cGoodsNo=b.cGoodsNo_minPackage 
        from #temp_GoodsNo a,t_Goods b
        where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''
        
        if (select OBJECT_ID('tempdb..#temp_GoodsNoSum_01'))is not null  drop table #temp_GoodsNoSum_01
		select cGoodsno,fQuantity=SUM(fQuantity),fQtyHj=CAST(null as money)
		into #temp_GoodsNoSum_01
		from #temp_GoodsNo
        group by cGoodsno
        
        ---门店销售
        update a
        set a.fQuantity=b.fQuantity
        from #temp_GoodsNoSum_01 a,#temp_cGoodsSaleDateSumStore b
        where a.cGoodsNo=b.cGoodsNo
        
        --- 总公司销售
        update a
        set a.fQtyHj=b.fQuantity
        from #temp_GoodsNoSum_01 a,#temp_cGoodsSaleDateSum b
        where a.cGoodsNo=b.cGoodsNo
        
        
        update a 
        set a.cGoodsNo=b.cGoodsNo_minPackage
        from #temp_GoodsNoSum_01 a,t_Goods b
        where a.cGoodsNO=b.cGoodsNo and isnull(b.cGoodsNo_minPackage,'')<>''
       
       if (select OBJECT_ID('tempdb..#temp_GoodsNoSum'))is not null  drop table #temp_GoodsNoSum
       select cGoodsno,fQuantity=sum(fQuantity),fQtyHj=sum(fQtyHj) 
       into #temp_GoodsNoSum
       from #temp_GoodsNoSum_01
       group by cGoodsno
       
	   
	   declare @iAnDays varchar(32) 
	   set @iAnDays=cast((@AnQuanxs+@ATianshu) as varchar)
	   
	   declare @iAnDays_01 varchar(32) 
	   set @iAnDays_01=cast((@ATianshu) as varchar)
	   
	    declare @cStoreNoPa varchar(32)
        set @cStoreNoPa=(select cStoreNo from t_Store where cParentNo='--')
        if @cStoreNoPa=@cStoreNo
        begin
            exec('
			 truncate table U_key.dbo.temp_GoodsKuWei'+@cTermID+'
			 insert into U_key.dbo.temp_GoodsKuWei'+@cTermID+'
			 (
			   cStoreNo,cStoreName,cGoodsNo,cGoodsName,cBarcode,
			   cUnit,cSpec,fPreservationDown,fPreservationUp,fPreservation_soft,
			   cGoodsTypeno,cGoodsTypename,fQty_Avg,fQtyHj_Avg,cSupNo,cSupName,fUp,fDown,fPaimian,fPackRatio
			 )
			   select a.cStoreNo,a.cStoreName,a.cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,fPreservationDown=ISNULL(fPreservationDown,0),
			   fPreservationUp=ISNULL(fPreservationUp,0),fPreservation_soft=ISNULL(fPreservation_soft,0),
			   cGoodsTypeno,cGoodsTypename,fQty_Avg=fQuantity/'+@iDay+',fQtyHj_Avg=fQtyHj/'+@iDay+',
			   cSupNo=c.cSupNoMain,a.cSupName,fUp=0,fDown=0,fPaimian=0,a.fPackRatio
			   from t_cStoreGoods a,#temp_GoodsNoSum b,t_SupplierStore c
			   where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo 
			   and a.cStoreNo=c.cStoreNo and a.cSupNo=c.cSupNo
			   
			   update a
			   set a.fPaimian=b.fPreserPaimian,a.fDown=isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQtyHj_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0),
			   ---a.fUp=(isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQtyHj_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0))+isnull(a.fQtyHj_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0))
			   a.fUp=(isnull(b.fPreserPaimian,0)+ROUND(isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQtyHj_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0)+isnull(a.fQtyHj_Avg*((isnull(b.Songhuo_Tianshu,0))),0), 0))
			   ,a.AnQuan_Xs=b.AnQuan_Xs,a.Songhuo_Tianshu=b.Songhuo_Tianshu
			   from U_key.dbo.temp_GoodsKuWei'+@cTermID+' a,t_cStoreGoodsKuwei b
			   where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo
		   
			   update a
			   set  a.fDown=isnull(a.fPaimian,0)+ROUND(isnull(a.fQty_Avg*(3.5),0), 0),
			   a.fUp=(isnull(a.fPaimian,0)+ROUND(isnull(a.fPaimian,0)+ROUND(isnull(a.fQty_Avg*(3.5),0), 0)+isnull(a.fQty_Avg*((3)),0), 0))
			   ,a.AnQuan_Xs=3,a.Songhuo_Tianshu=10
			   from U_key.dbo.temp_GoodsKuWei'+@cTermID+'  a
			   where isnull(AnQuan_Xs,0)=0
			   
		   ')
        end else
        begin
        exec('
         truncate table U_key.dbo.temp_GoodsKuWei'+@cTermID+'
         insert into U_key.dbo.temp_GoodsKuWei'+@cTermID+'
         (
           cStoreNo,cStoreName,cGoodsNo,cGoodsName,cBarcode,
           cUnit,cSpec,fPreservationDown,fPreservationUp,fPreservation_soft,
           cGoodsTypeno,cGoodsTypename,fQty_Avg,fQtyHj_Avg,cSupNo,cSupName,fUp,fDown,fPaimian,fPackRatio
         )
		   select a.cStoreNo,a.cStoreName,a.cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,fPreservationDown=ISNULL(fPreservationDown,0),
		   fPreservationUp=ISNULL(fPreservationUp,0),fPreservation_soft=ISNULL(fPreservation_soft,0),
		   cGoodsTypeno,cGoodsTypename,fQty_Avg=fQuantity/'+@iDay+',fQtyHj_Avg=fQtyHj/'+@iDay+',
		   cSupNo=c.cSupNoMain,a.cSupName,fUp=0,fDown=0,fPaimian=0,a.fPackRatio
		   from t_cStoreGoods a,#temp_GoodsNoSum b,t_SupplierStore c
		   where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo 
		   and a.cStoreNo=c.cStoreNo and a.cSupNo=c.cSupNo
		   
		   update a
		   set a.fPaimian=b.fPreserPaimian,a.fDown=isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQty_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0),
		   ---a.fUp=(isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQty_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0))+isnull(a.fQty_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0))
		   a.fUp=(isnull(b.fPreserPaimian,0)+ROUND(isnull(b.fPreserPaimian,0)+ROUND(isnull(a.fQty_Avg*(isnull(b.AnQuan_Xs,0)+isnull(b.Songhuo_Tianshu,0)),0), 0)+isnull(a.fQty_Avg*((isnull(b.Songhuo_Tianshu,0))),0), 0))
		   ,a.AnQuan_Xs=b.AnQuan_Xs,a.Songhuo_Tianshu=b.Songhuo_Tianshu
		   from U_key.dbo.temp_GoodsKuWei'+@cTermID+' a,t_cStoreGoodsKuwei b
		   where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo
	   
	       update a
		   set  a.fDown=isnull(a.fPaimian,0)+ROUND(isnull(a.fQty_Avg*(3.5),0), 0),
		   a.fUp=(isnull(a.fPaimian,0)+ROUND(isnull(a.fPaimian,0)+ROUND(isnull(a.fQty_Avg*(3.5),0), 0)+isnull(a.fQty_Avg*((3)),0), 0))
		   ,a.AnQuan_Xs=2.5,a.Songhuo_Tianshu=1
		   from U_key.dbo.temp_GoodsKuWei'+@cTermID+'  a
		   where isnull(AnQuan_Xs,0)=0
       ')
        end
       
end

GO
