
/*
  [p_StoreCostGOodsUpdate_wei_test] 'UPCT201703-000013','00'
*/
CREATE proc [dbo].[p_StoreCostGOodsUpdate_wei]
@cSheetNo varchar(32),
@cStoreNo varchar(32)
as
begin 
		if (select OBJECT_ID('tempdb..#tmp_Store'))is not null drop table #tmp_Store
		create table #tmp_Store(cStoreNo varchar(32))
	 
		if (select OBJECT_ID('tempdb..#tmp_StoreGoods'))is not null drop table #tmp_StoreGoods
		select cGoodsNo,fNormalPrice,fckprice,fPrice_Contract 
		into #tmp_StoreGoods
		from t_StoreCostGoodsUpdateDetail
		where cSheetNo=@cSheetNo
		
		---所有都改
		if @cStoreNo='--' 
		begin  
 
		     update a
		     set a.fckprice=b.fckprice,a.fPrice_Contract=b.fPrice_Contract,
		     a.fPsprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100)
		     from t_Goods a,#tmp_StoreGoods b ,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo
			 and a.cGoodsTypeNo=c.cGoodsTypeno  
		      
			 update a
		     set a.fckprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100),
		     a.fPrice_Contract=b.fPrice_Contract*(1+isnull(c.fPSRate,0)*1.0/100)
		     from t_cStoreGoods a,#tmp_StoreGoods b,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo 
			 and a.cGoodsTypeNo=c.cGoodsTypeno 
		     
		     
		     
		     ----大改小
		     if (select OBJECT_ID('tempdb..#tmp_cGoodsMin'))is not null drop table #tmp_cGoodsMin
		     select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
		     b.fckprice,b.fPrice_Contract
		     into #tmp_cGoodsMin 
		     from t_Goods a,#tmp_StoreGoods b
		     where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
		     
		     
		     update a
		     set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
		     a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
		     from t_Goods a,#tmp_cGoodsMin b
		     where a.cGoodsNo=b.cGoodsNo
		     
		     
		     update a
			 set  a.fPsprice=a.fPsprice/b.fQty_minPackage 
			 from t_Goods a,#tmp_cGoodsMin b ,t_GoodsType c
			 where a.cGoodsNo=b.cGoodsNo  
			 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
					 
		     
		     update a
		     set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
		     a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
		     from t_cStoreGoods a,#tmp_cGoodsMin b
		     where a.cGoodsNo=b.cGoodsNo
		     
		     ----小改大
		     if (select OBJECT_ID('tempdb..#tmp_cGoodsMax'))is not null drop table #tmp_cGoodsMax
		     select a.cGoodsNo,fQty_minPackage=ISNULL(fQty_minPackage,1),
		     b.fckprice,b.fPrice_Contract
		     into #tmp_cGoodsMax 
		     from t_Goods a,#tmp_StoreGoods b
		     where a.cGoodsNo_minPackage=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
		     
		     
		     update a
		     set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
		     a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
		     from t_Goods a,#tmp_cGoodsMax b
		     where a.cGoodsNo=b.cGoodsNo
		     
		     
		     update a
			 set  a.fPsprice=a.fPsprice*b.fQty_minPackage 
			 from t_Goods a,#tmp_cGoodsMax b ,t_GoodsType c
			 where a.cGoodsNo=b.cGoodsNo  
			 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
					 
		     
		     update a
		     set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
		     a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
		     from t_cStoreGoods a,#tmp_cGoodsMax b
		     where a.cGoodsNo=b.cGoodsNo
		     
		     
		     update t_StoreCostGoodsUpdate
		     set bExamin=1		     
		     where cSheetNo=@cSheetNo 
		 
		     
		end else
		begin
		           declare @cStoreNo01 varchar(32)
		           set @cStoreNo01=(select top 1 cParentNo from t_Store where cStoreNo=@cStoreNo)
		           
		           if ISNULL(@cStoreNo01,'')='--'
		           begin		      
					 
				              
		                     update a
							 set a.fckprice=b.fckprice,a.fPrice_Contract=b.fPrice_Contract,
							 a.fPsprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100)
							 from t_Goods a,#tmp_StoreGoods b ,t_GoodsType c
							 where a.cGoodsNo=b.cGoodsNo
							 and a.cGoodsTypeNo=c.cGoodsTypeno  
						      
							 update a
							 set a.fckprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100),
							 a.fPrice_Contract=b.fPrice_Contract*(1+isnull(c.fPSRate,0)*1.0/100)
							 from t_cStoreGoods a,#tmp_StoreGoods b,t_GoodsType c
							 where a.cGoodsNo=b.cGoodsNo
							 and a.cGoodsTypeNo=c.cGoodsTypeno 
						     
						
						     
							 ----输大码 改小码
							 if (select OBJECT_ID('tempdb..#tmp_cGoodsMin3'))is not null drop table #tmp_cGoodsMin3
							 select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
							 b.fckprice,b.fPrice_Contract
							 into #tmp_cGoodsMin3 
							 from t_Goods a,#tmp_StoreGoods b
							 where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
						     
						     
							 update a
							 set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
							 from t_Goods a,#tmp_cGoodsMin3 b
							 where a.cGoodsNo=b.cGoodsNo
						     
						     
							 update a
							 set  a.fPsprice=a.fPsprice/b.fQty_minPackage
							 from t_Goods a,#tmp_cGoodsMin3 b ,t_GoodsType c
							 where a.cGoodsNo=b.cGoodsNo  
							 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
									 
						     
							 update a
							 set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
							 from t_cStoreGoods a,#tmp_cGoodsMin3 b
							 where a.cGoodsNo=b.cGoodsNo
							 
							 ---或者是根据小码 调整大码
							 
							 if (select OBJECT_ID('tempdb..#tmp_cGoodsMax1'))is not null drop table #tmp_cGoodsMax1
							 select a.cGoodsNo,fQty_minPackage=ISNULL(fQty_minPackage,1),
							 b.fckprice,b.fPrice_Contract
							 into #tmp_cGoodsMax1
							 from t_Goods a,#tmp_StoreGoods b
							 where a.cGoodsNo_minPackage=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
						     
						     
							 update a
							 set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
							 from t_Goods a,#tmp_cGoodsMax1 b
							 where a.cGoodsNo=b.cGoodsNo
						     
						     
							 update a
							 set  a.fPsprice=b.fCKPrice*b.fQty_minPackage 
							 from t_Goods a,#tmp_cGoodsMax1 b ,t_GoodsType c
							 where a.cGoodsNo=b.cGoodsNo  
							 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
									 
						     
							 update a
							 set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
							 from t_cStoreGoods a,#tmp_cGoodsMax1 b
							 where a.cGoodsNo=b.cGoodsNo
							 
						     
							 update t_StoreCostGoodsUpdate
							 set bExamin=1		     
							 where cSheetNo=@cSheetNo 			
							 
							 
							  
		           end else
		           begin
		           
							if (select OBJECT_ID('tempdb..#tmp_StoreAll'))is not null drop table #tmp_StoreAll
		     
							select cStoreNo=cRegNo,cStoreName=cRegName,cParentNo 
							into #tmp_StoreAll
							from t_Store_Regionalism 
							union all
							select cStoreNo,cStoreName,cRegNo from t_Store 
							union all
							select '--','总公司',cParentNo='ALL'
							order by cRegNo
							 
							
							if exists(select cStoreNo from #tmp_StoreAll where cParentNo=@cStoreNo)
							begin
								insert into #tmp_Store(cStoreNo)			 
								select cStoreNo from #tmp_StoreAll where cParentNo=@cStoreNo 
							end else
							begin
								insert into #tmp_Store(cStoreNo) values(@cStoreNo)		 
							end
							
							  -----处理总部基本信息
				           if exists(select * from #tmp_Store a,t_Store b
										 where a.cStoreNo=b.cStoreNo
										 and b.cParentNo='--')
							begin			
						 
							         
							      
								 update a
								 set a.fckprice=b.fckprice,a.fPrice_Contract=b.fPrice_Contract,
								 a.fPsprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100)
								 from t_Goods a,#tmp_StoreGoods b ,t_GoodsType c
								 where a.cGoodsNo=b.cGoodsNo
								 and a.cGoodsTypeNo=c.cGoodsTypeno  
							      
								 update a
								 set a.fckprice=b.fCKPrice*(1+isnull(c.fPSRate,0)*1.0/100),
								 a.fPrice_Contract=b.fPrice_Contract*(1+isnull(c.fPSRate,0)*1.0/100)
								 from t_cStoreGoods a,#tmp_StoreGoods b,t_GoodsType c
								 where a.cGoodsNo=b.cGoodsNo
								 and a.cGoodsTypeNo=c.cGoodsTypeno 
							     
							     
							     
								 ---- 大转小
								 if (select OBJECT_ID('tempdb..#tmp_cGoodsMin4'))is not null drop table #tmp_cGoodsMin4
								 select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
								 b.fckprice,b.fPrice_Contract
								 into #tmp_cGoodsMin4 
								 from t_Goods a,#tmp_StoreGoods b
								 where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
							     
							     
								 update a
								 set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
								 a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
								 from t_Goods a,#tmp_cGoodsMin4 b
								 where a.cGoodsNo=b.cGoodsNo
							     
							     
								 update a
								 set  a.fPsprice=a.fPsprice/b.fQty_minPackage 
								 from t_Goods a,#tmp_cGoodsMin4 b ,t_GoodsType c
								 where a.cGoodsNo=b.cGoodsNo  
								 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
										 
							     
								 update a
								 set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
								 a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
								 from t_cStoreGoods a,#tmp_cGoodsMin4 b
								 where a.cGoodsNo=b.cGoodsNo
								 
								 ---小转大
								 if (select OBJECT_ID('tempdb..#tmp_cGoodsMax2'))is not null drop table #tmp_cGoodsMax2
								 select a.cGoodsNo,fQty_minPackage=ISNULL(fQty_minPackage,1),
								 b.fckprice,b.fPrice_Contract
								 into #tmp_cGoodsMax2 
								 from t_Goods a,#tmp_StoreGoods b
								 where a.cGoodsNo_minPackage=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
							     
							     
								 update a
								 set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
								 a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
								 from t_Goods a,#tmp_cGoodsMax2 b
								 where a.cGoodsNo=b.cGoodsNo
							     
							     
								 update a
								 set  a.fPsprice=a.fPsprice*b.fQty_minPackage 
								 from t_Goods a,#tmp_cGoodsMax2 b ,t_GoodsType c
								 where a.cGoodsNo=b.cGoodsNo  
								 and a.cGoodsTypeNo=c.cGoodsTypeno and isnull(a.bOnePSPrice,0)=0
										 
							     
								 update a
								 set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
								 a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
								 from t_cStoreGoods a,#tmp_cGoodsMax2 b
								 where a.cGoodsNo=b.cGoodsNo
								 
							end 
							 
							 
							
							 update a
							 set  a.fckprice=b.fCKPrice*(1+isnull(d.fPSRate,0)*1.0/100),a.fPrice_Contract=b.fPrice_Contract*(1+isnull(d.fPSRate,0)*1.0/100)					 
							 from t_cStoreGoods a,#tmp_StoreGoods b,#tmp_Store c,t_GoodsType d
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 and a.cGoodsTypeno=d.cGoodsTypeno
							 
							 
							 ---大转小
							 if (select OBJECT_ID('tempdb..#tmp_cGoodsMin0'))is not null drop table #tmp_cGoodsMin0
							 select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
							 b.fckprice,b.fPrice_Contract
							 into #tmp_cGoodsMin0 
							 from t_Goods a,#tmp_StoreGoods b
							 where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
						 
						     
							  
							 update a
							 set a.fCKPrice=b.fCKPrice/b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract/b.fQty_minPackage
							 from t_cStoreGoods a,#tmp_cGoodsMin0 b,#tmp_Store c
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 
							 ----小转大
							 if (select OBJECT_ID('tempdb..#tmp_cGoodsMax0'))is not null drop table #tmp_cGoodsMax0
							 select a.cGoodsNo,fQty_minPackage=ISNULL(fQty_minPackage,1),
							 b.fckprice,b.fPrice_Contract
							 into #tmp_cGoodsMax0 
							 from t_Goods a,#tmp_StoreGoods b
							 where a.cGoodsNo_minPackage=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
						 
						     
							  
							 update a
							 set a.fCKPrice=b.fCKPrice*b.fQty_minPackage,
							 a.fPrice_Contract=b.fPrice_Contract*b.fQty_minPackage
							 from t_cStoreGoods a,#tmp_cGoodsMax0 b,#tmp_Store c
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 
							 
							 update t_StoreCostGoodsUpdate
							 set bExamin=1		     
							 where cSheetNo=@cSheetNo  
					 end
		end
		
end
GO
