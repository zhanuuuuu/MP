
/*
  p_GetCardHistoryHistroy_Store '90001682'
*/
create proc p_GetCardHistoryHistory_Store
@cardno varchar(32)
as
begin
   
  if (select OBJECT_ID('tempdb..#temp_MoneyCardHistory'))is not null
  drop table #temp_MoneyCardHistory
  
  select  a.cardno,dSaleDate=a.AddmoneyDate,cSaleSheetNo='充值',fMoney_o=null,fLeftMoney_o=null,
  fMoney=Addmoney,fLeftMoney=null,a.operno,cPosNo=cast(null as varchar(64)),
  b.date1,b.date2,a.opername,PosName=cast(null as varchar(64)),cStoreName=cast(null as varchar(64)),ly='History'
  into #temp_MoneyCardHistory
  from supermarket.dbo.MoneyCard_history a,supermarket.dbo.Moneycard b
  where a.cardno=b.cardno and b.cardno=@cardno
  
  update a set a.cStoreName=b.cStoreName
  from #temp_MoneyCardHistory a,
  (select  cStoreName from  t_Store b where cParentNo='--') b
 
  
  select cardno,dSaleDate,cSaleSheetNo,fMoney_o,fLeftMoney_o,fMoney,fLeftMoney,cOperNo=operno,cPosNo,
  date1,date2,cOperName=opername,PosName,cStoreName,ly
  from #temp_MoneyCardHistory  
  order by dSaleDate
  
  
  
end
GO
