
/*
客户包装返还查询
参数说明
@delphiTable 从delphi中过来的表（所查询的供应商，商品信息）
@date1 开始日期
@date2 截止日期
select * from delphi_Goods
exec p_PackReturnQueryByClient  'delphi_Goods','2008-12-10','2009-12-15'
*/
CREATE proc [dbo].[p_PackReturnQueryByClient]
@delphiTable varchar(32),
@date1 datetime,
@date2 datetime
as
begin
exec('
	if (select Object_id(''tempdb..#temp_PackIn''))is not null
		drop table #temp_PackIn
	if (select Object_id(''tempdb..#temp_PackInTotal''))is not null
		drop table #temp_PackInTotal
	if (select Object_id(''tempdb..#temp_PackRet''))is not null
		drop table #temp_PackRet
	if (select Object_id(''tempdb..#temp_PackRetTotal''))is not null
		drop table #temp_PackRetTotal
	if (select Object_id(''tempdb..#temp_PackLost''))is not null
		drop table #temp_PackLost
	if (select Object_id(''tempdb..#temp_PackLostTotal''))is not null
		drop table #temp_PackLostTotal
	if (select Object_id(''tempdb..#temp_PackDestory''))is not null
		drop table #temp_PackDestory
	if (select Object_id(''tempdb..#temp_PackDestoryTotal''))is not null
		drop table #temp_PackDestoryTotal
	--查询客户借出包装总数 drop table #temp_PackIn
	select  a.cSupNo,a.cPackNo,c.fQuantity
	into #temp_PackIn
	from '+@delphiTable+' a left join 
	(
	  select  a.cClientNo,b.cPackNo,b.fQuantity
	  from t_PackOutWarehouse a,t_PackOutWarehouseDetail b
	  where a.cSheetNo=b.cSheetNo and isnull(a.bExamin,0)=1
	  and a.dDate between'''+@date1+''' and '''+@date2+'''
	)c
	on a.cSupNo=isnull(c.cClientNo,'''')and a.cPackNo=c.cPackNo
	select cSupNo,cPackNo,fQty=sum(isnull(fQuantity,0))
	into #temp_PackInTotal
	from #temp_PackIn
	group by cSupNo,cPackNo

	--查询供应商返还包装总数 drop table #temp_PackIn
	select  a.cSupNo,a.cPackNo,c.fQty_Baozhuang
	into #temp_PackRet
	from '+@delphiTable+' a left join 
	(
	  select  a.cClientNo,b.cPackNo,b.fQty_Baozhuang
	  from t_PackRet a,t_PackRetDetail b
	  where a.cSheetNo=b.cSheetNo and isnull(a.bExamin,0)=1
	  and a.dDate between'''+@date1+''' and '''+@date2+'''
	)c
	on a.cSupNo=isnull(c.cClientNo,'''')and a.cPackNo=c.cPackNo
	select cSupNo,cPackNo,fQty=sum(isnull(fQty_Baozhuang,0))
	into #temp_PackRetTotal
	from #temp_PackRet
	group by cSupNo,cPackNo

	--查询丢失供应商包装总数 drop table #temp_PackIn
	select  a.cSupNo,a.cPackNo,c.fQuantity
	into #temp_PackLost
	from '+@delphiTable+' a left join 
	(
	  select  a.cClientNo,b.cPackNo,b.fQuantity
	  from t_PackLost a,t_PackLostDetail b
	  where a.cSheetNo=b.cSheetNo and isnull(a.bExamin,0)=1
	  and a.dDate between'''+@date1+''' and '''+@date2+'''
	)c
	on a.cSupNo=isnull(c.cClientNo,'''')and a.cPackNo=c.cPackNo
	select cSupNo,cPackNo,fQty=sum(isnull(fQuantity,0))
	into #temp_PackLostTotal
	from #temp_PackLost
	group by cSupNo,cPackNo

	--查询破损供应商包装总数 drop table #temp_PackDestoryTotal
	select  a.cSupNo,a.cPackNo,c.fQuantity,c.fMoneyDestory_BaoZhuang
	into #temp_PackDestory
	from '+@delphiTable+' a left join 
	(
	  select  a.cClientNo,b.cPackNo,b.fQuantity,b.fMoneyDestory_BaoZhuang
	  from t_PackDestory a,t_PackDestoryDetail b
	  where a.cSheetNo=b.cSheetNo and isnull(a.bExamin,0)=1
	  and a.dDate between'''+@date1+''' and '''+@date2+'''
	)c
	on a.cSupNo=isnull(c.cClientNo,'''')and a.cPackNo=c.cPackNo
	select cSupNo,cPackNo,fQty=sum(isnull(fQuantity,0)),fMoneyDes=sum(isnull(fMoneyDestory_BaoZhuang,0))
	into #temp_PackDestoryTotal
	from #temp_PackDestory
	group by cSupNo,cPackNo

	select a.cSupNo,a.cSupName,a.cPackNo,a.cPackName,fPrice=isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0),QtyIn=b.fQty,fMoneyIn=isnull(b.fQty,0)*isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0),
	QtyRet=c.fQty,fMoneyRet=isnull(c.fQty,0)*isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0),
	QtyLost=d.fQty,fMoneyLost=isnull(d.fQty,0)*isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0),
	QtyDes=e.fQty,e.fMoneyDes,
    QtyNoRet=b.fQty-c.fQty-d.fQty,fMoneyNoRet=(b.fQty-c.fQty-d.fQty)*(isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0)),
    QtyNormal=c.fQty-e.fQty,fMoneyNormal=(c.fQty-e.fQty)*(isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0)),
    QtyWhole=c.fQty+d.fQty,fMoneyWhose=(c.fQty-e.fQty+d.fQty)*(isnull(f.fPrice_BaozhuangClient,0)*isnull(f.fQty_Baozhuang,0))+e.fMoneyDes
	from '+@delphiTable+' a left join #temp_PackInTotal b
	on a.cSupNo=b.cSupNo and a.cPackNo=b.cPackNo
	left join #temp_PackRetTotal c
	on a.cSupNo=c.cSupNo and a.cPackNo=c.cPackNo
	left join #temp_PackLostTotal d
	on a.cSupNo=d.cSupNo and a.cPackNo=d.cPackNo 
	left join #temp_PackDestoryTotal e
	on a.cSupNo=e.cSupNo and a.cPackNo=e.cPackNo 
	left join v_Goods f
	on a.cPackNo=f.cGoodsNo

')
end

--cSupNo,cSupName,cPackNo,cPackName,fPrice,QtyIn,fMoneyIn,QtyRet,fMoneyRet,QtyLost,fMoneyLost,
--QtyDes,fMoneyDes,QtyNoRet,fMoneyNoRet,QtyNormal,fMoneyNormal,QtyWhole,fMoneyWhose
GO
