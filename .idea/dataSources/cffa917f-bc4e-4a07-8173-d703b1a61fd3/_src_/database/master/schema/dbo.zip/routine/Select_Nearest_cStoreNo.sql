 CREATE proc [dbo].[Select_Nearest_cStoreNo] 
    @longitude float,
    @latitude float
    as
     if (select OBJECT_ID('tempdb..#cStoreNo'))is not null drop table #cStoreNo
     
    --查询离用户最近的一个店铺
     SELECT top 1 cStoreNo,cStoreName,cTel,cStyle,image_path
     into #cStoreNo
     FROM t_Store order by dbo.fnGetDistance(@longitude,@latitude,longitude,latitude)
     
     --计算最近店铺的距离
     declare @lon float
     declare @lat float
     select @lon=longitude,@lat=latitude  from #cStoreNo a,t_Store b where a.cStoreNo=b.cStoreNo
      
     if(select OBJECT_ID('tempdb..#distance_table'))is not null drop table #distance_table
     select dbo.fnGetDistance(@longitude ,@latitude,@lon,@lat)  as distance
     into #distance_table
     
     --查询离用户最近的店铺信息和距离
   ---  select * from #distance_table ,#cStoreNo
      select distance=10000, cStoreNo,cStoreName,cTel,cStyle,image_path  from t_Store  where cParentNo='--'
 GO
