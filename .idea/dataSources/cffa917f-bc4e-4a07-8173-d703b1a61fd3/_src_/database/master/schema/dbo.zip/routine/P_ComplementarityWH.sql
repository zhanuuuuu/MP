

/*
P_ComplementarityWH '01','',1,1

*/

CREATE  procedure P_ComplementarityWH  /*仓库补货*/
  @WHno varchar(32),/*是仓库No*/
	@cGoodsTypeno varchar(32),
  @bMainSale bit/*是否主卖场*/,
	@bStorage bit/*是否管理库存*/
as
begin
	declare @CurWhDate datetime
	select @CurWhDate=(select top 1 dDateTime_CurWH from dbo.t_Goods_CurWH)
/*   v_Goods_Relation_X  列出商品及其关联商品*/	
	select c.cGoodsNo,c.fMin,c.fMax,c.cGoodsName,c.cUnitedNo,c.cProductNo,c.cBarCode 
	into #tempStorageOfWH
	from
		(
			select a.cGoodsNo,a.fMin,a.fMax,b.cGoodsName,b.cUnitedNo,b.cProductNo,b.cBarCode 
			from
			(
				select 	cGoodsNo,fMin,fMax
				from dbo.t_Goods_StorageOfWH
				where cWhNo=@WHno
			) a,t_Goods b
 			where a.cGoodsNo=b.cGoodsNo and b.cGoodsTypeno like @cGoodsTypeno+'%'
		) c

-- select * from #tempStorageOfWH

  /*计算date>=@CurWhDate的商品进销数量*/ 
  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,a.cBarCode,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  into #temp_Goods 
  from t_Goods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo
	where a.bStorage=1

/*销售*/
    
      
		  select a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bChecked,b.dSaleDate
		  into #temp_Sale9 
		  from #temp_Goods a ,t_salesheetdetail b
		  where isnull(b.bChecked,0) =0 and @bMainSale=1 
						and b.dSaleDate>=@CurWhDate and a.cGoodsNo=b.cGoodsNo   


		  select cGoodsNo,qty=sum(isnull(fQuantity,0)),LastSettle=sum(isnull(fLastSettle,0))
		  into #temp_Sale0--计算以前没有经过盘点的销售数量
		  from #temp_Sale9 
		  group by cGoodsNo
		
		
		  select t.GoodsNo,qty=sum(t.Qty)
		  into #temp_Sale    --所有商品的销售数量（含加工）
			from
			  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
		         a.qty*b.qty as Qty
				from #temp_Sale0 a
		  	     left join #temp_Goods b
		    	        on a.cGoodsNo=b.cGoodsNo 
				) t
			where @bMainSale=1	
			group by GoodsNo

/*                 盘点单                     */ 
/*
  select a.cGoodsNo,a.cUnitedNo,b.cProductSerno,b.fQuantity,
         b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked,fLastSettle=b.fMoney,b.cSheetno
  into #wh_CheckWhDetail_shelf 
  from #temp_Goods a 
      left join wh_CheckWhDetail b
        on b.bChecked=0 and a.cGoodsNo=b.cGoodsNo 
  where b.bChecked=0 
	and b.cSheetno in (select cSheetno from dbo.wh_CheckWh where cWhNo=@WHno and dDate>=@CurWhDate)
 
  select a.cSheetno as Sheetno,a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked as Checked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_CheckWhDetail0  --盘点单
  from #wh_CheckWhDetail_shelf a  
       left join wh_CheckWh b
            on  a.cSheetno =b.cSheetno   
  where b.bChecked=0


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_CheckWhDetail1
  from #wh_CheckWhDetail0 
  where Checked is not null and Checked=0  --Checked=0 上次盘点数量 checked=1过期盘点数量
                                           --checked is null 表示本次盘点数量待生效
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_CheckWhDetail    --所有商品的盘点数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_CheckWhDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo
*/

/*                 入库单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_InWarehouseDetail_shelf 
  from #temp_Goods a 
      left join wh_InWarehouseDetail b
        on isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
  and b.cSheetno in (select cSheetno from dbo.wh_InWarehouse where cWhNo=@WHno  and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fInPrice AS fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_InWarehouseDetail0  --入库单
  from #wh_InWarehouseDetail_shelf a  
       left join wh_InWarehouse b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_InWarehouseDetail1  --入库单
  from #wh_InWarehouseDetail0
  group by cGoodsNo,cUnitedNo


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_InWarehouseDetail    --所有商品的入库数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_InWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo

/*                 退货入库单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_RetWarehouseDetail_shelf 
  from #temp_Goods a 
      left join dbo.WH_ReturnGoodsDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.WH_ReturnGoods where cWhNo=@WHno and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fInPrice AS fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_RetWarehouseDetail0  --退货入库单
  from #wh_RetWarehouseDetail_shelf a  
       left join dbo.WH_ReturnGoods b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_RetWarehouseDetail1  --退货入库单
  from #wh_RetWarehouseDetail0
  group by cGoodsNo,cUnitedNo


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_RetWarehouseDetail    --所有商品的退货入库数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_RetWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo
  

/*                 溢出单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice as fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked

  into #wh_EffusionWhDetail_shelf 
  from #temp_Goods a 
      left join wh_EffusionWhDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_EffusionWh where cWhNo=@WHno and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_EffusionWhDetail0  --溢出单
  from #wh_EffusionWhDetail_shelf a  
       left join wh_EffusionWh b
            on  a.cSheetno =b.cSheetno   

  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_EffusionWhDetail1  --溢出单
  from #wh_EffusionWhDetail0
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_EffusionWhDetail    --所有商品的溢出数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_EffusionWhDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo


/*                 出库单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice as fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_OutWarehouseDetail_shelf 
  from #temp_Goods a 
      left join wh_OutWarehouseDetail b
        on isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_OutWarehouse where cWhNo=@WHno and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_OutWarehouseDetail0  --出库单 
  from #wh_OutWarehouseDetail_shelf a  
       left join wh_OutWarehouse b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1

--  drop table #wh_OutWarehouseDetail_shelf


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_OutWarehouseDetail1  --出库单
  from #wh_OutWarehouseDetail0
  group by cGoodsNo,cUnitedNo 

--  drop table #wh_OutWarehouseDetail0 

  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_OutWarehouseDetail    --所有商品的出库数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_OutWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo


/*                 报损单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_LossWarehouseDetail_shelf 
  from #temp_Goods a 
      left join wh_LossWarehouseDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_LossWarehouse where cWhNo=@WHno and dDate>=@CurWhDate)


  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_LossWarehouseDetail0 --报损单  
  from #wh_LossWarehouseDetail_shelf a  
       left join wh_LossWarehouse b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_LossWarehouseDetail1  --报损单
  from #wh_LossWarehouseDetail0
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_LossWarehouseDetail    --所有商品的报损数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_LossWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo


/*                 返厂单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice as fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_RbdWarehouseDetail_shelf 
  from #temp_Goods a 
      left join wh_RbdWarehouseDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_RbdWarehouse where cWhNo=@WHno and dDate>=@CurWhDate)


  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_RbdWarehouseDetail0   --返厂单
  from #wh_RbdWarehouseDetail_shelf a  
       left join wh_RbdWarehouse b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_RbdWarehouseDetail1  --返厂单
  from #wh_RbdWarehouseDetail0
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_RbdWarehouseDetail    --所有商品的返厂数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_RbdWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo



/*                 调拨单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice as fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_TfrWarehouseDetail_shelf 
  from #temp_Goods a 
      left join wh_TfrWarehouseDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_TfrWarehouse where cWhNo=@WHno and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_TfrWarehouseDetail0  --调拨单
  from #wh_TfrWarehouseDetail_shelf a  
       left join wh_TfrWarehouse b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1

  drop table #wh_TfrWarehouseDetail_shelf

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_TfrWarehouseDetail1  --调拨单
  from #wh_TfrWarehouseDetail0
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_TfrWarehouseDetail    --所有商品的调拨数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_TfrWarehouseDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo



/*                 兑奖单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_ExchangeDetail_shelf 
  from #temp_Goods a 
      left join wh_ExchangeDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 
	and b.cSheetno in (select cSheetno from dbo.wh_Exchange where cWhNo=@WHno and dDate>=@CurWhDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_ExchangeDetail0  --兑奖单
  from #wh_ExchangeDetail_shelf a  
       left join wh_Exchange b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1


  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_ExchangeDetail1  --兑奖单
  from #wh_ExchangeDetail0
  group by cGoodsNo,cUnitedNo 


  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_ExchangeDetail    --所有商品的调拨数量（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_ExchangeDetail1 a
  	     left join #temp_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo


				  select a.GoodsNo_Pdt as GoodsNo,
				       (
				        isnull(InWh.Qty,0)+
				        isnull(RetWh.Qty,0)+
				        isnull(EffusionWh.Qty,0)-
				        isnull(OutWh.Qty,0)-
				        isnull(TfrWh.Qty,0)-
				        isnull(RbdWh.Qty,0)-
				        isnull(Exchange.Qty,0)-
				        isnull(LossWh.Qty,0)-
				        isnull(Sale.Qty,0)
				       ) as Qry_End--期末数量
					into #temp_InOut
				  from #temp_Goods a
				     left join #wh_InWarehouseDetail InWh  on a.GoodsNo_Pdt=InWh.GoodsNo--期间入库数量
				     left join #wh_RetWarehouseDetail RetWh  on a.GoodsNo_Pdt=RetWh.GoodsNo--期间退货入库数量
				     left join #wh_EffusionWhDetail EffusionWh  on a.GoodsNo_Pdt=EffusionWh.GoodsNo--期间溢出数量
				     left join #wh_OutWarehouseDetail OutWh  on a.GoodsNo_Pdt=OutWh.GoodsNo--期间出库数量
				     left join #wh_TfrWarehouseDetail TfrWh  on a.GoodsNo_Pdt=TfrWh.GoodsNo--期间调拨数量
				     left join #wh_RbdWarehouseDetail RbdWh  on a.GoodsNo_Pdt=RbdWh.GoodsNo--期间返厂数量
				
				     left join #wh_ExchangeDetail Exchange  on a.GoodsNo_Pdt=Exchange.GoodsNo--期间兑奖数量
				     left join #wh_LossWarehouseDetail LossWh  on a.GoodsNo_Pdt=LossWh.GoodsNo--期间报损数量
				     left join #temp_Sale Sale  on a.GoodsNo_Pdt=Sale.GoodsNo--期间销售数量

	select f.cGoodsNo,fQty_realtime=sum(f.fQty_realtime)
	into #tempGoodsList0
  from
	(  
			select cGoodsNo,fQty_realtime=fQty_CurWH
		  from dbo.t_Goods_CurWH
			union all
			select cGoodsNo=GoodsNo,fQty_realtime=Qry_End
		  from #temp_InOut
	) f
	group by cGoodsNo

	select a.cGoodsNo,a.fQty_realtime,b.fMin,b.fMax
	into #tempGoodsList
	from #tempGoodsList0 a,#tempStorageOfWH b
	where a.cGoodsNo=b.cGoodsNo

--select * from #temp_InOut

	select f.cGoodsNo,b.fCurCostPrice,b.cCooperate
	into #tempGoods_PRatio
  from
	(
	  select cGoodsNo,dDate=max(dDate)
		from dbo.t_Goods_PRatio
		group by cGoodsNo
	) f
	left join t_Goods_PRatio b on f.cGoodsNo=b.cGoodsNo and f.dDate=b.dDate


	
			select a.cGoodsNo,a.fMin,a.fMax,b.cGoodsName,b.cUnit,b.cSpec,b.cBarCode,a.fQty_realtime,
			b.cGoodsTypeno,b.cGoodsTypename,b.fNormalPrice,b.fVipPrice,b.fVipScore,
			c.fCurCostPrice,c.cCooperate
			fQty_realtime
			from #tempGoodsList a
			left join t_goods b on a.cGoodsNo=b.cGoodsNo
			left join #tempGoods_PRatio c on a.cGoodsNo=c.cGoodsNo




end


GO
