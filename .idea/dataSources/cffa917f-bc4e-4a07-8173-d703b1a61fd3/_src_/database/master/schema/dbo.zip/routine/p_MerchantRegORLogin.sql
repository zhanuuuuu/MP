 
/*

 declare @return int 
 exec  [p_MerchantReg] '2016031916515465095992','123456',1,@return output
 select @return
  
*/

/*
    注册返回状态：1表示当前用户名已注册；           
            0表示注册异常； 
            5是注册成功
*/
/*
登录返回状态：11表示密码验证通过；
			10表示商家编号未注册；
			12密码不正确
			13该商家未为启用
			0表示异常； 
*/
 /*
登出返回状态：21表示登出通过；
			  0表示异常； 
 */
create  proc [dbo].[p_MerchantRegORLogin]
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@MerchantPwd varchar(64), --商家密码
@cAction int,             --类型：0 注册，1 登录,2 登出
@return int output        --返回值
as
begin

  IF @cAction=0 
  begin
      begin try 
	  begin tran
		if exists (select cStoreNo from t_Store where cStoreNo=@Merchantid)  -- 判定UesrName是否已经被使用过
		begin
			set @return=1
		end else
		begin	
		  insert into t_Store(cStoreNo,cStoreName,cStyle,cRegNo,bOpen,dOpenDate,MerchantPwd,iLineNo)
		  VALUES(@Merchantid,@Merchantid,'加盟店','',1,getdate(),@MerchantPwd,(SELECT count(*)+1 from t_Store))    
		  set @return=5
		 
		end  	
		commit tran
	    
		end try
		begin catch  
		   rollback  
		  set @return=0
		end catch
  end else if @cAction=1   --登录
  BEGIN
      begin try
          declare @cStoreNo varchar(64)
		  declare @cMerchantPwd varchar(64)
		  declare @bOpen bit
		  set @cStoreNo=''  
		  
		  select @cStoreNo=cStoreNo,@cMerchantPwd=MerchantPwd,@bOpen=isnull(bOpen,0) from t_Store where cStoreNo=@Merchantid  
		  
		  IF @cStoreNo=''
		  BEGIN 
			set @return=10
		  end else
		  BEGIN
			if @MerchantPwd=@cMerchantPwd  --- 表示密码一致
			begin
				if @bOpen=1
				begin				
				  update t_Store SET bOnLine=1
				  where cStoreNo=@Merchantid 				   
				  set @return=11
				end else
				BEGIN
				  set @return=13
				end				 
			end else
			BEGIn
			  set @return=12
			end
		  end  
		 
      end try
      begin catch
         set @return=0
      end catch 
  end else           ---------登出
  BEGIN 
       begin try 			
				  update t_Store SET bOnLine=0
				  where cStoreNo=@Merchantid 
				  set @return=21 
      end try
      begin catch
         set @return=0
      end catch
  end
  
end
 
--201512081042459907426
--2016031852549-10007
GO
