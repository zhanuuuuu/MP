


--模糊查询商品信息在特定的时间段内
CREATE    procedure [dbo].P_Z_getGoods_byGoodInformation_1_limit
  @goodsInformation varchar(50)--模糊查询的商品信息

as
begin
   select t.cGoodsNo,t.cGoodsName,t.cBarCode,t.cUnitedNo,t.cGoodsTypeno,t.cGoodsTypename,
          t.cUnit,t.cSpec,t.fNormalPrice,t.fVipPrice
   from t_Goods t 
	 where (t.cGoodsNo like '%'+@goodsInformation+'%'
		     or t.cGoodsName like '%'+@goodsInformation+'%'		
		     or t.cBarCode like '%'+@goodsInformation+'%'
   )
   and  cGoodsTypeNo in (select cGoodsTypeNo from  #tmpGoodstype_list)	
  end


GO
