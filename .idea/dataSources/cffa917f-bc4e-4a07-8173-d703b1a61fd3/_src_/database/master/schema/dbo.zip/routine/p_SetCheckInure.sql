/*
[p_SetCheckInure] '001'
*/

CREATE           procedure [dbo].[p_SetCheckInure]
@cCheckTaskno varchar(32)
as
begin
  declare @cWHno varchar(32)
	declare @dCheckDate datetime
	declare @bStorage bit


  set @cWHno=( select distinct cWhNo from dbo.t_CheckTast where cCheckTaskNo=@cCheckTaskno)
  set @dCheckDate=( select distinct dCheckTask from dbo.t_CheckTast where cCheckTaskNo=@cCheckTaskno)
  set @bStorage=( select distinct bStorage from dbo.t_CheckTast where cCheckTaskNo=@cCheckTaskno)
 
  if @cWHno is null return 0 
  if @dCheckDate is null return 0 

  select  cGoodsNo,fQty=isnull(sum(isnull(fQuantity,0)),0) 
	into #tempGoodsOfZone
	from dbo.wh_CheckWhDetail 
	where cSheetno in (select distinct cSheetno from dbo.wh_CheckWh where cSupplierNo=@cCheckTaskno)
	group by cGoodsNo
/*以下计算本次盘点商品的系统库存*/
  create table #tempCheckGoods(GoodsNo varchar(32),GoodsName varchar(64),cBarCode varchar(32),Qty_Begin money,Qty_InWh money,
  Qty_RetWh money,Qty_EffusionWh money,Qty_OutWh money,Qty_TfrWh money,Qty_RbdWh money,Qty_Exchange money,Qty_LossWh money,
	Qty_divide money ,Qty_Pack money,Qty_Sale money,Qry_End money,cUnit varchar(32),cSpec varchar(32),fSaleMoney Money)

  insert into  #tempCheckGoods 
	(GoodsNo,GoodsName ,cBarCode,Qty_Begin,Qty_InWh,
  Qty_RetWh,Qty_EffusionWh,Qty_OutWh,Qty_TfrWh ,Qty_RbdWh ,Qty_Exchange,Qty_LossWh,
	Qty_divide,Qty_Pack,Qty_Sale,Qry_End,cUnit ,cSpec,fSaleMoney )
  exec p_CheckGoodsStorage_preview @dCheckDate,@cWHno,1,@bStorage
/*以上计算本次盘点商品的系统库存*/

/*以下计算本次盘点商品的人工库存*/
 
--print '01'
  /*               生成#tempKuCunGoods的关联信息                                           */
  select cShelfNo=b.cGoodsTypeno,cShelfName=b.cGoodsTypeName,cShelfPart=' ',
         b.cGoodsNo,b.cGoodsName,b.cBarCode,b.cProductNo,b.cUnitedNo,b.fNormalPrice as fNormalPrice,
				 b.cUnit,b.cSpec	
  into #t_ShelfGoods0
  from #tempGoodsOfZone a
	left join t_goods b on a.cGoodsno=b.cGoodsno 

  select distinct a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cBarCode,a.cProductNo,a.fNormalPrice,
					a.cUnit,a.cSpec	
	into #t_ShelfGoods
	from #t_ShelfGoods0 a

  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  into #t_Goods 
  from #t_ShelfGoods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo

  select t.GoodsNo_Pdt as GoodsNo_Pdt,a.cGoodsName as GoodsName_Pdt,cBarcode=a.cBarcode
	into #t_Goods_zone
	from
		(
		select GoodsNo_Pdt
		from #t_Goods
		group by GoodsNo_Pdt 
		) t
		left join t_Goods a on a.cGoodsNo=t.GoodsNo_Pdt
  

  select distinct a.cGoodsNo,b.fQty
  into #wh_InWarehouseDetail_shelf 
  from #t_goods a 
      left join #tempGoodsOfZone b
      on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is not null



  select cGoodsNo,sum(isnull(fQty,0)) as Qty
  into #wh_InWarehouseDetail1  
  from #wh_InWarehouseDetail_shelf
  group by cGoodsNo

--print '02'

  select t.GoodsNo,qty=sum(t.Qty)
  into #TempCheckTaskGoods    --所有商品的实际库存数量（人工盘点）（含加工）
	from
	  (select b.GoodsNo_Pdt as GoodsNo,b.GoodsName_Pdt as GoodsName,
         a.qty*b.qty as Qty
		from #wh_InWarehouseDetail1 a
  	     left join #t_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by t.GoodsNo

--print '03'
  select distinct a.cGoodsNo
	into #tempGoodsOfStorage

	from t_goods a left join #tempGoodsOfZone b
	on a.cGoodsNo=b.cGoodsNo
	where a.bStorage=@bStorage and b.cGoodsNo is not null and a.cGoodsNo is not null

	declare @strtempTablename_Pub varchar(32)
	set @strtempTablename_Pub='##CheckTask_result_Pub'+dbo.trim(dbo.getDayStr_noSeparator(@dCheckDate))
  exec('if (select object_id(''tempdb..'+@strtempTablename_Pub+''')) is not null '
			 +'drop table '+@strtempTablename_Pub)

  if @bStorage=1 --管理库存商品
	begin
--		update dbo.t_CheckTast set bChecked=0 where cCheckTaskNo=@cCheckTaskno
		exec dbo.p_CalculateGoodsInCost @dCheckDate	  

		declare @strtempTablename varchar(32)
		set @strtempTablename='##avgCostPrice'+dbo.trim(dbo.getDayStr_noSeparator(@dCheckDate))

		select GoodsNo_sys=a.GoodsNo,a.GoodsName ,a.cBarCode,a.Qty_Begin,a.Qty_InWh,
	  a.Qty_RetWh,a.Qty_EffusionWh,a.Qty_OutWh,a.Qty_TfrWh ,a.Qty_RbdWh ,a.Qty_Exchange,a.Qty_LossWh,
		a.Qty_divide,a.Qty_Pack,a.Qty_Sale,a.Qry_End,a.cUnit ,a.cSpec,cGoodsNo=b.GoodsNo,Qty_check=b.qty,a.fSaleMoney 
		into #TempCheckTask_result0
		from #tempCheckGoods a 
		right join #TempCheckTaskGoods b
		on a.GoodsNo=b.GoodsNo
	--print '04'
    exec('	
	  select a.GoodsNo_sys,a.GoodsName ,a.cBarCode,a.Qty_Begin,a.Qty_InWh,
	  a.Qty_RetWh,a.Qty_EffusionWh,a.Qty_OutWh,a.Qty_TfrWh ,a.Qty_RbdWh ,a.Qty_Exchange,a.Qty_LossWh,
		a.Qty_Sale,a.Qry_End,a.cUnit ,a.cSpec,a.cGoodsNo,a.Qty_check,b.avgCostPrice,
		b.fInMoney,InQty_avg=b.Qty,fQuantity_Diff=cast(0.00 as money),fMoney_Diff=cast(0.00 as money),
		fMoney_CurSale=cast(0.00 as money),cCheckTaskNo=cast('' '' as varchar(32)),a.fSaleMoney
		into #TempCheckTask_result
		from #TempCheckTask_result0 a left join '+@strtempTablename+' b
		on a.GoodsNo_sys=b.cGoodsNO

    update a set a.avgCostPrice=b.fCKPrice,a.fMoney_CurSale=b.fNormalPrice
		from #TempCheckTask_result a left join t_goods b
		on a.GoodsNo_sys=b.cGoodsNo
		where a.avgCostPrice is  null

    update a set 
		a.fInMoney=isnull(a.InQty_avg,0)*isnull(a.avgCostPrice,0),
		a.InQty_avg=isnull(a.InQty_avg,0),
		a.fQuantity_Diff=a.Qty_check-a.Qry_End,
		a.fMoney_CurSale=b.fNormalPrice
		from #TempCheckTask_result a left join t_goods b
		on a.GoodsNo_sys=b.cGoodsNo
		where a.avgCostPrice is  not null

		update #TempCheckTask_result
		set cCheckTaskNo='''+@cCheckTaskno+''',fMoney_Diff=fQuantity_Diff*avgCostPrice
    
    select * into '+@strtempTablename_Pub+' from  #TempCheckTask_result

		select * from #TempCheckTask_result

		')
	end else
	begin--不管理库存商品
		select GoodsNo_sys=null
	end 
/*以上计算本次盘点商品的人工库存*/
--	where b.cGoodsNo
end


GO
