---入库单一品多商
CREATE proc [dbo].[p124543645645]

as



--入库单供应商<>商品档案供应商
select a.cGoodsNo,a.cGoodsName,
cSupNO_inWh=b.cSupplierNo,cSupName_inWh=b.cSupplier,
cSupNo_info=c.cSupNo,cSupName_info=c.cSupName
from wh_InWarehouseDetail a,wh_InWarehouse b,t_goods c
where a.cSheetno=b.cSheetno and a.cGoodsNo=c.cGoodsNo
and b.cSupplierNo<>c.cSupNo
order by c.cSupNo


--以下为入库单一种商品存在多个供应商
--drop table #tmp
select distinct a.cGoodsNo,a.cGoodsName,
cSupNO_inWh=b.cSupplierNo,cSupName_inWh=b.cSupplier,a.cSheetNo
into #tmp
from wh_InWarehouseDetail a,wh_InWarehouse b
where a.cSheetno=b.cSheetno

select distinct a.*,'档案供应商No'=c.cSupNo,'档案供应商名称'=c.cSupName
from #tmp a,
(
select cGoodsNO,num=COUNT(distinct cSupNO_inWh)
from #tmp
group by cGoodsNO having(COUNT(distinct cSupNO_inWh))>1
)b,t_goods c
where a.cGoodsNo=b.cGoodsNO and a.cGoodsNo=c.cGoodsNO
--and a.cSupNO_inWh<>c.cSupNo
order by a.cGoodsNo

GO
