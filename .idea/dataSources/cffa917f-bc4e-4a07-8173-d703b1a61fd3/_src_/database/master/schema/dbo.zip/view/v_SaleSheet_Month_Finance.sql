CREATE view v_SaleSheet_Month_Finance
as
select cYear,cYearEnd,cMonth,
cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
fCostSettle=sum(fQuantity*fCostPrice)
from v_SaleSheet_day_Finance
group by cYear,cYearEnd,cMonth,cGoodsNo,bAuditing
GO
