/*
  p_GetcGoodsPageSale_test '10019','2017-2-11','2017-02-11','1001'
  --select 102/7
*/
CREATE proc p_GetcGoodsPageSale_test
@cGoodsNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cStoreNo varchar(32)
as
begin
   if (select object_id('tempdb..#tmp_Goods'))is not null drop table #tmp_Goods
   
   select cGoodsNo,cGoodsName,cUnit,cSpec,cBarcode into #tmp_Goods 
   from t_Goods where cGoodsNo=@cGoodsNo or cGoodsNo_minPackage=@cGoodsNo
   
   select * from #tmp_Goods
   
    declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cStoreNo=@cStoreNo)+1
	if @dDate1>@dMaxDailyDate
	set @dMaxDailyDate=@dDate1
	
   
   if (select object_id('tempdb..#tmp_GoodsSaleList'))is not null drop table #tmp_GoodsSaleList
   
   select a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,a.fQuantity,a.fLastSettle
   into #tmp_GoodsSaleList
   from t_SaleSheetDetail a,#tmp_Goods b
   where dSaleDate between @dMaxDailyDate and @dDate2 and 
   a.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
   union all
   select a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,a.fQuantity,a.fLastSettle
   from t_SaleSheet_Day a,#tmp_Goods b
   where dSaleDate between @dDate1 and @dDate2 and 
   a.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
   
   select * from #tmp_GoodsSaleList
   
   select @dMaxDailyDate,@dDate1,@dDate2
   
   select cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,fqty=sum(fQuantity),xsmoney=sum(fLastSettle)
   from #tmp_GoodsSaleList 
   where isnull(fQuantity,0)<>0
   group by cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec
   union all
   select cGoodsNo=null,cGoodsName='合计:',cBarcode=null,cUnit=null,cSpec=null,fqty=sum(fQuantity),xsmoney=sum(fLastSettle)
   from #tmp_GoodsSaleList  
   
end


GO
