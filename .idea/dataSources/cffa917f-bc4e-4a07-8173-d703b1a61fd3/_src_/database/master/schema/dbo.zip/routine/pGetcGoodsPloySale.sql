create proc pGetcGoodsPloySale
@cGoodsNo varchar(32)
as
begin
    
	if  (select object_id('tempdb..#temp_GoodsList')) is not null  
	drop table #temp_GoodsList
                                   --促销进价    特价   
	select a.cGoodsNo,a.cGoodsName,a.fInPrice,a.fPrice_SO,dDateStart,dDateEnd,b.cStoreNo
	into #temp_GoodsList
	from t_PloyOfSale a,t_PloyStore b
	where a.cPloyNo=b.cPloyNo and a.cGoodsNo=@cGoodsNo
	and a.dDateEnd>=cast(dbo.getDayStr(GETDATE()) as datetime)
	union 
	select a.cGoodsNo,a.cGoodsName,a.fInPrice,a.fPrice_SO,dDateStart,dDateEnd,a.cStoreNo
	from t_PloyOfSale a 
	where  a.dDateEnd>=cast(dbo.getDayStr(GETDATE()) as datetime) and a.cGoodsNo=@cGoodsNo
    
    select a.cGoodsNo,a.cGoodsName,fInPrice,fPrice_SO,dDateStart,dDateEnd,c.cStoreNo,c.cStoreName,
    c.fCKPrice,c.fNormalPrice,c.cBarcode
    from #temp_GoodsList a , t_cStoreGoods c
    where a.cStoreNo=c.cStoreNo and a.cGoodsNo=c.cGoodsNo
    
 
    
end
GO
