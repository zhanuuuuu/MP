
create  procedure p_jiaozhang
@shouyinyuanno varchar(32),
@date datetime,
@iTypeno int
as
begin
  if @iTypeno=0/*当天销售*/
	begin
		select jstype=detail,shishou=sum(isnull(shishou,0))
		from jiesuan
		where (jiaozhang=0 or jiaozhang is null ) and shouyinyuanno=@shouyinyuanno and zdriqi=@date
		group by detail
	end else/*截止到当天销售*/
	begin
		select jstype=detail,shishou=sum(isnull(shishou,0))
		from jiesuan
		where (jiaozhang=0 or jiaozhang is null )and shouyinyuanno=@shouyinyuanno and zdriqi<=@date
		group by detail

	end
end

GO
