 
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsNo,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='11576' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
	drop table #temp_Goods
	Create Table #temp_Goods (
	cGoodsNo varchar(128),
	cProductNo varchar(128),
	cSupplierNo varchar(128))

	if  (select object_id('tempdb..#tempSupNo')) is not null
	 drop table #tempSupNo
	select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier
	
	
    if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	select distinct cGoodsNo into #temp_Goods 
	from #tempSupNo a,t_Goods b
	where a.cSupplierNo=b.cSupNo
	
	CREATE INDEX IX_tmp_WhFromGoods  ON #temp_Goods(cGoodsNo)
	
    if (select object_id('tempdb..#temp_Goods_1'))is not null drop table #temp_Goods_1

    select distinct a.cGoodsNo,b.cSupplierNo into #temp_Goods_1   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where a.cGoodsNo in (select cGoodsNo from #temp_Goods)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cGoodsNo in (select cGoodsNo from #temp_Goods))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)


if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cSupplierNo into  #tmp_WhGoodsList  from (
select distinct a.cGoodsNo,a.cSupplierNo  
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''
) a

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

	
exec p_GetSupplierSaleFmlHuanBi '2015-3-1','2015-3-30','01','Pos_Wh_Form'

*/
CREATE procedure [dbo].[p_GetSupplierSaleFmlHuanBi]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cdbname varchar(32)
as  --查询某时段 商品销售利润（含顾客退货） 

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  
 
--print dbo.getTimeStr(GETDATE())
--print 2

/*修改主供应商-- 有入库、但是该商品为不管理库存、*/
  
if(select object_id('tempdb..#temp_WhFrombeginLast')) is not null drop table #temp_WhFrombeginLast
if(select object_id('tempdb..#temp_WhFromendLast')) is not null drop table #temp_WhFromendLast
CREATE TABLE #temp_WhFrombeginLast ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 
库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money)
CREATE TABLE #temp_WhFromendLast([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 库存标志 bit,期初库存 money,期末库存 money,
fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money)
 
 /*快照表中的最大日期。。。*/
 
 
	-----查最大日结时间内信息@dDateBegin到@dDateEnd
 if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsnoLast'))is not null drop table #tmp_WhGoodsList_cGoodsnoLast
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsnoLast from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombeginLast(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromendLast(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsnoLast(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateEnd)
set @Day1=day(@dDateEnd)
set @Y1=YEAR(@dDateEnd)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@dDateEnd) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@dDateEnd) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
    
	if(@bY1<>@eY1)
	begin 
	    set @tj='1'
    end else
    begin
       if @bM1=@eM1
       begin
        exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	    fQty0=b.fQty_010131,fQtytj0=b.fQtytj_010131  
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	    Sale0=b.Sale_010131, Saletj0=b.Saletj_010131 
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	    fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),
		Sale0=sum(Sale0), Saletj0=sum(Saletj0)  
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromendLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0), 
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))			
			
	from #temp_WhFromendLast a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	')
       exec('
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	   fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131  						 
	into #temp_Wh_Goods_endCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),
		fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),		 	 
		a.fml=(isnull(a.销售金额0,0))-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))		
	from #temp_WhFromendLast a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
 
') 
       end else
       begin
        set @tj='1'
       end
    end
    if @tj='1'
    begin
	  exec('
	 --------期初销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_beginQty
		from  #temp_Wh_Goods_beginQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_beginSale
		from  #temp_Wh_Goods_beginSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFrombeginLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_beginQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFrombeginLast a ,#temp_SumWh_Goods_beginSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期初成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_beginCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_beginCost
		from  #temp_Wh_Goods_beginCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFrombeginLast a ,#temp_Wh_Goods_beginCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	 
	 
	 
	')

	exec('
	 --------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromendLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFromendLast a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFromendLast a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	 
	')
 
		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
		a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0)) 
		from #temp_WhFromendLast a,#temp_WhFrombeginLast b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    end
end else
begin
  if @M1=@M_1
  begin
 exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	    fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+'  
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	    Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'  
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	    fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),
		Sale0=sum(Sale0), Saletj0=sum(Saletj0)  
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromendLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0), 
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))			
			
	from #temp_WhFromendLast a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	')
 exec('
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	   fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'   						 
	into #temp_Wh_Goods_endCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),
		fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),		 	 
		a.fml=(isnull(a.销售金额0,0))-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))		
	from #temp_WhFromendLast a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
 
')
  end else
  begin
	  exec('
	 --------期初销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_beginQty
		from  #temp_Wh_Goods_beginQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_beginSale
		from  #temp_Wh_Goods_beginSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFrombeginLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_beginQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFrombeginLast a ,#temp_SumWh_Goods_beginSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期初成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_beginCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_beginCost
		from  #temp_Wh_Goods_beginCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFrombeginLast a ,#temp_Wh_Goods_beginCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	 
	 
	 
	')

	exec('
	 --------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromendLast(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFromendLast a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFromendLast a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
	 
	')


	update a 
	set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
	a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
	a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0)) 
	from #temp_WhFromendLast a,#temp_WhFrombeginLast b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
  end
end
--print dbo.getTimeStr(GETDATE())
--print 4

if (select OBJECT_ID('tempdb..#temp_goodsKuCunLast'))is not null  drop table #temp_goodsKuCunLast
select  cGoodsNo,cSupplierNo,cSupName=CAST(null as varchar(64)), 销售数量=sum(销售数量0),销售金额=sum(销售金额0),	 
fPrice_Avg=AVG(fPrice_Avg),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML)  
into  #temp_goodsKuCunLast
from #temp_WhFromendLast 
group by cGoodsNo, cSupplierNo 
order by  cGoodsNo

CREATE INDEX IX_temp_goodsKuCunml  ON #temp_goodsKuCunLast(cGoodsNo)

 
--	 print dbo.getTimeStr(GETDATE())
--   print 7
---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1Last'))is not null  
drop table #tmp_WhGoodsList_begin_1Last
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1Last from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1Last  ON #tmp_WhGoodsList_begin_1Last(cGoodsNo)

--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNoLast'))is not null  
drop table #temp_wh_DiffGoodsNoLast
select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNoLast
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1Last b
where dSaleDate between @dDate1 and @dDate2 
and a.cStoreNo=@cStoreNo
and a.cGoodsno=b.cGoodsNo 
group by a.cGoodsno,a.cSupNo


CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNoLast(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1Last'))is not null  
drop table #temp_wh_DiffGoodsNo1Last
select b.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo1Last
from #temp_wh_DiffGoodsNoLast a,#temp_goodsKuCunLast b
where a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
group by b.cGoodsno,a.cSupNo

CREATE INDEX IX_temp_wh_wh_DiffGoodsNo1Last  ON #temp_wh_DiffGoodsNo1Last(cGoodsNo)

update a
set
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCunLast a,#temp_wh_DiffGoodsNo1Last b
where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo


if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_NullLast'))is not null  
drop table #temp_wh_DiffGoodsNo1_NullLast
select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo1_NullLast
from #temp_wh_DiffGoodsNoLast a left join #temp_goodsKuCunLast b
on a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
where ISNULL(b.cGoodsNo,'')=''
group by a.cGoodsno,a.cSupNo

CREATE INDEX IX_temp_wh_DiffGoodsNo1_NullLast  ON #temp_wh_DiffGoodsNo1_NullLast(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null0Last'))is not null  
drop table #temp_wh_DiffGoodsNo1_Null0Last
select b.cGoodsNo,cSupNo=b.cSupplierNo,fqty_Sale=sum(a.fqty_Sale),fMoney_Diff=sum(a.fMoney_Diff),cRows=COUNT(b.cGoodsNo)
into #temp_wh_DiffGoodsNo1_Null0Last
from #temp_wh_DiffGoodsNo1_NullLast a,#temp_goodsKuCunLast b
where a.cGoodsno=b.cGoodsNo and a.cSupNo<>b.cSupplierNo
group by b.cGoodsNo,b.cSupplierNo
having COUNT(b.cGoodsNo)=1

update a
set 
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCunLast a,#temp_wh_DiffGoodsNo1_Null0Last b
where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo

/*
 2015-03-11 获取库存调整的商品
*/
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCunLast

--------获取期末前最新的毛利调整数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fDiffMoney=SUM(a.fDiffMoney)--,dDateTime=max(dDateTime),a.cSupNo
into #tmpGoodsRelationKucun_1
from  dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
where dDatetime between @dDateBgn and @dDateEnd and a.cgoodsno=b.cgoodsno  
group by a.cGoodsNo 
	
---------修改最近调整成本商品的毛利
--update a 
--set a.fMoney_Cost=ISNULL(a.销售数量,0)*ISNULL(b.fNewPrice,0),
--a.fML=isnull(a.销售金额,0)-ISNULL(a.销售数量,0)*ISNULL(b.fNewPrice,0),
--a.fPrice_Avg=b.fNewPrice
--from #temp_goodsKuCunLast a,#tmpGoodsRelationKucun_1 b
--where a.cGoodsNo=b.cGoodsNo  
update a 
set a.fMoney_Cost=ISNULL(a.fMoney_Cost,0)-ISNULL(b.fDiffMoney,0),
a.fML=isnull(a.销售金额,0)-(ISNULL(a.fMoney_Cost,0)-ISNULL(b.fDiffMoney,0))
from #temp_goodsKuCunLast a,#tmpGoodsRelationKucun_1 b
where a.cGoodsNo=b.cGoodsNo  

 
if (select OBJECT_ID('tempdb..#temp_goodsKuCunGroupbyLast'))is not null  drop table #temp_goodsKuCunGroupbyLast
select cGoodsNo,cSupplierNo,xsQty=SUM(销售数量),xsMoney=SUM(销售金额),fML=SUM(fML),
fMoney_Cost=SUM(fMoney_Cost)
into #temp_goodsKuCunGroupbyLast
from #temp_goodsKuCunLast
group by cGoodsNo,cSupplierNo 
 
CREATE INDEX IX_temp_goodsKuCunGroupbyLast  ON #temp_goodsKuCunGroupbyLast(cGoodsNo)

 

if (select OBJECT_ID('tempdb..#temp_GetLastMonthSale_wei'))is not null  
begin
	insert into #temp_GetLastMonthSale_wei(cSupplierNo,xsQty,xsMoney,fml,fMoney_Cost)
	select  cSupplierNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney) ,fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost)
	 from #temp_goodsKuCunGroupbyLast 
	 group by cSupplierNo
end else
begin
 
 select xsMoney=SUM(xsMoney) from #temp_goodsKuCunGroupbyLast
 end
/*获取时间段的入库记录 日期以单据日期为判断。*/

/*删除临时表*/
 
if(select object_id('tempdb..#temp_WhFrombeginLast')) is not null drop table #temp_WhFrombeginLast 
if(select object_id('tempdb..#temp_WhFromendLast')) is not null drop table #temp_WhFromendLast 
if (select OBJECT_ID('tempdb..#temp_maxWhdDateLast'))is not null drop table #temp_maxWhdDateLast
if (select OBJECT_ID('tempdb..#temp_ReadyKucunLast'))is not null drop table #temp_ReadyKucunLast
if(select object_id('tempdb..#temp_WhKouDianLast')) is not null drop table #temp_WhKouDianLast
if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunmlLast'))is not null  drop table #temp_SumgoodsKuCunmlLast
if (select OBJECT_ID('tempdb..#temp_goodsKuCunLast'))is not null  drop table #temp_goodsKuCunLast
GO
