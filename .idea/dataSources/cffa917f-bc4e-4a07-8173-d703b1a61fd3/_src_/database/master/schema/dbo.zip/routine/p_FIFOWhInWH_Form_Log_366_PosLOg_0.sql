/*
  p_FIFOWhInWH_Form_Log_366 '2014-12-27'

   p_FIFOWhInWH_Form_Log_366 '2015-1-1'
   
*/
create proc p_FIFOWhInWH_Form_Log_366_PosLOg
@SheetDate datetime
as 
declare @SheetDate_1 datetime 
set @SheetDate_1=@SheetDate-1
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@SheetDate)
set @Day1=day(@SheetDate)
set @Y1=YEAR(@SheetDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @M_1=MONTH(@SheetDate_1)
set @Day_1=day(@SheetDate_1)
set @Y_1=YEAR(@SheetDate_1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
 
-------经销管理库存------
if (select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
begin
 drop table #temp_PicWhFormcGoods_WH_Form_Log
end
select 业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
盘点单价, 库存标志 ,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
into #temp_PicWhFormcGoods_WH_Form_Log
from Pos_wh_Form.dbo.t_WH_Form_Log_1 with(nolock)  
union all
select 业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
盘点单价, 库存标志 ,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
from Pos_wh_Form.dbo.t_WH_Form_Log_0 with(nolock)  
where 业务日期=@SheetDate   
  
CREATE INDEX IX_tmp_PicWhFormcGoods_WH_Form_Log  ON #temp_PicWhFormcGoods_WH_Form_Log(cGoodsNo)

 

if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_0'))is not null
begin
  drop table #temp_MaxPicWhFormcGoods_0
end
select cGoodsNo,cSupplierNo,
fQuantity=sum(isnull(销售数量0,0)),
fLastSettle=sum(isnull(销售金额0,0)), 
fQuantity1=sum(isnull(特价销售数量,0)),
fLastSettle1=sum(isnull(特价销售金额,0)) 
into #temp_MaxPicWhFormcGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by  cGoodsNo,cSupplierNo

---销售成本
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Cost(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Cost b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

---销售数量
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Qty(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Qty b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

---销售金额
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Sale(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Sale b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

-----获取成本
if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_cost'))is not null
begin
  drop table #temp_MaxPicWhFormcGoods_cost
end
select cGoodsNo,cSupplierNo,
fMOney_Cost=sum(isnull(销售数量0,0)*isnull(fPrice_In,0))
,fQuantity=sum(isnull(销售数量0,0))
into #temp_MaxPicWhFormcGoods_cost
from #temp_PicWhFormcGoods_WH_Form_Log
where iAttribute<>20
group by  cGoodsNo,cSupplierNo


if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_cost0'))is not null
begin
  drop table #temp_MaxPicWhFormcGoods_cost0
end
select cGoodsNo,cSupplierNo,
fMOney_Cost=sum(isnull(扣率金额,0)),fQuantity=sum(isnull(销售数量0,0))
into #temp_MaxPicWhFormcGoods_cost0
from #temp_PicWhFormcGoods_WH_Form_Log
where iAttribute=20
group by  cGoodsNo,cSupplierNo
------处理联营
if @MMDAY1<>'0101'
begin 
   exec(' 
	update b set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(a.fQuantity,0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(a.fMoney_Cost,0) 
	from #temp_MaxPicWhFormcGoods_cost0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Cost b
	where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupplierNo  

    ')
end else
begin
	 exec('
     ---- 获取上一年的记录成本数据
    if (select object_id(''tempdb..#temp_CostGoodslog_0_1231''))is not null
	begin
	  drop table #temp_CostGoodslog_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(b.fQuantity,0),
    fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(b.fMOney_Cost,0)
    into #temp_CostGoodslog_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Cost a,#temp_MaxPicWhFormcGoods_cost0 b
    where cYear='''+@Y_1+''' and a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupplierNo
     
    
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Cost a, #temp_CostGoodslog_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
    ')
end
 

-------------******************获取当天剩余库存***********************88----------------
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Left(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Left b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_LeftGoods_0'))is not null
begin
 drop table #temp_LeftGoods_0
end 
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_Left,0)),
fLastSettle=sum(isnull(fMoney_Left,0)) 
into #temp_LeftGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo

exec(' 
------------修改剩余库存数量和金额
update b set 
fQty_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoney_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from #temp_LeftGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Left b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
 
')

---------------------取当天的所有入库、出库、报损、返厂、成本
----一、---------取当天入库数表：t_WH_Form_Log_Day_IN
---入库
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_In(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_In b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_INGoods_0'))is not null
begin
 drop table #temp_INGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
fLastSettle=sum(isnull(fMoney_In,0)) 
into #temp_INGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where dDateTime=@SheetDate and iAttribute=0
group by cGoodsNo,cSupplierNo

exec(' 
------------修改入库数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from #temp_INGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_In b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
 
')
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   exec('
	update Pos_WH_Form.dbo.t_WH_Form_Log_Day_In set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_INGoods_0_1231''))is not null
	begin
	  drop table #temp_INGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_INGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_In
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_In(cGoodsNO,cSupNo,cYear)
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	from #temp_INGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_In b
	on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_In a, #temp_INGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo and a.cYear='''+@Y1+'''	 
    ')
end

-------成品入库：t_WH_Form_Log_Day_Divide
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

 if (select object_id('tempdb..#temp_DivideGoods_0'))is not null
begin
 drop table #temp_DivideGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
fLastSettle=sum(isnull(fMoney_In,0)) 
into #temp_DivideGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where dDateTime=@SheetDate and iAttribute=9
group by cGoodsNo,cSupplierNo


exec(' 
------------修改成品入库数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from #temp_DivideGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  

')
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   exec('
	update Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_DivideGoods_0_1231''))is not null
	begin
	  drop table #temp_DivideGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_DivideGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide(cGoodsNO,cSupNo,cYear)
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	from #temp_DivideGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide b
	on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Divide a, #temp_DivideGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo and a.cYear='''+@Y1+'''	 
    ')
end

-------t_WH_Form_Log_Day_Effusion[报益单]
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_EffusionGoods_0'))is not null
begin
 drop table #temp_EffusionGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
fLastSettle=sum(isnull(fMoney_In,0)) 
into #temp_EffusionGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where dDateTime=@SheetDate and iAttribute=6
group by cGoodsNo,cSupplierNo


exec(' 
------------修改报溢数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from #temp_EffusionGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  

') 
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   exec('
	update Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_EffusionGoods_0_1231''))is not null
	begin
	  drop table #temp_EffusionGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_EffusionGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion(cGoodsNO,cSupNo,cYear)
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	from #temp_EffusionGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion b
	on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Effusion a, #temp_EffusionGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo and a.cYear='''+@Y1+'''	 
    ')
end
-------t_WH_Form_Log_Day_Return[退货入库] 3
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

 if (select object_id('tempdb..#temp_ReturnGoods_0'))is not null
begin
 drop table #temp_ReturnGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
fLastSettle=sum(isnull(fMoney_In,0)) 
into #temp_ReturnGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where dDateTime=@SheetDate and iAttribute=3
group by cGoodsNo,cSupplierNo


exec(' 
------------修改退货入库数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from #temp_ReturnGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
') 
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   exec('
	update Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_ReturnGoods_0_1231''))is not null
	begin
	  drop table #temp_ReturnGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_ReturnGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return(cGoodsNO,cSupNo,cYear)
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	from #temp_ReturnGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return b
	on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_Return a, #temp_ReturnGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo and a.cYear='''+@Y1+'''	 
    ')
end
--
-------t_WH_Form_Log_Day_TfrIn[调拨入库]
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''
if (select object_id('tempdb..#temp_TfrInGoods_0'))is not null
begin
 drop table #temp_TfrInGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
fLastSettle=sum(isnull(fMoney_In,0)) 
into #temp_TfrInGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where dDateTime=@SheetDate and iAttribute=31
group by cGoodsNo,cSupplierNo


exec(' 
------------修改调拨入库数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from #temp_TfrInGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
')

-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   exec('
	update Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_TfrInGoods_0_1231''))is not null
	begin
	  drop table #temp_TfrInGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_TfrInGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn(cGoodsNO,cSupNo,cYear)
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	from #temp_TfrInGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn b
	on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
	update a
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn1231,0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn1231,0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_TfrIn a, #temp_TfrInGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo and a.cYear='''+@Y1+'''	 
    ')
end
----------------***************出库、返厂、报损、***********************---------------
/*出库单t_WH_Form_Log_Day_Out[出库单]*/
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Out(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Out b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_OutGoods_0'))is not null
begin
 drop table #temp_OutGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(出库数量0,0)),
fLastSettle=sum(isnull(出库金额0,0)) 
into #temp_OutGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo


exec(' 
------------修改出库数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from #temp_OutGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Out b
where b.cYear='''+@Y1+'''   and a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo  
')
 
/*返厂单t_WH_Form_Log_Day_Rbd[返厂单]*/
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Rbd(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Rbd b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_RbdGoods_0'))is not null
begin
 drop table #temp_RbdGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(返厂数量0,0)),
fLastSettle=sum(isnull(返厂金额0,0)) 
into #temp_RbdGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo


exec(' 
------------修改返厂数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from #temp_RbdGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Rbd b
where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
')
 

/*报损 单t_WH_Form_Log_Day_Loss[报损单]*/
insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Loss(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Loss b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''
if (select object_id('tempdb..#temp_LossGoods_0'))is not null
begin
 drop table #temp_LossGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(报损数量0,0)),
fLastSettle=sum(isnull(报损金额0,0)) 
into #temp_LossGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo


exec(' 
------------修改报损单数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(a.fLastSettle,0)   
from #temp_LossGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Loss b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
')
 
 /*调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]*/
 insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Tfr(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Tfr b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''
if (select object_id('tempdb..#temp_TfrGoods_0'))is not null
begin
 drop table #temp_TfrGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(调拨出库数量0,0)),
fLastSettle=sum(isnull(调拨出库金额0,0)) 
into #temp_TfrGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo


exec(' 
------------修改调拨数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from #temp_TfrGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Tfr b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
')
 
 /*原料出库单t_WH_Form_Log_Day_Pack[原料出库单]*/
  insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_Pack(cGoodsNO,cSupNo,cYear)
select a.cGoodsNo,a.cSupplierNo,cYear=@Y1
from #temp_MaxPicWhFormcGoods_0 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_Pack b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

if (select object_id('tempdb..#temp_PackGoods_0'))is not null
begin
 drop table #temp_PackGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(原料出库数量0,0)),
fLastSettle=sum(isnull(原料出库金额0,0)) 
into #temp_PackGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo


exec(' 
------------修改原料出库单数量、金额
update b set 
fQtyIn_'+@MMDAY1+'=isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from #temp_PackGoods_0 a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_Pack b
where a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo and b.cYear='''+@Y1+'''  
')
 
/*------------------获取会员销售明细-来客数  会员销售--------------*/
   if (select object_id('tempdb..#temp_GoodsvipSale')) is not null
   drop table #temp_GoodsvipSale
   create table #temp_GoodsvipSale(dSaleDate datetime,cSaleSheetno varchar(32),
   cGoodsno varchar(32),fQuantity money,fLastSettle money,vipCount bigint,
   cVipNo varchar(32))

	declare @date1 datetime
	declare @date2 datetime
	set @date1=@SheetDate
	set @date2=@SheetDate
 
   if exists (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date1)  -- 包含在时间断内
   begin
	if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
	create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

	insert into #temp_SaleSheetInfor(databasename)
	select a.databasename from (
	select * from t_SaleSheetInfor
	where SaleEnd>=@date1 ) a,(
	select * from t_SaleSheetInfor
	where SaleBegin<=@date2) b
	where a.DataBaseName=b.DataBaseName

	declare SaleSheetInfor_cursor1 cursor
	for
	select databasename
	from #temp_SaleSheetInfor

	declare @InfoName1 varchar(32)

	open SaleSheetInfor_cursor1
	fetch next from SaleSheetInfor_cursor1
	into @InfoName1

	  while @@fetch_status=0
	  begin		 
        exec('	
                insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo
				from '+@InfoName1+'.dbo.t_SaleSheetDetail with (nolock)
				where dSaleDate='''+@date1+'''  --and ISNULL(cVipNo,'''')<>''''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
		  ')					  
		fetch next from SaleSheetInfor_cursor1
		into @InfoName1
	  end

	  close SaleSheetInfor_cursor1
	  deallocate SaleSheetInfor_cursor1
	  
		if not exists  (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date2)
		begin  	   
			    insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo
				from t_SaleSheetDetail with (nolock)
				--where dSaleDate=@date1  --and ISNULL(cVipNo,'')<>''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
			 
		end		
		end else
		begin   
				insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo--,vipCount=COUNT(cVipNo)
				from t_SaleSheetDetail with (nolock)
				where dSaleDate=@date1  --and ISNULL(cVipNo,'')<>''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
		end
		
 
-----------获取商品总销售来客数
if (select OBJECT_ID('tempdb..#temp_SaleSheetLk'))is not null drop table #temp_SaleSheetLk
select cGoodsno,lk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
viplk=CAST(null as money),fQuantityVip=CAST(null as money),fLastSettleVip=CAST(null as money)
into #temp_SaleSheetLk
from #temp_GoodsvipSale
group by cGoodsno

 -----------获取商品vip来客数
if (select OBJECT_ID('tempdb..#temp_SaleSheetvipLk'))is not null drop table #temp_SaleSheetvipLk
select cGoodsno,viplk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle)
into #temp_SaleSheetvipLk
from #temp_GoodsvipSale
where ISNULL(cVipNo,'')<>''
group by cGoodsno
 
 
update a set a.viplk=b.viplk,a.fQuantityVip=b.fQuantity,a.fLastSettleVip=b.fLastSettle
from #temp_SaleSheetLk a,#temp_SaleSheetvipLk b
where a.cGoodsno=b.cGoodsno

   
 insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip(cGoodsNO,cYear)
select a.cGoodsNo,cYear=@Y1
from #temp_SaleSheetLk a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip b
on a.cGoodsNo=b.cGoodsNO  and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''


insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip(cGoodsNO,cYear)
select a.cGoodsNo,cYear=@Y1
from #temp_SaleSheetLk a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip b
on a.cGoodsNo=b.cGoodsNO and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount(cGoodsNO,cYear)
select a.cGoodsNo,cYear=@Y1
from #temp_SaleSheetLk a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount b
on a.cGoodsNo=b.cGoodsNO and b.cYear=@Y1
where isnull(b.cGoodsNO,'')=''

exec(' 
------------修改数量
update b set 
fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(a.fQuantityVip,0) 
from #temp_SaleSheetLk a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip b
where a.cGoodsNo=b.cGoodsNO  and b.cYear='''+@Y1+'''  
 
------------修改会员销售金额
  
update b set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(a.fLastSettleVip,0)  
from #temp_SaleSheetLk a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip b
where a.cGoodsNo=b.cGoodsNO  and b.cYear='''+@Y1+''' 

 
-------- 修改总来客数 和会员来客数
 
  
update b set Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY1+',0)+isnull(a.viplk,0),
Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY1+',0)+isnull(a.lk,0) 
from #temp_SaleSheetLk a,Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount b
where a.cGoodsNo=b.cGoodsNO  and b.cYear='''+@Y1+'''  
 
 
')
 
if (@M1+@Day1)<>'0101'
begin
exec('
------------修改会员销售数量 
update Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip
set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(fQty_'+@MMDAY_1+',0)
------------修改会员销售金额
update Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip
set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(Sale_'+@MMDAY_1+',0)
 
-------- 修改总来客数 和会员来客数
update Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount
set Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY1+',0)+isnull(Qtyzs_'+@MMDAY_1+',0),
Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY1+',0)+isnull(Qty_'+@MMDAY_1+',0)
 
')
end    else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_QtyVipGoods_0_1231''))is not null
	begin
	  drop table #temp_QtyVipGoods_0_1231
	end
    select cGoodsNo,fQty1231=isnull(fQty_'+@MMDAY_1+',0)
    into #temp_QtyVipGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip
    where cYear='''+@Y_1+'''  
    
    if (select object_id(''tempdb..#temp_VipGoodsNull''))is not null
	begin
	  drop table #temp_VipGoodsNull
	end
    select a.cGoodsNo,cYear='''+@Y1+''' 
    into #temp_VipGoodsNull
	from #temp_QtyVipGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip b
	on a.cGoodsNo=b.cGoodsNO and b.cYear='''+@Y1+''' 
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip(cGoodsNO,cYear)
	select cGoodsNo,cYear
	from #temp_VipGoodsNull
	
	update a
	set fQty_'+@MMDAY1+'=isnull(fQty1231,0)+isnull(fQty_'+@MMDAY1+',0) 
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_QtyVip a, #temp_QtyVipGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO  and a.cYear='''+@Y1+'''	
	
	
	if (select object_id(''tempdb..#temp_SaleVipGoods_0_1231''))is not null
	begin
	  drop table #temp_SaleVipGoods_0_1231
	end
    select cGoodsNo,Sale1231=isnull(Sale_'+@MMDAY_1+',0)
    into #temp_SaleVipGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip(cGoodsNO,cYear)
	--select a.cGoodsNo,cYear='''+@Y1+''' 
	--from #temp_SaleVipGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip b
	--on b.cYear='''+@Y1+'''  and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	--where isnull(b.cGoodsNO,'''')=''''
	select cGoodsNo,cYear
	from #temp_VipGoodsNull
	
	update a
	set Sale_'+@MMDAY1+'=isnull(Sale1231,0)+isnull(Sale_'+@MMDAY1+',0) 
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_SaleVip a, #temp_SaleVipGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cYear='''+@Y1+'''	
	
	
	
	if (select object_id(''tempdb..#temp_VipCountGoods_0_1231''))is not null
	begin
	  drop table #temp_VipCountGoods_0_1231
	end
    select cGoodsNo,Qtyzs1231=isnull(Qtyzs_'+@MMDAY_1+',0),Qty1231=isnull(Qty_'+@MMDAY_1+',0)
    into #temp_VipCountGoods_0_1231
    from Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount
    where cYear='''+@Y_1+'''  
    
    insert into Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount(cGoodsNO,cYear)
	--select a.cGoodsNo,cYear='''+@Y1+''' 
	--from #temp_VipCountGoods_0_1231 a left join Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount b
	--on a.cGoodsNo=b.cGoodsNO  and b.cYear='''+@Y1+''' 
	--where isnull(b.cGoodsNO,'''')=''''
	select cGoodsNo,cYear
	from #temp_VipGoodsNull
	
	update a
	set Qtyzs_'+@MMDAY1+'=isnull(Qtyzs1231,0)+isnull(Qtyzs_'+@MMDAY1+',0),
	Qty_'+@MMDAY1+'=isnull(Qty1231,0)+isnull(Qty_'+@MMDAY1+',0)
	from Pos_WH_Form.dbo.t_WH_Form_Log_Day_VipCount a, #temp_VipCountGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cYear='''+@Y1+'''	
	
    ')
end


GO
