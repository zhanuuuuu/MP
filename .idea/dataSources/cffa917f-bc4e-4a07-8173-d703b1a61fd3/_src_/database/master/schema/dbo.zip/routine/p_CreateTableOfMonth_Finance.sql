


CREATE   procedure p_CreateTableOfMonth_Finance
@cYearF char(4)
as
begin
  declare @iMonth int
  declare @iWeeks int
  declare @iWeeks_old int
	declare @cYear varchar(4)
	declare @cYearEnd varchar(4) 
	declare @cMonth varchar(2) 
	declare @dDate1 datetime
	declare @dDate2	datetime

  declare cursorMonth cursor
	for 
	select cYear,cYearEnd,cMonth,dDate1,dDate2
	from dbo.t_MonthsOfYearSerno
	where cYear=@cYearF
	order by cYear,cYearEnd,cMonth
	
	open cursorMonth
	Fetch next from cursorMonth
	into @cYear,@cYearEnd,@cMonth,@dDate1,@dDate2

  while @@Fetch_status=0
	begin
		if year(@dDate1)=year(@dDate2)
		begin
			set @iWeeks=dbo.f_GetWeeks(@dDate1)-1
			
			while @dDate1<=@dDate2
			begin
					if not exists(select cYear from dbo.t_WeekOfMonth_Finance
							where cYear=@cYear and cMonth=@cMonth and iWeekNo=dbo.f_GetWeeks(@dDate1)-@iWeeks
						 )
					begin
						insert into dbo.t_WeekOfMonth_Finance(cYear,cYearEnd,cMonth,iWeekNo,cWeekName1,cWeekName2,dDate1,dDate2)
						values(@cYear,@cYearEnd,@cMonth,dbo.f_GetWeeks(@dDate1)-@iWeeks,
									 DATENAME(dw,@dDate1),DATENAME(dw,@dDate1),@dDate1,@dDate1)
		
					end else
					begin
						update dbo.t_WeekOfMonth_Finance set dDate2=@dDate1,cWeekName2=DATENAME(dw,@dDate1)
						where cYear=@cYear and cMonth=@cMonth and iWeekNo=dbo.f_GetWeeks(@dDate1)-@iWeeks
		
					end
					set @dDate1=@dDate1+1
			end	
		end else
		begin
			set @iWeeks=dbo.f_GetWeeks(@dDate1)-1
      set @iWeeks_old=0
			while @dDate1<=@dDate2
			begin
					if year(@dDate1)=year(@dDate2)
					begin	
            if (@iWeeks_old=0) set @iWeeks_old=dbo.f_GetWeeks(@dDate1-1)
					end
					if not exists(select cYear from dbo.t_WeekOfMonth_Finance
							where cYear=@cYear and cMonth=@cMonth and iWeekNo=dbo.f_GetWeeks(@dDate1)-@iWeeks+@iWeeks_old
--							where cYear=@cYear and cMonth=@cMonth and iWeekNo=@iWeeks_old+@iWeeks-1
						 )
					begin
						insert into dbo.t_WeekOfMonth_Finance(cYear,cYearEnd,cMonth,iWeekNo,cWeekName1,cWeekName2,dDate1,dDate2)
						values(@cYear,@cYearEnd,@cMonth,
									 dbo.f_GetWeeks(@dDate1)-@iWeeks+@iWeeks_old,	
--dbo.f_GetWeeks(@dDate1)-@iWeeks,
									 DATENAME(dw,@dDate1),DATENAME(dw,@dDate1),@dDate1,@dDate1)
		
					end else
					begin
						update dbo.t_WeekOfMonth_Finance set dDate2=@dDate1,cWeekName2=DATENAME(dw,@dDate1)
						where cYear=@cYear and cMonth=@cMonth 
									and iWeekNo=dbo.f_GetWeeks(@dDate1)-@iWeeks+@iWeeks_old
--and iWeekNo=dbo.f_GetWeeks(@dDate1)-@iWeeks
		
					end
					
					set @dDate1=@dDate1+1
			end
		end			

		Fetch next from cursorMonth
		into @cYear,@cYearEnd,@cMonth,@dDate1,@dDate2
	end

	CLOSE cursorMonth
	DEALLOCATE cursorMonth

  update dbo.t_WeekOfMonth_Finance set iDays=datediff(day,dDate1,dDate2)+1
end

/*


p_CreateTableOfMonth_Finance '2006'

select * from dbo.t_WeekOfMonth_Finance

truncate table t_WeekOfMonth_Finance
*/



GO
