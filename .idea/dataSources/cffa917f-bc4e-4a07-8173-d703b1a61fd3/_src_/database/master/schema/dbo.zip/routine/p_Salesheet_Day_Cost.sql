create procedure p_Salesheet_Day_Cost
@dDate datetime,
@cWhNo varchar(32)
as
begin
  if (select object_id('tempdb..#tmp_p_Salesheet_Day_Cost_01'))is not null
  begin
	 drop table #tmp_p_Salesheet_Day_Cost_01
  end

  select cGoodsNo,fQty_Cost=SUM(fQty_Cost),fMoney_Cost=SUM(fMoney_Cost),
  fPrice_Cost=SUM(fMoney_Cost)/case when SUM(fQty_Cost)<>0 then SUM(fQty_Cost) else null end 
  into #tmp_p_Salesheet_Day_Cost_01
  from t_Cost_distribute 
  where dDate_Sheet=@dDate and iAttribute=10 and cWhNo=@cWhNo
  group by cGoodsNo,dDate_Sheet
  
  update a set a.fPrice_Cost=b.fCKPrice
  from #tmp_p_Salesheet_Day_Cost_01 a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo and a.fPrice_Cost is null
  
  update a set a.fCostPrice_sales=b.fPrice_Cost
  from t_SaleSheet_Day a,#tmp_p_Salesheet_Day_Cost_01 b
  where a.cWHno=@cWhNo and a.cGoodsNo=b.cGoodsNo

end
GO
