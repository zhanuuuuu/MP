 
 /*
 
if (select object_id('tempdb..#temp_Goods'))is not null
drop table #temp_Goods
-- 取相应类别下的商品。。。 				
 select cGoodsNo into #temp_Goods from t_Goods
 where cgoodstypeno like '1000%'
 
exec  p_GetcGoodsMonthSaleDay_Zh '2015-1-1','2015-01-28','01'
 
*/
CREATE proc [dbo].[p_GetcGoodsMonthSaleDay_Zh]
@dDateBgn datetime,
@dDateEnd datetime, 
@cWhno varchar(32)
as
begin 
 
if @dDateEnd>CONVERT (date, GETDATE())
begin
  set @dDateEnd=CONVERT (date, GETDATE())
end
 
declare @day int
set @day=DATEDIFF(DAY,@dDateBgn,@dDateEnd)+1 
 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsno,cWHno  into  #tmp_WhGoodsList  from (
select distinct cGoodsNo=b.cGoodsNo_minPackage,cWHno=@cWhno
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsNo,cWHno=@cWhno   
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
) a
 
CREATE INDEX IX_tmp_WhGoodsList ON #tmp_WhGoodsList(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

declare  @cdbname varchar(32)

select distinct @cdbname=Pos_WH_Form,@cWhNo=cWhNo from t_WareHouse where ISNULL(bMainSale,0)=1

 --print dbo.getTimeStr(GETDATE())
--print 1
 /*快照表中的最大日期。。。*/
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)
insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
 
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
declare @BgndDate1 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
					set @BgndDate1=@dDate_1
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
					set @BgndDate1=@dDate_1
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd 
		--set @maxWhdDate=@dDateBgn-1
		set @BgndDate1=@maxWhdDate+1
	end 

-----查最大日结时间内信息@dDateBegin到@dDateEnd

--销售数量0, 销售金额0, 
--特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
-------取记账部分：快照数据。
	
declare @strDateBgn datetime
declare @strDateEnd datetime
declare @strBgn varchar(32)
set @strDateBgn= @dDateBgn
set @strDateEnd=@maxWhdDate
set @strBgn=dbo.getdaystr(@dDateBgn)  

declare @date1 datetime
declare @a int  
declare @daylog int
set @daylog=DATEDIFF (DAY,@strDateBgn,@strDateEnd)+1 
declare @strQtyCon varchar(2000)
set @strQtyCon=''
declare @strQtyCon_1 varchar(2000)
set @strQtyCon_1=''
declare @strSaleCon varchar(2000)
set @strSaleCon=''
declare @strSaleCon_1 varchar(2000)
set @strSaleCon_1=''

declare @strSaleCon_20 varchar(2000)
set @strSaleCon_20=''

declare @strSaleCon_2 varchar(2000)
set @strSaleCon_2=''

declare @strSumSaleCon varchar(2000)
set @strSumSaleCon=''
declare @strSumSaleCon_1 varchar(2000)
set @strSumSaleCon_1=''

declare @strSumSaleQtyCon varchar(2000)
set @strSumSaleQtyCon=''
declare @strSumSaleQtyCon_1 varchar(2000)
set @strSumSaleQtyCon_1=''

declare @strSumSale varchar(2000)
set @strSumSale=''
---销售字段
declare @cAddFields varchar(2000)
set @cAddFields=''
---销售数量字段
declare @cAddFieldsQty varchar(2000)
set @cAddFieldsQty=''
-----毛利
declare @strfMl0 varchar(2000)
set @strfMl0=''
declare @strSumfMl0 varchar(2000)
set @strSumfMl0=''
declare @strfMl1 varchar(2000)
set @strfMl1=''
declare @strSumfMl1 varchar(2000)
set @strSumfMl1=''
declare @cAddFieldsfMl varchar(2000)
set @cAddFieldsfMl=''
declare @strFmlCon varchar(2000)
set @strFmlCon=''
---库存
declare @strKu1 varchar(2000)
set @strKu1=''
declare @strSumKu1 varchar(2000)
set @strSumKu1=''
declare @strKuQty1 varchar(2000)
set @strKuQty1=''
declare @strSumKuqty1 varchar(2000)
set @strSumKuqty1=''

declare @cAddFieldsKu varchar(2000)
set @cAddFieldsKu=''
declare @strKuCon varchar(2000)
set @strKuCon=''
declare @strKuConQty varchar(2000)
set @strKuConQty=''

set @a=0
declare @MD1231 varchar(8)
set @MD1231=''
declare @MDYear varchar(8)
set @MDYear=''

declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
declare @MD varchar(8)

declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
declare @M_D varchar(8)
 
 --print dbo.getTimeStr(GETDATE())
--print 2
while @a<@daylog 
begin	  
	set @M1=MONTH(@strDateBgn+@a)
	set @Day1=day(@strDateBgn+@a)
	set @Y1=YEAR(@strDateBgn+@a)
	if LEN(@M1)=1 
	begin
	   set @M1='0'+@M1
	end
	if LEN(@Day1)=1 
	begin
	   set @Day1='0'+@Day1
	end
	set @MD=@M1+@Day1
	set @strQtyCon=@strQtyCon+'fQty_'+@MD+','
	set @strSaleCon=@strSaleCon+'Sale_'+@MD+','
	set @strSumSaleCon=@strSumSaleCon+'Sale_'+@MD+'=sum(Sale_'+@MD+'),'
	set @strSumSaleQtyCon=@strSumSaleQtyCon+'fQty_'+@MD+'=sum(fQty_'+@MD+'),'
	
	set @strSumSale=@strSumSale+'isnull(Sale_'+@MD+',0)+'
	
	set @cAddFields=@cAddFields+'Sale_'+@MD+' money,'
	set @cAddFieldsQty=@cAddFieldsQty+'fQty_'+@MD+' money,'
	
	set @strfMl1=@strfMl1+'fMoneyIn_'+@MD+','
	set @strSumfMl1=@strSumfMl1+'Sale_'+@MD+'=sum(fMoneyIn_'+@MD+'),'
	set @strFmlCon=@strFmlCon+'Fml_'+@MD+','
	
	set @cAddFieldsfMl=@cAddFieldsfMl+'Fml_'+@MD+' money,'
	
	set @strKu1=@strKu1+'fMoney_'+@MD+','
	set @strKuQty1=@strKuQty1+'fQty_'+@MD+','
	
	set @cAddFieldsKu=@cAddFieldsKu+'KuQty_'+@MD+' money,Ku_'+@MD+' money,'
	set @strSumKu1=@strSumKu1+'Sale_'+@MD+'=sum(fMoney_'+@MD+'),'
	set @strSumKuQty1=@strSumKuQty1+'fQty_'+@MD+'=sum(fQty_'+@MD+'),'
	
	set @strKuCon=@strKuCon+'Ku_'+@MD+','
	set @strKuConQty=@strKuConQty+'KuQty_'+@MD+','
	
	set @M_1=MONTH(@strDateBgn+@a-1)
	set @Day_1=day(@strDateBgn+@a-1)
	set @Y_1=YEAR(@strDateBgn+@a-1)
	if LEN(@M_1)=1 
	begin
	   set @M_1='0'+@M_1
	end
	if LEN(@Day_1)=1 
	begin
	   set @Day_1='0'+@Day_1
	end
	set @M_D=@M_1+@Day_1
	if(@M_D='1231')
	begin
	  set @MD1231=@M_D
	  set @MDYear=@Y_1
	end else
	begin
	  set @strQtyCon_1=@strQtyCon_1+'fQty_'+@M_D+','
	  set @strSaleCon_1=@strSaleCon_1+'Sale_'+@M_D+','
	   
	  set @strSumSaleCon_1=@strSumSaleCon_1+'Sale_'+@M_D+'=sum(Sale_'+@M_D+'),'
	  set @strSumSaleQtyCon_1=@strSumSaleQtyCon_1+'fQty_'+@M_D+'=sum(fQty_'+@M_D+'),'
	  
	  set @strfMl0=@strfMl0+'fMoneyIn_'+@M_D+','
	  set @strSumfMl0=@strSumfMl0+'Sale_'+@M_D+'=sum(fMoneyIn_'+@M_D+'),'
	end
    set @a=@a+1      		      
end

set @cAddFields=@cAddFields+'合计 money'
set @cAddFieldsQty=@cAddFieldsQty+'合计 money'
set @strSumSaleCon=@strSumSaleCon+'合计=null'
set @strSumSaleCon_1=@strSumSaleCon_1+'合计=null'
set @strSumSaleQtyCon_1=@strSumSaleQtyCon_1+'合计=null'
set @strQtyCon=@strQtyCon+'合计'
set @strSaleCon=@strSaleCon+'合计'
set @strSaleCon_1=@strSaleCon_1+'合计'
set @strQtyCon_1=@strQtyCon_1 +'合计'
set @strSumSaleQtyCon=@strSumSaleQtyCon+'合计=null'
set @strSumSale=@strSumSale+'0'
----毛利
set @strFmlCon=@strFmlCon+'合计'
set @strfMl0=@strfMl0+' 合计'
set @strfMl1=@strfMl1+' 合计'
set @cAddFieldsfMl=@cAddFieldsfMl+'合计 money'
---库存
set @strKu1=@strKu1+'合计'
set @cAddFieldsKu=@cAddFieldsKu+'合计 money,Qty合计 money'

set @strSumKu1=@strSumKu1+'合计=null'
set @strKuCon=@strKuCon+'合计'

set @strKuQty1=@strKuQty1+'Qty合计' 

set @strSumKuQty1=@strSumKuQty1+'Qty合计=null'
set @strKuConQty=@strKuConQty+'Qty合计'

 --print dbo.getTimeStr(GETDATE())
--print 3
----销售
if(select object_id('tempdb..#temp_WhFrom1231')) is not null drop table #temp_WhFrom1231
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend 
CREATE TABLE #temp_WhFrom1231([cGoodsNo] [varchar](32) NOT NULL,fQty_1231 money,Sale_1231 money)
CREATE TABLE #temp_WhFrombegin([cGoodsNo] [varchar](32) NOT NULL)
CREATE TABLE #temp_WhFromend([cGoodsNo] [varchar](32) NOT NULL)

CREATE INDEX IX_temp_WhFrom1231  ON #temp_WhFrom1231(cGoodsNo)
CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)

exec( 'alter table #temp_WhFrombegin add '+@cAddFields)
exec( 'alter table #temp_WhFromend add '+@cAddFields)

if(select object_id('tempdb..#temp_WhFrombeginQty')) is not null drop table #temp_WhFrombeginQty
if(select object_id('tempdb..#temp_WhFromendQty')) is not null drop table #temp_WhFromendQty  
CREATE TABLE #temp_WhFrombeginQty([cGoodsNo] [varchar](32) NOT NULL)
CREATE TABLE #temp_WhFromendQty([cGoodsNo] [varchar](32) NOT NULL)

exec( 'alter table #temp_WhFrombeginQty add '+@cAddFieldsQty)
exec( 'alter table #temp_WhFromendQty add '+@cAddFieldsQty)

CREATE INDEX IX_temp_WhFrombeginQty  ON #temp_WhFrombeginQty(cGoodsNo)
CREATE INDEX IX_temp_WhFromendQty  ON #temp_WhFromendQty(cGoodsNo) 
----毛利
if(select object_id('tempdb..#temp_WhFromFml1231')) is not null drop table #temp_WhFromFml1231
if(select object_id('tempdb..#temp_WhFrombeginFml')) is not null drop table #temp_WhFrombeginFml
if(select object_id('tempdb..#temp_WhFromendFml')) is not null drop table #temp_WhFromendFml 
CREATE TABLE #temp_WhFromFml1231([cGoodsNo] [varchar](32) NOT NULL,fQty_1231 money,Sale_1231 money)
CREATE TABLE #temp_WhFrombeginFml([cGoodsNo] [varchar](32) NOT NULL)
CREATE TABLE #temp_WhFromendFml([cGoodsNo] [varchar](32) NOT NULL)
exec( 'alter table #temp_WhFrombeginFml add '+@cAddFieldsfMl)
exec( 'alter table #temp_WhFromendFml add '+@cAddFieldsfMl)
CREATE INDEX IX_temp_WhFromFml1231  ON #temp_WhFromFml1231(cGoodsNo)
CREATE INDEX IX_temp_WhFrombeginFml  ON #temp_WhFrombeginFml(cGoodsNo)
CREATE INDEX IX_temp_WhFromendFml  ON #temp_WhFromendFml(cGoodsNo) 
----库存
if(select object_id('tempdb..#temp_WhFromendKc')) is not null drop table #temp_WhFromendKc 
CREATE TABLE #temp_WhFromendKc([cGoodsNo] [varchar](32) NOT NULL)
exec( 'alter table #temp_WhFromendKc add '+@cAddFieldsKu)

CREATE INDEX IX_temp_WhFromendKc  ON #temp_WhFromendKc(cGoodsNo) 


------获取上年的年末数据 
declare @strSaleQtyCon_2 varchar(2000)
declare @strSaleQtyCon_20 varchar(2000)
---金额字段
set @strSaleCon_2=@strSaleCon_1
set @strSaleCon_20=@strSaleCon_1
---销售数量字段
set @strSaleQtyCon_2=@strQtyCon_1
set @strSaleQtyCon_20=@strQtyCon_1
 --print dbo.getTimeStr(GETDATE())
--print 4
if @MD1231='1231'
begin
    set @strSaleCon_2='null,'+@strSaleCon_2
    set @strSaleCon_20='-b.Sale_1231,'+@strSaleCon_1
 
    set @strSaleQtyCon_2='null,'+@strSaleQtyCon_2
    set @strSaleQtyCon_20='-b.fQty_1231,'+@strQtyCon_1
    
    exec('
	--------期末销售  
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_1231Sale''))is not null  drop table #temp_Wh_Goods_1231Sale	            
	select a.cgoodsno,Sale=b.Sale_'+@MD1231+' 
	into #temp_Wh_Goods_1231Sale					
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@MD1231+' b
	with (nolock) 
	where b.cyear='''+@MDYear+''' and  a.cGoodsNo=b.cGoodsNo
 
    
 
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_1231Sale''))is not null  drop table #temp_SumWh_Goods_1231Sale
	select cgoodsno,Sale=sum(Sale)
	into #temp_SumWh_Goods_1231Sale
	from  #temp_Wh_Goods_1231Sale
	group by cgoodsno 
	
	insert into #temp_WhFrom1231(cgoodsno,Sale_1231)
	select  cgoodsno,Sale
	from #temp_SumWh_Goods_1231Sale 
	
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_1231Qty''))is not null  drop table #temp_Wh_Goods_1231Qty	            
	select a.cgoodsno,Qty=b.fQty_'+@MD1231+' 
	into #temp_Wh_Goods_1231Qty					
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@MD1231+' b
	with (nolock) 
	where b.cyear='''+@MDYear+''' and  a.cGoodsNo=b.cGoodsNo
 
    
 
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_1231Qty''))is not null  drop table #temp_SumWh_Goods_1231Qty
	select cgoodsno,Qty=sum(Qty)
	into #temp_SumWh_Goods_1231Qty
	from  #temp_Wh_Goods_1231Qty
	group by cgoodsno 
	
	update a
	set a.fQty_1231=b.Qty
	from #temp_WhFrom1231 a,#temp_SumWh_Goods_1231Qty b
	where a.cgoodsno=b.cgoodsno
	
	
	----成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_1231Cost''))is not null  drop table #temp_Wh_Goods_1231Cost
	select a.cgoodsno,fMoney=b.fMoneyIn_'+@MD1231+' 					 
	into #temp_Wh_Goods_1231Cost
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@MD1231+' b
	with (nolock) 
	where b.cyear='''+@MDYear+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_1231Cost''))is not null  drop table #temp_SumWh_Goods_1231Cost
	select cgoodsno,fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_1231Cost
	from  #temp_Wh_Goods_1231Cost
	group by cgoodsno 
	

    insert into #temp_WhFromFml1231(cgoodsno,Sale_1231)
	select  cgoodsno,fMoney
	from #temp_SumWh_Goods_1231Cost 
	')
end

set @strSaleCon_20=REPLACE(@strSaleCon_20,',',',-')
set @strSaleCon_2='-'+REPLACE(@strSaleCon_2,',',',-')

set @strSaleQtyCon_20=REPLACE(@strSaleQtyCon_20,',',',-')
set @strSaleQtyCon_2='-'+REPLACE(@strSaleQtyCon_2,',',',-')
 --print dbo.getTimeStr(GETDATE())
--print 5
------获取期初数据
--select @strSaleCon,@strSaleCon_1,@strSaleCon_2,@strSaleCon_20
 
exec('
--------期初销售  
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale	            
select a.cgoodsno,'+@strSaleCon_1+'=null
into #temp_Wh_Goods_beginSale					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
select cgoodsno,'+@strSumSaleCon_1+'
into #temp_SumWh_Goods_beginSale
from  #temp_Wh_Goods_beginSale
group by cgoodsno 

--------期初销售数量 
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSaleQty''))is not null  drop table #temp_Wh_Goods_beginSaleQty	            
select a.cgoodsno,'+@strQtyCon_1+'=null
into #temp_Wh_Goods_beginSaleQty					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSaleQty''))is not null  drop table #temp_SumWh_Goods_beginSaleQty
select cgoodsno,'+@strSumSaleQtyCon_1+'
into #temp_SumWh_Goods_beginSaleQty
from  #temp_Wh_Goods_beginSaleQty
group by cgoodsno  

 
--------期初成本  
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost           
select a.cgoodsno,'+@strfMl0+'=null
into #temp_Wh_Goods_beginCost					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
select cgoodsno,'+@strSumfMl0+'合计=null
into #temp_SumWh_Goods_beginCost
from  #temp_Wh_Goods_beginCost
group by cgoodsno 


if '''+@MD1231+'''=''1231''
begin 
    insert into #temp_WhFrombegin(cgoodsno,'+@strSaleCon+')
	select  a.cgoodsno,'+@strSaleCon_20+'
	from #temp_SumWh_Goods_beginSale a left join #temp_WhFrom1231 b
	on a.cGoodsno=b.cGoodsno	 
	
	insert into #temp_WhFrombeginQty(cgoodsno,'+@strQtyCon+')
	select  a.cgoodsno,'+@strSaleQtyCon_20+'
	from #temp_SumWh_Goods_beginSaleQty a left join #temp_WhFrom1231 b
	on a.cGoodsno=b.cGoodsno	 
	
	
	insert into #temp_WhFrombeginFml(cgoodsno,'+@strFmlCon+')
	select  a.cgoodsno,'+@strSaleCon_20+'
	from #temp_SumWh_Goods_beginCost a left join #temp_WhFromFml1231 b
	on a.cGoodsno=b.cGoodsno	
	
end else
begin 
	insert into #temp_WhFrombegin(cgoodsno,'+@strSaleCon+')
	select  cgoodsno,'+@strSaleCon_2+'
	from #temp_SumWh_Goods_beginSale 
	
	insert into #temp_WhFrombeginQty(cgoodsno,'+@strQtyCon+')
	select  cgoodsno,'+@strSaleQtyCon_2+'
	from #temp_SumWh_Goods_beginSaleQty 
	
	insert into #temp_WhFrombeginFml(cgoodsno,'+@strFmlCon+')
	select  cgoodsno,'+@strSaleCon_2+'
	from #temp_SumWh_Goods_beginCost 
end

')
  --print dbo.getTimeStr(GETDATE())
--print 6
exec('
--------期末销售  
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale	            
select a.cgoodsno,'+@strSaleCon+'=null
into #temp_Wh_Goods_endSale					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
select cgoodsno,'+@strSumSaleCon+'
into #temp_SumWh_Goods_endSale
from  #temp_Wh_Goods_endSale
group by cgoodsno 

if (select OBJECT_ID(''tempdb..#temp_Wh_endSale''))is not null  drop table #temp_Wh_endSale
select cgoodsno,'+@strSaleCon+'
into #temp_Wh_endSale
from  #temp_SumWh_Goods_endSale
union all
select cgoodsno,'+@strSaleCon+' from #temp_WhFrombegin

if (select OBJECT_ID(''tempdb..#temp_SumWh_endSale''))is not null  drop table #temp_SumWh_endSale
select cgoodsno,'+@strSumSaleCon+' 
into #temp_SumWh_endSale
from #temp_Wh_endSale
group by cgoodsno

insert into #temp_WhFromend(cgoodsno,'+@strSaleCon+')
select  cgoodsno,'+@strSaleCon+'
from #temp_SumWh_endSale 
order by cGoodsno

 
----------期末销售数量 
if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSaleQty''))is not null  drop table #temp_Wh_Goods_endSaleQty	            
select a.cgoodsno,'+@strQtyCon+'=null
into #temp_Wh_Goods_endSaleQty					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

 

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSaleQty''))is not null  drop table #temp_SumWh_Goods_endSaleQty
select cgoodsno,'+@strSumSaleQtyCon+'
into #temp_SumWh_Goods_endSaleQty
from  #temp_Wh_Goods_endSaleQty
group by cgoodsno 

if (select OBJECT_ID(''tempdb..#temp_Wh_endSaleQty''))is not null  drop table #temp_Wh_endSaleQty
select cgoodsno,'+@strQtyCon+'
into #temp_Wh_endSaleQty
from  #temp_SumWh_Goods_endSaleQty
union all
select cgoodsno,'+@strQtyCon+' from #temp_WhFrombeginQty

 
 
if (select OBJECT_ID(''tempdb..#temp_SumWh_endSaleQty''))is not null  drop table #temp_SumWh_endSaleQty
select cgoodsno,'+@strSumSaleQtyCon+' 
into #temp_SumWh_endSaleQty
from #temp_Wh_endSaleQty
group by cgoodsno

insert into #temp_WhFromendQty(cgoodsno,'+@strQtyCon+')
select  cgoodsno,'+@strQtyCon+'
from #temp_SumWh_endSaleQty 
order by cGoodsno

 
---------------成本

if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost           
select a.cgoodsno,'+@strfMl1+'=null
into #temp_Wh_Goods_endCost					
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
select cgoodsno,'+@strSumfMl1+'合计=null
into #temp_SumWh_Goods_endCost
from  #temp_Wh_Goods_endCost
group by cgoodsno 


if (select OBJECT_ID(''tempdb..#temp_Wh_endCost''))is not null  drop table #temp_Wh_endCost
select cgoodsno,'+@strSaleCon+'
into #temp_Wh_endCost
from  #temp_SumWh_Goods_endCost
union all
select cgoodsno,'+@strFmlCon+' from #temp_WhFrombeginFml


if (select OBJECT_ID(''tempdb..#temp_SumWh_endCost''))is not null  drop table #temp_SumWh_endCost
select cgoodsno,'+@strSumSaleCon+' 
into #temp_SumWh_endCost
from #temp_Wh_endCost
group by cgoodsno

insert into #temp_WhFromendFml(cgoodsno,'+@strFmlCon+')
select  cgoodsno,'+@strSaleCon+'
from #temp_SumWh_endCost
order by cGoodsno


---------------库存

if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endKu''))is not null  drop table #temp_Wh_Goods_endKu          
select a.cgoodsno,'+@strKuQty1+'=null,'+@strKu1+'=null
into #temp_Wh_Goods_endKu			
from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
with (nolock) 
where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo

 
 
 if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endKu''))is not null  drop table #temp_SumWh_Goods_endKu
select cgoodsno,'+@strSumKuQty1+','+@strSumKu1+'
into #temp_SumWh_Goods_endKu
from  #temp_Wh_Goods_endKu
group by cgoodsno 
 

insert into #temp_WhFromendKc(cgoodsno,'+@strKuConQty+','+@strKuCon+')
select  cgoodsno,'+@strKuQty1+','+@strSaleCon+'
from #temp_SumWh_Goods_endKu
order by cGoodsno
')
 --print dbo.getTimeStr(GETDATE())
--print 7
declare @strSalLine varchar(4000)
set @strSalLine=REPLACE(@strSaleCon,'合计','金额合计=null')
declare @strQtyLine varchar(4000)
set @strQtyLine=REPLACE(@strQtyCon,'合计','数量合计=null')
 
---------------取盘点差异
if(select object_id('tempdb..#templast_pd01')) is not null drop table #templast_pd01
select b.dCheckTask,a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
into #templast_pd01
from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
on a.cCheckTaskNo=b.cCheckTaskNo 
where b.dCheckTask<=@dDateEnd  
and b.cWhNo=@cWHno  
group by  b.dCheckTask,a.cGoodsNo

if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
select a.dCheckTask,a.cGoodsNo,a.fQuantity_Diff,a.fmoney_Diff into #templast_pd0 
from #templast_pd01 a,#tmp_WhGoodsList b
where a.cGoodsNo=b.cGoodsNo
	
 
	
-------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity_Diff=a.fQuantity_Diff*ISNULL(b.fQty_minPackage,1) 
from #templast_pd0 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

if(select object_id('tempdb..#templast_pdheji0')) is not null drop table #templast_pdheji0

select dCheckTask,cGoodsNo,fQuantity_Diff=SUM(fQuantity_Diff),fmoney_Diff=SUM(fmoney_Diff) 
into #templast_pdheji0
from #templast_pd0
group by dCheckTask,cGoodsNo


 
--------获取期初前调整库存数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select dDatetime,a.cGoodsNo,fQty=sum(a.fQty),fMoney=sum(a.fMoney)
into #tmpGoodsRelationKucun_1
from posmanagement_Relation01.dbo.t_GoodsUpdateKucunDetail a,(select distinct cgoodsno from #temp_WhFromend) b
where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno
group by dDatetime,a.cGoodsNo

 
-------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQty=a.fQty*ISNULL(b.fQty_minPackage,1) 
from #tmpGoodsRelationKucun_1 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


--------取改时间段的差价单分配情况。。。 
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)

--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
drop table #temp_wh_DiffGoodsNo
select dSaleDate,a.cGoodsno,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
where dSaleDate between @dDateBgn and @dDateEnd 
and a.cGoodsno=b.cGoodsNo 
group by a.cGoodsno,dSaleDate

CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

 -------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fqty_Sale=a.fqty_Sale*ISNULL(b.fQty_minPackage,1) 
from #temp_wh_DiffGoodsNo a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

-----------合计。
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNoHeji'))is not null  
drop table #temp_wh_DiffGoodsNoHeji
select dSaleDate,cGoodsno,fMoney_Diff=SUM(fMoney_Diff) 
into #temp_wh_DiffGoodsNoHeji
from #temp_wh_DiffGoodsNo 
group by dSaleDate,cGoodsno

CREATE INDEX IX_temp_wh_DiffGoodsNoHeji  ON #temp_wh_DiffGoodsNoHeji(cGoodsNo) 

 --print dbo.getTimeStr(GETDATE())
--print 8

if (select OBJECT_ID('tempdb..#temp_WhFromendZh'))is not null  
drop table #temp_WhFromendZh
create table #temp_WhFromendZh([cGoodsNo] [varchar](32) NOT NULL)
-----循环获取每天的盘点差异、 差价单分配
exec( 'alter table #temp_WhFromendQty add  fQtyheji money')
exec( 'alter table #temp_WhFromend add Saleheji money')
exec( 'alter table #temp_WhFromendFml add fMlheji money')
exec( 'alter table #temp_WhFromendKc add KuMoneyheji money,KuQtyheji money')

exec( 'alter table #temp_WhFromendZh add fQtyheji money,Saleheji money,fMlheji money,KuMoneyheji money,KuQtyheji money')
CREATE INDEX IX_temp_WhFromendZh  ON #temp_WhFromendZh(cGoodsNo) 

insert into #temp_WhFromendZh(cGoodsNo)
select cGoodsNo from #temp_WhFromend

--print dbo.getTimeStr(GETDATE())
--print 9

declare @i int
set @a=0
declare @upFile varchar(8000)
set @upFile=''
declare @upFileheji varchar(8000)
set @upFileheji=''
while @a<@daylog 
begin	  
	set @M1=MONTH(@strDateBgn+@a)
	set @Day1=day(@strDateBgn+@a)
	set @Y1=YEAR(@strDateBgn+@a)
	if LEN(@M1)=1 
	begin
	   set @M1='0'+@M1
	end
	if LEN(@Day1)=1 
	begin
	   set @Day1='0'+@Day1
	end
	set @MD=@M1+@Day1
 
   declare @i0 varchar(32) 
   set @i0=CAST((1+@i) as varchar)
   declare @dDate varchar(32)
   set @dDate= dbo.getdaystr(@strDateBgn+@a)
 --  set @upFile=@upFile+'fQty_'+@MD+',Sale_'+@MD+',Fml_'+@MD+',KuQty_'+@MD+',Ku_'+@MD+','
 --  set @upFileheji=@upFileheji+'fQty_'+@MD+'=sum(fQty_'+@MD+'),Sale_'+@MD+'=sum(Sale_'+@MD+'),Fml_'+@MD+'=sum(Fml_'+@MD+'),KuQty_'+@MD+'=sum(KuQty_'+@MD+'),Ku_'+@MD+'=sum(Ku_'+@MD+'),'
 --  exec( 'alter table #temp_WhFromendZh add fQty_'+@MD+' money,Sale_'+@MD+' money,Fml_'+@MD+' money,KuQty_'+@MD+' money,Ku_'+@MD+' money')
	----print dbo.getTimeStr(GETDATE())
 --   --print 90
	--	exec(' 
	--	   ----- 获取销售金额、数量合计
	--	    update a
	--	    set a.Sale_'+@MD+'=b.Sale_'+@MD+',
	--	    a.Saleheji=isnull(a.Saleheji,0)+isnull(b.Sale_'+@MD+',0) 
	--	    from #temp_WhFromendZh a,#temp_WhFromend b
	--	    where a.cGoodsNo=b.cGoodsNo 
 --           --print dbo.getTimeStr(GETDATE())
    
 --           update a
	--	    set a.fQty_'+@MD+'=b.fQty_'+@MD+',
	--	    a.fQtyheji=isnull(a.fQtyheji,0)+isnull(b.fQty_'+@MD+',0) 
	--	    from #temp_WhFromendZh a,#temp_WhFromendQty b
	--	    where a.cGoodsNo=b.cGoodsNo 
		    
 --           --print dbo.getTimeStr(GETDATE())

 --           ---------盘点库存
	--		if(select object_id(''tempdb..#templast_pdheji1'')) is not null drop table #templast_pdheji1
	--		select cGoodsNo,fQty_diff=SUM(fQuantity_Diff),fmoney_Diff=sum(fmoney_Diff)  into #templast_pdheji1 
	--		from #templast_pdheji0
	--		where dCheckTask<='''+@dDate+'''
	--		group by cGoodsNo
			
	--		CREATE INDEX IX_templast_pdheji1  ON #templast_pdheji1(cGoodsNo)
			 
	--		update a set a.KuQty_'+@MD+'=isnull(KuQty_'+@MD+',0)+isnull(b.fQty_diff,0),
	--		a.Ku_'+@MD+'=isnull(Ku_'+@MD+',0)+isnull(b.fmoney_Diff,0) 
	--		from #temp_WhFromendZh a,#templast_pdheji1 b
	--		where a.cGoodsNo=b.cGoodsNo
			
	--	    --print dbo.getTimeStr(GETDATE())
    
	--		update a
	--	    set a.KuQty_'+@MD+'=b.KuQty_'+@MD+',
	--	    a.Ku_'+@MD+'=isnull(b.Ku_'+@MD+',0) 
	--	    from #temp_WhFromendZh a,#temp_WhFromendKc b
	--	    where a.cGoodsNo=b.cGoodsNo 
	--	 		 --print dbo.getTimeStr(GETDATE())
 
	--	--------手动调整库存	
	--		if(select object_id(''tempdb..#tmpGoodsRelationKucun_hebing'')) is not null 
	--		drop table #tmpGoodsRelationKucun_hebing
	--		select  cGoodsNo,fQty=sum(fqty),fMoney=sum(fMoney)
	--		into #tmpGoodsRelationKucun_hebing 
	--		from  #tmpGoodsRelationKucun_1
	--		where  dDatetime<='''+@dDate+'''
	--		group by  cGoodsNo
			
	--		CREATE INDEX IX_tmpGoodsRelationKucun_hebing  ON #tmpGoodsRelationKucun_hebing(cGoodsNo)
			
	--	    --print dbo.getTimeStr(GETDATE())
  	
	--		update a set a.KuQty_'+@MD+'=isnull(a.KuQty_'+@MD+',0)+isnull(b.fQty,0),
	--		a.Ku_'+@MD+'=isnull(Ku_'+@MD+',0)+isnull(b.fMoney,0) 
	--		from #temp_WhFromendKc a,#tmpGoodsRelationKucun_hebing b
	--		where a.cGoodsNo=b.cGoodsNo
	--		 --print dbo.getTimeStr(GETDATE())
		
	--		update a
	--	    set a.KuQty_'+@MD+'=b.KuQty_'+@MD+',
	--	    a.Ku_'+@MD+'=isnull(b.Ku_'+@MD+',0) 
	--	    from #temp_WhFromendZh a,#temp_WhFromendKc b
	--	    where a.cGoodsNo=b.cGoodsNo 
		    
	--		--print dbo.getTimeStr(GETDATE())
  		
 --  -- ---- 毛利

 --           update a
	--	    set a.Fml_'+@MD+'=isnull(Sale_'+@MD+',0)-isnull(b.Fml_'+@MD+',0),
	--	    a.fMlheji=isnull(a.fMlheji,0)+isnull(Sale_'+@MD+',0)-isnull(b.Fml_'+@MD+',0)
	--	    from #temp_WhFromendZh a,#temp_WhFromendFml b
	--	    where a.cGoodsNo=b.cGoodsNo  
		    
	--	    --print dbo.getTimeStr(GETDATE())
		    
	--		update a set a.Fml_'+@MD+'=isnull(a.Fml_'+@MD+',0)+isnull(b.fMoney_Diff,0) ,
	--	    a.fMlheji=isnull(a.fMlheji,0)+isnull(b.fMoney_Diff,0)		  
	--		from #temp_WhFromendZh a,#temp_wh_DiffGoodsNoHeji b
	--		where a.cGoodsNo=b.cGoodsNo and b.dSaleDate='''+@dDate+'''
	 
    --   --print dbo.getTimeStr(GETDATE())
	   
	--	')	 
	 
   set @upFile=@upFile+'第'+@Day1+'天销售数量=fQty_'+@MD+',第'+@Day1+'天销售金额=Sale_'+@MD+',第'+@Day1+'天毛利=Fml_'+@MD+',第'+@Day1+'天库存=KuQty_'+@MD+',' ---Ku_'+@MD+',
   set @upFileheji=@upFileheji+'fQty_'+@MD+'=sum(fQty_'+@MD+'),Sale_'+@MD+'=sum(Sale_'+@MD+'),Fml_'+@MD+'=sum(Fml_'+@MD+'),KuQty_'+@MD+'=sum(KuQty_'+@MD+'),'--Ku_'+@MD+'=sum(Ku_'+@MD+'),
   exec( 'alter table #temp_WhFromendZh add fQty_'+@MD+' money,Sale_'+@MD+' money,Fml_'+@MD+' money,KuQty_'+@MD+' money,Ku_'+@MD+' money')
	--print dbo.getTimeStr(GETDATE())
    --print 90
		exec(' 
		   ----- 获取销售金额、数量合计
		    update a
		    set a.Sale_'+@MD+'=b.Sale_'+@MD+',
		    a.Saleheji=isnull(a.Saleheji,0)+isnull(b.Sale_'+@MD+',0) 
		    from #temp_WhFromendZh a,#temp_WhFromend b
		    where a.cGoodsNo=b.cGoodsNo 
            --print dbo.getTimeStr(GETDATE())
    
            update a
		    set a.fQty_'+@MD+'=b.fQty_'+@MD+',
		    a.fQtyheji=isnull(a.fQtyheji,0)+isnull(b.fQty_'+@MD+',0) 
		    from #temp_WhFromendZh a,#temp_WhFromendQty b
		    where a.cGoodsNo=b.cGoodsNo 
		    
            --print dbo.getTimeStr(GETDATE())

            ---------盘点库存
			if(select object_id(''tempdb..#templast_pdheji1'')) is not null drop table #templast_pdheji1
			select cGoodsNo,fQty_diff=SUM(fQuantity_Diff),fmoney_Diff=sum(fmoney_Diff)  into #templast_pdheji1 
			from #templast_pdheji0
			where dCheckTask<='''+@dDate+'''
			group by cGoodsNo
			
			CREATE INDEX IX_templast_pdheji1  ON #templast_pdheji1(cGoodsNo)
			 
			update a set a.KuQty_'+@MD+'=isnull(KuQty_'+@MD+',0)+isnull(b.fQty_diff,0),
			a.Ku_'+@MD+'=isnull(Ku_'+@MD+',0)+isnull(b.fmoney_Diff,0) 
			from #temp_WhFromendZh a,#templast_pdheji1 b
			where a.cGoodsNo=b.cGoodsNo
			
		    --print dbo.getTimeStr(GETDATE())
    
			update a
		    set a.KuQty_'+@MD+'=b.KuQty_'+@MD+',
		    a.Ku_'+@MD+'=isnull(b.Ku_'+@MD+',0) 
		    from #temp_WhFromendZh a,#temp_WhFromendKc b
		    where a.cGoodsNo=b.cGoodsNo 
		 		 --print dbo.getTimeStr(GETDATE())
 
		--------手动调整库存	
			if(select object_id(''tempdb..#tmpGoodsRelationKucun_hebing'')) is not null 
			drop table #tmpGoodsRelationKucun_hebing
			select  cGoodsNo,fQty=sum(fqty),fMoney=sum(fMoney)
			into #tmpGoodsRelationKucun_hebing 
			from  #tmpGoodsRelationKucun_1
			where  dDatetime<='''+@dDate+'''
			group by  cGoodsNo
			
			CREATE INDEX IX_tmpGoodsRelationKucun_hebing  ON #tmpGoodsRelationKucun_hebing(cGoodsNo)
			
		    --print dbo.getTimeStr(GETDATE())
  	
			update a set a.KuQty_'+@MD+'=isnull(a.KuQty_'+@MD+',0)+isnull(b.fQty,0),
			a.Ku_'+@MD+'=isnull(Ku_'+@MD+',0)+isnull(b.fMoney,0) 
			from #temp_WhFromendKc a,#tmpGoodsRelationKucun_hebing b
			where a.cGoodsNo=b.cGoodsNo
			 --print dbo.getTimeStr(GETDATE())
		
			update a
		    set a.KuQty_'+@MD+'=b.KuQty_'+@MD+',
		    a.Ku_'+@MD+'=isnull(b.Ku_'+@MD+',0) 
		    from #temp_WhFromendZh a,#temp_WhFromendKc b
		    where a.cGoodsNo=b.cGoodsNo 
		    
			--print dbo.getTimeStr(GETDATE())
  		
   -- ---- 毛利

            update a
		    set a.Fml_'+@MD+'=isnull(Sale_'+@MD+',0)-isnull(b.Fml_'+@MD+',0),
		    a.fMlheji=isnull(a.fMlheji,0)+isnull(Sale_'+@MD+',0)-isnull(b.Fml_'+@MD+',0)
		    from #temp_WhFromendZh a,#temp_WhFromendFml b
		    where a.cGoodsNo=b.cGoodsNo  
		    
		    --print dbo.getTimeStr(GETDATE())
		    
			update a set a.Fml_'+@MD+'=isnull(a.Fml_'+@MD+',0)+isnull(b.fMoney_Diff,0) ,
		    a.fMlheji=isnull(a.fMlheji,0)+isnull(b.fMoney_Diff,0)		  
			from #temp_WhFromendZh a,#temp_wh_DiffGoodsNoHeji b
			where a.cGoodsNo=b.cGoodsNo and b.dSaleDate='''+@dDate+'''
			
		
  		
			
    		 --print dbo.getTimeStr(GETDATE())
	   
		')	 
       set @a=@a+1
       --print dbo.getTimeStr(GETDATE())
--print 91
end
--print dbo.getTimeStr(GETDATE())
--print 10
exec('
select ''商品编码''=a.cGoodsno,''商品名称''=b.cGoodsName,''商品类别''=b.cGoodsTypeno,''类别名称''=b.cGoodsTypename,
'+@upFile+'数量=fQtyheji,金额=Saleheji,毛利=fMlheji,库存金额=KuMoneyheji,库存数量=KuQtyheji 
from #temp_WhFromendZh a,t_Goods b
where a.cGoodsno=b.cGoodsno
union all
select cGoodsno=''合计'',cgoodsname=null,cgoodstypeno=null,cGoodsTypename=null,'+@upFileheji+'fQtyheji=sum(fQtyheji),
Saleheji=sum(Saleheji),fMlheji=sum(fMlheji),KuMoneyheji=sum(KuMoneyheji),KuQtyheji=sum(KuQtyheji) 
from #temp_WhFromendZh
--group by cGoodsno
')
--print dbo.getTimeStr(GETDATE())
--print 11
--select * from #temp_WhFromendFml
--select * from #temp_WhFromendKc
--exec('
--if (select OBJECT_ID(''tempdb..#temp_cGoods_endSale''))is not null  drop table #temp_cGoods_endSale
--select b.cGoodsName,b.cGoodsTypeno,b.cGoodsTypename,a.cGoodsno,'+@strSaleCon+',heji=('+@strSumSale+') 
--into #temp_cGoods_endSale
--from #temp_WhFromend a,t_Goods b
--where a.cGoodsNo=b.cGoodsNo

--select cGoodsName,cGoodsTypeno,cGoodsTypename,cGoodsno,'+@strSaleCon+',heji from 
--#temp_cGoods_endSale
--union all
--select  cGoodsName=''合计：'',cGoodsTypeno=null,cGoodsTypename=null,
--cGoodsno=''ZZZZZ'','+@strSumSaleCon+',heji=sum(heji)
--from #temp_cGoods_endSale 
--order by cGoodsNo
--')


end
 GO
