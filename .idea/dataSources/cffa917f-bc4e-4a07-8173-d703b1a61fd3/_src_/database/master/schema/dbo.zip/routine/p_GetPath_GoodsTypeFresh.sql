

create     procedure [dbo].[p_GetPath_GoodsTypeFresh]
as
begin
 

		declare @bFlag bit
		set @bFlag=0
		update t_GoodsType set cPath=cGoodsTypeno
			
			declare @cGoodsTypeno varchar(32)
			declare @cParentNo varchar(32)
			declare @cPath varchar(1028)
			declare @cPath_temp varchar(1028)
			
			
		while exists (select cGoodsTypeno,cParentNo,cPath
			from t_GoodsType
			where    patindex('%--%',isnull(cPath,''))=0)   
		begin
		  
			declare GoodsType_cursor cursor
			for
			select cGoodsTypeno,cParentNo,cPath
			from t_GoodsType
			where patindex('%--%',isnull(cPath,''))=0

			open GoodsType_cursor
			fetch next from GoodsType_cursor
			into @cGoodsTypeno,@cParentNo,@cPath
		  
			while @@fetch_status=0
			begin

				set @cPath_temp=(select top 1 cPath from t_GoodsType where cGoodsTypeno=@cParentNo)
				set @cPath_temp=case when @cPath_temp is null then '--' else @cPath_temp end
			
				update t_GoodsType 
				set cPath= @cPath_temp+'.'+@cGoodsTypeno
				       
				where cGoodsTypeno=	@cGoodsTypeno

				fetch next from GoodsType_cursor
				into @cGoodsTypeno,@cParentNo,@cPath
			end

			close GoodsType_cursor
			deallocate GoodsType_cursor
		end	
	select diquno=cGoodsTypeno,diqumc=cGoodsTypename,cParentNo,cPath
	from t_GoodsType  where ISNULL(bfresh,0)=1 
end


GO
