
create  procedure [dbo].[p_x_salesABC_Profits_bySupplier_wind]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit
as
begin


/*
	declare @dBeginDate datetime
	declare @dEndDate datetime
	declare @bJiaGong bit
	declare @bZero bit
	set @dBeginDate='2008-08-01'
  set @dEndDate='2008-09-04'
	set @bJiaGong=0
	set @bZero=0

*/

		if(select object_id('tempdb..#temp_Goods_supplier')) is not null
		begin
			drop table 	#temp_Goods_supplier
		end 

		if(select object_id('tempdb..#tempSaleSheet_Day_unique')) is not null
		begin
			drop table 	#tempSaleSheet_Day_unique
		end 

		if(select object_id('tempdb..#tempLastWH')) is not null
		begin
			drop table 	#tempLastWH
		end 

		if(select object_id('tempdb..#tempLastInfor')) is not null
		begin
			drop table 	#tempLastInfor
		end 

		if(select object_id('tempdb..#temp_SupplierGoods')) is not null
		begin
			drop table 	#temp_SupplierGoods
		end 

		if(select object_id('tempdb..#temp_SaleSheetDetail_shelf')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_shelf
		end 

/*

  select distinct k.cGoodsNo,k.cSupNo
	into #temp_SupplierGoods
  from
  (select distinct cSupNo,cGoodsNo from t_supplier_Goods
   union 
   select distinct cSupNo=q.cSupplierNo,p.cGoodsno from dbo.wh_InWarehouseDetail p,wh_InWarehouse q
   where p.cSheetno=q.cSheetno
  ) k  left join 
  (select distinct cGoodsNo,cSupNo from t_Supplier_goods_eStop 
  
  ) j 
  on k.cGoodsNo=j.cGoodsNo and k.cSupNo=j.cSupNo 
  where j.cGoodsNo is null 
 
	select distinct cGoodsNo,cSupplierNo=cSupNo 
	into #temp_Goods_supplier 
	from #temp_SupplierGoods

		if(select object_id('tempdb..#temp_supplier_selected')) is not null
		begin
			drop table 	#temp_supplier_selected
		end 
   select distinct cSupplierNo into #temp_supplier_selected from #temp_Goods_supplier
*/

  select distinct cGoodsNo,cSupplierNo into #temp_Goods_supplier from #temp_Goods

		if(select object_id('tempdb..#temp_supplier_selected')) is not null
		begin
			drop table 	#temp_supplier_selected
		end 
   select distinct cSupplierNo into #temp_supplier_selected from #temp_Goods
	
--                销售单                 开始 
		select b.cGoodsNo,a.cSupplierNo,b.dSaleDate,b.fQuantity,b.fLastSettle,b.tag_daily,cGoodsNo_b=b.cGoodsNo  --统计最近一次日结后的销售
		into #temp_SaleSheetDetail_shelf 
		from #temp_Goods_supplier a , t_SaleSheetDetail b
		where a.cGoodsNo=b.cGoodsNo and (b.dSaleDate between @dBeginDate and @dEndDate)  and isnull(b.tag_daily,0)=0 

		if(select object_id('tempdb..#temp_SaleSheetDetail_perDay')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_perDay
		end 


		select x.cGoodsNo,x.cSupplierNo,x.dSaleDate,fQuantity=sum(isnull(x.fQuantity,0)),
					fLastSettle=sum(isnull(x.fLastSettle,0)),fCostMoney=cast(null as money),
					cHezuofangshi=cast('' as varchar(32))
		into #temp_SaleSheetDetail_perDay
		from #temp_SaleSheetDetail_shelf x
		group by x.dSaleDate,x.cGoodsNo,x.cSupplierNo
	/*
    CREATE UNIQUE CLUSTERED INDEX IX_PK_temp_SaleSheetDetail_perDay
		ON #temp_SaleSheetDetail_perDay(dSaleDate,cGoodsNo,cSupplierNo);

		create index ix_temp_SaleSheetDetail_perDay_dSaleDate
    on 	#temp_SaleSheetDetail_perDay (dSaleDate)
		create index ix_temp_SaleSheetDetail_perDay_cGoodsNo
    on 	#temp_SaleSheetDetail_perDay (cGoodsNo)
		create index ix_temp_SaleSheetDetail_perDay_cSupplierNo
    on 	#temp_SaleSheetDetail_perDay (cSupplierNo)
	*/
		update a	set a.fCostMoney=b.fLastCostPrice*a.fQuantity
		from #temp_SaleSheetDetail_perDay a,t_goods b
		where a.cGoodsNo=b.cGoodsNo
/*以下开始处理成本*/
		if(select object_id('tempdb..#temp_Supplier_zulin')) is not null
		begin
			drop table 	#temp_Supplier_zulin
		end 
		if(select object_id('tempdb..#temp_Supplier_Hezuofangshi')) is not null
		begin
			drop table 	#temp_Supplier_Hezuofangshi
		end 
 			
    select distinct a.cHezuofangshi, cSupNo= b.cSupplierNo
		into #temp_Supplier_Hezuofangshi
    from dbo.t_Supplier_Contract a ,#temp_supplier_selected b
		where a.cSupNo=b.cSupplierNo
    --group by  cHezuofangshi,cSupNo

		create index ix_temp_Supplier_Hezuofangshi_cSupNo
    on 	#temp_Supplier_Hezuofangshi (cSupNo)


		if(select object_id('tempdb..#temp_Supplier_Goods_Hezuofangshi')) is not null
		begin
			drop table 	#temp_Supplier_Goods_Hezuofangshi
		end 


		if(select object_id('tempdb..#temp_supplier_Goods_IN')) is not null
		begin
			drop table 	#temp_supplier_Goods_IN
		end 

        select distinct a.cGoodsNo,a.cSupNo,b.cHezuofangshi
				into #temp_supplier_Goods_IN
        from t_supplier_Goods a,#temp_Supplier_Hezuofangshi b
        where a.cSupNo=b.cSupNo
				union all
        select distinct a.cGoodsNo,cSupNo=b.cSupplierNo,c.cHezuofangshi
        from WH_INwarehousedetail a ,WH_INwarehouse b, #temp_Supplier_Hezuofangshi c 
				where  a.cSheetno=b.cSheetno and b.cSupplierNo=c.cSupNo
		

		if(select object_id('tempdb..#temp_Supplier_goods_eStop')) is not null
		begin
			drop table 	#temp_Supplier_goods_eStop
		end 

			select distinct e.cGoodsNo,e.cSupNo 
			into #temp_Supplier_goods_eStop
			from t_Supplier_goods_eStop e,#temp_Supplier_Hezuofangshi f
      where e.cSupNo=f.cSupNo

    select distinct c.cGoodsNo,c.cSupNo,c.cHezuofangshi,x.fRatio
    into #temp_Supplier_Goods_Hezuofangshi
    from #temp_supplier_Goods_IN c 
		left join #temp_Supplier_goods_eStop d 
		on c.cGoodsNo=d.cGoodsNo and  c.cSupNo=d.cSupNo
		left join 
		(
			select cSupNo=guizuno,fRatio=max(fRatio)
			from t_Supplier_Contract_Ratio
			group by guizuno
		) x on c.cSupNo=x.cSupNo
    where d.cSupNo is  null

		update a	
		set a.fCostMoney=
				case when b.cHezuofangshi='租赁' 
									then a.fLastSettle
						 when isnull(b.fRatio,0)<>0 and  b.cHezuofangshi<>'租赁' 
									then a.fLastSettle*(1-isnull(b.fRatio,0)/100) 
						 else  a.fCostMoney
				end,
				a.cHezuofangshi=b.cHezuofangshi
		from #temp_SaleSheetDetail_perDay a,#temp_Supplier_Goods_Hezuofangshi b
		where a.cGoodsNo=b.cGoodsNo 

    update #temp_SaleSheetDetail_perDay set fCostMoney=fLastSettle
		where  cSupplierNo is null


		if(select object_id('tempdb..#temp_SaleSheet_day')) is not null
		begin
			drop table 	#temp_SaleSheet_day
		end 

	select a.dSaleDate,a.cGoodsNo,a.fQuantity,a.fLastSettle,
	fCostMoney=case when a.bStorage is not null and a.bStorage=1 then a.fQuantity*a.fCostPrice
									when isnull(a.bStorage,0)=0 and a.cSupplierNo is not null then a.fLastSettle
									else a.fLastSettle*(1-isnull(a.fProfitsRatio,0)/100)
						 end,
	b.cSupNo,b.cHezuofangshi
	into #temp_SaleSheet_day
	from t_SaleSheet_day a , #temp_Supplier_Goods_Hezuofangshi b

	where a.cGoodsNo=b.cGoodsNo and a.dSaleDate between @dBeginDate and @dEndDate

		if(select object_id('tempdb..#temp_Sales_Sum')) is not null
		begin
			drop table 	#temp_Sales_Sum
		end 
/*计算时段顾客退货*/
		if(select object_id('tempdb..#tempReturnGoods')) is not null
		begin
			drop table 	#tempReturnGoods
		end 
  select a.cGoodsNo,fQuantity=-a.fQuantity,fLastSettle=-a.fInMoney,cSupplierNo=c.cSupNo,dSaleDate=b.dDate,
  c.cHezuofangshi
	into #tempReturnGoods
  --into #t_SaleSheetDetail_shelf
  from WH_ReturnGoodsDetail a,WH_ReturnGoods b,#temp_Supplier_Goods_Hezuofangshi c
  where a.cSheetno=b.cSheetno and a.cGoodsNo=c.cGoodsNo and (b.dDate between @dBeginDate and @dEndDate)

		if(select object_id('tempdb..#temp_Salesheet_day_distinct_0')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct_0
		end 

		if(select object_id('tempdb..#temp_Salesheet_day_distinct')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct
		end 
	  
			select a.cGoodsNo,a.dSaleDate,a.fCostPrice,a.fProfitsRatio
			into #temp_Salesheet_day_distinct_0
			from t_salesheet_day a,#temp_Supplier_Goods_Hezuofangshi b
			where  a.dSaleDate  between @dBeginDate and @dEndDate and a.cGoodsNo=b.cGoodsNo
	
  select cGoodsNo,dSaleDate,fCostPrice=max(fCostPrice),fProfitsRatio=max(fProfitsRatio)
	into #temp_Salesheet_day_distinct
	from #temp_Salesheet_day_distinct_0
	group by dSaleDate,cGoodsNo
		if(select object_id('tempdb..#temp_Salesheet_day_distinct_0')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct_0
		end 
  
		if(select object_id('tempdb..#tempReturnGoods_result')) is not null
		begin
			drop table 	#tempReturnGoods_result
		end 
  select b.cGoodsNo,b.cSupplierNo,b.dSaleDate,b.fQuantity,b.fLastSettle,
	fCostMoney=(case when a.fProfitsRatio is null 
											 then b.fQuantity*a.fCostPrice 
									 else b.fLastSettle*(1-a.fProfitsRatio/100) 
							end),
	b.cHezuofangshi,tag_daily=0
	into #tempReturnGoods_result
  from #temp_Salesheet_day_distinct a,#tempReturnGoods b
	where a.dSaleDate  between @dBeginDate and @dEndDate and a.dSaleDate=b.dSaleDate and a.cGoodsNo=b.cGoodsNo 
    
/*以上计算时段顾客退货*/

	select cGoodsNo,cSupplierNo,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=0
	into #temp_Sales_Sum   -----------时段内销售收入、成本、及所属供应商
	from #temp_SaleSheetDetail_perDay
	union all
	select cGoodsNo,cSupplierNo=cSupno,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=1
	from #temp_SaleSheet_day
	union all
	select cGoodsNo,cSupplierNo,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=1
	from #tempReturnGoods_result

-----  释放临时表
		if(select object_id('tempdb..#temp_SaleSheetDetail_perDay')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_perDay
		end 
		if(select object_id('tempdb..#tempReturnGoods_result')) is not null
		begin
			drop table 	#tempReturnGoods_result
		end 
		if(select object_id('tempdb..#temp_SaleSheet_day')) is not null
		begin
			drop table 	#temp_SaleSheet_day
		end 


		if(select object_id('tempdb..#temp_Sales_Sum_group')) is not null
		begin
			drop table 	#temp_Sales_Sum_group
		end 

  select cGoodsNo,cSupplierNo,cHezuofangshi,fQuantity=sum(isnull(fQuantity,0)),
	fLastSettle=sum(isnull(fLastSettle,0)),fCostMoney=sum(isnull(fCostMoney,0))
  into #temp_Sales_Sum_group
	from #temp_Sales_Sum
	group by cGoodsNo,cSupplierNo,cHezuofangshi

/*加工商品成本分摊比例列表*/
		if(select object_id('tempdb..#temp_Goods_Produncted')) is not null
		begin
			drop table 	#temp_Goods_Produncted
		end 
  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,a.cBarCode,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  into #temp_Goods_Produncted 
  from t_Goods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo
	where a.bStorage=1 and b.cGoodsNo is not null and isnull(dbo.trim(a.cProductNo),'')<>''
  order by a.cGoodsNo

		if(select object_id('tempdb..#temp_Goods_Produncted_sum')) is not null
		begin
			drop table 	#temp_Goods_Produncted_sum
		end 
	select cGoodsNo,ProductedPrice_sum=sum(isnull(ProductedPrice,0))
	into #temp_Goods_Produncted_sum
	from #temp_Goods_Produncted
	group by cGoodsNo

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio
		end 
  select a.*,fRatio=round(a.ProductedPrice/case when b.ProductedPrice_sum=0 then null else  b.ProductedPrice_sum end *100,4),b.ProductedPrice_sum
	into #temp_Goods_Produncted_Ratio
	from #temp_Goods_Produncted a,#temp_Goods_Produncted_sum b
	where a.cGoodsNo=b.cGoodsNo
  --and (a.cGoodsNo='21030267' or a.cGoodsNo='25060266')

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio_1')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio_1
		end 
	select a.cGoodsNo,a.fRatio_total_loss
	into #temp_Goods_Produncted_Ratio_1
	from
	(
			select cGoodsNo,fRatio_total_loss=100-sum(isnull(fRatio,0))
			from #temp_Goods_Produncted_Ratio
			group by cGoodsNo
	) a
	where a.fRatio_total_loss<>0

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio_1_locate')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio_1_locate
		end 
	select distinct a.cGoodsNo,GoodsNo_Pdt_loss=(select top 1 GoodsNo_Pdt from #temp_Goods_Produncted where cGoodsNo=a.cGoodsNo ),
         b.fRatio_total_loss         
	into #temp_Goods_Produncted_Ratio_1_locate
	from #temp_Goods_Produncted a,#temp_Goods_Produncted_Ratio_1 b
	where a.cGoodsNo=b.cGoodsNo
  
  update a set a.fRatio=a.fRatio+b.fRatio_total_loss
	from #temp_Goods_Produncted_Ratio a,#temp_Goods_Produncted_Ratio_1_locate b
	where a.cGoodsNo=b.cGoodsNo and a.GoodsNo_Pdt=b.GoodsNo_Pdt_loss
/* 加工商品成本分摊比例列表处理完毕 */

/*下面按照 加工商品成本分摊比例列表 进行商品分类：非加工商品 、加工商品 */
		if(select object_id('tempdb..#temp_Sales_Sum_group_join')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join
		end 

  select a.cGoodsNo,a.cSupplierNo,a.cHezuofangshi,a.fQuantity,a.fLastSettle,a.fCostMoney,
	cGoodsNo_b=b.cGoodsNo
	into #temp_Sales_Sum_group_join
	from #temp_Sales_Sum_group a left join
	(  select distinct cGoodsNo
     from #temp_Goods_Produncted_Ratio 
	) b
	on a.cGoodsNo=b.cGoodsNo

		if(select object_id('tempdb..#temp_Sales_Sum_group_join_result_0')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join_result_0
		end 

	select cGoodsNo,cSupplierNo,cHezuofangshi,fQuantity,fLastSettle, fCostMoney ,fProfit=(fLastSettle-fCostMoney),
	fRatioAvg=(fLastSettle-fCostMoney)/case when fLastSettle=0 then null else fLastSettle end,iTag=0
	into #temp_Sales_Sum_group_join_result_0
	from #temp_Sales_Sum_group_join  ---非加工商品
	where cGoodsNo_b is null
	union all
	SELECT cGoodsNo=b.GoodsNo_Pdt,a.cSupplierNo,a.cHezuofangshi,
	fQuantity=a.fQuantity*b.Qty,fLastSettle=a.fLastSettle*10000*b.fRatio/1000000,
	fCostMoney=a.fCostMoney*10000*b.fRatio/1000000 ,
	fProfit=((a.fLastSettle*10000*b.fRatio/1000000)-(a.fCostMoney*10000*b.fRatio/1000000)),
	fRatioAvg=(((a.fLastSettle*10000*b.fRatio/1000000)-(a.fCostMoney*10000*b.fRatio/1000000)))
						/case when a.fLastSettle*10000*b.fRatio/1000000=0 
											then null 
									else a.fLastSettle*10000*b.fRatio/1000000 
						 end,
	iTag=1             --加工商品
	FROM #temp_Sales_Sum_group_join a  , #temp_Goods_Produncted_Ratio b
	where a.cGoodsNo=b.cGoodsNo
	
		if(select object_id('tempdb..#temp_Sales_Sum_group_join_result_1')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join_result_1
		end 

  select cGoodsNo,cSupplierNo,cHezuofangshi,fQuantity,fLastSettle, fCostMoney ,
	fProfit,fRatioAvg,iOrder=0
	into #temp_Sales_Sum_group_join_result_1
	from #temp_Sales_Sum_group_join_result_0
	union all
  select cGoodsNo='合计:',cSupplierNo,cHezuofangshi,fQuantity=sum(isnull(fQuantity,0)),
	fLastSettle=sum(isnull(fLastSettle,0)), fCostMoney=sum(fCostMoney) ,
	fProfit=sum(fProfit),
	fRatioAvg=sum(fProfit)
					/case when sum(isnull(fLastSettle,0))=0 
										then null 
								else sum(isnull(fLastSettle,0)) 
					 end,
	iOrder=1
	from #temp_Sales_Sum_group_join_result_0
	group by cSupplierNo,cHezuofangshi
	union all
  select cGoodsNo='合计:',cSupplierNo=null,cHezuofangshi,fQuantity=sum(isnull(fQuantity,0)),
	fLastSettle=sum(isnull(fLastSettle,0)), fCostMoney=sum(fCostMoney) ,
	fProfit=sum(fProfit),
	fRatioAvg=sum(fProfit)
					/case when sum(isnull(fLastSettle,0))=0 
										then null 
								else sum(isnull(fLastSettle,0)) 
					 end,
	iOrder=2
	from #temp_Sales_Sum_group_join_result_0
	group by cHezuofangshi
	union all
  select cGoodsNo='总计:',cSupplierNo='ZZZZZZZ',cHezuofangshi=null,fQuantity=sum(isnull(fQuantity,0)),
	fLastSettle=sum(isnull(fLastSettle,0)), fCostMoney=sum(fCostMoney) ,
	fProfit=sum(fProfit),
	fRatioAvg=sum(fProfit)
					/case when sum(isnull(fLastSettle,0))=0 
										then null 
								else sum(isnull(fLastSettle,0)) 
					 end,
	iOrder=3
	from #temp_Sales_Sum_group_join_result_0
  order by cSupplierNo,iOrder,cGoodsNo

	
 update a set a.fCostMoney=a.fLastSettle,a.fRatioAvg=0.00,a.fProfit=0.00
 from #temp_Sales_Sum_group_join_result_1 a
 where a.cHezuofangshi='租赁'  
	and a.cSupplierNo not in 
			(select cSupplierNo=guizuno 
			from t_Supplier_Contract_Ratio where guizuno=a.cSupplierNo and fRatio<>0)


  select GoodsNo_Pdt=a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsName,
	BeginDate=@dBeginDate,EndDate=@dEndDate,b.bProducted,b.cProductNo,
	a.cSupplierNo,c.cSupName,a.cHezuofangshi,xsQty=a.fQuantity,xsMoney=a.fLastSettle,a.fCostMoney ,
	a.fProfit,fRatioAvg=a.fRatioAvg*100,a.iOrder
	from #temp_Sales_Sum_group_join_result_1 a left join t_Goods b on a.cGoodsNo=b.cGoodsNo
  left join t_supplier c on a.cSupplierNo=c.cSupNo
	where isnull(a.fQuantity,0)<>0
  order by a.iOrder,a.cHezuofangshi,a.cSupplierNo,a.cGoodsNo
end

/*

	select * from #temp_Sales_Sum_group_join_result_0

	select sum(fLastSettle) from #temp_Sales_Sum_group_join

	select sum(fLastSettle) from #temp_Sales_Sum_group

	select sum(fLastSettle) from #temp_Sales_Sum
	select sum(fLastSettle) from #temp_SaleSheetDetail_perDay
	select sum(fLastSettle) from #temp_SaleSheet_day

	select sum(fLastSettle) from t_salesheetdetail	
	where dSaledate between '2008-05-04' and '2008-08-10'

	select sum(fLastSettle) from t_salesheet_day	
	where dSaledate between '2008-05-04' and '2008-08-10'


select distinct y.cSupNo--一品多商
from
(
		 select a.*,b.iCount
		 from #temp_Supplier_Goods_Hezuofangshi a,
		 (
			 select x.*
			 from
			 (
					select cGoodsNo,iCount=count(cSupNo) 
					from #temp_Supplier_Goods_Hezuofangshi
					group by cGoodsNo
			 ) x	where x.iCount>1
		 ) b
		 where a.cGoodsNo=b.cGoodsNo 
		-- order by a.cGoodsNo
) y


	select sum(c.fLastSettle) from 
	(select a.cGoodsNo,a.fLastSettle
	 from	t_salesheetdetail a left join #temp_SupplierGoods b	
	 on a.cGoodsNo=b.cGoodsNo	
	 where a.dSaledate between '2008-05-04' and '2008-08-10'
	 and b.cGoodsNo is not null
	)  c

	select sum(c.fLastSettle) from 
	(select a.cGoodsNo,a.fLastSettle
	 from	t_salesheetdetail a left join #temp_SupplierGoods b	
	 on a.cGoodsNo=b.cGoodsNo	
	 where a.dSaledate between '2008-05-04' and '2008-08-10'
	 and b.cGoodsNo is  null
	)  c

select sum(fLastSettle) from #temp_SaleSheet_day
select  sum(fLastSettle)  from #temp_SaleSheetdetail_Perday

*/

/*
select * from #temp_Goods_Produncted_Ratio

select  cGoodsNo,dSaleDate,fQty_BeginWH,fQuantity_Total,fQty_CurWH,fInPrice_avg,fCostPrice,
fMoney_WH_Begin,fMoney_WH,fMoney_WH_end,bStorage
from t_salesheet_day
where cGoodsNo ='25060082'--,'25060079','25060090')
order by cGoodsNo,dSaledate

select  cGoodsNo,dSaleDate,fQty_BeginWH,fQuantity_Total,fNormalPrice,fQty_CurWH,fInPrice_avg,fCostPrice,
fMoney_WH_Begin,fMoney_WH,fMoney_WH_end,bStorage
from t_salesheet_day
where cGoodsNo ='25140195'--,'25060079','25060090')
order by cGoodsNo,dSaledate

select  cGoodsNo,dSaleDate,fQty_BeginWH,fQuantity_Total,
fNormalPrice,fQty_CurWH,fInPrice_avg,fCostPrice,
fMoney_WH_Begin,fMoney_WH,fMoney_WH_end,bStorage
from t_salesheet_day
where cGoodsNo ='23040862'--,'25060079','25060090')
order by cGoodsNo,dSaledate

select * from t_Goods where cGoodsNo ='23040862'
--select * from #temp_Goods_Produncted_Ratio_1_locate

select * from wh_inwarehousedetail
where cGoodsNo='23040862'
*/

  
/*
select y.*
from
(
		select distinct c.cGoodsNo,c.cSupNo,c.cHezuofangshi--,x.fRatio
    --into #temp_Supplier_Goods_Hezuofangshi
    from
    (
        select distinct a.cGoodsNo,a.cSupNo,b.cHezuofangshi
        from t_supplier_Goods a,#temp_Supplier_Hezuofangshi b
        where a.cSupNo=b.cSupNo
				union all
        select distinct a.cGoodsNo,cSupNo=b.cSupplierNo,c.cHezuofangshi
        from WH_INwarehousedetail a left join WH_INwarehouse b on a.cSheetno=b.cSheetno
             left join t_Supplier c on b.cSupplierNo=c.cSupNo
				--where b.dDate  between '2008-05-04' and '2008-08-10' -- and a.cSupNo=b.cSupNo

    ) c left join
    (
      select distinct e.cGoodsNo,e.cSupNo 
			from t_Supplier_goods_eStop e,#temp_Supplier_Hezuofangshi f
      where e.cSupNo=f.cSupNo
    ) d on c.cGoodsNo=d.cGoodsNo and  c.cSupNo=d.cSupNo
) y
where y.cGoodsNo='23041762' 

		left join 
		(
			select cSupNo=guizuno,fRatio=max(fRatio)
			from t_Supplier_Contract_Ratio
			group by guizuno
		) x on c.cSupNo=x.cSupNo
    where d.cSupNo is  null





select cGoodsNo,cSupplierNo,dSaleDate,fQuantity,
					fLastSettle,fCostMoney,
					cHezuofangshi
from #temp_SaleSheetDetail_perDay
where cHezuofangshi='联营'

select sum(fLastSettle) from #temp_SaleSheetDetail_perDay
select sum(fLastSettle)
from t_SaleSheetDetail  
where (dSaleDate between '2008-05-04' and '2008-08-10')  and isnull(tag_daily,0)=0  

select *
from
#temp_Supplier_Goods_Hezuofangshi
where cGoodsNo='23041762'

select * from #temp_Supplier_Hezuofangshi


*/
		
/*以上处理租赁成本*/

/*以下开始处理供货、联营成本  */


	
/*以上处理供货、联营成本*/
GO
