-----------------------------------------  从各个数据库中取日销售v  t_SaleSheet_Day
  ------2012-10-15  销售结转---------------------------------------------------------------    
CREATE proc p_x_salesABC_bySupplier_chen_WH_Ref
@date1 datetime,
@date2 datetime,
@dMaxDailyDate datetime,
---@databaseName varchar(32),
@cWHno varchar(32)
as
begin

 if exists (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date1)  -- 包含在时间断内
 begin
    if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor
   
   
			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName
			 
			
				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
						insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fQuantity,fLastSettle,bAuditing,cWHno)
						select dSaleDate,cGoodsNo,
						fQuantity,fLastSettle,bAuditing,cWHno 
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@dMaxDailyDate+''' and '''+@date2+''' and cWHno='''+@cWHno+'''
					
					    insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
						fQuantity,fLastSettle,bAuditing,cWHno)
						select dSaleDate,cGoodsNo,
						fQuantity,fLastSettle,bAuditing,cWHno 
						from '+@InfoName1+'.dbo.t_SaleSheet_Day 
						where dSaleDate between '''+@date1+''' and '''+@date2+''' and cWHno='''+@cWHno+'''
					
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
			 if not exists  (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date2)
            begin  	  
				insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno 
				from dbo.t_salesheetDetail 
				where dSaleDate between @dMaxDailyDate and @date2 and cWHno=@cWHno 
	 
	 
           		insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno 
				from dbo.t_SaleSheet_Day 
				--where dSaleDate between @date1 and @date2 and cWHno=@cWHno 
				where dSaleDate between @SalesheetDate and @date2 and cWHno=@cWHno
            end
end else
   begin  
     
                insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno 
				from dbo.t_salesheetDetail 
				where dSaleDate between @dMaxDailyDate and @date2 and cWHno=@cWHno 
	 
	 
           		insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno 
				from dbo.t_SaleSheet_Day 
				--where dSaleDate between @date1 and @date2 and cWHno=@cWHno 
				where dSaleDate between @date1 and @date2 and cWHno=@cWHno
   end

end
GO
