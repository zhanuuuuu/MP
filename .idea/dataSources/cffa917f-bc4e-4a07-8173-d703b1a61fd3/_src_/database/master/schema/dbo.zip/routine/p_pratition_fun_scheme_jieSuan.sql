
--创建分区函数，架构，分区表
/*
exec p_pratition_fun_scheme_jieSuan
*/
create proc p_pratition_fun_scheme_jieSuan
as
begin
	create partition function jieSuanPartFun(datetime)
	as
	range right for values(
	'2008-02-01',
	'2008-03-01',
	'2008-04-01',
	'2008-05-01',
	'2008-06-01',
	'2008-07-01',
	'2008-08-01',
	'2008-09-01',
	'2008-10-01',
	'2008-11-01',
	'2008-12-01'

	)
	create partition scheme jieSuanPartScheme
	as
	partition jieSuanPartFun
	to ([jieSuan_01],[jieSuan_02],[jieSuan_03],
		[jieSuan_04],[jieSuan_05],[jieSuan_06],
		[jieSuan_07],[jieSuan_08],[jieSuan_09],
		[jieSuan_10],[jieSuan_11],[jieSuan_12])

CREATE TABLE [dbo].[jiesuan](
    [zdriqi] [datetime] not null,
	[sheetno] [varchar](32) COLLATE Chinese_PRC_CI_AS NOT NULL,
	[jstype] [varchar](32) COLLATE Chinese_PRC_CI_AS NOT NULL,
	[mianzhi] [money] NULL CONSTRAINT [DF_jiesuan_mianzhi]  DEFAULT (0),
	[zhekou] [money] NULL CONSTRAINT [DF_jiesuan_zhekou]  DEFAULT (0),
	[zhaoling] [money] NULL CONSTRAINT [DF_jiesuan_zhaoling]  DEFAULT (0),
	[shishou] [money] NULL CONSTRAINT [DF_jiesuan_shishou]  DEFAULT (0),
	[jstime] [datetime] NULL,
	[jiaozhang] [smallint] NULL CONSTRAINT [DF_jiesuan_jiaozhang]  DEFAULT (0),
	[jiaozhangtime] [datetime] NULL CONSTRAINT [DF_jiesuan_jiaozhangtime]  DEFAULT (null),
	[jiaozhangdate] [datetime] NULL CONSTRAINT [DF_jiesuan_jiaozhangdate]  DEFAULT (null),
	[shouyinyuanno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
	[shouyinyuanmc] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
	[jiaokuantime] [datetime] NULL,
	[shoukuanno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
	[shoukuanname] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
	[netjiecun] [smallint] NOT NULL CONSTRAINT [DF_jiesuan_netjiecun]  DEFAULT (0),
	[orientmoney] [money] NULL,
	[leftmoney] [money] NULL,
	[storevalue] [smallint] NULL CONSTRAINT [DF_jiesuan_storevalue]  DEFAULT (0),
	[detail] [varchar](50) COLLATE Chinese_PRC_CI_AS NULL,
	[bPost] [bit] NULL CONSTRAINT [DF_jiesuan_bPost]  DEFAULT (0),
	[tag_daily] [bit] NULL,
 CONSTRAINT [PK_jiesuan] PRIMARY KEY CLUSTERED 
(
	[sheetno] ASC,
	[jstype] ASC,
    [zdriqi] asc
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [FG_jieSuan]
) ON jieSuanPartScheme([zdriqi])

	

	--select isdate(datename(yyyy,getdate())+'0201')
end
GO
