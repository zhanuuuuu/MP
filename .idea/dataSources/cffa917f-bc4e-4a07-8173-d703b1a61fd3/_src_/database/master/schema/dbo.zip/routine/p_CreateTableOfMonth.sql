

CREATE  procedure p_CreateTableOfMonth
@cYear char(4)
as
begin
  declare @cMonth char(2)
  declare @iMonth int
	set @iMonth=1
	while @iMonth<13
	begin
    set @cMonth=dbo.trim(cast(@iMonth as char(2)))
    if len(@cMonth)=1 
		begin
      set @cMonth='0'+@cMonth
		end
		declare @date1 datetime
		declare @date2 datetime
		declare @i int
		declare @iFirstWeeksOfMonth int
		declare @iDays int
		select @iDays=dbo.GetMonths(cast(@cMonth as int),cast(@cYear as int))
		set @date1=@cYear+'-'+@cMonth+'-01'
		set @date2=@cYear+'-'+@cMonth+'-'+cast(@iDays as char(2))
		set @i=1
		set @iFirstWeeksOfMonth=dbo.f_GetWeeks(@cYear+'-'+@cMonth+'-01')-1

		while @i<=@iDays
		begin
			if not exists(select cYear from dbo.t_WeekOfMonth 
					where cYear=@cYear and cMonth=@cMonth and iWeekNo=dbo.f_GetWeeks(@date1)-@iFirstWeeksOfMonth
				 )
			begin
				insert into dbo.t_WeekOfMonth(cYear,cMonth,iWeekNo,cWeekName1,cWeekName2,dDate1,dDate2)
				values(@cYear,@cMonth,dbo.f_GetWeeks(@date1)-@iFirstWeeksOfMonth,
							 DATENAME(dw,@date1),DATENAME(dw,@date1),@date1,@date1)

			end else
			begin
				update dbo.t_WeekOfMonth set dDate2=@date1,cWeekName2=DATENAME(dw,@date1)
				where cYear=@cYear and cMonth=@cMonth and iWeekNo=dbo.f_GetWeeks(@date1)-@iFirstWeeksOfMonth

			end
/*
		  print dbo.f_GetWeeks(@date1)
		  print dbo.f_GetDayOfWeek(@date1)
*/
		  set @date1=dateadd(day,1,@date1) 
			set @i=@i+1
		end
		set @iMonth=@iMonth+1
	end
  update dbo.t_WeekOfMonth set iDays=datediff(day,dDate1,dDate2)+1
end

/*


p_CreateTableOfMonth '2006'

select * from dbo.t_WeekOfMonth

--truncate table t_WeekOfMonth
*/


GO
