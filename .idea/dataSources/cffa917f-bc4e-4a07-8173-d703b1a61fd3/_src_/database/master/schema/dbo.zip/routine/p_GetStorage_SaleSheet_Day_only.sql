/*
p_GetStorage_SaleSheet_Day '2009-10-10'
*/

CREATE procedure p_GetStorage_SaleSheet_Day_only
@dDate datetime
as
begin
/*
  if(select object_id('tempdb..#temp_Goods')) is not null
  begin
	  drop table #temp_Goods
  end
  select cGoodsNo into #temp_Goods from t_Goods
*/
	select distinct a.cGoodsNo,a.fQty_CurWH,a.dSaleDate
  from t_SaleSheet_Day a,
  (
   
		select  cGoodsNo,dSaleDate_last=max(dSaleDate)
		from dbo.t_SaleSheet_Day
    where cGoodsNo in (select cGoodsNo from #temp_Goods)
		group by cGoodsNo
  ) b
  where a.dSaleDate=b.dSaleDate_last and a.cGoodsNo=b.cGoodsNo



end
GO
