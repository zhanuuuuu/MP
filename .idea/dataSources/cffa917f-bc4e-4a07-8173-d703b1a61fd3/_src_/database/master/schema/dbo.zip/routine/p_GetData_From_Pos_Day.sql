CREATE proc p_GetData_From_Pos_Day
as
begin
	begin try
		begin tran
			select distinct sheetno into #jiesuan
			from Pos_Day.dbo.jiesuan
			where isnull(bPost,0)=0

			select  distinct cSaleSheetno into #pos_SaleSheetDetail 
			from  Pos_Day.dbo.t_SaleSheetDetail
			where isnull(bPost,0)=0
			
			insert into dbo.jiesuan
			(
				sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,jiaozhang,
				jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
				shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,
				detail,bPost,tag_daily
			)
			select a.sheetno,a.jstype,a.mianzhi,a.zhekou,a.zhaoling,a.shishou,a.jstime,a.zdriqi,a.jiaozhang,
				a.jiaozhangtime,a.jiaozhangdate,a.shouyinyuanno,a.shouyinyuanmc,a.jiaokuantime,
				a.shoukuanno,a.shoukuanname,a.netjiecun,a.orientmoney,a.leftmoney,a.storevalue,
				a.detail,a.bPost,a.tag_daily
			from Pos_Day.dbo.jiesuan as a,#jiesuan as b
			where a.sheetno=b.sheetno and a.shishou is not null and a.shishou <>0
/*
select * from #jiesuan
*/

			insert into	dbo.t_SaleSheetDetail
			(
				cSaleSheetno,iSeed,cGoodsNo,cGoodsName,cBarCode,cOperatorno,cOperatorName,
				cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,fPrice,fNormalSettle,
				bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,fAgio,fLastSettle0,fLastSettle,
				cManager,cManagerno,dSaleDate,cSaleTime,dFinanceDate,cWorkerno,cWorker,bPost,
				bChecked,cCheckNo,dCheck,cVipNo,bBalance,jiesuanno,cStationNo,tag_daily
			)
			select a.cSaleSheetno,a.iSeed,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cOperatorno,a.cOperatorName,
				a.cVipCardno,a.bAuditing,a.cChkOperno,a.cChkOper,a.bSettle,a.fVipScore,a.fPrice,a.fNormalSettle,
				a.bVipPrice,a.fVipPrice,a.bVipRate,a.fVipRate,a.fQuantity,a.fAgio,a.fLastSettle0,a.fLastSettle,
				a.cManager,a.cManagerno,a.dSaleDate,a.cSaleTime,a.dFinanceDate,a.cWorkerno,a.cWorker,a.bPost,
				a.bChecked,a.cCheckNo,a.dCheck,a.cVipNo,a.bBalance,a.jiesuanno,a.cStationNo,a.tag_daily
			from Pos_Day.dbo.t_SaleSheetDetail as a , #pos_SaleSheetDetail b
			where a.cSaleSheetno=b.cSaleSheetno
            --where a.cSaleSheetno is not null

			update a
			set a.bPost=1
			from Pos_Day.dbo.t_SaleSheetDetail a,#pos_SaleSheetDetail b
			where a.cSaleSheetno=b.cSaleSheetno
			

			drop table #pos_SaleSheetDetail

			update a
			set a.bPost=1
			from Pos_Day.dbo.jiesuan a,#jiesuan b
			where a.sheetno=b.sheetno
			drop table #jiesuan
		commit tran
	end try
	begin catch
		rollback
	end catch
		
end

/*
FromPosToServer_jieSuan_chen
*/
GO
