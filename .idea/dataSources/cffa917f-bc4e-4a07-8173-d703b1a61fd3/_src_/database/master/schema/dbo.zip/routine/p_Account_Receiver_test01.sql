 

/*
p_Account_Receiver '','2014-12-22','2014-12-23','--'
go
p_Account_Receiver '802','2014-12-22','2014-12-23','--'

*/

CREATE   procedure [dbo].[p_Account_Receiver_test01]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime,
@cStoreNo varchar(32)
as
begin
  /*生成报表的列*/
  
  select fMoney_Save=sum(isnull(fMoney_Save,0)),cOpertorNo,cOperName,dSaleDate,cStoreNo,cStoreName
	into #temp_t_Vip_Save
	from t_Vip_Save
  where dSaleDate between @date1 and  @date2 and isnull(fMoney_Save,0)<>0
    and ( cStoreNo=@cStoreNo)
  
  group by cOpertorNo,cOperName,dSaleDate,cStoreNo,cStoreName

--select * from #temp_t_Vip_Save

------**********从p_Account_Ref 获取结算信息***********-----

    if (select OBJECT_ID('tempdb..#temp_Jiesuan'))is not null drop table #temp_Jiesuan
    create table #temp_Jiesuan(zdriqi datetime,detail varchar(32),theyear varchar(32),themonth varchar(32),
	mianzhi money,zhaoling money,shishou money,
	shouyinyuanno varchar(32),shouyinyuanmc varchar(32),sheetno varchar(32),jiaozhang money,jstime datetime,cStoreNo varchar(32),cStoreName varchar(64))

   
     
     insert into #temp_Jiesuan(zdriqi,theyear,themonth,detail,
	mianzhi,zhaoling,shishou,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo,cStoreName)
		select zdriqi,theyear=cast(year(zdriqi) as varchar(4)),themonth=cast(month(zdriqi) as varchar(2)),detail,
	sum(mianzhi),sum(zhaoling),sum(shishou),shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo,cStoreName
	from jiesuan
	where zdriqi between @date1 and  @date2
	  and ( cStoreNo=@cStoreNo)
	group by  cast(year(zdriqi) as varchar(4)),cast(month(zdriqi) as varchar(2)),detail,
	zdriqi,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo,cStoreName
 
   

-----
  select detail,sum(shishou) shishou 
  into #jiesuan_detail0
	---from jiesuan
	from #temp_Jiesuan
  where  zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
  group by detail
  union all
  select detail='服务台退货',shishou=-sum(fMoney)  
  from WH_ReturnGoods
  where  dDate between @date1 and  @date2 and isnull(fMoney,0)<>0
  and ( cStoreNo=@cStoreNo)


  select detail,shishou 
  into #jiesuan_detail
	from #jiesuan_detail0
  union all
  select detail='电子钱包',shishou=sum(isnull(fMoney_Save,0))
  from #temp_t_Vip_Save
 
  --where ISNULL(bZeng,0)=0
 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail

  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     门店编号No varchar(32) COLLATE Chinese_PRC_CI_AS ,
     门店名称 varchar(64) COLLATE Chinese_PRC_CI_AS ,
     收银员No varchar(32) COLLATE Chinese_PRC_CI_AS ,
     收银员 varchar(32) COLLATE Chinese_PRC_CI_AS ,
     结算日期 varchar(32) COLLATE Chinese_PRC_CI_AS 
	)

  declare @cAddFields varchar(4000)
  set @cAddFields=''
  declare @strtmp varchar(4000)
  set @strtmp=''
  declare @strtmp_group varchar(4000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(4000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+'合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+'合计=cast(sum(cast(合计 as money)) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+'合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
--  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

   --select * into ##account_detail from #account_detail



	select shouyinyuanno,shouyinyuanmc,detail,zdriqi=dbo.getdaystr(zdriqi),
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,sum(shishou) shishou,cStoreNo,cStoreName
  into #jiesuan
 ---from jiesuan
 from #temp_Jiesuan
	where zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
	group by  shouyinyuanno,shouyinyuanmc,detail,zdriqi,cStoreNo,cStoreName
  union all
	select shouyinyuanno=cOpertorNo,shouyinyuanmc=cOperName,detail='电子钱包',zdriqi=dbo.getdaystr(dSaleDate),
	 mianzhi=sum(fMoney_Save),zhaoling=0, shishou=sum(fMoney_Save),cStoreNo,cStoreName
	from #temp_t_Vip_Save
	where dSaleDate between @date1 and  @date2
	group by  cOpertorNo,cOperName,dSaleDate,cStoreNo,cStoreName
  union all
	select shouyinyuanno=cOperatorNo,shouyinyuanmc=cOperator,detail='服务台退货',zdriqi=dbo.getdaystr(dDate),
	mianzhi=-sum(fMoney),zhaoling=0.00,shishou=-sum(fMoney) ,cStoreNo,cStoreName
	from WH_ReturnGoods
	where dDate between @date1 and  @date2 and ( cStoreNo=@cStoreNo) and isnull(fMoney,0)<>0
	group by  cOperatorNo,cOperator,dDate,cStoreNo,cStoreName

	order by cStoreNo,cStoreName,shouyinyuanno,shouyinyuanmc,zdriqi
 
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,zdriqi,shishou=cast(shishou as char(32)),cStoreNo,cStoreName
  from #jiesuan
  order by zdriqi,cStoreNo,cStoreName,shouyinyuanno,shouyinyuanmc,detail
  
  select sheetno,shouyinyuanno,shouyinyuanmc,zdriqi,shishou=SUM(isnull(shishou,0)),cStoreNo,cStoreName
  into #jiesuan_01
  --from jiesuan
  from #temp_Jiesuan
  where zdriqi between @date1 and  @date2
  group by sheetno,shouyinyuanno,shouyinyuanmc,zdriqi,cStoreNo,cStoreName

 
  select shouyinyuanno,shouyinyuanmc,zdriqi=dbo.getdaystr(zdriqi),shishou=cast(sum(isnull(shishou,0)) as char(32)),cStoreNo,cStoreName
  into #jiesuan_heji
  from #jiesuan
  group by shouyinyuanno,shouyinyuanmc,zdriqi,cStoreNo,cStoreName
  

  
  declare @cStoreNo1 varchar(32)
  declare @cStoreName varchar(32)
  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou,@cStoreNo1,@cStoreName


  while @@fetch_status=0
  begin
		if (select 收银员No from #account_detail 
				where 收银员No=@shouyinyuanno and 收银员=@shouyinyuanmc and 结算日期=@zdriqi and 门店编号No=@cStoreNo1) is null
    begin
      exec('insert into #account_detail select '''+@cStoreNo1+''','''+@cStoreName+''','''+@shouyinyuanno+''','''+@shouyinyuanmc+''','''+@zdriqi+''','+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 收银员No='''+@shouyinyuanno+'''  and 收银员='''+@shouyinyuanmc+'''  and 结算日期='''+@zdriqi+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou,@cStoreNo1,@cStoreName     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 

  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc and a.结算日期=b.zdriqi and a.门店编号No=b.cStoreNo

  update a set a.门店名称=b.cStoreName
  from #account_detail a,t_Store b
  where a.门店编号No=b.cStoreNo  
  
 
 
  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 门店编号No=''总计'',门店名称=null,收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
		+' if not exists 
		 ( 
		 select column_name from information_schema.columns  
		 where table_name=''#account_detail_last'' and column_name=''收款'' 
		 )   
		 begin  
			 alter table #account_detail_last add 收款 money,退款  money 
		 end 
		 
	 

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a left join
		(select shouyinyuanno,shouyinyuanmc,zdriqi,shishou=sum(isnull(shishou,0)),cStoreNo,cStoreName
		from #jiesuan_01
		where isnull(shishou,0)<0
		group by zdriqi,shouyinyuanno,shouyinyuanmc,cStoreNo,cStoreName	) b
		on a.结算日期=b.zdriqi and a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc
		and a.门店编号No=b.cStoreNo 

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a ,
		(select shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		) b
		where  a.收银员No=''总计''
	 '
 
    +' select * from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 收银员No='''+@guizuno+''' '+'
    
    union all
    select 门店编号No=''总计'',门店名称=null,收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail where 收银员No='''+@guizuno+''' '
    +@strtmp_Clear
		+' if not exists 
		 ( 
		 select column_name from information_schema.columns  
		 where table_name=''#account_detail_last'' and column_name=''收款'' 
		 )   
		 begin  
			 alter table #account_detail_last add 收款 money,退款  money 
		 end 

		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a left join
		(select shouyinyuanno,shouyinyuanmc,zdriqi,shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		group by zdriqi,shouyinyuanno,shouyinyuanmc	) b
		on a.结算日期=b.zdriqi and a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc
		update a set a.收款=a.合计-isnull(b.shishou,0),a.退款=b.shishou
		from #account_detail_last a ,
		(select shishou=sum(isnull(shishou,0))
		from #jiesuan_01
		where isnull(shishou,0)<0
		) b
		where  a.收银员No=''总计''
	 '
    +' select * from #account_detail_last')
  end

end


GO
