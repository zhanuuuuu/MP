--select * from t_wh_form
--select * from dbo.t_Cost_distribute
/*
  declare @dDate datetime
  set @dDate='2009-11-20'
  FIFO先进先出成本表（库龄、失效期、买完？）
drop table #tmpCostGoodsList
select cGoodsNo into #tmpCostGoodsList from t_goods where cgoodsNo='117589'
create table #tmpCostTypeList (cTypeNo varchar(32)) 
insert into #tmpCostTypeList 
select distinct cGoodsTypeno from t_GoodsType  where cGoodsTypeno like '10%'
create table #tmpCostSupList (cSupNo varchar(32))  
create table #tmpCostGoodsList (cGoodsNo varchar(32))  

exec p_FIFOCWhStorage_chen_MultiSup '2015-3-7','2015-5-18','01',0

*/
CREATE proc [dbo].[p_FIFOCWhStorage_chen_MultiSup]
@dDate1 datetime,
@dDate2 datetime,
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商
as
--declare @dDate datetime
--declare @Type int
--  set @dDate='2009-11-24'
--set @Type=0
if (select object_id('tempdb..#FIFOCWhDate_chen'))is not null
drop table #FIFOCWhDate_chen
if (select object_id('tempdb..#tmp_Date1In'))is not null
drop table #tmp_Date1In
if (select object_id('tempdb..#tmp_Date1Out'))is not null
drop table #tmp_Date1Out
if (select object_id('tempdb..#tmp_Date2In'))is not null
drop table #tmp_Date2In
if (select object_id('tempdb..#tmp_Date2Out'))is not null
drop table #tmp_Date2Out
create table #FIFOCWhDate_chen
(
  cGoodsNo varchar(32),
  cGoodsName varchar(100),
  date1 datetime,
  date2 datetime,
  fQty_in_bgn money,
  fMoney_in_bgn money,  --起初接收
  fQty_Out_bgn money,
  fMoney_Out_bgn money,
  fMoneySale_Out_bgn money,--起初发出
  fSheetMoney_Out_bgn money default(0),--起初发出单据金额
  fQty_bgn money,
  fMoney_bgn money,        --起初库存
  fQty_in_period money,
  fMoney_in_period money,  --期间接收
  fQty_Out_period money,
  fMoney_Out_period money,
  fMoneySale_Out_period money,--期间发出
  fQty_period money,
  fMoney_period money, --期间库存（tmp）
  cSupNO varchar(32),
  cSupName varchar(64),
  cUnit varchar(32),
  cSpec varchar(32),
  fQty money,
  fMOney money,
  cGoodsTypeno varchar(32),
  cGoodsTypeName varchar(64)
  
 ) 

--insert into #FIFOCWhDate_chen
--(
--  cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,date1,date2
--)
--select cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,@dDate1,@dDate2
--from t_goods
--where 
if (select object_id('tempdb..#tmpGoodsSupplierno'))is not null
drop table #tmpGoodsSupplierno

select distinct a.cGoodsNo,a.cSupplierNo,cSupplier=null
into #tmpGoodsSupplierno
from
(
	select cGoodsNo,cSupplierNo=cSupNo
	from t_goods
	union
	select distinct cGoodsNo,cSupplierNo
	from T_WH_Form_Log --where dDateTime<=@dDate2
) a	


---  t_supplier
insert into #FIFOCWhDate_chen
(
  cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,date1,date2
)

select x.cGoodsNo,x.cGoodsName,x.cUnit,x.cSpec,x.cSupNO,x.cSupName,x.cGoodsTypeno,x.cGoodsTypeName,@dDate1,@dDate2
from (select a.cGoodsNo,b.cGoodsName,b.cUnit,b.cSpec,cSupNO=a.cSupplierNo,cSupName=a.cSupplier,b.cGoodsTypeno,b.cGoodsTypename,b.bstorage 
     from #tmpGoodsSupplierno a,t_goods b where a.cGoodsNo=b.cGoodsNo) x
where 
isnull(bstorage,0)=1
and(
     ( 
--        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)

        ( @Type=0 )
				and cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log
				 where cGoodsNo in (select distinct cGoodsNo from #tmpCostGoodsList)
				)
 
     )
      or
     ( 
--        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
        ( @Type=1 )
				and cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log 
				 where cGoodsNo in 
				 (select distinct b.cGoodsNo from #tmpCostTypeList a,t_Goods b where a.cTypeNo=b.cGoodsTypeNO )
				)
     )
     or
     ( 
        --(@Type=2)and cSupNo in(select distinct cSupNo from #tmpCostSupList)
        (@Type=2)
				--and cGoodsNo in
				--(select distinct cGoodsNo from t_WH_Form 
				-- where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				--)
				and x.cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log 
				 where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				 union
				 select cGoodsNo from t_Goods 
				 where cSupNo in (select distinct cSupNo from #tmpCostSupList)				 
				)
     )
)


/*
select a.cGoodsNo,fQty_in=sum(isnull(b.fQty_in,0)),fMoney_In=sum(isnull(b.fMoney_In,0))
into #tmp_Date1In
from #FIFOCWhDate_chen a left join t_wh_form  b
on a.cGoodsNo=b.cGoodsNo and b.dDateTime<@dDate1
where b.cWhNo=@cWhNo
group by a.cGoodsNo 

*/

--起初入库数量------------- 

select  cGoodsNo,cSupNO
into #FIFOCWhDate_chen_SingleMainSupplier
from #FIFOCWhDate_chen


declare @MaxCost datetime  --- 获取最大的月结日期 
select @MaxCost=isnull(MAX(date2),'2000-01-01') from t_MaxMonthDate

declare @maxWhDate datetime,@PosName varchar(32)
select @PosName=Pos_WH_Form from t_WareHouse

if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(dDateEnd),''2000-01-01'') from '+@PosName+'.dbo.t_WH_Form_Log_Month  with (nolock) ')
set @maxWhDate=(select dDate from #temp_maxWhdDate)

------从月结表
if (select OBJECT_ID('tempdb..#tmp_Date1In'))is not null drop table #tmp_Date1In
create table #tmp_Date1In(
  cGoodsNo varchar(32),cSupplierNo varchar(32),fQty_in money,fMoney_In money,fQty_Left money,fMoney_Left money
)

if (select OBJECT_ID('tempdb..#temp_distribute'))is not null drop table #temp_distribute
create table #temp_distribute(cGoodsNo varchar(32),fQty_Cost money,fMoney_Cost money,
fMoney_sale money,cSupplierNo varchar(32),cSupplier varchar(64),
fQty_end money,fMoney_end money
)

-------期间入库
if (select OBJECT_ID('tempdb..#tmp_Date2In1'))is not null drop table #tmp_Date2In1
create table #tmp_Date2In1(
  cGoodsNo varchar(32),cSupplierNo varchar(32),fQty_in money,fMoney_In money,fQty_Left money,fmoney_Left money,fMoney_TrfIn money,iAttribute int
)

--期间出库数量
if (select object_id('tempdb..#tmp_PeriodOut_List'))is not null
drop table #tmp_PeriodOut_List
create table #tmp_PeriodOut_List(cGoodsNo varchar(32),cSupplierNo varchar(32),
iAttribute int,bdone bit,fQty_Out money,fMoney_Out money,fSheetMoney money)

if @maxWhDate<@dDate1
begin
    declare @maxWhDate1 varchar(32)
    set @maxWhDate1=dbo.getdaystr(@maxWhDate)
    declare @d1_1 varchar(32)
    set @d1_1=dbo.getdaystr(@maxWhDate+1)
    
     declare @d11_1 varchar(32)
    set @d11_1=dbo.getdaystr(@dDate1-1)
    
   exec('
       select a.cGoodsNo,fQty_in=isnull(入库数量1,0)+isnull(报溢数量1,0)+isnull(退货入库数量1,0)+isnull(调拨入库数量1,0)+isnull(成品入库数量1,0)
	   ,fMoney_In=isnull(入库金额1,0)+isnull(报溢金额1,0)+isnull(退货入库金额1,0)+isnull(调拨入库金额1,0)+isnull(成品入库金额1,0),
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   ,b.cSupplierNo,fQty_Left=0,fMoney_Left=0
		into #temp_Date1In_MultiSupplier
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_Month  b
	   on a.cGoodsNo=b.cGoodsNo and b.dDateEnd='''+@maxWhDate1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
	   b.cSupplierNo,b.fQty_Left,b.fMoney_Left 
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
       b.cSupplierNo,0,0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@d1_1+''' and '''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20
	   ------------获取时间段的情况
	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,fMoney_Out=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)),
	   b.cSupplierNo,0,0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@maxWhDate1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   

	   ------ 期初入库
        insert into #tmp_Date1In(cGoodsNo,cSupplierNo,fQty_in,fMoney_In)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0))
		from #temp_Date1In_MultiSupplier
		group by cGoodsNo,cSupplierNo
		
		
		--起初出库数量
 
 
		insert into #temp_distribute(cGoodsNo,cSupplierNo,fQty_Cost,fMoney_Cost,fMoney_sale)
		select x.cGoodsNo,x.cSupplierNo,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale 
		from 
		(select b.cGoodsNo,cSupplierNo,fQty_Cost=sum(isnull(fQty_in,0))-sum(fQty_Left),
		fMoney_Cost=SUM(fMoney_In)-sum(fMoney_Left),fMoney_sale=SUM(fMoney_Out)
		 from	#temp_Date1In_MultiSupplier b
		 group by   b.cGoodsNo,cSupplierNo
		) x

       ---------------获取期间-------
       
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out,fQty_Out
	  ,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   into #temp_Date1In_MultiSupplier_1
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,0,0,
	   fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	       union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
 
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute=10  
	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	  ,b.cSupplierNo,0,0,
	  fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	  ,b.cSupplierNo,0,0,
	  fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	   

	   
        --- 期间入库
	    insert into #tmp_Date2In1(cGoodsNo,cSupplierNo,fQty_in,fMoney_In,fQty_Left,fmoney_Left)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0)),sum(fQty_Left),sum(fmoney_Left)
		from #temp_Date1In_MultiSupplier_1
		group by cGoodsNo,cSupplierNo
		
		
		--- 期间发出
		  insert into #tmp_PeriodOut_List(cGoodsNo,cSupplierNo,fQty_Out,fMoney_Out,fSheetMoney)
		  select x.cGoodsNo,x.cSupplierNo,sum(x.fQty_Out),sum(fMoney_Out),fSheetMoney=sum(x.fMoney_Outsal)
		  from #temp_Date1In_MultiSupplier_1 x
		  group by x.cGoodsNo,x.cSupplierNo
		  ')
end else
begin
      declare @d1 datetime
      set @d1=CAST((cast(YEAR(@dDate1) as varchar(16))+'-'+cast(MONTH(@dDate1) as varchar(16))+'-01') AS DATETIME)
      declare @d1_bgn varchar(32)
      set @d1_bgn=dbo.getDayStr(DATEADD(MONTH,-1,@d1))
       declare @d1_str varchar(32)
      set @d1_str=dbo.getDayStr(@d1-1)
      
        declare @dd1_str varchar(32)
      set @dd1_str=dbo.getDayStr(@dDate1-1)
     exec('
       select a.cGoodsNo,fQty_in=isnull(入库数量1,0)+isnull(报溢数量1,0)+isnull(退货入库数量1,0)+isnull(调拨入库数量1,0)+isnull(成品入库数量1,0)
	    ,fMoney_In=isnull(入库金额1,0)+isnull(报溢金额1,0)+isnull(退货入库金额1,0)+isnull(调拨入库金额1,0)+isnull(成品入库金额1,0)
	   ,b.cSupplierNo ,fQty_Left=0,fMoney_Left=0,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   into #temp_Date1In_MultiSupplier0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_Month  b
	   on a.cGoodsNo=b.cGoodsNo and 
	   b.dDateBgn='''+@d1_bgn+''' 
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,b.cSupplierNo ,b.fQty_Left,b.fMoney_Left ,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,b.cSupplierNo ,0,0,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@d1+''' and '''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20
	   	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,b.cSupplierNo ,0,0 ,
	   fMoney_Out=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   
	
        insert into #tmp_Date1In(cGoodsNo,cSupplierNo,fQty_in,fMoney_In)
		select x.cGoodsNo,x.cSupplierNo,fQty_in=sum(isnull(x.fQty_in,0)),fMoney_In=sum(isnull(x.fMoney_In,0))
		--into #tmp_Date1In
		from #temp_Date1In_MultiSupplier0 x
		group by x.cGoodsNo,x.cSupplierNo
		
		
	 --起初出库数量 
 
		insert into #temp_distribute(cGoodsNo,cSupplierNo,fQty_Cost,fMoney_Cost,fMoney_sale)
		select x.cGoodsNo,x.cSupplierNo,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale 
		from 
		(select b.cGoodsNo,cSupplierNo,fQty_Cost=sum(isnull(fQty_in,0))-sum(fQty_Left),
		fMoney_Cost=SUM(fMoney_In)-sum(fMoney_Left),fMoney_sale=SUM(fMoney_Out)
		 from	#temp_Date1In_MultiSupplier0 b
		   group by  b.cGoodsNo,cSupplierNo
		) x
 
		---------------获取期间-------

       select a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out,fQty_Out
	   ,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	   fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
 
	   into #temp_Date1In_MultiSupplier0_1
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,0,0,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
 
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20  
	     union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
 
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute=10  
	   union all
	    select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	   ,b.cSupplierNo,0,0,
	   fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo

	 
	   
        --- 期间入库
	    insert into #tmp_Date2In1(cGoodsNo,cSupplierNo,fQty_in,fMoney_In,fQty_Left,fmoney_Left)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0)),sum(fQty_Left),sum(fMoney_Left)
		from #temp_Date1In_MultiSupplier0_1
		group by cGoodsNo,cSupplierNo
		
 
		--- 期间发出
		insert into #tmp_PeriodOut_List(cGoodsNo,cSupplierNo,fQty_Out,fMoney_Out,fSheetMoney)
		select x.cGoodsNo,x.cSupplierNo,sum(x.fQty_Out),sum(fMoney_Out),fSheetMoney=sum(x.fMoney_Outsal)
		from #temp_Date1In_MultiSupplier0_1 x
		group by x.cGoodsNo,x.cSupplierNo
		
		')
end

 
exec('
 
select a.cGoodsNo,b.fQty_in,b.fMoney_In,b.cSupplierNo 
into #temp_MultiSupplier
from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
where b.cWhNo='+@cWhNo+'  and a.cSupNO=b.cSupplierNo
union all 
select a.cGoodsNo,b.fQty_in,b.fMoney_In,b.cSupplierNo 
from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
where b.cWhNo='+@cWhNo+'  and a.cSupNO=b.cSupplierNo and b.iAttribute<>20

select distinct a.cGoodsNo,a.cSupplierNo,cGoodsName=cast(null as varchar(64)),
cSupName=cast(null as varchar(64)),date1='''+@dDate1+''',date2='''+@dDate2+'''--主供应商外的其它供应商
into #temp_otherSupplier
from
(
	select distinct cGoodsNo,cSupplierNo
	from #temp_MultiSupplier
) a left join #FIFOCWhDate_chen b on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNO
where b.cSupNO is null

 
insert into #FIFOCWhDate_chen(cGoodsNo,cGoodsName,cSupNO,cSupName,date1,date2)
select cGoodsNo,cGoodsName,cSupplierNo,cSupName,'''+@dDate1+''','''+@dDate2+'''  --插入主供应商外的其它供应商
from #temp_otherSupplier

')

delete from #FIFOCWhDate_chen
where @Type=2 and cSupNO not in (select distinct cSupNo from #tmpCostSupList)

 
update a
set a.cSupName=b.cSupName
from #FIFOCWhDate_chen a,t_Supplier b
where a.cSupNO=b.cSupNo

    --select * into  ##tmp_Date1In_old from #tmp_Date1In
    
    --  select * into  ##FIFOCWhDate_chen_old from #FIFOCWhDate_chen
 
update a
set a.fQty_in_bgn=isnull(b.fQty_in,0),a.fMoney_in_bgn=isnull(b.fMoney_In,0)
from #FIFOCWhDate_chen a,#tmp_Date1In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
  
 
select cGoodsNo,cSupplierNo,cSupplier,fQty_Out=fQty_Cost, fMoney_Out=fMoney_Cost,fSheetMoney=fMoney_sale,fQty_end,fMoney_end
into #tmp_Date1Out_List 
from #temp_distribute

select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0)),
fQty=SUM(ISNULL(fQty_end,0)),fMoney=SUM(ISNULL(fMoney_end,0))
into #tmp_Date1Out
from #tmp_Date1Out_List
group by cGoodsNo,cSupplierNo

  
 
update a
set a.fQty_Out_bgn=isnull(b.fQty_Out,0),a.fMoney_Out_bgn=isnull(b.fMoney_Out,0),
fSheetMoney_Out_bgn=isnull(b.fSheetMoney,0),
fMoneySale_Out_bgn=isnull(b.fSheetMoney,0)
from #FIFOCWhDate_chen a,#tmp_Date1Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

--select * from #FIFOCWhDate_chen

--期间入库数量
/*
select a.cGoodsNo,fQty_in=sum(isnull(b.fQty_in,0)),fMoney_In=sum(isnull(b.fMoney_In,0))
into #tmp_Date2In
from #FIFOCWhDate_chen a left join t_wh_form  b
on a.cGoodsNo=b.cGoodsNo and b.dDateTime between @dDate1 and @dDate2
where b.cWhNo=@cWhNo
group by a.cGoodsNo 

update a
set a.fQty_in_period=isnull(b.fQty_in,0),a.fMoney_In_period=isnull(b.fMoney_In,0)
from #FIFOCWhDate_chen a,#tmp_Date2In b
where a.cGoodsNo=b.cGoodsNo
*/
/*
--select b.cGoodsNo,b.cSupplierNo,fQty_in=sum(isnull(b.fQty_in,0)),
--fMoney_In=sum(isnull(b.fMoney_In,0)),fMoney_TrfIn=sum(isnull(b.fQty_in*b.fPrice_Tran,0)),b.iAttribute
--into #tmp_Date2In1
--from t_wh_form  b  
--where b.dDateTime between @dDate1 and @dDate2 and isnull(b.fQty_in,0)<>0
--and b.iAttribute is not null
--and b.cWhNo=@cWhNo and b.cGoodsNo in (select cGoodsNo from #FIFOCWhDate_chen_SingleMainSupplier)
--group by b.cGoodsNo,b.cSupplierNo,b.iAttribute
*/
---从入库单里面找
 

select b.cGoodsNo,b.cSupplierNo,fQty_in=sum(isnull(b.fQty_in,0)),
fMoney_In=sum(isnull(b.fMoney_In,0)),fMoney_TrfIn=sum(isnull(fMoney_TrfIn,0)),fQty_Left=SUM(fQty_Left),fmoney_Left=SUM(fmoney_Left)
into #tmp_Date2In
from #tmp_Date2In1 b
group by b.cGoodsNo,b.cSupplierNo

--select * from #tmp_Date2In
 
select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
into #tmp_Date2Out
from #tmp_PeriodOut_List
group by cGoodsNo,cSupplierNo



--起初期末库存数
update a
set a.fQty_In_period=b.fQty_In,
a.fMoney_In_period=b.fMoney_In,--,a.fMoneySale_Out_bgn=b.fSheetMoney--,a.fMoney_in_period=b.fMoney_Out
a.fQty=b.fQty_Left,a.fMOney=b.fmoney_Left
from #FIFOCWhDate_chen a,#tmp_Date2In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupplierNo
 
update a
set a.fQty_Out_period=b.fQty_Out,
a.fMoney_out_period=b.fMoney_Out,a.fMoneySale_Out_period=b.fSheetMoney--,a.fMoney_in_period=b.fMoney_Out
from #FIFOCWhDate_chen a,#tmp_Date2Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupplierNo


/*减去退货入库的*/
--update a
--set a.fQty_Out_period=a.fQty_Out_period-b.fQty_In,
--a.fMoney_out_period=a.fMoney_out_period-b.fMoney_In,a.fMoneySale_Out_period=a.fMoneySale_Out_period-b.fMoney_In--,a.fMoney_in_period=b.fMoney_Out
--from #FIFOCWhDate_chen a,#tmp_Date2In1 b
--where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupplierNo
--and isnull(b.iAttribute,1000)=13


update #FIFOCWhDate_chen
set fQty_bgn=isnull(fQty_in_bgn,0)-isnull(fQty_Out_bgn,0),
    fMoney_bgn=isnull(fMoney_in_bgn,0)-isnull(fMoney_out_bgn,0),
    fQty_period=isnull(fQty_in_period,0)-isnull(fQty_Out_period,0),
    fMoney_period=isnull(fMoney_in_period,0)-isnull(fMoney_out_period,0)

 
update #FIFOCWhDate_chen
set fQty=isnull(fQty_bgn,0)+isnull(fQty_Period,0),
    fMoney=isnull(fMoney_period,0)+isnull(fMoney_bgn,0)

 

update a
set a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.cGoodsTypeNo=b.cGoodsTypeNo,a.cGoodsTypeName=b.cGoodsTypeName
from #FIFOCWhDate_chen a,t_Goods b
where a.cGoodsNo=b.cGoodsNo

--select cGoodsNo,cGoodsName,date1,date2,fQty_in_bgn,fMoney_in_bgn,fQty_out_bgn,fMOney_out_bgn,fQty_bgn,fMOney_bgn, 
--fQty_in_period,fMoney_in_period,fQty_out_period,fMOney_out_period,fQty_period,fMOney_period,cSupNo,cSupName,
--cUnit,cSpec,fQty,fMoney,cGoodsTypeno,cGoodsTypeName,iserno=0,fMoneySale_Out_bgn,fMoneySale_Out_period,iLineNo=0
--  into	##temp_Cost 
--from #FIFOCWhDate_chen


select cGoodsNo,cGoodsName,date1,date2,fQty_in_bgn,fMoney_in_bgn,fQty_out_bgn,fMOney_out_bgn,fQty_bgn,fMOney_bgn, 
fQty_in_period,fMoney_in_period,fQty_out_period,fMOney_out_period,fQty_period,fMOney_period,cSupNo,cSupName,
cUnit,cSpec,fQty,fMoney,cGoodsTypeno,cGoodsTypeName,iserno=0,fMoneySale_Out_bgn,fMoneySale_Out_period,iLineNo=0
from #FIFOCWhDate_chen --where cGoodsNo<>'117589'
union all
select cgoodsno,cGoodsName='小计:',date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,iserno=1,sum(fMoneySale_Out_bgn),sum(fMoneySale_Out_period),iLineNo=1
from #FIFOCWhDate_chen --where cGoodsNo<>'117589'
group by cgoodsno
union all
select '合计:',null,date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,iserno=1,sum(fMoneySale_Out_bgn),sum(fMoneySale_Out_period),iLineNo=2
from #FIFOCWhDate_chen --where cGoodsNo<>'117589'
order by cgoodsno,iLineNo,iserno,cSupNo

GO
