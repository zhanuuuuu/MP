 
 
/*
--原来毛利脚本

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods   where  cgoodsno='33341'
--union all
--select cGoodsNo,csupno='1070' from t_Goods where  cgoodsno='101267'

exec [p_x_salesABC_byGoods_log] '2015-4-1','2015-4-30','02'
 
*/
CREATE procedure [dbo].[p_GetLastMonthSale_wei]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cdbname varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）


declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  
 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo into  #tmp_WhGoodsList   from (
select distinct  cGoodsNo=b.cGoodsNo_minPackage  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsNo  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))=''
union all
select distinct b.cGoodsNo  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage 
) a
 

CREATE INDEX IX_tmp_WhGoodsList ON #tmp_WhGoodsList(cGoodsNo)

 
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money,fmoney_cost money )
CREATE TABLE #temp_WhFromend   ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money,fmoney_cost money)
  
 
-----查最大日结时间内信息@dDateBegin到@dDateEnd

	
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateEnd)
set @Day1=day(@dDateEnd)
set @Y1=YEAR(@dDateEnd)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end
 
declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
 

insert into #temp_WhFromend  ([cGoodsNo],[cWHno]) 
select cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@dDateEnd) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@dDateEnd) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
    
	if(@bY1<>@eY1)
	begin 
	    set @tj='1'
	end else
	begin
	  if @bM1=@eM1
	  begin
      exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	fQty0=b.fQty_010131,fQtytj0=b.fQtytj_010131   
	into #temp_Wh_Goods_endQty
	from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	Sale0=b.Sale_010131, Saletj0=b.Saletj_010131  
	into #temp_Wh_Goods_endSale					
	from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)   
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,销售数量0)
	select cgoodsno,isnull(fQty1,0)-isnull(fQty0,0)
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0)			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo 
	')
      exec('
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 					 
	into #temp_Wh_Goods_endCost
	from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno
	

    update a 
	set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo 
 
')
      end else
      begin
        set @tj='1'
      end
	end
	if @tj='1'
	begin
	  
		insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
		select cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
		CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
		exec('
			--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale	            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno
			 
			 
			
			insert into #temp_WhFrombegin(cgoodsno,销售数量0)
			select cgoodsno,fQty
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cgoodsno
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo 
			 
		')

		exec('
		 --------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno
			 
			 
			
			insert into #temp_WhFromend(cgoodsno,销售数量0)
			select cgoodsno,fQty
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo 
		')
		exec('----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cgoodsno
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo 
		 
		')
	 
		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo
	end
end else
begin
   if @M1=@M_1
   begin
   exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+'   
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'  
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)   
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,销售数量0)
	select cgoodsno,isnull(fQty1,0)-isnull(fQty0,0)
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0)			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo 
	')
   exec('
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  					 
	into #temp_Wh_Goods_endCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno
	

    update a 
	set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo 
 
')
end else
begin
        insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
		select cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
		CREATE INDEX IX_temp_WhFrombegin0  ON #temp_WhFrombegin(cGoodsNo)
		exec('
			--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale	            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno
			 
			 
			
			insert into #temp_WhFrombegin(cgoodsno,销售数量0)
			select cgoodsno,fQty
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cgoodsno
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo 
			 
		')

		exec('
		 --------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno
			 
			 
			
			insert into #temp_WhFromend(cgoodsno,销售数量0)
			select cgoodsno,fQty
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo 
		')
		exec('----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cgoodsno
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo 
		 
		')
	 
		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo
   end
end
-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
--- 结束日期数据-（开始日期-1）数据 得出时间段数据   

 
 
if (select OBJECT_ID('tempdb..#temp_ReadycGoodsHb'))is not null drop table #temp_ReadycGoodsHb
select [cGoodsNo],[cWHno],xsQty=销售数量0,xsMoney=销售金额0,fMoney_Cost
into #temp_ReadycGoodsHb
from #temp_WhFromend	 

-----------包装转换-------

update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1) 
from #temp_ReadycGoodsHb a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

   
if(select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null 
begin	   
       insert into  #temp_GetLastMonthSale_wei(cgoodsno,[cWHno],xsQty,xsMoney,fMoney_Cost)     
		  select [cGoodsNo],[cWHno],xsQty=ISNULL(SUM(xsQty),0),xsMoney=ISNULL(SUM(xsMoney),0),sum(fMoney_Cost)
		  from #temp_ReadycGoodsHb
		  group by [cGoodsNo],[cWHno] 
end  
	/*获取时间段的入库记录 日期以单据日期为判断。*/

GO
