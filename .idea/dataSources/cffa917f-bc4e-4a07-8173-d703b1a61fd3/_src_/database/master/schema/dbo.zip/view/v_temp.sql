
create view v_temp
as
select cGoodsNo,bAuditing,dSaleDate,fQuantity=sum(fQuantity)

from dbo.t_SaleSheetDetail
group by cGoodsNo,dSaleDate,bAuditing

GO
