/*
  
  declare @return varchar(32)
  exec p_cStoreBhApplyTocStoreOut 'BHSQ20161004-000013',@return output
  select @return
  
*/
CREATE proc [dbo].[p_cStoreBhApplyTocStoreOut_1]
@cSheetNo varchar(32),--- 补货单号。
@return varchar(32) output    -- 正确返回配送出库单号、异常返回0
as
begin

   declare @cStoreNo varchar(32)
   declare @dDAte datetime
   select @cStoreNo=cStoreNo,@dDAte=dDate from WH_BhApply
   where cSheetno=@cSheetNo
 
   
 
      --生成配送出库单号
      declare @cOutSheetno varchar(32)
      select @cOutSheetno=dbo.f_GencStoreOutsheetno(CAST(Year(@dDAte) as varchar),@cStoreNo)
      
      --- 生成出库批次号
      declare @cOutSerNo varchar(32)
      
      set @cOutSerNo=(select dbo.[f_cStoreOutPcSerNo](@dDAte,@cStoreNo))
      
	   ---插入单据
	   insert into wh_cStoreOutWarehouse  (    
	   cSheetno,cCustomerNo,cCustomer,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,    
	   bExamin,cWhNo,cWh,dDate,cTime,cBeizhu1,cBeizhu2,cStoreNo,cStoreName,StoreInSheetNo,cOutSerNo)  
	   select   @cOutSheetno,a.cStoreNo,a.cStoreName,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,     1,b.cWhNo,b.cWh,    
	   dDate,cTime,cBeizhu1,cBeizhu2,b.cStoreNo,b.cStoreName,cSheetno ,@cOutSerNo
	   from WH_BhApply a,v_StoreParent b 
	   where  cSheetno=@cSheetNo 
	   and a.cStoreNo=b.cStoreNo1
	   
	   
	  -- 插入明细  
      insert into dbo.wh_cStoreOutWarehouseDetail  
      (    cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,    
      fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,    
      fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,    cUnit,cSpec  )  
      select @cOutSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,  
		fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,  
		fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,cUnit,cSpec  
		from WH_BhApplyDetail  
		where cSheetNo=@cSheetNo
		order by iLineNo
	      
      update WH_BhApply set bPeisong=1,OutSheetNo=@cOutSheetno 
      where cSheetNo=@cSheetNo
      
      --commit tran
	  set @return=@cOutSheetno        -- 正确返回1 
 
	   --update WH_BhApply set bPeisong=0,bfresh=0
	   --where cSheetno='BHSQ20161004-000013'
   
end
GO
