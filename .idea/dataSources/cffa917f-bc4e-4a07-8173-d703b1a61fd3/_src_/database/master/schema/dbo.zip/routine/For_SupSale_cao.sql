
/*
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select cGoodsNO,cSupplierNo=cSupNo into #temp_Goods  from t_goods --where cGoodsNO='14001'
exec [For_SupSale_cao] '2014-01-1','2014-01-15','01'
*/
create procedure For_SupSale_cao
@dBeginDate datetime,
@dEndDate datetime,
@cWHno varchar(32)
as
--declare @dBeginDate datetime,@dEndDate datetime,@cWHno varchar(32)
--select @dBeginDate='2014-06-06',@dEndDate='2014-06-06',@cWHno='01'

if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select cGoodsNO,cSupplierNo=cSupNo into #temp_Goods  from t_goods --where cGoodsNO='14001'





declare @num int 
set @num=DATEDIFF(DAY,@dBeginDate-1,@dEndDate)
if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo 
if(select object_id('tempdb..#t_SaleSheetDetail_shelf_ready')) is not null drop table #t_SaleSheetDetail_shelf_ready
if(select object_id('tempdb..#t_SaleSheetDetail_shelf')) is not null drop table #t_SaleSheetDetail_shelf
if(select object_id('tempdb..#t_SaleSheetDetail1')) is not null drop table #t_SaleSheetDetail1
if(select object_id('tempdb..#temp_goodsKuCun1')) is not null drop table #temp_goodsKuCun1
if(select object_id('tempdb..#temp_kusun')) is not null drop table #temp_kusun
if(select object_id('tempdb..#temp_goodsKuCun1_NoZero')) is not null drop table #temp_goodsKuCun1_NoZero

select cGoodsNo,cSupplierNo into  #temp_GoodsNo  from #temp_Goods
where cGoodsNo is not null
  
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL)
CREATE TABLE #temp_end   (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL) 

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime,@date_ForBgn datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='+@cWHno+''
insert into #temp_date
exec (@SQLstr)
select @date=MaxDate from #temp_date
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)
if(@date>=@dBeginDate-1)
	begin
		if (@date<@dEndDate)    
			begin
					set @date1=@date+1
					set @date2=@dEndDate
			end
		else
			begin
					set @date1='2000-01-01'
					set @date2='2000-01-01'
					set @date=@dEndDate
			end
	end
else
	begin 
		set @date1=@dBeginDate
		set @date2=@dEndDate 
	end
set @date_ForBgn=@dBeginDate-1
if @date_ForBgn>@date set @date_ForBgn=@date

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin(ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='Bgn',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 
insert into #temp_end  (ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='End',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 

set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
              a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date_ForBgn)+''' and b.cWHno='+@cWHno+'
             '
set @SQLstr1='update a
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
              a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='+@cWHno+'
            '
exec (@SQLstr+@SQLstr1)
declare @dMaxDailyDate datetime
set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1
if @dBeginDate>@dMaxDailyDate
set @dMaxDailyDate=@dBeginDate
--print  '02 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '
--+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
-----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    

 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
	 
	exec p_x_salesABC_bySupplier_chen_WH_Ref @date1,@date2,@dMaxDailyDate,@cWHno
	 
-----------------------------------------
 --------------------------------已结转   开始  
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0))-ISNULL(fMoney_Return_all,0),bAuditing=0
  into #t_SaleSheetDetail_shelf 
  from #temp_begin 
  union all
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale1,0)),
         fLastSettle=-(isnull(fMoney_Sale1_all,0)),bAuditing=1
  from #temp_begin
  union all
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0))-ISNULL(fMoney_Return_all,0),bAuditing=0
  from #temp_end
  union all
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale1,0)),
         fLastSettle=-(isnull(fMoney_Sale1_all,0)),bAuditing=1
  from #temp_end
--------------------------------未结转   开始
--                销售单                 开始    
  union all  
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing
  from  #temp_GoodsNo  a,
     --  t_SaleSheet_Day b
     --    where a.cGoodsNo=b.cGoodsNo
          #temp_SaleSheet_Day b         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @date1 and @date2) and b.cWHno=@cWHno 
  union all
  select 'X',c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0'
  from  #temp_GoodsNo  a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c
         where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @date1 and @date2)
          and c.cWHno=@cWHno
  union all   ---未日结
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing
  from  #temp_GoodsNo  a,
      -- --t_SaleSheetDetail b         where a.cGoodsNo=b.cGoodsNo
         #temp_salesheetDetail b         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @dMaxDailyDate and @date2) and b.cWHno=@cWHno 
        
---销售数量
  select a.cGoodsNo,Qty=a.Qty-b.Qty,fLastMoney=a.fLastMoney-b.fLastMoney,a.bAuditing,
         case when (isnull(a.bAuditing,0)=0) then '正价' else '特价' end as Auditing
  into #t_SaleSheetDetail1  --销售单
  from 
      (  
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney,bAuditing
         from #t_SaleSheetDetail_shelf 
         where dSaleTime between @date1 and @dEndDate or ForSign='End' 
         group by cGoodsNo,bAuditing
      ) a left join 
      (
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney,bAuditing
         from #t_SaleSheetDetail_shelf 
         where dSaleTime<@dBeginDate or ForSign='Bgn' group by cGoodsNo,bAuditing
      )b on a.cGoodsNo=b.cGoodsNo and a.bAuditing=b.bAuditing


--               销售单                 结束 

--合并  开始

      select distinct a.cGoodsNo,BeginDate=@dBeginDate,EndDate=@dEndDate,a.cSupplierNo,o.cSupName,m.Auditing,
                  xsQty=m.qty,xsMoney=m.fLastMoney
      into #temp_goodsKuCun1_NoZero from  #temp_GoodsNo  a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , t_Supplier o --on a.cSupplierNo=o.cSupNo
                             , #t_SaleSheetDetail1 m --on a.GoodsNo_Pdt=m.GoodsNo
                             where --m.qty<>0 and 
                             a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=o.cSupNo and a.cGoodsNo=m.cGoodsNo 
                              
--合并  结束
if(select object_id('tempdb..#temp_xs ')) is not null drop table #temp_xs
select BeginDate,EndDate,cSupplierNo,cSupName,Auditing,xsQty=SUM(ISNULL(xsQty,0)),xsMoney=SUM(ISNULL(xsMoney,0)) 
into #temp_xs
from #temp_goodsKuCun1_NoZero
group by BeginDate,EndDate,cSupplierNo,cSupName,Auditing

if(select object_id('tempdb..#temp_sum ')) is not null drop table #temp_sum
select BeginDate,EndDate,cSupplierNo,cSupName,Qty=SUM(ISNULL(xsQty,0)),Money=SUM(ISNULL(xsMoney,0)) 
into #temp_sum
from #temp_goodsKuCun1_NoZero
group by BeginDate,EndDate,cSupplierNo,cSupName
/*
供应商名称	排名	促销销售	促销销售占比	正常销售	正常销售占比	销售合计	日均销售
*/
if(select object_id('tempdb..#temp_xs1 ')) is not null drop table #temp_xs1
select a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,type1=a.Auditing,xs1=a.xsQty,m1=a.xsMoney,type2=b.Auditing,xs2=b.xsQty,m2=b.xsMoney 
into #temp_xs1
from #temp_xs a left join #temp_xs b
on a.cSupplierNo=b.cSupplierNo
where a.Auditing='正价' and b.Auditing='特价'

if(select object_id('tempdb..#temp_ready ')) is not null drop table #temp_ready
select identity(int,1,1) as id,a.BeginDate,a.EndDate,a.cSupName,a.cSupplierNo,a.type1,a.xs1,a.m1,
       bl1=Convert(decimal(18,2),a.m1/case when b.Money=0 then null else b.Money end *100),
       a.type2,a.xs2,a.m2,
       bl2=Convert(decimal(18,2),a.m2/case when b.Money=0 then null else b.Money end *100),
       xs_avg=Convert(decimal(18,2),b.Money/@num),
       b.Qty,b.Money
into #temp_ready
from #temp_xs1 a left join #temp_sum b
on a.cSupplierNo=b.cSupplierNo
order by b.Money desc

select * from #temp_ready


GO
