CREATE proc [dbo].[eReport008]
@date1 datetime,
@date2 datetime,
@n int
as
--declare @date1 datetime,@date2 datetime,@n int
--select @date1='2012-01-01',@date2='2012-01-30',@n='30'
/*
select count(distinct cSaleSheetno)
from t_SaleSheetDetail
where  dSaleDate between @date1 and @date2 and cVipNo is not null and fVipScore_cur>0
*/
if(select object_id('tempdb..#temp_ready')) is not null drop table #temp_ready
create table #temp_ready(cSaleSheetno varchar(64),cVipNo varchar(64),fVipScore_cur money)

insert into #temp_ready(cSaleSheetno,cVipNo,fVipScore_cur)
select distinct cSaleSheetno,cVipNo,fVipScore_cur
from t_SaleSheetDetail
where  dSaleDate=@date1 and cVipNo is not null and fVipScore_cur>0

--declare @i int
----datediff 返回跨两个指定日期的日期和时间边界数
--set @i=datediff(day,@date1,@date2)
--select @i

declare @date datetime,@d datetime
set @date=@date1

while (@date<=@date2)
begin 
	--dateadd 在向指定日期加上一段时间的基础上，返回新的 datetime 值：
	set @d=@date+1
	set @date=dateadd(day,@n,@date)

	if(@date>@date2)
	begin 
		insert into #temp_ready(cSaleSheetno,cVipNo,fVipScore_cur)
		select distinct cSaleSheetno,cVipNo,fVipScore_cur
		from t_SaleSheetDetail
		where  dSaleDate between @d and @date2 and isnull(cVipNo,'')<>'' and fVipScore_cur>0
	end
	else
	begin 
		insert into #temp_ready(cSaleSheetno,cVipNo,fVipScore_cur)
		select distinct cSaleSheetno,cVipNo,fVipScore_cur
		from t_SaleSheetDetail
		where  dSaleDate between @d and @date and isnull(cVipNo,'')<>'' and fVipScore_cur>0
	end
end 

select 时间段=convert(varchar(100),@date1,23)+'至'+convert(varchar(100),@date2,23),销售单=cSaleSheetno,会员卡=cVipNo,积分=fVipScore_cur from #temp_ready order by cVipNo
GO
