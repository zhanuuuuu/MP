--select * from t_wh_form
--select * from dbo.t_Cost_distribute
/*
  declare @dDate datetime
  set @dDate='2009-11-20'
  FIFO先进先出成本表（库龄、失效期、买完？）
drop table #tmpCostGoodsList
select cGoodsNo into #tmpCostGoodsList from t_goods where cgoodsNo='110276'
select * from #tmpCostGoodsList

create table #tmpCostSupList (cSupNo varchar(32))  

create table #tmpCostTypeList (cTypeNo varchar(32)) 
insert into #tmpCostTypeList(cTypeNo)
select cGoodsTypeno from t_GoodsType --- where cGoodsTypeno like '2200201%'

exec p_FIFOCWhStorageDetail_chen_MultiSup '2015-5-1','2015-5-18',1,'01',0

*/

create proc [dbo].[p_FIFOCWhStorageDetail_chen_MultiSup_TermID]
@dDate1 datetime,
@dDate2 datetime,
@bListOtherSupplier bit,--是否显示一品多商之相关供应商
@cWhNo varchar(32),
@Type int, --0:按商品列表查，1：商品类别 2：供应商
@cTermID varchar(32) 
as
--declare @dDate1 datetime
--declare @dDate2 datetime
--declare @Type int
--set @dDate1='2008-11-24'
--set @dDate2='2009-11-24'
--set @Type=0
if (select object_id('tempdb..#FIFOCWhDate_chen'))is not null
drop table #FIFOCWhDate_chen
if (select object_id('tempdb..#tmp_Date1In'))is not null
drop table #tmp_Date1In
if (select object_id('tempdb..#tmp_Date1Out'))is not null
drop table #tmp_Date1Out
if (select object_id('tempdb..#tmp_Date2In'))is not null
drop table #tmp_Date2In
if (select object_id('tempdb..#tmp_Date2Out'))is not null
drop table #tmp_Date2Out
if (select object_id('tempdb..#tmp_Date2In1'))is not null
drop table #tmp_Date2In1
if (select object_id('tempdb..#tmp_PeriodJxcOut'))is not null
drop table #tmp_PeriodJxcOut

if (select object_id('tempdb..#tmpSysInit'))is not null
drop table #tmpSysInit
if (select object_id('tempdb..#tmpSysInit1'))is not null
drop table #tmpSysInit1
if (select object_id('tempdb..#tmpSysInit2'))is not null
drop table #tmpSysInit2


create table #FIFOCWhDate_chen
(
  cGoodsNo varchar(32),
  cGoodsName varchar(100),
  date1 datetime,
  date2 datetime,
  fQty_in_bgn money default(0),     --起初接收数量
  fMoney_in_bgn money default(0),   --起初接收金额
  fQty_Out_bgn money default(0),    --起初发出数量
  fMoney_Out_bgn money default(0),  --起初发出金额
  fSheetMoney_Out_bgn money default(0),--起初发出单据金额
  fQty_bgn money default(0),        --起初库存数量
  fMoney_bgn money default(0),      --起初库存金额
  fQty_in_period money default(0),  --起间接收数量
  fMoney_in_period money default(0),--起间接收金额
  fQty_Out_period money default(0), --起间发出数量
  fMoney_Out_period money default(0),--起间发出金额
  fSheetMoney_Out_period money default(0),--起j间发出单据金额
  
  fQty_period money default(0),     --起间数量（temp）
  fMoney_period money default(0),   --起间金额（temp）
  cSupNO varchar(32),
  cSupName varchar(64),
  cUnit varchar(32),
  cSpec varchar(32),
  fQty money default(0),           --期末库存
  fMOney money default(0),         --期末库存数量
  cGoodsTypeno varchar(32),
  cGoodsTypeName varchar(64),
 --以下是期间进销存
  fQty_jxc_in money default(0),   --入库
  fMoney_jxc_in money default(0),
  fQty_jxc_out money default(0),  --出库
  fMoney_jxc_out money default(0),
  fSheetMoney_out money default(0),
  fQty_jxc_rbd money default(0),  --返厂
  fMoney_jxc_rbd money default(0),
  fSheetMoney_rbd money default(0),
  fQty_jxc_Return money default(0),   --客退
  fMoney_jxc_Return money default(0),
  fQty_jxc_Tfr money default(0),      --调拨出库
  fMoney_jxc_Tfr money default(0),
  fSheetMoney_Tfr money default(0),

  fQty_jxc_TfrIn money default(0),      --调拨入库
  fMoney_jxc_TfrIn money default(0),
  fSheetMoney_TfrIn money default(0),

  fQty_jxc_Lost money default(0),     --报损
  fMoney_jxc_Lost money default(0),
  fSheetMoney_Lost money default(0),
  fQty_jxc_Effusion money default(0), --报溢
  fMoney_jxc_Effusion money default(0),
  fQty_jxc_Pack money default(0),     --原料出库
  fMoney_jxc_Pack money default(0),
  fSheetMoney_Pack money default(0),
  fQty_jxc_Deliver money default(0),     --成品入库
  fMoney_jxc_Deliver money default(0),  
  fQty_jxc_sale money default(0),     --销售
  fMoney_jxc_sale money default(0),
  fSheetMoney_sale money default(0),  
  fQty_jxc_PdIn money default(0),     --盘点溢出
  fMoney_jxc_PdIn money default(0), 
  fQty_jxc_PdOut money default(0),     --盘点报损
  fMoney_jxc_PdOut money default(0),
  fSheetMoney_pdOut money default(0),

  fQty_jxc_PosIn money default(0),     --Pos销售退货入库数量
  fMoney_jxc_PosIn money default(0),
  fQtyIn_init money default(0),      --16系统初始化接收数量  
  fQtyOut_init money default(0),      --16系统初始化接收数量  
  fMoney_init money default(0),     --16系统初始化金额
  fMoneySale_init money default(0),--16系统初始化销售金额
  fCurNormalPrice money default(0)--按零售价核算
 ) 

if (select object_id('tempdb..#tmpGoodsSupplierno'))is not null
drop table #tmpGoodsSupplierno

select distinct a.cGoodsNo,a.cSupplierNo,cSupplier=null
into #tmpGoodsSupplierno
from
(
	select cGoodsNo,cSupplierNo=cSupNo
	from t_goods
	union
	select distinct cGoodsNo,cSupplierNo
	from T_WH_Form_Log --where dDateTime<=@dDate2
) a	

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
create table #tmpCostGoodsList(cGoodsNo varchar(32))

if (select object_id('tempdb..#tmpCostTypeList'))is not null drop table #tmpCostTypeList
create table #tmpCostTypeList(cTypeNo varchar(32))

if (select object_id('tempdb..#tmpCostSupList'))is not null drop table #tmpCostSupList
create table #tmpCostSupList(cSupNo varchar(32))

if ( @Type=0 )
begin
    exec('
	insert into #tmpCostGoodsList([cGoodsNo])
	select distinct [cGoodsNo]  
	from #tmpCostGoodsList'+@cTermID+'
	')
end else if(@Type=1)
begin
   exec('
	insert into #tmpCostTypeList([cTypeNo])
	select distinct [cTypeNo]  
	from #tmpCostTypeList'+@cTermID+'
	')
end else
begin
  exec('
	insert into #tmpCostSupList([cSupNo])
	select distinct [cSupNo]  
	from #tmpCostSupList'+@cTermID+'
	') 
end

---  t_supplier
insert into #FIFOCWhDate_chen
(
  cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,date1,date2
)

select x.cGoodsNo,x.cGoodsName,x.cUnit,x.cSpec,x.cSupNO,x.cSupName,x.cGoodsTypeno,x.cGoodsTypeName,@dDate1,@dDate2
from (select a.cGoodsNo,b.cGoodsName,b.cUnit,b.cSpec,cSupNO=a.cSupplierNo,cSupName=a.cSupplier,b.cGoodsTypeno,b.cGoodsTypename,b.bstorage 
     from #tmpGoodsSupplierno a,t_goods b where a.cGoodsNo=b.cGoodsNo) x
where 
isnull(bstorage,0)=1
and(
     ( 
--        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)

        ( @Type=0 )
				and x.cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log 
				 where cGoodsNo in (select distinct cGoodsNo from #tmpCostGoodsList)
				)
 
     )
      or
     ( 
--        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
        ( @Type=1 )
				and x.cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log 
				 where cGoodsNo in 
				 (select distinct b.cGoodsNo from #tmpCostTypeList a,t_Goods b where a.cTypeNo=b.cGoodsTypeNO )
				)
     )
     or
     ( 
        --(@Type=2)and cSupNo in(select distinct cSupNo from #tmpCostSupList)
        (@Type=2)
            /*
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				)
			*/
				--and x.cGoodsNo in 
				--(select cGoodsNo from t_Goods 
				-- where cSupNo in (select distinct cSupNo from #tmpCostSupList)
				-- )
				and
				x.cGoodsNo in
				(select distinct cGoodsNo from T_WH_Form_Log 
				 where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				 union
				 select cGoodsNo from t_Goods 
				 where cSupNo in (select distinct cSupNo from #tmpCostSupList)				 
				)
				
     )
)


/*
select a.cGoodsNo,fQty_in=sum(isnull(b.fQty_in,0)),fMoney_In=sum(isnull(b.fMoney_In,0))
into #tmp_Date1In
from #FIFOCWhDate_chen a left join t_wh_form  b
on a.cGoodsNo=b.cGoodsNo and b.dDateTime<@dDate1
where b.cWhNo=@cWhNo
group by a.cGoodsNo 
*/
--print '1:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

select  cGoodsNo,cSupNO
into #FIFOCWhDate_chen_SingleMainSupplier
from #FIFOCWhDate_chen
----------------------

select a.cGoodsNo,b.cSupplierNo 
into #temp_MultiSupplier
from  #FIFOCWhDate_chen a left join (
    select distinct a.cGoodsNo,b.cSupplierNo,b.cWhNo   from wh_InWarehouseDetail a
   right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
   where b.dDate<=@dDate2
)  b
on a.cGoodsNo=b.cGoodsNo 
where b.cWhNo=@cWhNo and a.cSupNO=b.cSupplierNo
	
	

--print '2:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())
 
select distinct a.cGoodsNo,a.cSupplierNo,cGoodsName=cast(null as varchar(64)),
cSupName=cast(null as varchar(64)),date1=@dDate1,date2=@dDate2--主供应商外的其它供应商
into #temp_otherSupplier
from
(
	select distinct cGoodsNo,cSupplierNo
	from #temp_MultiSupplier
) a left join #FIFOCWhDate_chen b on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNO
where b.cSupNO is null


update a
set a.cSupName=b.cSupName
from #temp_otherSupplier a,t_Supplier b
where a.cSupplierNo=b.cSupNo

update a
set a.cGoodsName=b.cGoodsName--,a.cUnit=b.cUnit,a.cSpec=b.cSpec
from #temp_otherSupplier a,t_Goods b
where a.cGoodsNo=b.cGoodsNo



insert into #FIFOCWhDate_chen(cGoodsNo,cGoodsName,cSupNO,cSupName,date1,date2)
select cGoodsNo,cGoodsName,cSupplierNo,cSupName,@dDate1,@dDate2  --插入主供应商外的其它供应商
from #temp_otherSupplier



delete from #FIFOCWhDate_chen
where @Type=2 and cSupNO not in (select distinct cSupNo from #tmpCostSupList)


--print '3:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())



--起初出库数量
/*--       只能处理一品一商
select a.cGoodsNo,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
into #tmp_Date1Out
from #FIFOCWhDate_chen a left join t_Cost_distribute  b
on a.cGoodsNo=b.cGoodsNo and b.dDate_Sheet<@dDate1 and isnull(b.bDone,0)=0
where b.cWhNo=@cWhNo
group by a.cGoodsNo 
*/

--select a.cGoodsNo,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
---------------
---------------
--------------
---------------
---------------------
declare  @Zt varchar(16)  --- 方便修改期初数量

declare @MaxCost datetime  --- 获取最大的月结日期
--select @MaxCost=MAX(date2) from posmanagement_Month.dbo.t_GoodsMonth
select @MaxCost=MAX(date2) from t_MaxMonthDate

declare @maxWhDate datetime,@PosName varchar(32)
select @PosName=Pos_WH_Form from t_WareHouse

if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(dDateEnd),''2000-01-01'') from '+@PosName+'.dbo.t_WH_Form_Log_Month  with (nolock) ')
set @maxWhDate=(select dDate from #temp_maxWhdDate)

------从月结表
if (select OBJECT_ID('tempdb..#tmp_Date1In'))is not null drop table #tmp_Date1In
create table #tmp_Date1In(
  cGoodsNo varchar(32),cSupplierNo varchar(32),fQty_in money,fMoney_In money,fQty_Left money,fMoney_Left money
)

if (select OBJECT_ID('tempdb..#temp_distribute'))is not null drop table #temp_distribute
create table #temp_distribute(cGoodsNo varchar(32),fQty_Cost money,fMoney_Cost money,
fMoney_sale money,cSupplierNo varchar(32),cSupplier varchar(64),
fQty_end money,fMoney_end money
)

-------期间入库
if (select OBJECT_ID('tempdb..#tmp_Date2In1'))is not null drop table #tmp_Date2In1
create table #tmp_Date2In1(
  cGoodsNo varchar(32),cSupplierNo varchar(32),fQty_in money,fMoney_In money,fQty_Left money,fmoney_Left money,fMoney_TrfIn money,iAttribute int,
   入库数量1 money,报溢数量1 money,退货入库数量1 money,调拨入库数量1  money,成品入库数量1 money,
		 入库金额1 money,报溢金额1 money,退货入库金额1 money,调拨入库金额1 money,成品入库金额1 money
		
)

--期间出库数量
if (select object_id('tempdb..#tmp_PeriodOut_List'))is not null
drop table #tmp_PeriodOut_List
create table #tmp_PeriodOut_List(cGoodsNo varchar(32),cSupplierNo varchar(32),
iAttribute int,bdone bit,fQty_Out money,fMoney_Out money,fSheetMoney money,
出库数量0 money,报损数量0 money,返厂数量0 money,调拨出库数量0 money,原料出库数量0 money,
出库金额0 money,报损金额0 money,返厂金额0 money,调拨出库金额0 money,原料出库金额0 money,
fmoney_SalCost money,fmoney_outCost money,fmoney_bsCost money,fmoney_rbdCost money,fmoney_dbout money,fmoney_ylout money,
销售数量0 money, 销售金额0 money,
)


if @maxWhDate<@dDate1
begin
    declare @maxWhDate1 varchar(32)
    set @maxWhDate1=dbo.getdaystr(@maxWhDate)
    declare @d1_1 varchar(32)
    set @d1_1=dbo.getdaystr(@maxWhDate+1)
    
      declare @d11_1 varchar(32)
      set @d11_1=dbo.getdaystr(@dDate1-1)
    
     --  select @maxWhDate1,@d11_1,@d1_1,@dDate2,@dDate1
    
      exec('
       select a.cGoodsNo,fQty_in=isnull(入库数量1,0)+isnull(报溢数量1,0)+isnull(退货入库数量1,0)+isnull(调拨入库数量1,0)+isnull(成品入库数量1,0)
	   ,fMoney_In=isnull(入库金额1,0)+isnull(报溢金额1,0)+isnull(退货入库金额1,0)+isnull(调拨入库金额1,0)+isnull(成品入库金额1,0),
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   ,b.cSupplierNo,fQty_Left=0,fMoney_Left=0
		into #temp_Date1In_MultiSupplier
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_Month  b
	   on a.cGoodsNo=b.cGoodsNo and b.dDateEnd='''+@maxWhDate1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
	   b.cSupplierNo,b.fQty_Left,b.fMoney_Left 
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
       b.cSupplierNo,0,0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@d1_1+''' and '''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20
	   ------------获取时间段的情况
	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,fMoney_Out=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)),
	   b.cSupplierNo,0,0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@maxWhDate1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   

	   ------ 期初入库
        insert into #tmp_Date1In(cGoodsNo,cSupplierNo,fQty_in,fMoney_In)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0))
		from #temp_Date1In_MultiSupplier
		group by cGoodsNo,cSupplierNo
		
		
		--起初出库数量
 
 
		insert into #temp_distribute(cGoodsNo,cSupplierNo,fQty_Cost,fMoney_Cost,fMoney_sale)
		select x.cGoodsNo,x.cSupplierNo,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale 
		from 
		(select b.cGoodsNo,cSupplierNo,fQty_Cost=sum(isnull(fQty_in,0))-sum(fQty_Left),
		fMoney_Cost=SUM(fMoney_In)-sum(fMoney_Left),fMoney_sale=SUM(fMoney_Out)
		 from	#temp_Date1In_MultiSupplier b
		 group by   b.cGoodsNo,cSupplierNo
		) x

       ---------------获取期间-------
       
	   select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out,fQty_Out
	  ,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
	     fmoney_SalCost=b.销售数量0*b.fPrice_In,b.销售数量0,b.销售金额0,
	     b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
	     ,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
	     b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
	     ,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   into #temp_Date1In_MultiSupplier_1
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,0,0,
	   fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
	    fmoney_SalCost=b.销售数量0*b.fPrice_In,b.销售数量0,b.销售金额0,
	     b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
	     ,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
	     b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
	     ,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	   	   union all
	   select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	   fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0),
	    fmoney_SalCost=b.销售数量0*b.fPrice_In,b.销售数量0,b.销售金额0,
	     b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
	     ,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
	     b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
	     ,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute=10 
	   union all
	   select b.dDateTime,a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	  ,b.cSupplierNo,0,0,
	  fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)),
	    fmoney_SalCost=-b.销售数量0*b.fPrice_In,-b.销售数量0,-b.销售金额0,
	   --0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	    -b.入库数量1,-b.报溢数量1,-b.退货入库数量1,-b.调拨入库数量1,-b.成品入库数量1
	     ,-b.出库数量0,-b.报损数量0,-b.返厂数量0,-b.调拨出库数量0,-b.原料出库数量0,
	     -b.入库金额1,-b.报溢金额1,-b.退货入库金额1,-b.调拨入库金额1,-b.成品入库金额1
	     ,-b.出库金额0,-b.报损金额0,-b.返厂金额0,-b.调拨出库金额0,-b.原料出库金额0,
	     fmoney_outCost=-b.出库数量0*b.fPrice_In,fmoney_bsCost=-b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=-b.返厂数量0*b.fPrice_In,fmoney_dbout=-b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=-b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select b.dDateTime,a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	  ,b.cSupplierNo,0,0,
	  fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)),
	   fmoney_SalCost=-b.销售数量0*b.fPrice_In,-b.销售数量0,-b.销售金额0,
	   --0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	   	    -b.入库数量1,-b.报溢数量1,-b.退货入库数量1,-b.调拨入库数量1,-b.成品入库数量1
	     ,-b.出库数量0,-b.报损数量0,-b.返厂数量0,-b.调拨出库数量0,-b.原料出库数量0,
	     -b.入库金额1,-b.报溢金额1,-b.退货入库金额1,-b.调拨入库金额1,-b.成品入库金额1
	     ,-b.出库金额0,-b.报损金额0,-b.返厂金额0,-b.调拨出库金额0,-b.原料出库金额0,
	     fmoney_outCost=-b.出库数量0*b.fPrice_In,fmoney_bsCost=-b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=-b.返厂数量0*b.fPrice_In,fmoney_dbout=-b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=-b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d11_1+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	   
	   
        --- 期间入库
        /*
	    insert into #tmp_Date2In1(cGoodsNo,cSupplierNo,fQty_in,fMoney_In,
	    入库数量1,报溢数量1,退货入库数量1,调拨入库数量1,成品入库数量1,
	    入库金额1,报溢金额1,退货入库金额1,调拨入库金额1,成品入库金额1)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0)),
		sum(入库数量1),sum(报溢数量1),sum(退货入库数量1),
	    sum(调拨入库数量1),sum(成品入库数量1),sum(入库金额1),sum(报溢金额1),
	    sum(退货入库金额1),sum(调拨入库金额1),sum(成品入库金额1)
		from #temp_Date1In_MultiSupplier_1
		group by cGoodsNo,cSupplierNo
		*/
		
		 insert into #tmp_Date2In1(cGoodsNo,cSupplierNo,fQty_in,fMoney_In,fQty_Left,fmoney_Left)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0)),sum(fQty_Left),sum(fmoney_Left)
		from #temp_Date1In_MultiSupplier_1
		group by cGoodsNo,cSupplierNo
		
		update a set a.入库数量1=b.入库数量1,a.报溢数量1=b.报溢数量1,a.退货入库数量1=b.退货入库数量1,
	    a.调拨入库数量1=b.调拨入库数量1,a.成品入库数量1=b.成品入库数量1,
	    a.入库金额1=b.入库金额1,a.报溢金额1=b.报溢金额1,a.退货入库金额1=b.退货入库金额1,
	    a.调拨入库金额1=b.调拨入库金额1,a.成品入库金额1=b.成品入库金额1
		from #tmp_Date2In1 a,(select cGoodsNo,cSupplierNo,
			入库数量1=sum(入库数量1),报溢数量1=sum(报溢数量1),退货入库数量1=sum(退货入库数量1),
			调拨入库数量1=sum(调拨入库数量1),成品入库数量1=sum(成品入库数量1),入库金额1=sum(入库金额1),
			报溢金额1=sum(报溢金额1),退货入库金额1=sum(退货入库金额1),调拨入库金额1=sum(调拨入库金额1),
			成品入库金额1=sum(成品入库金额1)
			from #temp_Date1In_MultiSupplier_1
			where dDateTime  between '''+@dDate1+''' and '''+@dDate2+'''
			group by cGoodsNo,cSupplierNo
		) b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
		
		
		
		  --- 期间发出
		  insert into #tmp_PeriodOut_List(cGoodsNo,cSupplierNo,fQty_Out,fMoney_Out,fSheetMoney,
		  出库数量0,报损数量0,返厂数量0,调拨出库数量0,原料出库数量0,出库金额0,报损金额0,返厂金额0,调拨出库金额0,原料出库金额0,
			fmoney_SalCost,销售数量0, 销售金额0,fmoney_outCost,fmoney_bsCost,fmoney_rbdCost,fmoney_dbout,fmoney_ylout)
		  select x.cGoodsNo,x.cSupplierNo,sum(x.fQty_Out),sum(fMoney_Out),fSheetMoney=sum(x.fMoney_Outsal),
		  sum(出库数量0),sum(报损数量0),sum(返厂数量0),sum(调拨出库数量0),sum(原料出库数量0),
		  sum(出库金额0),sum(报损金额0),sum(返厂金额0),sum(调拨出库金额0),sum(原料出库金额0),
		  sum(fmoney_SalCost),sum(销售数量0), sum(销售金额0),
		  sum(fmoney_outCost),sum(fmoney_bsCost),sum(fmoney_rbdCost),sum(fmoney_dbout),sum(fmoney_ylout)
		  from #temp_Date1In_MultiSupplier_1 x
		  group by x.cGoodsNo,x.cSupplierNo
		  
		  ')
end else
begin
      declare @d1 datetime
      set @d1=CAST((cast(YEAR(@dDate1) as varchar(16))+'-'+cast(MONTH(@dDate1) as varchar(16))+'-01') AS DATETIME)
      declare @d1_bgn varchar(32)
      set @d1_bgn=dbo.getDayStr(DATEADD(MONTH,-1,@d1))
      
   
      
      declare @d1_str varchar(32)
      set @d1_str=dbo.getDayStr(@d1-1)
      
      declare @dd1_str varchar(32)
      set @dd1_str=dbo.getDayStr(@dDate1-1)
      
      
      
      exec('
       select a.cGoodsNo,fQty_in=isnull(入库数量1,0)+isnull(报溢数量1,0)+isnull(退货入库数量1,0)+isnull(调拨入库数量1,0)+isnull(成品入库数量1,0)
	    ,fMoney_In=isnull(入库金额1,0)+isnull(报溢金额1,0)+isnull(退货入库金额1,0)+isnull(调拨入库金额1,0)+isnull(成品入库金额1,0)
	   ,b.cSupplierNo ,fQty_Left=0,fMoney_Left=0,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	   into #temp_Date1In_MultiSupplier0
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_Month  b
	   on a.cGoodsNo=b.cGoodsNo and 
	   b.dDateBgn='''+@d1_bgn+''' 
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,b.cSupplierNo ,b.fQty_Left,b.fMoney_Left ,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select a.cGoodsNo,fQty_in
	   ,fMoney_In,b.cSupplierNo ,0,0,
	   fMoney_Out=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@d1+''' and '''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20
	   	   union all
	   select a.cGoodsNo,-fQty_in
	   ,-fMoney_In,b.cSupplierNo ,0,0 ,
	   fMoney_Out=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@d1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   
	
        insert into #tmp_Date1In(cGoodsNo,cSupplierNo,fQty_in,fMoney_In)
		select x.cGoodsNo,x.cSupplierNo,fQty_in=sum(isnull(x.fQty_in,0)),fMoney_In=sum(isnull(x.fMoney_In,0))
		--into #tmp_Date1In
		from #temp_Date1In_MultiSupplier0 x
		group by x.cGoodsNo,x.cSupplierNo
		
		
	 --起初出库数量 
 
		insert into #temp_distribute(cGoodsNo,cSupplierNo,fQty_Cost,fMoney_Cost,fMoney_sale)
		select x.cGoodsNo,x.cSupplierNo,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale 
		from 
		(select b.cGoodsNo,cSupplierNo,fQty_Cost=sum(isnull(fQty_in,0))-sum(fQty_Left),
		fMoney_Cost=SUM(fMoney_In)-sum(fMoney_Left),fMoney_sale=SUM(fMoney_Out)
		 from	#temp_Date1In_MultiSupplier0 b
		   group by  b.cGoodsNo,cSupplierNo
		) x
 
		---------------获取期间-------

       select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In,fMoney_Out,fQty_Out
	   ,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	   fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
        ,fmoney_SalCost=b.销售数量0*b.fPrice_In,
	    b.销售数量0,b.销售金额0,
	    b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
		,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
		b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
		,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   into #temp_Date1In_MultiSupplier0_1
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
	   union all
	   select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,0,0,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
       ,fmoney_SalCost=b.销售数量0*b.fPrice_In,
	    b.销售数量0,b.销售金额0,
	    b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
		,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
		b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
		,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	   	   union all
	   select b.dDateTime,a.cGoodsNo,fQty_in
	   ,fMoney_In, fMoney_Out,fQty_Out,b.cSupplierNo,b.fQty_Left,b.fMoney_Left,
	  fMoney_Outsal=isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0)
       ,fmoney_SalCost=b.销售数量0*b.fPrice_In,
	    b.销售数量0,b.销售金额0,
	    b.入库数量1,b.报溢数量1,b.退货入库数量1,b.调拨入库数量1,b.成品入库数量1
		,b.出库数量0,b.报损数量0,b.返厂数量0,b.调拨出库数量0,b.原料出库数量0,
		b.入库金额1,b.报溢金额1,b.退货入库金额1,b.调拨入库金额1,b.成品入库金额1
		,b.出库金额0,b.报损金额0,b.返厂金额0,b.调拨出库金额0,b.原料出库金额0,
	     fmoney_outCost=b.出库数量0*b.fPrice_In,fmoney_bsCost=b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=b.返厂数量0*b.fPrice_In,fmoney_dbout=b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期 between '''+@dDate1+''' and '''+@dDate2+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute=10
	   union all
	    select b.dDateTime,a.cGoodsNo,-fQty_in
	   ,-fMoney_In,-fMoney_Out,-fQty_Out
	   ,b.cSupplierNo,0,0,
	   fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	   ,fmoney_SalCost=-b.销售数量0*b.fPrice_In,-b.销售数量0,-b.销售金额0,
	   -- 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	   	    -b.入库数量1,-b.报溢数量1,-b.退货入库数量1,-b.调拨入库数量1,-b.成品入库数量1
	     ,-b.出库数量0,-b.报损数量0,-b.返厂数量0,-b.调拨出库数量0,-b.原料出库数量0,
	     -b.入库金额1,-b.报溢金额1,-b.退货入库金额1,-b.调拨入库金额1,-b.成品入库金额1
	     ,-b.出库金额0,-b.报损金额0,-b.返厂金额0,-b.调拨出库金额0,-b.原料出库金额0,
	     fmoney_outCost=-b.出库数量0*b.fPrice_In,fmoney_bsCost=-b.报损数量0*b.fPrice_In,
	     fmoney_rbdCost=-b.返厂数量0*b.fPrice_In,fmoney_dbout=-b.调拨出库金额0*b.fPrice_In,
	     fmoney_ylout=-b.原料出库金额0*b.fPrice_In
	   from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_1  b
	   on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dd1_str+'''
	   where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo
    --  union all
	   -- select b.dDateTime,a.cGoodsNo,-fQty_in
	   --,-fMoney_In,-fMoney_Out,-fQty_Out
	   --,b.cSupplierNo,0,0,
	   --fMoney_Outsal=-(isnull(出库金额0,0)+isnull(报损金额0,0)+isnull(返厂金额0,0)+isnull(调拨出库金额0,0)+isnull(原料出库金额0,0)+isnull(销售金额0,0))
	   -- ,fmoney_SalCost=-b.销售数量0*b.fPrice_In,-b.销售数量0,-b.销售金额0,
	   -- 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	   --from  #FIFOCWhDate_chen a left join '+@PosName+'.dbo.t_WH_Form_Log_0  b
	   --on a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dd1_str+'''
	   --where b.cWhNo='+@cWhNo+' and a.cSupNO=b.cSupplierNo and b.iAttribute<>20 
	   
            --- 期间入库
      
		 insert into #tmp_Date2In1(cGoodsNo,cSupplierNo,fQty_in,fMoney_In,fQty_Left,fmoney_Left)
		select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_In=sum(isnull(fMoney_In,0)),sum(fQty_Left),sum(fmoney_Left)
		from #temp_Date1In_MultiSupplier0_1
		group by cGoodsNo,cSupplierNo
		
		update a set a.入库数量1=b.入库数量1,a.报溢数量1=b.报溢数量1,a.退货入库数量1=b.退货入库数量1,
	    a.调拨入库数量1=b.调拨入库数量1,a.成品入库数量1=b.成品入库数量1,
	    a.入库金额1=b.入库金额1,a.报溢金额1=b.报溢金额1,a.退货入库金额1=b.退货入库金额1,
	    a.调拨入库金额1=b.调拨入库金额1,a.成品入库金额1=b.成品入库金额1
		from #tmp_Date2In1 a,(select cGoodsNo,cSupplierNo,
			入库数量1=sum(入库数量1),报溢数量1=sum(报溢数量1),退货入库数量1=sum(退货入库数量1),
			调拨入库数量1=sum(调拨入库数量1),成品入库数量1=sum(成品入库数量1),入库金额1=sum(入库金额1),
			报溢金额1=sum(报溢金额1),退货入库金额1=sum(退货入库金额1),调拨入库金额1=sum(调拨入库金额1),
			成品入库金额1=sum(成品入库金额1)
			from #temp_Date1In_MultiSupplier0_1
			where dDateTime  between '''+@dDate1+''' and '''+@dDate2+'''
			group by cGoodsNo,cSupplierNo
		) b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
		
		
		--- 期间发出
		/*
		insert into #tmp_PeriodOut_List(cGoodsNo,cSupplierNo,fQty_Out,fMoney_Out,fSheetMoney,
		出库数量0,报损数量0,返厂数量0,调拨出库数量0,原料出库数量0,
		出库金额0,报损金额0,返厂金额0,调拨出库金额0,原料出库金额0,
		fmoney_SalCost,销售数量0, 销售金额0,fmoney_outCost,fmoney_bsCost,fmoney_rbdCost,fmoney_dbout,fmoney_ylout)
		select x.cGoodsNo,x.cSupplierNo,sum(x.fQty_Out),sum(fMoney_Out),fSheetMoney=sum(x.fMoney_Outsal),
		sum(出库数量0),sum(报损数量0),sum(返厂数量0),sum(调拨出库数量0),sum(原料出库数量0),
		sum(出库金额0),sum(报损金额0),sum(返厂金额0),sum(调拨出库金额0),sum(原料出库金额0),
		sum(fmoney_SalCost),
		sum(销售数量0), sum(销售金额0),sum(fmoney_outCost),sum(fmoney_bsCost),sum(fmoney_rbdCost),sum(fmoney_dbout),sum(fmoney_ylout)
		from #temp_Date1In_MultiSupplier0_1 x
		group by x.cGoodsNo,x.cSupplierNo
		
		*/
		insert into #tmp_PeriodOut_List(cGoodsNo,cSupplierNo,fQty_Out,fMoney_Out,fSheetMoney,fmoney_SalCost,销售数量0, 销售金额0)
		select x.cGoodsNo,x.cSupplierNo,sum(x.fQty_Out),sum(fMoney_Out),fSheetMoney=sum(x.fMoney_Outsal),sum(fmoney_SalCost),
		sum(销售数量0), sum(销售金额0)
		from #temp_Date1In_MultiSupplier0_1 x
		group by x.cGoodsNo,x.cSupplierNo
		
		update a
		set a.出库数量0=b.出库数量0,a.报损数量0=b.报损数量0,a.返厂数量0=b.返厂数量0,a.调拨出库数量0=b.调拨出库数量0,
		a.原料出库数量0=b.原料出库数量0,
		a.出库金额0=b.出库金额0,a.报损金额0=b.报损金额0,a.返厂金额0=b.返厂金额0,a.调拨出库金额0=b.调拨出库金额0,a.原料出库金额0=b.原料出库金额0,
		a.fmoney_outCost=b.fmoney_outCost,a.fmoney_bsCost=b.fmoney_bsCost,
		a.fmoney_rbdCost=b.fmoney_rbdCost,a.fmoney_dbout=b.fmoney_dbout,a.fmoney_ylout=b.fmoney_ylout		
		from #tmp_PeriodOut_List a,
			(select x.cGoodsNo,x.cSupplierNo,
			出库数量0=sum(出库数量0),报损数量0=sum(报损数量0),返厂数量0=sum(返厂数量0),调拨出库数量0=sum(调拨出库数量0),
			原料出库数量0=sum(原料出库数量0),
			出库金额0=sum(出库金额0),报损金额0=sum(报损金额0),返厂金额0=sum(返厂金额0),调拨出库金额0=sum(调拨出库金额0),
			原料出库金额0=sum(原料出库金额0),
			fmoney_outCost=sum(fmoney_outCost),fmoney_bsCost=sum(fmoney_bsCost),fmoney_rbdCost=sum(fmoney_rbdCost),
			fmoney_dbout=sum(fmoney_dbout),fmoney_ylout=sum(fmoney_ylout)
			from #temp_Date1In_MultiSupplier0_1 x
			where dDateTime  between '''+@dDate1+''' and '''+@dDate2+''' 
			group by x.cGoodsNo,x.cSupplierNo
		) b
        where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
        
		')
end


 --select * from #tmp_PeriodOut_List

select cGoodsNo,cSupplierNo,cSupplier,fQty_Out=fQty_Cost, fMoney_Out=fMoney_Cost,fSheetMoney=fMoney_sale,fQty_end,fMoney_end
into #tmp_Date1Out_List 
from #temp_distribute


select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0)),
fQty=SUM(ISNULL(fQty_end,0)),fMoney=SUM(ISNULL(fMoney_end,0))
into #tmp_Date1Out
from #tmp_Date1Out_List
group by cGoodsNo,cSupplierNo
 
 --select * into ##FIFOCWhDate_chen_new from #FIFOCWhDate_chen
 
 
update a
set a.fQty_in_bgn=isnull(b.fQty_in,0),a.fMoney_in_bgn=isnull(b.fMoney_In,0)
from #FIFOCWhDate_chen a,#tmp_Date1In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 
--起初入库数量


update a
set a.fQty_Out_bgn=isnull(b.fQty_Out,0),a.fMoney_Out_bgn=isnull(b.fMoney_Out,0),
fSheetMoney_Out_bgn=isnull(b.fSheetMoney,0),
a.fQty_bgn=b.fQty,a.fMoney_bgn=b.fMoney
---起初入库数量
--,fQty_in_bgn=ISNULL(b.fQty_Out,0)+b.fQty,
--fMoney_in_bgn=ISNULL(b.fMoney_Out,0)+ISNULL(b.fMoney,0)
from #FIFOCWhDate_chen a,#tmp_Date1Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

----------------
-----------------
---------------
-------------------
--print '4:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())
 
 
--期间接收数量
/*
select b.cGoodsNo,b.cSupplierNo,b.iAttribute,fQty_in=sum(isnull(b.fQty_in,0)),
fMoney_In=sum(isnull(b.fMoney_In,0)),fMoney_TrfIn=sum(isnull(b.fQty_in*b.fPrice_Tran,0)),b.dDateTime,b.iLineNo
into #tmp_PeriodJxcIn
from t_wh_form  b  
where b.dDateTime between @dDate1 and @dDate2 and isnull(b.fQty_in,0)<>0
and b.iAttribute is not null
and b.cWhNo=@cWhNo and b.cGoodsNo in (select cGoodsNo from #FIFOCWhDate_chen_SingleMainSupplier)
group by b.cGoodsNo,b.cSupplierNo,b.iAttribute,b.dDateTime,b.iLineNo
*/
---------------------------------------
------------------------------
select b.cGoodsNo,b.cSupplierNo,b.iAttribute,fQty_in=sum(isnull(b.fQty_in,0)),
fMoney_In=sum(isnull(b.fMoney_In,0)),fMoney_TrfIn=sum(isnull(fMoney_TrfIn,0)),
		入库数量1=sum(入库数量1),报溢数量1=sum(报溢数量1),退货入库数量1=sum(退货入库数量1),
	    调拨入库数量1=sum(调拨入库数量1),成品入库数量1=sum(成品入库数量1),入库金额1=sum(入库金额1),
	    报溢金额1=sum(报溢金额1),退货入库金额1=sum(退货入库金额1),调拨入库金额1=sum(调拨入库金额1),成品入库金额1=sum(成品入库金额1),
	    fQty_Left=SUM(fQty_Left),fmoney_Left=SUM(fmoney_Left)
into #tmp_PeriodJxcIn1
from #tmp_Date2In1  b  
group by b.cGoodsNo,b.cSupplierNo,b.iAttribute
--print '5:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())
 

select cGoodsNo,cSupplierNo,iAttribute,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
,出库数量0=sum(出库数量0),报损数量0=sum(报损数量0),返厂数量0=sum(返厂数量0),调拨出库数量0=sum(调拨出库数量0),原料出库数量0=sum(原料出库数量0),
出库金额0=sum(出库金额0),报损金额0=sum(报损金额0),返厂金额0=sum(返厂金额0),调拨出库金额0=sum(调拨出库金额0),原料出库金额0=sum(原料出库金额0),
fmoney_SalCost=sum(fmoney_SalCost),  
fmoney_outCost=sum(fmoney_outCost),fmoney_bsCost=sum(fmoney_bsCost),fmoney_rbdCost=sum(fmoney_rbdCost),
fmoney_dbout=sum(fmoney_dbout),fmoney_ylout=sum(fmoney_ylout),
销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0)
into #tmp_PeriodJxcOut
from #tmp_PeriodOut_List
group by cGoodsNo,cSupplierNo,iAttribute


------------------------------------------
--------------------------------------------
--select * into ##tmp_PeriodJxcOut_new from #tmp_PeriodJxcOut
/*
select a.cGoodsNo,b.iAttribute,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
into #tmp_PeriodJxcOut
from #FIFOCWhDate_chen a left join t_Cost_distribute  b
on a.cGoodsNo=b.cGoodsNo and b.dDate_Sheet between  @dDate1 and @dDate2 and isnull(b.bDone,0)=0
where b.iAttribute is not null
and b.cWhNo=@cWhNo
group by a.cGoodsNo,b.iAttribute
*/

--期间入库
update a
set a.fQty_jxc_in=b.入库数量1,
    a.fMoney_jxc_in=b.入库金额1
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 
--调拨入库
/*
  fQty_jxc_TfrIn money default(0),      --调拨入库
  fMoney_jxc_TfrIn money default(0),
  fSheetMoney_TfrIn money default(0),
*/

update a
set a.fQty_jxc_TfrIn=b.调拨入库数量1,
    a.fMoney_jxc_TfrIn=b.调拨入库金额1,
    a.fSheetMoney_TfrIn=b.fMoney_TrfIn
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 
--期间出库
update a
set a.fQty_jxc_out=b.出库数量0,
    a.fMoney_jxc_out=b.fmoney_outCost,
    a.fSheetMoney_Out=b.出库金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间返厂
update a
set a.fQty_jxc_rbd=b.返厂数量0,
    a.fMoney_jxc_rbd=b.fmoney_rbdCost,
    a.fSheetMoney_rbd=b.返厂金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间客退
update a
set a.fQty_jxc_Return=b.退货入库数量1,
    a.fMoney_jxc_Return=b.退货入库金额1
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间调拨入库
 

--期间调拨出库
update a
set a.fQty_jxc_Tfr=b.调拨出库数量0,
    a.fMoney_jxc_Tfr=b.fmoney_dbout,
    a.fSheetMoney_Tfr=b.调拨出库金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间报损
update a
set a.fQty_jxc_Lost=b.报损数量0,
    a.fMoney_jxc_Lost=b.fmoney_bsCost,
    a.fSheetMoney_Lost=b.报损金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间报溢
update a
set a.fQty_jxc_Effusion=b.报溢数量1,
    a.fMoney_jxc_Effusion=b.报溢金额1
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间原料出库
update a
set a.fQty_jxc_Pack=b.原料出库数量0,
    a.fMoney_jxc_Pack=b.fmoney_ylout,
    a.fSheetMoney_Pack=b.原料出库金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间成品入库
update a
set a.fQty_jxc_Deliver=b.成品入库数量1,
    a.fMoney_jxc_Deliver=b.成品入库金额1
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 

--期间销售
/*
update a
set a.fQty_jxc_sale=b.fQty_Out,
    a.fMoney_jxc_sale=b.fMoney_Out,
    a.fSheetMoney_Sale=b.fSheetMoney
from #FIFOCWhDate_chen a,
	(select cGoodsNo,iAttribute,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),
	fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
	from #tmp_PeriodJxcOut
	group by cGoodsNo,iAttribute,cSupplierNo
) b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=10
*/
update a
set a.fQty_jxc_sale=b.销售数量0,
    a.fMoney_jxc_sale=b.fmoney_SalCost,
    a.fSheetMoney_Sale=b.销售金额0
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
 
 
select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_in=sum(isnull(fMoney_in,0)),
fQty_Left=SUM(fQty_Left),fmoney_Left=SUM(fmoney_Left)
into #tmp_Date2In
from #tmp_Date2In1
group by cGoodsNo,cSupplierNo

select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
into #tmp_Date2Out
from #tmp_PeriodJxcOut
group by cGoodsNo,cSupplierNo
 
 
update a
set a.fQty_in_period=b.fQty_in,a.fMoney_in_period=b.fMoney_in,
a.fQty=b.fQty_Left,a.fMOney=b.fmoney_Left
from #FIFOCWhDate_chen a,#tmp_Date2In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

update a
set a.fQty_Out_period=b.fQty_Out,a.fMoney_Out_period=b.fMoney_Out
from #FIFOCWhDate_chen a,#tmp_Date2Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

/*修改总发出数量（有POS客退情况）2013-04-22 */
--if (select object_id('tempdb..#temp_OUT'))is not null
--drop table #temp_OUT

--  select b.cGoodsNo,fQty_Out=a.fQty_In,fMoney_Out=a.fMoney_In,b.cSupplierNo into #temp_OUT from T_WH_Form a,#tmp_Date2Out b 
--  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and 
--  dDateTime between  @dDate1 and @dDate2 
--  and a.iAttribute=13 and a.cWhNo=@cWhNo
  
  
--  update a
--set a.fQty_Out_period=a.fQty_Out_period-b.fQty_Out,a.fMoney_Out_period=a.fMoney_Out_period-b.fMoney_Out
--from #FIFOCWhDate_chen a,#temp_OUT b
--where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

update a
set a.fQty_Out_period=a.fQty_Out_period-b.fQty_in,
    a.fMoney_Out_period=a.fMoney_Out_period-b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn1 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=13

/*
 以上 获取退货信息 把总的发出数量
*/

 
  --起初期末库存数
update #FIFOCWhDate_chen
set fQty_bgn=isnull(fQty_in_bgn,0)-isnull(fQty_Out_bgn,0), fMoney_bgn=isnull(fMoney_in_bgn,0)-isnull(fMoney_out_bgn,0),
    fQty_period=isnull(fQty_in_period,0)-isnull(fQty_Out_period,0),
    fMoney_period=isnull(fMoney_in_period,0)-isnull(fMoney_out_period,0)
 

update #FIFOCWhDate_chen
set fQty=isnull(fQty_bgn,0)+isnull(fQty_Period,0),
    fMoney=isnull(fMoney_period,0)+isnull(fMoney_bgn,0)

--系统初始化数量
/*
select a.cGoodsNo,fQtyIn=sum(isnull(a.fQty_in,0)),fQtyOut=sum(isnull(b.fQty_Cost,0)),
fMoney_init=sum(isnull(a.fmoney_in,0))-sum(isnull(b.fmoney_Cost,0)),fMoney_sale=sum(isnull(b.fMoney_sale,0))
into #tmpSysInit
from t_wh_form a left join t_Cost_distribute b
on a.iserno=b.iserno and a.cgoodsno=b.cgoodsno and isnull(b.bDone,0)=0 and b.dDate_Sheet<=@dDate2
and isnull(a.iAttribute,99)=16 and isnull(b.iAttribute,99)=16
where isnull(a.iAttribute,99)=16 and a.dDateTime<=@dDate2   --'@dDate2'
group by a.cgoodsno
*/

select cGoodsNo,cSupplierNo,fQtyIn=sum(isnull(fQty_in,0)),fMoney_init=sum(isnull(fmoney_in,0))
into #tmpSysInit1
from t_wh_form 
where isnull(iAttribute,99)=16
and cWhNo=@cWhNo
group by cGoodsNo,cSupplierNo

--print '7:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

select a.cGoodsNo,b.cSupplierNo,fQtyOut=sum(isnull(a.fQty_Cost,0)),fMoney_cost=sum(isnull(a.fmoney_Cost,0)),fMoney_sale=sum(isnull(a.fMoney_sale,0))
into #tmpSysInit2
from t_Cost_distribute a left join t_wh_form b on a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno
where isnull(a.iAttribute,99)=16 and isnull(bDone,0)=0
and a.cWhNo=@cWhNo
group by a.cGoodsNo,b.cSupplierNo

--print '8:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())


select a.cGoodsNo,a.cSupplierNo,fQtyIn_init=isnull(a.fQtyIn,0),fQtyOut_init=isnull(b.fQtyOut,0),
fMoney_init=isnull(a.fMoney_init,0)-isnull(b.fMoney_cost,0),fMoneySale_init=isnull(b.fMoney_sale,0)
into #tmpSysInit
from #tmpSysInit1 a left join #tmpSysInit2 b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

update a
set fQtyIn_init=b.fQtyIn_init,fQtyOut_init=b.fQtyOut_init,fMoney_init=b.fMoney_init,fMoneySale_init=b.fMoneySale_init
from #FIFOCWhDate_chen a,#tmpSysInit b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

update a
set a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.cGoodsTypeNo=b.cGoodsTypeNo,a.cGoodsTypeName=b.cGoodsTypeName,
a.fCurNormalPrice=b.fNormalPrice
from #FIFOCWhDate_chen a,t_Goods b
where a.cGoodsNo=b.cGoodsNo

update a
set a.cSupName=b.cSupName
from #FIFOCWhDate_chen a,t_supplier b
where a.cSupNO=b.cSupNo
/*
        select cGoodsNo,cGoodsName, cSupNO,cSupName,fQty_bgn, --- 期初库存
	  fMoney_bgn,--  期初库存金额
	  fQty_in_period, --- 期间入库数量
	  fMoney_in_period, --- 期间入库金额
	  fQty_Out_period,   -- 期间出库数量
	  fMoney_Out_period,  -- 期间出库金额
	  fQty_period,   ---  期间数量=期间入库数量-期间出库数量
	  fMoney_period,----   期间金额=期间入库金额-期间出库金额
	  fQty,   --期末库存= 期初库存+期间数量
	   fMOney,   -- 期末金额=期初库存金额+期间金额
	 --以下是期间进销存
	  fQty_jxc_in ,   --入库
	  fMoney_jxc_in ,
	  fQty_jxc_out ,  --出库
	  fMoney_jxc_out,
	  fSheetMoney_out,
	  fQty_jxc_rbd,  --返厂
	  fMoney_jxc_rbd,
	  fSheetMoney_rbd,
	  fQty_jxc_Return,   --客退
	  fMoney_jxc_Return,
	  fQty_jxc_Tfr,      --调拨出库
	  fMoney_jxc_Tfr,
	  fSheetMoney_Tfr,

	  fQty_jxc_TfrIn,      --调拨入库
	  fMoney_jxc_TfrIn,
	  fSheetMoney_TfrIn,

	  fQty_jxc_Lost,     --报损
	  fMoney_jxc_Lost,
	  fSheetMoney_Lost,
	  fQty_jxc_Effusion, --报溢
	  fMoney_jxc_Effusion,
	  fQty_jxc_Pack,     --原料出库
	  fMoney_jxc_Pack,
	  fSheetMoney_Pack,
	  fQty_jxc_Deliver,     --成品入库
	  fMoney_jxc_Deliver,  
	  fQty_jxc_sale,     --销售
	  fMoney_jxc_sale,
	  fSheetMoney_sale,  
	  fQty_jxc_PdIn,     --盘点溢出
	  fMoney_jxc_PdIn, 
	  fQty_jxc_PdOut,     --盘点报损
	  fMoney_jxc_PdOut,
	  fSheetMoney_pdOut,

	  fQty_jxc_PosIn,     --Pos销售退货入库数量
	  fMoney_jxc_PosIn,
		fCurNormalPrice--按零售价核算 
	 into	##temp_CostDetail
		from #FIFOCWhDate_chen
		*/
/*------------------------------------------------------*/
   if (select OBJECT_ID('tempdb..#tmpGoodsListInfo'))is not null 	
   begin
       insert into #tmpGoodsListInfo(
          cGoodsNo,cGoodsName,
   cSupNO,cSupName,
  fQty_bgn, --- 期初库存
  fMoney_bgn,--  期初库存金额
  fQty_in_period, --- 期间入库数量
  fMoney_in_period, --- 期间入库金额
  fQty_Out_period,   -- 期间出库数量
  fMoney_Out_period,  -- 期间出库金额
  fQty_period,   ---  期间数量=期间入库数量-期间出库数量
  fMoney_period,----   期间金额=期间入库金额-期间出库金额
  fQty,   --期末库存= 期初库存+期间数量
   fMOney,   -- 期末金额=期初库存金额+期间金额
 --以下是期间进销存
  fQty_jxc_in ,   --入库
  fMoney_jxc_in ,
  fQty_jxc_out ,  --出库
  fMoney_jxc_out,
  fSheetMoney_out,
  fQty_jxc_rbd,  --返厂
  fMoney_jxc_rbd,
  fSheetMoney_rbd,
  fQty_jxc_Return,   --客退
  fMoney_jxc_Return,
  fQty_jxc_Tfr,      --调拨出库
  fMoney_jxc_Tfr,
  fSheetMoney_Tfr,

  fQty_jxc_TfrIn,      --调拨入库
  fMoney_jxc_TfrIn,
  fSheetMoney_TfrIn,

  fQty_jxc_Lost,     --报损
  fMoney_jxc_Lost,
  fSheetMoney_Lost,
  fQty_jxc_Effusion, --报溢
  fMoney_jxc_Effusion,
  fQty_jxc_Pack,     --原料出库
  fMoney_jxc_Pack,
  fSheetMoney_Pack,
  fQty_jxc_Deliver,     --成品入库
  fMoney_jxc_Deliver,  
  fQty_jxc_sale,     --销售
  fMoney_jxc_sale,
  fSheetMoney_sale,  
  fQty_jxc_PdIn,     --盘点溢出
  fMoney_jxc_PdIn, 
  fQty_jxc_PdOut,     --盘点报损
  fMoney_jxc_PdOut,
  fSheetMoney_pdOut,

  fQty_jxc_PosIn,     --Pos销售退货入库数量
  fMoney_jxc_PosIn,
    fCurNormalPrice--按零售价核算
       )
       select cGoodsNo,cGoodsName,
	   cSupNO,cSupName,
	  fQty_bgn, --- 期初库存
	  fMoney_bgn,--  期初库存金额
	  fQty_in_period, --- 期间入库数量
	  fMoney_in_period, --- 期间入库金额
	  fQty_Out_period,   -- 期间出库数量
	  fMoney_Out_period,  -- 期间出库金额
	  fQty_period,   ---  期间数量=期间入库数量-期间出库数量
	  fMoney_period,----   期间金额=期间入库金额-期间出库金额
	  fQty,   --期末库存= 期初库存+期间数量
	   fMOney,   -- 期末金额=期初库存金额+期间金额
	 --以下是期间进销存
	  fQty_jxc_in ,   --入库
	  fMoney_jxc_in ,
	  fQty_jxc_out ,  --出库
	  fMoney_jxc_out,
	  fSheetMoney_out,
	  fQty_jxc_rbd,  --返厂
	  fMoney_jxc_rbd,
	  fSheetMoney_rbd,
	  fQty_jxc_Return,   --客退
	  fMoney_jxc_Return,
	  fQty_jxc_Tfr,      --调拨出库
	  fMoney_jxc_Tfr,
	  fSheetMoney_Tfr,

	  fQty_jxc_TfrIn,      --调拨入库
	  fMoney_jxc_TfrIn,
	  fSheetMoney_TfrIn,

	  fQty_jxc_Lost,     --报损
	  fMoney_jxc_Lost,
	  fSheetMoney_Lost,
	  fQty_jxc_Effusion, --报溢
	  fMoney_jxc_Effusion,
	  fQty_jxc_Pack,     --原料出库
	  fMoney_jxc_Pack,
	  fSheetMoney_Pack,
	  fQty_jxc_Deliver,     --成品入库
	  fMoney_jxc_Deliver,  
	  fQty_jxc_sale,     --销售
	  fMoney_jxc_sale,
	  fSheetMoney_sale,  
	  fQty_jxc_PdIn,     --盘点溢出
	  fMoney_jxc_PdIn, 
	  fQty_jxc_PdOut,     --盘点报损
	  fMoney_jxc_PdOut,
	  fSheetMoney_pdOut,

	  fQty_jxc_PosIn,     --Pos销售退货入库数量
	  fMoney_jxc_PosIn,
		fCurNormalPrice--按零售价核算 
		from #FIFOCWhDate_chen
   end
/*------------------------------------------------------*/
else
begin
select cGoodsNo,cGoodsName,date1,date2,fQty_in_bgn,fMoney_in_bgn,fQty_out_bgn,fMOney_out_bgn,fQty_bgn,fMOney_bgn, 
fQty_in_period,fMoney_in_period,fQty_out_period,fMOney_out_period,fQty_period,fMOney_period,cSupNo,cSupName,
cUnit,cSpec,fQty,fMoney,cGoodsTypeno,cGoodsTypeName,
fSheetMoney_Out_bgn=isnull(fCurNormalPrice,0)*isnull(fQty_out_bgn,0),
fQty_jxc_in,fMoney_jxc_in,
fQty_jxc_out,fMoney_jxc_out,fSheetMoney_Out,
fQty_jxc_rbd,fMoney_jxc_rbd,fSheetMoney_Rbd,
fQty_jxc_Return,fMoney_jxc_Return,
fQty_jxc_Tfr,fMoney_jxc_Tfr,fSheetMoney_Tfr,
fQty_jxc_TfrIn,fMoney_jxc_TfrIn,fSheetMoney_TfrIn,
fQty_jxc_Lost,fMoney_jxc_Lost,fSheetMoney_Lost,
fQty_jxc_Effusion,fMoney_jxc_Effusion,
fQty_jxc_Pack,fMoney_jxc_Pack,fSheetMoney_Pack,
fQty_jxc_Deliver,fMoney_jxc_Deliver,
fQty_jxc_sale,fMoney_jxc_sale,fSheetMoney_sale,
fQty_jxc_PdIn,fMoney_jxc_PdIn,
fQty_jxc_PdOut,fMoney_jxc_PdOut,fSheetMoney_PdOut,
fQty_jxc_PosIn,fMoney_jxc_PosIn,
fQtyIn_init,fQtyOut_init,fMoney_init,fMoneySale_init,
iserno=0,fCurNormalPrice,fMoney_CurNormalPrice=isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0),

fMoney_CurNormalPrice_End=isnull(fCurNormalPrice,0)*isnull(fQty,0)
from #FIFOCWhDate_chen
union all
select cGoodsNo,cGoodsName='小计：',date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,
fSheetMoney_Out_bgn=sum(isnull(fCurNormalPrice,0)*isnull(fQty_out_bgn,0)),
sum(fQty_jxc_in),sum(fMoney_jxc_in),
sum(fQty_jxc_out),sum(fMoney_jxc_out),sum(fSheetMoney_Out),
sum(fQty_jxc_rbd),sum(fMoney_jxc_rbd),sum(fSheetMoney_Rbd),
sum(fQty_jxc_Return),sum(fMoney_jxc_Return),
sum(fQty_jxc_Tfr),sum(fMoney_jxc_Tfr),sum(fSheetMoney_Tfr),
sum(fQty_jxc_TfrIn),sum(fMoney_jxc_TfrIn),sum(fSheetMoney_TfrIn),
sum(fQty_jxc_Lost),sum(fMoney_jxc_Lost),sum(fSheetMoney_Lost),
sum(fQty_jxc_Effusion),sum(fMoney_jxc_Effusion),
sum(fQty_jxc_Pack),sum(fMoney_jxc_Pack),sum(fSheetMoney_Pack),
sum(fQty_jxc_Deliver),sum(fMoney_jxc_Deliver),
sum(fQty_jxc_sale),sum(fMoney_jxc_sale),sum(fSheetMoney_sale),
sum(fQty_jxc_PdIn),sum(fMoney_jxc_PdIn),
sum(fQty_jxc_PdOut),sum(fMoney_jxc_PdOut),sum(fSheetMoney_PdOut),
sum(fQty_jxc_PosIn),sum(fMoney_jxc_PosIn),
sum(fQtyIn_init),sum(fQtyOut_init),sum(fMoney_init),sum(fMoneySale_init),
iserno=2,fCurNormalPrice=null,
fMoney_CurNormalPrice=sum(isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0)),
fMoney_CurNormalPrice_End=sum(isnull(fCurNormalPrice,0)*isnull(fQty,0))
from #FIFOCWhDate_chen
group by cGoodsNo
union all
select '合计：',null,date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,
fSheetMoney_Out_bgn=sum(isnull(fCurNormalPrice,0)*isnull(fQty_out_bgn,0)),
sum(fQty_jxc_in),sum(fMoney_jxc_in),
sum(fQty_jxc_out),sum(fMoney_jxc_out),sum(fSheetMoney_Out),
sum(fQty_jxc_rbd),sum(fMoney_jxc_rbd),sum(fSheetMoney_Rbd),
sum(fQty_jxc_Return),sum(fMoney_jxc_Return),
sum(fQty_jxc_Tfr),sum(fMoney_jxc_Tfr),sum(fSheetMoney_Tfr),
sum(fQty_jxc_TfrIn),sum(fMoney_jxc_TfrIn),sum(fSheetMoney_TfrIn),
sum(fQty_jxc_Lost),sum(fMoney_jxc_Lost),sum(fSheetMoney_Lost),
sum(fQty_jxc_Effusion),sum(fMoney_jxc_Effusion),
sum(fQty_jxc_Pack),sum(fMoney_jxc_Pack),sum(fSheetMoney_Pack),
sum(fQty_jxc_Deliver),sum(fMoney_jxc_Deliver),
sum(fQty_jxc_sale),sum(fMoney_jxc_sale),sum(fSheetMoney_sale),
sum(fQty_jxc_PdIn),sum(fMoney_jxc_PdIn),
sum(fQty_jxc_PdOut),sum(fMoney_jxc_PdOut),sum(fSheetMoney_PdOut),
sum(fQty_jxc_PosIn),sum(fMoney_jxc_PosIn),
sum(fQtyIn_init),sum(fQtyOut_init),sum(fMoney_init),sum(fMoneySale_init),
iserno=9,fCurNormalPrice=null,fMoney_CurNormalPrice=sum(isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0)),
fMoney_CurNormalPrice_End=sum(isnull(fCurNormalPrice,0)*isnull(fQty,0))
from #FIFOCWhDate_chen
order by cgoodsno,iserno
end
-- drop table ##FIFOCWhDate_chen_new
--select * into ##FIFOCWhDate_chen_new from #FIFOCWhDate_chen
--where cGoodsNo='21003' or cGoodsNo='21006' or cGoodsNo='21007'
GO
