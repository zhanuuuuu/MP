/*

p_Get_ScalDateCenter_ScaleList_Status '00','1001',0

*/
create procedure p_Update_ScalDateCenter_ScaleList_Status
@cStoreNo varchar(32),
@cScaleNo varchar(32),
@iStatus smallint  /*@iStatus=1 正在称重；@iStatus=2 称重完毕；@iStatus=0 空闲；@iStatus=-1 维修中  */
as
begin
  update a
  set a.iStatus=1
  from
  dbo.t_ScaleDataCenter_ScaleList a 
  where a.cStoreNo=@cStoreNo and a.cScaleNo=@cScaleNo 
   
end
GO
