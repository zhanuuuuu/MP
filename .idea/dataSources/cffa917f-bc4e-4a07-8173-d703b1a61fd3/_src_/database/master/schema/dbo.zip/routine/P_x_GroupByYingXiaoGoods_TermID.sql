 

/*    

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods   where  cGoodsNo in ('110023') 

exec [P_x_SetCheckWh_byGoodsType_log] '000','2016-3-3','2016-4-24','01' 
go
exec [P_x_SetCheckWh_byGoodsType_log] '2015-6-7','2015-6-7','01' 
go
*/
/*按供应商查库存*/
create procedure [dbo].[P_x_GroupByYingXiaoGoods_TermID]
@cStoreNo varchar(32),
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32),
@cTermID varchar(32),
@IDay int
as 

---获取部组编号
if (select object_id('tempdb..#temp_GroupGoodsTypeNo'))is not null drop table #temp_GroupGoodsTypeNo
create table #temp_GroupGoodsTypeNo(cGoodsTypeNo varchar(32))
exec(' 
   insert into #temp_GroupGoodsTypeNo(cGoodsTypeNo)
   select distinct cGoodsTypeNo 
   from U_Key.dbo.temp_GoodsTypeNo'+@cTermID+'
')
-- 获取部组的类别编号
if (select object_id('tempdb..#temp_GoodsTypeNo'))is not null drop table #temp_GoodsTypeNo
select distinct a.cGoodsTypeNo,a.cGroupTypeNo,cGroupTypeName into #temp_GoodsTypeNo 
from T_GroupType_GoodsType a,#temp_GroupGoodsTypeNo b
where a.cGroupTypeNo=b.cGoodsTypeNo


if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsno,cGroupTypeNo,cGroupTypeName into #temp_Goods from t_Goods a,#temp_GoodsTypeNo b
where a.cGoodsTypeno=b.cGoodsTypeNo
 
--print dbo.gettimestr(getdate())
--print 1
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
select distinct a.cGoodsno,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1 into  #tmp_WhGoodsList_1  
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1   ---- 大包装
union all
select distinct a.cGoodsNo ,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1   --- 小包装
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''  -- 获取大包装下的笑包装
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsno,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_cStoreGoods b
where b.cStoreNo=@cStoreNo and a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1

CREATE INDEX IX_WhGoodsList_1  ON #tmp_WhGoodsList_1(cGoodsNo)

 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsno,cGoodsNo_minPackage,fQty_minPackage,bbox 
into #tmp_WhGoodsList from  #tmp_WhGoodsList_1

 
 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32),@Rdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@Rdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno


if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,
  fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,
  fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money,
  期初盘点 money,期末盘点 money,期初账面库存 money,期末账面库存 money,fAvgMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock)   where cStoreNo='''+@cStoreNo+'''   ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

/*结转表中取数据*/

declare @dDate1 datetime
declare @dDate2 datetime
declare @BgndDate1 datetime
 declare @i int
set @i=1
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
			        
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
					set @BgndDate1=@dDate1
					--set @i=0
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
					set @BgndDate1=@dDate1
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=0
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 	 
		set @BgndDate1=@maxWhdDate+1		
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd

 
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额

 
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn)  
    
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1


insert into #temp_WhFromend  ([cGoodsNo],[cWHno]) 
select distinct cGoodsno,@cWhNo from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@maxWhdDate) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@maxWhdDate) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
	if(@bY1<>@eY1)
	begin 
	    set @tj='1'
   end else
   begin      
       if @bM1=@eM1
       begin  
       exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select b.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+' 
		,fQty0=b.fQty_010131,fMoney0=b.fMoney_010131 		
		into #temp_Wh_Goods_end
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#temp_WhFromend a 
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno
		 
		update a 
		set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
		a.fmoney_left=b.fMoney1,	
		a.期初账面库存=isnull(b.fQty0,0), 
		a.期末账面库存=isnull(b.fQty1,0)	
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  	
		 
	')
	  exec('
	------------
	   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select b.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
		fQty0=b.fQty_010131 ,fQtytj0=b.fQtytj_010131    
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_WhFromend a 
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select b.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
		Sale0=b.Sale_010131 , Saletj0=b.Saletj_010131 
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cGoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
		fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cGoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno
		 
		update a 
		set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
		a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
		a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0))				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
		where a.cGoodsNo=b.cGoodsNo  
		 
		update a 
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))   	
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo  
		')
	exec('		  	  
	----------期末入库数
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endIn''))is not null  drop table #temp_Wh_Goods_endIn
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131  					 
		into #temp_Wh_Goods_endIn
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endIn''))is not null  drop table #temp_SumWh_Goods_endIn
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endIn
		from  #temp_Wh_Goods_endIn
		group by cgoodsno
		

		update a 
		set a.入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endIn b
		where a.cGoodsNo=b.cGoodsNo  
		')
	exec('
	----------期末成品入库：t_WH_Form_Log_Day_Divide
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endDivide''))is not null  drop table #temp_Wh_Goods_endDivide
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131  					 
		into #temp_Wh_Goods_endDivide
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endDivide''))is not null  drop table #temp_SumWh_Goods_endDivide
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_endDivide
		from  #temp_Wh_Goods_endDivide
		group by cgoodsno
		

		update a 
		set a.成品入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),成品入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endDivide b
		where a.cGoodsNo=b.cGoodsNo 
		')
	exec('
	----------期末t_WH_Form_Log_Day_Effusion[报益单]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endEffusion''))is not null  drop table #temp_Wh_Goods_endEffusion
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131  						 
		into #temp_Wh_Goods_endEffusion
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endEffusion''))is not null  drop table #temp_SumWh_Goods_endEffusion
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_endEffusion
		from  #temp_Wh_Goods_endEffusion
		group by cgoodsno
		

		update a 
		set a.报溢数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),报溢金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	 			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endEffusion b
		where a.cGoodsNo=b.cGoodsNo 	
		')
	exec('
	----------期末t_WH_Form_Log_Day_Return[退货入库]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endReturn''))is not null  drop table #temp_Wh_Goods_endReturn
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131 						 
		into #temp_Wh_Goods_endReturn
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endReturn''))is not null  drop table #temp_SumWh_Goods_endReturn
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endReturn
		from  #temp_Wh_Goods_endReturn
		group by cgoodsno
		

		update a 
		set a.退货入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),退货入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endReturn b
		where a.cGoodsNo=b.cGoodsNo 	
		')
	exec('
	----------期末t_WH_Form_Log_Day_TfrIn[调拨入库]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrIn''))is not null  drop table #temp_Wh_Goods_endTfrIn
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endTfrIn
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrIn''))is not null  drop table #temp_SumWh_Goods_endTfrIn
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endTfrIn
		from  #temp_Wh_Goods_endTfrIn
		group by cgoodsno
		

		update a 
		set a.调拨入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),调拨入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrIn b
		where a.cGoodsNo=b.cGoodsNo 
		')
	exec('
	----------*************发出********--------	
	----------期末出库单t_WH_Form_Log_Day_Out[出库单
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endOut''))is not null  drop table #temp_Wh_Goods_endOut
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131   					 
		into #temp_Wh_Goods_endOut
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endOut''))is not null  drop table #temp_SumWh_Goods_endOut
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endOut
		from  #temp_Wh_Goods_endOut
		group by cgoodsno
		

		update a 
		set a.出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endOut b
		where a.cGoodsNo=b.cGoodsNo 
		')
	exec('
	----------期末返厂单t_WH_Form_Log_Day_Rbd[返厂单]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRbd''))is not null  drop table #temp_Wh_Goods_endRbd
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131 						 
		into #temp_Wh_Goods_endRbd
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRbd''))is not null  drop table #temp_SumWh_Goods_endRbd
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endRbd
		from  #temp_Wh_Goods_endRbd
		group by cgoodsno
		

		update a 
		set a.返厂数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),返厂金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endRbd b
		where a.cGoodsNo=b.cGoodsNo 
		')
	exec('
	----------期末报损 单t_WH_Form_Log_Day_Loss[报损单]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endLoss''))is not null  drop table #temp_Wh_Goods_endLoss
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131   							 
		into #temp_Wh_Goods_endLoss
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endLoss''))is not null  drop table #temp_SumWh_Goods_endLoss
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endLoss
		from  #temp_Wh_Goods_endLoss
		group by cgoodsno
		

		update a 
		set a.报损数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),报损金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	  			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endLoss b
		where a.cGoodsNo=b.cGoodsNo 	
		')
	exec('
	----------期末调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfr''))is not null  drop table #temp_Wh_Goods_endTfr
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131   					 
		into #temp_Wh_Goods_endTfr
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfr''))is not null  drop table #temp_SumWh_Goods_endTfr
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
		into #temp_SumWh_Goods_endTfr
		from  #temp_Wh_Goods_endTfr
		group by cgoodsno
		

		update a 
		set a.调拨出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),调拨出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfr b
		where a.cGoodsNo=b.cGoodsNo 
		')
	exec('
	----------期末原料出库单t_WH_Form_Log_Day_Pack
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endPack''))is not null  drop table #temp_Wh_Goods_endPack
		select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131 ,fMoney0=b.fMoneyIn_010131   					 
		into #temp_Wh_Goods_endPack
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b,#temp_WhFromend a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endPack''))is not null  drop table #temp_SumWh_Goods_endPack
		select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_endPack
		from  #temp_Wh_Goods_endPack
		group by cgoodsno
		

		update a 
		set a.原料出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),原料出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0) 			
		from #temp_WhFromend a ,#temp_SumWh_Goods_endPack b
		where a.cGoodsNo=b.cGoodsNo 	
		
		')
		end else
		begin
		  set @tj='1'	
		end
   end
   if @tj='1'
   begin
      		insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
		select distinct cGoodsno,@cWhNo from  #tmp_WhGoodsList 

		CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select b.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b,#temp_WhFrombegin a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno
			

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		--------期初销售
		   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select b.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select b.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
			where a.cGoodsNo=b.cGoodsNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo  
				')
		exec('			
		----------期初入库数
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginIn''))is not null  drop table #temp_Wh_Goods_beginIn
			select b.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginIn
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginIn''))is not null  drop table #temp_SumWh_Goods_beginIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginIn
			from  #temp_Wh_Goods_beginIn
			group by cgoodsno
			

			update a 
			set a.入库数量1=b.fQty,入库金额1=b.fMoney			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginIn b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期初成品入库：t_WH_Form_Log_Day_Divide
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginDivide''))is not null  drop table #temp_Wh_Goods_beginDivide
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginDivide
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M_1+' b,#temp_WhFrombegin a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginDivide''))is not null  drop table #temp_SumWh_Goods_beginDivide
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginDivide
			from  #temp_Wh_Goods_beginDivide
			group by cgoodsno
			

			update a 
			set a.成品入库数量1=b.fQty,成品入库金额1=b.fMoney	 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginDivide b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初t_WH_Form_Log_Day_Effusion[报益单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginEffusion''))is not null  drop table #temp_Wh_Goods_beginEffusion
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginEffusion
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginEffusion''))is not null  drop table #temp_SumWh_Goods_beginEffusion
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginEffusion
			from  #temp_Wh_Goods_beginEffusion
			group by cgoodsno
			

			update a 
			set a.报溢数量1=b.fQty,报溢金额1=b.fMoney	 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginEffusion b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期初t_WH_Form_Log_Day_Return[退货入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginReturn''))is not null  drop table #temp_Wh_Goods_beginReturn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginReturn
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginReturn''))is not null  drop table #temp_SumWh_Goods_beginReturn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginReturn
			from  #temp_Wh_Goods_beginReturn
			group by cgoodsno
			

			update a 
			set a.退货入库数量1=b.fQty,退货入库金额1=b.fMoney 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginReturn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期初t_WH_Form_Log_Day_TfrIn[调拨入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrIn''))is not null  drop table #temp_Wh_Goods_beginTfrIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrIn
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrIn''))is not null  drop table #temp_SumWh_Goods_beginTfrIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrIn
			from  #temp_Wh_Goods_beginTfrIn
			group by cgoodsno
			

			update a 
			set a.调拨入库数量1=b.fQty,调拨入库金额1=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrIn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------*************发出********--------	
		----------期初出库单t_WH_Form_Log_Day_Out[出库单
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginOut''))is not null  drop table #temp_Wh_Goods_beginOut
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginOut
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginOut''))is not null  drop table #temp_SumWh_Goods_beginOut
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginOut
			from  #temp_Wh_Goods_beginOut
			group by cgoodsno
			

			update a 
			set a.出库数量0=b.fQty,出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginOut b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初返厂单t_WH_Form_Log_Day_Rbd[返厂单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginRbd''))is not null  drop table #temp_Wh_Goods_beginRbd
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginRbd
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginRbd''))is not null  drop table #temp_SumWh_Goods_beginRbd
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginRbd
			from  #temp_Wh_Goods_beginRbd
			group by cgoodsno
			

			update a 
			set a.返厂数量0=b.fQty,返厂金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginRbd b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初报损 单t_WH_Form_Log_Day_Loss[报损单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginLoss''))is not null  drop table #temp_Wh_Goods_beginLoss
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginLoss
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginLoss''))is not null  drop table #temp_SumWh_Goods_beginLoss
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginLoss
			from  #temp_Wh_Goods_beginLoss
			group by cgoodsno
			

			update a 
			set a.报损数量0=b.fQty,报损金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginLoss b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期初调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfr''))is not null  drop table #temp_Wh_Goods_beginTfr
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfr
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfr''))is not null  drop table #temp_SumWh_Goods_beginTfr
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfr
			from  #temp_Wh_Goods_beginTfr
			group by cgoodsno
			

			update a 
			set a.调拨出库数量0=b.fQty,调拨出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfr b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初原料出库单t_WH_Form_Log_Day_Pack
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginPack''))is not null  drop table #temp_Wh_Goods_beginPack
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginPack
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginPack''))is not null  drop table #temp_SumWh_Goods_beginPack
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginPack
			from  #temp_Wh_Goods_beginPack
			group by cgoodsno
			

			update a 
			set a.原料出库数量0=b.fQty,原料出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginPack b
			where a.cGoodsNo=b.cGoodsNo 	
			
			') 

		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo  	
			 
			')
		exec('
		------------
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
			where a.cGoodsNo=b.cGoodsNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo  	
			')
		exec('	  	  
		----------期末入库数
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endIn''))is not null  drop table #temp_Wh_Goods_endIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endIn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endIn''))is not null  drop table #temp_SumWh_Goods_endIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endIn
			from  #temp_Wh_Goods_endIn
			group by cgoodsno
			

			update a 
			set a.入库数量1=b.fQty,入库金额1=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endIn b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期末成品入库：t_WH_Form_Log_Day_Divide
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endDivide''))is not null  drop table #temp_Wh_Goods_endDivide
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endDivide
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endDivide''))is not null  drop table #temp_SumWh_Goods_endDivide
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endDivide
			from  #temp_Wh_Goods_endDivide
			group by cgoodsno
			

			update a 
			set a.成品入库数量1=b.fQty,成品入库金额1=b.fMoney	 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endDivide b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末t_WH_Form_Log_Day_Effusion[报益单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endEffusion''))is not null  drop table #temp_Wh_Goods_endEffusion
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endEffusion
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endEffusion''))is not null  drop table #temp_SumWh_Goods_endEffusion
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endEffusion
			from  #temp_Wh_Goods_endEffusion
			group by cgoodsno
			

			update a 
			set a.报溢数量1=b.fQty,报溢金额1=b.fMoney	 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endEffusion b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期末t_WH_Form_Log_Day_Return[退货入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endReturn''))is not null  drop table #temp_Wh_Goods_endReturn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endReturn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endReturn''))is not null  drop table #temp_SumWh_Goods_endReturn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endReturn
			from  #temp_Wh_Goods_endReturn
			group by cgoodsno
			

			update a 
			set a.退货入库数量1=b.fQty,退货入库金额1=b.fMoney 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endReturn b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期末t_WH_Form_Log_Day_TfrIn[调拨入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrIn''))is not null  drop table #temp_Wh_Goods_endTfrIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrIn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrIn''))is not null  drop table #temp_SumWh_Goods_endTfrIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrIn
			from  #temp_Wh_Goods_endTfrIn
			group by cgoodsno
			

			update a 
			set a.调拨入库数量1=b.fQty,调拨入库金额1=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrIn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------*************发出********--------	
		----------期末出库单t_WH_Form_Log_Day_Out[出库单
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endOut''))is not null  drop table #temp_Wh_Goods_endOut
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endOut
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endOut''))is not null  drop table #temp_SumWh_Goods_endOut
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endOut
			from  #temp_Wh_Goods_endOut
			group by cgoodsno
			

			update a 
			set a.出库数量0=b.fQty,出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endOut b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末返厂单t_WH_Form_Log_Day_Rbd[返厂单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRbd''))is not null  drop table #temp_Wh_Goods_endRbd
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endRbd
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRbd''))is not null  drop table #temp_SumWh_Goods_endRbd
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endRbd
			from  #temp_Wh_Goods_endRbd
			group by cgoodsno
			

			update a 
			set a.返厂数量0=b.fQty,返厂金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endRbd b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末报损 单t_WH_Form_Log_Day_Loss[报损单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endLoss''))is not null  drop table #temp_Wh_Goods_endLoss
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endLoss
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endLoss''))is not null  drop table #temp_SumWh_Goods_endLoss
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endLoss
			from  #temp_Wh_Goods_endLoss
			group by cgoodsno
			

			update a 
			set a.报损数量0=b.fQty,报损金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endLoss b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期末调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfr''))is not null  drop table #temp_Wh_Goods_endTfr
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfr
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfr''))is not null  drop table #temp_SumWh_Goods_endTfr
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfr
			from  #temp_Wh_Goods_endTfr
			group by cgoodsno
			

			update a 
			set a.调拨出库数量0=b.fQty,调拨出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfr b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末原料出库单t_WH_Form_Log_Day_Pack
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endPack''))is not null  drop table #temp_Wh_Goods_endPack
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endPack
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endPack''))is not null  drop table #temp_SumWh_Goods_endPack
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endPack
			from  #temp_Wh_Goods_endPack
			group by cgoodsno
			

			update a 
			set a.原料出库数量0=b.fQty,原料出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endPack b
			where a.cGoodsNo=b.cGoodsNo 	
			')
			  
			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
			a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
			a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
			a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
			a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
			
			a.入库数量1=isnull(a.入库数量1,0)-isnull(b.入库数量1,0), 
			a.入库金额1=isnull(a.入库金额1,0)-isnull(b.入库金额1,0),
			a.报溢数量1=isnull(a.报溢数量1,0)-isnull(b.报溢数量1,0), 
			a.报溢金额1=isnull(a.报溢金额1,0)-isnull(b.报溢金额1,0),					  
			a.退货入库数量1=isnull(a.退货入库数量1,0)-isnull(b.退货入库数量1,0), 
			a.退货入库金额1=isnull(a.退货入库金额1,0)-isnull(b.退货入库金额1,0),		  
			a.调拨入库数量1=isnull(a.调拨入库数量1,0)-isnull(b.调拨入库数量1,0), 
			a.调拨入库金额1=isnull(a.调拨入库金额1,0)-isnull(b.调拨入库金额1,0),		  
			a.成品入库数量1=isnull(a.成品入库数量1,0)-isnull(b.成品入库数量1,0), 
			a.成品入库金额1=isnull(a.成品入库金额1,0)-isnull(b.成品入库金额1,0),
							
			a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
			a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
			a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
			a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),					  
			a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
			a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
			a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
			a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
			a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
			a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
			a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
			a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),			      
			a.期初库存=isnull(b.期初库存,0), 
			a.期末库存=isnull(a.期末库存,0), 
			a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
			a.期初账面库存=isnull(b.期初库存,0), 
			a.期末账面库存=isnull(a.期末库存,0), 
			a.fPrice_Avg=a.fPrice_Avg,
			a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
			a.fMoney_left=ISNULL(a.fMoney_left,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo 
   end
end else
begin
   if @M1=@M_1
   begin
   exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
	select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+' 
	,fQty0=b.fQty_'+@MMDAY_1+',fMoney0=b.fMoney_'+@MMDAY_1+' 		
	into #temp_Wh_Goods_end
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
  
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_end
	from  #temp_Wh_Goods_end
	group by cgoodsno
	 
    update a 
	set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
	a.fmoney_left=b.fMoney1,	
	a.期初账面库存=isnull(b.fQty0,0), 
	a.期末账面库存=isnull(b.fQty1,0)	
	from #temp_WhFromend a ,#temp_SumWh_Goods_end b
	where a.cGoodsNo=b.cGoodsNo  	
	 
')
  
  exec('
------------
   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cGoodsno,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+'   
	into #temp_Wh_Goods_endQty
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cGoodsno,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'  
	into #temp_Wh_Goods_endSale					
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cGoodsno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cGoodsno,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno
	 
	update a 
	set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
	a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
	a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0))				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
	where a.cGoodsNo=b.cGoodsNo  
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
	a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
	a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))   	
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo  
	')
exec('		  	  
----------期末入库数
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endIn''))is not null  drop table #temp_Wh_Goods_endIn
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_endIn
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endIn''))is not null  drop table #temp_SumWh_Goods_endIn
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
	into #temp_SumWh_Goods_endIn
	from  #temp_Wh_Goods_endIn
	group by cgoodsno
	

    update a 
	set a.入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endIn b
	where a.cGoodsNo=b.cGoodsNo  
	')
exec('
----------期末成品入库：t_WH_Form_Log_Day_Divide
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endDivide''))is not null  drop table #temp_Wh_Goods_endDivide
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_endDivide
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endDivide''))is not null  drop table #temp_SumWh_Goods_endDivide
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_endDivide
	from  #temp_Wh_Goods_endDivide
	group by cgoodsno
	

    update a 
	set a.成品入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),成品入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endDivide b
	where a.cGoodsNo=b.cGoodsNo 
	')
exec('
----------期末t_WH_Form_Log_Day_Effusion[报益单]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endEffusion''))is not null  drop table #temp_Wh_Goods_endEffusion
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 						 
	into #temp_Wh_Goods_endEffusion
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endEffusion''))is not null  drop table #temp_SumWh_Goods_endEffusion
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_endEffusion
	from  #temp_Wh_Goods_endEffusion
	group by cgoodsno
	

    update a 
	set a.报溢数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),报溢金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	 			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endEffusion b
	where a.cGoodsNo=b.cGoodsNo 	
	')
exec('
----------期末t_WH_Form_Log_Day_Return[退货入库]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endReturn''))is not null  drop table #temp_Wh_Goods_endReturn
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 						 
	into #temp_Wh_Goods_endReturn
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endReturn''))is not null  drop table #temp_SumWh_Goods_endReturn
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endReturn
	from  #temp_Wh_Goods_endReturn
	group by cgoodsno
	

    update a 
	set a.退货入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),退货入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endReturn b
	where a.cGoodsNo=b.cGoodsNo 	
	')
exec('
----------期末t_WH_Form_Log_Day_TfrIn[调拨入库]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrIn''))is not null  drop table #temp_Wh_Goods_endTfrIn
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 	 					 
	into #temp_Wh_Goods_endTfrIn
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrIn''))is not null  drop table #temp_SumWh_Goods_endTfrIn
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endTfrIn
	from  #temp_Wh_Goods_endTfrIn
	group by cgoodsno
	

    update a 
	set a.调拨入库数量1=isnull(b.fQty1,0)-isnull(b.fQty0,0),调拨入库金额1=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrIn b
	where a.cGoodsNo=b.cGoodsNo 
	')
exec('
----------*************发出********--------	
----------期末出库单t_WH_Form_Log_Day_Out[出库单
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endOut''))is not null  drop table #temp_Wh_Goods_endOut
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  					 
	into #temp_Wh_Goods_endOut
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endOut''))is not null  drop table #temp_SumWh_Goods_endOut
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endOut
	from  #temp_Wh_Goods_endOut
	group by cgoodsno
	

    update a 
	set a.出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endOut b
	where a.cGoodsNo=b.cGoodsNo 
	')
exec('
----------期末返厂单t_WH_Form_Log_Day_Rbd[返厂单]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRbd''))is not null  drop table #temp_Wh_Goods_endRbd
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  						 
	into #temp_Wh_Goods_endRbd
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRbd''))is not null  drop table #temp_SumWh_Goods_endRbd
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endRbd
	from  #temp_Wh_Goods_endRbd
	group by cgoodsno
	

    update a 
	set a.返厂数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),返厂金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endRbd b
	where a.cGoodsNo=b.cGoodsNo 
	')
exec('
----------期末报损 单t_WH_Form_Log_Day_Loss[报损单]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endLoss''))is not null  drop table #temp_Wh_Goods_endLoss
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  							 
	into #temp_Wh_Goods_endLoss
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endLoss''))is not null  drop table #temp_SumWh_Goods_endLoss
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endLoss
	from  #temp_Wh_Goods_endLoss
	group by cgoodsno
	

    update a 
	set a.报损数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),报损金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	  			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endLoss b
	where a.cGoodsNo=b.cGoodsNo 	
	')
exec('
----------期末调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfr''))is not null  drop table #temp_Wh_Goods_endTfr
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  					 
	into #temp_Wh_Goods_endTfr
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfr''))is not null  drop table #temp_SumWh_Goods_endTfr
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)
	into #temp_SumWh_Goods_endTfr
	from  #temp_Wh_Goods_endTfr
	group by cgoodsno
	

    update a 
	set a.调拨出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),调拨出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endTfr b
	where a.cGoodsNo=b.cGoodsNo 
	')
exec('
----------期末原料出库单t_WH_Form_Log_Day_Pack
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endPack''))is not null  drop table #temp_Wh_Goods_endPack
	select a.cGoodsno,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
	fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  					 
	into #temp_Wh_Goods_endPack
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endPack''))is not null  drop table #temp_SumWh_Goods_endPack
	select cGoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_endPack
	from  #temp_Wh_Goods_endPack
	group by cgoodsno
	

    update a 
	set a.原料出库数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0),原料出库金额0=isnull(b.fMoney1,0)-isnull(b.fMoney0,0) 			
	from #temp_WhFromend a ,#temp_SumWh_Goods_endPack b
	where a.cGoodsNo=b.cGoodsNo 	
	
    ')
    end else
    begin
        insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
		select distinct cGoodsno,@cWhNo from  #tmp_WhGoodsList 
		CREATE INDEX IX_temp_WhFrombegin0  ON #temp_WhFrombegin(cGoodsNo)		
		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select b.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b,#temp_WhFrombegin a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno
			

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		--------期初销售
		   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select b.cGoodsno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select b.cGoodsno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
			where a.cGoodsNo=b.cGoodsNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo  
				')
		exec('			
		----------期初入库数
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginIn''))is not null  drop table #temp_Wh_Goods_beginIn
			select b.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginIn
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+' b,#temp_WhFrombegin a
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginIn''))is not null  drop table #temp_SumWh_Goods_beginIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginIn
			from  #temp_Wh_Goods_beginIn
			group by cgoodsno
			

			update a 
			set a.入库数量1=b.fQty,入库金额1=b.fMoney			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginIn b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期初成品入库：t_WH_Form_Log_Day_Divide
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginDivide''))is not null  drop table #temp_Wh_Goods_beginDivide
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginDivide
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M_1+' b,#temp_WhFrombegin a 
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginDivide''))is not null  drop table #temp_SumWh_Goods_beginDivide
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginDivide
			from  #temp_Wh_Goods_beginDivide
			group by cgoodsno
			

			update a 
			set a.成品入库数量1=b.fQty,成品入库金额1=b.fMoney	 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginDivide b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初t_WH_Form_Log_Day_Effusion[报益单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginEffusion''))is not null  drop table #temp_Wh_Goods_beginEffusion
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginEffusion
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginEffusion''))is not null  drop table #temp_SumWh_Goods_beginEffusion
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginEffusion
			from  #temp_Wh_Goods_beginEffusion
			group by cgoodsno
			

			update a 
			set a.报溢数量1=b.fQty,报溢金额1=b.fMoney	 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginEffusion b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期初t_WH_Form_Log_Day_Return[退货入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginReturn''))is not null  drop table #temp_Wh_Goods_beginReturn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginReturn
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginReturn''))is not null  drop table #temp_SumWh_Goods_beginReturn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginReturn
			from  #temp_Wh_Goods_beginReturn
			group by cgoodsno
			

			update a 
			set a.退货入库数量1=b.fQty,退货入库金额1=b.fMoney 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginReturn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期初t_WH_Form_Log_Day_TfrIn[调拨入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrIn''))is not null  drop table #temp_Wh_Goods_beginTfrIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrIn
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrIn''))is not null  drop table #temp_SumWh_Goods_beginTfrIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrIn
			from  #temp_Wh_Goods_beginTfrIn
			group by cgoodsno
			

			update a 
			set a.调拨入库数量1=b.fQty,调拨入库金额1=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrIn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------*************发出********--------	
		----------期初出库单t_WH_Form_Log_Day_Out[出库单
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginOut''))is not null  drop table #temp_Wh_Goods_beginOut
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginOut
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginOut''))is not null  drop table #temp_SumWh_Goods_beginOut
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginOut
			from  #temp_Wh_Goods_beginOut
			group by cgoodsno
			

			update a 
			set a.出库数量0=b.fQty,出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginOut b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初返厂单t_WH_Form_Log_Day_Rbd[返厂单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginRbd''))is not null  drop table #temp_Wh_Goods_beginRbd
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginRbd
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginRbd''))is not null  drop table #temp_SumWh_Goods_beginRbd
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginRbd
			from  #temp_Wh_Goods_beginRbd
			group by cgoodsno
			

			update a 
			set a.返厂数量0=b.fQty,返厂金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginRbd b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初报损 单t_WH_Form_Log_Day_Loss[报损单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginLoss''))is not null  drop table #temp_Wh_Goods_beginLoss
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginLoss
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginLoss''))is not null  drop table #temp_SumWh_Goods_beginLoss
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginLoss
			from  #temp_Wh_Goods_beginLoss
			group by cgoodsno
			

			update a 
			set a.报损数量0=b.fQty,报损金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginLoss b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期初调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfr''))is not null  drop table #temp_Wh_Goods_beginTfr
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfr
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfr''))is not null  drop table #temp_SumWh_Goods_beginTfr
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfr
			from  #temp_Wh_Goods_beginTfr
			group by cgoodsno
			

			update a 
			set a.调拨出库数量0=b.fQty,调拨出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfr b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期初原料出库单t_WH_Form_Log_Day_Pack
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginPack''))is not null  drop table #temp_Wh_Goods_beginPack
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginPack
			from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M_1+' b
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginPack''))is not null  drop table #temp_SumWh_Goods_beginPack
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginPack
			from  #temp_Wh_Goods_beginPack
			group by cgoodsno
			

			update a 
			set a.原料出库数量0=b.fQty,原料出库金额0=b.fMoney  			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginPack b
			where a.cGoodsNo=b.cGoodsNo 	
			
			') 

		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo  	
			 
			')
		exec('
		------------
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
			where a.cGoodsNo=b.cGoodsNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo  	
			')
		exec('	  	  
		----------期末入库数
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endIn''))is not null  drop table #temp_Wh_Goods_endIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endIn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endIn''))is not null  drop table #temp_SumWh_Goods_endIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endIn
			from  #temp_Wh_Goods_endIn
			group by cgoodsno
			

			update a 
			set a.入库数量1=b.fQty,入库金额1=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endIn b
			where a.cGoodsNo=b.cGoodsNo  
			')
		exec('
		----------期末成品入库：t_WH_Form_Log_Day_Divide
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endDivide''))is not null  drop table #temp_Wh_Goods_endDivide
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endDivide
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endDivide''))is not null  drop table #temp_SumWh_Goods_endDivide
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endDivide
			from  #temp_Wh_Goods_endDivide
			group by cgoodsno
			

			update a 
			set a.成品入库数量1=b.fQty,成品入库金额1=b.fMoney	 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endDivide b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末t_WH_Form_Log_Day_Effusion[报益单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endEffusion''))is not null  drop table #temp_Wh_Goods_endEffusion
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endEffusion
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endEffusion''))is not null  drop table #temp_SumWh_Goods_endEffusion
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endEffusion
			from  #temp_Wh_Goods_endEffusion
			group by cgoodsno
			

			update a 
			set a.报溢数量1=b.fQty,报溢金额1=b.fMoney	 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endEffusion b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期末t_WH_Form_Log_Day_Return[退货入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endReturn''))is not null  drop table #temp_Wh_Goods_endReturn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endReturn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endReturn''))is not null  drop table #temp_SumWh_Goods_endReturn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endReturn
			from  #temp_Wh_Goods_endReturn
			group by cgoodsno
			

			update a 
			set a.退货入库数量1=b.fQty,退货入库金额1=b.fMoney 			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endReturn b
			where a.cGoodsNo=b.cGoodsNo 	
			')
		exec('
		----------期末t_WH_Form_Log_Day_TfrIn[调拨入库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrIn''))is not null  drop table #temp_Wh_Goods_endTfrIn
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrIn
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrIn''))is not null  drop table #temp_SumWh_Goods_endTfrIn
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrIn
			from  #temp_Wh_Goods_endTfrIn
			group by cgoodsno
			

			update a 
			set a.调拨入库数量1=b.fQty,调拨入库金额1=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrIn b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------*************发出********--------	
		----------期末出库单t_WH_Form_Log_Day_Out[出库单
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endOut''))is not null  drop table #temp_Wh_Goods_endOut
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endOut
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endOut''))is not null  drop table #temp_SumWh_Goods_endOut
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endOut
			from  #temp_Wh_Goods_endOut
			group by cgoodsno
			

			update a 
			set a.出库数量0=b.fQty,出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endOut b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末返厂单t_WH_Form_Log_Day_Rbd[返厂单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRbd''))is not null  drop table #temp_Wh_Goods_endRbd
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endRbd
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRbd''))is not null  drop table #temp_SumWh_Goods_endRbd
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endRbd
			from  #temp_Wh_Goods_endRbd
			group by cgoodsno
			

			update a 
			set a.返厂数量0=b.fQty,返厂金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endRbd b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末报损 单t_WH_Form_Log_Day_Loss[报损单]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endLoss''))is not null  drop table #temp_Wh_Goods_endLoss
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endLoss
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endLoss''))is not null  drop table #temp_SumWh_Goods_endLoss
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endLoss
			from  #temp_Wh_Goods_endLoss
			group by cgoodsno
			

			update a 
			set a.报损数量0=b.fQty,报损金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endLoss b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('	
		----------期末调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfr''))is not null  drop table #temp_Wh_Goods_endTfr
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfr
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfr''))is not null  drop table #temp_SumWh_Goods_endTfr
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfr
			from  #temp_Wh_Goods_endTfr
			group by cgoodsno
			

			update a 
			set a.调拨出库数量0=b.fQty,调拨出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfr b
			where a.cGoodsNo=b.cGoodsNo 
			')
		exec('
		----------期末原料出库单t_WH_Form_Log_Day_Pack
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endPack''))is not null  drop table #temp_Wh_Goods_endPack
			select a.cGoodsno,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endPack
			from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endPack''))is not null  drop table #temp_SumWh_Goods_endPack
			select cGoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endPack
			from  #temp_Wh_Goods_endPack
			group by cgoodsno
			

			update a 
			set a.原料出库数量0=b.fQty,原料出库金额0=b.fMoney  			
			from #temp_WhFromend a ,#temp_SumWh_Goods_endPack b
			where a.cGoodsNo=b.cGoodsNo 	
			')
			  
			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
			a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
			a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
			a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
			a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
			
			a.入库数量1=isnull(a.入库数量1,0)-isnull(b.入库数量1,0), 
			a.入库金额1=isnull(a.入库金额1,0)-isnull(b.入库金额1,0),
			a.报溢数量1=isnull(a.报溢数量1,0)-isnull(b.报溢数量1,0), 
			a.报溢金额1=isnull(a.报溢金额1,0)-isnull(b.报溢金额1,0),					  
			a.退货入库数量1=isnull(a.退货入库数量1,0)-isnull(b.退货入库数量1,0), 
			a.退货入库金额1=isnull(a.退货入库金额1,0)-isnull(b.退货入库金额1,0),		  
			a.调拨入库数量1=isnull(a.调拨入库数量1,0)-isnull(b.调拨入库数量1,0), 
			a.调拨入库金额1=isnull(a.调拨入库金额1,0)-isnull(b.调拨入库金额1,0),		  
			a.成品入库数量1=isnull(a.成品入库数量1,0)-isnull(b.成品入库数量1,0), 
			a.成品入库金额1=isnull(a.成品入库金额1,0)-isnull(b.成品入库金额1,0),
							
			a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
			a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
			a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
			a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),					  
			a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
			a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
			a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
			a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
			a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
			a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
			a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
			a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),			      
			a.期初库存=isnull(b.期初库存,0), 
			a.期末库存=isnull(a.期末库存,0), 
			a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
			a.期初账面库存=isnull(b.期初库存,0), 
			a.期末账面库存=isnull(a.期末库存,0), 
			a.fPrice_Avg=a.fPrice_Avg,
			a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
			a.fMoney_left=ISNULL(a.fMoney_left,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo 
    end
end 

 
--- 取记账之前的数据... 
if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
create table #temp_ReadyKucun(
cGoodsNo varchar(32),cUnitedNo varchar(32),BgnQty money,EndQty money,
	rkQty money,thrkQty money,ckQty money,fcQty money,
	dbQty money,bsQty money,byQty money,djQty money,xsQty money,
	ylckQty money,cprkQty money,dbrkQty money,fEndQuantity_Diff   money,
	fCKPriceMoney money,avgInPriceMoney money,fNormalPriceMoney money						
)

if @maxWhdDate<@dDateEnd
begin
      -- exec P_x_SetCheckWh_byGoodsType_Wei @dDate1,@dDate2,@cWhNo,1
      -------期末前最新盘点日期-----------------------------------------------------
   
  if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	select distinct b.cGoodsno,b.cSupNo into #tmpPloyOfGoodsinfo  
	from #tmp_WhGoodsList a,t_cStoreGoods b
	where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
	and ISNULL(b.bStorage,0)=1
	and a.cGoodsNo is not null

   declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select isnull(MAX(dDate),'2000-01-01') from t_Daily_history  where cStoreNo=@cStoreNo and  cWHno=@cWHno)
    if @dMaxDailyDate>@dDate2
    begin
      set @dMaxDailyDate=@dDate2
    end

---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	
	    select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsno,b.bAuditing,
 		fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,t_SaleSheet_Day b 
		 with (nolock) 
		where b.dSaleDate between @BgndDate1 and @dDate2 and a.cGoodsNo=b.cGoodsNo  
		and b.cStoreNo=@cStoreNo and ISNULL(b.cWhNo,'')=@cWhNo 
		union all
		select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsno,b.bAuditing,
		fQuantity=isnull(b.fQuantity,0),fMoney=isnull(b.fLastSettle,0)
		from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b		
		where b.dSaleDate>=@BgndDate1 and b.dSaleDate between (@dMaxDailyDate+1) and @dDate2 and a.cGoodsNo=b.cGoodsNo
		 and b.cStoreNo=@cStoreNo and ISNULL(b.cWhNo,'')=@cWhNo	
		
		select dDateTime=b.dSaleDate,a.cGoodsno,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsno,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsno,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo 
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsno,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束
		
		--配送出库单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=17,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_cStoreOutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_cStoreOutWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--配送出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsno,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
	    union all
		select @dDate2,cGoodsno,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
        
		if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
		select distinct a.cGoodsno,b.cGoodsNo_minPackage,b.fQty_minPackage into  #tmpPackGoodsList  
		from #tmpPloyOfGoodsinfo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(b.cGoodsNo_minPackage,'')<>''
		and ISNULL(b.bStorage,0)=1
         
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsno,cWhNo=@cWhNo,cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money),
		cGoodsName=cast(null as varchar(64)),cUnitedNo=cast(null as varchar(32)),
		cBarcode=cast(null as varchar(32)),cUnit=cast(null as varchar(32)),
		cSpec=cast(null as varchar(32)),fNormalPrice=cast(null as money),
		cGoodsTypeno=cast(null as varchar(32)),cGoodsTypename=cast(null as varchar(100)),
		cSupName=cast(null as varchar(100)),
		BeginDate=cast(null as datetime),EndDate=cast(null as datetime),
		rkQty=cast(0 as money),thrkQty=cast(0 as money),
		ckQty=cast(0 as money),fcQty=cast(0 as money),dbQty=cast(0 as money),
		bsQty=cast(0 as money),byQty=cast(0 as money),djQty=cast(0 as money),
		xsQty=cast(0 as money),ylckQty=cast(0 as money),cprkQty=cast(0 as money),
		dbrkQty=cast(0 as money),fCKPrice=cast(0 as money),avgInPrice=cast(0 as money),
		fCKPriceMoney=cast(0 as money),fNormalPriceMoney=cast(0 as money),
		avgInPriceMoney=cast(0 as money),fEndQuantity_Diff=cast(0 as money)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsno,cWhNo

		update a
		set a.cSupNo=b.cSupNo
		from #GoodsCurStorageList a,t_cStoregoods b
		where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo and isnull(a.cSupNo,'-')='-'

		update a
		set a.cGoodsName=b.cGoodsName,a.cUnitedNo=b.cUnitedNo,a.cBarcode=b.cBarcode,a.cSupplierNo=b.cSupNo,
		a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.fNormalPrice=b.fNormalPrice,
		a.cGoodsTypeno=b.cGoodsTypeno,
		a.cGoodsTypename=b.cGoodsTypename,a.EndDate=@dDate2,a.fCKPrice=b.fCKPrice
		from #tmpGoodsListInfo_1 a,t_cStoregoods b
		where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo

		update a
		set a.cSupName=b.cSupName
		from #tmpGoodsListInfo_1 a,t_supplierStore b
		where a.cSupplierNo=b.cSupNo
		
 
--end
/*
select * from #GoodsCurStorageList where iAttribute<>9999

select cGoodsno,fQuantity=sum(fQuantity),iAttribute,fMoney=sum(fMoney) 
from #GoodsCurStorageList 
where iAttribute<>9999
group by cGoodsno,iAttribute
order by cGoodsNo
*/
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 
		
		--更新期初库存
		update a
		set a.BeginQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
		  select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime <@dDateBgn
			group by cGoodsNo		  
		)b
		where a.cGoodsNo=b.cGoodsNo
		
		--更新入库数量
 
		update a
		set a.rkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=0
			group by cGoodsNo 
		)b
		where a.cGoodsNo=b.cGoodsNo 
 
		--更新客退数量
		update a
		set a.thrkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=3
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		--更新出库数量
		update a
		set a.ckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=1
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo
		
		--更新配送出库数量
		update a
		set a.ckQty=isnull(a.ckQty,0)+isnull(b.fQty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=17
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新返厂数量
		update a
		set a.fcQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=2
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新调拨数量
		update a
		set a.dbQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsno,fqty=sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDate1 and @dDate2 and (iAttribute=41 or iAttribute=40)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报损数量
		update a
		set a.bsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=5
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报溢数量
		update a
		set a.byQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=6
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新销售数量
		update a
		set a.xsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsno,fqty=-sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDate1 and @dDate2 and (iAttribute=20 or iAttribute=21)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新原料出库数量
		update a
		set a.ylckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=8
			group by cGoodsNo

		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新成品入库数量
		update a
		set a.cprkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsno,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=9
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo
	
	--平均进价
		if (select OBJECT_ID('tempdb..#tmpAvgCost'))is not null drop table #tmpAvgCost
		select cGoodsno,cWhNo,avgCost=avg(fPrice_in)
		into #tmpAvgCost
		from t_wh_form
		where dDateTime <=@dDate2 and iAttribute=0
		group by cGoodsno,cWhNo

		update a
		set a.avginPrice=b.avgCost
		from #tmpGoodsListInfo_1 a,#tmpAvgCost b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo

		update a
		set a.avginPrice=b.fckPrice
		from #tmpGoodsListInfo_1 a,t_cStoreGoods b
       where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo and isnull(a.avginPrice,0)=0
	
	   

       insert into   #temp_ReadyKucun(cGoodsno, BgnQty, EndQty,rkQty, thrkQty, ckQty, fcQty,
		   dbQty, bsQty, byQty, djQty, xsQty,ylckQty, cprkQty, dbrkQty, fEndQuantity_Diff,
		   fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney)
       select cGoodsno, BeginQty, EndQty,
		   rkQty, thrkQty, ckQty, fcQty,
		   dbQty, bsQty, byQty, djQty, xsQty,
		   ylckQty, cprkQty, dbrkQty, fEndQuantity_Diff,fCKPrice*EndQty,fNormalPrice*EndQty,avginPrice*EndQty
		    from #tmpGoodsListInfo_1   
	 
	  
   end
  
   if @i=0  
   begin 
        update #temp_WhFromend
		set 
		  入库数量1=0,  退货入库数量1=0,
		  出库数量0=0, 返厂数量0=0, 
		  调拨出库数量0=0, 报损数量0=0, 
		  报溢金额1=0,  差价数量=0,
		  销售数量0=0,  原料出库数量0=0, 
		  成品入库数量1=0,  调拨入库数量1=0,
		  盘点数量=0,期初库存=期末库存
   end
 
   	--------------------盘点
   
	if(select object_id('tempdb..#templast_pd01')) is not null drop table #templast_pd01
	select a.cGoodsno,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd01
 	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo  and b.cStoreNo=@cStoreNo
	where b.dCheckTask<@dDateBgn  
	and b.cWhNo=@cWHno  
	group by a.cGoodsNo
	
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	select a.cGoodsno,a.fQuantity_Diff,a.fmoney_Diff into #templast_pd0 
	from #templast_pd01 a,#tmp_WhGoodsList b
	where a.cGoodsNo=b.cGoodsNo
	
 
	--select * from  #templast_pd0
	----------期末日期的前的所有盘点差异。
	if(select object_id('tempdb..#templast_pd11')) is not null drop table #templast_pd11
	select a.cGoodsno,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd11
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo  and b.cStoreNo=@cStoreNo
	where b.dCheckTask between @dDateBgn and @dDateEnd
	and b.cWhNo=@cWHno  
	group by a.cGoodsNo
	order by a.cGoodsNo
	
	if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	select a.cGoodsno,a.fQuantity_Diff,a.fmoney_Diff into #templast_pd1
	from #templast_pd11 a,#tmp_WhGoodsList b
	where a.cGoodsNo=b.cGoodsNo
	
    ---select * from  #templast_pd1
 
	if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	select cGoodsno,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo='XXXXXX',cSupName='超市盘点'
    into #templast_pdcGoodsNo
    from #templast_pd0
	union all
	select cGoodsno,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo='XXXXXX',cSupName='超市盘点' 
	from #templast_pd1

 
		----- 修改盘点期初数量
		update a
		set a.BeginQty=b.fQuantity_Diff
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		----- 修改盘点期末数量
		update a
		set a.EndQty=b.fQuantity_Diff,
		a.fmoney_Diff=isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		
		update a
		set a.EndQty=isnull(a.EndQty,0)+isnull(b.fQuantity_Diff,0),
		a.fmoney_Diff=isnull(a.fmoney_Diff,0)+isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd1 b
		where a.cGoodsNo=b.cGoodsNo	
 
	
		update a
		set a.期初库存=isnull(a.期初库存,0)+isnull(b.BeginQty,0),
		a.期末库存=isnull(a.期末库存,0)+isnull(b.EndQty,0),
	    a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.BeginQty,0)*a.fPrice_Avg,
	    a.fMoney_left=ISNULL(a.fMoney_left,0),
	    a.期初账面库存=isnull(a.期初库存,0),
	    a.期末账面库存=isnull(a.期末库存,0),
	    a.期初盘点=isnull(b.BeginQty,0),
	    a.期末盘点=isnull(b.EndQty,0),
	    a.fAvgMoney_Diff=isnull(b.fmoney_Diff,0)
		from #temp_WhFromend a,#templast_pdcGoodsNo b
		where a.cGoodsNo=b.cGoodsNo
 
    
	
 
	update b
	set --b.期初库存=case when @i=1 then b.期初库存 else isnull(a.BgnQty,0)+isnull(b.期初库存,0) end,
	  b.期初库存=isnull(a.BgnQty,0)+isnull(b.期初库存,0),
	  b.期末库存=isnull(a.EndQty,0)+isnull(b.期末库存,0), 
	  b.入库数量1=isnull(a.rkQty,0)+isnull(b.入库数量1,0), 
	  b.退货入库数量1=isnull(a.thrkQty,0)+isnull(b.退货入库数量1,0),
      b.出库数量0=abs(isnull(a.ckQty,0))+isnull(b.出库数量0,0), 
      b.返厂数量0=abs(isnull(a.fcQty,0))+isnull(b.返厂数量0,0), 
      b.调拨出库数量0=abs(isnull(a.dbQty,0))+isnull(b.调拨出库数量0,0),
      b.报损数量0=abs(isnull(a.bsQty,0))+isnull(b.报损数量0,0), 
      b.报溢金额1=isnull(a.byQty,0)+isnull(b.报溢金额1,0), 
      b.差价数量=isnull(a.djQty,0)+isnull(b.差价数量,0),
      b.销售数量0=isnull(a.xsQty,0)+isnull(b.销售数量0,0), 
      b.原料出库数量0=abs(isnull(a.ylckQty,0))+isnull(b.原料出库数量0,0), 
      b.成品入库数量1=abs(isnull(a.cprkQty,0))+isnull(b.成品入库数量1,0), 
      b.调拨入库数量1=isnull(a.dbrkQty,0)+ isnull(b.调拨入库数量1,0),
      b.盘点数量=isnull(a.fEndQuantity_Diff,0)+isnull(b.盘点数量,0),
     -- b.fmoney_cost=isnull(b.fmoney_cost,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
	--  b.fMoney_left=isnull(b.fMoney_left,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
	  b.fmoney_cost=isnull(b.fmoney_cost,0)+isnull(a.avgInPriceMoney,0),
	  b.fMoney_left=isnull(b.fMoney_left,0)+isnull(a.avgInPriceMoney,0),
	  b.期初账面库存=isnull(b.期初账面库存,0)+isnull(a.BgnQty,0),
	  b.期末账面库存=isnull(b.期末账面库存,0)+isnull(a.EndQty,0)
	from #temp_ReadyKucun a left join #temp_WhFromend b
	on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is not null 	
	
 

	insert into #temp_WhFromend(
	  cGoodsno, 期初库存, 期末库存, 入库数量1, 退货入库数量1,
      出库数量0, 返厂数量0, 调拨出库数量0, 报损数量0, 报溢金额1, 差价数量,
      销售数量0, 原料出库数量0, 成品入库数量1, 调拨入库数量1,
      盘点数量,fCKPriceMoney,fNormalPriceMoney,fmoney_left
	)
	select a.cGoodsno,a.BgnQty,a.EndQty,
		  a.rkQty,a.thrkQty,a.ckQty,a.fcQty,
		  a.dbQty,a.bsQty,a.byQty,a.djQty,a.xsQty,
		  a.ylckQty,a.cprkQty,a.dbrkQty,a.fEndQuantity_Diff,a.fCKPriceMoney,a.fNormalPriceMoney,a.avgInPriceMoney
	from #temp_ReadyKucun a left join #temp_WhFromend b
	on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is  null		
 
         /*差价2014-10-18*/
    	 ---------获取时间段内的差价表。。---------
		 if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  
		 drop table #temp_wh_DiffPriceWarehouseDetail
		 select a.cGoodsno,b.cWhNo,fMoney_diff=sum(a.fMoney_diff),fQuantity=sum(a.fQuantity)
		 into #temp_wh_DiffPriceWarehouseDetail
		 from wh_DiffPriceWarehouseDetail a,wh_DiffPriceWarehouse b
		 where b.dDate<=@dDateEnd  and a.cSheetno=b.cSheetno  and b.cStoreNo=@cStoreNo
		 group by a.cGoodsno,b.cWhNo 
		 
		 if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_diff '))is not null  
		 drop table #tmp_WhGoodsList_diff 
		 select distinct cGoodsno,cwhno=@cWhNo into #tmp_WhGoodsList_diff from  #tmp_WhGoodsList_1 
		 
	 
		
	    if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null  
	    drop table #temp_wh_DiffPricecGoodsNo
		select  a.cGoodsno,a.cWhNo,a.fMoney_diff,a.fQuantity 
		into #temp_wh_DiffPricecGoodsNo 
		from #temp_wh_DiffPriceWarehouseDetail a,#tmp_WhGoodsList_diff b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cwhno
	

   
   --select * from #temp_wh_DiffPricecGoodsNo
	
	update a set a.fMoney_left=isnull(a.fMoney_left,0)-isnull(b.fMoney_diff,0)
	from #temp_WhFromend a,#temp_wh_DiffPricecGoodsNo b
	where a.cGoodsNo=b.cGoodsNo
	
	 

		  /*2014-10-02修改数量、大小包装*/
		update a 
		set a.cGoodsNo=b.cGoodsNo_minPackage,
		a.入库数量1=a.入库数量1*b.fQty_minPackage,a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,
		a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.销售数量0=a.销售数量0*b.fQty_minPackage,
		a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
		a.本日库存数量=a.本日库存数量*b.fQty_minPackage,a.期初库存=a.期初库存*b.fQty_minPackage,
		a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,
		a.出库数量0=a.出库数量0*b.fQty_minPackage,
		a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
		a.期末库存=a.期末库存*b.fQty_minPackage,
		a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,
		a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage,
		a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,
		a.差价数量=a.差价数量*b.fQty_minPackage,
		a.盘点数量=a.盘点数量*b.fQty_minPackage,
		a.期初账面库存=isnull(a.期初账面库存,0)*b.fQty_minPackage,
		a.期末账面库存=isnull(a.期末账面库存,0)*b.fQty_minPackage,
		a.期初盘点=isnull(a.期初盘点,0)*b.fQty_minPackage,
		a.期末盘点=isnull(a.期末盘点,0)*b.fQty_minPackage	 
		from #temp_WhFromend  a,(select distinct cGoodsno,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
		where a.cGoodsNo=b.cGoodsNo
	 
 
		if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
		select cGoodsno,
		入库数量1=SUM(入库数量1), 入库金额1=SUM(入库金额1), 
		Pos客退数量1=SUM(Pos客退数量1), Pos客退金额1=SUM(Pos客退金额1), 
		退货入库数量1=SUM(退货入库数量1), 退货入库金额1=SUM(退货入库金额1),   
		出库数量0=SUM(出库数量0), 出库金额0=SUM(出库金额0), 
		返厂数量0=SUM(返厂数量0), 返厂金额0=SUM(返厂金额0), 
		报溢数量1=SUM(报溢数量1), 
		调拨入库数量1=SUM(调拨入库数量1), 调拨出库数量0=SUM(调拨出库数量0), 
		原料出库数量0=SUM(原料出库数量0), 报损数量0=SUM(报损数量0), 
		销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
		特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
		正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额), 
		本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 
		差价数量=sum(差价数量),盘点数量=SUM(盘点数量),
		报溢金额1=sum(报溢金额1),成品入库数量1=SUM(成品入库数量1),
		fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost),
		期初账面库存=SUM(期初账面库存),
		期末账面库存=SUM(期末账面库存),
		期初盘点=SUM(期初盘点),
		期末盘点=SUM(期末盘点),
		fAvgMoney_Diff=SUM(fAvgMoney_Diff)
		into #temp_goodsKuCun_1
		from   #temp_WhFromend
		group by cGoodsNo
	 --- 天数
	 
		
		 
		if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null 
		drop table #tmpGoodsListInfo_2
		select GoodsNo_Pdt=a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename,
		xsQty=sum(isnull(销售数量0,0)),
		BeginDate=@dDateBgn,BeginQty=sum(ISNULL(a.期初库存,0)), 
		EndDate=@dDateEnd,EndQty=sum(isnull(a.期末库存,0)) ,
		MaxSaleDAte=cast(null as datetime),
		MaxOrderDAte=cast(null as datetime)
		into #tmpGoodsListInfo_2
		from #temp_goodsKuCun_1 a,t_cStoreGoods b
        where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
		group by a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename
 

 /*------------------*/
      if(select object_id('tempdb..#tmpMaxSaleDateGoods')) is not null  drop table #tmpMaxSaleDateGoods
      select b.GoodsNo_Pdt,MaxSaleDAte=Max(dSaleDAte) into #tmpMaxSaleDateGoods 
      from t_SaleSheetDetail a,#tmpGoodsListInfo_2 b
      where a.cStoreNo=@cStoreNo and a.cGoodsNo=b.GoodsNo_Pdt
      group by b.GoodsNo_Pdt
      
      if(select object_id('tempdb..#tmpMaxOrderDateGoods')) is not null  drop table #tmpMaxOrderDateGoods
      select b.GoodsNo_Pdt,MaxOrderDAte=Max(dDate) into #tmpMaxOrderDateGoods 
      from wh_InWarehouse a,wh_InWarehouseDetail c,#tmpGoodsListInfo_2 b
      where a.cStoreNo=@cStoreNo and a.cSheetno=c.cSheetno and c.cGoodsNo=b.GoodsNo_Pdt
      group by b.GoodsNo_Pdt
      
      
      UPDATE a
      set a.MaxSaleDAte=b.MaxSaleDAte
      from #tmpGoodsListInfo_2 a,#tmpMaxSaleDateGoods b
      where a.GoodsNo_Pdt=b.GoodsNo_Pdt
      
	  UPDATE a
      set a.MaxOrderDAte=b.MaxOrderDAte
      from #tmpGoodsListInfo_2 a,#tmpMaxOrderDateGoods b
      where a.GoodsNo_Pdt=b.GoodsNo_Pdt
      
 
		 
				 if(select object_id('tempdb..#tmpGoodsListInfo_2Last')) is not null  drop table #tmpGoodsListInfo_2Last     
						
				  select GoodsNo_Pdt,cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.cGoodsTypeno,a.cGoodsTypename,
				            b.cGroupTypeNo,b.cGroupTypeName, 
							BeginDate,BeginQty=ISNULL(BeginQty,0), 
							EndDate,EndQty=isnull(EndQty,0), 
						    xsQty=isnull(xsQty,0),	MaxSaleDAte,MaxOrderDAte,
						    iDay=(DATEDIFF (Day,isnull(MaxOrderDAte,'1900-01-01'),@dDateBgn))+1	 
							into #tmpGoodsListInfo_2Last
							from #tmpGoodsListInfo_2 a,#temp_Goods b
							where a.GoodsNo_Pdt=b.cGoodsNo and a.cBarcode not like '%X%'
  

					select cGoodsno=GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,
				            cGroupTypeNo,cGroupTypeName, 
							BeginDate,BeginQty, 
							EndDate,EndQty, 
						    xsQty ,MaxSaleDAte,MaxOrderDAte
						    from   #tmpGoodsListInfo_2Last
						     where EndQty<=0 and iDay>=@IDay			 
					       order by GoodsNo_Pdt
 
			 /*删除临时表*/
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
      
	  if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	  if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	   if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	   if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
	    if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
	    if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	    if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null drop table #tmpGoodsListInfo_2


GO
