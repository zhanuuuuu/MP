
CREATE  view v_Goods_Relation
as
  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  from t_Goods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo

GO
