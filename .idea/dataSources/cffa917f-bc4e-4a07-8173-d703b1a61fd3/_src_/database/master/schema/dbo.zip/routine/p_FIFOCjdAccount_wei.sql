
CREATE proc [dbo].[p_FIFOCjdAccount_wei]
@cSheetNo varchar(50),
@operNo varchar(30),
@operName varchar(30),
@Ret_goodsno varchar(50) output
as

--declare @cSheetNo varchar(50)
--declare @operNo varchar(30)
--declare @operName varchar(30)
--declare @Ret_goodsno varchar(30)
--select @cSheetNo='CJ20104002-000006'

declare @dDate datetime
declare @cSupNo varchar(50)
declare @cGoodsNo varchar(50)
declare @fQty money
declare @fNoTaxPrice money
declare @fNoTaxMoney money
set @Ret_goodsno=''
begin try
 begin tran

	--差价单列表
	if (select object_id('tempdb..#tmpcjd_FIFOCJDACCOUNT'))is not null
	drop table #tmpcjd_FIFOCJDACCOUNT
/*	
	select b.dDate,b.cSupplierNO,a.cGoodsNo,a.fQuantity,a.fNoTaxPrice,a.fNoTaxMoney
	into #tmpcjd_FIFOCJDACCOUNT
	from wh_DiffPriceWarehouseDetail a,wh_DiffPriceWarehouse b
	where a.csheetno=b.csheetno 
	and b.csheetno=@cSheetNo 
*/	
	select b.dDate,b.cSupplierNO,a.cGoodsNo,a.fQuantity,a.fNoTaxPrice,a.fNoTaxMoney,a.fPrice_diff
	into #tmpcjd_FIFOCJDACCOUNT
  from
  (    ---------------处理同一差价单中 同一单品出现多次差价的问题
		 select cSheetno,iLineNo=min(iLineNo), cGoodsNo,cGoodsName,cProductSerno=null,cUnit,cSpec,  
		 dProduct=null,fTimes=null,fQuantity=SUM(fQuantity),fInPrice=SUM(fInMoney)/SUM(fQuantity),fInMoney=SUM(fInMoney),fTaxrate=null,  
		 fTaxPrice=null,fTaxMoney=null,fNoTaxPrice=SUM(fNoTaxMoney)/SUM(fQuantity),fNoTaxMoney=SUM(fNoTaxMoney),  
		 fPrice_diff=SUM(fMoney_diff)/SUM(fQuantity),fMoney_diff=SUM(fMoney_diff)  
		 from wh_DiffPriceWarehouseDetail   
		 group by cSheetno,cGoodsNo,cGoodsName,cUnit,cSpec  
		 having SUM(fQuantity)>0 
	)	a ,wh_DiffPriceWarehouse b
	where a.csheetno=b.csheetno 
	and b.csheetno=@cSheetNo 
		
    --转换为最小商品
	if (select object_id('tempdb..#tmpUpdate'))is not null
	drop table #tmpUpdate
	select a.cGoodsNO,b.cGoodsNo_MinPackage,fQty_minPackage=isnull(b.fQty_minPackage,1)
	into #tmpUpdate
	from #tmpcjd_FIFOCJDACCOUNT a, t_goods b
	where a.cgoodsno=b.cgoodsno
	and isnull(b.cGoodsNo_MinPackage,b.cGoodsNo)<>b.cGoodsNo

	update a
	set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage,
	a.fPrice_diff=case when isnull(b.fQty_minPackage,0)<>0 then a.fPrice_diff/(b.fQty_minPackage*1.0) else a.fPrice_diff end,----计算最小单位差价
	a.fNoTaxPrice=case when isnull(a.fQuantity,0)<>0 then a.fNoTaxMoney/(a.fQuantity*b.fQty_minPackage*1.0) else a.fNoTaxPrice end
	from #tmpcjd_FIFOCJDACCOUNT a,#tmpUpdate b
	where a.cGoodsNo=b.cGoodsNo
	
	    --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_GoodsList')
  		begin
  		  close Cur_GoodsList
          deallocate Cur_GoodsList
  		end 
	
    --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_IserNOList')
  		begin
  		  close Cur_IserNOList
          deallocate Cur_IserNOList
  		end 
  		
	declare Cur_GoodsList cursor for
	select dDate,cSupplierNO,cGoodsNo,fQuantity,fNoTaxPrice,fNoTaxMoney,fPrice_diff
	from #tmpcjd_FIFOCJDACCOUNT

	declare @fPrice_diff money
	
	open Cur_GoodsList
	fetch next from Cur_GoodsList into @dDate,@cSupNo,@cGoodsNo,@fQty,@fNoTaxPrice,@fNoTaxMoney,@fPrice_diff
	while @@FETCH_STATUS=0
	begin
	  if(select object_id('tempdb..#Cur_goodsiSerno'))is not null
	  drop table #Cur_goodsiSerno
	  create table #Cur_goodsiSerno
	  (
		iSerNo bigint,
		fPrice money,
		fQty_diff money,
		fPrice_diff money
	  )
	  --成本表
	  declare  Cur_IserNOList  Cursor for 
	  select iSerNo,fPrice_in,fQty_In
	  from t_wh_form_log
	  where isnull(iattribute,999)=0
	  and cSupplierNO=@cSupNo
	  and dDateTime<=@dDate
	  and cGoodsNO=@cGoodsNo 
	  and (isnull(bChangePrice,0)=0 or (isnull(bChangePrice,0)=1 and isnull(fQty_Diff,0)<fQty_In))
	  and  fPrice_in>@fNoTaxPrice
	  order by fQty_In desc,dDateTime desc
	  
	  declare @iserNO bigint
	  declare @price money
	  declare @fQty_In money
	  declare @tmp_Qty money
	  select @iserNO=0,@price=0,@fQty_In=0,@tmp_Qty=@fQty
	  open Cur_IserNOList
	  fetch next from Cur_IserNOList into @iserNO,@price,@fQty_In
	  if isnull(@iserNO,'')=''
	  begin
		   close Cur_IserNOList
		   deallocate Cur_IserNOList
		   close Cur_GoodsList
		   deallocate Cur_GoodsList
		   rollback tran
		   set @Ret_goodsno=@cGoodsNo
		   return @Ret_goodsno
	  end
	  while @@fetch_status=0
	  begin
			if (@tmp_Qty>0)
      begin
				if (@tmp_Qty<=@fQty_In)
				begin
					 insert into #Cur_goodsiSerno
					 (
					 iSerNo, fPrice,fQty_diff,fPrice_diff
					 )
					 values
					 (
						@iserNO,@price,@tmp_Qty,@fPrice_diff
					 )
					 set @tmp_Qty=@tmp_Qty-@fQty_In
				end else
				begin
					 insert into #Cur_goodsiSerno
					 (
					 iSerNo, fPrice,fQty_diff,fPrice_diff
					 )
					 values
					 (
						@iserNO,@price,@fQty_In,@fPrice_diff
					 )
					 set @tmp_Qty=@tmp_Qty-@fQty_In
				end
			end
			fetch next from Cur_IserNOList into @iserNO,@price,@fQty_In
	  end
	  close Cur_IserNOList
	  deallocate Cur_IserNOList
	  
	   --更新成本表
		insert into Pos_Cost_distribute.dbo.t_wh_form_history_log
		(
		  iserNO,cGOodsNo,fPrice_changeBefore,fprice_changeAfter,
		  cOperNo,cOperName,dDateTime,iType
		)
		select a.iserNO,a.cGOodsNo,a.fPrice_in,fprice_changeAfter=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In,
		--(fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in),
		@operNo,@operName,getdate(),0
		from t_wh_form_log a,#Cur_goodsiSerno b
		where a.cGoodsNO=@cGoodsNo and  a.cSupplierNo=@cSupNo and a.iSerno=b.iSerNo
		--and iserno in(select iSerNo from #Cur_goodsiSerno)
		    
/*
		update t_wh_form
		set fPrice_in=(fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in),fMoney_in=((fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in))*fqty_in,
		fPrice_out=(fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in),fMoney_Out=((fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in))*fqty_Out,
		fPrice_Left=(fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in),fMoney_Left=((fMoney_in+@fNoTaxMoney)/(@fQty+fQty_in))*fqty_Left,
		bChangePrice=1,cChangePriceBillNo=@cSheetNo
		where cGoodsNO=@cGoodsNo and  cSupplierNo=@cSupNo
		and iserno in(select iSerNo from #Cur_goodsiSerno)
*/    
		update a
		set a.fPrice_in=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In,
		a.fMoney_in=a.fMoney_in-b.fPrice_diff*b.fQty_diff,
		a.fPrice_out=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In,
		a.fMoney_Out=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In*a.fqty_Out,
		a.fPrice_Left=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In,
		a.fMoney_Left=(a.fMoney_in-b.fPrice_diff*b.fQty_diff)/a.fQty_In*a.fqty_Left,
		a.bChangePrice=1,a.cChangePriceBillNo=@cSheetNo,
		a.fQty_diff=isnull(b.fQty_diff,0)+ISNULL(a.fQty_diff,0),
		a.差价数量=ISNULL(a.差价数量,0)+ISNULL(b.fQty_diff,0),
		a.差价金额=ISNULL(a.差价金额,0)+b.fPrice_diff*b.fQty_diff
    from t_wh_form_log a,#Cur_goodsiSerno b
		where a.cGoodsNO=@cGoodsNo and  a.cSupplierNo=@cSupNo and a.iSerno=b.iSerno
		and a.fQty_In<>0
		--and iserno in(select iSerNo from #Cur_goodsiSerno)

        update a
        set a.fPrice_Cost=b.fPrice_in,a.fMoney_cost=b.fPrice_in*a.fQty_Cost
        from Pos_Cost_distribute.dbo.t_cost_distribute_log a,t_wh_form_log b,#Cur_goodsiSerno c
        where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo and a.iSerNo=c.iSerNo 
        and a.cGoodsNo=@cGoodsNo

	    

	  fetch next from Cur_GoodsList into @dDate,@cSupNo,@cGoodsNo,@fQty,@fNoTaxPrice,@fNoTaxMoney,@fPrice_diff

	end

	  
	  update wh_DiffPriceWarehouse
	  set bAccount=1,bAccount_log=1
	  where cSheetNo=@cSheetNo
	close Cur_GoodsList
	deallocate Cur_GoodsList
    
commit tran
  set @Ret_goodsno=''
  return @Ret_goodsno
end try
begin catch
   rollback tran
end catch
GO
