/*


p_CatchDataFromPos 'chen','2011-05-13'


*/

create Procedure p_CatchDataFromPos
@cPosName varchar(32),
@cDate varchar(32)
as
begin
  
exec('
    declare @cWhNo varchar(32)
    select @cWhNo=cWHno from t_Posstation where PosName='''+@cPosName+'''

     if (select object_id(''tempdb..#temp_pos_jiesuan'' ) )is not null  
     drop table #temp_pos_jiesuan
     
     if (select object_id(''tempdb..#temp_Pos_SaleSheetDetail'' ) )is not null  
     drop table #temp_Pos_SaleSheetDetail

     select *  into  #temp_pos_jiesuan from '+@cPosName+'.Posstation.dbo.pos_jiesuan
     where zdriqi='''+@cDate+'''
     
     delete from #temp_pos_jiesuan
     where sheetno in (select sheetno from pos_day.dbo.jiesuan where zdriqi='''+@cDate+''')
     or sheetno in (select sheetno from dbo.jiesuan where zdriqi='''+@cDate+''')
    
     insert into Pos_Day.dbo.jiesuan (cWHno,detail,storevalue,orientmoney,leftmoney,  
     netjiecun,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,  
     sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,bpost)  
     select @cWhNo, detail,storevalue,orientmoney,leftmoney,  
     netjiecun,jiaozhangtime,jiaozhang,shouyinyuanno,shouyinyuanmc,  
     sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,bpost=1  
     from #temp_pos_jiesuan 
     
			insert into dbo.jiesuan
			(
				sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,jiaozhang,
				jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
				shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,
				detail,bPost,tag_daily,cWHno
			)
			select distinct a.sheetno,a.jstype,a.mianzhi,a.zhekou,a.zhaoling,a.shishou,a.jstime,a.zdriqi,a.jiaozhang,
				a.jiaozhangtime,a.jiaozhangdate,a.shouyinyuanno,a.shouyinyuanmc,a.jiaokuantime,
				a.shoukuanno,a.shoukuanname,a.netjiecun,a.orientmoney,a.leftmoney,a.storevalue,
				a.detail,a.bPost,a.tag_daily,cWhno=@cWhNo
			from Pos_Day.dbo.jiesuan as a
			where a.zdriqi='''+@cDate+''' and a.sheetno in (select sheetno from #temp_pos_jiesuan)     

     update '+@cPosName+'.posstation.dbo.pos_jiesuan set bpost=1
     where zdriqi='''+@cDate+''' and sheetno in (select sheetno from #temp_pos_jiesuan)  

     select cWHno=@cWHno,cSaleSheetno,iSeed,cGoodsNo ,cGoodsName,cBarcode,cOperatorno,  
     cOperatorName,cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,  
     fPrice,fNormalSettle,bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,  
     fAgio,fLastSettle0,fLastSettle,cManager,cManagerno,dSaleDate,cSaleTime,  
     dFinanceDate,cWorkerno,cWorker,bPost,bChecked,cCheckNo,dCheck,cVipNo,  
     bHidePrice,bHideQty ,bWeight,  
     fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited,fVipScore_cur 
     into #temp_Pos_SaleSheetDetail 
     from '+@cPosName+'.Posstation.dbo.pos_SaleSheetDetail
     where dSaleDate='''+@cDate+'''
     
     delete from #temp_Pos_SaleSheetDetail 
     where cSaleSheetno in (select cSaleSheetno from pos_day.dbo.t_SaleSheetDetail where dSaleDate='''+@cDate+''')
     or cSaleSheetno in (select cSaleSheetno from t_SaleSheetDetail where dSaleDate='''+@cDate+''')


     insert into pos_day.dbo.t_SaleSheetDetail(  
     fVipScore_cur,cWHno,cSaleSheetno,iSeed,cGoodsNo ,cGoodsName,cBarcode,cOperatorno,  
     cOperatorName,cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,  
     fPrice,fNormalSettle,bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,  
     fAgio,fLastSettle0,fLastSettle,cManager,cManagerno,dSaleDate,cSaleTime,  
     dFinanceDate,cWorkerno,cWorker,bPost,bChecked,cCheckNo,dCheck,cVipNo,  
     bHidePrice,bHideQty ,bWeight,  
     fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited   
     )  
     select fVipScore_cur,cWHno,cSaleSheetno,iSeed,cGoodsNo ,cGoodsName,cBarcode,cOperatorno,  
     cOperatorName,cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,  
     fPrice,fNormalSettle,bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,  
     fAgio,fLastSettle0,fLastSettle,cManager,cManagerno,dSaleDate,cSaleTime,  
     dFinanceDate,cWorkerno,cWorker,bPost=1,bChecked,cCheckNo,dCheck,cVipNo,  
     bHidePrice,bHideQty ,bWeight,  
     fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited  
     from #temp_Pos_SaleSheetDetail 

			insert into	dbo.t_SaleSheetDetail
			(
				cSaleSheetno,iSeed,cGoodsNo,cGoodsName,cBarCode,cOperatorno,cOperatorName,
				cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,fPrice,fNormalSettle,
				bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,fAgio,fLastSettle0,fLastSettle,
				cManager,cManagerno,dSaleDate,cSaleTime,dFinanceDate,cWorkerno,cWorker,bPost,
				bChecked,cCheckNo,dCheck,cVipNo,bBalance,jiesuanno,cStationNo,tag_daily,cWHno,
        bHidePrice,bHideQty ,bWeight,
        fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited,fVipScore_cur 

			)
			select distinct a.cSaleSheetno,a.iSeed,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cOperatorno,a.cOperatorName,
				a.cVipCardno,a.bAuditing,a.cChkOperno,a.cChkOper,a.bSettle,a.fVipScore,a.fPrice,a.fNormalSettle,
				a.bVipPrice,a.fVipPrice,a.bVipRate,a.fVipRate,a.fQuantity,a.fAgio,a.fLastSettle0,a.fLastSettle,
				a.cManager,a.cManagerno,a.dSaleDate,a.cSaleTime,a.dFinanceDate,a.cWorkerno,a.cWorker,a.bPost,
				a.bChecked,a.cCheckNo,a.dCheck,a.cVipNo,a.bBalance,a.jiesuanno,a.cStationNo,a.tag_daily,a.cWhno,
        a.bHidePrice,a.bHideQty ,a.bWeight,
        a.fNormalVipScore ,a.bExchange ,a.fSupRatio_exchange,a.bPresent,a.bSend,a.bLimited,a.fVipScore_cur
			from Pos_Day.dbo.t_SaleSheetDetail as a
			where a.dSaleDate='''+@cDate+''' and a.cSaleSheetno in (select cSaleSheetno from #temp_Pos_SaleSheetDetail)     

     update '+@cPosName+'.posstation.dbo.Pos_SaleSheetDetail set bpost=1
     where dSaleDate='''+@cDate+''' and cSaleSheetno in (select cSaleSheetno from #temp_Pos_SaleSheetDetail)  
      
  ')   
end
GO
