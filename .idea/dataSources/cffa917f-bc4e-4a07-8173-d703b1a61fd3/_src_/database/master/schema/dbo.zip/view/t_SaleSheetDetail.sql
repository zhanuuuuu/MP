 






CREATE view [dbo].[t_SaleSheetDetail]
as
select dSaleDate, cSaleSheetno, iSeed, cStoreNo, cGoodsNo, cGoodsName, 
cBarCode, cOperatorno, 
cOperatorName, cVipCardno, bAuditing, cChkOperno, cChkOper, bSettle, 
fVipScore, fPrice, fNormalSettle, bVipPrice, fVipPrice, bVipRate, fVipRate,
 fQuantity, fAgio, fLastSettle0, fLastSettle, cManager, cManagerno, cSaleTime, 
 dFinanceDate, cWorkerno, cWorker, bPost, bChecked, cCheckNo, dCheck, cVipNo,
  bBalance, jiesuanno, cStationNo, tag_daily, bGroupSale, cWHno, bHidePrice,
   bHideQty, bWeight, fNormalVipScore, bExchange, fSupRatio_exchange, bPresent,
    bSend, iPresentTimes, bLimited, fVipScore_cur, bSetMoneyUsed, bDownCurWH, bSent,
     bScoreRetMoney, b_ftp, cStoreName,cBanci,cBanci_ID,iLineNo_Banci,dUpTime,bOnline,posid
from Pos_Sale.dbo.t_SaleSheetDetail with (nolock)


GO
