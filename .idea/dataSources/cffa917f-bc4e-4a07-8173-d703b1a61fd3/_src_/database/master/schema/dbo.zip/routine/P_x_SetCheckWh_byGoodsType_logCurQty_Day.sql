 
/*    

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods   where  cGoodsNo in ('216247')-- or cgoodsno='2100226' or cgoodsno='210122'
--or cgoodsno in('210223','210231','210261','210423')

	if  (select object_id('tempdb..#tempSupNo')) is not null
	 drop table #tempSupNo
	select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier

   if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	select distinct cGoodsNo into #temp_Goods 
	from #tempSupNo a,t_Goods b
	where a.cSupplierNo=b.cSupNo
	
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
    
if (select OBJECT_ID('#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods   where cGoodsNo in ('0110681','0110028','0110683','0110184')

 

exec [P_x_SetCheckWh_byGoodsType_logCurQty_Day]
'000','2017-2-19','2017-2-19','00'  

select * from  #temp_goodsKuCurQty

*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_byGoodsType_logCurQty_Day]
@cStoreNo varchar(32),
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32)--,/*是仓库No*/
--@bJiaGong bit
as 

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsNo into #tmpCostGoodsList from #temp_Goods

---  print '10000000   '+dbo.getTimeStr(GETDATE())
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
select distinct a.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1 into  #tmp_WhGoodsList_1  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1   ---- 大包装
union all
select distinct a.cGoodsNo ,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1   --- 小包装
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''  -- 获取大包装下的笑包装
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1

CREATE INDEX IX_WhGoodsList_1  ON #tmp_WhGoodsList_1(cGoodsNo)

 --- print '11000000   '+dbo.getTimeStr(GETDATE())
 
if (select object_id('tempdb..#tmp_WhGoodsListCur'))is not null drop table #tmp_WhGoodsListCur
select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage,bbox 
into #tmp_WhGoodsListCur from  #tmp_WhGoodsList_1

 
 CREATE INDEX IX_WhGoodsListCur  ON #tmp_WhGoodsListCur(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32),@Rdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@Rdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno


if(select object_id('tempdb..#temp_WhFrombeginCur')) is not null drop table #temp_WhFrombeginCur
if(select object_id('tempdb..#temp_WhFromendCur')) is not null drop table #temp_WhFromendCur
CREATE TABLE #temp_WhFrombeginCur ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money)
CREATE TABLE #temp_WhFromendCur   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,
  fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money,
  期初盘点 money,期末盘点 money,期初账面库存 money,期末账面库存 money,fAvgMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock)   where cStoreNo='''+@cStoreNo+'''  ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

/*结转表中取数据*/

declare @dDate1 datetime
declare @dDate2 datetime
declare @BgndDate1 datetime
 declare @i int
set @i=1
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
					set @BgndDate1=@dDate1
					--set @i=0
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
					set @BgndDate1=@dDate1
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=0
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 	 
		set @BgndDate1=@maxWhdDate+1
		
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd

 
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
 --  print '12000000   '+dbo.getTimeStr(GETDATE())
   
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn)  


declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)

 
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
insert into #temp_WhFromendCur  ([cGoodsNo],[cWHno]) 
select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsListCur 

CREATE INDEX IX_temp_WhFromendCur  ON #temp_WhFromendCur(cGoodsNo)
if @Y_1<>@Y1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@maxWhdDate) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@maxWhdDate) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
    
	if(@bY1<>@eY1)
	begin 
	    set @tj='1'
	end else
	begin
	    if @bM1=@eM1
	    begin
	    exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select a.cgoodsno,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+',
		fQty0=b.fQty_010131,fMoney0=b.fMoney_010131				
		into #temp_Wh_Goods_end
		from #temp_WhFromendCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cgoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1) ,
		fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno
		 
		update a 
		set a.期末库存=b.fQty1,
			a.期初库存=b.fQty0,
			a.期初账面库存=isnull(b.fQty0,0), 
			a.期末账面库存=isnull(b.fQty1,0),  	 
			a.fmoney_left=b.fMoney1,
			a.fPrice_Avg=case when isnull(b.fQty1,0)<>0 then 
			   ISNULL(b.fMoney1,0)/isnull(b.fQty1,0) else 0 end		
			from #temp_WhFromendCur a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo  		  		  	  
	     
		') 
		end else
		begin
		  set @tj='1'
		end
	end
	if @tj='1'
	begin
	  insert into #temp_WhFrombeginCur([cGoodsNo],[cWHno]) 
		select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsListCur 
		CREATE INDEX IX_temp_WhFrombeginCur  ON #temp_WhFrombeginCur(cGoodsNo)

		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select a.cgoodsno,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from #temp_WhFrombeginCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno	

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombeginCur a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo   
			') 

		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cgoodsno,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #temp_WhFromendCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromendCur a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo    		  	  
		 
			')
		    
		--- 结束日期数据-（开始日期-1）数据 得出时间段数据    
		update a 
		set  
		a.期初库存=isnull(b.期初库存,0), 
		a.期末库存=isnull(a.期末库存,0), 
		a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
		a.期初账面库存=isnull(b.期初库存,0), 
		a.期末账面库存=isnull(a.期末库存,0),  
		a.fPrice_Avg=case when isnull(a.期末库存,0)<>0 then 
		ISNULL(a.fMoney_left,0)/isnull(a.期末库存,0) else 0 end,
		a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
		a.fMoney_left=ISNULL(a.fMoney_left,0)
		from #temp_WhFromendCur a,#temp_WhFrombeginCur b
		where a.cGoodsNo=b.cGoodsNo 
	end
end else
begin
 if @M1=@M_1
 begin
 exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
	select a.cgoodsno,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+',
	fQty0=b.fQty_'+@MMDAY_1+',fMoney0=b.fMoney_'+@MMDAY_1+' 				
	into #temp_Wh_Goods_end
	from #temp_WhFromendCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
  
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	select cgoodsno,fQty1=sum(fQty1), fMoney1=sum(fMoney1) ,
	fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_end
	from  #temp_Wh_Goods_end
	group by cgoodsno
	 
    update a 
	set a.期末库存=b.fQty1,
	    a.期初库存=b.fQty0,
	    a.期初账面库存=isnull(b.fQty0,0), 
	    a.期末账面库存=isnull(b.fQty1,0),  	 
		a.fmoney_left=b.fMoney1,
		a.fPrice_Avg=case when isnull(b.fQty1,0)<>0 then 
	       ISNULL(b.fMoney1,0)/isnull(b.fQty1,0) else 0 end		
		from #temp_WhFromendCur a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  		  		  	  
     
    ')
  end else
  begin
        insert into #temp_WhFrombeginCur([cGoodsNo],[cWHno]) 
		select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsListCur 
		CREATE INDEX IX_temp_WhFrombeginCur0  ON #temp_WhFrombeginCur(cGoodsNo)

		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select a.cgoodsno,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from #temp_WhFrombeginCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno	

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombeginCur a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo   
			') 

		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cgoodsno,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #temp_WhFromendCur a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromendCur a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo    		  	  
		 
			')
		    
		--- 结束日期数据-（开始日期-1）数据 得出时间段数据    
		update a 
		set  
		a.期初库存=isnull(b.期初库存,0), 
		a.期末库存=isnull(a.期末库存,0), 
		a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
		a.期初账面库存=isnull(b.期初库存,0), 
		a.期末账面库存=isnull(a.期末库存,0),  
		a.fPrice_Avg=case when isnull(a.期末库存,0)<>0 then 
		ISNULL(a.fMoney_left,0)/isnull(a.期末库存,0) else 0 end,
		a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
		a.fMoney_left=ISNULL(a.fMoney_left,0)
		from #temp_WhFromendCur a,#temp_WhFrombeginCur b
		where a.cGoodsNo=b.cGoodsNo 
		
  end   
end
 -- print '13000000   '+dbo.getTimeStr(GETDATE())
update a
set a.fPrice_Avg=case when a.fPrice_Avg=0 then b.fCKPrice else a.fPrice_Avg end
from #temp_WhFromendCur a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and b.bStorage=1 and isnull(a.fPrice_Avg,0)=0
 		
 -- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
	
 
 -- print '14000000   '+dbo.getTimeStr(GETDATE())
--- 取记账之前的数据... 
	 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	create table #temp_ReadyKucun(
	cGoodsNo varchar(32),cUnitedNo varchar(32),BgnQty money,EndQty money,
	xsQty money,fEndQuantity_Diff money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney	 money)

if @maxWhdDate<@dDateEnd
begin 
    
  if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	select distinct b.cGoodsNo,b.cSupNo into #tmpPloyOfGoodsinfo  
	from #tmp_WhGoodsListCur a,t_goods b
	where a.cgoodsno=b.cgoodsno
	and ISNULL(b.bStorage,0)=1
	and a.cGoodsNo is not null
	
	CREATE INDEX IX_temp_PloyOfGoodsinfo  ON #tmpPloyOfGoodsinfo(cGoodsNo)

   declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select isnull(MAX(dDate),'2000-01-01') from t_Daily_history  where  cStoreNo=@cStoreNo and  cWHno=@cWHno)
    if @dMaxDailyDate>@dDate2
    begin
      set @dMaxDailyDate=@dDate2
    end

---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	
	    select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
 		fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,t_SaleSheet_Day b 
		 with (nolock) 
		where b.dSaleDate between @BgndDate1 and @dDate2 and a.cGoodsNo=b.cGoodsNo
		and  b.cStoreNo=@cStoreNo and ISNULL(b.cWhNo,'')=@cWhNo 
		union all
		select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
		fQuantity=isnull(b.fQuantity,0),fMoney=isnull(b.fLastSettle,0)
		from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b		
		where b.dSaleDate>=@BgndDate1 and b.dSaleDate between (@dMaxDailyDate+1) and @dDate2 and a.cGoodsNo=b.cGoodsNo 
		and  b.cStoreNo=@cStoreNo and ISNULL(b.cWhNo,'')=@cWhNo	
		
		select dDateTime=b.dSaleDate,a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo 
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束
		
	--配送出库单统计开始 
		union all
		select c.dDate,a.cGoodsno,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_cStoreOutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_cStoreOutWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and isnull(bShip,0)=1
		and ISNULL(c.bRestOut,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--配送出库单统计结束

		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--门店退货。  
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cClientNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_cStoreReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_cStoreReturnGoods c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo 
		
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo 
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
	    union all
		select @dDate2,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
        
		if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
		select distinct a.cGoodsNO,b.cGoodsNo_minPackage,b.fQty_minPackage into  #tmpPackGoodsList  
		from #tmpPloyOfGoodsinfo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(b.cGoodsNo_minPackage,'')<>''
		and ISNULL(b.bStorage,0)=1
         
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money),
		 
		xsQty=cast(0 as money),avginPrice=cast(0 as money)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsNo,cWhNo

 
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 
	 
		--更新销售数量
		update a
		set a.xsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDate1 and @dDate2 and (iAttribute=20 or iAttribute=21)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		 --平均进价
		 /*
		if (select OBJECT_ID('tempdb..#tmpAvgCost'))is not null drop table #tmpAvgCost
		select cGoodsNo,cWhNo,avgCost=avg(fPrice_in)
		into #tmpAvgCost
		from T_WH_Form_Log
		where dDateTime <=@dDate2 and iAttribute=0
		group by cGoodsNo,cWhNo
 
		update a
		set a.avginPrice=b.avgCost
		from #tmpGoodsListInfo_1 a,#tmpAvgCost b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo
		
		*/

		update a
		set a.avginPrice=case when isnull(b.fckPrice,0)<>0 
		then b.fCKPrice else  
		                   case when ISNULL(b.fPrice_Contract,0)<>0 
		                        then ISNULL(b.fPrice_Contract,0) 
		                        else 0 end end
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(a.avginPrice,0)=0
		

	   insert into   #temp_ReadyKucun(cGoodsNo, BgnQty, EndQty, xsQty,avgInPriceMoney)
	   select cGoodsNo, BeginQty, EndQty,xsQty,avginPrice*EndQty
	   from #tmpGoodsListInfo_1    
   end
 
   if @i=0 
   begin 
        update #temp_WhFromendCur
		set  期初库存=期末库存
   end

  --print '14-1000000   '+dbo.getTimeStr(GETDATE())

if(select object_id('tempdb..#templast_pd01')) is not null drop table #templast_pd01
select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
into #templast_pd01
from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
on a.cCheckTaskNo=b.cCheckTaskNo   and b.cStoreNo=@cStoreNo 
where b.dCheckTask<@dDateBgn  
and b.cWhNo=@cWHno  
group by a.cGoodsNo

update a
set  a.cGoodsNo=b.cGoodsNo_minPackage,
a.fQuantity_Diff=case when isnull(b.fQty_minPackage,1)=0 then a.fQuantity_Diff else a.fQuantity_Diff*b.fQty_minPackage end 
from #templast_pd01 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

 

if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
select a.cGoodsno,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fmoney_Diff) into #templast_pd0 
from #templast_pd01 a,(select distinct cGoodsNo from #tmp_WhGoodsListCur)  b
where a.cGoodsNo=b.cGoodsNo

group by a.cGoodsNo



--select * from  #templast_pd0
----------期末日期的前的所有盘点差异。
if(select object_id('tempdb..#templast_pd11')) is not null drop table #templast_pd11
select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
into #templast_pd11
from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
on a.cCheckTaskNo=b.cCheckTaskNo  and b.cStoreNo=@cStoreNo 
where b.dCheckTask between @dDateBgn and @dDateEnd
and b.cWhNo=@cWHno  
group by a.cGoodsNo
order by a.cGoodsNo

update a
set  a.cGoodsNo=b.cGoodsNo_minPackage,
a.fQuantity_Diff=case when isnull(b.fQty_minPackage,1)=0 then a.fQuantity_Diff else a.fQuantity_Diff*b.fQty_minPackage end 
from #templast_pd11 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

 

if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
select a.cGoodsno,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fmoney_Diff) into #templast_pd1 
from #templast_pd11 a,(select distinct cGoodsNo from #tmp_WhGoodsListCur)  b
where a.cGoodsNo=b.cGoodsNo
group by a.cGoodsNo

 

if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0) 
into #templast_pdcGoodsNo
from #templast_pd0
union all
select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0) 
from #templast_pd1

 
----- 修改盘点期初数量
update a
set a.BeginQty=b.fQuantity_Diff
from #templast_pdcGoodsNo a,#templast_pd0 b
where a.cGoodsNo=b.cGoodsNo
----- 修改盘点期末数量
update a
set a.EndQty=b.fQuantity_Diff,
a.fmoney_Diff=isnull(b.fmoney_Diff,0)
from #templast_pdcGoodsNo a,#templast_pd0 b
where a.cGoodsNo=b.cGoodsNo

update a
set a.EndQty=isnull(a.EndQty,0)+isnull(b.fQuantity_Diff,0),
a.fmoney_Diff=isnull(a.fmoney_Diff,0)+isnull(b.fmoney_Diff,0)
from #templast_pdcGoodsNo a,#templast_pd1 b
where a.cGoodsNo=b.cGoodsNo	
 
update a
set a.期初库存=isnull(a.期初库存,0)+isnull(b.BeginQty,0),
a.期末库存=isnull(a.期末库存,0)+isnull(b.EndQty,0),
a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.BeginQty,0)*a.fPrice_Avg,
a.fMoney_left=ISNULL(a.fMoney_left,0),
a.期初账面库存=isnull(a.期初库存,0),
a.期末账面库存=isnull(a.期末库存,0),
a.期初盘点=isnull(b.BeginQty,0),
a.期末盘点=isnull(b.EndQty,0),
a.fAvgMoney_Diff=isnull(b.fmoney_Diff,0)
from #temp_WhFromendCur a,#templast_pdcGoodsNo b
where a.cGoodsNo=b.cGoodsNo

 
 -- print '15000000   '+dbo.getTimeStr(GETDATE())
 
update b
set   b.期初库存=isnull(a.BgnQty,0)+isnull(b.期初库存,0),
  b.期末库存=isnull(a.EndQty,0)+isnull(b.期末库存,0),     
  b.fmoney_cost=isnull(b.fmoney_cost,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
  b.fMoney_left=isnull(b.fMoney_left,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
  b.期初账面库存=isnull(b.期初账面库存,0)+isnull(a.BgnQty,0),
  b.期末账面库存=isnull(b.期末账面库存,0)+isnull(a.EndQty,0)
from #temp_ReadyKucun a left join #temp_WhFromendCur b
on a.cGoodsNo=b.cGoodsNo
where b.cGoodsNo is not null 	
	

insert into #temp_WhFromendCur(
cGoodsNo, 期初库存, 期末库存,fCKPriceMoney,fNormalPriceMoney,fmoney_left
)
select a.cGoodsNo,a.BgnQty,a.EndQty,a.fCKPriceMoney,a.fNormalPriceMoney,a.avgInPriceMoney
from #temp_ReadyKucun a left join #temp_WhFromendCur b
on a.cGoodsNo=b.cGoodsNo
where b.cGoodsNo is  null	


/*差价2014-10-18*/
---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  
drop table #temp_wh_DiffPriceWarehouseDetail
select a.cGoodsNo,b.cWhNo,fMoney_diff=sum(a.fMoney_diff),fQuantity=sum(a.fQuantity)
into #temp_wh_DiffPriceWarehouseDetail
from wh_DiffPriceWarehouseDetail a,wh_DiffPriceWarehouse b
where b.dDate<=@dDateEnd  and a.cSheetno=b.cSheetno  and b.cStoreNo=@cStoreNo 
group by a.cGoodsNo,b.cWhNo 

if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_diff '))is not null  
drop table #tmp_WhGoodsList_diff 
select distinct cGoodsNo,cwhno=@cWhNo into #tmp_WhGoodsList_diff from  #tmp_WhGoodsList_1 

if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null  
drop table #temp_wh_DiffPricecGoodsNo
select  a.cGoodsNo,a.cWhNo,a.fMoney_diff,a.fQuantity 
into #temp_wh_DiffPricecGoodsNo 
from #temp_wh_DiffPriceWarehouseDetail a,#tmp_WhGoodsList_diff b
where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cwhno

/*2014-10-02修改数量、大小包装*/
update a 
set a.cGoodsNo=b.cGoodsNo_minPackage,
 a.fQuantity=a.fQuantity*b.fQty_minPackage
from #temp_wh_DiffPricecGoodsNo  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsListCur where bbox=1) b
where a.cGoodsNo=b.cGoodsNo

 
if(select object_id('tempdb..#temp_wh_DiffPricecGoodsNo_21')) is not null 
drop table #temp_wh_DiffPricecGoodsNo_21		 
select  cGoodsNo,cWhNo,fMoney_diff=sum(fMoney_diff),fQuantity=sum(fQuantity)
into  #temp_wh_DiffPricecGoodsNo_21
from #temp_wh_DiffPricecGoodsNo 
group by cGoodsNo,cWhNo


update a set a.fMoney_left=case when isnull(期末库存,0)<>0  then a.fMoney_left-b.fMoney_diff else 0 end
from #temp_WhFromendCur a,#temp_wh_DiffPricecGoodsNo b
where a.cGoodsNo=b.cGoodsNo

  /*2014-10-02修改数量、大小包装*/
update a 
set a.cGoodsNo=b.cGoodsNo_minPackage, 
a.本日库存数量=a.本日库存数量*b.fQty_minPackage,a.期初库存=a.期初库存*b.fQty_minPackage,
a.期末库存=ISNULL(a.期末库存,0)*b.fQty_minPackage,
a.期初账面库存=isnull(a.期初账面库存,0)*b.fQty_minPackage,
a.期末账面库存=isnull(a.期末账面库存,0)*b.fQty_minPackage,
a.期初盘点=isnull(a.期初盘点,0)*b.fQty_minPackage,
a.期末盘点=isnull(a.期末盘点,0)*b.fQty_minPackage	 
from #temp_WhFromendCur  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsListCur where bbox=1) b
where a.cGoodsNo=b.cGoodsNo

--   print '16000000   '+dbo.getTimeStr(GETDATE())

if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
select cGoodsNo,	 
本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 		   
fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost),
期初账面库存=SUM(期初账面库存),
期末账面库存=SUM(期末账面库存),
期初盘点=SUM(期初盘点),
期末盘点=SUM(期末盘点),
fAvgMoney_Diff=SUM(fAvgMoney_Diff)
into #temp_goodsKuCun_1
from   #temp_WhFromendCur
group by cGoodsNo
 
 
if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null 
drop table #tmpGoodsListInfo_2
select GoodsNo_Pdt=a.cGoodsNo,
BeginDate=@dDateBgn,BeginQty=sum(ISNULL(a.期初库存,0)),期初账面库存=SUM(a.期初账面库存),期初盘点=SUM(a.期初盘点),
EndDate=@dDateEnd,EndQty=sum(isnull(a.期末库存,0)),期末账面库存=SUM(a.期末账面库存),期末盘点=SUM(a.期末盘点),
 
fCKPrice=sum(isnull(b.fCKPrice,0)),fNormalPrice=isnull(b.fNormalPrice,0), 
fCKPriceMoney=sum(isnull(b.fCKPrice,0)*isnull(a.期末库存,0)),
fNormalPriceMoney=sum(isnull(fNormalPrice,0)*isnull(a.期末库存,0)),avgInPriceMoney=sum(isnull(fmoney_left,0)),
fAvgMoney_Diff=SUM(fAvgMoney_Diff)
into #tmpGoodsListInfo_2
from #temp_goodsKuCun_1 a,t_Goods b
where a.cgoodsno=b.cGoodsno 
group by a.cGoodsNo,b.fNormalPrice,b.fCKPrice

  -- print '17000000   '+dbo.getTimeStr(GETDATE())
 
/*
 2015-03-11 获取库存调整的商品
*/
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
      drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno=GoodsNo_Pdt into #tmpGoodsRelationKucun_0 from #tmpGoodsListInfo_2

declare @dDate01 datetime
set @dDate01=@dDateBgn+1
--------获取期初前调整库存数
exec('
if(select object_id(''tempdb..#tmpGoodsRelationKucun_1'')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fQty=sum(a.fQty),fMoney=sum(a.fMoney)
into #tmpGoodsRelationKucun_1
from  dbo.t_GoodsUpdateKucunDetail a,#tmpGoodsRelationKucun_0 b
where dDatetime<='''+@dDateBgn+''' and a.cgoodsno=b.cgoodsno  and a.cStoreNo='''+@cStoreNo+''' 
group by a.cGoodsNo

--------获取期末前调整库存数
if(select object_id(''tempdb..#tmpGoodsRelationKucun_2'')) is not null 
drop table #tmpGoodsRelationKucun_2
select a.cGoodsNo,fQty=sum(a.fQty),fMoney=sum(a.fMoney)
into #tmpGoodsRelationKucun_2
from  dbo.t_GoodsUpdateKucunDetail a,#tmpGoodsRelationKucun_0 b
where a.dDatetime between '''+@dDate01+''' and '''+@dDateEnd+''' and a.cgoodsno=b.cgoodsno
 and a.cStoreNo='''+@cStoreNo+''' 
group by a.cGoodsNo
		
---------修改期初获取库存
 update a 
 set a.BeginQty=isnull(a.BeginQty,0)+isnull(b.fQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.fQty,0),
 fCKPriceMoney=isnull(a.fCKPriceMoney,0)+isnull(b.fQty,0)*isnull(a.fCKPrice,0),
 fNormalPriceMoney=isnull(a.fNormalPriceMoney,0)+isnull(b.fQty,0)*isnull(a.fNormalPrice,0),
 avgInPriceMoney=isnull(a.avgInPriceMoney,0)+isnull(b.fMoney,0) 
 from #tmpGoodsListInfo_2 a,#tmpGoodsRelationKucun_1 b
 where a.GoodsNo_Pdt=b.cGoodsNo
---------修改获取库存
 update a 
 set  a.EndQty=isnull(a.EndQty,0)+isnull(b.fQty,0), 
 fCKPriceMoney=isnull(a.fCKPriceMoney,0)+isnull(b.fQty,0)*isnull(a.fCKPrice,0),
 fNormalPriceMoney=isnull(a.fNormalPriceMoney,0)+isnull(b.fQty,0)*isnull(a.fNormalPrice,0),
 avgInPriceMoney=isnull(a.avgInPriceMoney,0)+isnull(b.fMoney,0) 
 from #tmpGoodsListInfo_2 a,#tmpGoodsRelationKucun_2 b
 where a.GoodsNo_Pdt=b.cGoodsNo
 
 ')
 
 /*------------------*/
 --  print '18000000   '+dbo.getTimeStr(GETDATE())
--处理数量大于0 。金额《0--
update #tmpGoodsListInfo_2
set avgInPriceMoney=fckprice*EndQty
where EndQty>0 and avgInPriceMoney<0	
	  
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null 
begin  
    insert into #temp_goodsKuCurQty(cGoodsNo,EndQty,Endmoney)
	select GoodsNo_Pdt , EndQty=isnull(EndQty,0), Endmoney=isnull(fAvgMoney_Diff,0)+isnull(avgInPriceMoney,0)
	from #tmpGoodsListInfo_2 
end else
begin 
   
      update a
      set a.EndQty=isnull(b.EndQty,0),a.Endmoney=isnull(b.fAvgMoney_Diff,0)+isnull(b.avgInPriceMoney,0)
      from t_goodsKuCurQty_wei a,#tmpGoodsListInfo_2 b
      where a.cGoodsNo=b.GoodsNo_Pdt and a.cStoreNo=@cStoreNo
      
      insert into t_goodsKuCurQty_wei(cStoreNo,cGoodsNo,EndQty,Endmoney)
      select  @cStoreNo,b.GoodsNo_Pdt,EndQty=isnull(b.EndQty,0), Endmoney=isnull(b.fAvgMoney_Diff,0)+isnull(b.avgInPriceMoney,0)
      from t_goodsKuCurQty_wei a right join #tmpGoodsListInfo_2 b
      on a.cGoodsNo=b.GoodsNo_Pdt  and a.cStoreNo=@cStoreNo
      where isnull(a.cGoodsNo,'')=''
      
    -------------------------2016-01-23 号修改
      
      insert into t_Goods_CurWH(cStoreNo,cGoodsNo,cWHno,fQty_CurWH)
      select @cStoreNo,a.cGoodsNo,cWHno=@cWhNo,b.fQty_CurWH 
      --into #tmpGoodsfQty_CurWH
      from t_Goods a left join t_Goods_CurWH  b
      on a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo
      where isnull(b.cGoodsNo,'')=''
      
      update a
      set a.fQty_CurWH=b.EndQty
      from t_Goods_CurWH a,t_goodsKuCurQty_wei b
      where a.cGoodsNo=b.cGoodsNo  and b.cStoreNo=a.cStoreNo
      and a.cStoreNo=@cStoreNo
end 

 
 --select GoodsNo_Pdt , EndQty=isnull(EndQty,0), Endmoney=isnull(fAvgMoney_Diff,0)+isnull(avgInPriceMoney,0)
 --into ##temp_1
 -- from #tmpGoodsListInfo_2
  
			 /*删除临时表*/
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
	  if (select object_id('tempdb..#tmp_WhGoodsListCur'))is not null drop table #tmp_WhGoodsListCur
	  if(select object_id('tempdb..#temp_WhFrombeginCur')) is not null drop table #temp_WhFrombeginCur
      if(select object_id('tempdb..#temp_WhFromendCur')) is not null drop table #temp_WhFromendCur
      
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	    if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	   if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	   if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
	    if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
	    if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	    if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null drop table #tmpGoodsListInfo_2


GO
