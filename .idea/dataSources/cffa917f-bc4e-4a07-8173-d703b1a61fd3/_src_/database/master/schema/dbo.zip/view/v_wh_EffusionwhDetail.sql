
CREATE  view v_wh_EffusionwhDetail
as
  select b.cSheetno,iLineNo,a.cGoodsNo,fQuantity,fPrice,b.fMoney,
         fTaxrate,bTax,fTaxPrice,fTaxMoney,fLastMoney,dProduct,fTimes,cProductSerno,
         b.bPost,bChecked,cCheckNo,dCheck,cSupplierNo,cSupplier,cOperatorNo,cOperator,
         dFillin,cFillinTime,cProcureDptno,cProcureDpt,cManagerNo,cManager,
         bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,dDate,cTime,c.cUnitedNo,c.cGoodsName,
         cGoodsTypeno,cGoodsTypename,cBarcode,cUnit,cSpec,fNormalPrice,cProductUnit,cHelpCode,
         cTaxRate,fPreservationUp,fPreservationDown,cLevel,bSuspend,bDeling,bDeled,dSuspendDate1,
         dSuspendDate2,dDelingDate1,dDelingDate2,fVipScore,bProducted,cProductNo
  from wh_EffusionWhDetail a left join wh_EffusionWh b
                             on a.cSheetno=b.cSheetno
                             left join t_Goods c
                             on  a.cGoodsNo=c.cGoodsNo


GO
