/*
exec p_SetGoodsTypeVipScore '002'

select fValue_Score,fValue_con,cGoodsTypeno,cGoodsTypename,cPath
from t_GoodsType
where cPath like '--.99%'

select * from t_GoodsType where  cPath like '--.99%'

*/
CREATE procedure [dbo].[p_SetGoodsTypeVipScore]
	 @cTypeNo_Parent varchar(32)
as
begin
	declare @cPath_TypeNo_Parent varchar(32)
	select @cPath_TypeNo_Parent=cPath 
	from t_GoodsType 
	where cGoodsTypeno=@cTypeNo_Parent
	 
	--update a
	--set a.fValue_Score=b.fValue_Score,a.fValue_con=b.fValue_con
	--from t_GoodsType a,
	--(select cGoodsTypeno,cGoodsTypename,fValue_Score,fValue_con 
	--from t_GoodsType where cGoodsTypeno=@cTypeNo_Parent
	--) b
	--where a.cPath like @cPath_TypeNo_Parent+'.%'
	
	if (select OBJECT_ID('tempdb..#tmp_GoodsValue'))is not null drop table #tmp_GoodsValue
	select a.cGoodsTypeno,a.cParentNo,b.fValue_Score,b.fValue_con,b.bDazhe,b.bWeight,b.cDeptNo,b.cDept,b.bfresh
	into #tmp_GoodsValue
	from t_GoodsType a,
	(select cGoodsTypeno,cGoodsTypename,fValue_Score,fValue_con,bDazhe,bWeight,cDeptNo,cDept,bfresh
	from t_GoodsType where cGoodsTypeno=@cTypeNo_Parent
	) b
	where a.cPath like @cPath_TypeNo_Parent+'.%'
	

	
    update a
    set a.fValue_Score=b.fValue_Score,a.fValue_con=b.fValue_con,
    --a.bWeight=b.bWeight,a.bDazhe=b.bDazhe,
    a.cDept=b.cDept,a.cDeptNo=b.cDeptNo,a.bfresh=b.bfresh
    from t_GoodsType a,#tmp_GoodsValue b
    where a.cGoodsTypeno=b.cGoodsTypeno
    
    
    if (select OBJECT_ID('tempdb..#tmp_GoodsValue0'))is not null drop table #tmp_GoodsValue0
    select cGoodsTypeno,fValue_Score,fValue_con,bWeight,bDazhe,bfresh
    into #tmp_GoodsValue0
    from #tmp_GoodsValue where cGoodsTypeno not in (select cParentNo from #tmp_GoodsValue)
	
	--if (select OBJECT_ID('tempdb..#tmp_GoodsValue1'))is not null drop table #tmp_GoodsValue1
 --   select a.cGoodsTypeno,b.bWeight,b.bDazhe
 --   into #tmp_GoodsValue1
 --   from #tmp_GoodsValue0 a,t_GoodsType b
 --   where a.cGoodsTypeno=b.cGoodsTypeno
    
     update a
	 set  
	 a.fVipScore=round(a.fNormalPrice*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2),
	  --a.bWeight=c.bWeight,a.bDazhe=c.bDazhe,
	  a.bHidePrice=case when isnull(c.bWeight,0)=1 then 1 else 0 end,
	  a.bHideQty=case when isnull(c.bWeight,0)=1 then 1 else 0 end
	  --,a.bfresh=b.bfresh
	 from t_Goods a,#tmp_GoodsValue0 c
	 where a.cGoodsTypeno=c.cGoodsTypeno
	 
	 --update a
	 --set  
	 --a.bWeight=c.bWeight,a.bDazhe=c.bDazhe
	 --from t_Goods a,#tmp_GoodsValue1 c
	 --where a.cGoodsTypeno=c.cGoodsTypeno 
	 
	 print @cPath_TypeNo_Parent	
	
end

GO
