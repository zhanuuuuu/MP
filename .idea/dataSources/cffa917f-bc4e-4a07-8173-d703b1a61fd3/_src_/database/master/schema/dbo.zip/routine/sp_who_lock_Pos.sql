create procedure [dbo].[sp_who_lock_Pos]
@serverName varchar(32)
as
begin
exec('
	declare @spid int,@bl int,
	@intTransactionCountOnEntry int,
	@intRowcount int,
	@intCountProperties int,
	@intCounter int
	create table #tmp_lock_who (
	id int identity(1,1),
	spid smallint,
	bl smallint)
	IF @@ERROR=0  
	begin
		insert into #tmp_lock_who(spid,bl) select 0 ,blocked
		from (select * from '+@serverName+'.master.dbo.sysprocesses where blocked>0 ) a
		where not exists(select * from (select * from '+@serverName+'.master.dbo.sysprocesses where blocked>0 ) b
		where a.blocked=spid)
		union 
		select spid,blocked from '+@serverName+'.master.dbo.sysprocesses 
		where blocked>0 or ( waittime >0 and ltrim(rtrim(hostname))<>'''')
	end
	IF @@ERROR=0 
	begin
		-- 找到临时表的记录数
		select @intCountProperties = Count(*),@intCounter = 1
		from #tmp_lock_who
		IF @@ERROR=0 
		begin
			if @intCountProperties=0
			select iBlockCount=0 
		end else
		begin
			select iBlockCount=1 
		end
	end else
	begin
			select iBlockCount=1 
	end
	drop table #tmp_lock_who
')
end
GO
