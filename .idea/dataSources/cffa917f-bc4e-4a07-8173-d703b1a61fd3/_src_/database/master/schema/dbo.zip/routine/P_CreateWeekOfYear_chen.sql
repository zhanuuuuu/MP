
/*
生成全年周次开始日期、结束日期
P_CreateWeekOfYear_chen 1999
drop proc P_CreateWeekOfYear
*/
CREATE proc P_CreateWeekOfYear_chen
@year int 
as

--declare @year int
--set @year=2010
declare @R varchar(100)
if exists(
  select iYear, iWeek
  from dbo.t_YearWeekChen
  where iYear=@year
)
begin
  --set @R=cast(@year as varchar(4))+'年的周次已存在'
  --RaisError( @R,16,1)
  return
end 
set datefirst 1
declare @dDateFirstDayOfYear datetime
declare @dDateLastDayOfYear datetime
declare @date datetime
declare @dateBgn datetime
declare @dateEnd datetime
declare @Week int
set @dDateFirstDayOfYear=cast(cast(@year as varchar(4))+'-01-01' as datetime)
set @dDateLastDayOfYear=cast(cast(@year as varchar(4))+'-12-31' as datetime)
if (select object_id('tempdb..#tmpdate'))is not null
drop table #tmpdate
create table #tmpdate
(
  iYear int,
  iWeek int,
  dDate datetime
)
set @date=@dDateFirstDayOfYear
while @date<=@dDateLastDayOfYear
begin
  insert into #tmpdate
  (
    iYear,iWeek,dDate
   ) 
  select @year,datepart(wk,@date),@date     
  set @date=dateadd(dd,1,@date);
end
insert into t_YearWeekChen
(
  iYear,iWeek,dDateBegin,dDateEnd,bCreatedReport
)
select iYear,iweek,dMinDate=min(dDate),dMaxDate=max(dDate),0
from #tmpdate
group by iYear,iweek


GO
