


CREATE view [dbo].[v_GoodsOut_chen_log]
as
----------------------------------------
select SheetType,TypeNo,dDate,cTime,sc,cSheetno,iLineNo,cGoodsNo,cGoodsName,
cWhNo,bStorage
from v_GoodsIN_chen_log
union all
----------------------------------------
--出库单
select SheetType='出库单',TypeNo=1,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cCustomerNo+' '+b.cCustomer,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from wh_OutWarehouseDetail a,wh_OutWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1
union all
--返厂单
select SheetType='返厂单',TypeNo=2,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from wh_RbdWarehouseDetail a,wh_RbdWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1
union all
--报损单
select SheetType='报损单',TypeNo=5,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from wh_OutWarehouseDetail a,wh_LossWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1
union all
--调拨单
select SheetType='调拨单',TypeNo=4,b.dDate,cTime=cast(b.cTime as datetime),sc='-',
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from wh_TfrWarehouseDetail a,wh_TfrWarehouse b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1
union all
--原料出库单
select SheetType='原料出库单',TypeNo=8,b.dDate,cTime=cast(b.cTime as datetime),sc=b.cSupplierNo+' '+b.cSupplier,
a.cSheetno,a.iLineNo,a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from dbo.wh_PackDetail a,dbo.wh_Pack b,t_goods c
where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1
union all
--日结
select SheetType='日结',TypeNo=10,a.dSaleDate,cTime='1900-01-01 23:58:59',sc='-',
cSheetno='-',iLineNo='',a.cGoodsNo,cGoodsName='',a.cWhNO,a.bStorage
from t_saleSheet_day a,t_Daily_history b
where a.dSaleDate=b.dDate
and isnull(b.bAccount_log,0)<>1
/*
union all
--盘点报损
select distinct SheetType='盘点报损',TypeNo=12,b.dCheckTask,cTime='1900-01-01 23:59:59',sc='-',
cSheetno=a.cCheckTaskNo,iLineNo='',a.cGoodsNo,a.cGoodsName,b.cWhNo,c.bStorage
from t_CheckTast_GoodsDetail a,t_CheckTast b,t_goods c
where a.cCheckTaskNo=b.cCheckTaskNo
and a.cGoodsNo=c.cGoodsNo
and isnull(b.bAccount_log,0)<>1 and isnull(a.fQuantity_diff,0)<0
and b.bchecked in(0,1)


*/










GO
