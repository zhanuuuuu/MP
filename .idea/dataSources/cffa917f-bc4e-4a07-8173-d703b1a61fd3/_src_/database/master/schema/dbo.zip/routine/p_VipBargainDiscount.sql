Create Procedure p_VipBargainDiscount
/*贵宾享受议价后打折
*/
as
begin
  select d=null
end
GO
