
CREATE  procedure P_Z_checkBirthDay
  @BirthDay datetime
as
	begin
	declare @MM int
	declare @DD int
	select @MM=month(@BirthDay)
	select @DD=datepart(dd,@BirthDay)
	select cVipno,cVipName,cSex,dBirthday,cHome,cTel,cIdCard,fCurValue
	from t_Vip
	where 
      month(dBirthday)=@MM
	and
      datepart(dd,dBirthday)=@DD
end

GO
