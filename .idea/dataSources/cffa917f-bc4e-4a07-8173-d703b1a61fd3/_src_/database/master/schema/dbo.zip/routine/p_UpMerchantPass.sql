/*
返回状态：  11表示密码验证通过；
			10表示商家编号未注册；
			12旧密码不正确 
			0表示异常； 
 */ 
create proc p_UpMerchantPass
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@MerchantOldPwd varchar(64), --商家旧密码
@MerchantNewPwd varchar(64),   --商家新密码           
@return int output        --返回值
as
begin   
      begin try 
	  begin tran
		declare @cStoreNo varchar(64)
		declare @cMerchantPwd varchar(64)
		set @cStoreNo=''  		  
		  select @cStoreNo=cStoreNo,@cMerchantPwd=MerchantPwd from t_Store where cStoreNo=@Merchantid   
		  IF @cStoreNo=''
		  BEGIN 
			set @return=10
		  end else
		  BEGIN
			if @MerchantOldPwd=@cMerchantPwd  --- 表示密码一致
			begin
				update  t_Store SET MerchantPwd=@MerchantNewPwd
				where cStoreNo=@Merchantid   
				set @return=11
			end else
			BEGIn
			  set @return=12
			end
		  end   		  
		  commit tran	    
		end try
		begin catch  
		   rollback  
		  set @return=0
		end catch
	 
end
GO
