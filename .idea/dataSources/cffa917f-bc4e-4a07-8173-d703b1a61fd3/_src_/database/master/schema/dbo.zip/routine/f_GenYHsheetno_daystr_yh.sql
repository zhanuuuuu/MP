/*
 select f_GenYHsheetno_daystr '2011','81005','20110906'
*/
create    function [dbo].[f_GenYHsheetno_daystr_yh]
(@cYear varchar(8),@cSupplierNo varchar(16),@daystr varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
	 --declare @iPatIndex int
   declare @strTemp varchar(32)
	 declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.wh_StockVerify
                  where (cSupplierNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear
												)
												or
												(substring(cSheetno,11,PatIndex('%-%',cSheetno)-11)=@cSupplierNo
												 and datename(yyyy,dDate)=@cYear	
												)
                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp='YH'+@daystr+'.'+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp='YH'+@daystr+'.'+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end


GO
