




CREATE view [dbo].[v_Code]
as

select cCode=cWhNo,cName=cWh,cTablename='仓库'
from dbo.t_WareHouse
union all
select cCode=cClentNo,cName=cClentName,cTablename='客户'
from dbo.t_Client
union all

select cCode=cEmployeeNo,cName=cEmployee,cTablename='员工信息'
from dbo.t_Employee
union all
select cCode=cOperatorno,cName=cOperatorName,cTablename='操作员信息'
from  dbo.t_Operator
union all
select cCode=feiyongno,cName=feiyong,cTablename='科目(供应商费用)'
from dbo.t_Supplier_FeeCode
--union all
--select cCode=cGoodsTypeno,cName=cGoodsTypename,cTablename='商品类别库'
--from dbo.t_GoodsType_Lib


GO
