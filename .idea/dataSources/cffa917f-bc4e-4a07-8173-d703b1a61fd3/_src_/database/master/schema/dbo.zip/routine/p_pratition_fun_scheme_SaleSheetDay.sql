
--创建分区函数，架构，分区表
/*
exec p_pratition_fun_scheme_SaleSheetDay
*/
create proc p_pratition_fun_scheme_SaleSheetDay
as
begin
	create partition function SaleSheetDayPartFun(datetime)
	as
	range right for values(
	'2008-02-01',
	'2008-03-01',
	'2008-04-01',
	'2008-05-01',
	'2008-06-01',
	'2008-07-01',
	'2008-08-01',
	'2008-09-01',
	'2008-10-01',
	'2008-11-01',
	'2008-12-01'

	)
	create partition scheme SaleSheetDayPartScheme
	as
	partition SaleSheetDayPartFun
	to ([SaleSheetDay_01],[SaleSheetDay_02],[SaleSheetDay_03],
		[SaleSheetDay_04],[SaleSheetDay_05],[SaleSheetDay_06],
		[SaleSheetDay_07],[SaleSheetDay_08],[SaleSheetDay_09],
		[SaleSheetDay_10],[SaleSheetDay_11],[SaleSheetDay_12])

	
CREATE TABLE [dbo].[t_SaleSheet_Day](
	[dSaleDate] [datetime] NOT NULL,
	[iSeed] [int] IDENTITY(1,1) NOT NULL,
	[cGoodsNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NOT NULL,
	[bAuditing] [bit] NULL,
	[cChkOperno] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
	[cChkOper] [varchar](16) COLLATE Chinese_PRC_CI_AS NULL,
	[bSettle] [bit] NULL,
	[fVipScore] [money] NULL,
	[fQuantity_Total] [money] NULL,
	[fQuantity] [money] NOT NULL,
	[fLastSettle] [money] NOT NULL,
	[fCostPrice] [money] NULL,
	[fProfitsRatio] [money] NULL,
	[cSaleTime] [varchar](16) COLLATE Chinese_PRC_CI_AS NOT NULL,
	[dFinanceDate] [datetime] NOT NULL,
	[bPost] [bit] NULL,
	[bChecked] [bit] NULL,
	[cCheckNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
	[dCheck] [datetime] NULL,
	[bBalance] [bit] NULL,
	[jiesuanno] [varchar](50) COLLATE Chinese_PRC_CI_AS NULL,
	[bPost_month] [bit] NULL,
	[cCooperate] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
	[fCKPrice] [money] NULL,
	[fMoney_WH] [money] NULL,
	[fMoney_WH_Begin] [money] NULL,
	[fMoney_WH_Sale_Begin] [money] NULL,
	[fMoney_WH_End] [money] NULL,
	[fMoney_WH_Sale_End] [money] NULL,
	[fInPrice_avg] [money] NULL,
	[fInPrice_H] [money] NULL,
	[fInPrice_L] [money] NULL,
	[fNormalPrice] [money] NULL,
	[fVipPrice] [money] NULL,
	[fQty_BeginWH] [money] NULL,
	[fQty_CurWH] [money] NULL,
	[cSupplierNo] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
	[cMultSupplierIDno] [varchar](32) COLLATE Chinese_PRC_CI_AS NULL,
	[H0] [money] NULL,
	[H1] [money] NULL,
	[H2] [money] NULL,
	[H3] [money] NULL,
	[H4] [money] NULL,
	[H5] [money] NULL,
	[H6] [money] NULL,
	[H7] [money] NULL,
	[H8] [money] NULL,
	[H9] [money] NULL,
	[H10] [money] NULL,
	[H11] [money] NULL,
	[H12] [money] NULL,
	[H13] [money] NULL,
	[H14] [money] NULL,
	[H15] [money] NULL,
	[H16] [money] NULL,
	[H17] [money] NULL,
	[H18] [money] NULL,
	[H19] [money] NULL,
	[H20] [money] NULL,
	[H21] [money] NULL,
	[H22] [money] NULL,
	[H23] [money] NULL,
	[H0_Q] [money] NULL,
	[H1_Q] [money] NULL,
	[H2_Q] [money] NULL,
	[H3_Q] [money] NULL,
	[H4_Q] [money] NULL,
	[H5_Q] [money] NULL,
	[H6_Q] [money] NULL,
	[H7_Q] [money] NULL,
	[H8_Q] [money] NULL,
	[H9_Q] [money] NULL,
	[H10_Q] [money] NULL,
	[H11_Q] [money] NULL,
	[H12_Q] [money] NULL,
	[H13_Q] [money] NULL,
	[H14_Q] [money] NULL,
	[H15_Q] [money] NULL,
	[H16_Q] [money] NULL,
	[H17_Q] [money] NULL,
	[H18_Q] [money] NULL,
	[H19_Q] [money] NULL,
	[H20_Q] [money] NULL,
	[H21_Q] [money] NULL,
	[H22_Q] [money] NULL,
	[H23_Q] [money] NULL,
	[bLast] [bit] NULL,
	[bStorage] [bit] NULL,
	[bInitial] [bit] NULL,
	[fCostPrice_History] [money] NULL,
 CONSTRAINT [PK_t_SaleSheet_Day] PRIMARY KEY CLUSTERED 
(
	[dSaleDate] ASC,
	[iSeed] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [FG_SaleSheetDay]
) ON SaleSheetDayPartScheme([dSaleDate])


	--select isdate(datename(yyyy,getdate())+'0201')
end
GO
