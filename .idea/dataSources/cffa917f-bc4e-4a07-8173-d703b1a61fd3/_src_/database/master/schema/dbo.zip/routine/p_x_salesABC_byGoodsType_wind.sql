
/*

p_x_salesABC_byGoodsType_wind '2008-08-01','2008-09-01',0,1

*/

CREATE  procedure [dbo].[p_x_salesABC_byGoodsType_wind]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit
as
begin
  select distinct cGoodsNo into #t_Goods from #temp_Goods     --#temp_Goods 在delphi程序中已创建的临时表  

--                销售单                 开始    
  select a.cGoodsNo,b.fQuantity,b.fLastSettle
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      ,t_SaleSheetDetail b
        where a.cGoodsNo=b.cGoodsNo 
       and  (b.dSaleDate between @dBeginDate and @dEndDate)
       and isnull(tag_daily,0)=0
  union all
  select a.cGoodsNo,b.fQuantity,b.fLastSettle
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       t_SaleSheet_Day b
         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @dBeginDate and @dEndDate)
  union all
  select a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney 
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c
         where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dBeginDate and @dEndDate)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
  into #t_SaleSheetDetail1  --销售单
  from #t_SaleSheetDetail_shelf
  group by cGoodsNo
--               销售单                 结束 

--合并  开始
    if @bZero=1
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,
                  xsQty=m.qty,xsMoney=m.fLastMoney
      into #temp_goodsKuCun1 from #t_Goods a 
                             left join t_goods b on a.cGoodsNo=b.cGoodsNo
                             left join #t_SaleSheetDetail1 m on a.cGoodsNo=m.cGoodsNo
                             --where a.GoodsNo_Pdt=b.cGoodsNo and a.cGoodsNo=m.cGoodsNo
    else
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,
                  
                  xsQty=m.qty,xsMoney=m.fLastMoney
      into #temp_goodsKuCun1_NoZero from #t_Goods a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , #t_SaleSheetDetail1 m --on a.cGoodsNo=m.cGoodsNo
                             where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=m.cGoodsNo
--合并  结束
    if @bZero=1
	    select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)
		  from #temp_goodsKuCun1
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
             
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
    else
      select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
             
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)
		  from #temp_goodsKuCun1_NoZero
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1_NoZero 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1_NoZero
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
end


GO
