
CREATE  view v_Goods_Relation_X
as
  select distinct cGoodsNo,GoodsNo_Pdt
  from v_Goods_Relation
	union all
	select cGoodsNo=GoodsNo_Pdt,GoodsNo_Pdt=cGoodsNo
	from v_Goods_Relation
	where isnull(cProductNo,'')<>''
	union all
	select cGoodsNo,GoodsNo_Pdt=cGoodsNo
	from v_Goods_Relation
	where isnull(cProductNo,'')<>''


GO
