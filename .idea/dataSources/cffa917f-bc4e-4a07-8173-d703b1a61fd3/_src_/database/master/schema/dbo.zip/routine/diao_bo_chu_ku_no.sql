CREATE proc diao_bo_chu_ku_no
@Year  varchar(20),
@cWhNo varchar(20)
as  
select dbo.[f_GenDiaoBosheetno]  (@Year,@cWhNo ) as diao_bo_chu_ku_no
GO
