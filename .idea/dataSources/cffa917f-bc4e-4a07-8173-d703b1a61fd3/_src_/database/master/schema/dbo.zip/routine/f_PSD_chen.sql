

create  function [dbo].[f_PSD_chen]
(@cYear varchar(4),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   declare @strTemp varchar(32)
	 declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(Sheetno_Delivered) from t_Deliver
                  where (bumenNo=@cSupplierNo
                        and datename(yyyy,dDatetime)=@cYear
												)
												or
												(substring(Sheetno_Delivered,8,PatIndex('%-%',Sheetno_Delivered)-8)=@cSupplierNo
												 and datename(yyyy,dDatetime)=@cYear	
												)
                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp='PSD'+@cYear+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp='PSD'+@cYear+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end
--print dbo.f_PsD_chen ('2009','18016')


GO
