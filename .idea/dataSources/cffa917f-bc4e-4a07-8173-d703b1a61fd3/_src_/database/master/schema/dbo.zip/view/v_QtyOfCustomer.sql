
create view v_QtyOfCustomer
as
 select QtyOfCustomer=count(distinct sheetno) from dbo.jiesuan


GO
