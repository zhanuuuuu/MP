CREATE procedure [dbo].[p_FIFO_Tfr_In_wei]
@dbSheetNo varchar(32),--对应调拨出库单ＮＯ
--@dbWHno    varchar(32),--对应调拨出库单仓库
@dbDate    datetime,--对应调拨出库单日期
@cSheetNo  varchar(32),--本调拨入库单ＮＯ
@cWhno     varchar(32),--本调拨入库单对应仓库
@dDatetime     varchar(32)--本调拨入库单制单日期
as
begin
	select a.dDate_Sheet,a.cGoodsNo,a.iSerno,a.fPrice_Tran,a.fPrice_Cost,a.fQty_Cost,
	a.fMoney_Cost,a.cSheetNo,a.iLineNo,a.fQty,a.dDate_Account,a.cWhNo,
	b.cSupplierNo,b.cSupplier
  into #temp_Tfr_In_CostDetail
	from  Pos_Cost_distribute.dbo.t_Cost_distribute_Log a,dbo.t_wh_form_log b
	where a.dDate_Sheet=@dbDate and a.cSheetNo=@dbSheetNo and isnull(a.bDone,0)=0
	and a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo and  a.iSerno=b.iMyIdentity

  update a 
	set a.fPrice_Tran=b.fInPrice
	from #temp_Tfr_In_CostDetail a,dbo.wh_TfrWarehouseDetail b
  where b.cSheetno=@dbSheetNo and a.cGoodsNo=b.cGoodsNo and a.iLineNo=b.iLineNo
/*
  select cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,
	cSummary,fPrice_Tran,fPrice_in,fQty_in,fMoney_in,
  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
  cSupplierNo,cSupplier,iSerNo
	into #temp_WH_Form
  from t_wh_form_log
  where iMyIdentity=-99
*/
  insert into t_wh_form_log(业务日期,cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,
	cSummary,fPrice_Tran,fPrice_in,fQty_in,fMoney_in,
  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
  cSupplierNo,cSupplier,iSerNo,调拨入库数量1,调拨入库金额1,本日库存数量
  )
  select @dDatetime,cGoodsNo,dDateTime=@dDatetime,cSheetNo=@cSheetNo,iLineNo,iAttribute=31,
	cSummary='从调拨出库单:'+@dbSheetNo+'调入',fPrice_Tran,fPrice_in=fPrice_Cost,fQty_in=fQty_Cost,fMoney_in=fMoney_Cost,
  fPrice_out=0,fQty_out=0,fMOney_out=0,fPrice_left=fPrice_Cost,fQty_left=fQty_Cost,fMoney_left=fQty_Cost,cWhNo=@cWhno,
  cSupplierNo,cSupplier,iSerNo=-99,fQty_Cost,fMoney_Cost,fQty_Cost
  from #temp_Tfr_In_CostDetail

  update t_wh_form_log
  set iSerNo=iMyIdentity
  where dDateTime=@dDatetime and isnull(iSerNo,0)=-99

 
   

end
GO
