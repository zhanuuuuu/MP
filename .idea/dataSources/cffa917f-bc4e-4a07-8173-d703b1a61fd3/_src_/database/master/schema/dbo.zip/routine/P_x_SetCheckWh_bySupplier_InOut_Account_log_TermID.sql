 
/*

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods    where       csupno='1040'
union all
select cGoodsNo,cSupplierNo='6013' from t_Goods    where       cgoodsno='210122'

if (select object_id('tempdb..#temp_Super')) is not null
    drop table #temp_Super
 
    select cSupNo into #temp_Super from t_supplier  where cSupNo='1001'
  
--- drop table ##temp_Kucun
declare @bJiaGong bit
exec [P_x_SetCheckWh_bySupplier_InOut_Account_log]
'2012-12-01','2015-5-29','01'

*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_bySupplier_InOut_Account_log_TermID]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32),/*是仓库No*/
@cStoreNo varchar(32)
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-04-02' set @dDateEnd='2012-04-02'  set @cWhNo='02' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods 
 
  if (select object_id('tempdb..#temp_Goods')) is not null
   drop table #temp_Goods
  Create Table #temp_Goods (cGoodsNo varchar(128),cProductNo varchar(128),cSupplierNo varchar(128))
   insert into #temp_Goods (cGoodsNo,cSupplierNo)
    select distinct a.cGoodsNo,b.cSupplierNo from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno where b.cStoreNo=@cStoreNo and b.cSupplierNo in(select cSupNo from #temp_Super )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupNo from #temp_Super ))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_cStoregoods a
    where cStoreNo=@cStoreNo and a.bStorage=1 and a.cSupno in(select cSupNo from #temp_Super )
    and a.cGoodsNo not in (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in(select cSupNo from #temp_Super ))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_cStoreGoods a
    where cStoreNo=@cStoreNo and isnull(a.bStorage,0)=1 and a.cSupno in(select cSupNo from #temp_Super )
    

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsNo,cSupplierNo into #tmpCostGoodsList from #temp_Goods


 
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct a.cGoodsNo,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=1 into  #tmp_WhGoodsList  
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and cStoreNo=@cStoreNo 
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1
union all
select distinct a.cGoodsNo,a.cSupplierNo ,cGoodsNo_minPackage,fQty_minPackage,bbox=0
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and cStoreNo=@cStoreNo 
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo,cGoodsNo_minPackage,fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and cStoreNo=@cStoreNo  and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,a.cSupplierNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_cStoreGoods b
where b.cStoreNo=@cStoreNo and a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1
 

 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)


declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cStoreNo=@cStoreNo

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money,fMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

/*2014-10-23如果查询期初的时间段超出记账日期时、数量取最后记账的*/
if @maxWhdDate<@dDateBgn 
begin
   set @dDateBgn=@maxWhdDate
   set @dDateEnd=@maxWhdDate
end


declare @dDate1 datetime
declare @dDate2 datetime
declare @i int
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
			        set @i=1
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=1
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 
		set @maxWhdDate=@dDateEnd
		set @dDateBgn=@dDateBgn
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
	--insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 
	--insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo,[cWHno]) 
	--select distinct cGoodsNo,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 

  if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

	CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
	CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
	   CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
		declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
    set @strDateEnd=dbo.getdaystr(@maxWhdDate)
    set @strBgn=dbo.getdaystr(@dDateBgn)
 
 /*
	exec('	  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
		select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,
		  b.销售数量0, b.销售金额0, 
		 
		   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
		   fPrice_Avg=b.fPrice_In,
		   fmoney_cost=b.fPrice_In*b.销售数量0,
		   fMoney_Left=b.fMoney_Left
			into #temp_Wh_Goods_begin
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
			 with (nolock) 
		  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo   
		  and b.cWHno='+@cWHno+'				  
		  union all             
		 select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
	 
		   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
		   fPrice_Avg=b.fPrice_In,
		   fmoney_cost=b.fPrice_In*b.销售数量0,
		   fMoney_left=0
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo  
		  and b.cWHno='+@cWHno+'
  
		  			
             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
	         select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		 
			  本日库存数量=SUM(isnull(本日库存数量,0)), 
			   盘点数量=SUM(isnull(盘点数量,0)),
			   fPrice_Avg=AVG(fPrice_Avg),
			   fmoney_cost=sum(fmoney_cost),
			   fMoney_left=sum(isnull(fMoney_left,0))
			   into #temp_SumWh_Goods_begin
				from #temp_Wh_Goods_begin
              group by cgoodsno,cSupplierNo,cWHno		
		  
 
		    insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,
		  
		  
		  本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fMoney_left)
		  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,				  
		  
		  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fMoney_left
		  from #temp_SumWh_Goods_begin
		  
		 ')

	exec('  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		  select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,b.销售数量0, b.销售金额0, 
		 
		   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
		   fPrice_Avg=b.fPrice_In,
		   fmoney_cost=b.fPrice_In*b.销售数量0,
		   fMoney_Left=b.fMoney_Left
	     	into #temp_Wh_Goods_end
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
			 with (nolock) 
		  where b.业务日期='''+@strDateEnd+'''  and a.cGoodsNo=b.cGoodsNo 
		  and b.cWHno='+@cWHno+'				  
		  union all             
		 select 业务日期,a.cgoodsno,b.cSupplierNo,b.dDatetime,b.cWHno,
		  b.销售数量0, b.销售金额0, 
	 
		   本日库存数量=b.fQty_left, 盘点数量=b.盘点数量,
		   fPrice_Avg=b.fPrice_In,
		   fmoney_cost=b.fPrice_In*b.销售数量0,			
		   fMoney_left=0
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where  b.业务日期 between '''+@strDateBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo 
		  and b.cWHno='+@cWHno+'  and  b.iAttribute<>20	
		 
         
             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	         select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		 
			   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
			   fPrice_Avg=AVG(fPrice_Avg),
			   fmoney_cost=sum(fmoney_cost),
			   fmoney_left=sum(isnull(fmoney_left,0))					   
			   into #temp_SumWh_Goods_end
				from #temp_Wh_Goods_end
              group by cgoodsno,cSupplierNo,cWHno		     

         

          insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0, 
		  本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fmoney_left)
		  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0, 
		  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fmoney_left
		  from #temp_SumWh_Goods_end

	 
		')

	     
		 update a 
		 set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		 a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 				 
		  a.期初库存=isnull(b.期初库存,0), 
		  a.期末库存=isnull(a.期末库存,0), 
		  a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
		  a.fPrice_Avg=a.fPrice_Avg,
		  a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
		  a.fMoney_left=ISNULL(a.fMoney_left,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
*/
--select * from #temp_WhFrombegin

--select * from #temp_WhFromend

	/*获取时间段的入库记录 日期以单据日期为判断。*/
 
	----------------上面从快照表中取出库存数据-------------------

declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1


insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo,[cWHno]) 
select distinct cGoodsno,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 

 
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@maxWhdDate) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@maxWhdDate) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
	if(@bY1<>@eY1)
	begin 
	    set @tj='1'
   end else
   begin      
       if @bM1=@eM1
       begin  
       exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select b.cGoodsno,b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+' 
		,fQty0=b.fQty_010131,fMoney0=b.fMoney_010131 		
		into #temp_Wh_Goods_end
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a 
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cGoodsno,cSupNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno,cSupNo
		 
		update a 
		set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
		a.fmoney_left=b.fMoney1 	 
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
		 
	')
	 exec('  		
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno,cSupplierNo
 

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0) 
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

		')
		
	  exec('
	------------
	   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select b.cGoodsno,cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
		fQty0=b.fQty_010131 ,fQtytj0=b.fQtytj_010131    
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a 
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select b.cGoodsno,cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
		Sale0=b.Sale_010131 , Saletj0=b.Saletj_010131 
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cGoodsno,cSupNo,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
		fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cGoodsno,cSupNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupNo
		 
		update a 
		set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
		a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
		a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0))				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
		 
		update a 
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))   	
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
		')
 
		end else
		begin
		  set @tj='1'	
		end
   end
   if @tj='1'
   begin
        insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo,[cWHno]) 
		select distinct cGoodsno,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 
 
		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select b.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cGoodsno,cSupNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno,cSupNo
			

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
			')
		exec('
		   ----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
		')
		exec('
		--------期初销售
		   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select b.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select b.cGoodsno,b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,cSupNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno,cSupNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,cSupNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno,cSupNo
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
			
				')
 

		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cGoodsno,cSupNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno,cSupNo
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
			 
			')
		exec('
		------------
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cSupNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno,cSupNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,cSupNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno,cSupNo
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
			')
            exec('
             ----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,b.cSupNo,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cSupNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cSupNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
            ')
			  
			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
			a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
			a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
			a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
			a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),  
			a.期初库存=isnull(b.期初库存,0), 
			a.期末库存=isnull(a.期末库存,0), 
			a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
			a.fPrice_Avg=a.fPrice_Avg,
			a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
			a.fMoney_left=ISNULL(a.fMoney_left,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo 
   end
end else
begin
   if @M1=@M_1
   begin
   exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
	select a.cGoodsno,b.cSupNO,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+' 
	,fQty0=b.fQty_'+@MMDAY_1+',fMoney0=b.fMoney_'+@MMDAY_1+' 		
	into #temp_Wh_Goods_end
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+'''  and  a.cGoodsNo=b.cGoodsNo 
  
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	select cGoodsno,cSupNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
	into #temp_SumWh_Goods_end
	from  #temp_Wh_Goods_end
	group by cgoodsno,cSupNo
	 
    update a 
	set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
	a.fmoney_left=b.fMoney1 
	from #temp_WhFromend a ,#temp_SumWh_Goods_end b
	where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNO=b.cSupNo
	 
')
exec('
 ----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno ,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)	
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
')
  
  exec('
------------
   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cGoodsno,b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+'   
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cGoodsno,b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'  
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cGoodsno,cSupNo,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cGoodsno,cSupNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupNo
	 
	update a 
	set a.销售数量0=isnull(b.fQty1,0)-isnull(b.fQty0,0), 
	a.特价销售数量=isnull(b.fQtytj1,0)-isnull(b.fQtytj0,0),
	a.正价销售数量=(isnull(b.fQty1,0)-isnull(b.fQtytj1,0))-(isnull(b.fQty0,0)-isnull(b.fQtytj0,0))				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
	where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
	a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
	a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))   	
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo 
	')
 
    end else
    begin
  
        insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo,[cWHno]) 
		select distinct cGoodsno,cSupplierNo,@cWhNo from  #tmp_WhGoodsList 
		CREATE INDEX IX_temp_WhFrombegin0  ON #temp_WhFrombegin(cGoodsNo)		
 
		exec('
		-------期初库存
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
			select b.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_begin
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a 
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			select cGoodsno,cSupNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_begin
			from  #temp_Wh_Goods_begin
			group by cgoodsno,cSupNo
			

			update a 
			set a.期初库存=b.fQty 			
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo
			')
		exec('
		--------期初销售
		   if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select b.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select b.cGoodsno,b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cYear='''+@Y_1+'''  and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,cSupNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno,cSupNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,cSupNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno,cSupNo
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupNo
				')
 
        exec('
         ----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		 
        ')
        
 
        
		exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select a.cGoodsno,b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
			into #temp_Wh_Goods_end
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		  
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cGoodsno,cSupNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_end
			from  #temp_Wh_Goods_end
			group by cgoodsno,cSupNo
			 
			update a 
			set a.期末库存=b.fQty, 
			a.fmoney_left=b.fMoney			
			from #temp_WhFromend a ,#temp_SumWh_Goods_end b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo  	
			 
			')
		exec('
		------------
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
			with (nolock) 
			where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cSupNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno,cSupNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,cSupNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno,cSupNo
			
			

			update a 
			set a.销售数量0=b.fQty, 
			a.特价销售数量=b.fQtytj,
			a.正价销售数量=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo  
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupNo 	
			')
		exec('
		 ----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
		') 
			   
			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
			a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
			a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
			a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
			a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),				 	      
			a.期初库存=isnull(b.期初库存,0), 
			a.期末库存=isnull(a.期末库存,0), 
			a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
 
			a.fPrice_Avg=a.fPrice_Avg,
			a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
			a.fMoney_left=ISNULL(a.fMoney_left,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo 

    end
end 	

     update a set a.cSupplier=b.cSupName
     from #temp_WhFromend a,t_SupplierStore b
	 where b.cStoreNo=@cStoreNo and a.cSupplierNo=b.cSupNo

 
	 /*2014-10-02修改数量、大小包装*/
	 
	 update a 
	 set a.cGoodsNo=b.cGoodsNo_minPackage,
     a.销售数量0=a.销售数量0*b.fQty_minPackage,
    
     a.本日库存数量=a.本日库存数量*b.fQty_minPackage,
     a.期初库存=a.期初库存*b.fQty_minPackage,
   
     a.期末库存=a.期末库存*b.fQty_minPackage
    
	 from #temp_WhFromend  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
	 where a.cGoodsNo=b.cGoodsNo 
	 
	 
	 if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
     select cGoodsNo,cSupplierNo,cSupName=cSupplier,
		  
		  销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
		 
		  本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 
		  fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost) ,
		  fMoney_Diff=SUM(fMoney_Diff)
         into #temp_goodsKuCun_1
         from   #temp_WhFromend
         group by cGoodsNo,cSupplierNo,cSupplier
	
	
    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
    select a.cGoodsNo,cSupplierNo,
	    销售数量0, 销售金额0, 
	  本日库存数量,  期初库存,期末库存,fMoney_left,fmoney_cost, 
	  fprice_in=case when ISNULL(a.销售数量0,0)=0 
		then b.fPrice_Contract
		else fmoney_cost/销售数量0 end,
		fProfitRatio_avg=case when isnull(销售金额0,0)<>0 then (isnull(销售金额0,0)-isnull(fmoney_cost,0))/isnull(销售金额0,0)*100 else null end ,
         xsQty=isnull(销售数量0,0),xsMoney=isnull(销售金额0,0)
        into  #temp_goodsKuCun
	  from #temp_goodsKuCun_1 a,t_cStoreGoods b
	  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo  ---and isnull(销售数量0,0)<>0
	  order by a.cGoodsNo
	  
 
	 if (select OBJECT_ID('tempdb..#temp_cSupXsMonthCost'))is not null
	 begin
	      insert into #temp_cSupXsMonthCost(cSupNo,cWHno,[fQty_Sale],[fMoney_Sale],fmoney_cost)
			   select  cSupplierNo,@cWhNo,[fQty_Sale]=SUM(销售数量0),[fMoney_Sale]=sum(销售金额0),
			    fmoney_cost=sum(fmoney_cost)
			  from #temp_goodsKuCun
		group by  cSupplierNo 
		order by cSupplierNo
	  
   end else
   begin
        select  cSupplierNo,@cWhNo,[fQty_Sale]=SUM(销售数量0),[fMoney_Sale]=sum(销售金额0),
			 fmoney_cost=sum(fmoney_cost)
			  from #temp_goodsKuCun
		group by  cSupplierNo 
		order by cSupplierNo
   end
	 /*删除临时表*/
	  	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
      
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	       if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
/*
select cGoodsNo,cSupplierNo,
	  入库数量1, 入库金额1, 
	   Pos客退数量1, Pos客退金额1, 
	  --退货入库数量1, 退货入库金额1,   
	  --出库数量0, 出库金额0, 
	  返厂数量0, 返厂金额0, 
	  销售数量0, 销售金额0, 
	  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 
	  本日库存数量,  期初库存,期末库存 --into ##temp1 
	  from #temp_WhFromend 
	--  where cGoodsNo='140797'
*/

--select @dDate1,@dDate2,@maxWhdDate,@dDateEnd


-- where cGoodsNo='140797'
GO
