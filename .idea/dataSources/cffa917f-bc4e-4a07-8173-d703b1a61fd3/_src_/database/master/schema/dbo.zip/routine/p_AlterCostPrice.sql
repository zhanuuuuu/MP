/*
 [p_AlterCostPrice] 'IN20151058-000023','1321455',7,'01',100,4.8,20,'2015-05-01'

*/
CREATE proc [dbo].[p_AlterCostPrice]
@cSheetno varchar(32),--入库单号
@cGoodsNo varchar(32),--商品店内码
@iLineNo int,------入库单中序号
@cWHno varchar(32),----所属仓库
@fQty_new money,------新数量
@fPrice_new money,----新单价
@fQty_Diff money,------数量差异
@dDate_sheet datetime-----入库日期
as
begin
	--begin try
	--	begin tran

    declare @cDbName varchar(32)
    set @cDbName=null
    select @cDbName=cdbname
    from t_WareHouse
		where cWhNo=@cWHno
		
		declare @cGoodsNo_minpackage varchar(32)
		declare @fQty_minPackage varchar(32)
		declare @iMyIdentity bigint
	
		set @cGoodsNo_minpackage =null
		set @fQty_minPackage=null
		set @iMyIdentity =null
		select @cGoodsNo_minpackage=cGoodsNo_minpackage,@fQty_minPackage=fQty_minPackage
		from t_goods 
		where cGoodsNO=@cGoodsNo and isnull(fQty_minPackage,0)>0 
		and isnull(cGoodsNo_minpackage,'')=isnull(cGoodsNo_minPackage_tmp,'')
    and isnull(cGoodsNo_minPackage_tmp,'')<>''
    
		declare @iCount_pd int
		set @iCount_pd=0
		set @iCount_pd=isnull((select count(dDate) from wh_CheckWh where dDate=@dDate_sheet
		and cSheetno in (select distinct cSheetno from wh_CheckWhDetail)),0)    
    
		declare @fQty_Diff_str varchar(32)
		declare @iExist int
		set @iExist=0
		set @iExist=isnull((select count(cGoodsNO) from t_wh_form where cGoodsNo=@cGoodsNo and cWHno=@cWHno ),0)

		/* @iExist>0 表明 cGoodsNo 没有关联商品审核，否则@iExist=0*/
		if (@cGoodsNo_minpackage is null) or (@iExist>0)
		begin   /*没有关联商品信息*/
		
			select @iMyIdentity=iMyIdentity
			from dbo.T_WH_Form
			where cWhNo=@cWHno and isnull(iAttribute,0)=0 and iLineNo=@iLineNo and cSheetNo=@cSheetno
			
			
			
			if @iMyIdentity is not null
			begin
				update T_WH_Form set fPrice_In=@fPrice_new,fPrice_Out=@fPrice_new,fPrice_Left=@fPrice_new,
				fQty_In=fQty_In+@fQty_Diff,fQty_Left=fQty_Left+@fQty_Diff,
				fMoney_Left=(fQty_Left+@fQty_Diff)*@fPrice_new,
				fMoney_Out=fQty_Out*@fPrice_new
				where cGoodsNo=@cGoodsNo and cWhNo=@cWHno and isnull(iAttribute,0)=0 and iLineNo=@iLineNo

				  update t_Cost_distribute
				  set fPrice_Cost=@fPrice_new,fMoney_Cost=@fPrice_new*fQty_Cost,fQty=fQty+@fQty_Diff
				  where iSerno=@iMyIdentity and cGoodsNo=@cGoodsNo 
			
				  set @fQty_Diff_str=CAST(@fQty_Diff as varchar(32))
				  
				if @iCount_pd=0
				begin
					exec('update '+@cDbName+'.dbo.t_Goods_CurWH_relation '
					+' set fQuantity=fQuantity+'+@fQty_Diff_str+','
					+'  fQty_In=fQty_In+'+@fQty_Diff_str+','
					+'  total_In=total_In+'+@fQty_Diff_str+','
					+'  fPrice_Avg=
					case when (total_In+'+@fQty_Diff_str+')>0 then
					 fMoney_In_all/(total_In+'+@fQty_Diff_str+')
					 else fPrice_Avg
					 end '
					+' where dDateTime>='''+@dDate_sheet+''' and cGoodsNo='''+@cGoodsNo+'''')
				end else
				begin
					exec('update '+@cDbName+'.dbo.t_Goods_CurWH_relation '
					+' set fQuantity=fQuantity+'+@fQty_Diff_str+','
					+'  fQty_In=fQty_In+'+@fQty_Diff_str+','
					+'  total_In=total_In+'+@fQty_Diff_str+','
					+'  fPrice_Avg=
					case when (total_In+'+@fQty_Diff_str+')>0 then
					 fMoney_In_all/(total_In+'+@fQty_Diff_str+')
					 else fPrice_Avg
					 end ,
					 fQty_pd_diff=fQty_pd_diff+'+@fQty_Diff_str
					+' where dDateTime>='''+@dDate_sheet+''' and cGoodsNo='''+@cGoodsNo+'''')
				end
			
			  update wh_InWarehouseDetail
			  set fQty_Original=fQuantity,fPrice_In_Original=fInPrice,fQuantity=@fQty_new,fInPrice=@fPrice_new
			  where cSheetno=@cSheetno and iLineNo=@iLineNo and cGoodsNo=@cGoodsNo

			  update t_Stock_Cost_ProfitsRatio_chen
			  set bChecked=1,dCheced=GETDATE()
			  where cGoodsNo=@cGoodsNo and cSheetno=@cSheetno and iLineNo_sheet=@iLineNo
			  
			end
    end else
         begin/*存在关联商品信息*/
			select @iMyIdentity=iMyIdentity
			from dbo.T_WH_Form
			where cWhNo=@cWHno and isnull(iAttribute,0)=0 and iLineNo=@iLineNo and cSheetNo=@cSheetno
			if (@iMyIdentity is not null) and (@fQty_minPackage>0)
			begin
				update T_WH_Form set fPrice_In=@fPrice_new/@fQty_minPackage,fPrice_Out=@fPrice_new/@fQty_minPackage,fPrice_Left=@fPrice_new/@fQty_minPackage,
				fQty_In=fQty_In+@fQty_Diff*@fQty_minPackage,fQty_Left=fQty_Left+@fQty_Diff*@fQty_minPackage,
				fMoney_Left=(fQty_Left+@fQty_Diff*@fQty_minPackage)*@fPrice_new/@fQty_minPackage,
				fMoney_Out=(fQty_Out*@fPrice_new/@fQty_minPackage)
				where cGoodsNo=@cGoodsNo_minpackage and cWhNo=@cWHno and isnull(iAttribute,0)=0 and iLineNo=@iLineNo
			  update t_Cost_distribute
			  set fPrice_Cost=@fPrice_new/@fQty_minPackage,fMoney_Cost=@fPrice_new/@fQty_minPackage*fQty_Cost,fQty=fQty+@fQty_Diff*@fQty_minPackage
			  where iSerno=@iMyIdentity and cGoodsNo=@cGoodsNo_minpackage 


			  set @fQty_Diff_str=CAST(@fQty_Diff as varchar(32))
				if @iCount_pd=0
				begin
					exec('update '+@cDbName+'.dbo.t_Goods_CurWH_relation '
					+' set fQuantity=fQuantity+'+@fQty_Diff_str+','
					+'  fQty_In=fQty_In+'+@fQty_Diff_str+','
					+'  total_In=total_In+'+@fQty_Diff_str+','
					+'  fPrice_Avg=
					case when (total_In+'+@fQty_Diff_str+')>0 then
					 fMoney_In_all/(total_In+'+@fQty_Diff_str+')
					 else fPrice_Avg
					 end '
					+' where dDateTime>='''+@dDate_sheet+''' and cGoodsNo='''+@cGoodsNo+'''')
				end else
				begin
					exec('update '+@cDbName+'.dbo.t_Goods_CurWH_relation '
					+' set fQuantity=fQuantity+'+@fQty_Diff_str+','
					+'  fQty_In=fQty_In+'+@fQty_Diff_str+','
					+'  total_In=total_In+'+@fQty_Diff_str+','
					+'  fPrice_Avg=
					case when (total_In+'+@fQty_Diff_str+')>0 then
					 fMoney_In_all/(total_In+'+@fQty_Diff_str+')
					 else fPrice_Avg
					 end ,
					 fQty_pd_diff=fQty_pd_diff+'+@fQty_Diff_str
					+' where dDateTime>='''+@dDate_sheet+''' and cGoodsNo='''+@cGoodsNo+'''')
				end
				
			
			  update wh_InWarehouseDetail
			  set fQty_Original=fQuantity,fPrice_In_Original=fInPrice,fQuantity=@fQty_new,fInPrice=@fPrice_new
			  where cSheetno=@cSheetno and iLineNo=@iLineNo and cGoodsNo=@cGoodsNo
			  			  
			  update t_Stock_Cost_ProfitsRatio_chen
			  set bChecked=1,dCheced=GETDATE()
			  where cGoodsNo=@cGoodsNo and cSheetno=@cSheetno and iLineNo_sheet=@iLineNo			  
			end
			
    end
	--	commit tran
	--end try
	--begin catch
	--	rollback
	--end catch
				  
  
end
GO
