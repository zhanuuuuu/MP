

/*
--select * from #temp_Goods
--select cGoodsNo into #temp_Goods from t_Goods where cGoodsNo='21041016'
p_FIFO_SalesProfit_MultSupplier '2009-11-8','2009-12-28','04'

select sum(flastSettle)
from t_salesheet_day
where dSaleDate='2009-11-28'


*/
CREATE   procedure [dbo].[p_FIFO_SalesProfit_MultSupplier_jiesuan]
@dDate1 datetime,
@dDate2 datetime
--@Type int,--0:按商品列表查，1：商品类别 2：供应商
--@cWHno varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）
begin
--     when a.iAttribute=0 then '采购入库'
--     when a.iAttribute=1 then '出库'
--     when a.iAttribute=2 then '返厂'
--     when a.iAttribute=3 then '客退'
--     when a.iAttribute=4 then '调拨'
--     when a.iAttribute=5 then '报损'
--     when a.iAttribute=6 then '报溢'
--     when a.iAttribute=7 then '差价'
--     when a.iAttribute=8 then '原料出库'
--     when a.iAttribute=9 then '加工入库'
--     when a.iAttribute=10 then '日结'
--     when a.iAttribute=11 then '盘点溢出'
--     when a.iAttribute=12 then '盘点报损'
--     when a.iAttribute=13 then 'POS客退

	/*注意一品多商的情况*/
	if(select object_id('tempdb..#temp_Sale_Cost_distribute')) is not null
	begin
		drop table 	#temp_Sale_Cost_distribute
	end 

  declare @dDate_MaxAccount datetime
  select @dDate_MaxAccount=isnull(max(dDate),'2000-01-01') 
	from dbo.t_Daily_history
  where isnull(bAccount,0)=1 

  select c.cWHno,c.dSaleDate,	c.cGoodsNo,c.iSeed,c.fQuantity,c.fLastSettle,c.fProfitsRatio,c.cWHno,c.bAuditing
  into #temp_SaleSheet_Day
  from t_SaleSheet_Day c,#temp_Goods a
	where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
	and a.cGoodsNo=c.cGoodsNo

	select c.cGoodsNo,c.bAuditing,dDateTime=case when a.dDateTime is not null then a.dDateTime else c.dSaleDate end,
	a.iSerno,a.cSupplierNo,a.cSupplier,
	a.fPrice_In,a.fQty_In,a.fMoney_In,a.cWhNo,
	iLineNo=case when b.iLineNo is not null then b.iLineNo else 1 end,
	b.fPrice_Cost,fQty_Cost=case when b.fQty_Cost is not null then  b.fQty_Cost else c.fQuantity end,b.fMoney_Cost,
  dDate_Sheet=case when b.dDate_Sheet is not null then b.dDate_Sheet else c.dSaleDate end
	,fMoney_sale_whole=c.fLastSettle,fQty_Sale_whole=c.fQuantity,c.fProfitsRatio,
	fMoney_sale_distribute=b.fMoney_sale,
	fQty_sale_distribute=b.fQty_Cost,IDENTITY(int, 1,1) AS iSeedNo

	into #temp_Sale_Cost_distribute
	from dbo.#temp_SaleSheet_Day c left join dbo.t_Cost_distribute b 
				on c.dSaleDate=b.dDate_Sheet and c.cGoodsNo=b.cGoodsNo and b.iLineNo=c.iSeed
           and b.dDate_Sheet<=@dDate_MaxAccount and b.dDate_Sheet between @dDate1 and @dDate2 
           and isnull(b.bDone,0)=0 and b.iAttribute=10 and b.cWHno=c.cWHno
       left join dbo.t_WH_Form a
        on a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and a.cWhNo=c.cWHno
	where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
	--and c.cWHno=@cWHno

	

	--alter table #temp_Sale_Cost_distribute  add iSeedNo int identity(1,1)
/*
	update a
	set a.fQty_sale_distribute=a.fQty_Cost,
	fMoney_sale_distribute
	=case when a.fQty_Sale_whole<>0 then a.fMoney_sale_whole*a.fQty_Cost/a.fQty_Sale_whole
	 else 0
	 end
	from #temp_Sale_Cost_distribute a
  update a
  set a.fMoney_sale_distribute=a.fMoney_sale_distribute+(y.fMoney_sale_whole-y.fMoney_sale_distribute)
  from #temp_Sale_Cost_distribute a,
  ( select x.* from
		(
			select cGoodsNo,dDateTime,fMoney_sale_whole,iLineNo,fMoney_sale_distribute=sum(fMoney_sale_distribute),
			iSeedNo=max(iSeedNo)
			from #temp_Sale_Cost_distribute
			group by cGoodsNo,dDateTime,fMoney_sale_whole,iLineNo
		) x where x.fMoney_sale_whole<>fMoney_sale_distribute
  )y
  where a.iSeedNo=y.iSeedNo and a.cGoodsNo=y.cGoodsNo
*/
	/*以上处理四舍五入造成的 销售金额 损耗*/

  update #temp_Sale_Cost_distribute
  set fMoney_sale_distribute=fMoney_sale_whole,fQty_sale_distribute=fQty_Sale_whole
  where iSerno is null

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=fMoney_sale_distribute
  from #temp_Sale_Cost_distribute a,dbo.t_Goods b--供应商为空
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null
--select * from #temp_Sale_Cost_distribute

--select * from t_Goods where cGoodsNo='32051019'

	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost=sum(fQty_Cost),fMoney_Cost=sum(fMoney_Cost),
	fMoney_sale_distribute=sum(fMoney_sale_distribute),bAuditing
	into #temp_Sale_Cost_distribute_Daily
	from #temp_Sale_Cost_distribute
  group by cSupplierNo,cSupplier,dDate_Sheet,cGoodsNo,bAuditing

  /*以下计算（预估） 计算未参加日结记账的销售毛利*/
  
  select a.dSaleDate,a.cGoodsNo,a.fQuantity,a.fLastSettle,a.bAuditing
  into #temp_salesheetdetail0
  from t_salesheetdetail a,#temp_Goods b
	where a.dSaleDate >@dDate_MaxAccount and  a.dSaleDate between @dDate1 and @dDate2 and a.cGoodsNo=b.cGoodsNo
  union all
	select e.dSaleDate,e.cGoodsNo,e.fQuantity,e.fLastSettle,e.bAuditing ---顾客退货单
	from
  (
		select c.cGoodsNo,c.cGoodsName,c.cBarCode,fQuantity=-c.fQuantity,fLastSettle=-c.fInMoney,dSaleDate=d.dDate,bAuditing=0
		from dbo.WH_ReturnGoodsDetail c,dbo.WH_ReturnGoods d ,#temp_Goods k
		where  d.dDate between @dDate1 and @dDate2 and c.cSheetno=d.cSheetno and c.cGoodsNo=k.cGoodsNo
  ) e
  

--select * from #temp_salesheetdetail0

	select cGoodsNo,cSupplierNo=cast(null as varchar(32)),cSupplier=cast(null as varchar(64)),
	dDate_Sheet=dSaleDate,fQty_Cost=sum(fQuantity),fMoney_Cost=cast(0 as money),
  fMoney_sale_distribute=sum(fLastSettle),bAuditing
  into #temp_salesheetdetail 
	from #temp_salesheetdetail0  
	where dSaleDate >@dDate_MaxAccount and  dSaleDate between @dDate1 and @dDate2 
	group by cGoodsNo,dSaleDate ,bAuditing   

  update a
  set a.cSupplierNo=b.cSupplierNo,a.cSupplier=b.cSupplier,
  a.fMoney_Cost=a.fQty_Cost*b.fPrice_In
  from #temp_salesheetdetail a,
  (
		select k.cGoodsNo,k.dDateTime,k.iSerno,k.cSupplierNo,k.cSupplier,
		k.fPrice_In,k.fQty_In,k.fMoney_In
		from dbo.T_WH_Form k,
    (
      select cGoodsNo,iSerno=max(iSerno) --取最近一次成本
      from T_WH_Form
  		where dDateTime<=@dDate2 and iAttribute=0 and iAttribute is not null
      group by cGoodsNo

    ) j
		where k.dDateTime<=@dDate2 and k.iSerno=j.iSerno and k.cGoodsNo=j.cGoodsNoand 
		and  k.iAttribute=0 and k.iAttribute is not null
		
  ) b
  where a.cGoodsNo=b.cGoodsNo and b.fPrice_In is not null

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=fMoney_sale_distribute
  from #temp_salesheetdetail a,dbo.t_Goods b--没有记账成本
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null


  /*以上计算（预估） 计算未参加日结记账的销售毛利*/

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=fMoney_sale_distribute
  from #temp_Sale_Cost_distribute_Daily a,dbo.t_Goods b--没有记账成本
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null

--select * into ##temp_Sale_Cost_distribute from #temp_Sale_Cost_distribute

  select b.*,fProfitRatio=cast(null as money),fMoney_Profit_sum=cast(0 as money),fProfitRatio_avg=cast(null as money)
	into #temp_Sale_Cost
  from
  (
	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost,fMoney_Cost,fMoney_sale_distribute,cDetail='记账',bAuditing
  from #temp_Sale_Cost_distribute_Daily
	union all
	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost,fMoney_Cost,fMoney_sale_distribute,cDetail='未记账',bAuditing
  from #temp_salesheetdetail
	) b

  update #temp_Sale_Cost
  set fMoney_Cost=fMoney_sale_distribute
  where fMoney_Cost is null

  update a set a.fProfitRatio=b.fRatio
  from #temp_Sale_Cost a,
  (
    select cSupplierNo=guizuno,fRatio=max(fRatio)
    from dbo.t_Supplier_Contract_Ratio
    group by  guizuno
  ) b
  where a.cSupplierNo=b.cSupplierNo

  update #temp_Sale_Cost
  set fMoney_Profit_sum=(fMoney_Sale_distribute-fMoney_Cost)+fMoney_Sale_distribute*isnull(fProfitRatio,0)/100

  update #temp_Sale_Cost 
  set fProfitRatio_avg=case when isnull(fMoney_Sale_distribute,0)<>0
											  then fMoney_Profit_sum/fMoney_Sale_distribute*100 else null end

/* 以下处理策略活动t_PloyOfSale的毛利变动*/

  select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
  into #temp_PloyOfSale
  from t_PloyOfSale
  where (dDateStart between @dDate1 and @dDate2)
   or (dDateEnd  between @dDate1 and @dDate2)
	group by cGoodsNo,dDateStart,dDateEnd

	select  a.cGoodsNo,a.dDate_Sheet,a.fMoney_sale_distribute,
					a.fQty_Cost,a.bAuditing,b.dDateStart,b.dDateEnd,fSupRatio=isnull(b.fSupRatio,0)
	into #t_SaleSheetDetail_bybAuditing
	from #temp_Sale_Cost a
	left join #temp_PloyOfSale b on a.dDate_Sheet between b.dDateStart and b.dDateEnd
	     and b.cGoodsNo=a.cGoodsNo
  where isnull(a.bAuditing,0)=1 and b.dDateStart is not null

  update a
  set a.fMoney_Profit_sum=a.fMoney_Sale_distribute*b.fSupRatio/100.00,
  a.fMoney_Cost=a.fMoney_Sale_distribute*(1-b.fSupRatio/100.00)
  from #temp_Sale_Cost a,#t_SaleSheetDetail_bybAuditing b
  where a.cGoodsNo=b.cGoodsNo and a.dDate_Sheet between b.dDateStart and b.dDateEnd and isnull(a.bAuditing,0)=1

/* 以上处理策略活动的毛利变动*/


  select cGoodsNo,cSupplierNo,cSupplier,fQty_Cost=sum(isnull(fQty_Cost,0)),
  fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0)),
  fProfitRatio,
  fProfitRatio_avg=case when sum(isnull(fMoney_Sale_distribute,0))<>0
											  then sum(isnull(fMoney_Profit_sum,0))/sum(isnull(fMoney_Sale_distribute,0))*100 
									 else null end,
  fMoney_Profit_sum=sum(isnull(fMoney_Profit_sum,0)),
  fCostPrice=case when sum(isnull(fQty_Cost,0))<>0
											  then sum(isnull(fMoney_Cost,0))/sum(isnull(fQty_Cost,0))
									 else null end,
  fMoney_Cost=sum(isnull(fMoney_Cost,0)),
	fML=sum(isnull(fMoney_Profit_sum,0))

  into #temp_Sale_Cost99
  from #temp_Sale_Cost
  group by cGoodsNo,cSupplierNo,cSupplier,fProfitRatio

  select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
				b.cGoodsTypeno,b.cGoodsTypename,bProducted=null,cProductNo=null,
        BeginDate=@dDate1,EndDate=@dDate2,a.cSupplierNo,cSupName=a.cSupplier,
        xsQty=isnull(a.fQty_Cost,0),xsMoney=isnull(a.fMoney_sale_distribute,0),
				a.fProfitRatio,a.fProfitRatio_avg,a.fMoney_Profit_sum,
				fCostPrice=case when isnull(a.fQty_Cost,0)<>0 
									      then a.fMoney_Cost/a.fQty_Cost else null end,
        a.fMoney_Cost,
				fML=a.fMoney_Profit_sum
  into #temp_goodsKuCun
  from #temp_Sale_Cost99 a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo



--  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
--         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,fProfitRatio,fMoney_Profit_sum,fProfitRatio_avg,
--         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),fML=isnull(xsMoney,0)-isnull(fMoney_Cost,0)
--  from #temp_goodsKuCun
--  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=sum(isnull(fMoney_Profit_sum,0)),
         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then sum(isnull(fMoney_Profit_sum,0))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0))
  from #temp_goodsKuCun 
  group by cSupplierNo,cSupName,BeginDate,EndDate
--  union all
--  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
--         BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
--         fProfitRatio=null,fMoney_Profit_sum=sum(isnull(fMoney_Profit_sum,0)),
--         fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then sum(isnull(fMoney_Profit_sum,0))/sum(isnull(xsMoney,0))*100 else null end ,
--         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(fMoney_Cost,0))
--  from #temp_goodsKuCun
--  group by BeginDate,EndDate
--  order by cSupplierNo,cGoodsTypeno,cGoodsNo



end


GO
