--select top 1* from wh_InWarehouse
--select top 1* from wh_InWarehouseDetail
--select top 1* from t_goods
create proc P_CorrectInWareSup
as

if (select OBJECT_ID('tempdb..#tmpInWhGoods'))is not null
drop table #tmpInWhGoods
select a.cSheetno,a.cGoodsNo,a.cGoodsName,c.cGoodsTypeno,c.cGoodsTypename,
cSupNO_inWh=b.cSupplierNo,cSupName_inWh=b.cSupplier,
cSupNo_info=c.cSupNo,cSupName_info=c.cSupName,
cSupNO_new=CAST(null as varchar(32)),cSupName_new=CAST(null as varchar(64))
into #tmpInWhGoods
from wh_InWarehouseDetail a,wh_InWarehouse b,t_goods c
where a.cSheetno=b.cSheetno and a.cGoodsNo=c.cGoodsNo
order by c.cSupNo,c.cGoodsTypeno

select distinct 
cSupNo_info,cSupName_info,cGoodsTypeNO,cGoodsTypeName,cSupNO_inWh,cSupName_inWh,
cSupNO_new,cSupName_new
from #tmpInWhGoods
order by cSupNO_new,cGoodsTypeNO

GO
