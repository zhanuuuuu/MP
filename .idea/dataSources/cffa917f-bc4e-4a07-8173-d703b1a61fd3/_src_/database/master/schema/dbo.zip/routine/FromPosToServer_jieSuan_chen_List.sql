/*
   [FromPosToServer_jieSuan_chen_List] 'Pos_Day','2'
*/

CREATE proc [dbo].[FromPosToServer_jieSuan_chen_List]
@Pos_Day varchar(32),
@iDays  varchar(3)
as
begin
exec('
  
  --declare @iDays int
  --set @iDays=2
	begin try
		begin tran
		/*老版本兼容，现在可以注释掉 
			update a
			set a.cWhno=b.cWhno
			from '+@Pos_Day+'.dbo.jiesuan a,t_WareHouse b,t_Posstation c
			where a.zdriqi>=(getdate()-'+@iDays+') and isnull(b.bMainSale,0)=1 and
			 b.cStoreNo=c.cStoreNo and a.cWHNo=b.cWhNo 
		
			update a
			set a.cWhno=b.cWhno
			from jiesuan a,t_WareHouse b
			where a.zdriqi>=(getdate()-'+@iDays+') and isnull(b.bMainSale,0)=1 
		*/
			if DATEPART ( hh, getdate())>22
			begin
				update t_Goods_Vip
				set fQty_CurSale=0
			end
			
		 
			select distinct sheetno,jstype,cWhNo 
			into #jiesuan
			from '+@Pos_Day+'.dbo.jiesuan a 
			where isnull(bPost,0)=0 and zdriqi>=(getdate()-'+@iDays+')
			
			select   distinct a.sheetno,a.jstype,a.cWhNo
			into #temp_bPost1
			from jiesuan a, #jiesuan b
			where a.zdriqi>=(getdate()-'+@iDays+') and a.sheetno=b.sheetno and a.jstype=b.jstype
			and a.cWhNo=b.cWhNo
			
			update a
			set a.bPost=1
			from '+@Pos_Day+'.dbo.jiesuan   a, #temp_bPost1 b
			where a.zdriqi>=(getdate()-'+@iDays+') and a.sheetno=b.sheetno and a.jstype=b.jstype 
			and a.cWhNo=b.cWhNo
			
			delete a
			from #jiesuan  a, #temp_bPost1 b
			where a.sheetno=b.sheetno and a.jstype=b.jstype 
			and a.cWhNo=b.cWhNo
			
			insert into dbo.jiesuan
			(
				sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,jiaozhang,
				jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
				shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,
				detail,
				tag_daily,cWHno,cStoreNo,invoiceNo
			)
			select distinct a.sheetno,a.jstype,a.mianzhi,a.zhekou,a.zhaoling,a.shishou,a.jstime,a.zdriqi,a.jiaozhang,
				a.jiaozhangtime,a.jiaozhangdate,a.shouyinyuanno,a.shouyinyuanmc,a.jiaokuantime,
				a.shoukuanno,a.shoukuanname,a.netjiecun,a.orientmoney,a.leftmoney,a.storevalue,
				a.detail,
				a.tag_daily,c.cWhno,c.cStoreNo,a.invoiceNo
			from '+@Pos_Day+'.dbo.jiesuan as a,#jiesuan as b,v_Posstation c
			where a.sheetno=b.sheetno and substring(a.sheetno,1,2)=c.PosID and a.jstype=b.jstype
			and b.cWhNo=c.cWhNo

			
			--------------------------2015-09-08获取储值卡消费-------------------------------
			if (select OBJECT_ID(''tempdb..#temp_MoneycardJiesuan''))is not null drop table #temp_MoneycardJiesuan
			select distinct a.sheetno,a.zdriqi,b.cWhNo into #temp_MoneycardJiesuan
			from '+@Pos_Day+'.dbo.jiesuan as a,#jiesuan as b,v_Posstation c 
			where a.sheetno=b.sheetno and substring(a.sheetno,1,2)=c.PosID and a.jstype=b.jstype
			and a.jstype like ''储值卡%''
			and b.cWhNo=c.cWhNo
			
			---已有单号。。
			delete a 
			from #temp_MoneycardJiesuan a,Moneycardjiesuan b
			where a.sheetno=b.sheetno and a.zdriqi=b.zdriqi and a.cWhNo=b.cWhNo
			
			 insert into dbo.Moneycardjiesuan
			(
				sheetno,jstype,mianzhi,zhekou,zhaoling,shishou,jstime,zdriqi,jiaozhang,
				jiaozhangtime,jiaozhangdate,shouyinyuanno,shouyinyuanmc,jiaokuantime,
				shoukuanno,shoukuanname,netjiecun,orientmoney,leftmoney,storevalue,
				detail,
				tag_daily,cWHno,cStoreNo
			)
			select distinct a.sheetno,a.jstype,a.mianzhi,a.zhekou,a.zhaoling,a.shishou,a.jstime,a.zdriqi,a.jiaozhang,
				a.jiaozhangtime,a.jiaozhangdate,a.shouyinyuanno,a.shouyinyuanmc,a.jiaokuantime,
				a.shoukuanno,a.shoukuanname,a.netjiecun,a.orientmoney,a.leftmoney,a.storevalue,
				a.detail,
				a.tag_daily,c.cWhno,c.cStoreNo
			from '+@Pos_Day+'.dbo.jiesuan as a,#jiesuan as b,v_Posstation c 
			where a.sheetno=b.sheetno and substring(a.sheetno,1,2)=c.PosID and a.jstype=b.jstype
			and a.jstype like ''储值卡%''
			and b.cWhNo=c.cWhNo
			
			---已有明细单号。。
			delete a 
			from #temp_MoneycardJiesuan a,t_MoneycardSaleSheetDetail b
			where a.sheetno=b.cSaleSheetno and a.zdriqi=b.dSaleDate
			 and a.cWhNo=b.cWhNo
			
			insert into	 dbo.t_MoneycardSaleSheetDetail
			(
				cSaleSheetno,iSeed,cGoodsNo,cGoodsName,cBarCode,cOperatorno,cOperatorName,
				cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,fPrice,fNormalSettle,
				bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,fAgio,fLastSettle0,fLastSettle,
				cManager,cManagerno,dSaleDate,cSaleTime,dFinanceDate,cWorkerno,cWorker,	 
				cVipNo,bBalance,jiesuanno,cStationNo,tag_daily,cWHno,
				bHidePrice,bHideQty ,bWeight,
				fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited,fVipScore_cur,cStoreNo 
			)
			select distinct a.cSaleSheetno,a.iSeed,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cOperatorno,a.cOperatorName,
				a.cVipCardno,a.bAuditing,a.cChkOperno,a.cChkOper,a.bSettle,a.fVipScore,a.fPrice,a.fNormalSettle,
				a.bVipPrice,a.fVipPrice,a.bVipRate,a.fVipRate,a.fQuantity,a.fAgio,a.fLastSettle0,a.fLastSettle,
				a.cManager,a.cManagerno,a.dSaleDate,a.cSaleTime,a.dFinanceDate,a.cWorkerno,a.cWorker,		 
				a.cVipNo,a.bBalance,a.jiesuanno,a.cStationNo,a.tag_daily,a.cWhno,
                a.bHidePrice,a.bHideQty ,a.bWeight,
                a.fNormalVipScore ,a.bExchange ,a.fSupRatio_exchange,a.bPresent,a.bSend,a.bLimited,a.fVipScore_cur,d.cStoreNo
			from '+@Pos_Day+'.dbo.t_SaleSheetDetail as a , #temp_MoneycardJiesuan b ,v_Posstation d
			where  a.dSaleDate=b.zdriqi and a.cSaleSheetno=b.sheetno and b.cWhNo=d.cWhNo
            
			
			update a
			set a.bPost=1
			from '+@Pos_Day+'.dbo.jiesuan a,#jiesuan b
			where a.sheetno=b.sheetno and a.jstype=b.jstype and a.cWhNo=b.cWhNo
		commit tran
	end try
	begin catch
		rollback
	end catch
 ')		
end

/*
FromPosToServer_jieSuan_chen
*/
GO
