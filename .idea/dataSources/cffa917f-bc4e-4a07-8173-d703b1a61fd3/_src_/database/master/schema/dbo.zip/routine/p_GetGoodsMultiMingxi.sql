 /*
 
 exec p_GetGoodsMultiMingxi '2015-05-05','2015-05-04','01','2310107'
 
 exec p_GetGoodsMultiMingxi '2015-05-05','2015-05-06','01','2310107'
 
*/
create proc p_GetGoodsMultiMingxi
@dDate1   datetime,
@dDate2   datetime,
@cWhno    varchar(32),
@cGoodsno varchar(32)
as
begin
    
    declare @maxWhForm datetime
    declare @cdbname varchar(32)
    select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno
 
	 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	 create table #temp_maxWhdDate(dDate datetime)

	insert into #temp_maxWhdDate(dDate)
	exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock) ')
	set @maxWhForm=(select dDate from #temp_maxWhdDate)
    
    if @dDate2>@maxWhForm
    begin
       set @dDate2=@maxWhForm
    end 
    
    declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDate1-1)
    set @strDateEnd=dbo.getdaystr(@dDate2)
    
    if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
    create table #temp_WhFromend(业务日期 datetime,cgoodsno varchar(32),cgoodsname varchar(64),dDateTime datetime,
    批次单号 varchar(32),批次成本 money,批次供应商 varchar(64),批次供应商号 varchar(32),
	批次累计销售 money,批次累计销售金额 money,批次成本金额 money,批次毛利 money,fQty_Left money,cGoodsNo_Parent varchar(32))
    
    insert into #temp_WhFromend(业务日期,cgoodsno,dDateTime,
    批次单号,批次成本,批次供应商,批次供应商号,
	批次累计销售,批次累计销售金额,批次成本金额,批次毛利,fQty_Left,cGoodsNo_Parent)
    exec(' 
	select 业务日期,cgoodsno,dDateTime,批次单号=cSheetNo,批次成本=fPrice_In,批次供应商=cSupplier,批次供应商号=cSupplierNo,
	批次累计销售=销售数量0,批次累计销售金额=销售金额0,批次成本金额=fPrice_In*销售数量0,批次毛利=销售金额0-fPrice_In*销售数量0
	,fQty_Left,cGoodsNo_Parent
	from Pos_WH_Form.dbo.t_WH_Form_Log_1
	where 业务日期='''+@strDateEnd+''' and cGoodsNo='''+@cGoodsno+'''
	union all
	select 业务日期,cgoodsno,dDateTime,批次单号=cSheetNo,批次成本=fPrice_In,批次供应商=cSupplier,批次供应商号=cSupplierNo,
	批次累计销售=销售数量0,批次累计销售金额=销售金额0,批次成本金额=fPrice_In*销售数量0,批次毛利=销售金额0-fPrice_In*销售数量0
	,fQty_Left,cGoodsNo_Parent
	from Pos_WH_Form.dbo.t_WH_Form_log_0
	where 业务日期 between '''+@strDateBgn+''' and '''+@strDateEnd+''' and cGoodsNo='''+@cGoodsno+''' and iAttribute<>20

   ')  
   /*
    insert into #temp_WhFromend(业务日期,cgoodsno,dDateTime,
    批次单号,批次成本,批次供应商,批次供应商号,
	批次累计销售,批次累计销售金额,批次成本金额,批次毛利)
    exec(' 
	select 业务日期,cgoodsno,dDateTime,批次单号=cSheetNo,批次成本=fPrice_In,批次供应商=cSupplier,批次供应商号=cSupplierNo,
	批次累计销售=销售数量0,批次累计销售金额=销售金额0,批次成本金额=fPrice_In*销售数量0,批次毛利=销售金额0-fPrice_In*销售数量0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_1
	where 业务日期='''+@strDateBgn+''' and cGoodsNo='''+@cGoodsno+'''
	union all
	select 业务日期,cgoodsno,dDateTime,批次单号=cSheetNo,批次成本=fPrice_In,批次供应商=cSupplier,批次供应商号=cSupplierNo,
	批次累计销售=销售数量0,批次累计销售金额=销售金额0,批次成本金额=fPrice_In*销售数量0,批次毛利=销售金额0-fPrice_In*销售数量0 
	from Pos_WH_Form.dbo.t_WH_Form_log_0
	where 业务日期= '''+@strDateBgn+'''  and cGoodsNo='''+@cGoodsno+''' and iAttribute<>20

   ')
   */
   select 业务日期,dDateTime,a.cgoodsno,b.cgoodsname,
    批次单号,批次成本,批次供应商,批次供应商号,
	批次累计销售,批次累计销售金额,批次成本金额,批次毛利,fQty_Left,cGoodsNo_Parent
	from #temp_WhFromend a,t_Goods b
	where a.cgoodsno=b.cGoodsNo
	union all
	select 业务日期='9999-01-01',dDateTime=null,cgoodsno='合计：',cgoodsname=null,
    批次单号=null,sum(批次成本),批次供应商=null,批次供应商号=null,
	sum(批次累计销售),sum(批次累计销售金额),sum(批次成本金额),sum(批次毛利),sum(fQty_Left),cGoodsNo_Parent=null
	from #temp_WhFromend  
	order by 业务日期
end
 GO
