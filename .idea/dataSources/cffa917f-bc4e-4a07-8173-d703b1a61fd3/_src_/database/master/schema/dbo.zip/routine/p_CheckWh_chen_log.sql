/*
p_CheckWh_chen '001'
select distinct cCheckTaskNo,cCheckTask,dCheckTask from t_CheckTast_GoodsDetail_log
select sum(fMoney_Diff) from t_CheckTast_GoodsDetail_log where cCheckTaskNo='002'
select sum(fMoney_Diff) from t_CheckTast_GoodsDetail_log where cCheckTaskNo='001'
select sum(fMoney_Diff) from #tmp_GoodsCheckList2010_1
4-25 26791.5839         001
4-25 -253694.3534       002

exec [p_CheckWh_chen_log] '161231-003'

*/
CREATE proc [dbo].[p_CheckWh_chen_log]
@cTaskNo varchar(100)
as

declare @cTaskDate datetime set @cTaskDate='2012-08-27'

declare @cStoreNo varchar(32)

update a
set a.fCKPrice=b.fCKPrice
from t_Goods a,
(
	select cGoodsNo_min=cGoodsNo_minPackage,
	fCKPrice=MAX(fCKPrice/case when isnull(fQty_minPackage,0)=0 then 1 else fQty_minPackage end)
	from t_Goods
	where 
	dbo.trim(isnull(cGoodsNo_minPackage,''))<>'' and
	ISNULL(fQty_minPackage,0)>0 and
	dbo.trim(isnull(cCkPriceInSheetno,''))<>''
  group by 	cGoodsNo_minPackage
) b
where a.cGoodsNo=b.cGoodsNo_min and dbo.trim(isnull(a.cCkPriceInSheetno,''))=''


/*----------------------------------------------------*/


declare @cWhNo varchar(32),@date datetime
select @cWhNo=cWhNo,@date=dCheckTask,@cStoreNo=cStoreNo from t_CheckTast where cCheckTaskNo=@cTaskNo

declare @SQLstr varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from t_WareHouse where cStoreNo=@cStoreNo and cWhNo=@cWHno

declare @date1 datetime,@date2 datetime
set @date1='2000-01-01'
set @date2=@date

--要查询的商品
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo_X'))is not null drop table #tmpPloyOfGoodsinfo_X

select distinct c.cGoodsNo,c.cSupNo 
into #tmpPloyOfGoodsinfo_X  --需要查询的商品信息
from wh_CheckWh a left join wh_CheckWhDetail b on a.cSheetno=b.cSheetno
     left join t_goods c 
	 on b.cGoodsNo=c.cGoodsNo and isnull(c.bStorage,0)=1
where a.dDate=@date  and a.cWhNo=@cWHno and ISNULL(c.bStorage,0)=1
----  增加条件
and a.cSupplierNo=@cTaskNo
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo_XX'))is not null drop table #tmpPloyOfGoodsinfo_XX

select distinct x.cGoodsNo 
into #tmpPloyOfGoodsinfo_XX
from 
(
	select cGoodsNO
	from #tmpPloyOfGoodsinfo_X
	union all
	select b.cGoodsNo_minPackage
	from #tmpPloyOfGoodsinfo_X a,t_goods b
	where a.cGoodsNo=b.cGoodsNo 
	union all
	select b.cGoodsNo
	from #tmpPloyOfGoodsinfo_X a,t_goods b
	where a.cGoodsNo=b.cGoodsNo_minPackage
)x

if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null drop table  #temp_dateBaseForKuCun
if(select object_id('tempdb..#temp_dateFrist')) is not null drop table  #temp_dateFrist
create table #temp_dateBaseForKuCun(cGoodsNo varchar(64),cGoodsTypeno varchar(64),EndQty money,fAvgPrice money)

declare @bJiaGong int 

if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select distinct cGoodsNo into #temp_Goods from #tmpPloyOfGoodsinfo_XX  
 
 
---exec [P_x_SetCheckWh_byGoodsType] @date1,@date2,@cWhNo,@bJiaGong
exec P_x_SetCheckWh_byGoodsType_CheckWh_log @cStoreNo,@date1,@date2,@cWhNo
--'2000-01-01','2012-04-25','01',@bJiaGong
      
select * into #temp_dateFrist
from #temp_dateBaseForKuCun




drop table #temp_dateBaseForKuCun

----------------------------------------------------------------------------------------------------
if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null  drop table #GoodsCurStorageList
select dDateTime=@date,cGoodsNo,cWHno=@cWhNo,fAvgPrice,cSupNo='',fQuantity=EndQty,iAttribute=0,fMoney=0
into #GoodsCurStorageList
from #temp_dateFrist

--包装转单品
		if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
		select cGoodsNo,cGoodsNo_MinPackage=case when isnull(cGoodsNo_MinPackage,'')='' 
		then cGoodsNo else cGoodsNo_MinPackage end,fQty_minPackage=case when isnull(fQty_minPackage,1)=0 
		then 1 else isnull(fQty_minPackage,1) end
		into #tmpPackGoodsList
		from t_goods
		where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)
		
		--select * from #tmpPackGoodsList
	 --where cGoodsNO in (select distinct cGoodsNo from t_Goods
	 --where  cGoodsNo_minPackage='13609' or cGoodsNo='13609')
		
 
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage,
		fAvgPrice=fAvgPrice/ISNULL(b.fQty_minPackage,1)
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
	
	 
        
  --      select * from #GoodsCurStorageList
	 --where cGoodsNO in (select distinct cGoodsNo from t_Goods
	 --where (cGoodsNo_minPackage='13609' or cGoodsNo='13609'))
        
 
--结转、销售合计库存更新到#temp_GoodsLeft，平均进价取t_goods进价
        if (select OBJECT_ID('tempdb..#temp_GoodsLeft'))is not null drop table #temp_GoodsLeft
        create table #temp_GoodsLeft
        (cGoodsNo varchar(64),fQuantity money,fPrice_Avg money)
        insert into #temp_GoodsLeft(cGoodsNo,fPrice_Avg)
        select a.cGoodsNo,fPrice_Avg=case when b.fCKPrice=0 then b.fNormalPrice else b.fCKPrice end
        from #tmpPloyOfGoodsinfo_XX a,t_goods b
        where a.cGoodsNo=b.cGoodsNo
        
        --------成本取批次成本
        
        update a
		set a.fPrice_Avg=b.fAvgPrice
		from #temp_GoodsLeft a, #GoodsCurStorageList b
		where a.cGoodsNo=b.cGoodsNo

		update a
		set a.fQuantity=b.fQuantity
		from #temp_GoodsLeft a,
				 (
					select cGoodsNo,fQuantity=Sum(isnull(fQuantity,0))
					from #GoodsCurStorageList
					where cWhNo=@cWhNo
					group by cGoodsNo,cWhNo
				 ) b
		where a.cGoodsNo=b.cGoodsNo
		
		--	   select * from #temp_GoodsLeft
	 --where cGoodsNO in (select distinct cGoodsNo from t_Goods
	 --where  cGoodsNo='5110039' or cGoodsNo='13609')
		
		--	       select * from #temp_GoodsLeft
	 --where cGoodsNO in (select distinct cGoodsNo from t_Goods
	 --where (cGoodsNo_minPackage='13609' or cGoodsNo='13609'))
	 
	     
	 
--------盘点商品信息处理
		if (select OBJECT_ID('tempdb..#temp_CheckTast_GoodsDetail'))is not null drop table #temp_CheckTast_GoodsDetail
		if (select OBJECT_ID('tempdb..#temp_CheckTast_cGoodsNo'))is not null drop table #temp_CheckTast_cGoodsNo
		if (select OBJECT_ID('tempdb..#temp_CheckTast_cGoodsNo1'))is not null drop table #temp_CheckTast_cGoodsNo1

/*2012-05-09改,任务名称直接从盘点任务表[t_CheckTast]中取		
--------------------------------2012-04-28 改
		select cCheckTaskNo=b.cSupplierNo,cCheckTask=b.cSupplier,a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0))
		into #temp_CheckTast_cGoodsNo1
		from wh_CheckWhDetail a,wh_CheckWh b 
		where b.dDate=@date and a.cSheetno=b.cSheetno and b.cWhNo=@cWhNo
		group by b.cSupplierNo,b.cSupplier,a.cGoodsNo
*/		
		select cCheckTaskNo=c.cCheckTaskNo,cCheckTask=c.cCheckTask,a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0))
        into #temp_CheckTast_cGoodsNo1
		from wh_CheckWhDetail a,wh_CheckWh b,t_CheckTast c
		where b.dDate=@date and a.cSheetno=b.cSheetno and b.cWhNo=@cWhNo and b.cSupplierNo=c.cCheckTaskNo
		and b.cSupplierNo=@cTaskNo
		group by c.cCheckTaskNo,c.cCheckTask,a.cGoodsNo
		union all 
		select cCheckTaskNo=@cTaskNo,cCheckTask=b.cCheckTask,cGoodsNo,0
		from #tmpPloyOfGoodsinfo_XX a,t_CheckTast b
		where  b.cCheckTaskNo=@cTaskNo
		
        
		--select * from wh_CheckWh
		--select * from t_CheckTast
		--盘点商品中的包装转单品 --2012-05-17改
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #temp_CheckTast_cGoodsNo1 a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		select cCheckTaskNo,cCheckTask,cGoodsNo,fQuantity=sum(isnull(fQuantity,0))
		into #temp_CheckTast_cGoodsNo
		from #temp_CheckTast_cGoodsNo1
		group by cCheckTaskNo,cCheckTask,cGoodsNo		
--------------------------------2012-04-28 改
		select a.cCheckTaskNo,a.cCheckTask,
		a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,a.fQuantity
		into #temp_CheckTast_GoodsDetail
		from #temp_CheckTast_cGoodsNo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
		
		if (select OBJECT_ID('tempdb..#tmp_GoodsCheckList2010_1'))is not null drop table #tmp_GoodsCheckList2010_1
		select cCheckTaskNo,cCheckTask,
		cGoodsTypeno=cast(null as varchar(32)),cGoodsTypename=cast(null as varchar(64)),
		cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,
		fNormalPrice,
		fQuantity_Sys=cast(null as money),--当前库存
		fMoney_CurSale=cast(null as money),--当前库存金额
		fQuantity_Check=fQuantity,--盘点库存
		fMoney_check=cast(null as money),--盘点库存金额
		fQuantity_Diff=cast(null as money),--盘点差异
		fMoney_Diff=cast(null as money),--盘点差异金额
		fInPrice_Avg=cast(null as money)--平均进价 
		into #tmp_GoodsCheckList2010_1
		from #temp_CheckTast_GoodsDetail
		
		update a
		set a.fInPrice_Avg=b.fPrice_Avg,a.fQuantity_Sys=b.fQuantity
		from #tmp_GoodsCheckList2010_1 a ,#temp_GoodsLeft b 
		where a.cGoodsNo=b.cGoodsNo
		
		
		update a
		set a.fNormalPrice=b.fNormalPrice,a.cGoodsTypeno=b.cGoodsTypeno,a.cGoodsTypename=b.cGoodsTypename,
		a.fInPrice_Avg=case when ISNULL(a.fInPrice_Avg,0)=0 then 
		case when isnull(b.fCKPrice,0)=0 
		then case when isnull(b.fPrice_Contract,0)=0 then b.fNormalPrice else b.fPrice_Contract end else  b.fCKPrice end
		else a.fInPrice_Avg end
		from #tmp_GoodsCheckList2010_1 a ,t_goods b 
		where a.cGoodsNo=b.cGoodsNo
		
		
		update a
		set a.fQuantity_Sys=isnull(d.fQuantity,0),
		    a.fMoney_CurSale=isnull(d.fQuantity,0)*a.fInPrice_Avg,
		    a.fMoney_check=isnull(a.fQuantity_Check,0)*a.fInPrice_Avg,
		    a.fQuantity_Diff=isnull(a.fQuantity_Check,0)-isnull(d.fQuantity,0),
		    a.fMoney_Diff=(isnull(a.fQuantity_Check,0)-isnull(d.fQuantity,0))*a.fInPrice_Avg
		from #tmp_GoodsCheckList2010_1 a ,#temp_GoodsLeft d
		where a.cGoodsNo=d.cGoodsNo
		
		update a
		set a.fQuantity_Sys=isnull(a.fQuantity_Sys,0),
		    a.fMoney_CurSale=isnull(a.fQuantity_Sys,0)*a.fInPrice_Avg,
		    a.fMoney_check=isnull(a.fQuantity_Check,0)*a.fInPrice_Avg,
		    a.fQuantity_Diff=isnull(a.fQuantity_Check,0)-isnull(a.fQuantity_Sys,0),
		    a.fMoney_Diff=(isnull(a.fQuantity_Check,0)-isnull(a.fQuantity_Sys,0))*a.fInPrice_Avg
		from #tmp_GoodsCheckList2010_1 a 
		where isnull(a.fQuantity_Sys,0)=0
		
	
		
	 begin try 
   begin tran
/**/
		delete from dbo.t_CheckTast_GoodsDetail_log where cCheckTaskNo=@cTaskNo  

		insert into t_CheckTast_GoodsDetail_log  
		(                                  
			cCheckTaskNo,cCheckTask,cWhNo,
			cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,fQuantity_Check, 
			fQuantity_Sys,
			fQuantity_Diff,cSupplierNo,cSupplier,fInPrice_Avg,fNormalPrice,
			fMoney_Diff,fMoney_CurSale,
			fMoney_Sale_Diff,dCheckTask,cStoreNo 
		)  

		select a.cCheckTaskNo,a.cCheckTask,cWhNo=@cWhNo,
		a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cUnit,a.cSpec,a.fQuantity_Check,
		a.fQuantity_Sys,
		a.fQuantity_Diff,b.cSupNo,b.cSupName,a.fInPrice_Avg,a.fNormalPrice,
		a.fMoney_Diff,a.fMoney_CurSale,fMoney_Sale_Diff=a.fQuantity_Diff*a.fNormalPrice,dDatetime=@date,
		@cStoreNo

		from #tmp_GoodsCheckList2010_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo
/*		
		select distinct count(cGoodsNo) from #tmp_GoodsCheckList2010_1 
		
		select * 
		from #tmp_GoodsCheckList2010_1 a,#tmp_GoodsCheckList2010_1 b
		where a.cGoodsNO=b.cGOodsNo and a.fQuantity_Check<>b.fQuantity_Check
		
select * from #tmp_GoodsCheckList2010_1 where cGoodsNo='8211018'
*/
  commit tran
  
 end try
 begin catch
    rollback
 end catch
 
/*
drop table #aaa
drop table #bbb
drop table #ccc
select cGoodsNo,cGoodsName,盘点库存=sum(fQuantity_Check),电脑库存=sum(fQuantity_Sys),差异数量=sum(fQuantity_Diff),差异金额=sum(fMoney_Diff)
into #xxx
from 
(
	select * from t_CheckTast_GoodsDetail_log where cCheckTaskNo='002'
	union all 
    select * from t_CheckTast_GoodsDetail_log where cCheckTaskNo='001'
)c
group by cGoodsNo,cGoodsName

select a.*,条码=b.cBarcode
from #xxx a,t_goods b
where a.cGoodsNo=b.cGoodsNo and 差异金额<>0 order by cGoodsNo



select x.*,条码=b.cBarcode,cGoodsTypeno,cGoodsTypename
from #xxx x,t_goods b
where x.cGoodsNo=b.cGoodsNo and x.差异金额<0 order by cGoodsTypeno,x.cGoodsNo

select sum(差异金额)
from #xxx x,t_goods b
where x.cGoodsNo=b.cGoodsNo and x.差异金额<>0 order by cGoodsTypeno,x.cGoodsNo


select * from t_CheckTast_GoodsDetail_log where cCheckTaskNo='002'
select * from t_CheckTast_GoodsDetail_log where cCheckTaskNo='001'



select * from t_CheckTast_GoodsDetail_log where abs(fMoney_Diff)>100

select sum(fMoney_Diff) from t_CheckTast_GoodsDetail_log where abs(fMoney_Diff)>100

*/
GO
