

create proc p_GoodsCostChange 
@iSerNo bigint,
@cGoodsNo varchar(32),
@price_new money,
@cOperNo varchar(32),
@cOperName varchar(32),
@iRet int output
as

begin try
  begin tran 

       insert into t_wh_form_history
		(
		  iserNO,cGOodsNo,fPrice_changeBefore,fprice_changeAfter,
		  cOperNo,cOperName,dDateTime,iType
		)
		select iserNO,cGOodsNo,fPrice_in,@price_new,
		@cOperNo,@cOperName,getdate(),1
		from T_WH_Form
		where iSerNo=@iSerNo
		and cGoodsNO=@cGoodsNo

		update T_WH_Form
		set fPrice_in=@price_new,fMoney_in=@price_new*fQty_in,
			fPrice_Out=@price_new,fMoney_Out=@price_new*fQty_Out,
			fPrice_Left=@price_new,fMoney_Left=@price_new*fQty_Left
		where iSerNo=@iSerNo
		and cGoodsNO=@cGoodsNo

		update dbo.t_Cost_distribute
		set fPrice_Cost=@price_new,fMoney_Cost=@price_new*fQty_Cost
		where iSerNo=@iSerNo
		and cGoodsNO=@cGoodsNo

 set @iRet=1
 commit tran
end try
begin catch
  set @iRet=0
  rollback tran
end catch
GO
