/*
p_cStoreInGoods '1001','0110002'
*/
CREATE proc p_cStoreInGoods
@cStoreNo varchar(32),
@cGoodsNo varchar(32)
as
   begin try
	 declare @cStoreName varchar(32)
	 set @cStoreName=(select cStoreName from t_Store where cStoreNo=@cStoreNo)
	declare @count int
	
	set @count=(select count(cGoodsNo) from  t_cStoreGoods where cStoreNo=@cStoreNo and cGoodsNo=@cGoodsNo)
	
	if @count=0 
	begin	  
	        
	        declare @cSupNo varchar(32)
	        select @cSupNo=cSupNo from t_Goods
	        where cGoodsNo=@cGoodsNo
	        
	        if not exists (select cSupNo from t_SupplierStore where cSupNoMain=@cSupNo and cStoreNo=@cStoreNo)
	        begin
	          insert into t_SupplierStore(cSupNo, cSupName, cSupAbbName, cContractNo, cTrade, cAddress, cPostCode, cRegCode, 
				cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson, cBP, cMobile, cPPerson, iDisRate, 
				iCreGrade, iCreLine, iCreDate, cPayCond, cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, iAPMoney, 
				dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, cRegNo, cPassword, 
				cHezuoFangshi, cHelpCode, SecDogNo, bContractPrice, bLastPrice, bRatio_without_Rbd, bCaredEndDate, 
				bInPricePlan, iPre_Days, iOver_Days, b_NoStorage, bChange, bChangedDate, bFresh, cStoreNo, cStoreName, 
				cSupNoMain, bUpDatePrice)
				select StorecSupNO=a.cSupNo+cast((select iLineNo from t_Store where cStoreNo=@cStoreNo) as varchar),a.cSupName, 
				a.cSupAbbName, a.cContractNo, a.cTrade, a.cAddress, a.cPostCode, a.cRegCode, 
				a.cBank, a.cAccount, a.dDevDate, a.cLPerson, a.cPhone, a.cFax, a.cEmail, a.cSupPerson, a.cBP, a.cMobile, a.cPPerson, a.iDisRate, 
				a.iCreGrade, a.iCreLine, a.iCreDate, a.cPayCond, a.cSupIAddress, a.cSupIType, a.cSupHeadCode, a.cSupDepart, a.iAPMoney, 
				dLastDate, iLastMoney, dLRDate, iLRMoney, bEnd, dEndDate, iFrequency, bSupTax, cRegNo, cPassword, 
				a.cHezuoFangshi, a.cHelpCode, a.SecDogNo, a.bContractPrice, a.bLastPrice, a.bRatio_without_Rbd, a.bCaredEndDate, 
				a.bInPricePlan, a.iPre_Days, a.iOver_Days, a.b_NoStorage, a.bChange, a.bChangedDate, a.bFresh, @cStoreNo, @cStoreName, 
				a.cSupNo,0 from t_Supplier a where cSupNo=@cSupNo
				
				insert into t_Supplier_Contract(
					   cSupNo, cSupName, cSupAbbName, cTrade, cAddress, cPostCode,
					   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
						cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
						 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
					   cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate
					)
					select StorecSupNO=a.cSupNo+cast((select iLineNo from t_Store where cStoreNo=@cStoreNo) as varchar),a.cSupName, 
					 a.cSupAbbName, cTrade, cAddress, cPostCode,
					   cRegCode, cBank, cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson,
						cBP, cMobile, cPPerson, iDisRate, iCreGrade, iCreLine, iCreDate, cPayCond,
						 cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, dEndDate, bSupTax,  		 
					   cRegNo, cHezuoFangshi, cHelpCode, bChange, bChangedDate 
					   from t_Supplier  a where cSupNo=@cSupNo
				
	        end
	        
			insert into t_cStoreGoods([cGoodsNo],[cStoreNo],[cStoreName],[cUnitedNo],[cGoodsName],
			[cGoodsTypeno],[cGoodsTypename],[cBarcode],[cUnit],[cSpec],[fNormalPrice],[fVipPrice],
			[cProductUnit],[cHelpCode],[cTaxRate],[cHezuoFangshi],[fPreservationUp],[fPreservationDown],[cLevel],[bSuspend],[bDeling],
			 [bDeled],[dSuspendDate1],[dSuspendDate2],[dDelingDate1],
			[dDelingDate2],[fVipScore],[bProducted],[cProductNo],[bStock],[bPiCi],[bShenHe],[bWeight],[bCared],[fCKPrice],[cSupNo],[cSupName],
			[bStorage],[bBaozhuang],[fQty_Baozhuang],[fPrice_Baozhuang],[cParentNo],[bNoVipPrice],[dCreateDate],[cCkPriceInSheetno],[fLastCostPrice],
			[fLastRatio],[cZoneNo],
			[cZoneName],[fPrice_BaozhuangClient],[pinpaino],[pinpai],[bHidePrice],[bHideQty],[iGoodsStatus],[cSeasonNo],[cPersonNo],[iSex],
			[fPreservation_soft],[bUpdate],[bStocking],[fVipScore_base],[fVipPrice_student],[cGoodsNo_minPackage],[fQty_minPackage],[fPackRatio],
			[cGoodsNo_minPackage_tmp],[bQty_created],[cSheetNo_StockVerify],
			[fQty_created],[fPrice_Contract],[fRatio],[cUpdatePici],[dUpdate],[dCheckSupNo],[cCheckSupNo],[bUnStock],[iNumOfSup],[bDownLoad],
			[fAddRatio_Cal],[fInPrice_cuxiao],[dDate1_cuxiao],[dDate2_cuxiao],[fFreshDays],bTestSale,TestSaleBgn,TestSaleEnd,bStop,bjijie,cjijie,
			cjijiemonth,bUpDatePrice,bFresh,bDazhe,cGoodsImage)
			 select a.[cGoodsNo],@cStoreNo,@cStoreName,a.[cUnitedNo],a.[cGoodsName],
			a.[cGoodsTypeno],a.[cGoodsTypename],a.[cBarcode],a.[cUnit],a.[cSpec],
			 a.[fNormalPrice],a.[fVipPrice],
			a.[cProductUnit],a.[cHelpCode],a.[cTaxRate],a.[cHezuoFangshi],a.[fPreservationUp],a.[fPreservationDown],a.[cLevel],a.[bSuspend],a.[bDeling],
			 a.[bDeled],a.[dSuspendDate1],a.[dSuspendDate2],a.[dDelingDate1],
			 a.[dDelingDate2],a.[fVipScore],a.[bProducted],a.[cProductNo],a.[bStock],a.[bPiCi],a.[bShenHe],a.[bWeight],a.[bCared],
			 a.fCKPrice,c.[cSupNo],c.[cSupName],[bStorage],
			a.[bBaozhuang],a.[fQty_Baozhuang],a.[fPrice_Baozhuang],a.[cParentNo],a.[bNoVipPrice],a.[dCreateDate],null,a.[fLastCostPrice],
			 a.[fLastRatio],a.[cZoneNo],
			a.[cZoneName],a.[fPrice_BaozhuangClient],a.[pinpaino],a.[pinpai],a.[bHidePrice],a.[bHideQty],a.[iGoodsStatus],a.[cSeasonNo],a.[cPersonNo],a.[iSex],
			 a.[fPreservation_soft],a.[bUpdate],a.[bStocking],a.[fVipScore_base],a.[fVipPrice_student],a.[cGoodsNo_minPackage],
			 a.[fQty_minPackage],a.[fPackRatio],
			 a.[cGoodsNo_minPackage_tmp],a.[bQty_created],a.[cSheetNo_StockVerify],
			 null,a.fPrice_Contract,a.[fRatio],a.[cUpdatePici],a.[dUpdate],a.[dCheckSupNo],a.[cCheckSupNo],a.[bUnStock],a.[iNumOfSup],a.[bDownLoad],
			 a.[fAddRatio_Cal],a.[fInPrice_cuxiao],a.[dDate1_cuxiao],a.[dDate2_cuxiao],a.[fFreshDays],a.bTestSale,a.TestSaleBgn,a.TestSaleEnd,
			 a.bStop,a.bjijie,a.cjijie,a.cjijiemonth,
			 a.bUpDatePrice,a.bFresh,a.bDazhe,cGoodsImage     
			 FROM [dbo].[t_Goods] a,t_SupplierStore c
			  where a.cGoodsNo=@cGoodsNo and a.cSupNo=c.cSupNoMain and c.cStoreNo=@cStoreNo and 
			  a.cGoodsNo not in (select cGoodsNo from t_cStoreGoods where cStoreNo=@cStoreNo)
		 
	 
			  delete a from t_Supplier_goods a,t_cStoreGoods c 
			  where a.cGoodsNo=c.cGoodsNo and a.cSupNo=c.cSupNo and c.cStoreNo=@cStoreNo
			  and c.cGoodsNo=@cGoodsNo
		     
		    

			  insert into t_Supplier_goods (cSupNo,cSupName,cBarcode,cGoodsNo,cUnitedNo,cGoodsName,
			   cUnit,cSpec,fInMoney,cGoodsTypeno,cGoodsTypename,bShenhe,bCreate)
			   select a.cSupNo,a.cSupName,a.cBarcode,a.cGoodsNo,a.cUnitedNo,a.cGoodsName,
			   a.cUnit,a.cSpec,a.fckPrice,a.cGoodsTypeno,a.cGoodsTypename,0,1  
				from t_cStoreGoods a 
				where a.cGoodsNO=@cGoodsNo and a.cStoreNo=@cStoreNo

			   delete a from t_ChangeGoods a where a.cGoodsNO=@cGoodsNo and a.cStoreNo=@cStoreNo

			   insert into t_ChangeGoods(cGoodsNo,cStoreNo) values(@cGoodsNo,@cStoreNo)
		       
			   select a01=1
		       
    end else
    begin 
       select a01=0
    end 
      
  end try
  begin catch
	  select a01=0
  end catch
GO
