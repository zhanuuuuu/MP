

CREATE   procedure p_InWh_GroupByGoodsType
@cSheetno varchar(32)
/*按照入库单进行商品分类*/
as
begin
	select a.*,fQuantity=(select sum(isnull(fQuantity,0)) from wh_InWarehouseDetail where cSheetno=@cSheetno)
	into #wh_InWarehouse_tmp0
	from dbo.wh_InWarehouse a
	where a.cSheetno=@cSheetno

	select cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,bPresent,fInPrice,bBalance,
					fInMoney=sum(isnull(fInMoney,0)),fQuantity=sum(isnull(fQuantity,0))
	into #wh_InWarehouseDetail_tmp0
	from dbo.wh_InWarehouseDetail
	where cSheetno=@cSheetno
	group by cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,bPresent,fInPrice,bBalance

	select a.cSheetno,a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.bPresent,
					a.fInPrice,a.bBalance,a.fInMoney,a.fQuantity,b.cGoodsTypeno,b.cGoodsTypename
	into #wh_InWarehouseDetail_tmp1
	from #wh_InWarehouseDetail_tmp0 a
	left join t_goods b
	on a.cGoodsNo=b.cGoodsNo


	select cSheetno,cGoodsTypeno,cGoodsTypename,bPresent,bBalance,
				 fInMoney=sum(fInMoney),fQuantity=sum(fQuantity)
	into #wh_InWarehouseDetail_tmp
	from #wh_InWarehouseDetail_tmp1
	group by cSheetno,cGoodsTypeno,cGoodsTypename,bPresent,bBalance

  select a.cSheetno,a.cGoodsTypeno,a.cGoodsTypename,a.bPresent,a.bBalance,a.fInMoney,a.fQuantity,
				 b.cSupplierNo,b.cSupplier,b.cOperatorNo,b.cOperator,b.cFillEmpNo,b.cFillEmp,
				 b.cStockDptno,b.cStockDpt,b.fMoney,b.cExaminerNo,b.cExaminer,b.cWhNo,b.cWh,b.jiesuanno
	from #wh_InWarehouseDetail_tmp a
	left join #wh_InWarehouse_tmp0 b
	on a.cSheetno=b.cSheetno and a.cSheetno=@cSheetno
	
  union all
  select cSheetno=@cSheetno,cGoodsTypeno='合计:',cGoodsTypename=null,bPresent,bBalance,fInMoney=fMoney,fQuantity=fQuantity,
				 cSupplierNo,cSupplier,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,
				 cStockDptno,cStockDpt,fMoney,cExaminerNo,cExaminer,cWhNo,cWh,jiesuanno
	from #wh_InWarehouse_tmp0
	order by cGoodsTypeno

end


GO
