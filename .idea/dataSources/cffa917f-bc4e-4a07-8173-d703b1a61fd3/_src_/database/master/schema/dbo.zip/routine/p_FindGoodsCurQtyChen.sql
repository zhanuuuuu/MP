--超市商品实时库存查询[p_FindGoodsCurQtyChen]
/*
if (select object_id('tempdb..#tmpGoodsCurQtyList'))is not null drop table #tmpGoodsCurQtyList
if (select object_id('tempdb..#tmpTypeCurQtyList'))is not null drop table #tmpTypeCurQtyList
if (select object_id('tempdb..#tmpSupCurQtyList'))is not null drop table #tmpSupCurQtyList
create table #tmpTypeCurQtyList (cTypeNo varchar(32))  create table #tmpSupCurQtyList (cSupNo varchar(32)) 

select cGoodsNo into #tmpGoodsCurQtyList from t_goods where cGoodsNo='41200'
exec [p_FindGoodsCurQtyChen] '',0
*/
CREATE proc [dbo].[p_FindGoodsCurQtyChen]
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商
as
--declare @cWhNo varchar(32),@Type int
--set @cWhNo='' 
--set @Type=0
begin 

 if (select OBJECT_ID('tempdb..#temp_ForBase'))is not null drop table #temp_ForBase
 create table #temp_ForBase
 (cGoodsNo varchar(32),fQty_CurWh money,fQty_in money,fQty_Divide money,fQty_Return money,fQty_tfrin money,
 fQty_effusion money,fQty_out money,fQty_pack money,fQty_rbd money,fQty_loss money,
 fQty_trf money,fQty_checkout money,fQty_sale money)
 
 create table #temp_ForReady
 (cGoodsNo varchar(32),fQty_CurWh money,fQty_in money,fQty_Divide money,fQty_Return money,fQty_tfrin money,
 fQty_effusion money,fQty_out money,fQty_pack money,fQty_rbd money,fQty_loss money,
 fQty_trf money,fQty_checkout money,fQty_sale money)

 select cGoodsNo 
 into #temp_ForReady1
 from t_goods 
 where isnull(bstorage,0)=1
 and(
     ( 
        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpGoodsCurQtyList)
     )
      or
     ( 
        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpTypeCurQtyList)
     )
     or
     ( 
        (@Type=2)and cSupNo in(select distinct cSupNo from #tmpSupCurQtyList)
     )
 )

---包装转单品
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

update a
set a.cGoodsNo=b.cGoodsNO_minPackage
from #temp_ForReady1 a,#tmpPackGoodsList b
where a.cGoodsNo=b.cGoodsNo

insert into #temp_ForReady(cGoodsNo) 
select distinct cGoodsNo from #temp_ForReady1

  if(@cWhNo='')--1
  begin
  
		declare cr cursor for
		select cwhno from t_warehouse order by cwhno

		open cr

		fetch next from cr
		into @cWhNo

		while @@Fetch_Status=0
		begin
			 exec [p_FindGoodsCurQtyChen_ForBase] @cWhNo,@Type

			 update a
			 set a.fQty_CurWh=isnull(a.fQty_CurWh,0)+isnull(b.fQty_CurWh,0),
				 a.fQty_in=isnull(a.fQty_in,0)+isnull(b.fQty_in,0),
				 a.fQty_Divide=isnull(a.fQty_Divide,0)+isnull(b.fQty_Divide,0),
				 a.fQty_Return=isnull(a.fQty_Return,0)+isnull(b.fQty_Return,0),
				 a.fQty_tfrin=isnull(a.fQty_tfrin,0)+isnull(b.fQty_tfrin,0),
				 a.fQty_effusion=isnull(a.fQty_effusion,0)+isnull(b.fQty_effusion,0),
				 a.fQty_out=isnull(a.fQty_out,0)+isnull(b.fQty_out,0),
				 a.fQty_pack=isnull(a.fQty_pack,0)+isnull(b.fQty_pack,0),
				 a.fQty_rbd=isnull(a.fQty_rbd,0)+isnull(b.fQty_rbd,0),
				 a.fQty_loss=isnull(a.fQty_loss,0)+isnull(b.fQty_loss,0),
				 a.fQty_trf=isnull(a.fQty_trf,0)+isnull(b.fQty_trf,0),
				 a.fQty_checkout=isnull(a.fQty_checkout,0)+isnull(b.fQty_checkout,0),
				 a.fQty_sale=isnull(a.fQty_sale,0)+isnull(b.fQty_sale,0)
			 from #temp_ForReady a,#temp_ForBase b
			 where a.cGoodsNo=b.cGoodsNo
		          
			 delete from #temp_ForBase
			 
			 --set @cWhNo=''

			 fetch next from cr
			 into @cWhNo
		end

		CLOSE cr
		DEALLOCATE cr
  end
else
  begin
     exec [p_FindGoodsCurQtyChen_ForBase] @cWhNo,@Type
     
     update a
     set a.fQty_CurWh=isnull(a.fQty_CurWh,0)+b.fQty_CurWh,
         a.fQty_in=isnull(a.fQty_in,0)+b.fQty_in,
         a.fQty_Divide=isnull(a.fQty_Divide,0)+b.fQty_Divide,
         a.fQty_Return=isnull(a.fQty_Return,0)+b.fQty_Return,
         a.fQty_tfrin=isnull(a.fQty_tfrin,0)+b.fQty_tfrin,
         a.fQty_effusion=isnull(a.fQty_effusion,0)+b.fQty_effusion,
         a.fQty_out=isnull(a.fQty_out,0)+b.fQty_out,
         a.fQty_pack=isnull(a.fQty_pack,0)+b.fQty_pack,
         a.fQty_rbd=isnull(a.fQty_rbd,0)+b.fQty_rbd,
         a.fQty_loss=isnull(a.fQty_loss,0)+b.fQty_loss,
         a.fQty_trf=isnull(a.fQty_trf,0)+b.fQty_trf,
         a.fQty_checkout=isnull(a.fQty_checkout,0)+b.fQty_checkout,
         a.fQty_sale=isnull(a.fQty_sale,0)+b.fQty_sale
     from #temp_ForReady a,#temp_ForBase b
     where a.cGoodsNo=b.cGoodsNo
     
     delete from #temp_ForBase
     
  end
  if (select OBJECT_ID('tempdb..#temp_ForBase_StockIn'))is not null 
  begin
    insert into #temp_ForBase_StockIn(cGoodsNo,fQty_CurWH)
		select x.cGoodsNo,b.fQty_CurWh
		from #temp_ForReady b
		left join t_Goods x on b.cGoodsNo=x.cGoodsNo
    		
  end else
  begin
		select x.cGoodsNo,x.cGoodsName,x.cUnit,x.cSpec,x.cSupNo,x.cSupName,x.cGoodsTypeNo,x.cGoodsTypeName,x.fCkPrice,
		cWhNo='',fQty_CurWh,dDateTime_CurWh='',dDatetime_Gen='',
		fQty_in,fQty_Divide,fQty_Return,fQty_tfrin,fQty_effusion,fQty_out,fQty_pack,fQty_rbd,fQty_loss,
		fQty_trf,fQty_checkout,fQty_sale,dDate_Daily='',
		
		x.fPrice_Contract,x.fQty_created,
		x.cGoodsNo_minPackage_tmp,x.fQty_minPackage,
		x.fVipPrice_student,x.fPackRatio,x.fVipScore_Base,

		x.cCkPriceInSheetno,x.cUnitedNo,x.fNormalPrice,x.fVipScore,
		x.fCKPrice,x.fVipPrice,
		x.cBarcode,cBarcode_min=y.cBarcode,cGoodsName_min=y.cGoodsName,
		cUnit_min=y.cUnit,cSpec_min=y.cSpec
		from #temp_ForReady b
		left join t_Goods x on b.cGoodsNo=x.cGoodsNo
		left join t_Goods y on y.cGoodsNo=x.cGoodsNo_minPackage_tmp

		order by x.cGoodsNo,x.cSupNo,x.cGoodsTypeNo
	end
end
GO
