
CREATE    proc [dbo].[p_updateStoreGoodsPrice_OneDay]

@cGoodsNo varchar(32),
@cOperatorNo varchar(16),
@cOperatorName varchar(16),
@fNormalPrice_new money,
@fVipPrice_new money,
@fVipPrice_student_new money,
@cUpdatePici varchar(32),
@fVipScore_new money,
@fVipScore_base_new money,
@cStoreNo varchar(32)

as
declare @dOperateDate datetime
declare @fNormalPrice_old money 
declare @fVipPrice_old money
declare @fVipPrice_student_old money
declare @fVipScore_old money
declare @fVipScore_base_old money

set @dOperateDate=getdate()
 

select @fNormalPrice_old=fNormalPrice,@fVipPrice_old=fVipPrice,@fVipPrice_student_old=fVipPrice_student,
@fVipScore_old=fVipScore,@fVipScore_base_old=fVipScore_base
from t_cStoreGoods
where cStoreNo=@cStoreNo and cGoodsNo=@cGoodsNo
 
 
insert t_OneDayTempPrice(dOperateDate,cGoodsNo,cOperatorNo,cOperatorName,
                fNormalPrice_old,fVipPrice_old,fNormalPrice_new,fVipPrice_new,fVipPrice_student_new,fVipPrice_student_old,
                fVipScore_new,fVipScore_old,fVipScore_base_new,fVipScore_base_old,cStoreNo)
      values(dbo.getDayStr(@dOperateDate),@cGoodsNo,@cOperatorNo,@cOperatorName,
                @fNormalPrice_old,@fVipPrice_old,@fNormalPrice_new,@fVipPrice_new,@fVipPrice_student_new,@fVipPrice_student_old,
                @fVipScore_new,@fVipScore_old,@fVipScore_base_new,@fVipScore_base_old,@cStoreNo)


GO
