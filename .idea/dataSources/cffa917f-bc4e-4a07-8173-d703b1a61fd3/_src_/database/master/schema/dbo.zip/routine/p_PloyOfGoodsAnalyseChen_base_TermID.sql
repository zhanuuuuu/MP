
/*
策略商品分析

if (select OBJECT_ID('tempdb..#tmpQueryPloy'))is not null
drop table #tmpQueryPloy
create table #tmpQueryPloy(cPloyNo varchar(32))
insert into #tmpQueryPloy(cPloyNo)values('460510')
insert into #tmpQueryPloy(cPloyNo)values('001')
insert into #tmpQueryPloy(cPloyNo)values('0010')

if (select object_id('tempdb..#tmpQueryGoods'))is not null
drop table #tmpQueryGoods
select distinct cGoodsNo  
into #tmpQueryGoods
from t_PloyOfSale
where cPloyTypeNo in(select cPloyNo from #tmpQueryPloy)

if (select object_id('tempdb..#tmpGoodsType'))is not null
drop table #tmpGoodsType
if (select object_id('tempdb..#tmpGoodsSup'))is not null
drop table #tmpGoodsSup
select a.cGoodsNo,b.cGoodsName,b.cGoodsTypeNo,b.cGoodsTypeName
into #tmpGoodsType
from #tmpQueryGoods a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
select a.cGoodsNo,b.cGoodsName,b.cSupNo,b.cSupName
into #tmpGoodsSup
from #tmpQueryGoods a left join t_goods b
on a.cGoodsNo=b.cGoodsNo


if (select object_id('tempdb..#tmpGoodsList'))is not null
drop table #tmpGoodsList
create table #tmpGoodsList
( cGoodsNo varchar(32) )

insert into #tmpGoodsList(cGoodsNo) values 
('24722')
insert into #tmpGoodsList(cGoodsNo) values 
('22007')
insert into #tmpGoodsList(cGoodsNo) values 
('22093')
insert into #tmpGoodsList(cGoodsNo) values 
('22094')
insert into #tmpGoodsList(cGoodsNo) values 
('22095')
insert into #tmpGoodsList(cGoodsNo) values 
('22099')

exec p_PloyOfGoodsAnalyseChen_base '2012-04-29','2012-05-9'

*/

create proc [dbo].[p_PloyOfGoodsAnalyseChen_base_TermID]
@dDateBgn datetime,  --时段开始日期
@dDateEnd datetime,  --时段截止日期
@cTermID varchar(32)
as

--三个日期
--declare @dDateBgn datetime  --时段开始日期
--declare @dDateEnd datetime  --时段截止日期
declare @dDate_daily datetime  --日结日期
declare @dDate_account datetime  --日结日期
--select @dDateBgn='2010-06-01',@dDateEnd='2010-06-30'

if (select OBJECT_ID('tempdb..#tmpQueryPloy'))is not null
drop table #tmpQueryPloy
create table #tmpQueryPloy(cPloyNo varchar(32))

exec('
   insert into #tmpQueryPloy(cPloyNo)
   select cPloyNo from #tmpQueryPloy'+@cTermID+'
')

if (select OBJECT_ID('tempdb..#tmpGoodsList'))is not null
drop table #tmpGoodsList
create table #tmpGoodsList(cGoodsNo varchar(32))

exec('
   insert into #tmpGoodsList(cGoodsNo)
   select cGoodsNo from #tmpGoodsList'+@cTermID+'
')


select @dDate_daily=isnull(MAX(dSaleDate),'1900-01-01') from t_SaleSheet_Day

select @dDate_account=isnull(MAX(dDate),'1900-01-01') from t_Daily_history where ISNULL(bAccount,0)=1


--取商品(管理库存，未管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null
drop table #tmpPloyOfGoodsinfo
select distinct a.cGoodsNo,a.cPloyNo
into #tmpPloyOfGoodsinfo
from t_PloyOfSale a,t_goods b  
where a.cGoodsNO=b.cGoodsNo and isnull(b.bStorage,0)=1
and a.cPloyNo in(select cPloyNo from #tmpQueryPloy)
and a.cGoodsNo in(select cGoodsNo from #tmpGoodsList)

if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfoNull'))is not null
drop table #tmpPloyOfGoodsinfoNull
select distinct a.cGoodsNo,a.cPloyNo
into #tmpPloyOfGoodsinfoNull
from t_PloyOfSale a,t_goods b  
where a.cGoodsNO=b.cGoodsNo and isnull(b.bStorage,0)=0
and a.cPloyNo in(select cPloyNo from #tmpQueryPloy)
and a.cGoodsNo in(select cGoodsNo from #tmpGoodsList)



--未日结商品，从成本分配表中找最近一次成本
if (select OBJECT_ID('tempdb..#tmpNoExistDailyGoods0'))is not null
drop table #tmpNoExistDailyGoods0

select a.cGoodsNo,b.cSupNo,fPrice_Cost=c.fPrice_In
into #tmpNoExistDailyGoods0
from #tmpPloyOfGoodsinfo a left join 
(
   select cGoodsNO,cSupNO=cSupplierNo,iMaxISerNo=max(iSerNo)
   from t_Wh_Form
   where dDateTime<=@dDate_account
   group by cGoodsNO,cSupplierNo
) b
on a.cGoodsNo=b.cGoodsNo
left join t_Wh_Form c
on b.cGoodsNO=c.cGoodsNO and b.iMaxISerNo=c.iSerNo and c.dDateTime<=@dDate_account

--如果此商品一直未记账，则更新供应商为主供应商
update a
set a.cSupNO=b.cSupNo
from #tmpNoExistDailyGoods0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo
and a.cSupNo is null

update a
set a.fPrice_Cost=b.fCKPrice
from #tmpNoExistDailyGoods0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo 
and a.fPrice_Cost is null

--if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange0'))is not null
--drop table #tmpGoodsStorageChange0
--select cGoodsNo,countNum=count(distinct bstorage)
--into #tmpGoodsStorageChange0
--from t_saleSheet_Day
--group by cGoodsNo having(count(distinct bstorage))>1

/*--------修改 上面--------*/
if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange0'))is not null
drop table #tmpGoodsStorageChange0
create table #tmpGoodsStorageChange0(cGoodsNo varchar(32),countNum int)
insert into #tmpGoodsStorageChange0
exec p_SupSale_Day
--************--从各个分库中获取总数--****************

------*********从各个分开中取数据*********--------

declare @cWhNo varchar(32)
set @cWhNo=(select top 1 cWhNo from t_WareHouse where ISNULL(bMainSale,0)=1)
----- 销售表
 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fPrice money,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
 ------  日结表 

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fNormalPrice money,fLastSettle money ,bauditing bit,bStorage bit,cWHno varchar(32))
------  成本表

    if(select object_id('tempdb..#temp_Cost_distribute')) is not null drop table #temp_Cost_distribute
	create table #temp_Cost_distribute(dDate_Sheet datetime,cGoodsNo varchar(32),
	fPrice_Cost money ,fQty_Cost money,fMoney_Cost money,iLineNo int,fPrice_sale money,fMoney_sale money,
	iAttribute int ,bdone bit,iSerNo bigint,cWHno varchar(32))
	
	exec p_SupSale_Ref @dDateBgn,@dDateEnd,@cWhNo
	----------------------------


if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange'))is not null
drop table #tmpGoodsStorageChange
select a.cGoodsNO,c.cPloyNo
into #tmpGoodsStorageChange
from #tmpGoodsStorageChange0 a,t_goods b,t_PloyOfSale c
where a.cGoodsNo=b.cGoodsNO and isnull(b.bStorage,0)=1
and a.cGoodsNO=c.cGoodsNo 
and c.cPloyNo in(select cPloyNo from #tmpQueryPloy)
and c.cGoodsNo in(select cGoodsNo from #tmpGoodsList)

--商品连接日结记账，日结表中取出是否为特价
if (select OBJECT_ID('tempdb..#tmpPloyOfGoods_Money0'))is not null
drop table #tmpPloyOfGoods_Money0

select a.cPloyNo,b.dDate_Sheet,a.cGoodsNo,cSupNo=t.cSupplierNo,b.fPrice_Cost,b.fQty_Cost,
b.fMoney_Cost,b.iLineNo,b.fPrice_sale,b.fMoney_sale,bAuditing=ISNULL(c.bauditing,0),
bDaily=1,iType=0
into #tmpPloyOfGoods_Money0
from #tmpPloyOfGoodsinfo a left join ---t_Cost_distribute b
#temp_Cost_distribute b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=10 and ISNULL(b.bdone,0)=0
--left join t_SaleSheet_Day c
left join #temp_SaleSheet_Day c
on b.dDate_Sheet=c.dSaleDate and b.iLineNo=c.iSeed and b.cGoodsNo=c.cGoodsNo
and b.cWhNo=c.cWHno
left join t_Wh_Form t
on b.iSerNo=t.iSerNo 
/*
where b.dDate_Sheet between '2010-06-01' and '2010-06-30'
       and dDate_Sheet<='2010-07-15'
*/

where  b.dDate_Sheet between @dDateBgn and @dDateEnd
       and dDate_Sheet<=@dDate_account

union all  --日结但未记账的商品(销售)
select a.cPloyNo,b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfo a left join --t_SaleSheet_Day b
#temp_SaleSheet_Day b 
on  a.cGoodsNo=b.cGoodsNo
/*
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between '2010-06-01' and '2010-06-30'
and b.dSaleDate>='2010-07-16'
and b.dSaleDate<='2010-07-18'
*/
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between @dDateBgn and @dDateEnd
and b.dSaleDate>=@dDate_account+1
and b.dSaleDate<=@dDate_daily

union all  --未日结的商品从销售单中取
select a.cPloyNo,b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfo a left join --t_SaleSheetDetail b
#temp_salesheetDetail b
on  a.cGoodsNo=b.cGoodsNo
/*
where b.dSaleDate between '2010-06-01' and '2010-06-30'
and b.dSaleDate>='2010-07-19'
*/
where b.dSaleDate between @dDateBgn and @dDateEnd
and b.dSaleDate>=@dDate_daily+1

union all --前台销售退货
select a.cPloyNo,b.dDateTime,a.cGoodsNo,b.cSupplierNo,b.fPrice_In,-b.fQty_In,
-b.fMoney_In,b.iLineNo,c.fNormalPrice,c.fLastSettle,bAuditing=ISNULL(c.bauditing,0),
bDaily=1,iType=0
from #tmpPloyOfGoodsinfo a left join T_WH_Form b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=13 
--left join t_SaleSheet_Day c
left join #temp_SaleSheet_Day c
on b.dDateTime=c.dSaleDate and b.iLineNo=c.iSeed and b.cGoodsNo=c.cGoodsNo
and b.cWhNo=c.cWHno
/*
where b.dDateTime between '2010-06-01' and '2010-06-30'
and b.dDateTime<='2010-07-15'
*/
where b.dDateTime between @dDateBgn and @dDateEnd
and b.dDateTime<=@dDate_account


union all --已记账顾客退货
select a.cPloyNo,b.dDateTime,a.cGoodsNo,b.cSupplierNo,b.fPrice_In,b.fQty_In,
b.fMoney_In,b.iLineNo,c.fInPrice,c.fInMoney,bAuditing=0,
bDaily=1,iType=1
from #tmpPloyOfGoodsinfo a left join T_WH_Form b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=3 
left join WH_ReturnGoodsDetail c
on b.iLineNo=c.iLineNo and b.cSheetNo=c.cSheetNo and b.cGoodsNo=c.cGoodsNo
--where b.dDateTime between '2010-06-01' and '2010-06-30'
where b.dDateTime between @dDateBgn and @dDateEnd


union all --未记账顾客退货
select a.cPloyNo,c.dDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iLineNo,fPrice=isnull(b.fInPrice,0),fLastSettle=isnull(b.fInMoney,0),
bAuditing=0,bDaily=0,iType=1
from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
--where c.dDate between '2010-06-01' and '2010-06-30' and isnull(c.baccount,0)=0
where c.dDate between @dDateBgn and @dDateEnd and isnull(c.baccount,0)=0


--不管理库存商品
union all  
select a.cPloyNo,b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfoNull a left join --t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo
/*
where b.dSaleDate between '2010-06-01' and '2010-06-30' 
and b.dSaleDate<='2010-07-18'
and isnull(b.fQuantity,0)<>0 
*/
where b.dSaleDate between @dDateBgn and @dDateEnd 
and b.dSaleDate<=@dDate_daily
and isnull(b.fQuantity,0)<>0 


union all  
select a.cPloyNo,b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfoNull a left join ---t_SaleSheetDetail b
#temp_salesheetDetail b
on  a.cGoodsNo=b.cGoodsNo
/*
where b.dSaleDate between '2010-06-01' and '2010-06-30' 
and isnull(b.fQuantity,0)<>0
and b.dSaleDate>='2010-07-19'
*/
where b.dSaleDate between @dDateBgn and @dDateEnd 
and b.dSaleDate>=@dDate_daily+1


union all 
select a.cPloyNo,c.dDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iLineNo,fPrice=isnull(b.fInPrice,0),fLastSettle=isnull(b.fInMoney,0),
bAuditing=0,bDaily=0,iType=1
from #tmpPloyOfGoodsinfoNull a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
--where c.dDate between '2010-06-01' and '2010-06-30'
where c.dDate between @dDateBgn and @dDateEnd 

--以前管理库存，现更改为不管理库存的商品
union all 
select a.cPloyNo,b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpGoodsStorageChange a left join --t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between @dDateBgn and @dDateEnd
and isnull(b.bStorage,0)=0



update a
set a.cSupNo=b.cSupNo
from #tmpPloyOfGoods_Money0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo
and a.cSupNo is null
--更新未记账商品的成本，销售
update a
set a.fPrice_Cost=b.fPrice_Cost,fMoney_Cost=b.fPrice_Cost*a.fqty_Cost
from #tmpPloyOfGoods_Money0 a,#tmpNoExistDailyGoods0 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
and bDaily=0 



--获取供应商最小扣率
if (select OBJECT_ID('tempdb..#tmpPloy_SupMinRatio'))is not null
drop table #tmpPloy_SupMinRatio
select a.guizuno,a.fRatio
into #tmpPloy_SupMinRatio
from t_Supplier_Contract_Ratio a,
(
   select guizuno,fMoney1=MIN(fMoney1)
   from t_Supplier_Contract_Ratio 
   where fRatio is not null
   group by guizuno
 )b
where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1

--获取供应商扣率
update a
set a.fMoney_Cost=((100.00-b.fRatio)/100.00)*a.fMoney_Sale
from #tmpPloyOfGoods_Money0 a,#tmpPloy_SupMinRatio b
where a.cSupNo=b.guizuno 
and b.fRatio is not null


--策略扣率
  if (select OBJECT_ID('tempdb..#temp_PloyOfSale'))is not null
  drop table #temp_PloyOfSale
  if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_bybAuditing'))is not null
  drop table #t_SaleSheetDetail_bybAuditing
  select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
  into #temp_PloyOfSale
  from t_PloyOfSale
  where (dDateStart between @dDateBgn and @dDateEnd)
   or (dDateEnd  between @dDateBgn and @dDateEnd)
	group by cGoodsNo,dDateStart,dDateEnd

	select  a.cGoodsNo,a.dDate_Sheet,a.fMoney_sale,
					a.fQty_Cost,a.bAuditing,b.dDateStart,b.dDateEnd,fSupRatio=isnull(b.fSupRatio,0)
	into #t_SaleSheetDetail_bybAuditing
	from #tmpPloyOfGoods_Money0 a
	left join #temp_PloyOfSale b on a.dDate_Sheet between b.dDateStart and b.dDateEnd
	     and b.cGoodsNo=a.cGoodsNo
  where isnull(a.bAuditing,0)=1 and b.dDateStart is not null

  update a
  set a.fMoney_Cost=a.fMoney_Sale*(1-b.fSupRatio/100.00)
  from #tmpPloyOfGoods_Money0 a,#t_SaleSheetDetail_bybAuditing b
  where a.cGoodsNo=b.cGoodsNo and a.dDate_Sheet between b.dDateStart and b.dDateEnd and isnull(a.bAuditing,0)=1

--策略商品成本金额、销售金额合计
if (select OBJECT_ID('tempdb..#tmpPloyOfGoods_Money'))is not null
drop table #tmpPloyOfGoods_Money

select cPloyNo,cGoodsNO,cSupNo,bAuditing,fQty=sum(ISNULL(fQty_Cost,0)),fMoney_Cost=sum(ISNULL(fMoney_Cost,0)),
fMoney_Sale=sum(ISNULL(fMoney_Sale,0))
into #tmpPloyOfGoods_Money
from #tmpPloyOfGoods_Money0
group by cPloyNo,cGoodsNO,cSupNo,bAuditing



--策略商品对应供应商
if (select OBJECT_ID('tempdb..#tmpPloyOfGoods_sup'))is not null
drop table #tmpPloyOfGoods_sup

select a.cPloyNO,a.cGoodsNo,a.cSupNo,a.bAuditing,fQty,a.fMoney_Cost,a.fMoney_Sale,
fRatio=case when isnull(fmoney_sale,0)<>0 then (fMoney_sale-fmoney_cost)/isnull(fmoney_sale,0)*100.00 else null end,
fProfit=fMoney_sale-fmoney_cost
into #tmpPloyOfGoods_sup
from #tmpPloyOfGoods_Money a 


--把正特价合为一条记录
if (select OBJECT_ID('tempdb..#tmpPloyOfGoods_LastInfo'))is not null
drop table #tmpPloyOfGoods_LastInfo

select distinct cPloyNo,cGoodsNo,cSupNo,
fQty_zj=CAST(0 as Money),fQty_tj=CAST(0 as Money),
fMoneyCost_zj=CAST(0 as Money),fMoneyCost_tj=CAST(0 as Money), /*正、特价成本金额*/
fMoneySale_zj=CAST(0 as Money),fMoneySale_tj=CAST(0 as Money), /*正、特价销售金额*/
fRatio_zj=CAST(0 as Money),fRatio_tj=CAST(0 as Money),
fProfit_zj=CAST(0 as Money),fProfit_tj=CAST(0 as Money),
fProportion_zj=CAST(0 as numeric(10,3)),/*正价占比*/
fProportion_tj=CAST(0 as numeric(10,3))/*特价占比*/
into #tmpPloyOfGoods_LastInfo
from #tmpPloyOfGoods_sup


--更新正价
update a
set a.fQty_zj=b.fQty,
    a.fMoneyCost_zj=b.fMoney_Cost,a.fMoneySale_Zj=b.fMoney_Sale,
    a.fRatio_zj=b.fRatio,a.fProfit_zj=b.fMoney_Sale-fMoney_Cost
from #tmpPloyOfGoods_LastInfo a,#tmpPloyOfGoods_sup b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
and ISNULL(b.bAuditing,0)=0

--更新特价
update a
set a.fQty_tj=b.fQty,
    a.fMoneyCost_tj=b.fMoney_Cost,a.fMoneySale_tj=b.fMoney_Sale,
    a.fRatio_tj=b.fRatio,a.fProfit_tj=b.fMoney_Sale-fMoney_Cost
from #tmpPloyOfGoods_LastInfo a,#tmpPloyOfGoods_sup b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
and ISNULL(b.bAuditing,0)=1

update #tmpPloyOfGoods_LastInfo
set fProportion_zj=case when ISNULL(fQty_zj,0)+ISNULL(fQty_tj,0)<>0 
                               then ISNULL(fQty_zj,0)/(ISNULL(fQty_zj,0)+ISNULL(fQty_tj,0))*100.00
                        else null end,
    fProportion_tj=case when ISNULL(fQty_zj,0)+ISNULL(fQty_tj,0)<>0 
                               then ISNULL(fQty_tj,0)/(ISNULL(fQty_zj,0)+ISNULL(fQty_tj,0))*100.00
                        else null end                    

/*
update #tmpPloyOfGoods_LastInfo
set fProportion=case when ISNULL(fQty_zj,0)=0 then 0 
                     when ISNULL(fQty_tj,0)=0 then 100
                     else ISNULL(fQty_zj,0)/ISNULL(fQty_tj,0) end
*/

--select * from #tmpPloyOfGoods_LastInfo


select a.cPloyNO,a.cGoodsNo,b.cGoodsName,a.cSupNO,c.cSupName,
a.fQty_zj,fqty_tj,
fMoneyCost_zj,fMoneyCost_tj,
fMoneySale_zj,fMoneySale_tj,
fRatio_zj,fRatio_tj,
fProfit_zj,fProfit_tj,
fProportion_zj,fProportion_tj
from #tmpPloyOfGoods_LastInfo a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
left join t_supplier c
on a.cSupNo=c.cSupNo
order by a.cPloyNO,a.cGoodsNo,a.cSupNO
GO
