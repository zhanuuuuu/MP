
CREATE view v_GenGoods_CurWh
as
  select a.cGoodsNo,b.cGoodsName,b.cBarCode,b.cGoodsTypeno,b.cGoodsTypename,b.cUnit,
	b.cSpec,b.fNormalPrice,b.fVipPrice,b.fVipScore,a.fQty_CurWH,a.dDateTime_CurWH,a.dDateTime_gen 
	from t_Goods_CurWH a left join t_goods b
	on a.cGoodsNo=b.cGoodsNo


GO
