CREATE    procedure p_SaveToCheckTast_GoodsDetail 
@cCheckTaskNo varchar(32),  
@dCheckDate	datetime  
as                   
begin                    
	declare @strtempTablename_Pub varchar(32) 
	set @strtempTablename_Pub='##CheckTask_result_Pub'+dbo.trim(dbo.getDayStr_noSeparator(@dCheckDate))
	delete from dbo.t_CheckTast_GoodsDetail where cCheckTaskNo=@cCheckTaskNo  
	exec('               
  insert into t_CheckTast_GoodsDetail  
	(                                  
  cCheckTaskNo,cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,fQuantity_Check, 
	fInPrice_Avg,fQuantity_Diff,fMoney_Diff,fQuantity_Sys,fMoney_CurSale,
	Qty_Begin,Qty_InWh,Qty_RetWh,Qty_EffusionWh,Qty_OutWh,  
	Qty_TfrWh,Qty_RbdWh,Qty_Exchange,Qty_LossWh,Qty_Sale,fInMoney, 
	InQty_avg,fSaleMoney   
	)                    
	select cCheckTaskNo='''+@cCheckTaskNo+''',GoodsNo_sys,GoodsName ,cBarCode,cUnit,cSpec,Qty_check,
	avgCostPrice,fQuantity_Diff,fMoney_Diff,Qry_End,fMoney_CurSale, 
	Qty_Begin,Qty_InWh,Qty_RetWh,Qty_EffusionWh,Qty_OutWh,    
	Qty_TfrWh ,Qty_RbdWh,Qty_Exchange,Qty_LossWh,Qty_Sale,fInMoney, 
	InQty_avg,fSaleMoney                                        
	from '+ @strtempTablename_Pub+' where GoodsNo_sys is not null' 
  ) 
end
GO
