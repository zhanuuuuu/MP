CREATE  procedure [dbo].[P_VipAward]
	 @cVipno varchar(16),
	 @cOperatorno varchar(16),
	 @dAwardDate datetime,
	 @dDate2_Period datetime,
	 @cVipName varchar(16),
	 @cOpertorName varchar(16),
	 @fCurValue money,
	 @fScore money,
	 @fLeaveValue money,
	 @cAwardName varchar(64),@fMoney_cost money,@feiyongNo varchar(64),@feiyong varchar(32),
	 @dDate1 datetime,@dDate2 datetime,
	 @bRatio bit
as
begin
  update t_vip
  set 
  fCurValue_Pos=case when fCurValue_Pos>=@fScore then fCurValue_Pos-@fScore else 0 end
  where cVipno=@cVipno
  
  update t_vip
  set fCurValue=isnull(fCurValue_MP,0)+isnull(fCurValue_Pos,0)
  where cVipno=@cVipno

  update t_Award_Vip_Done
  set fCurValue=fCurValue-@fScore,
  fCurValue_Pos=fCurValue_Pos-@fScore,
  fVipScore_Period_Pos=fVipScore_Period_Pos-@fScore,
  fVipScore_Period_Pos_Sub=@fScore
  where cVipno=@cVipno and dDate2=@dDate2_Period

  insert into t_VipAward
  (
    cVipno,
    cOperatorno,
    dAwardDate,
    cVipName,
    cOperatorName,
    fCurValue,
    fScore,
    fLeaveValue,cAwardName,fMoney_cost,feiyong,feiyongno,dDate1,dDate2,bRatio
  )
  values
  (
    @cVipno,
    @cOperatorno,
    @dAwardDate,
    @cVipName,
    @cOpertorName,
    @fCurValue,
    -@fScore,
    @fLeaveValue,@cAwardName,@fMoney_cost,@feiyong,@feiyongno,@dDate1,@dDate2,@bRatio
  )
end


GO
