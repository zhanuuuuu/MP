/*

  p_x_salesABC_bySupplier_Web_A '2010-01-01','2011-06-03','0001'
*/

CREATE PROCEDURE [dbo].[p_x_salesABC_bySupplier_Web_A] 
	@dBeginDate datetime,
@dEndDate datetime,


@supno varchar(32)
AS



BEGIN

if  (select object_id('tempdb..#temp_SupplierNo')) is not null
 drop table #temp_SupplierNo
Create Table #temp_SupplierNo (
cSupplierNo varchar(128))
insert into #temp_SupplierNo (cSupplierNo)
select cSupplierNo=cSupNo from  t_Supplier where cSupNo= @supno
if (select object_id('tempdb..#temp_Goods')) is not null
 drop table #temp_Goods
Create Table #temp_Goods (
cGoodsNo varchar(128),
cProductNo varchar(128),
cSupplierNo varchar(128))

if  (select object_id('tempdb..#tempSupNo')) is not null
 drop table #tempSupNo
select distinct cSupplierNo into #tempSupNo from #temp_SupplierNo
insert into  #temp_Goods  (cGoodsNo,cSupplierNo) 
select distinct a.cGoodsNo,a.cSupNo
from t_goods a,#tempSupNo b
where a.cSupNo=b.cSupplierNo
update a set a.cProductNo=b.cProductNo
from #temp_Goods a,t_goods b where a.cGoodsNo=b.cGoodsNo



	 select cGoodsNo,cSupplierNo into #t_Goods from #temp_Goods

--                销售单                 开始    
  select a.cGoodsNo,b.fQuantity,b.fLastSettle
        
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      ,t_SaleSheetDetail b
        where a.cGoodsNo=b.cGoodsNo 
       and  (b.dSaleDate between @dBeginDate and @dEndDate)
       and isnull(tag_daily,0)=0  --未日结
  union all
  select a.cGoodsNo,b.fQuantity,b.fLastSettle  from #t_goods a,
       t_SaleSheet_Day b
         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @dBeginDate and @dEndDate)
  union all
  select a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney
   
  from #t_goods a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c
         where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dBeginDate and @dEndDate)
  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
  into #t_SaleSheetDetail1  --销售单
  from #t_SaleSheetDetail_shelf
  group by cGoodsNo
--               销售单                 结束 

--合并  开始
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,a.cSupplierNo,o.cSupName,
               
                  xsQty=m.qty,xsMoney=m.fLastMoney
      into #temp_goodsKuCun1_NoZero from #t_Goods a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , t_Supplier o --on a.cSupplierNo=o.cSupNo
                             , #t_SaleSheetDetail1 m --on a.GoodsNo_Pdt=m.GoodsNo
                             where a.cGoodsNo=b.cGoodsNo  and a.cGoodsNo=m.cGoodsNo and a.cSupplierNo=o.cSupNo
                              
--合并  结束

if(select OBJECT_ID('tempdb..#tmpGoodsLast')) is not null
drop table #tmpGoodsLast
declare @strSQL   varchar(6000)       -- 主语句
    set @strSQL=' select GoodsNo_Pdt=''总计:''
		  ,cUnitedNo=null,cGoodsName=null,cGoodsTypeno=null,
		  cGoodsTypename=null,bProducted=null,cProductNo=null,
		     BeginDate,EndDate,cSupplierNo=null,cSupName=null,
            
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from  #temp_goodsKuCun1_NoZero 
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
		  '      
 exec(@strSQL)
 --select @pageCount=ceiling(@recordCount*1.0/@pageSize)--总共分了多少页
 	  	
END
GO
