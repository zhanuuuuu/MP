 
/*
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods    where  (cGoodsNo='0410084'   ) 
 
exec [P_x_SetCheckWh_byGoodsType_CheckWh_log]
'1010','2017-2-22','2017-2-22','01010' 
 
exec [P_x_SetCheckWh_byGoodsType_CheckWh_log_test]
'1010','2017-2-22','2017-2-22','01010' 

*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_byGoodsType_CheckWh_log]
@cStoreNo varchar(32),
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32)--,/*是仓库No*/
--@bJiaGong bit
as
  
--print getdate()
--print 1
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
select distinct a.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1 into  #tmp_WhGoodsList_1  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1   ---- 大包装
union all
select distinct a.cGoodsNo ,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1   --- 小包装
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''  -- 获取大包装下的笑包装
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1

CREATE INDEX IX_WhGoodsList_1  ON #tmp_WhGoodsList_1(cGoodsNo)

if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage,bbox 
into #tmp_WhGoodsList from  #tmp_WhGoodsList_1

 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32),@Rdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@Rdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,期末库存 money,fPrice_Avg money)
  
 /*快照表中的最大日期。。。*/

/*结转表中取数据*/
 
	-----查最大日结时间内信息@dDateBegin到@dDateEnd

insert into #temp_WhFromend  ([cGoodsNo],[cWHno]) 
select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
--print getdate()
--print 3
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额

	--if @dDateBgn<=@maxWhdDate
	--begin
	--    set @i=1
 
declare @strDateEnd varchar(32)				 
set @strDateEnd=dbo.getdaystr(@dDateEnd)  
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateEnd)
set @Day1=day(@dDateEnd)
set @Y1=YEAR(@dDateEnd)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1

exec(' 
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
	select a.cgoodsno,fQty1=b.fQty_'+@MMDAY1+' 	
	into #temp_Wh_Goods_end
	from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
	select cgoodsno,本日库存数量=SUM(isnull(fQty1,0))							   
	into #temp_SumWh_Goods_end
	from #temp_Wh_Goods_end
	group by cgoodsno 	            

	update a 
	set a.期末库存=b.本日库存数量	   
	from #temp_WhFromend a ,#temp_SumWh_Goods_end b
	where a.cGoodsNo=b.cGoodsNo 
	
	----------期末入库数
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select distinct a.cGoodsno,fPriveAvg=b.fAvgIn_'+@MMDAY1+'					 
	into #temp_Wh_Goods_endCost
	from '+@cdbname+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b,#temp_WhFromend a
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
 
	 
	update a 
	set  
	a.fPrice_Avg=b.fPriveAvg		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo 
	
') 
 
	 -- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
			 --- 结束日期数据-（开始日期-1）数据 得出时间段数据    
   	--------------------盘点
	if(select object_id('tempdb..#templast_pd0_1')) is not null drop table #templast_pd0_1
	select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff)
	into #templast_pd0_1
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo and b.cStoreNo=@cStoreNo
	where b.dCheckTask<@dDateEnd
	and b.cWhNo=@cWHno   
	group by a.cGoodsNo
	order by a.cGoodsNo
	
	
	update a
	set  a.cGoodsNo=b.cGoodsNo_minPackage,
	a.fQuantity_Diff=case when isnull(b.fQty_minPackage,1)=0 then a.fQuantity_Diff else a.fQuantity_Diff*b.fQty_minPackage end 
	from #templast_pd0_1 a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''
     
 
     
	
    if(select OBJECT_ID('tempdb..#templast_pd0')) is not null drop table #templast_pd0
    select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff) into #templast_pd0 from 
    #templast_pd0_1 a,(select distinct cGoodsNO from #tmp_WhGoodsList) b
    where a.cGoodsNo=b.cGoodsNo
    group by a.cGoodsNo
    
    
 
	if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),cSupplierNo='XXXXXX',cSupName='超市盘点'
    into #templast_pdcGoodsNo
    from #templast_pd0
	
	--select * from #templast_pd0

	----- 修改盘点期末数量
	update a
	set a.EndQty=b.fQuantity_Diff
	from #templast_pdcGoodsNo a,#templast_pd0 b
	where a.cGoodsNo=b.cGoodsNo
	
	update a
	set a.期末库存=isnull(a.期末库存,0)+isnull(b.EndQty,0)
	from #temp_WhFromend a,#templast_pdcGoodsNo b
	where a.cGoodsNo=b.cGoodsNo
		
		
	 
    
	 /*2014-10-02修改数量、大小包装*/
	 
	 /*取小包装成本*/
	 
	 
	 update a 
	 set a.cGoodsNo=b.cGoodsNo_minPackage,	
     a.期末库存=a.期末库存*b.fQty_minPackage,
     a.fPrice_Avg=case when isnull(b.fQty_minPackage,1)=0 then a.fPrice_Avg else a.fPrice_Avg/isnull(b.fQty_minPackage,1) end   
	 from #temp_WhFromend  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
	 where a.cGoodsNo=b.cGoodsNo
	 
	 /*取合计库存*/
	 if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
     select cGoodsNo,期末库存=SUM(期末库存),fPrice_Avg=CAST(null as money) into #temp_goodsKuCun_1
     from   #temp_WhFromend
     group by cGoodsNo 
     
     ---取最小成本
     if (select OBJECT_ID('tempdb..#temp_goodsKuCun_2'))is not null  drop table #temp_goodsKuCun_2
     select cGoodsNo,fPrice_Avg=MIN(fPrice_Avg) into #temp_goodsKuCun_2
     from   #temp_WhFromend
     group by cGoodsNo 
     
   
     
     update a
     set a.fPrice_Avg=b.fPrice_Avg
     from #temp_goodsKuCun_1 a,#temp_goodsKuCun_2 b
     where a.cGoodsNo=b.cGoodsNo

	 --if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
  --   select cGoodsNo,期末库存=SUM(期末库存),fPrice_Avg into #temp_goodsKuCun_1
  --   from   #temp_WhFromend
  --   group by cGoodsNo,fPrice_Avg
   

 
 
	if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null 
	drop table #tmpGoodsListInfo_2
	select a.cGoodsNo,b.cGoodsTypeno,EndQty=sum(isnull(a.期末库存,0)),
	fPrice_Avg=case when isnull(a.fPrice_Avg,0)=0 
	then 
	    case when isnull(b.fCKPrice,0)=0 
	    then 
	       case when isnull(b.fPrice_Contract,0)=0 then b.fNormalPrice else fPrice_Contract end 
	    else b.fCKPrice end
	else a.fPrice_Avg end		
	into #tmpGoodsListInfo_2
	from #temp_goodsKuCun_1 a,t_Goods b
	where a.cgoodsno=b.cGoodsno 
	group by a.cGoodsNo,b.cGoodsTypeno,a.fPrice_Avg,b.fCKPrice,b.fPrice_Contract,b.fNormalPrice
	
	
    
    /*
 2015-03-11 获取库存调整的商品
*/
	if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
	drop table #tmpGoodsRelationKucun_0
	select distinct cGoodsno into #tmpGoodsRelationKucun_0 from #tmpGoodsListInfo_2


--------获取期末前调整库存数
exec('
	if(select object_id(''tempdb..#tmpGoodsRelationKucun_2'')) is not null 
	drop table #tmpGoodsRelationKucun_2
	select a.cGoodsNo,fQty=sum(a.fQty) 
	into #tmpGoodsRelationKucun_2
	from '+@Rdbname+'.dbo.t_GoodsUpdateKucunDetail a,#tmpGoodsRelationKucun_0 b
	where a.dDatetime<='''+@dDateEnd+''' and a.cgoodsno=b.cgoodsno
	and a.cStoreNo='''+@cStoreNo+'''
	group by a.cGoodsNo


	---------修改获取库存
	update a 
	set  a.EndQty=isnull(a.EndQty,0)+isnull(b.fQty,0)  
	from #tmpGoodsListInfo_2 a,#tmpGoodsRelationKucun_2 b
	where a.cGoodsNo=b.cGoodsNo
')
	 /*------------------*/
	 
			 /*删除临时表*/
	 
	  if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList 
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
 
		if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null 
		begin  
			   insert into #temp_dateBaseForKuCun(cGoodsNo,cGoodsTypeno,EndQty,fAvgPrice)
			   select cGoodsNo,cGoodsTypeno,EndQty,fPrice_Avg from
			   #tmpGoodsListInfo_2
			 
		end else
		begin
		   select cGoodsNo,cGoodsTypeno,EndQty,fPrice_Avg from
			   #tmpGoodsListInfo_2
		end


GO
