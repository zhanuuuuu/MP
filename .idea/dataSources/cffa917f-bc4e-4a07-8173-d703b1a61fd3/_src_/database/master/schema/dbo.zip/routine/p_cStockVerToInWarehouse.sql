/*
  
  declare @return varchar(32)
  exec p_cStockVerToInWarehouse 'YH20161001-000003',@return output
  select @return
  
*/
CREATE proc p_cStockVerToInWarehouse
@cSheetNo varchar(32),--- 验货单号。
@return varchar(32) output    -- 正确返回配送出库单号、异常返回0
as
begin
   declare @cSupNo varchar(32)
   declare @dDAte datetime
   select @cSupNo=cSupplierNo,@dDAte=dDate from wh_StockVerify
   where cSheetno=@cSheetNo
 
 
  begin try
  begin tran
      --生成入库单号
       declare @cInSheetno varchar(32)
       select @cInSheetno=dbo.f_GenInsheetno(CAST(Year(@dDAte) as varchar),@cSupNo)
 
	   ---插入单据
	   insert into dbo.wh_InWarehouse  (    
	   cSheetno,cSupplierNo,cSupplier,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,    
	   bExamin,cWhNo,cWh,dDate,cTime,cBeizhu1,cBeizhu2,cStoreNo,cStoreName,cVerifySheetNo,fQty  )  
	   select   @cInSheetno,cSupplierNo,cSupplier,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,     1,cWhNo,cWh,    
	   dDate,cTime,cBeizhu1,cBeizhu2,cStoreNo,cStoreName,cSheetno,
	   (select SUM(fQuantity) from wh_StockVerifyDetail where  cSheetno=@cSheetNo  )
	   from wh_StockVerify
	   where  cSheetno=@cSheetNo 
	   
	   
	  -- 插入明细  
      insert into dbo.wh_InWarehouseDetail  
      (    cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,    
      fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,    
      fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,    cUnit,cSpec  )  
      select @cInSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,  
		fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,  
		fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,cUnit,cSpec  
		from wh_StockVerifyDetail  
		where cSheetNo=@cSheetNo
		order by iLineNo
	      
      update wh_StockVerify set bReceive=1,bExamin=1
      where cSheetNo=@cSheetNo
      
      
      commit tran
	  set @return=@cInSheetno        -- 正确返回1 
	  
  end try
  begin catch
	 rollback 
     set @return='0'        ---  异常 返回 0
  end catch
	   --update WH_BhApply set bPeisong=0,bfresh=0
	   --where cSheetno='BHSQ20161004-000013'
   
end
GO
