/*
exec p_ForSeleteAllcGoodsNo
''
*/
create proc p_ForSeleteAllcGoodsNo
@cGoodsNo varchar(64)
as
--declare @cGOodsNo varchar(64)
--set @cGOodsNo='12369'

--关联错误检测
if (select OBJECT_ID('tempdb..#temp_check'))is not null drop table #temp_check
select 大包装=a.cGoodsNo,中包装=a.cGoodsNo_minPackage,小包装=b.cGoodsNo_minPackage
into #temp_check
from 
(
	select cGoodsNo,cGoodsNo_minPackage from t_goods where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)
)a,
(
	select cGoodsNo,cGoodsNo_minPackage from t_goods where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)
)b
where a.cGoodsNo_minPackage=b.cGoodsNo

if(select COUNT(*) from #temp_check)>0
begin
	select 1
end
else
	begin 
	declare @min_goods varchar(64)
	if(@cGoodsNo)=''
	begin
		---查所有关联商品信息
		if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
		select cGoodsNo,cGoodsNo_MinPackage
		into #tmpPackGoodsList
		from t_goods
		where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

		if (select OBJECT_ID('tempdb..#temp_GoodsNo'))is not null drop table #temp_GoodsNo
		select a.*
		into #temp_GoodsNo
		from t_goods a,#tmpPackGoodsList b
		where a.cGoodsNo=b.cGoodsNo 
		union all
		select a.*
		from t_goods a,#tmpPackGoodsList b
		where a.cGoodsNo=b.cGoodsNo_minPackage
		order by a.cGoodsNo
		
		update #temp_GoodsNo
		set cGoodsNo_minPackage=cGoodsNo
		where ISNULL(cGoodsNo_minPackage,'')=''
		
		select * from #temp_GoodsNo order by cGoodsNo_minPackage,cGoodsNo
	end
	else
	begin 
		set @min_goods=@cGoodsNo
		while (select COUNT(*) from t_goods where cGoodsNo=@min_goods and cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo))>0
		begin
			 select @min_goods=cGoodsNo_minPackage from t_goods where cGoodsNo=@cGoodsNo
		end
	    
		select * from t_goods where cGoodsNo=@min_goods or cGoodsNo_minPackage=@min_goods order by cGoodsNo
	end 
end
GO
