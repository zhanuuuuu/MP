/*
返回状态：  11表示密码验证通过；
			10表示商家编号未注册； 
			0表示异常； 
 */ 
create proc p_UpMerchantInfor
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@cStoreName varchar(64),--商家名称
@image_path varchar(64),--商家图片路径
@cStoreAbbName varchar(32),--商家简称 
@cManager varchar(32),   --负责人
@cTel varchar(32),       --固定电话
@cMobilPhone varchar(32), --手机号
@cAddRess varchar(64),     --商家地址          
@return int output        --返回值
as
begin   
      begin try 
	  begin tran
		declare @cStoreNo varchar(64)
		declare @cMerchantPwd varchar(64)
		set @cStoreNo=''  		  
		  select @cStoreNo=cStoreNo,@cMerchantPwd=MerchantPwd from t_Store where cStoreNo=@Merchantid   
		  IF @cStoreNo=''
		  BEGIN 
			set @return=10
		  end else
		  BEGIN
			 update  t_Store 
			 SET   cStoreName=@cStoreName, image_path=@image_path,
				   cStoreAbbName=@cStoreAbbName, cManager=@cManager,
				   cTel=@cTel,cMobilPhone=@cMobilPhone,
				   cAddRess=@cAddRess
			 where cStoreNo=@Merchantid 
			 set @return=11
		  end   		  
		  commit tran	    
		end try
		begin catch  
		   rollback  
		  set @return=0
		end catch
	 
end
GO
