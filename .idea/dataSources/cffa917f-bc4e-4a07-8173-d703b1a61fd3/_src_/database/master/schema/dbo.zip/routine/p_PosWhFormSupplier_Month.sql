/*
  p_PosWhFormcGoods_Month '2013-08-01','2013-09-01','01','Pos_Wh_Form'
*/
create proc p_PosWhFormSupplier_Month
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32),
@DbName varchar(32)
as
begin
   declare @dDate1 varchar(32)
   declare @dDate2 varchar(32)
   set @dDate1=dbo.getdaystr(DATEADD(MONTH,-1,@dDateBgn))
   set @dDate2=dbo.getdaystr(CAST((cast(YEAR(@dDateEnd) as varchar(16))+'-'+cast(MONTH(@dDateEnd) as varchar(16))+'-01') AS DATETIME))
   
if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods
select distinct cGoodsNo into #temp_WhFromGoods from #temp_GoodsNo
   
   if(select object_id('tempdb..#temp_WhFromBgn_Month')) is not null drop table #temp_WhFromBgn_Month
  CREATE TABLE #temp_WhFromBgn_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,[cSupplierNo] varchar(32),
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money,cSupplier varchar(64),xsQty  money,xsMoney money)
  if(select object_id('tempdb..#temp_WhFromEnd_Month')) is not null drop table #temp_WhFromEnd_Month
  CREATE TABLE #temp_WhFromEnd_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,[cSupplierNo] varchar(32),
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money,cSupplier varchar(64),xsQty  money,xsMoney money)
 
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin_month''))is not null  drop table #temp_Wh_Goods_begin_month
	select a.[cGoodsNo],b.cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额
	into #temp_Wh_Goods_begin_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate1+''' and a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_month''))is not null  drop table #temp_SumWh_Goods_month
	select cgoodsno,cSupplierNo,销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额)
	into #temp_SumWh_Goods_month
	from  #temp_Wh_Goods_begin_month
	group by cgoodsno,cSupplierNo

	insert into #temp_WhFromBgn_Month([cGoodsNo],cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额)
	select [cGoodsNo],cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额 from #temp_SumWh_Goods_month           
')
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_month''))is not null  drop table #temp_Wh_Goods_end_month
	select a.[cGoodsNo],b.cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额
	into #temp_Wh_Goods_end_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate2+''' and a.cGoodsNo=b.cGoodsNo  

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_month1''))is not null  drop table #temp_SumWh_Goods_month1
	select cgoodsno,cSupplierNo,销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额)
	into #temp_SumWh_Goods_month1
	from  #temp_Wh_Goods_end_month
	group by cgoodsno,cSupplierNo

	insert into #temp_WhFromEnd_Month([cGoodsNo],cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额)
	select [cGoodsNo],cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额 from #temp_SumWh_Goods_month1           
')
 
  
 
	update a
	set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
	a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
	a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0)
	from #temp_WhFromEnd_Month a,#temp_WhFromBgn_Month b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

---------把联营的商品特别处理


 
if (select OBJECT_ID('tempdb..#temp_cGoodsSaleSheetdate'))is not null drop table #temp_cGoodsSaleSheetdate
select cGoodsNo,cWHno,fQuantity=销售数量0,fMoney=销售金额0,total_Sale0=正价销售数量,
fMoney_Sale0_all=正价销售金额,total_Sale1=特价销售数量,fMoney_Sale1_all=特价销售金额,
cSupplierNo ,cSupplier,xsQty,xsMoney
into #temp_cGoodsSaleSheetdate
from #temp_WhFromEnd_Month
 
/* 2015-05-16
 一品多商情况当前供应商根据分配超出、再次新入库入其他供应商、销售分配到新入库上、
 造成查销售时之前分配超出相应供应商的商品时销售造成负数：统一修改称主供应商
*/
---获取销售为负的商品
 
if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSalCount'))is not null drop table #temp_cGoodsSale_FuSalCount
select cGoodsNo,a=COUNT(cGoodsNo) into #temp_cGoodsSale_FuSalCount from #temp_cGoodsSaleSheetdate
--where ISNULL(fMoney,0)<0
group by cGoodsNo
having COUNT(cGoodsNo)>1

CREATE INDEX IX_temp_cGoodsSale_FuSalCount  ON #temp_cGoodsSale_FuSalCount(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSal'))is not null drop table #temp_cGoodsSale_FuSal
select b.cGoodsNo,c.cSupNo,c.cSupName into #temp_cGoodsSale_FuSal
from #temp_cGoodsSaleSheetdate a,#temp_cGoodsSale_FuSalCount b,t_Goods c
where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=c.cGoodsNo and ISNULL(a.fMoney,0)<0

CREATE INDEX IX_temp_cGoodsSale_FuSal  ON #temp_cGoodsSale_FuSal(cGoodsNo)

update a
set a.cSupplier=b.cSupName,a.cSupplierNo=b.cSupNo
from #temp_cGoodsSaleSheetdate a,#temp_cGoodsSale_FuSal b
where a.cGoodsNo=b.cGoodsNo


-----------包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*ISNULL(b.fQty_minPackage,1),
a.total_Sale0=a.total_Sale0*ISNULL(b.fQty_minPackage,1),
a.total_Sale1=a.total_Sale1*ISNULL(b.fQty_minPackage,1),
a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1)
from #temp_cGoodsSaleSheetdate a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

 
------------ 合计以上数据
if (select OBJECT_ID('tempdb..#temp_cGoodsSaleSheetdate_heji'))is not null drop table #temp_cGoodsSaleSheetdate_heji
select cGoodsNo,cWHno,fQuantity=SUM(ISNULL(fQuantity,0)),fMoney=SUM(ISNULL(fMoney,0)),
total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
xsQty=SUM(ISNULL(xsQty,0)),xsMoney=SUM(ISNULL(xsMoney,0)),cSupplierNo ,cSupplier
into #temp_cGoodsSaleSheetdate_heji
from #temp_cGoodsSaleSheetdate
group by cGoodsNo,cWHno,cSupplierNo,cSupplier

--select * from #temp_cGoodsSaleSheetdate_heji
--where cGoodsNo='1060679' or cGoodsNo='1010001'


 update a set a.cSupplier=b.cSupName
 from #temp_cGoodsSaleSheetdate_heji a,t_supplier b
 where a.cSupplierNo=b.cSupNo
	 
	 
	 
select GoodsNo_Pdt=a.cGoodsNo,a.cWHno,a.fQuantity,a.fMoney,--- 表示已记账销售数量、金额
	a.total_Sale0,a.fMoney_Sale0_all,
	a.total_Sale1,a.fMoney_Sale1_all,
	b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
	b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
	BeginDate=@dDateBgn,EndDate=@dDateEnd,a.cSupplierNo,cSupName=a.cSupplier ,
	xsQty,xsMoney,  --- 表示未记账销售数量、金额
	hejiQty=isnull(fQuantity,0)+isnull(xsQty,0),hejiMoney=isnull(fMoney,0)+isnull(xsMoney,0),
	fPrice_Contract=isnull(b.fPrice_Contract,0),
	fMoney_Contract=isnull(b.fPrice_Contract,0)*(isnull(fQuantity,0)+isnull(xsQty,0)),
	fMoney_Diff=(isnull(fMoney,0)+isnull(xsMoney,0))-(isnull(b.fPrice_Contract,0)*(isnull(fQuantity,0)+isnull(xsQty,0)))	
  into #temp_cSupXsdate
	from #temp_cGoodsSaleSheetdate_heji a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo
 
 
if(select object_id('tempdb..#temp_SupplierNo')) is not null 
begin
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.GoodsNo_Pdt,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
		         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,fQuantity=ISNULL(a.fQuantity,0),fMoney=ISNULL(a.fMoney,0),
		         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(a.hejiQty,0),hejiMoney=isnull(a.hejiMoney,0),a.total_Sale0,a.fMoney_Sale0_all,
	a.total_Sale1,a.fMoney_Sale1_all,a.fPrice_Contract,a.fMoney_Contract,a.fMoney_Diff
	into #temp_goodsKuCun_last
	from #temp_cSupXsdate a,#temp_SupplierNo b
    where a.cSupplierNo=b.cSupplierNo 
    and isnull(hejiMoney,0)<>0
    
    select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=ISNULL(fQuantity,0),fMoney=ISNULL(fMoney,0),
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(hejiQty,0),hejiMoney=isnull(hejiMoney,0),total_Sale0,fMoney_Sale0_all,
	total_Sale1,fMoney_Sale1_all,fPrice_Contract,fMoney_Contract,fMoney_Diff
		  from #temp_goodsKuCun_last where isnull(hejiMoney,0)<>0
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),
		         total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)
		  from #temp_goodsKuCun_last  where isnull(hejiMoney,0)<>0
		  group by cSupplierNo,cSupName,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)		         
		  from #temp_goodsKuCun_last where isnull(hejiMoney,0)<>0
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
		  
end else
begin
 
     select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=ISNULL(fQuantity,0),fMoney=ISNULL(fMoney,0),
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(hejiQty,0),hejiMoney=isnull(hejiMoney,0),total_Sale0,fMoney_Sale0_all,
	total_Sale1,fMoney_Sale1_all,fPrice_Contract,fMoney_Contract,fMoney_Diff
		  from #temp_cSupXsdate where isnull(hejiMoney,0)<>0
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),
		         total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)
		  from #temp_cSupXsdate  where isnull(hejiMoney,0)<>0
		  group by cSupplierNo,cSupName,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)		         
		  from #temp_cSupXsdate where isnull(hejiMoney,0)<>0
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
end

if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo 
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
if (select OBJECT_ID('tempdb..#temp_cSupXsdate'))is not null drop table #temp_cSupXsdate
if (select OBJECT_ID('tempdb..#temp_SalesABCbySupplier'))is not null drop table  #temp_SalesABCbySupplier 
if (select OBJECT_ID('tempdb..#temp_cGoodsSaleSheetdate_heji'))is not null drop table #temp_cGoodsSaleSheetdate_heji

   
end
GO
