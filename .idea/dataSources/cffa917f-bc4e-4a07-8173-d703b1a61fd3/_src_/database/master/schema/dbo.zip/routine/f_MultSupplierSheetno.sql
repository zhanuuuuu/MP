
/*
select dbo.f_MultSupplierSheetno ('2012','01','82038')
select dbo.f_MultSupplierSheetno ('2012','01','82055')
select dbo.f_GenCaiGousheetno('2011','82055')

select max(cSheetno) from t_MultSupplier_TranAcc
                  where cSupNo_Main='82055'
								and
								(substring(cSheetno,3,PatIndex('%_%',cSheetno)-11)='201201'
								
								)
select * from t_MultSupplier_TranAcc
select substring('AT201201_82055-0001',3,6)
select PatIndex('%_%','AT201201_82055-0001')
*/

create    function [dbo].[f_MultSupplierSheetno]
(@cYear varchar(4),@cMonth varchar(2),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from t_MultSupplier_TranAcc
                  where cSupNo_Main=@cSupplierNo
								and
								(
								--substring(cSheetno,3,PatIndex('%_%',cSheetno)-11)=@cYear+@cMonth
								substring(cSheetno,3,6)=@cYear+@cMonth
								)
                 )
   if @cMaxSerno is null 
   begin
     return  'AT'+@cYear+@cMonth+'_'+@cSupplierNo+'-'+'0001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,4) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<4 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'AT'+@cYear+@cMonth+'_'+@cSupplierNo+'-'+@cMaxSerno 
   end

  return ''
end


GO
