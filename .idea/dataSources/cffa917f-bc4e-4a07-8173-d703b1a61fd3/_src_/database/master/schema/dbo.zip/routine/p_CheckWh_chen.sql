/*
p_CheckWh_chen '001'
select distinct cCheckTaskNo,cCheckTask,dCheckTask from t_CheckTast_GoodsDetail
select sum(fMoney_Diff) from t_CheckTast_GoodsDetail where cCheckTaskNo='002'
select sum(fMoney_Diff) from t_CheckTast_GoodsDetail where cCheckTaskNo='001'
select sum(fMoney_Diff) from #tmp_GoodsCheckList2010_1
4-25 26791.5839         001
4-25 -253694.3534       002
*/
create proc [dbo].[p_CheckWh_chen]
@cTaskNo varchar(100)
as

declare @cTaskDate datetime set @cTaskDate='2012-08-27'
/*2012-05-09改,任务名称直接从盘点任务表[t_CheckTast]中取*/
/*2012-05-17改,盘点商品中的包装转单品 */
--declare @cTaskNo varchar(100)
--set @cTaskNo='002'

declare @cWhNo varchar(32),@date datetime
select @cWhNo=cWhNo,@date=dCheckTask from t_CheckTast where cCheckTaskNo=@cTaskNo

declare @SQLstr varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from t_WareHouse where cWhNo=@cWHno

declare @date1 datetime,@date2 datetime
set @date1='2000-01-01'
set @date2=@date-1

--要查询的商品
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo_X'))is not null drop table #tmpPloyOfGoodsinfo_X

select distinct c.cGoodsNo,c.cSupNo 
into #tmpPloyOfGoodsinfo_X  --需要查询的商品信息
from wh_CheckWh a left join wh_CheckWhDetail b on a.cSheetno=b.cSheetno
     left join t_goods c 
	 on b.cGoodsNo=c.cGoodsNo and isnull(c.bStorage,0)=1
where a.dDate=@date and c.cSpec is not null and a.cWhNo=@cWHno and ISNULL(c.bStorage,0)=1
----  增加条件
and a.cSupplierNo=@cTaskNo
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo_XX'))is not null drop table #tmpPloyOfGoodsinfo_XX

select distinct x.cGoodsNo 
into #tmpPloyOfGoodsinfo_XX
from 
(
	select cGoodsNO
	from #tmpPloyOfGoodsinfo_X
	union all
	select b.cGoodsNo_minPackage
	from #tmpPloyOfGoodsinfo_X a,t_goods b
	where a.cGoodsNo=b.cGoodsNo 
	union all
	select b.cGoodsNo
	from #tmpPloyOfGoodsinfo_X a,t_goods b
	where a.cGoodsNo=b.cGoodsNo_minPackage
)x

if(select object_id('tempdb..#temp_dateBaseForKuCun')) is not null drop table  #temp_dateBaseForKuCun
if(select object_id('tempdb..#temp_dateFrist')) is not null drop table  #temp_dateFrist
create table #temp_dateBaseForKuCun(cGoodsNo varchar(64),cGoodsTypeno varchar(64),EndQty money)

declare @bJiaGong int 

if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select distinct cGoodsNo into #temp_Goods from #tmpPloyOfGoodsinfo_XX --t_goods where cGoodsNo='12009' or cGoodsNo='12260' --

exec [P_x_SetCheckWh_byGoodsType] 
@date1,@date2,@cWhNo,@bJiaGong
--'2000-01-01','2012-04-25','01',@bJiaGong
select * into #temp_dateFrist
from #temp_dateBaseForKuCun

--select * from #temp_dateBaseForKuCun where cGoodsNo='12009' or cGoodsNo='12260'
--select * from #temp_Goods where cGoodsNo='12009' or cGoodsNo='12260'
--select * from #temp_dateFrist where cGoodsNo='12009' or cGoodsNo='12260'
drop table #temp_dateBaseForKuCun
--------------------------------------------------------------------------------盘点当天销售流水
declare @dDateBgn datetime 
set @dDateBgn=@date

if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
if (select OBJECT_ID('tempdb..#temp_SaleSheet_day'))is not null drop table #temp_SaleSheet_day
select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=(isnull(fQuantity,0)),fMoney=isnull(fLastSettle,0)
into #temp_SaleSheet_day
from t_SaleSheet_Day
where dSaleDate =@dDateBgn and isnull(cWhNo,'')=@cWhNo

----正价销售iAttribute=20,特价21
select a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0)
into #temp_jiesuan_for_day   
from #tmpPloyOfGoodsinfo_XX a left join 
			(
				select cWHno,cGoodsNo,fQuantity=sum(isnull(fQuantity,0))
				from #temp_SaleSheet_day
				group by cWHno,cGoodsNo
			) b
on  a.cGoodsNo=b.cGoodsNo
--------------------------------所有商品一天流水计算
 --iAttribute=0入库；1出库；2返厂；3顾客退货入库；31调拨入库;4调拨出库；5报损；6报益；7差价单
	if (select OBJECT_ID('tempdb..#temp_storage'))is not null drop table #temp_storage
	select cGoodsNo,cWHno,fQuantity
	into #temp_storage
	from #temp_jiesuan_for_day

--入库单统计开始 0入库；
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_InWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_InWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo
	
--出库单统计开始 1出库；
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_OutWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_OutWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--报损单统计开始 5报损；
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_LossWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_LossWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--报溢单统计开始 6报益；
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_EffusionWhDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_EffusionWh c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--返厂单统计开始 0入库；1出库；2返厂；3顾客退货入库；31调拨入库;4调拨出库；5报损；6报益；7差价单
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_RbdWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_RbdWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--客退单统计开始 0入库；1出库；2返厂；3顾客退货入库；31调拨入库;4调拨出库；5报损；6报益；7差价单
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join WH_ReturnGoodsDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join WH_ReturnGoods c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--原料出库单统计开始 0入库；1出库；2返厂；3顾客退货入库；31调拨入库;4调拨出库；5报损；6报益；7差价单
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_PackDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_Pack c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--成品入库单统计开始 0入库；1出库；2返厂；3顾客退货入库；31调拨入库;4调拨出库；5报损；6报益；7差价单
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_DivideWhDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_Divide c
	on b.cSheetNo=c.cSheetNo
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo

--调拨入库单统计开始.31调拨入库;4调拨出库；
	union all 
	select a.cGoodsNo,c.cInWhNo,fQuantity=ISNULL(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_TfrInWarehouseDetail b
	on a.cGoodsNo=b.cGoodsNo 
	left join Wh_TfrInWarehouse c
	on b.cSheetno=c.cSheetno
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cInWhNo,'')=@cWhNo

--调拨出库单统计开始
	union all
	select a.cGoodsNo,c.cWhNo,fQuantity=ISNULL(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo_XX a left join wh_TfrWarehouseDetail b
	on a.cGoodsNo=b.cGoodsNo
	left join wh_TfrWarehouse c 
	on b.cSheetno=c.cSheetno
	where c.dDate =@dDateBgn and isnull(c.bExamin,0)=1
	and ISNULL(c.cWhNo,'')=@cWhNo
----------------------------------------------------------------------------------------------------
if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null  drop table #GoodsCurStorageList
select dDateTime=@date,cGoodsNo,cWHno=@cWhNo,cSupNo='',fQuantity=EndQty,iAttribute=0,fMoney=0
into #GoodsCurStorageList
from #temp_dateFrist
union all 
select dDateTime=@date,cGoodsNo,cWhNo,cSupNo='',fQuantity=sum(isnuLL(fQuantity,0)),iAttribute=0,fMoney=0
from #temp_storage
where cWhNo=@cWhNo
group by cGoodsNo,cWhNo

--select * from #GoodsCurStorageList
--以上计算期末库存
--超出商品流水表#GoodsCurStorageList,结转商品表select * from #temp_BaseEnd

--包装转单品		select * from #GoodsCurStorageList where cGoodsNo='12009' or cGoodsNo='12260'
		if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
		select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
		into #tmpPackGoodsList
		from t_goods
		where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)
		
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
--结转、销售合计库存更新到#temp_GoodsLeft，平均进价取t_goods进价
        if (select OBJECT_ID('tempdb..#temp_GoodsLeft'))is not null drop table #temp_GoodsLeft
        create table #temp_GoodsLeft
        (cGoodsNo varchar(64),fQuantity money,fPrice_Avg money)
        insert into #temp_GoodsLeft(cGoodsNo,fPrice_Avg)
        select a.cGoodsNo,fPrice_Avg=case when b.fCKPrice=0 then b.fNormalPrice else b.fCKPrice end
        from #tmpPloyOfGoodsinfo_XX a,t_goods b
        where a.cGoodsNo=b.cGoodsNo
/*
---库存数量 
select sum(fQuantity) from #temp_GoodsLeft

select sum(EndQty) from #temp_dateFrist
select sum(fQuantity) from #temp_storage
---盘点数量
select distinct cCheckTaskNo=b.cSupplierNo,cCheckTask=b.cSupplier,a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0))
into #temp_pd
from wh_CheckWhDetail a,wh_CheckWh b
where b.dDate='2012-04-28' and a.cSheetno=b.cSheetno and b.cWhNo='01'
group by b.cSupplierNo,b.cSupplier,a.cGoodsNo

--盘点金额
select sum(fMoney)
from (
	select a.*,fMoney=a.fQuantity*b.fckPrice
	from #temp_pd a,t_goods b 
	where a.cGoodsNo=b.cGoodsNo
)x
--库存金额 select * from #temp_GoodsLeft
select sum(fMoney)
from (
	select *,fMoney= fQuantity*fPrice_Avg
	from #temp_GoodsLeft
)x

select sum(fMoney)
from 
(
	select a.*,bfQuantity=b.fQuantity,diff=a.fQuantity-b.fQuantity,fMoney=(a.fQuantity-b.fQuantity)*a.fNormalPrice
	from #temp_CheckTast_GoodsDetail a ,(
	select a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0)) from #temp_GoodsLeft a group by a.cGoodsNo
	) b 
	where a.cGoodsNo=b.cGoodsNo and a.fQuantity<>b.fQuantity
	and abs((a.fQuantity-b.fQuantity)*a.fNormalPrice)>1000
	order by a.cGoodsNo
	and (a.cGoodsNo='11777' or a.cGoodsNo='12430')
) x
*/
		update a
		set a.fQuantity=b.fQuantity
		from #temp_GoodsLeft a,
				 (
					select cGoodsNo,fQuantity=Sum(isnull(fQuantity,0))
					from #GoodsCurStorageList
					where cWhNo=@cWhNo
					group by cGoodsNo,cWhNo
				 ) b
		where a.cGoodsNo=b.cGoodsNo
		
		--select * from #temp_GoodsLeft where cGoodsNo='041006'
		--select * from #tmpPloyOfGoodsinfo_XX where cGoodsNo='041006'

--------盘点商品信息处理
		if (select OBJECT_ID('tempdb..#temp_CheckTast_GoodsDetail'))is not null drop table #temp_CheckTast_GoodsDetail
		if (select OBJECT_ID('tempdb..#temp_CheckTast_cGoodsNo'))is not null drop table #temp_CheckTast_cGoodsNo
		if (select OBJECT_ID('tempdb..#temp_CheckTast_cGoodsNo1'))is not null drop table #temp_CheckTast_cGoodsNo1

/*2012-05-09改,任务名称直接从盘点任务表[t_CheckTast]中取		
--------------------------------2012-04-28 改
		select cCheckTaskNo=b.cSupplierNo,cCheckTask=b.cSupplier,a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0))
		into #temp_CheckTast_cGoodsNo1
		from wh_CheckWhDetail a,wh_CheckWh b 
		where b.dDate=@date and a.cSheetno=b.cSheetno and b.cWhNo=@cWhNo
		group by b.cSupplierNo,b.cSupplier,a.cGoodsNo
*/		
		select cCheckTaskNo=c.cCheckTaskNo,cCheckTask=c.cCheckTask,a.cGoodsNo,fQuantity=sum(isnull(a.fQuantity,0))
        into #temp_CheckTast_cGoodsNo1
		from wh_CheckWhDetail a,wh_CheckWh b,t_CheckTast c
		where b.dDate=@date and a.cSheetno=b.cSheetno and b.cWhNo=@cWhNo and b.cSupplierNo=c.cCheckTaskNo
		and b.cSupplierNo=@cTaskNo
		group by c.cCheckTaskNo,c.cCheckTask,a.cGoodsNo
		union all 
		select cCheckTaskNo=@cTaskNo,cCheckTask=b.cCheckTask,cGoodsNo,0
		from #tmpPloyOfGoodsinfo_XX a,t_CheckTast b
		where  b.cCheckTaskNo=@cTaskNo
		--select * from wh_CheckWh
		--select * from t_CheckTast
		--盘点商品中的包装转单品 --2012-05-17改
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #temp_CheckTast_cGoodsNo1 a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		select cCheckTaskNo,cCheckTask,cGoodsNo,fQuantity=sum(isnull(fQuantity,0))
		into #temp_CheckTast_cGoodsNo
		from #temp_CheckTast_cGoodsNo1
		group by cCheckTaskNo,cCheckTask,cGoodsNo		
--------------------------------2012-04-28 改
		select a.cCheckTaskNo,a.cCheckTask,
		a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,a.fQuantity
		into #temp_CheckTast_GoodsDetail
		from #temp_CheckTast_cGoodsNo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and b.cSpec is not null and b.bStorage is not null and b.bStorage=1
		
--select * from #temp_CheckTast_GoodsDetail
/*2012-05-05
-------------------------------------------------------------------------------------------------------------------------------------
drop table #ready
select  a.cCheckTaskNo,a.cCheckTask,--cWhNo=@cWhNo,
		a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cUnit,a.cSpec,fQuantity_Check=a.fQuantity,
		fQuantity_Sys=b.fQuantity,
		fQuantity_Diff=a.fQuantity-b.fQuantity,
		cSupNo='',cSupName='',fInPrice_Avg=b.fPrice_Avg,a.fNormalPrice,
		fMoney_Diff=cast(0 as money),fMoney_CurSale='',fMoney_Sale_Diff=''--,Ddate=@date
into #ready
from #temp_CheckTast_GoodsDetail a,#temp_GoodsLeft b
where a.cGoodsNo=b.cGoodsNo

select * from #temp_CheckTast_GoodsDetail 
select * from #temp_GoodsLeft

select * from #ready where fMoney_Diff<-1000

update a
set fMoney_Diff=fQuantity_Diff*fInPrice_Avg
from #ready a

select SUM(fQuantity_Check),SUM(fQuantity_Sys),SUM(fQuantity_Diff),sum(fMoney_Diff) from #ready where fMoney_Diff<-1000
-----------------------------------------------------------------------------------------------------------------------------------------
*/		
		if (select OBJECT_ID('tempdb..#tmp_GoodsCheckList2010_1'))is not null drop table #tmp_GoodsCheckList2010_1
		select cCheckTaskNo,cCheckTask,
		cGoodsTypeno=cast(null as varchar(32)),cGoodsTypename=cast(null as varchar(64)),
		cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,
		fNormalPrice,
		fQuantity_Sys=cast(null as money),--当前库存
		fMoney_CurSale=cast(null as money),--当前库存金额
		fQuantity_Check=fQuantity,--盘点库存
		fMoney_check=cast(null as money),--盘点库存金额
		fQuantity_Diff=cast(null as money),--盘点差异
		fMoney_Diff=cast(null as money),--盘点差异金额
		fInPrice_Avg=cast(null as money)--平均进价 
		into #tmp_GoodsCheckList2010_1
		from #temp_CheckTast_GoodsDetail
		
		update a
		set a.fInPrice_Avg=b.fPrice_Avg,a.fQuantity_Sys=b.fQuantity
		from #tmp_GoodsCheckList2010_1 a ,#temp_GoodsLeft b 
		where a.cGoodsNo=b.cGoodsNo
		
		update a
		set a.fNormalPrice=b.fNormalPrice,a.cGoodsTypeno=b.cGoodsTypeno,a.cGoodsTypename=b.cGoodsTypename
		from #tmp_GoodsCheckList2010_1 a ,t_goods b 
		where a.cGoodsNo=b.cGoodsNo
		
		update a
		set a.fQuantity_Sys=isnull(d.fQuantity,0),
		    a.fMoney_CurSale=isnull(d.fQuantity,0)*a.fInPrice_Avg,
		    a.fMoney_check=isnull(a.fQuantity_Check,0)*a.fInPrice_Avg,
		    a.fQuantity_Diff=isnull(a.fQuantity_Check,0)-isnull(d.fQuantity,0),
		    a.fMoney_Diff=(isnull(a.fQuantity_Check,0)-isnull(d.fQuantity,0))*a.fInPrice_Avg
		from #tmp_GoodsCheckList2010_1 a ,#temp_GoodsLeft d
		where a.cGoodsNo=d.cGoodsNo
		
		update a
		set a.fQuantity_Sys=isnull(a.fQuantity_Sys,0),
		    a.fMoney_CurSale=isnull(a.fQuantity_Sys,0)*a.fInPrice_Avg,
		    a.fMoney_check=isnull(a.fQuantity_Check,0)*a.fInPrice_Avg,
		    a.fQuantity_Diff=isnull(a.fQuantity_Check,0)-isnull(a.fQuantity_Sys,0),
		    a.fMoney_Diff=(isnull(a.fQuantity_Check,0)-isnull(a.fQuantity_Sys,0))*a.fInPrice_Avg
		from #tmp_GoodsCheckList2010_1 a 
		where isnull(a.fQuantity_Sys,0)=0
		
	 begin try 
   begin tran
/**/
		delete from dbo.t_CheckTast_GoodsDetail where cCheckTaskNo=@cTaskNo  

		insert into t_CheckTast_GoodsDetail  
		(                                  
			cCheckTaskNo,cCheckTask,cWhNo,
			cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,fQuantity_Check, 
			fQuantity_Sys,
			fQuantity_Diff,cSupplierNo,cSupplier,fInPrice_Avg,fNormalPrice,
			fMoney_Diff,fMoney_CurSale,
			fMoney_Sale_Diff,dCheckTask  
		)  

		select a.cCheckTaskNo,a.cCheckTask,cWhNo=@cWhNo,
		a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cUnit,a.cSpec,a.fQuantity_Check,
		a.fQuantity_Sys,
		a.fQuantity_Diff,b.cSupNo,b.cSupName,a.fInPrice_Avg,a.fNormalPrice,
		a.fMoney_Diff,a.fMoney_CurSale,fMoney_Sale_Diff=a.fQuantity_Diff*a.fNormalPrice,dDatetime=@date

		from #tmp_GoodsCheckList2010_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo
/*		
		select distinct count(cGoodsNo) from #tmp_GoodsCheckList2010_1 
		
		select * 
		from #tmp_GoodsCheckList2010_1 a,#tmp_GoodsCheckList2010_1 b
		where a.cGoodsNO=b.cGOodsNo and a.fQuantity_Check<>b.fQuantity_Check
		
select * from #tmp_GoodsCheckList2010_1 where cGoodsNo='8211018'
*/
  commit tran
  
 end try
 begin catch
    rollback
 end catch
 
/*
drop table #aaa
drop table #bbb
drop table #ccc
select cGoodsNo,cGoodsName,盘点库存=sum(fQuantity_Check),电脑库存=sum(fQuantity_Sys),差异数量=sum(fQuantity_Diff),差异金额=sum(fMoney_Diff)
into #xxx
from 
(
	select * from t_CheckTast_GoodsDetail where cCheckTaskNo='002'
	union all 
    select * from t_CheckTast_GoodsDetail where cCheckTaskNo='001'
)c
group by cGoodsNo,cGoodsName

select a.*,条码=b.cBarcode
from #xxx a,t_goods b
where a.cGoodsNo=b.cGoodsNo and 差异金额<>0 order by cGoodsNo



select x.*,条码=b.cBarcode,cGoodsTypeno,cGoodsTypename
from #xxx x,t_goods b
where x.cGoodsNo=b.cGoodsNo and x.差异金额<0 order by cGoodsTypeno,x.cGoodsNo

select sum(差异金额)
from #xxx x,t_goods b
where x.cGoodsNo=b.cGoodsNo and x.差异金额<>0 order by cGoodsTypeno,x.cGoodsNo


select * from t_CheckTast_GoodsDetail where cCheckTaskNo='002'
select * from t_CheckTast_GoodsDetail where cCheckTaskNo='001'



select * from t_CheckTast_GoodsDetail where abs(fMoney_Diff)>100

select sum(fMoney_Diff) from t_CheckTast_GoodsDetail where abs(fMoney_Diff)>100

*/
GO
