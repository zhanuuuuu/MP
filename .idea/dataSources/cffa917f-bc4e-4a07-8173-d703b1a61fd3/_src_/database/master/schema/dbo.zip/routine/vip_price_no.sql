CREATE proc vip_price_no
@year varchar(20),
@cWhNo varchar(20)
as
select dbo.f_GetVipfPriceSheetno (@Year,@cWhNo) as vip_no_price_no
GO
