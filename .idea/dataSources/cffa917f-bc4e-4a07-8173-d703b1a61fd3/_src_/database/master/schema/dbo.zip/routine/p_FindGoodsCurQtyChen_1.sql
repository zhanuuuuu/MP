
--超市商品实时库存查询
/*
drop table #tmpGoodsCurQtyList
select cGoodsNo into #tmpGoodsCurQtyList from t_goods-- where cgoodsNo='46031075'
select * from #tmpGoodsCurQtyList
create table #tmpTypeCurQtyList (cTypeNo varchar(32)) 
create table #tmpSupCurQtyList (cSupNo varchar(32)) 
p_FindGoodsCurQtyChen '02',0 
*/
CREATE proc [dbo].[p_FindGoodsCurQtyChen]
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商
--set @Type=0
--set @cWhNo='04'
as
if (select object_id('tempdb..#tmpCurQueryGoods'))is not null
drop table #tmpCurQueryGoods

select cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,fCkPrice
into #tmpCurQueryGoods
from t_goods
where isnull(bstorage,0)=1
and(
     ( 
        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpGoodsCurQtyList)
      )
      or
     ( 
        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpTypeCurQtyList)
     )
     or
     ( 
        (@Type=2)and cSupNo in(select distinct cSupNo from #tmpSupCurQtyList)
     )
)

--select * from dbo.t_Goods_CurWH
--select * from #tmpCurQueryGoods

select a.cGoodsNo,a.cGoodsName,a.cUnit,a.cSpec,a.cSupNo,a.cSupName,a.cGoodsTypeNo,a.cGoodsTypeName,
a.fCkPrice,b.cWhNo,b.fQty_CurWh,b.dDateTime_CurWh,b.dDatetime_Gen,b.fQty_in,b.fQty_Divide,b.fQty_Return,
b.fQty_tfrin,b.fQty_effusion,b.fQty_out,b.fQty_pack,b.fQty_rbd,b.fQty_loss,b.fQty_trf,b.fQty_checkout,
b.fQty_sale,b.dDate_Daily,

x.fPrice_Contract,x.fQty_created,
x.cGoodsNo_minPackage_tmp,x.fQty_minPackage,
x.fVipPrice_student,x.fPackRatio,x.fVipScore_Base,

--x.fValue_Score,
x.cCkPriceInSheetno,x.cUnitedNo,x.fNormalPrice,x.fVipScore,
x.fVipPrice,
x.cBarcode,cBarcode_min=y.cBarcode,cGoodsName_min=y.cGoodsName,
cUnit_min=y.cUnit,cSpec_min=y.cSpec,fMoney_CurWH=b.fQty_CurWh*x.fPrice_Contract
into #temp_curwh_QtyChen
from #tmpCurQueryGoods a left join t_Goods_CurWH b
on a.cGoodsNo=b.cGoodsNo
left join t_Goods x on a.cGoodsNo=x.cGoodsNo
left join t_Goods y on y.cGoodsNo=x.cGoodsNo_minPackage_tmp
where (b.cWhNo=@cWhNo and dbo.trim(isnull(@cWhNo,''))<>'')
or dbo.trim(isnull(@cWhNo,''))=''
order by a.cGoodsNo,b.cWhNo,a.cSupNo,a.cGoodsTypeNo

select 
cGoodsNo,cGoodsName,cUnit,cSpec,cSupNo,cSupName,cGoodsTypeNo,cGoodsTypeName,
 fCkPrice, cWhNo, fQty_CurWh, dDateTime_CurWh, dDatetime_Gen, fQty_in, fQty_Divide, fQty_Return,
 fQty_tfrin, fQty_effusion, fQty_out, fQty_pack, fQty_rbd, fQty_loss, fQty_trf, fQty_checkout,
 fQty_sale, dDate_Daily,

 fPrice_Contract, fQty_created,
 cGoodsNo_minPackage_tmp, fQty_minPackage,
 fVipPrice_student, fPackRatio, fVipScore_Base,
 cCkPriceInSheetno, cUnitedNo, fNormalPrice, fVipScore,
  fVipPrice,
 cBarcode,cBarcode_min,cGoodsName_min,
	cUnit_min,cSpec_min,fMoney_CurWH
from #temp_curwh_QtyChen
union all
select 
cGoodsNo='合计:',cGoodsName=null,cUnit=null,cSpec=null,cSupNo=null,cSupName=null,cGoodsTypeNo=null,cGoodsTypeName=null,
 fCkPrice=null, cWhNo=null, fQty_CurWh=SUM(ISNULL(fQty_CurWh,0)), dDateTime_CurWh=null, dDatetime_Gen=null, 
 fQty_in=null, fQty_Divide=null, fQty_Return=null,
 fQty_tfrin=null, fQty_effusion=null, fQty_out=null, fQty_pack=null, fQty_rbd=null, fQty_loss=null, fQty_trf=null, fQty_checkout=null,
 fQty_sale=null, dDate_Daily=null,

 fPrice_Contract=null, fQty_created=null,
 cGoodsNo_minPackage_tmp=null, fQty_minPackage=null,
 fVipPrice_student=null, fPackRatio=null, fVipScore_Base=null,
 cCkPriceInSheetno=null, cUnitedNo=null, fNormalPrice=null, fVipScore=null,
 fVipPrice=null,
 cBarcode=null,cBarcode_min=null,cGoodsName_min=null,
cUnit_min=null,cSpec_min=null,fMoney_CurWH=SUM(isnull(fMoney_CurWH,0))
from #temp_curwh_QtyChen
order by cGoodsNo

GO
