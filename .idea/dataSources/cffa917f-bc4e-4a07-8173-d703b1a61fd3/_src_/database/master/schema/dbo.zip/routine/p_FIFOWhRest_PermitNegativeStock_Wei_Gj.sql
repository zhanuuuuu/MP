/*
 
  declare @Return int
  exec p_FIFOWhRest_PermitNegativeStock_Wei_Gj  '2015-04-01','t_Cost_distribute_Log_04_1', @Return output
  select @Return
  
*/
CREATE proc p_FIFOWhRest_PermitNegativeStock_Wei_Gj
@maxDailyCost datetime,
@tCost_distribute_Log varchar(32),
@Return int output       --返回1：库存不足2:内部错误3:数量为0
as
begin
	--declare @maxDailyCost datetime  -- 最大的备份日期
	
	declare @posWhForm varchar(32)
	declare @maxMonth datetime
	--select @maxDailyCost=MAX(dDate) from t_Daily_history where ISNULL(b_Backup_Cost_distribute_Log,0)=1
	
	declare @maxWhdDate datetime
	select @posWhForm=Pos_WH_Form from t_WareHouse where isnull(bMainSale,0)=1
	set @maxWhdDate=(select  MAX(dDate) from t_Daily_history where ISNULL(bAccount_log,0)=1)

--begin try
-- begin tran
	/*删除快照表*/
	
	declare @dDAte datetime
	set  @dDAte=@maxDailyCost+1
	
	declare  @CountDay int
	-------- 天数。。 
	set @CountDay=DATEDIFF(DAY,@dDAte,@maxWhdDate)+1
	
	declare @i int 
	set @i=0
	while(@i<@CountDay)
	begin	
		exec('
			delete from '+@posWhForm+'.dbo.t_WH_Form_Log_1
			where 业务日期='''+@dDAte+'''

			delete from '+@posWhForm+'.dbo.t_WH_Form_Log_0
			where 业务日期='''+@dDAte+'''

			 delete from '+@posWhForm+'.dbo.t_WH_Form_Log_type_Day where  dDateBgn='''+@dDAte+'''
		 ')
		 set @i=@i+1
		 set @dDAte=@dDAte+1
	end
	
 exec('
	/*删除成本表*/
	delete from Posmanagement.dbo.t_WH_Form_Log
	----修改显示列 先运行插入显示列
	set IDENTITY_INSERT t_WH_Form_Log  on
	/*添加成本表*/
	insert into Posmanagement.dbo.t_WH_Form_Log(
	 业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, iAttribute, cSummary, fPrice_Tran, fPrice_In, 
	 fQty_In, fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
	 cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价
	)
	select 
	业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, 
	fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, cSupplier, 
	cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价
	from '+@posWhForm+'.dbo.t_WH_Form_Log_1
	where 业务日期=('''+@maxDailyCost+''')

	/*不允许插入显示列:自动生成*/
	set IDENTITY_INSERT t_WH_Form_Log off 
')

	delete a
	from T_WH_Form_Log_Back a,t_WH_Form_Log b
	where a.iserno=b.iSerno

	/*以上为成本表*/

	truncate table Pos_Cost_distribute.dbo.T_Cost_distribute_log
	truncate table Pos_Cost_distribute.dbo.T_Cost_distribute_log_temp 

 
    declare @tCost_distribute_Log_temp varchar(32)
    set @tCost_distribute_Log_temp='t_Cost_distribute_Log_temp'+SUBSTRING(@tCost_distribute_Log,22,30)
    
 
	exec('
	set IDENTITY_INSERT Pos_Cost_distribute.dbo.T_Cost_distribute_log  on

	insert into Pos_Cost_distribute.dbo.t_Cost_distribute_log 
	(
	 dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	 fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, bJiesuan, cJiesuanNo
	)
	select  dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, bJiesuan, cJiesuanNo
	 from Tech_Contract_2005.dbo.'+@tCost_distribute_Log+'
 

	set IDENTITY_INSERT Pos_Cost_distribute.dbo.T_Cost_distribute_log  off

	insert into Pos_Cost_distribute.dbo.T_Cost_distribute_log_temp
	(
	 操作日期,dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	 fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, bJiesuan, cJiesuanNo
	)
	select  
	操作日期,dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, bJiesuan, cJiesuanNo
	 from Tech_Contract_2005.dbo.'+@tCost_distribute_Log_temp+'
 
	')
	/*恢复进销存.......*/
	    update dbo.wh_DiffPriceWarehouse set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update dbo.wh_Divide set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.wh_EffusionWh set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.wh_Exchange set bAccount_log=0 where dDate>@maxDailyCost

		update dbo.wh_InWarehouse  set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.wh_LossWarehouse set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update dbo.wh_OutWarehouse  set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update dbo.wh_Pack  set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.wh_RbdWarehouse set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.WH_ReturnGoods set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost

		update  dbo.Wh_TfrInWarehouse set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost
		update dbo.wh_TfrWarehouse  set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost
		 
		update t_Daily_history set bAccount_log=0,bAccount=0 where dDate>@maxDailyCost
		
		
  --      declare @temp_Goods_Vip_Sales_ varchar(32)
  --      set @temp_Goods_Vip_Sales_='temp_Goods_Vip_Sales'+SUBSTRING(@tCost_distribute_Log,22,30)

		--exec('
		--truncate table Posmanagement.dbo.temp_Goods_Vip_Sales

		--insert into Posmanagement.dbo.temp_Goods_Vip_Sales(
		--  cgoodsno,fquantity,flastsettle,dDate,vipCount,lkCount
		--)
		--select cgoodsno,fquantity,flastsettle,dDate,vipCount,lkCount 
		--from Tech_Contract_2005.dbo.'+@temp_Goods_Vip_Sales_+'
 
  --      ')


--  commit tran
--  set @Return=0 
--end try
--begin catch
-- rollback 
-- set @Return=2 
-- return
--end catch


end
GO
