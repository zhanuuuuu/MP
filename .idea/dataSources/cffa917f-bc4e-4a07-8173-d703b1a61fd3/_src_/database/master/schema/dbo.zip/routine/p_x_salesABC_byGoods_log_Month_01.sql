 
/*
--原来毛利脚本

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods   where  cgoodsno='33341'
--union all
--select cGoodsNo,csupno='1070' from t_Goods where  cgoodsno='101267'

exec [p_x_salesABC_byGoods_log_Month_01] '2015-10-6','2014-10-12','01'
 
*/
CREATE procedure [dbo].[p_x_salesABC_byGoods_log_Month_01]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cdbname varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）


declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

 
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 
 

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 
  正价销售金额 money)
  
 /*快照表中的最大日期。。。*/
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)
insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

/*结转表中取数据*/
 

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd 
		set @maxWhdDate=@dDateBgn-1
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
select cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
insert into #temp_WhFromend  ([cGoodsNo],[cWHno]) 
select cGoodsNo,@cWhNo from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)

	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
if @dDateBgn<=@maxWhdDate
begin
		set @SQLstr= '
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
					b.特价销售数量, b.特价销售金额, 
					b.正价销售数量, b.正价销售金额
					into #temp_Wh_Goods_begin
					from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					with (nolock) 
					where b.业务日期='''+dbo.getdaystr(@dDateBgn-1)+''' and  a.cGoodsNo=b.cGoodsNo 
					and b.cWHno='+@cWHno+'

					union all             
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
					b.特价销售数量, b.特价销售金额, 
					b.正价销售数量, b.正价销售金额			
					from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					with (nolock) 
					where b.业务日期='''+dbo.getdaystr(@dDateBgn-1)+''' and  a.cGoodsNo=b.cGoodsNo 
					and b.cWHno='+@cWHno+'


					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
					select cgoodsno,cWHno,销售数量0=sum(销售数量0), 销售金额0=sum(销售金额0), 
					特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 
					正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额)
					into #temp_SumWh_Goods_begin
					from  #temp_Wh_Goods_begin
					group by cgoodsno,cWHno

					update a 
					set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
					a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
					a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额					
					from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
					where a.cGoodsNo=b.cGoodsNo 
					----and b.业务日期='''+dbo.getdaystr(@dDateBgn-1)+''' 
					and b.cWHno='+@cWHno+'
					 ' 

		set @SQLstr1='
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
					b.特价销售数量, b.特价销售金额, 
					b.正价销售数量, b.正价销售金额
					into #temp_Wh_Goods_end
					from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					with (nolock) 
					where b.业务日期='''+dbo.getdaystr(@maxWhdDate)+''' and  a.cGoodsNo=b.cGoodsNo 
					and b.cWHno='+@cWHno+'

					union all             
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
					b.特价销售数量, b.特价销售金额, 
					b.正价销售数量, b.正价销售金额		 
					from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					with (nolock) 
					where b.业务日期 between '''+dbo.getdaystr(@dDateBgn-1)+''' and '''+dbo.getdaystr(@maxWhdDate)+''' 
					and  a.cGoodsNo=b.cGoodsNo 
					and b.cWHno='+@cWHno+' and b.iAttribute<>20 

					union all             
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
					b.特价销售数量, b.特价销售金额, 
					b.正价销售数量, b.正价销售金额
					from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					with (nolock) 
					where b.业务日期='''+dbo.getdaystr(@maxWhdDate)+''' and  a.cGoodsNo=b.cGoodsNo 
					and b.cWHno='+@cWHno+' and b.iAttribute=20 


					if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
					select cgoodsno,cWHno,
					销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
					特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
					正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额)  
					into #temp_SumWh_Goods_end
					from  #temp_Wh_Goods_end
					group by cgoodsno,cWHno

					update a
					set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
					a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
					a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额					  
					from #temp_WhFromend a ,#temp_SumWh_Goods_end b
					where a.cGoodsNo=b.cGoodsNo 					
					and b.cWHno='+@cWHno+'
		  
			'
		    exec (@SQLstr+@SQLstr1)

		-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
			 --- 结束日期数据-（开始日期-1）数据 得出时间段数据   
			     
		
			  
			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
			a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
			a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
			a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
			a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo
		
end	
	
	--- 取记账之前的数据... 
if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
create table #temp_ReadyKucun( cGoodsNo varchar(32),cUnitedNo varchar(32),
xsQty money,xsMoney money,zxsQty money,zxsMoney money,txsQty money,txsMoney money,cWHno varchar(16))       
if 	@maxWhdDate<@dDateEnd
begin
	declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)
	if @dMaxDailyDate>@dDate_2
	begin
	set @dMaxDailyDate=@dDate_2
	end
	       
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
	select dSaleDate,cWHno,a.cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing,cSupplierNo=null
	into #temp_cGoodsSaleDate from  t_SaleSheet_Day a,#tmpCostGoodsList b
	with (nolock) 
	where dSaleDate between @dDate_1 and @dDate_2  and a.cGoodsNo=b.cGoodsNo
	union all
	select dSaleDate,cWHno,a.cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing,cSupplierNo=null
	from t_SaleSheetDetail a,#tmpCostGoodsList b
	with (nolock) 
	where dSaleDate>=@dDate_1 and dSaleDate between (@dMaxDailyDate+1) and @dDate_2 and a.cGoodsNo=b.cGoodsNo   


	if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
	select a.cGoodsNo,a.cGoodsNo_MinPackage,fQty_minPackage=isnull(a.fQty_minPackage,1)
	into #tmpPackGoodsList
	from t_goods a,#temp_cGoodsSaleDate b
	where a.cGoodsNo=b.cGoodsNO and a.cGoodsNo<>isnull(a.cGoodsNo_minPackage,a.cGoodsNo) 

	update a set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
	from #temp_cGoodsSaleDate a,#tmpPackGoodsList b
	where a.cGoodsNo=b.cGoodsNo

	if (select OBJECT_ID('tempdb..#temp01'))is not null  drop table #temp01
	select cGoodsNo,fqty=SUM(fQuantity),fmoney=SUM(fLastSettle),bAuditing into #temp01 from #temp_cGoodsSaleDate 
	group by cGoodsNo,bAuditing

	insert into #temp_ReadyKucun(cGoodsNo,xsQty,xsMoney,cWHno)
	select cGoodsNo,fqty=SUM(fqty),fmoney=SUM(fmoney),@cWHno from #temp01 
	group by cGoodsNo
		
    update a  set a.zxsQty=b.fqty,a.zxsMoney=b.fmoney
    from #temp_ReadyKucun a,#temp01 b
    where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bAuditing,0)=0
    
     update a  set a.txsQty=b.fqty,a.txsMoney=b.fmoney
    from #temp_ReadyKucun a,#temp01 b
    where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bAuditing,0)=1 
    
end
 
 if (select OBJECT_ID('tempdb..#temp_ReadycGoodsHb'))is not null drop table #temp_ReadycGoodsHb
 select [cGoodsNo],[cWHno],xsQty=销售数量0,xsMoney=销售金额0,tjXsQty=特价销售数量,tjXsMoney=特价销售金额,
 zjXsqty=正价销售数量,zjXsmoney=正价销售金额
 into #temp_ReadycGoodsHb
 from #temp_WhFromend	
 union all
 select cGoodsNo,cWHno,xsQty,xsMoney,txsQty,txsMoney ,zxsQty,zxsMoney 
 from #temp_ReadyKucun
 
  
 -------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1),
a.tjXsQty=a.tjXsQty*ISNULL(b.fQty_minPackage,1),
a.zjXsqty=a.zjXsqty*ISNULL(b.fQty_minPackage,1) 
from #temp_ReadycGoodsHb a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''



if (select OBJECT_ID('tempdb..#temp_SumcGoodsXS'))is not null drop table #temp_SumcGoodsXS
select [cGoodsNo],[cWHno],xsQty=ISNULL(SUM(xsQty),0),xsMoney=ISNULL(SUM(xsMoney),0),tjXsQty=ISNULL(SUM(tjXsQty),0),
tjXsMoney=ISNULL(SUM(tjXsMoney),0), zjXsqty=ISNULL(SUM(zjXsqty),0),zjXsMoney=ISNULL(SUM(zjXsMoney),0)
into #temp_SumcGoodsXS
from #temp_ReadycGoodsHb
group by [cGoodsNo],[cWHno]
  
 
  
if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
BeginDate=@dDateBgn,EndDate=@dDateEnd,xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
tjXsQty=ISNULL(tjXsQty,0),
tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
into  #temp_goodsKuCun
from #temp_SumcGoodsXS a,t_Goods b
where a.cGoodsNo=b.cGoodsNo 
order by a.cGoodsNo
	  
	   --  select cGoodsNo,fQuantity=ISNULL(xsQty,0),fMoney=ISNULL(xsMoney,0)
		  --       into ##temp1
		  --from #temp_goodsKuCun where isnull(xsQty,0)<>0
		  
--		  if(select object_id('tempdb..##temp_typenew')) is not null drop table ##temp_typenew
--select cGoodsNo,xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0) into ##temp_typenew from #temp_goodsKuCun

if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin	  
			if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
			select GoodsNo_Pdt=a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,
			a.cGoodsTypename,a.bProducted,a.cProductNo,
			a.BeginDate,a.EndDate,
			xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
tjXsQty=ISNULL(tjXsQty,0),
tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
			into #temp_goodsKuCun_last
			from #temp_goodsKuCun a,#temp_GoodsTypeNo b
			where a.cGoodsTypeno=b.cGoodsTypeno
  
          select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,
          cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
tjXsQty=ISNULL(tjXsQty,0),
tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
		  from #temp_goodsKuCun_last
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun_last 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun_last
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
end else
begin
    select GoodsNo_Pdt=cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,
  cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
tjXsQty=ISNULL(tjXsQty,0),
tjXsMoney=ISNULL(tjXsMoney,0), zjXsqty=ISNULL(zjXsqty,0),zjXsMoney=ISNULL(zjXsMoney,0)
		  from #temp_goodsKuCun
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun 
		  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,
		  cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),tjXsQty=sum(ISNULL(tjXsQty,0)),
      tjXsMoney=sum(ISNULL(tjXsMoney,0)), zjXsqty=sum(ISNULL(zjXsqty,0)),zjXsMoney=sum(ISNULL(zjXsMoney,0))
		  from #temp_goodsKuCun
		  group by BeginDate,EndDate
		  order by cGoodsTypeno,GoodsNo_Pdt
end
	/*获取时间段的入库记录 日期以单据日期为判断。*/

	 /*删除临时表*/
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	   if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	    if(select object_id('tempdb..#temp_ReadycGoodsHb')) is not null drop table #temp_ReadycGoodsHb
	    if (select OBJECT_ID('tempdb..#temp_SumcGoodsXS'))is not null drop table #temp_SumcGoodsXS	 
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun

GO
