CREATE procedure [dbo].[eReport005_left2_1]
@date1 datetime,
@date2 datetime,
@sj1 int,@sj2 int
as
begin
/*
if(select object_id('tempdb..#admin_tgoodstype')) is not null drop table #admin_tgoodstype
select cGoodsTypeno into #admin_tgoodstype from t_goodstype where cgoodstypeno  like '%850%'
eReport005_left2
@date1='2011-06-01',@date2='2011-06-07',@sj1=9,@sj2=13
select cGoodsTypeno into #admin_tgoodstype from t_goodstype where cgoodstypeno='850'
*/
----获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @sj1 int
--declare @sj2 int
--select @date1='2011-01-01',@date2='2011-12-07',@sj1=8,@sj2=15

--if(select object_id('tempdb..#tempLevel1')) is not null drop table #tempLevel1

-- select a.cGoodsTypeNo,a.cParentNo
--        from dbo.t_GoodsType a left join t_GoodsType b
--        on a.cGoodsTypeNo =b.cParentNo 
--        where b.cGoodsTypeNo is  null and a.cGoodsTypeno in 
--(
--select * from #admin_tgoodstype
----select cGoodsTypeno from t_GoodsType
--)        order by a.cParentNo,a.cGoodsTypeNo


if(select object_id('tempdb..#type')) is not null 	drop table 	#type
select cGoodsTypeNo,cGoodsTypeName,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) into #type 
from t_GoodsType
update #type set cpath=cParentNo+'.'+cGoodsTypeNo

update #type set cpath=cParentNo+'.'+cGoodsTypeNo
declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #type where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #type a left join #type b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	
	select @num=COUNT(*) from #type where cpath not like '%--%'
end

declare @aaaa int
select @aaaa =MAX(ilevel) from #type

select a.cGoodsTypeno,a.cGoodsTypename,a.cpath,a.ilevel
into #tempGoodsTypePath
from #type a  
where a.ilevel=@aaaa and 
  cGoodsTypeno in 
		( select a.cGoodsTypeNo
				from dbo.t_GoodsType a left join t_GoodsType b
				on a.cGoodsTypeNo =b.cParentNo 
				where b.cGoodsTypeNo is  null and a.cGoodsTypeno in 
		(select * from #admin_tgoodstype
		 --select cGoodsTypeno from t_GoodsType
		)
)


/*
select * from #tempGoodsTypePath 
*/
/*以上形成类别列表*/ 
if (select object_id('tempdb..#TmpGoodsLevel'))is not null drop table #TmpGoodsLevel
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

if (select object_id('tempdb..#GoodsType'))is not null drop table #GoodsType
select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
--where cPath=cPath_leaf

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null
update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null


----------------------------------<<<<<<<<<?///////////////////////////////////////

if(select OBJECT_ID('tempdb..#temp_salesheetDetail')) is not null drop table #temp_salesheetDetail
create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNO varchar(32),fLastSettle money,cSaleTime varchar(16))
 if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName
				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
                      
						insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime)
						select dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@date1+''' and '''+@date2+'''
   
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
		
				  
			insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime)
			select dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime
			from dbo.t_salesheetDetail 
			where dSaleDate between @SalesheetDate+1 and @date2
------------------------------


if (select object_id('tempdb..#TmpGoodsBaseInfo'))is not null drop table #TmpGoodsBaseInfo
select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,fLastSettle=sum(a.fLastSettle),sj=datepart(hh,cSaleTime)
into #TmpGoodsBaseInfo
--from t_SaleSheetDetail a left join t_goods b
from #temp_salesheetDetail a left join t_goods b
on a.cGoodsNo=b.cGoodsNo left join #TmpGoodsLevel c 
on b.cGoodsTypeno=c.cGoodsTypeNo 
where c.bLeaf=1 and dSaleDate between @date1 and @date2
and datepart(hh,cSaleTime) between @sj1 and @sj2 
group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,datepart(hh,cSaleTime)
/*
select * from #TmpGoodsBaseInfo
select * from #tmpGoodsType_byLevel
select * from #tmpGoods_byLevel
select * from t_GoodsType
*/
	  
if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null
	  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=1
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select a.dSaleDate,b.BaseGoodsTypeNo,a.cGoodsTypeno,a.cGoodsTypeName,fLastSettle=SUM(a.fLastSettle),a.sj
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo
	group by a.dSaleDate,b.BaseGoodsTypeNo,a.sj,a.cGoodsTypeno,a.cGoodsTypeName
	order by a.dSaleDate,b.BaseGoodsTypeNo,a.sj
	---------------------------------------------
if (select object_id('tempdb..#tmpGoods_byLevel1'))is not null drop table #tmpGoods_byLevel1 
	select distinct identity(int)id,BaseGoodsTypeNo,cGoodsTypename 
	into #tmpGoods_byLevel1
	from #tmpGoods_byLevel
	group by BaseGoodsTypeNo,cGoodsTypename
	order by BaseGoodsTypeNo
	
if (select object_id('tempdb..#goodstypename'))is not null drop table #goodstypename 
	select distinct BaseGoodsTypeNo,cGoodsTypename=cast(null as varchar(1000)) 
	into #goodstypename
	from #tmpGoods_byLevel1
	group by BaseGoodsTypeNo order by BaseGoodsTypeNo
/*
select * from #tmpGoods_byLevel1
select * from #goodstypename
*/
	declare @typeno varchar(32),@name varchar(100),@no varchar(32),@name_ varchar(8000)
	declare @id int,@count int  set @id=1 
	declare c cursor for
    select BaseGoodsTypeNo from #goodstypename
    open c
	fetch next from c
	into @typeno
	set @name_=''  set @count=0
	while @@Fetch_Status=0
	begin
	  select @count=COUNT(*) from #tmpGoods_byLevel1 where BaseGoodsTypeNo=@typeno
	  while (@count>0)
	   begin
	      select @no=BaseGoodsTypeNo,@name=cGoodsTypename from #tmpGoods_byLevel1 where id=@id
	      set @name_=@name_+'('+@name+')'
	      set @count=@count-1
	      set @id=@id+1
	   end
	  update #goodstypename set cGoodsTypename=@name_ where BaseGoodsTypeNo=@typeno
	
	fetch next from c
	into @typeno
	set @name_='' 
	end
	CLOSE c
	DEALLOCATE c
	
--select * from #goodstypename
	---------------------------------------------

if (select object_id('tempdb..#last'))is not null drop table #last 
if (select object_id('tempdb..#last1'))is not null drop table #last1 
select a.dSaleDate,a.BaseGoodsTypeNo,b.cGoodsTypename,a.fLastSettle,合计=CAST(null as Money),a.sj
into #last 
from #tmpGoods_byLevel a left join t_GoodsType b 
on a.BaseGoodsTypeNo=b.cGoodsTypeno

select 类别NO=a.BaseGoodsTypeNo,类别名称=a.cGoodsTypename,
销售金额=sum(a.fLastSettle),日期=convert(char(10),a.dSaleDate,120) 
into #last1
from #last a ,#goodstypename b 
where a.BaseGoodsTypeNo=b.BaseGoodsTypeNo
group by dSaleDate,a.BaseGoodsTypeNo,a.cGoodsTypename
order by a.BaseGoodsTypeNo,dSaleDate

select a.类别NO,类别名称='['+a.类别名称+']-'+b.cGoodsTypename,a.销售金额,a.日期
from #last1 a ,#goodstypename b 
where a.类别NO=b.BaseGoodsTypeNo
union all
select '合计:',null,isnull(SUM(fLastSettle),0),null  from #last 
end


GO
