create    function [dbo].[f_GetPackLostSheetNo]
(@cYear varchar(4),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   declare @strTemp varchar(32)
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.t_PackLost
                  where ((cClientNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear)
					or(substring(cSheetno,8,PatIndex('%-%',cSheetno)-8)=@cSupplierNo
					   and datename(yyyy,dDate)=@cYear	
					  ))
                    or((cSupplierNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear)
					or(substring(cSheetno,8,PatIndex('%-%',cSheetno)-8)=@cSupplierNo
					   and datename(yyyy,dDate)=@cYear	
					  ))

                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp='PLT'+@cYear+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp='PLT'+@cYear+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end


GO
