--select * from t_wh_form
--select * from dbo.t_Cost_distribute
/*
  declare @dDate datetime
  set @dDate='2009-11-20'
  FIFO先进先出成本表（库龄、失效期、买完？）
drop table #tmpCostGoodsList
select cGoodsNo into #tmpCostGoodsList from t_goods where cgoodsNo='21031001'
select * from #tmpCostGoodsList
create table #tmpCostTypeList (cTypeNo varchar(32)) 
create table #tmpCostSupList (cSupNo varchar(32))  
p_FIFOCWhStorageDetail_chen_MultiSup '2010-02-25','2010-10-26',1,'04',0

*/
create proc [dbo].[p_FIFOCWhStorageDetail_chen_MultiSup20130419]
@dDate1 datetime,
@dDate2 datetime,
@bListOtherSupplier bit,--是否显示一品多商之相关供应商
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商
as
--declare @dDate1 datetime
--declare @dDate2 datetime
--declare @Type int
--set @dDate1='2008-11-24'
--set @dDate2='2009-11-24'
--set @Type=0
if (select object_id('tempdb..#FIFOCWhDate_chen'))is not null
drop table #FIFOCWhDate_chen
if (select object_id('tempdb..#tmp_Date1In'))is not null
drop table #tmp_Date1In
if (select object_id('tempdb..#tmp_Date1Out'))is not null
drop table #tmp_Date1Out
if (select object_id('tempdb..#tmp_Date2In'))is not null
drop table #tmp_Date2In
if (select object_id('tempdb..#tmp_Date2Out'))is not null
drop table #tmp_Date2Out
if (select object_id('tempdb..#tmp_PeriodJxcIn'))is not null
drop table #tmp_PeriodJxcIn
if (select object_id('tempdb..#tmp_PeriodJxcOut'))is not null
drop table #tmp_PeriodJxcOut

if (select object_id('tempdb..#tmpSysInit'))is not null
drop table #tmpSysInit
if (select object_id('tempdb..#tmpSysInit1'))is not null
drop table #tmpSysInit1
if (select object_id('tempdb..#tmpSysInit2'))is not null
drop table #tmpSysInit2


create table #FIFOCWhDate_chen
(
  cGoodsNo varchar(32),
  cGoodsName varchar(100),
  date1 datetime,
  date2 datetime,
  fQty_in_bgn money default(0),     --起初接收数量
  fMoney_in_bgn money default(0),   --起初接收金额
  fQty_Out_bgn money default(0),    --起初发出数量
  fMoney_Out_bgn money default(0),  --起初发出金额
  fSheetMoney_Out_bgn money default(0),--起初发出单据金额
  fQty_bgn money default(0),        --起初库存数量
  fMoney_bgn money default(0),      --起初库存金额
  fQty_in_period money default(0),  --起间接收数量
  fMoney_in_period money default(0),--起间接收金额
  fQty_Out_period money default(0), --起间发出数量
  fMoney_Out_period money default(0),--起间发出金额
  fQty_period money default(0),     --起间数量（temp）
  fMoney_period money default(0),   --起间金额（temp）
  cSupNO varchar(32),
  cSupName varchar(64),
  cUnit varchar(32),
  cSpec varchar(32),
  fQty money default(0),           --期末库存
  fMOney money default(0),         --期末库存数量
  cGoodsTypeno varchar(32),
  cGoodsTypeName varchar(64),
 --以下是期间进销存
  fQty_jxc_in money default(0),   --入库
  fMoney_jxc_in money default(0),
  fQty_jxc_out money default(0),  --出库
  fMoney_jxc_out money default(0),
  fSheetMoney_out money default(0),
  fQty_jxc_rbd money default(0),  --返厂
  fMoney_jxc_rbd money default(0),
  fSheetMoney_rbd money default(0),
  fQty_jxc_Return money default(0),   --客退
  fMoney_jxc_Return money default(0),
  fQty_jxc_Tfr money default(0),      --调拨出库
  fMoney_jxc_Tfr money default(0),
  fSheetMoney_Tfr money default(0),

  fQty_jxc_TfrIn money default(0),      --调拨入库
  fMoney_jxc_TfrIn money default(0),
  fSheetMoney_TfrIn money default(0),

  fQty_jxc_Lost money default(0),     --报损
  fMoney_jxc_Lost money default(0),
  fSheetMoney_Lost money default(0),
  fQty_jxc_Effusion money default(0), --报溢
  fMoney_jxc_Effusion money default(0),
  fQty_jxc_Pack money default(0),     --原料出库
  fMoney_jxc_Pack money default(0),
  fSheetMoney_Pack money default(0),
  fQty_jxc_Deliver money default(0),     --成品入库
  fMoney_jxc_Deliver money default(0),  
  fQty_jxc_sale money default(0),     --销售
  fMoney_jxc_sale money default(0),
  fSheetMoney_sale money default(0),  
  fQty_jxc_PdIn money default(0),     --盘点溢出
  fMoney_jxc_PdIn money default(0), 
  fQty_jxc_PdOut money default(0),     --盘点报损
  fMoney_jxc_PdOut money default(0),
  fSheetMoney_pdOut money default(0),

  fQty_jxc_PosIn money default(0),     --Pos销售退货入库数量
  fMoney_jxc_PosIn money default(0),
  fQtyIn_init money default(0),      --16系统初始化接收数量  
  fQtyOut_init money default(0),      --16系统初始化接收数量  
  fMoney_init money default(0),     --16系统初始化金额
  fMoneySale_init money default(0),--16系统初始化销售金额
  fCurNormalPrice money default(0)--按零售价核算

 ) 

insert into #FIFOCWhDate_chen
(
  cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,date1,date2
)
select cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,@dDate1,@dDate2
from t_goods
where 
isnull(bstorage,0)=1

/*
and(
     ( 
--        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)

        ( @Type=0 )
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cGoodsNo in (select distinct cGoodsNo from #tmpCostGoodsList)
				)
 
     )
      or
     ( 
--        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
        ( @Type=1 )
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cGoodsNo in 
				 (select distinct b.cGoodsNo from #tmpCostTypeList a,t_Goods b where a.cTypeNo=b.cGoodsTypeNO )
				)
     )
     or
     ( 
        --(@Type=2)and cSupNo in(select distinct cSupNo from #tmpCostSupList)
        (@Type=2)
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				)
				
     )
)

*/
and(
     ( 
--        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)

        ( @Type=0 )
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cGoodsNo in (select distinct cGoodsNo from #tmpCostGoodsList)
				)
 
     )
      or
     ( 
--        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
        ( @Type=1 )
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cGoodsNo in 
				 (select distinct b.cGoodsNo from #tmpCostTypeList a,t_Goods b where a.cTypeNo=b.cGoodsTypeNO )
				)
     )
     or
     ( 
        --(@Type=2)and cSupNo in(select distinct cSupNo from #tmpCostSupList)
        (@Type=2)
            /*
				and cGoodsNo in
				(select distinct cGoodsNo from t_WH_Form 
				 where cSupplierNo in (select distinct cSupNo from #tmpCostSupList)
				)
			*/
				and cGoodsNo in 
				(select cGoodsNo from t_Goods 
				 where cSupNo in (select distinct cSupNo from #tmpCostSupList)
				 )
				
     )
)

--起初入库数量
/*
select a.cGoodsNo,fQty_in=sum(isnull(b.fQty_in,0)),fMoney_In=sum(isnull(b.fMoney_In,0))
into #tmp_Date1In
from #FIFOCWhDate_chen a left join t_wh_form  b
on a.cGoodsNo=b.cGoodsNo and b.dDateTime<@dDate1
where b.cWhNo=@cWhNo
group by a.cGoodsNo 
*/
--print '1:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

select  cGoodsNo,cSupNO
into #FIFOCWhDate_chen_SingleMainSupplier
from #FIFOCWhDate_chen

	select a.cGoodsNo,b.fQty_in,b.fMoney_In,b.cSupplierNo 
  into #temp_Date1In_MultiSupplier
	from  #FIFOCWhDate_chen a left join t_wh_form  b
	on a.cGoodsNo=b.cGoodsNo and b.dDateTime<@dDate1
	where b.cWhNo=@cWhNo

	select a.cGoodsNo,b.fQty_in,b.fMoney_In,b.cSupplierNo 
  into #temp_MultiSupplier
	from  #FIFOCWhDate_chen a left join t_wh_form  b
	on a.cGoodsNo=b.cGoodsNo and b.dDateTime<=@dDate2
	where b.cWhNo=@cWhNo

--print '2:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

select x.cGoodsNo,x.cSupplierNo,fQty_in=sum(isnull(x.fQty_in,0)),fMoney_In=sum(isnull(x.fMoney_In,0))
into #tmp_Date1In
from #temp_Date1In_MultiSupplier x
group by x.cGoodsNo,x.cSupplierNo

select distinct a.cGoodsNo,a.cSupplierNo,cGoodsName=cast(null as varchar(64)),
cSupName=cast(null as varchar(64)),date1=@dDate1,date2=@dDate2--主供应商外的其它供应商
into #temp_otherSupplier
from
(
	select distinct cGoodsNo,cSupplierNo
	from #temp_MultiSupplier
) a left join #FIFOCWhDate_chen b on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNO
where b.cSupNO is null


update a
set a.cSupName=b.cSupName
from #temp_otherSupplier a,t_Supplier b
where a.cSupplierNo=b.cSupNo

update a
set a.cGoodsName=b.cGoodsName--,a.cUnit=b.cUnit,a.cSpec=b.cSpec
from #temp_otherSupplier a,t_Goods b
where a.cGoodsNo=b.cGoodsNo

insert into #FIFOCWhDate_chen(cGoodsNo,cGoodsName,cSupNO,cSupName,date1,date2)
select cGoodsNo,cGoodsName,cSupplierNo,cSupName,@dDate1,@dDate2  --插入主供应商外的其它供应商
from #temp_otherSupplier

delete from #FIFOCWhDate_chen
where @Type=2 and cSupNO not in (select distinct cSupNo from #tmpCostSupList)

--print '3:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

--起初入库数量
update a
set a.fQty_in_bgn=isnull(b.fQty_in,0),a.fMoney_in_bgn=isnull(b.fMoney_In,0)
from #FIFOCWhDate_chen a,#tmp_Date1In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

--起初出库数量
/*--       只能处理一品一商
select a.cGoodsNo,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
into #tmp_Date1Out
from #FIFOCWhDate_chen a left join t_Cost_distribute  b
on a.cGoodsNo=b.cGoodsNo and b.dDate_Sheet<@dDate1 and isnull(b.bDone,0)=0
where b.cWhNo=@cWhNo
group by a.cGoodsNo 
*/

--select a.cGoodsNo,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
select x.cGoodsNo,x.cSupplierNo,x.cSupplier,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale
into #tmp_Date1Out_List
from 
(select b.cGoodsNo,b.fQty_Cost,b.fMoney_Cost,b.fMoney_sale,c.cSupplierNo,c.cSupplier
 from	t_Cost_distribute  b left join t_WH_Form c 
 on  b.dDate_Sheet<@dDate1 and 
 b.cGoodsNo=c.cGoodsNo and b.iSerno=c.iSerno
 where b.dDate_Sheet<@dDate1
 and b.cGoodsNo in (select cGoodsNo from #FIFOCWhDate_chen_SingleMainSupplier) and  b.cWhNo=@cWhNo
  and isnull(b.bDone,0)=0	
) x

--print '4:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())


select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
into #tmp_Date1Out
from #tmp_Date1Out_List
group by cGoodsNo,cSupplierNo

update a
set a.fQty_Out_bgn=isnull(b.fQty_Out,0),a.fMoney_Out_bgn=isnull(b.fMoney_Out,0),fSheetMoney_Out_bgn=isnull(b.fSheetMoney,0)
from #FIFOCWhDate_chen a,#tmp_Date1Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

--期间接收数量
select b.cGoodsNo,b.cSupplierNo,b.iAttribute,fQty_in=sum(isnull(b.fQty_in,0)),
fMoney_In=sum(isnull(b.fMoney_In,0)),fMoney_TrfIn=sum(isnull(b.fQty_in*b.fPrice_Tran,0))
into #tmp_PeriodJxcIn
from t_wh_form  b  
where b.dDateTime between @dDate1 and @dDate2 and isnull(b.fQty_in,0)<>0
and b.iAttribute is not null
and b.cWhNo=@cWhNo and b.cGoodsNo in (select cGoodsNo from #FIFOCWhDate_chen_SingleMainSupplier)
group by b.cGoodsNo,b.cSupplierNo,b.iAttribute

--print '5:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

--期间发出数量
select x.cGoodsNo,x.cSupplierNo,x.iAttribute,x.bdone,fQty_Out=x.fQty_Cost,fMoney_Out=x.fMoney_Cost,fSheetMoney=x.fMoney_sale
into #tmp_PeriodOut_List
from 
(select b.cGoodsNo,b.iAttribute,b.bdone,b.fQty_Cost,b.fMoney_Cost,b.fMoney_sale,c.cSupplierNo
 from	t_Cost_distribute  b 
 left join t_WH_Form c on b.cGoodsNo=c.cGoodsNo and b.iSerno=c.iSerno
 where b.dDate_Sheet between  @dDate1 and @dDate2
 and b.cGoodsNo in 
 (select cGoodsNo from #FIFOCWhDate_chen_SingleMainSupplier) and  b.cWhNo=@cWhNo
  and isnull(b.bDone,0)=0	and b.iAttribute is not null
) x

--print '6:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())


select cGoodsNo,cSupplierNo,iAttribute,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
into #tmp_PeriodJxcOut
from #tmp_PeriodOut_List
group by cGoodsNo,cSupplierNo,iAttribute


/*
select a.cGoodsNo,b.iAttribute,fQty_Out=sum(isnull(b.fQty_Cost,0)),fMoney_Out=sum(isnull(b.fMoney_Cost,0)),fSheetMoney=sum(isnull(b.fMoney_sale,0))
into #tmp_PeriodJxcOut
from #FIFOCWhDate_chen a left join t_Cost_distribute  b
on a.cGoodsNo=b.cGoodsNo and b.dDate_Sheet between  @dDate1 and @dDate2 and isnull(b.bDone,0)=0
where b.iAttribute is not null
and b.cWhNo=@cWhNo
group by a.cGoodsNo,b.iAttribute
*/

--期间入库
update a
set a.fQty_jxc_in=b.fQty_in,
    a.fMoney_jxc_in=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=0

--调拨入库
/*
  fQty_jxc_TfrIn money default(0),      --调拨入库
  fMoney_jxc_TfrIn money default(0),
  fSheetMoney_TfrIn money default(0),
*/
update a
set a.fQty_jxc_TfrIn=b.fQty_in,
    a.fMoney_jxc_TfrIn=b.fMoney_in,
    a.fSheetMoney_TfrIn=b.fMoney_TrfIn

from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=31



--期间出库
update a
set a.fQty_jxc_out=b.fQty_Out,
    a.fMoney_jxc_out=b.fMoney_Out,
    a.fSheetMoney_Out=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=1

--期间返厂
update a
set a.fQty_jxc_rbd=b.fQty_Out,
    a.fMoney_jxc_rbd=b.fMoney_Out,
    a.fSheetMoney_rbd=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=2

--期间客退
update a
set a.fQty_jxc_Return=b.fQty_in,
    a.fMoney_jxc_Return=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=3

--期间调拨入库
update a
set a.fQty_jxc_TfrIn=b.fQty_In,
    a.fMoney_jxc_TfrIn=b.fMoney_In
    ,a.fSheetMoney_TfrIn=b.fMoney_TrfIn--仓库间调拨金额
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=31


--期间调拨出库
update a
set a.fQty_jxc_Tfr=b.fQty_Out,
    a.fMoney_jxc_Tfr=b.fMoney_Out,
    a.fSheetMoney_Tfr=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=4

--期间报损
update a
set a.fQty_jxc_Lost=b.fQty_Out,
    a.fMoney_jxc_Lost=b.fMoney_Out,
    a.fSheetMoney_Lost=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=5

--期间报溢
update a
set a.fQty_jxc_Effusion=b.fQty_in,
    a.fMoney_jxc_Effusion=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=6

--期间原料出库
update a
set a.fQty_jxc_Pack=b.fQty_Out,
    a.fMoney_jxc_Pack=b.fMoney_Out,
    a.fSheetMoney_Pack=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=8

--期间成品入库
update a
set a.fQty_jxc_Deliver=b.fQty_in,
    a.fMoney_jxc_Deliver=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=9

--期间销售
update a
set a.fQty_jxc_sale=b.fQty_Out,
    a.fMoney_jxc_sale=b.fMoney_Out,
    a.fSheetMoney_Sale=b.fSheetMoney
from #FIFOCWhDate_chen a,
(select cGoodsNo,iAttribute,fQty_Out=sum(isnull(fQty_Out,0)),
fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
from #tmp_PeriodJxcOut
group by cGoodsNo,iAttribute
) b
where a.cGoodsNo=b.cGoodsNo --and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=10


--期间盘点溢出
update a
set a.fQty_jxc_PdIn=b.fQty_in,
    a.fMoney_jxc_PdIn=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=11

--期间盘点报损
update a
set a.fQty_jxc_PdOut=b.fQty_Out,
    a.fMoney_jxc_PdOut=b.fMoney_Out,
    a.fSheetMoney_PdOut=b.fSheetMoney
from #FIFOCWhDate_chen a,#tmp_PeriodJxcOut b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=12

--期间Pos客退
update a
set a.fQty_jxc_PosIn=b.fQty_in,
    a.fMoney_jxc_PosIn=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_PeriodJxcIn b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
and isnull(b.iAttribute,1000)=13

select cGoodsNo,cSupplierNo,fQty_in=sum(isnull(fQty_in,0)),fMoney_in=sum(isnull(fMoney_in,0))
into #tmp_Date2In
from #tmp_PeriodJxcIn
group by cGoodsNo,cSupplierNo
select cGoodsNo,cSupplierNo,fQty_Out=sum(isnull(fQty_Out,0)),fMoney_Out=sum(isnull(fMoney_Out,0)),fSheetMoney=sum(isnull(fSheetMoney,0))
into #tmp_Date2Out
from #tmp_PeriodJxcOut
group by cGoodsNo,cSupplierNo

update a
set a.fQty_in_period=b.fQty_in,a.fMoney_in_period=b.fMoney_in
from #FIFOCWhDate_chen a,#tmp_Date2In b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo
update a
set a.fQty_Out_period=b.fQty_Out,a.fMoney_Out_period=b.fMoney_Out
from #FIFOCWhDate_chen a,#tmp_Date2Out b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

--起初期末库存数
update #FIFOCWhDate_chen
set fQty_bgn=isnull(fQty_in_bgn,0)-isnull(fQty_Out_bgn,0),
    fMoney_bgn=isnull(fMoney_in_bgn,0)-isnull(fMoney_out_bgn,0),
    fQty_period=isnull(fQty_in_period,0)-isnull(fQty_Out_period,0),
    fMoney_period=isnull(fMoney_in_period,0)-isnull(fMoney_out_period,0)
update #FIFOCWhDate_chen
set fQty=isnull(fQty_bgn,0)+isnull(fQty_Period,0),
    fMoney=isnull(fMoney_period,0)+isnull(fMoney_bgn,0)

--系统初始化数量
/*
select a.cGoodsNo,fQtyIn=sum(isnull(a.fQty_in,0)),fQtyOut=sum(isnull(b.fQty_Cost,0)),
fMoney_init=sum(isnull(a.fmoney_in,0))-sum(isnull(b.fmoney_Cost,0)),fMoney_sale=sum(isnull(b.fMoney_sale,0))
into #tmpSysInit
from t_wh_form a left join t_Cost_distribute b
on a.iserno=b.iserno and a.cgoodsno=b.cgoodsno and isnull(b.bDone,0)=0 and b.dDate_Sheet<=@dDate2
and isnull(a.iAttribute,99)=16 and isnull(b.iAttribute,99)=16
where isnull(a.iAttribute,99)=16 and a.dDateTime<=@dDate2   --'@dDate2'
group by a.cgoodsno
*/

select cGoodsNo,cSupplierNo,fQtyIn=sum(isnull(fQty_in,0)),fMoney_init=sum(isnull(fmoney_in,0))
into #tmpSysInit1
from t_wh_form 
where isnull(iAttribute,99)=16
and cWhNo=@cWhNo
group by cGoodsNo,cSupplierNo

--print '7:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())

select a.cGoodsNo,b.cSupplierNo,fQtyOut=sum(isnull(a.fQty_Cost,0)),fMoney_cost=sum(isnull(a.fmoney_Cost,0)),fMoney_sale=sum(isnull(a.fMoney_sale,0))
into #tmpSysInit2
from t_Cost_distribute a left join t_wh_form b on a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno
where isnull(a.iAttribute,99)=16 and isnull(bDone,0)=0
and a.cWhNo=@cWhNo
group by a.cGoodsNo,b.cSupplierNo

--print '8:'+dbo.getdaystr(getdate())+' '+datename(hh,getdate())+':'+datename(n,getdate())+':'+datename(s,getdate())


select a.cGoodsNo,a.cSupplierNo,fQtyIn_init=isnull(a.fQtyIn,0),fQtyOut_init=isnull(b.fQtyOut,0),
fMoney_init=isnull(a.fMoney_init,0)-isnull(b.fMoney_cost,0),fMoneySale_init=isnull(b.fMoney_sale,0)
into #tmpSysInit
from #tmpSysInit1 a left join #tmpSysInit2 b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

update a
set fQtyIn_init=b.fQtyIn_init,fQtyOut_init=b.fQtyOut_init,fMoney_init=b.fMoney_init,fMoneySale_init=b.fMoneySale_init
from #FIFOCWhDate_chen a,#tmpSysInit b
where a.cGoodsNo=b.cGoodsNo and a.cSupNO=b.cSupplierNo

update a
set a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.cGoodsTypeNo=b.cGoodsTypeNo,a.cGoodsTypeName=b.cGoodsTypeName,
a.fCurNormalPrice=b.fNormalPrice
from #FIFOCWhDate_chen a,t_Goods b
where a.cGoodsNo=b.cGoodsNo

select cGoodsNo,cGoodsName,date1,date2,fQty_in_bgn,fMoney_in_bgn,fQty_out_bgn,fMOney_out_bgn,fQty_bgn,fMOney_bgn, 
fQty_in_period,fMoney_in_period,fQty_out_period,fMOney_out_period,fQty_period,fMOney_period,cSupNo,cSupName,
cUnit,cSpec,fQty,fMoney,cGoodsTypeno,cGoodsTypeName,
fSheetMoney_Out_bgn,
fQty_jxc_in,fMoney_jxc_in,
fQty_jxc_out,fMoney_jxc_out,fSheetMoney_Out,
fQty_jxc_rbd,fMoney_jxc_rbd,fSheetMoney_Rbd,
fQty_jxc_Return,fMoney_jxc_Return,
fQty_jxc_Tfr,fMoney_jxc_Tfr,fSheetMoney_Tfr,
fQty_jxc_TfrIn,fMoney_jxc_TfrIn,fSheetMoney_TfrIn,
fQty_jxc_Lost,fMoney_jxc_Lost,fSheetMoney_Lost,
fQty_jxc_Effusion,fMoney_jxc_Effusion,
fQty_jxc_Pack,fMoney_jxc_Pack,fSheetMoney_Pack,
fQty_jxc_Deliver,fMoney_jxc_Deliver,
fQty_jxc_sale,fMoney_jxc_sale,fSheetMoney_sale,
fQty_jxc_PdIn,fMoney_jxc_PdIn,
fQty_jxc_PdOut,fMoney_jxc_PdOut,fSheetMoney_PdOut,
fQty_jxc_PosIn,fMoney_jxc_PosIn,
fQtyIn_init,fQtyOut_init,fMoney_init,fMoneySale_init,
iserno=0,fCurNormalPrice,fMoney_CurNormalPrice=isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0),

fMoney_CurNormalPrice_End=isnull(fCurNormalPrice,0)*isnull(fQty,0)
from #FIFOCWhDate_chen
union all
select cGoodsNo,cGoodsName='小计：',date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,
sum(fSheetMoney_Out_bgn),
sum(fQty_jxc_in),sum(fMoney_jxc_in),
sum(fQty_jxc_out),sum(fMoney_jxc_out),sum(fSheetMoney_Out),
sum(fQty_jxc_rbd),sum(fMoney_jxc_rbd),sum(fSheetMoney_Rbd),
sum(fQty_jxc_Return),sum(fMoney_jxc_Return),
sum(fQty_jxc_Tfr),sum(fMoney_jxc_Tfr),sum(fSheetMoney_Tfr),
sum(fQty_jxc_TfrIn),sum(fMoney_jxc_TfrIn),sum(fSheetMoney_TfrIn),
sum(fQty_jxc_Lost),sum(fMoney_jxc_Lost),sum(fSheetMoney_Lost),
sum(fQty_jxc_Effusion),sum(fMoney_jxc_Effusion),
sum(fQty_jxc_Pack),sum(fMoney_jxc_Pack),sum(fSheetMoney_Pack),
sum(fQty_jxc_Deliver),sum(fMoney_jxc_Deliver),
sum(fQty_jxc_sale),sum(fMoney_jxc_sale),sum(fSheetMoney_sale),
sum(fQty_jxc_PdIn),sum(fMoney_jxc_PdIn),
sum(fQty_jxc_PdOut),sum(fMoney_jxc_PdOut),sum(fSheetMoney_PdOut),
sum(fQty_jxc_PosIn),sum(fMoney_jxc_PosIn),
sum(fQtyIn_init),sum(fQtyOut_init),sum(fMoney_init),sum(fMoneySale_init),
iserno=2,fCurNormalPrice=null,
fMoney_CurNormalPrice=sum(isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0)),
fMoney_CurNormalPrice_End=sum(isnull(fCurNormalPrice,0)*isnull(fQty,0))
from #FIFOCWhDate_chen
group by cGoodsNo
union all
select '合计：',null,date1=@ddate1,date2=@ddate2,sum(fQty_in_bgn),sum(fMoney_in_bgn),sum(fQty_out_bgn),sum(fMOney_out_bgn),sum(fQty_bgn),sum(fMOney_bgn), 
sum(fQty_in_period),sum(fMoney_in_period),sum(fQty_out_period),sum(fMOney_out_period),sum(fQty_period),sum(fMOney_period),null,null,
null,null,sum(fQty),sum(fMoney),null,null,
sum(fSheetMoney_Out_bgn),
sum(fQty_jxc_in),sum(fMoney_jxc_in),
sum(fQty_jxc_out),sum(fMoney_jxc_out),sum(fSheetMoney_Out),
sum(fQty_jxc_rbd),sum(fMoney_jxc_rbd),sum(fSheetMoney_Rbd),
sum(fQty_jxc_Return),sum(fMoney_jxc_Return),
sum(fQty_jxc_Tfr),sum(fMoney_jxc_Tfr),sum(fSheetMoney_Tfr),
sum(fQty_jxc_TfrIn),sum(fMoney_jxc_TfrIn),sum(fSheetMoney_TfrIn),
sum(fQty_jxc_Lost),sum(fMoney_jxc_Lost),sum(fSheetMoney_Lost),
sum(fQty_jxc_Effusion),sum(fMoney_jxc_Effusion),
sum(fQty_jxc_Pack),sum(fMoney_jxc_Pack),sum(fSheetMoney_Pack),
sum(fQty_jxc_Deliver),sum(fMoney_jxc_Deliver),
sum(fQty_jxc_sale),sum(fMoney_jxc_sale),sum(fSheetMoney_sale),
sum(fQty_jxc_PdIn),sum(fMoney_jxc_PdIn),
sum(fQty_jxc_PdOut),sum(fMoney_jxc_PdOut),sum(fSheetMoney_PdOut),
sum(fQty_jxc_PosIn),sum(fMoney_jxc_PosIn),
sum(fQtyIn_init),sum(fQtyOut_init),sum(fMoney_init),sum(fMoneySale_init),
iserno=9,fCurNormalPrice=null,fMoney_CurNormalPrice=sum(isnull(fCurNormalPrice,0)*isnull(fQty_in_period,0)),
fMoney_CurNormalPrice_End=sum(isnull(fCurNormalPrice,0)*isnull(fQty,0))
from #FIFOCWhDate_chen
order by cgoodsno,iserno


GO
