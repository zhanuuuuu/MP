/*
select dbo.[f_cStoreOutPcSerNo]('2016-12-3','1002')
 */
CREATE      function [dbo].[f_cStoreOutPcSerNo]
(@dDate datetime,@cStoreNo varchar(16)) returns varchar(32)
as
begin

    declare @cMaxSerno varchar(32)
    declare @cSheetNo varchar(32)
    select @cMaxSerno=MAX(cOutSerNo),@cSheetNo=MAX(cSheetno)
	from wh_cStoreOutWarehouse
	where dDate>@dDate-15 and cCustomerNo=@cStoreNo
	and ISNULL(cOutSerNo,'')<>''
	and ISNULL(bShip,0)=0
	and ISNULL(bfresh,0)=0
	--where dDate=@dDate and cCustomerNo=@cStoreNo
 
	declare @YYYY varchar(8)
	declare @MM varchar(8)
	declare @DD varchar(8)
	set @YYYY=datename(YYYY,@dDate)
	set @MM=datename(MM,@dDate)
	set @DD=datename(DD,@dDate)
	
	if LEN(@MM)=1 
	begin
	  set @MM='0'+@MM
	end
	if LEN(@DD)=1 
	begin
	 set @DD='0'+@DD
	end
	 
   if @cMaxSerno is null 
   begin
        declare @cMaxSerno_01 varchar(32)
		declare @cSheetNo_01 varchar(32)
		select @cMaxSerno_01=MAX(cOutSerNo) 
		from wh_cStoreOutWarehouse
		where dDate=@dDate and cCustomerNo=@cStoreNo 
		and ISNULL(bShip,0)=0
	    and ISNULL(bfresh,0)=0
		
		if @cMaxSerno_01 is null
		begin
		   set @cMaxSerno=@YYYY+@MM+@DD+@cStoreNo+'-'+'001' 
		end else
		begin		     
		     set @cMaxSerno_01=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno_01,3) as int)+1 as varchar(10))))
			 --set @i=0 
			 while len(@cMaxSerno_01)<3
			 begin
			   set @cMaxSerno_01='0'+@cMaxSerno_01     
			 end
			 set @cMaxSerno=@YYYY+@MM+@DD+@cStoreNo+'-'+@cMaxSerno_01			 
		end		  
   end 
   
   return @cMaxSerno
    
   
   
end
GO
