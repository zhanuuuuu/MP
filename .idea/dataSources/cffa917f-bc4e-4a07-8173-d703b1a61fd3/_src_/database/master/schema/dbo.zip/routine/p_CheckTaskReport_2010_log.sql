--select cGoodsTypeno into #tmp_GoodsTypeList2010 from t_GoodsType

--select * from #tmp_GoodsTypeList2010

--p_CheckTaskReport_2010  '2010-12-27'
CREATE proc [dbo].[p_CheckTaskReport_2010_log]
@cStoreNo varchar(32),
@date datetime
as
--declare @date datetime
--set @date='2010-12-27'

if (select OBJECT_ID('tempdb..#tmp_GoodsCheckList2010'))is not null
drop table #tmp_GoodsCheckList2010
select c.cCheckTaskNo,c.cCheckTask,b.cGoodsTypeno,b.cGoodsTypename,
a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cUnit,a.cSpec,b.fNormalPrice,
a.fQuantity_Sys,a.fQuantity_Check,a.fQuantity_Diff,a.fInPrice_Avg,a.fMoney_Diff,
a.Qty_Begin,a.Qty_InWh,a.Qty_RetWh,a.Qty_EffusionWh,a.Qty_OutWh,a.Qty_TfrWh,
a.Qty_RbdWh,a.Qty_Exchange,a.Qty_LossWh,a.Qty_Sale,
fMoney_check=ISNULL(a.fQuantity_Check,0)*ISNULL(a.fInPrice_Avg,0),
a.fMoney_CurSale
into #tmp_GoodsCheckList2010
from t_CheckTast_GoodsDetail_log a,t_goods b,t_CheckTast c,#tmp_GoodsTypeList2010 d
where a.cGoodsNo=b.cGoodsNo and a.cCheckTaskNo=c.cCheckTaskNo
and b.cGoodsTypeno=d.cgoodsTypeNo and c.cStoreNo=@cStoreNo
and c.dCheckTask=@date
order by c.cCheckTaskNo,b.cGoodsTypeno,a.cGoodsNo

select cCheckTaskNo,cCheckTask=cCheckTaskNo+cCheckTask,cGoodsTypeno,cGoodsTypename,
cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,fNormalPrice,
fQuantity_Sys,fQuantity_Check,fQuantity_Diff,fInPrice_Avg,fMoney_Diff,
Qty_Begin,Qty_InWh,Qty_RetWh,Qty_EffusionWh,Qty_OutWh,Qty_TfrWh,
Qty_RbdWh,Qty_Exchange,Qty_LossWh,Qty_Sale,iserno=0,fMoney_check,
fMoney_CurSale
from #tmp_GoodsCheckList2010
union all
select cCheckTaskNo,cCheckTask=cCheckTaskNo+'类别小计',cGoodsTypeno,cGoodsTypename=null,
cGoodsNo=null,cGoodsName=null,cBarCode=null,cUnit=null,cSpec=null,fNormalPrice=null,
fQuantity_Sys=SUM(fQuantity_Sys),fQuantity_Check=SUM(fQuantity_Check),
fQuantity_Diff=SUM(fQuantity_Diff),fInPrice_Avg=null,fMoney_Diff=SUM(fMoney_Diff),
Qty_Begin=SUM(Qty_Begin),Qty_InWh=SUM(Qty_InWh),Qty_RetWh=SUM(Qty_RetWh),
Qty_EffusionWh=SUM(Qty_EffusionWh),Qty_OutWh=SUM(Qty_OutWh),
Qty_TfrWh=SUM(Qty_TfrWh),Qty_RbdWh=SUM(Qty_RbdWh),Qty_Exchange=SUM(Qty_Exchange),
Qty_LossWh=SUM(Qty_LossWh),Qty_Sale=SUM(Qty_Sale),iserno=1,fMoney_check=SUM(fMoney_check),
fMoney_CurSale=SUM(fMoney_CurSale)
from #tmp_GoodsCheckList2010
group by cCheckTaskNo,cGoodsTypeno
union all
select cCheckTaskNo,cCheckTask=cCheckTaskNo+'任务合计',cGoodsTypeno='z',cGoodsTypename=null,
cGoodsNo=null,cGoodsName=null,cBarCode=null,cUnit=null,cSpec=null,fNormalPrice=null,
fQuantity_Sys=SUM(fQuantity_Sys),fQuantity_Check=SUM(fQuantity_Check),
fQuantity_Diff=SUM(fQuantity_Diff),fInPrice_Avg=null,fMoney_Diff=SUM(fMoney_Diff),
Qty_Begin=SUM(Qty_Begin),Qty_InWh=SUM(Qty_InWh),Qty_RetWh=SUM(Qty_RetWh),
Qty_EffusionWh=SUM(Qty_EffusionWh),Qty_OutWh=SUM(Qty_OutWh),
Qty_TfrWh=SUM(Qty_TfrWh),Qty_RbdWh=SUM(Qty_RbdWh),Qty_Exchange=SUM(Qty_Exchange),
Qty_LossWh=SUM(Qty_LossWh),Qty_Sale=SUM(Qty_Sale),iserno=2,fMoney_check=SUM(fMoney_check),
fMoney_CurSale=SUM(fMoney_CurSale)
from #tmp_GoodsCheckList2010
group by cCheckTaskNo
union all
select cCheckTaskNo='总计',cCheckTask='任务总计',cGoodsTypeno='z',cGoodsTypename=null,
cGoodsNo=null,cGoodsName=null,cBarCode=null,cUnit=null,cSpec=null,fNormalPrice=null,
fQuantity_Sys=SUM(fQuantity_Sys),fQuantity_Check=SUM(fQuantity_Check),
fQuantity_Diff=SUM(fQuantity_Diff),fInPrice_Avg=null,fMoney_Diff=SUM(fMoney_Diff),
Qty_Begin=SUM(Qty_Begin),Qty_InWh=SUM(Qty_InWh),Qty_RetWh=SUM(Qty_RetWh),
Qty_EffusionWh=SUM(Qty_EffusionWh),Qty_OutWh=SUM(Qty_OutWh),
Qty_TfrWh=SUM(Qty_TfrWh),Qty_RbdWh=SUM(Qty_RbdWh),Qty_Exchange=SUM(Qty_Exchange),
Qty_LossWh=SUM(Qty_LossWh),Qty_Sale=SUM(Qty_Sale),iserno=3,fMoney_check=SUM(fMoney_check),
fMoney_CurSale=SUM(fMoney_CurSale)
from #tmp_GoodsCheckList2010

order by cCheckTaskNo,cGoodsTypeno,iserno


GO
