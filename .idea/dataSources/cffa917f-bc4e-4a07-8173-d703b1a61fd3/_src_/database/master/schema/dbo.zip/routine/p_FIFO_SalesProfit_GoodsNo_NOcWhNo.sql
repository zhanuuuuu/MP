/*
--原来毛利脚本
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods 
exec p_FIFO_SalesProfit_GoodsNo
'2012-01-01','2012-01-01','01'
*/
/*按商品信息查毛利*/
create procedure [dbo].[p_FIFO_SalesProfit_GoodsNo_NOcWhNo]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）
--declare @dDate1 datetime,@dDate2 datetime,@cWHno varchar(32)
--set @dDate1='2012-01-01' set @dDate2='2012-01-01' set @cWHno='01'
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods where cGoodsNo is not null and cSupNo='81019'

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2 

if (select OBJECT_ID('tempdb..#FindGoodsList0'))is not null drop table #FindGoodsList0
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #FindGoodsList0
from t_goods a,#temp_Goods  b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1
--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#tmpCostGoodsList1'))is not null drop table #tmpCostGoodsList1

select cGoodsNO
into #tmpCostGoodsList1
from #temp_Goods
union all
select cGoodsNo_MinPackage
from #FindGoodsList0
where ISNULL(bIsPack,0)=1
union all
select b.cGoodsNo
from #FindGoodsList0 a,t_goods b
where ISNULL(a.bIsPack,0)=0
and a.cGoodsNo=b.cGoodsNo_minPackage

if (select OBJECT_ID('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select distinct cGoodsNo into #tmpCostGoodsList
from #tmpCostGoodsList1 where isnull(cGoodsNo,'')<>'' 
drop table #tmpCostGoodsList1

	/*注意一品多商的情况*/
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,--销售数量
   fLastSettle money,--卖价
   fMoneyCost money,--进价
   fMoneyRatio money,--毛利
   fRatio money, --毛利率
   bAuditing int
)
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE [#temp_begin](ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)
CREATE TABLE [#temp_end]  (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime,@date_ForBgn datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='''+@cWHno+''''
insert into #temp_date exec (@SQLstr)
select @date=MaxDate from #temp_date
set @date=isnull(@date,'2000-01-01')

--如果超出，则分段查询@dDateBgn---@date(MaxDate),   @date1--@date2(@dDateEnd)

if(@date>=(@dDateBgn-1))
	begin
		if (@date<@dDateEnd)    
			begin
					set @date1=@date+1
					set @date2=@dDateEnd
			end
		else
			begin
					set @date1='2000-01-01'
					set @date2='2000-01-01'
					set @date=@dDateEnd
			end
	end
else
	begin 
		set @date1=@dDateBgn
		set @date2=@dDateEnd 
	end
set @date_ForBgn=@dDateBgn-1
if @date_ForBgn>@date set @date_ForBgn=@date
-----查最大结转时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin(ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='Bgn',dDateTime=@dDateBgn,cGoodsNo,@cWhNo from #tmpCostGoodsList
insert into #temp_end  (ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='End',dDateTime=@dDateEnd,cGoodsNo,@cWhNo from #tmpCostGoodsList

set @SQLstr=' update a set 
							a.fQuantity=b.fQuantity,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
							
							a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
							a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
							a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all,
							a.fPrice_Avg=b.fPrice_Avg,a.Ratio=b.Ratio,
							a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
							from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date_ForBgn)+''' and b.cWHno='''+@cWHno+'''
             '
set @SQLstr1='update a set 
							a.fQuantity=b.fQuantity,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
							
							a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
							a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
							a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all,
							a.fPrice_Avg=b.fPrice_Avg,a.Ratio=b.Ratio,
							a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
							from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='''+@cWHno+'''
            '
exec (@SQLstr+@SQLstr1)
insert into #GetGoodsListFormBase
(	cGoodsNo,bAuditing )
select cGoodsNo,0 from #tmpCostGoodsList
union all
select cGoodsNo,1 from #tmpCostGoodsList
-------------查超出部分
if (@date<@date2)    
begin 
      if (select OBJECT_ID('tempdb..#temp_goodsForSelect'))is not null drop table #temp_goodsForSelect
      if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_p'))is not null drop table #GetGoodsListFormBase_p
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_R'))is not null drop table #GetGoodsListFormBase_R
      select distinct cGoodsNo  into #temp_goodsForSelect from #tmpCostGoodsList
      
	  select dSaleTime=b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing
      into #t_SaleSheetDetail_shelf
      from #temp_goodsForSelect a, t_SaleSheetDetail b
      where (b.dSaleDate between @date1 and @date2) and a.cGoodsNo=b.cGoodsNo and b.cWHno=@cWHno 
      union all
      select c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0'
      from #temp_goodsForSelect a,WH_ReturnGoodsDetail b,WH_ReturnGoods c
      where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @date1 and @date2)
            and c.cWHno=@cWHno 
            
      /*---包装转单品*/
			if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
			select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
			into #tmpPackGoodsList
			from t_goods
			where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

			update a
			set a.cGoodsNo=b.cGoodsNo_MinPackage,
					a.fQuantity=a.fQuantity*b.fQty_minPackage
			from #t_SaleSheetDetail_shelf a, #tmpPackGoodsList b
			where a.cGoodsNO=b.cGoodsNO
---销售数量

      select dSaleTime=@dDate1,a.cGoodsNo,a.bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
             fMoneyCost=cast(0 as money),fMoneyRatio=cast(0 as money),fRatio=cast(0 as money),
             cSupno=CAST(null as varchar(32))
      into #GetGoodsListFormBase_p 
      from (
						select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0))
						from #t_SaleSheetDetail_shelf 
						where dSaleTime between @date1 and @date2
						group by cGoodsNo,bAuditing
           ) a
      group by a.cGoodsNo,a.bAuditing
      
      update a set a.cSupno=b.cSupNo
      from #GetGoodsListFormBase_p a,t_goods b
      where a.cGoodsNo=b.cGoodsNo
--获取供应商最小扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select a.guizuno,a.fRatio
			from t_Supplier_Contract_Ratio a,
			(
				 select guizuno,fMoney1=MIN(fMoney1)
				 from t_Supplier_Contract_Ratio 
				 where isnull(fRatio,0)<>0
				 group by guizuno
			 )b
			where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
	  ) b
	  where a.cSupno=b.guizuno
			
--获取t_goods表扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,fRatio
			from t_goods 
			where isnull(fRatio,0)<>0
	  ) b
	  where a.cGoodsNo=b.cGoodsNo
			
--策略扣率
      update a  
	  set a.fRatio=b.fSupRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
			from t_PloyOfSale
			where (
								(dDateStart between @date1 and @date2)
								or 
								(dDateEnd  between @date1 and @date2)
						)and isnull(fSupRatio,0)<>0
			group by cGoodsNo,dDateStart,dDateEnd
	  ) b
      where a.cGoodsNo=b.cGoodsNo and a.dSaleTime between b.dDateStart and b.dDateEnd 
      and isnull(a.bAuditing,0)=1
	
	/*
	  update a ---不管库存
	  set a.fMoneyRatio=a.fLastSettle*(1-a.fRatio/100.00)
	  from #GetGoodsListFormBase_p a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0
	  
	  update a ---管库存
	  set a.fMoneyRatio=a.fLastSettle*(1-a.fRatio/100.00)+a.fLastSettle-a.fMoneyCost
	  from #GetGoodsListFormBase_p a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
	*/
	  select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
		   fMoneyCost=sum(isnull(fMoneyCost,0)),
		   fMoneyRatio=sum(isnull(fMoneyRatio,0)),fRatio=avg(isnull(fRatio,0))
	  into #GetGoodsListFormBase_R
	  from #GetGoodsListFormBase_p 
	  group by cGoodsNo,bAuditing
	  
	  drop table #GetGoodsListFormBase_p
--销售成本 
/*
	  select cGoodsNo,fPrice_Avg from #temp_end
*/			
      ---平均价
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg0'))is not null drop table #temp_fPrice_Avg0
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg'))is not null drop table #temp_fPrice_Avg
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(c.fCKPrice,0)=0 then c.fNormalPrice else c.fCKPrice end
      into #temp_fPrice_Avg0
      from #GetGoodsListFormBase a left join t_goods c
      on a.cGoodsNo=c.cGoodsNo
      
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(b.fPrice_Avg,0)=0 then a.fPrice_Avg else b.fPrice_Avg end
      into #temp_fPrice_Avg
      from #temp_fPrice_Avg0 a left join #temp_end b
      on a.cGoodsNo=b.cGoodsNo 
      --select * from #temp_fPrice_Avg where fPrice_Avg is null
	  update a
	  set a.fMoneyCost=isnull(a.fQuantity,0)*b.fPrice_Avg
	  from #GetGoodsListFormBase_R a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo
	  --select * from #GetGoodsListFormBase_R
	  
	  ------扣点
	  update a ---不管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00),
	      a.fMoneyCost=isnull(a.fLastSettle,0)*(1-a.fRatio/100.00)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0
	  
	  update a ---管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00)+isnull(a.fLastSettle,0)-isnull(a.fMoneyCost,0)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
	  --更新到基础表#GetGoodsListFormBase中
	  update a
	  set a.fQuantity=isnull(b.fQuantity,0),a.fLastSettle=isnull(b.fLastSettle,0),
		a.fMoneyCost=isnull(b.fMoneyCost,0),
		a.fMoneyRatio=isnull(b.fMoneyRatio,0),a.fRatio=isnull(b.fRatio,0)
	  from #GetGoodsListFormBase a,#GetGoodsListFormBase_R b
	  where a.cGoodsNo=b.cGoodsNo and a.bAuditing=isnull(b.bAuditing,0)
	  
	  drop table #GetGoodsListFormBase_R

	  update a
	  set a.cSupNO=case when isnull(a.cSupNO,'')='' then b.cSupNo else a.cSupNO end,
	      a.cGoodsTypeNo=b.cGoodsTypeno,a.cGoodsTypeName=b.cGoodsTypename
	  from #GetGoodsListFormBase a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo
/*
	  select SUM(fLastSettle),SUM(fMoneyRatio),SUM(isnull(fMoneyCost,0)) 
	  from #GetGoodsListFormBase a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
	  
	  select SUM(fLastSettle),SUM(fMoneyRatio),SUM(isnull(fMoneyCost,0)) 
	  from #GetGoodsListFormBase a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0
*/
end
--以上获得期初期末库存
if (select object_id('tempdb..#GetGoodsListFormBase1'))is not null drop table #GetGoodsListFormBase1 --未超出
if (select object_id('tempdb..#GetGoodsListFormBase1_SelectIn'))is not null drop table #GetGoodsListFormBase1_SelectIn
select  
a.cGoodsNo,a.cSupNo,
fQuantity0=-isnull(a.total_Sale0,0)+isnull(b.total_Sale0,0)-isnull(a.total_Return,0)+isnull(b.total_Return,0),
fQuantity1=-isnull(a.total_Sale1,0)+isnull(b.total_Sale1,0),
fLastSettle0=-isnull(a.fMoney_Sale0_all,0)+isnull(b.fMoney_Sale0_all,0)-isnull(a.fMoney_Return_all,0)+isnull(b.fMoney_Return_all,0),
fLastSettle1=-isnull(a.fMoney_Sale1_all,0)+isnull(b.fMoney_Sale1_all,0),
fMoneyRatio=-(ISNULL(a.Ratio_Money_all,0)-ISNULL(b.Ratio_Money_all,0)),
fMoney_Cost=ISNULL(a.fMoney_all,0)-isnull(b.fMoney_all,0)--只有管库存商品的成本
into #GetGoodsListFormBase1
from #temp_end a left join #temp_begin b 
on a.cGoodsNo=b.cGoodsNo

--select a.cGoodsNo,b.cSupNo,b.fQuantity0,b.fQuantity1,b.fLastSettle0,b.fLastSettle1,
--       fMoneyRatio=b.fLastSettle1-b.fMoneyRatio,b.fMoney_Cost
--into #GetGoodsListFormBase1_SelectIn --------只选择需要查询商品
--from #tmpCostGoodsList a,#GetGoodsListFormBase1 b
--where a.cGoodsNo=b.cGoodsNo

select a.cGoodsNo,b.cSupNo,b.fQuantity0,b.fQuantity1,b.fLastSettle0,b.fLastSettle1,b.fMoneyRatio,b.fMoney_Cost
into #GetGoodsListFormBase1_SelectIn --------只选择需要查询商品
from #tmpCostGoodsList a,#GetGoodsListFormBase1 b
where a.cGoodsNo=b.cGoodsNo
--select * from #GetGoodsListFormBase1_SelectIn
/*---包装转单品*/
if (select OBJECT_ID('tempdb..#tmpPackGoodsList_1'))is not null 		drop table #tmpPackGoodsList_1
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList_1
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

declare @n int
select @n=COUNT(*)
from #GetGoodsListFormBase1_SelectIn a, #tmpPackGoodsList_1 b
where a.cGoodsNO=b.cGoodsNO 
while @n>0
begin
	update a
	set a.cGoodsNo=b.cGoodsNo_MinPackage,
		a.fQuantity0=a.fQuantity0*b.fQty_minPackage,
		a.fQuantity1=a.fQuantity1*b.fQty_minPackage
	from #GetGoodsListFormBase1_SelectIn a, #tmpPackGoodsList_1 b
	where a.cGoodsNO=b.cGoodsNO
	
	select @n=COUNT(*)
	from #GetGoodsListFormBase1_SelectIn a, #tmpPackGoodsList_1 b
	where a.cGoodsNO=b.cGoodsNO 
end

if (select OBJECT_ID('tempdb..#GetGoodsListFormBase1_SelectIn1'))is not null drop table #GetGoodsListFormBase1_SelectIn1
select cGoodsNo,cSupNo,fQuantity0=SUM(ISNULL(fQuantity0,0)),fQuantity1=SUM(ISNULL(fQuantity1,0)),fLastSettle0=SUM(ISNULL(fLastSettle0,0)),
fLastSettle1=SUM(ISNULL(fLastSettle1,0)),fMoneyRatio=SUM(ISNULL(fMoneyRatio,0)),fMoney_Cost=SUM(ISNULL(fMoney_Cost,0))
into #GetGoodsListFormBase1_SelectIn1
from #GetGoodsListFormBase1_SelectIn
group by cGoodsNo,cSupNo

update a
set a.cSupNo=b.cSupNo
from #GetGoodsListFormBase1_SelectIn1 a ,t_goods b
where a.cGoodsNo=b.cGoodsNo
----------管理库存商品
if (select object_id('tempdb..#temp_GetGoodsList_1'))is not null drop table #temp_GetGoodsList_1
select a.cGoodsNo,a.cSupNo,a.fQuantity0,a.fQuantity1,a.fLastSettle0,a.fLastSettle1,a.fMoneyRatio,a.fMoney_Cost
into #temp_GetGoodsList_1
from #GetGoodsListFormBase1_SelectIn1 a,t_goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=1

----------不管库存
if (select object_id('tempdb..#temp_GetGoodsList_0'))is not null drop table #temp_GetGoodsList_0
select a.cGoodsNo,a.cSupNo,a.fQuantity0,a.fQuantity1,a.fLastSettle0,a.fLastSettle1,a.fMoneyRatio,a.fMoney_Cost
into #temp_GetGoodsList_0
from #GetGoodsListFormBase1_SelectIn1 a,t_goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=0
/* 以上包装转单品为2012-04-23改
update a
set a.cGoodsNo=b.cGoodsNo_MinPackage,
    a.fQuantity0=a.fQuantity0*b.fQty_minPackage,
    a.fQuantity1=a.fQuantity1*b.fQty_minPackage
from #GetGoodsListFormBase1_SelectIn a, #tmpPackGoodsList_1 b
where a.cGoodsNO=b.cGoodsNO

update a
set a.cSupNo=b.cSupNo
from #GetGoodsListFormBase1_SelectIn a ,t_goods b
where a.cGoodsNo=b.cGoodsNo
----------管理库存商品
if (select object_id('tempdb..#temp_GetGoodsList_1'))is not null drop table #temp_GetGoodsList_1
select a.cGoodsNo,a.cSupNo,a.fQuantity0,a.fQuantity1,a.fLastSettle0,a.fLastSettle1,a.fMoneyRatio,a.fMoney_Cost
into #temp_GetGoodsList_1
from #GetGoodsListFormBase1_SelectIn a,t_goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=1

----------不管库存
if (select object_id('tempdb..#temp_GetGoodsList_0'))is not null drop table #temp_GetGoodsList_0
select a.cGoodsNo,a.cSupNo,a.fQuantity0,a.fQuantity1,a.fLastSettle0,a.fLastSettle1,a.fMoneyRatio,a.fMoney_Cost
into #temp_GetGoodsList_0
from #GetGoodsListFormBase1_SelectIn a,t_goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=0
*/

if (select object_id('tempdb..#temp_Supplier_Contract_Ratio'))is not null drop table #temp_Supplier_Contract_Ratio
select x.guizuno,x.fRatio
into #temp_Supplier_Contract_Ratio
from t_Supplier_Contract_Ratio x,
(
	 select guizuno,fMoney1=MIN(fMoney1)
	 from t_Supplier_Contract_Ratio 
	 where isnull(fRatio,0)<>0
	 group by guizuno
 )y
where x.guizuno=y.guizuno and x.fMoney1=y.fMoney1
-------供应商扣点
update a 
set a.fMoneyRatio=a.fLastSettle0+a.fLastSettle1-a.fMoney_Cost
from #temp_GetGoodsList_1 a 
--select * from #temp_GetGoodsList_1 
update a 
set a.fMoneyRatio=isnull(a.fMoneyRatio,0)+(b.fRatio/100.00)*isnull(a.fLastSettle0,0),
    a.fMoney_Cost=isnull(a.fMoneyRatio,0)+ --以前特价扣点成本
                  (1-b.fRatio/100.00)*isnull(a.fLastSettle0,0)
from #temp_GetGoodsList_0 a ,
     #temp_Supplier_Contract_Ratio b ,
     (select cGoodsNo from t_goods where ISNULL(fRatio,0)=0) c
where a.cSupNo=b.guizuno and a.cGoodsNo=c.cGoodsNo
--select * from #GetGoodsListFormBase1_SelectIn
/*
select sum(fLastSettle0)+SUM(fLastSettle1),SUM(fMoneyRatio),SUM(fMoney_Cost) from #temp_GetGoodsList_0
select sum(fLastSettle0)+SUM(fLastSettle1),SUM(fMoneyRatio),SUM(fMoney_Cost) from #temp_GetGoodsList_1
*/

if (select object_id('tempdb..#temp_GetGoodsListFormBase2'))is not null drop table #temp_GetGoodsListFormBase2
select cGoodsNo,cSupNo,
fQuantity0=sum(isnull(fQuantity0,0)),fQuantity1=sum(isnull(fQuantity1,0)),
fLastSettle0=sum(isnull(fLastSettle0,0)),--正价销售
fLastSettle1=sum(isnull(fLastSettle1,0)),--特价销售
fMoneyRatio=sum(isnull(fMoneyRatio,0)),--供应商扣点fRatio/100.00*销售
fMoney_Cost=sum(isnull(fMoney_Cost,0))--成本
into #temp_GetGoodsListFormBase2
from #temp_GetGoodsList_1 
group by cGoodsNo,cSupNo
union all
select cGoodsNo,cSupNo,
fQuantity0=sum(isnull(fQuantity0,0)),fQuantity1=sum(isnull(fQuantity1,0)),
fLastSettle0=sum(isnull(fLastSettle0,0)),--正价销售
fLastSettle1=sum(isnull(fLastSettle1,0)),--特价销售
fMoneyRatio=sum(isnull(fMoneyRatio,0)),--供应商扣点fRatio/100.00*销售
fMoney_Cost=sum(isnull(fMoney_Cost,0))--成本
from #temp_GetGoodsList_0 
group by cGoodsNo,cSupNo

update a set 
a.cSupNO=case when a.cSupNO is null then b.cSupNo else a.cSupNo end,
--总销售数量
a.fQuantity=case when (isnull(a.bAuditing,0)=0) then isnull(a.fQuantity,0)+isnull(b.fQuantity0,0) else isnull(a.fQuantity,0)+isnull(b.fQuantity1,0) end ,
--总销售金额
a.fLastSettle=case when (isnull(a.bAuditing,0)=0) then isnull(a.fLastSettle,0)+isnull(b.fLastSettle0,0) else isnull(a.fLastSettle,0)+isnull(b.fLastSettle1,0) end ,
--供应商扣点   
a.fMoneyRatio=ISNULL(a.fMoneyRatio,0)+ISNULL(b.fMoneyRatio,0)/2,
--成本
a.fMoneyCost=isnull(a.fMoneyCost,0)+isnull(b.fMoney_Cost,0)/2
from #GetGoodsListFormBase a right join #temp_GetGoodsListFormBase2 b
on b.cGoodsNo=a.cGoodsNo 

if (select object_id('tempdb..#GetGoodsListFormBase_Ready'))is not null drop table #GetGoodsListFormBase_Ready
select cGoodsNo,cSupNO,fQuantity=SUM(isnull(fQuantity,0)),
       fLastSettle=SUM(isnull(fLastSettle,0)),fMoneyCost=SUM(ISNULL(fMoneyCost,0)),
       fMoneyRatio=SUM(ISNULL(fMoneyRatio,0))
into #GetGoodsListFormBase_Ready
from #GetGoodsListFormBase
group by cGoodsNo,cSupNO

-------负毛利问题
if (select OBJECT_ID('tempdb..#temp_fPrice_Avg0_x'))is not null drop table #temp_fPrice_Avg0_x
if (select OBJECT_ID('tempdb..#temp_fPrice_Avg_x'))is not null drop table #temp_fPrice_Avg_x
select distinct a.cGoodsNo,fPrice_Avg=case when ISNULL(c.fCKPrice,0)=0 then c.fNormalPrice else c.fCKPrice end
into #temp_fPrice_Avg0_x
from #GetGoodsListFormBase a left join t_goods c
on a.cGoodsNo=c.cGoodsNo

select a.cGoodsNo,fPrice_Avg=case when ISNULL(b.fPrice_Avg,0)=0 then a.fPrice_Avg else b.fPrice_Avg end
into #temp_fPrice_Avg_x
from #temp_fPrice_Avg0_x a left join #temp_end b
on a.cGoodsNo=b.cGoodsNo 

update a
set a.fMoneyCost=isnull(a.fQuantity,0)*isnull(b.fPrice_Avg,0)
from #GetGoodsListFormBase_Ready a,#temp_fPrice_Avg_x b
where a.fLastSettle<a.fMoneyCost and a.cGoodsNo=b.cGoodsNo

  --(cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,bAuditing,fQuantity,fLastSettle,fMoneyCost,fMoneyRatio,fRatio)
if (select object_id('tempdb..#temp_Sale_Cost99'))is not null drop table #temp_Sale_Cost99
if (select object_id('tempdb..#temp_goodsKuCun'))is not null drop table #temp_goodsKuCun
  select a.cGoodsNo,cSupplierNo=b.cSupNO,cSupplier=b.cSupName,fQty_Cost=sum(isnull(a.fQuantity,0)),
  fMoney_sale_distribute=sum(isnull(a.fLastSettle,0)),
  fProfitRatio=null,
  fProfitRatio_avg=case when sum(isnull(a.fLastSettle,0))<>0
											  then sum(isnull(a.fMoneyRatio,0))/sum(isnull(a.fLastSettle,0))*100 
									 else null end,
  fMoney_Profit_sum=sum(isnull(a.fMoneyRatio,0)),
  fCostPrice=case when sum(isnull(a.fQuantity,0))<>0
											  then sum(isnull(a.fMoneyCost,0))/sum(isnull(a.fQuantity,0))
									 else null end,
  fMoney_Cost=sum(isnull(a.fMoneyCost,0)),fML=sum(isnull(fMoneyRatio,0))
  into #temp_Sale_Cost99  --select * from #temp_Sale_Cost99
  from #GetGoodsListFormBase_Ready a,t_goods b
  where a.cGoodsNo=b.cGoodsNo and a.fLastSettle<>0
  group by a.cGoodsNo,b.cSupNO,b.cSupName


  select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
				b.cGoodsTypeno,b.cGoodsTypename,bProducted=null,cProductNo=null,
        BeginDate=@dDateBgn,EndDate=@dDateEnd,a.cSupplierNo,cSupName=a.cSupplier,
        xsQty=isnull(a.fQty_Cost,0),xsMoney=isnull(a.fMoney_sale_distribute,0),
				a.fProfitRatio,a.fProfitRatio_avg,a.fMoney_Profit_sum,
				fCostPrice=case when isnull(a.fQty_Cost,0)<>0 
									      then a.fMoney_Cost/a.fQty_Cost else null end,
        a.fMoney_Cost,
				fML=a.fMoney_Profit_sum
  into #temp_goodsKuCun
  from #temp_Sale_Cost99 a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
  
  ---2012-04-21晚改,无扣点联营商品,毛利为0
  update a 
  set a.fMoney_Cost=isnull(xsMoney,0)-isnull(fMoney_Profit_sum,0),
      a.fML=isnull(fMoney_Profit_sum,0)
  from #temp_goodsKuCun  a
  where (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))<>a.fMoney_Profit_sum

 -- select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
 --        BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost=isnull(fCostPrice,0)*isnull(xsQty,0),fProfitRatio,
 --        fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fCostPrice,0)*isnull(xsQty,0),
 --        fProfitRatio_avg=case when isnull(xsMoney,0)<>0 then (isnull(xsMoney,0)-isnull(fCostPrice,0)*isnull(xsQty,0))/isnull(xsMoney,0)*100 else null end,
 --        xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),fML=isnull(xsMoney,0)-isnull(isnull(fCostPrice,0)*isnull(xsQty,0),0)
 -- from #temp_goodsKuCun
 -- where xsQty<>0 and xsMoney<>0 ----2012-05-04修改,屏蔽无销售
	--union all
 -- select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
 --        BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(isnull(fCostPrice,0)*isnull(xsQty,0),0)),
 --        fProfitRatio=null,fMoney_Profit_sum=sum(isnull(xsMoney,0)-isnull(fCostPrice,0)*isnull(xsQty,0)),
 --        fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then sum(isnull(xsMoney,0)-isnull(fCostPrice,0)*isnull(xsQty,0))/sum(isnull(xsMoney,0))*100 else null end ,
 --        xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(xsMoney,0))-sum(isnull(isnull(fCostPrice,0)*isnull(xsQty,0),0))
 -- from #temp_goodsKuCun
 -- where xsQty<>0 and xsMoney<>0 ----2012-05-04修改,屏蔽无销售
 -- group by BeginDate,EndDate
 -- order by cGoodsNo

if(select object_id('tempdb..#temp_SaledateBaseForKuCun')) is not null 
begin 
		insert into #temp_SaledateBaseForKuCun
		(cGoodsNo,cGoodsTypeno,EndQty,XsQty)
		select cGoodsNo,cGoodsTypeno,EndQty=0,XsQty=isnull(XsQty,0)
		from #temp_goodsKuCun 
end
GO
