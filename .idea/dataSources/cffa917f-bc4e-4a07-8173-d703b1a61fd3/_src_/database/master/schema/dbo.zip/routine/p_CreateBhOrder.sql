/*
	 DECLARE @return varchar(32) 
	 exec p_CreateBhOrder '2016031916515465095992','自动售货机%20TSO001-北京-001',@return OUTPUT
	 select @return
	 */
CREATE proc p_CreateBhOrder
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@Name varchar(64), --设备名称。同一个 merchantID 拥有的不同 设备不能有同样的设备名称 deviceName，               
@return varchar(32) output        --返回值
as
BEGIN	
    if (select object_id('tempdb..#tmp_GoodsList'))is not null
	begin
	  drop table #tmp_GoodsList
	end
	create table #tmp_GoodsList(cGoodsNo varchar(32),iLineNo int identity(1,1),fQty money,ExDate datetime,posname varchar(32))
	insert INTO #tmp_GoodsList(cGoodsNo,fQty,ExDate,posname)
	VALUES('20001849',10,'2017-08-30','自动售货机%20TSO001-北京-001')
	insert INTO #tmp_GoodsList(cGoodsNo,fQty,ExDate,posname)
	VALUES('2000185',6,'2017-08-30','自动售货机%20TSO001-北京-001')
	insert INTO #tmp_GoodsList(cGoodsNo,fQty,ExDate,posname)
	VALUES('20001850',16,'2017-08-30','自动售货机%20TSO001-北京-001')
	
	begin try 
	begin tran
		declare @cSheetNo varchar(32)
		set @cSheetNo=DateName(year,GetDate())+DateName(month,GetDate())+DateName(day,GetDate())+
		DateName(hour,GetDate())+DateName(minute,GetDate())+DateName(second,GetDate())+'_'+cast(cast( floor(rand()*100) as int) AS varchar)
		if (select object_id('tempdb..#tmp_GoodsListLast'))is not null
		begin
		  drop table #tmp_GoodsListLast
		end

		SELECT dDate=dbo.getDayStr(getdate()),cSheetno=@cSheetNo,a.iLineNo,b.cGoodsNo,b.cGoodsName,b.cBarcode,
		b.cUnitedNo,a.fQty,b.fCKPrice,fInMoney=a.fqty*b.fCKPrice,
		b.cUnit,b.cSpec,PosID=(SELECT posid from t_posstation where cStoreNo=@Merchantid and posname=@Name),ExDate
		into #tmp_GoodsListLast
		FROM #tmp_GoodsList a,t_cStoreGoods b
		where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@Merchantid
	  
 
		INSERT into WH_BhApply(dDate,cSheetno,cStoreNo,cStoreName,dDeadLine,fMoney,PosID)
		SELECT dDate,cSheetno,@Merchantid,'',ExDate,sum(fInMoney),PosID
		from #tmp_GoodsListLast
		group BY dDate,cSheetno,ExDate,PosID
		
	 
		INSERT INTO WH_BhApplyDetail(
		       cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,
		cUnit,cSpec)
		SELECT cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQty,fCKPrice,fInMoney,
		cUnit,cSpec from #tmp_GoodsListLast

		set @return=@cSheetNo
		
	commit tran

	end try
	begin catch  
	rollback  
	set @return='0'
	end catch
	
end
GO
