create view v_lsdsp
as
  select lsdno=a.cSaleSheetno,Pnumber=a.iSeed,spno=a.cGoodsNo,mingcheng=a.cGoodsName,
					tiaoma=a.cBarCode,Danjia=a.fPrice,yingshou=a.fNormalSettle,
					hyzhekoulv=a.fVipRate,Shuliang=a.fQuantity,Jine=a.fLastSettle,
					Lsriqi=a.dSaleDate,lstime=a.cSaleTime
	from t_SaleSheetDetail a

GO
