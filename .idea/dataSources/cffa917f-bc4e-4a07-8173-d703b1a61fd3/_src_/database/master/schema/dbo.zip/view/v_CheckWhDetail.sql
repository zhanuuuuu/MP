
CREATE  view v_CheckWhDetail
as
  select b.cSheetno,cSupplierNo,cSupplier,cOperatorNo,cOperator,dFillin,cFillinTime,
         cProcureDptno,cProcureDpt,b.fMoney,cManagerNo,cManager,bAgree,cExaminerNo,
         cExaminer,cWhNo,cWh,b.bPost,bZone,cZoneNo,cZone,bShelf,cShelfNo,cShelfName,
         bAll,dDate,cTime,b.bGoodsNo,c.cGoodsNo,c.cGoodsName,bGoodsTypeNo,
         cGoodsType,b.bChecked,cCheckedReason,iLineNo,c.cUnitedNo,c.cGoodsTypeno,c.cGoodsTypename,cBarcode,
         cUnit,cSpec,fNormalPrice,cProductUnit,cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,cLevel,
         bSuspend,bDeling,bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,fVipScore,bProducted,
         cProductNo
         fQuantity,fPrice,fTaxrate,bTax,fTaxPrice,fTaxMoney,fLastMoney,
         dProduct,fTimes,cProductSerno,cCheckNo,dCheck
 from wh_CheckWhDetail a left join wh_CheckWh b
                         on a.cSheetno=b.cSheetno
                         left join  t_Goods c
                         on a.cGoodsNo=c.cGoodsNo

GO
