 
/*
  delete t_TmpWhForm
  declare @d1 datetime 
  declare @d2 datetime 
  declare @i int
  set @d1='2016-5-14'
  set @d2='2016-5-14'
  set @i=1
  while @d1<=@d2
  begin  
	  declare @return int
	  exec p_FIFOWhInWH_Form_Log '001',@d1,@return output
	  select @return ,@d1
	  
	  set @d1=@d1+1	  
  end
  
   
*/
CREATE proc [dbo].[p_FIFOWhInWH_Form_Log]
@cStoreNo varchar(32),
@SheetDate datetime,
@return int output
as 
declare @SheetDate_1 datetime 
set @SheetDate_1=@SheetDate-1
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@SheetDate)
set @Day1=day(@SheetDate)
set @Y1=YEAR(@SheetDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @M_1=MONTH(@SheetDate_1)
set @Day_1=day(@SheetDate_1)
set @Y_1=YEAR(@SheetDate_1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end
declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1

 declare @StrDate varchar(32)
 set @StrDate=dbo.getDayStr(@SheetDate)

 /*****************判断当前是否正在生成快照 ******************/
if exists(select * from t_TmpWhForm where cGoodsNo='Pos_WH_Form' and cIp=@StrDate)
begin
   set @return=0
end else
begin
 /*****************防止多台操作生成快照 ******************/
    declare @PosWhName varchar(32)
	set @PosWhName=(select top 1 Pos_WH_Form from t_WareHouse where isnull(Pos_WH_Form,'')<>'')

    if (select object_id('tempdb..#temp_MaxWhLogDate'))is not null
	begin
	 drop table #temp_MaxWhLogDate
	end
	create table #temp_MaxWhLogDate(dDate datetime)
	exec('
	insert into #temp_MaxWhLogDate(dDate)
	select top 1 业务日期 from '+@PosWhName+'.dbo.t_WH_Form_Log_1 where 业务日期='''+@SheetDate+''' and cStoreNo='''+@cStoreNo+'''
	')
	
    if exists(select top 1 dDate from #temp_MaxWhLogDate)
    begin
       set @return=0
    end else
    begin
    if (select object_id('tempdb..#temp_MaxLogDate'))is not null
	begin
	 drop table #temp_MaxLogDate
	end
	create table #temp_MaxLogDate(cGoodsNo varchar(32))
	insert into #temp_MaxLogDate(cGoodsNo) values('Pos_WH_Form')

 /*****************防止多台操作生成快照 ******************/
 
begin try
begin tran

	exec p_InsertTmpWhFormGoods_chen '#temp_MaxLogDate',@StrDate
 

	if (select object_id('tempdb..#temp_cGoodsSaleDate0'))is not null
	begin
	 drop table #temp_cGoodsSaleDate0
	end
	select dSaleDate,cWHno,cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing 
	into #temp_cGoodsSaleDate0 
	from t_SaleSheet_Day 
	with(nolock)
	where dSaleDate=@SheetDate and cStoreNo=@cStoreNo
	and bStorage=0

	if (select object_id('tempdb..#temp_cGoodsSaleAll'))is not null
	begin
	  drop table #temp_cGoodsSaleAll
	end
	if (select object_id('tempdb..#temp_cGoodsSaleAll'))is not null
	begin
	  drop table #temp_cGoodsSaleAll
	end
	select distinct cGoodsNo,fQuantity,fLastSettle,bAuditing into #temp_cGoodsSaleAll from (
	select cGoodsNo,fQuantity=CAST(null as money),fLastSettle=CAST(null as money),bAuditing=0
	from t_Goods
	with(nolock)
	where  bStorage=0
	union all
	select cGoodsNo,fQuantity=CAST(null as money),fLastSettle=CAST(null as money),bAuditing=1
	from t_Goods
	with(nolock)
	where  bStorage=0
	union all
	select cGoodsNo,fQuantity=CAST(null as money),fLastSettle=CAST(null as money),bAuditing 
	from #temp_cGoodsSaleDate0
	 ) g
	 

	update a
	set a.fLastSettle=b.fLastSettle,a.fQuantity=b.fQuantity,a.bAuditing=b.bAuditing
	from #temp_cGoodsSaleAll a,#temp_cGoodsSaleDate0 b
	where a.cGoodsNo=b.cGoodsNo and a.bAuditing=b.bAuditing


	if (select object_id('tempdb..#temp_cGoodsSaleDate'))is not null
	begin
	  drop table #temp_cGoodsSaleDate
	end
	   
	select cGoodsNo,fQuantity,fLastSettle,bAuditing into #temp_cGoodsSaleDate 
	from #temp_cGoodsSaleAll
	 
	---------转最小
	if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
	select a.cGoodsNo,a.cGoodsNo_MinPackage,fQty_minPackage=isnull(a.fQty_minPackage,1)
	into #tmpPackGoodsList
	from t_goods a,#temp_cGoodsSaleDate b
	where a.cGoodsNo=b.cGoodsNO and a.cGoodsNo<>isnull(a.cGoodsNo_minPackage,a.cGoodsNo)

	update a set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
	from #temp_cGoodsSaleDate a,#tmpPackGoodsList b
	where a.cGoodsNo=b.cGoodsNo

	if (select object_id('tempdb..#temp_SumcGoodsSaleDate'))is not null
	begin
	 drop table #temp_SumcGoodsSaleDate
	end
	select  cGoodsNo,fQuantity=SUM(isnull(fQuantity,0)),fLastSettle=SUM(isnull(fLastSettle,0)),bAuditing 
	into #temp_SumcGoodsSaleDate
	from #temp_cGoodsSaleDate 
	group by  cGoodsNo,bAuditing

	--print dbo.getTimeStr(GETDATE())+'00001'
	 
	 
	---合并
	if (select object_id('tempdb..#temp_SumcGoodsSaleDate1'))is not null
	begin
	 drop table #temp_SumcGoodsSaleDate1
	end
	select  a.cGoodsNo,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),b.cSupNo,
	fMoney_Cost=CAST(null as money),fRatioMoney=CAST(null as money)
	into #temp_SumcGoodsSaleDate1
	from #temp_SumcGoodsSaleDate a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo
	group by a.cGoodsNo,b.cSupNo

	CREATE INDEX IX_temp_SumcGoodsSaleDate1  ON #temp_SumcGoodsSaleDate1(cGoodsNo)

	if (select object_id('tempdb..#temp_SumcGoodsSaleDate0'))is not null
	begin
	 drop table #temp_SumcGoodsSaleDate0
	end
	select  a.cGoodsNo,fQuantity,fLastSettle,bAuditing,b.cSupNo
	into #temp_SumcGoodsSaleDate0
	from #temp_SumcGoodsSaleDate a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo

	CREATE INDEX IX_temp_SumcGoodsSaleDate0  ON #temp_SumcGoodsSaleDate0(cGoodsNo)

	----
	exec('
	if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101''))is not null
	begin
	  drop table #temp_Log_Day_Qty_0_0101
	end
	select cGoodsNo,cSupno into #temp_Log_Day_Qty_0_0101 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''

	CREATE INDEX IX_temp_Log_Day_Qty_0_0101  ON #temp_Log_Day_Qty_0_0101(cGoodsNo)

	if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101Null''))is not null
	begin
	  drop table #temp_Log_Day_Qty_0_0101Null
	end
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+'''
	into #temp_Log_Day_Qty_0_0101Null
	from #temp_SumcGoodsSaleDate1 a left join #temp_Log_Day_Qty_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''

	---销售成本
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	 
	---销售数量
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	--print  dbo.getTimeStr(GETDATE())+''  13''
	---销售金额
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select '''+@cStoreNo+''',cGoodsNo,cSupNo,cYear from #temp_Log_Day_Qty_0_0101Null



	if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101''))is not null
	begin
	  drop table #temp_Log_Day_Qty_0_0101
	end

	')
	--------------处理当前#temp_SumcGoodsSaleDate1和0中不存在已经在dbo.t_WH_Form_Log_Day_Qty 中的数据-----------
	------防止数据累计为空--------
	--print dbo.getTimeStr(GETDATE())+'00002'
	/*取联营扣点*/
	  -----------获取合同扣率
	----- 获取特价扣率	 
	if (select OBJECT_ID('tempdb..#tmpcGoodsHetongRatio'))is not null  drop table #tmpcGoodsHetongRatio
	select b.cGoodsNo,a.guizuno,fRatio=max(a.fRatio) into #tmpcGoodsHetongRatio 
	from t_Supplier_Contract_Ratio a,#temp_SumcGoodsSaleDate1 b
	where a.guizuno=b.cSupNo     
	group by  b.cGoodsNo,a.guizuno

	update a
	set a.fRatioMoney=Convert(money,(convert(money,b.fRatio)/100)*(isnull(fLastSettle,0)))	 
	from #temp_SumcGoodsSaleDate1 a,#tmpcGoodsHetongRatio b
	where a.cGoodsNo=b.cGoodsNo 
			

			
	if (select OBJECT_ID('tempdb..#tmpcGoodsRatio'))is not null  drop table #tmpcGoodsRatio
	select b.cGoodsNo,a.fRatio into #tmpcGoodsRatio 
	from t_Goods a,#temp_SumcGoodsSaleDate1 b
	where a.cGoodsNo=b.cGoodsNo  and  ISNULL(a.fRatio,0)<>0      


	update a 
	set a.fRatioMoney=Convert(money,(convert(money,b.fRatio)/100)*(isnull(fLastSettle,0)))	 
	from #temp_SumcGoodsSaleDate1 a,#tmpcGoodsRatio b
	where a.cGoodsNo=b.cGoodsNo 
	  
 
	----- 获取特价扣率
	if (select OBJECT_ID('tempdb..#tmpcGoodsPloyOfSale'))is not null  drop table #tmpcGoodsPloyOfSale
	select fSupRatio,cPloyNo,a.cGoodsNo,dDateStart,dDateEnd 
	into #tmpcGoodsPloyOfSale
	from dbo.t_PloyOfSale a,#temp_SumcGoodsSaleDate1 b
	where a.cGoodsNo=b.cGoodsNo and  @SheetDate between dDateStart and dDateEnd 
	and a.cStoreNo=@cStoreNo
	 and  ISNULL(a.fSupRatio,0)<>0  	
	    

	update a 
	set a.fRatioMoney=Convert(money,(convert(money,b.fSupRatio)/100)*(isnull(fLastSettle,0)))	 
	from #temp_SumcGoodsSaleDate1 a,#tmpcGoodsPloyOfSale b
	where a.cGoodsNo=b.cGoodsNo 

	update a 
	set a.fMoney_Cost=isnull(fLastSettle,0)-ISNULL(fRatioMoney,0)	 
	from #temp_SumcGoodsSaleDate1 a
	--print dbo.getTimeStr(GETDATE())+'00003'	    
	exec('   
	
	------------修改销售成本记录表
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fMoney_Cost,0) 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#temp_SumcGoodsSaleDate1 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNo and b.cSupNo=a.cSupNo  
	and b.cStoreNo='''+@cStoreNo+'''

	------------修改数量
	update b set b.fQty_'+@MMDAY1+'=isnull(b.fQty_'+@MMDAY1+',0)+isnull(a.fQuantity,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_SumcGoodsSaleDate1 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupNo  
    and b.cStoreNo='''+@cStoreNo+'''

	update b set b.fQtytj_'+@MMDAY1+'=isnull(b.fQtytj_'+@MMDAY1+',0)+isnull(a.fQuantity,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_SumcGoodsSaleDate0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupNo 
	and b.cStoreNo='''+@cStoreNo+'''
	and a.bAuditing=1

	------------修改金额

	update b set b.Sale_'+@MMDAY1+'=isnull(b.Sale_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_SumcGoodsSaleDate1 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupNo   
	and b.cStoreNo='''+@cStoreNo+'''


	update b set b.Saletj_'+@MMDAY1+'=isnull(b.Saletj_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_SumcGoodsSaleDate0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupNo 
	and b.cStoreNo='''+@cStoreNo+'''
	and a.bAuditing=1

	')
	--print dbo.getTimeStr(GETDATE())+'00004'	    
	-------经销管理库存------
	if (select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
	begin
	 drop table #temp_PicWhFormcGoods_WH_Form_Log
	end
	select 业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
	iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
	fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
	cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
	dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
	cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
	入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
	调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
	报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
	差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
	特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
	盘点单价, 库存标志 ,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
	单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
	into #temp_PicWhFormcGoods_WH_Form_Log
	from T_WH_Form_Log    
	with(nolock) 
	where cStoreNo=@cStoreNo
	  
	CREATE INDEX IX_tmp_PicWhFormcGoods_WH_Form_Log  ON #temp_PicWhFormcGoods_WH_Form_Log(cGoodsNo)


	if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_0'))is not null
	begin
	  drop table #temp_MaxPicWhFormcGoods_0
	end
	select cGoodsNo,cSupplierNo,
	fQuantity=sum(isnull(当日特价销售数量,0)+ISNULL(当日正价销售数量,0)),
	fLastSettle=sum(isnull(当日特价销售金额,0)+ISNULL(当日正价销售金额,0)), 
	fQuantity1=sum(isnull(当日特价销售数量,0)),
	fLastSettle1=sum(isnull(当日特价销售金额,0)),
	fMoneyCost=SUM(ISNULL(fPrice_In,0)*(isnull(当日特价销售数量,0)+ISNULL(当日正价销售数量,0)))
	into #temp_MaxPicWhFormcGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by  cGoodsNo,cSupplierNo

	---销售成本
	exec('
	if (select object_id(''tempdb..#temp_Log_Day_Qty_1_0101''))is not null
	begin
	  drop table #temp_Log_Day_Qty_1_0101
	end
	select cGoodsNo,cSupno into #temp_Log_Day_Qty_1_0101 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''

	CREATE INDEX IX_temp_Log_Day_Qty_1_0101  ON #temp_Log_Day_Qty_1_0101(cGoodsNo)

	if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101Null0''))is not null
	begin
	  drop table #temp_Log_Day_Qty_0_0101Null0
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_Log_Day_Qty_0_0101Null0
	from #temp_MaxPicWhFormcGoods_0 a left join #temp_Log_Day_Qty_1_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''


	---销售成本
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0


	--print  dbo.getTimeStr(GETDATE())+''  12''
	---销售数量
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	--print  dbo.getTimeStr(GETDATE())+''  13''
	---销售金额
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null0


	if (select object_id(''tempdb..#temp_Log_Day_Qty_1_0101''))is not null
	begin
	  drop table #temp_Log_Day_Qty_1_0101
	end

	')
	--print dbo.getTimeStr(GETDATE())+'00005'	    
	exec(' 
	------------修改销售成本记录表
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fMoneyCost,0) 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#temp_MaxPicWhFormcGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''


	------------修改数量
	update b set 
	b.fQty_'+@MMDAY1+'=isnull(b.fQty_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fQtytj_'+@MMDAY1+'=isnull(b.fQtytj_'+@MMDAY1+',0)+isnull(a.fQuantity1,0) 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_MaxPicWhFormcGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''

	------------修改金额

	update b set b.Sale_'+@MMDAY1+'=isnull(b.Sale_'+@MMDAY1+',0)+isnull(a.fLastSettle,0),
	b.Saletj_'+@MMDAY1+'=isnull(b.Saletj_'+@MMDAY1+',0)+a.fLastSettle1  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_MaxPicWhFormcGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''

	')
	--print dbo.getTimeStr(GETDATE())+'00006'	  
	-------------******************获取当天剩余库存***********************88----------------
	exec('
	if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101''))is not null
	begin
	  drop table #temp_Log_Day_Left_1_0101
	end
	select cGoodsNo,cSupno into #temp_Log_Day_Left_1_0101 
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101NUll''))is not null
	begin
	  drop table #temp_Log_Day_Left_1_0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_Log_Day_Left_1_0101NUll
	from #temp_MaxPicWhFormcGoods_0 a left join #temp_Log_Day_Left_1_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

	if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101''))is not null
	begin
	  drop table #temp_Log_Day_Left_1_0101
	end
	')
	--print dbo.getTimeStr(GETDATE())+'00007'	 
	if (select object_id('tempdb..#temp_LeftGoods_0'))is not null
	begin
	 drop table #temp_LeftGoods_0
	end 
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_Left,0)),
	fLastSettle=sum(isnull(fMoney_Left,0)) 
	into #temp_LeftGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	 
	if @MMDAY1<>'0101'
	begin 
	exec(' 
	------------修改剩余库存数量和金额
	update b set 
	b.fQty_'+@MMDAY1+'=isnull(a.fQuantity,0),
	b.fMoney_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#temp_LeftGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''

	')
	end else
	begin
	  exec(' 
	 
	------------修改剩余库存数量和金额
		update b set 
		b.fQty_'+@MMDAY1+'=isnull(a.fQuantity,0),
		b.fMoney_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#temp_LeftGoods_0 a
		where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
        and b.cStoreNo='''+@cStoreNo+'''
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00008'	 
	---------------------取当天的所有入库、出库、报损、返厂、成本
	----一、---------取当天入库数表：t_WH_Form_Log_Day_IN
	---入库

	if (select object_id('tempdb..#temp_INGoods_0'))is not null
	begin
	 drop table #temp_INGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
	fLastSettle=sum(isnull(fMoney_In,0)) 
	into #temp_INGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where dDateTime=@SheetDate and iAttribute=0
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_In0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_In0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101NUll''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_In0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_In0101NUll
	from #temp_INGoods_0 a left join #temp_t_WH_Form_Log_Day_In0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll


	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll


	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_In0101
	end
	')

	exec(' 
	------------修改入库数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#temp_INGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
	and b.cStoreNo='''+@cStoreNo+'''
	 
	')
	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
			exec('
			update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			')
		end
	  
	end else
	begin
		exec('
		---- 获取上一年的数据 
		update a
		set 
		a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+'  a
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''
	 
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00009'	 
	-------成品入库：t_WH_Form_Log_Day_Divide

	if (select object_id('tempdb..#temp_DivideGoods_0'))is not null
	begin
	 drop table #temp_DivideGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
	fLastSettle=sum(isnull(fMoney_In,0)) 
	into #temp_DivideGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where dDateTime=@SheetDate and iAttribute=9
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Divide0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Divide0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101NUll''))is not null
	begin
	drop table #temp_t_WH_Form_Log_Day_Divide0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_Divide0101NUll
	from #temp_DivideGoods_0 a left join #temp_t_WH_Form_Log_Day_Divide0101 b
	on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Divide0101
	end

	')

	exec(' 
	------------修改成品入库数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b,#temp_DivideGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''

	')
	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
			exec('
			update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			')
		end   
	end else
	begin
		exec('
		---- 获取上一年的数据 
		
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''
		
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00010'	 
	-------t_WH_Form_Log_Day_Effusion[报益单]

	if (select object_id('tempdb..#temp_EffusionGoods_0'))is not null
	begin
	 drop table #temp_EffusionGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
	fLastSettle=sum(isnull(fMoney_In,0)) 
	into #temp_EffusionGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where dDateTime=@SheetDate and iAttribute=6
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Effusion0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Effusion0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''


	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101NUll''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Effusion0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_Effusion0101NUll
	from #temp_EffusionGoods_0 a left join #temp_t_WH_Form_Log_Day_Effusion0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')='''' 

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll


	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Effusion0101
	end
	')

	exec(' 
	------------修改报溢数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b,#temp_EffusionGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''

	') 
	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end
	   
	end else
	begin
		exec('
		---- 获取上一年的数据
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''  
		
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00011'	 
	-------t_WH_Form_Log_Day_Return[退货入库] 3

	 if (select object_id('tempdb..#temp_ReturnGoods_0'))is not null
	begin
	 drop table #temp_ReturnGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
	fLastSettle=sum(isnull(fMoney_In,0)) 
	into #temp_ReturnGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where dDateTime=@SheetDate and iAttribute=3
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Return0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Return0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101NUll''))is not null
	begin
	   drop table #temp_t_WH_Form_Log_Day_Return0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
	into #temp_t_WH_Form_Log_Day_Return0101NUll
	from #temp_ReturnGoods_0 a left join #temp_t_WH_Form_Log_Day_Return0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Return0101NUll

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Return0101
	end
	')

	exec(' 
	------------修改退货入库数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b,#temp_ReturnGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
	and b.cStoreNo='''+@cStoreNo+'''
	') 
	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
		if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end  
	   
	end else
	begin
		exec('
		---- 获取上一年的数据 		
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a 
		where a.cYear='''+@Y1+'''  and a.cStoreNo='''+@cStoreNo+'''
		
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00012'	 
	-------t_WH_Form_Log_Day_TfrIn[调拨入库]

	if (select object_id('tempdb..#temp_TfrInGoods_0'))is not null
	begin
	 drop table #temp_TfrInGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_In,0)),
	fLastSettle=sum(isnull(fMoney_In,0)) 
	into #temp_TfrInGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where dDateTime=@SheetDate and iAttribute=31
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_TfrIn0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_TfrIn0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101Null''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_TfrIn0101Null
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_TfrIn0101Null
	from #temp_TfrInGoods_0 a left join #temp_t_WH_Form_Log_Day_TfrIn0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')='''' 

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null
	 

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_TfrIn0101
	end
	')

	exec(' 
	------------修改调拨入库数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#temp_TfrInGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
	and b.cStoreNo='''+@cStoreNo+'''
	')

	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		 exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end 
	end else
	begin
		exec('
		---- 获取上一年的数据
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''
 
		')
	end
	--print dbo.getTimeStr(GETDATE())+'00013'	 
	----------------***************出库、返厂、报损、***********************---------------
	/*出库单t_WH_Form_Log_Day_Out[出库单]*/

	if (select object_id('tempdb..#temp_OutGoods_0'))is not null
	begin
	 drop table #temp_OutGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(出库数量0,0)),
	fLastSettle=sum(isnull(出库金额0,0)) 
	into #temp_OutGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Out0101
	end
		select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Out0101
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+'
		with (nolock) 
		where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101Null''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Out0101Null
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
	into #temp_t_WH_Form_Log_Day_Out0101Null
	from #temp_OutGoods_0 a left join #temp_t_WH_Form_Log_Day_Out0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
	
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Out0101
	end

	')
 
	exec(' 
	------------修改出库数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#temp_OutGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''
	')
	-----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end     
	end else
	begin
		exec('
		---- 获取上一年的数据
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a 
		where a.cYear='''+@Y1+'''  and a.cStoreNo='''+@cStoreNo+'''
		
		')
	end
 
	/*返厂单t_WH_Form_Log_Day_Rbd[返厂单]*/

	if (select object_id('tempdb..#temp_RbdGoods_0'))is not null
	begin
	 drop table #temp_RbdGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(返厂数量0,0)),
	fLastSettle=sum(isnull(返厂金额0,0)) 
	into #temp_RbdGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Rbd0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Rbd0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101Null''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Rbd0101Null
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
	into #temp_t_WH_Form_Log_Day_Rbd0101Null
	from #temp_RbdGoods_0 a left join #temp_t_WH_Form_Log_Day_Rbd0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''


	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null


	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Rbd0101
	end
	')
 --print 150001
	exec(' 
	------------修改返厂数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b,#temp_RbdGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
	and b.cStoreNo='''+@cStoreNo+'''
	')
	 -----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end 
	end else
	begin
		exec('
		---- 获取上一年的数据
		
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''  

		')
	end
	-- print dbo.getTimeStr(GETDATE())+'00015'	 
	/*报损 单t_WH_Form_Log_Day_Loss[报损单]*/

	if (select object_id('tempdb..#temp_LossGoods_0'))is not null
	begin
	 drop table #temp_LossGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(报损数量0,0)),
	fLastSettle=sum(isnull(报损金额0,0)) 
	into #temp_LossGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	exec('
	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Loss0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Loss0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+''' 

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101Null''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Loss0101Null
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_Loss0101Null
	from #temp_LossGoods_0 a left join #temp_t_WH_Form_Log_Day_Loss0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Loss0101
	end
	')

	exec(' 
	------------修改报损单数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b,#temp_LossGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
	and b.cStoreNo='''+@cStoreNo+'''
	')
	 -----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		 exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end 
	end else
	begin
		exec('
		---- 获取上一年的数据
		
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''
		
		 
		')
	end
	-- print dbo.getTimeStr(GETDATE())+'00016'	 
	 /*调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]*/

	if (select object_id('tempdb..#temp_TfrGoods_0'))is not null
	begin
	 drop table #temp_TfrGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(调拨出库数量0,0)),
	fLastSettle=sum(isnull(调拨出库金额0,0)) 
	into #temp_TfrGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	 exec('
	 if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Tfr0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Tfr0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101Null''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Tfr0101Null
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_Tfr0101Null
	from #temp_TfrGoods_0 a left join #temp_t_WH_Form_Log_Day_Tfr0101 b
	on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
	where isnull(b.cGoodsNO,'''')=''''
	 
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Tfr0101
	end

	')

	exec(' 
	------------修改调拨数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#temp_TfrGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
	and b.cStoreNo='''+@cStoreNo+'''
	')
	 -----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end
	end else
	begin
		exec('
		---- 获取上一年的数据
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a 
		where a.cYear='''+@Y1+''' and a.cStoreNo='''+@cStoreNo+'''

		')
	end
	-- print dbo.getTimeStr(GETDATE())+'00017'	 
	 /*原料出库单t_WH_Form_Log_Day_Pack[原料出库单]*/

	if (select object_id('tempdb..#temp_PackGoods_0'))is not null
	begin
	 drop table #temp_PackGoods_0
	end
	select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(原料出库数量0,0)),
	fLastSettle=sum(isnull(原料出库金额0,0)) 
	into #temp_PackGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	group by cGoodsNo,cSupplierNo

	exec('
	 if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Pack0101
	end
	select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Pack0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101NUll''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Pack0101NUll
	end
	select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
	into #temp_t_WH_Form_Log_Day_Pack0101NUll
	from #temp_PackGoods_0 a left join #temp_t_WH_Form_Log_Day_Pack0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_01(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_02(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_03(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_04(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_05(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_06(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_07(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_08(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_09(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_10(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_11(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll
	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_12(cStoreNo,cGoodsNO,cSupNo,cYear)
	select  '''+@cStoreNo+''',cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Pack0101NUll

	 if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Pack0101
	end

	')

	exec(' 
	------------修改原料出库单数量、金额
	update b set 
	b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
	b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b,#temp_PackGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo   
	and b.cStoreNo='''+@cStoreNo+'''
	')
	 -----把前一天数据加上
	if @MMDAY1<>'0101'
	begin 
	   if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M_1+'
			   where cYear='''+@Y1+''' and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		')
		end 
	end  else
	begin
		exec('
		---- 获取上一年的数据
		update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' a 
		where a.cYear='''+@Y1+''' 	and a.cStoreNo='''+@cStoreNo+'''
		
		 
		')
	end
	--  print dbo.getTimeStr(GETDATE())+'00018'	 
	if (select object_id('tempdb..#temp_JingWhFormcGoods_0'))is not null
	begin
	 drop table #temp_JingWhFormcGoods_0
	end
	---- 取当前批次中库存为0的商品。。。。
	select dDateTime,cGoodsNo,iMyIdentity,iSerno,iLineNo,iAttribute,cSummary,fPrice_In,fQty_In,fMoney_In,
	fPrice_Out,fQty_Out,fMoney_Out,fQty_Left,fPrice_Left,fMoney_Left,cSupplierNo,cSupplier,当日特价销售数量,当日正价销售数量
	into #temp_JingWhFormcGoods_0
	from #temp_PicWhFormcGoods_WH_Form_Log
	where fQty_In=fQty_Out and fQty_Left=0 
	 
	 
	CREATE INDEX IX_tmp_JingWhFormcGoods_0  ON #temp_JingWhFormcGoods_0(cGoodsNo)
	 
	/*防止有静态手动改成动态时。即把原来的不是最大批次号改成最大批次号。。*/
	---------------------- 2015-03-16-------------------------------
	 

	if (select object_id('tempdb..#temp_MaxiSerno'))is not null
	begin
	 drop table #temp_MaxiSerno
	end
	select cgoodsno,iSerno=MAX(iSerno)
	into #temp_MaxiSerno
	from #temp_PicWhFormcGoods_WH_Form_Log 
	--where iAttribute<>10 and iAttribute<>13
	where  iAttribute<>13
	group by cgoodsno

	---------- 在判断批次中为0商品批次号不是最大批次
	if (select object_id('tempdb..#temp_NoMaxPicWhFormcGoods_0'))is not null
	begin
	 drop table #temp_NoMaxPicWhFormcGoods_0
	end
	 select distinct a.dDateTime,b.cGoodsNo,a.iSerno,a.cSupplierNo,a.iMyIdentity
	into #temp_NoMaxPicWhFormcGoods_0
	from #temp_JingWhFormcGoods_0 a,#temp_MaxiSerno b
	 where a.cGoodsNo=b.cGoodsNo and a.iSerno<b.iSerno 
	 ---------------------- 2015-03-16-------------------------------
	 if (select object_id('tempdb..#temp_MaxPicWhFormcGoods'))is not null
	begin
	 drop table #temp_MaxPicWhFormcGoods 
	end
	select SheetDate=@SheetDate, a.cGoodsNo, a.dDateTime, a.cWhNo, a.cSheetNo, a.iMyIdentity, a.iSerno, a.iLineNo, 
	a.iAttribute, a.cSummary, a.fPrice_Tran, a.fPrice_In, a.fQty_In, a.fMoney_In, a.fPrice_Out, a.fQty_Out, 
	a.fMoney_Out, a.fQty_Left, a.fPrice_Left, a.fMoney_Left, a.bJiecun, a.dJiecunDate, a.cSupplierNo, 
	a.cSupplier, a.cReason, a.bSupplierPay, a.fMoneyACC_SpplierPay, a.cJiesuanno_Last, a.iSerno_Cost_Distribute, 
	a.dDate_sheet_Cost_Distribute, a.cGoodsNo_Parent, a.fQty_minPackage, a.fQty_In_Parent, a.bChangePrice, 
	a.cChangePriceBillNo, a.fQty_Diff, a.fPrice_In_OnSheet, a.fMoney_In_OnSheet, 
	a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, a.退货入库数量1, a.退货入库金额1, 
	a.调拨入库数量1, a.调拨入库金额1, a.Pos客退数量1, a.Pos客退金额1, a.出库数量0, a.出库金额0, 
	a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, a.调拨出库数量0, a.调拨出库金额0, a.差价数量, 
	a.差价金额, a.原料出库数量0, a.原料出库金额0, a.成品入库数量1, a.成品入库金额1, a.销售数量0, a.销售金额0, 
	a.特价销售数量, a.特价销售金额, a.正价销售数量, a.正价销售金额, a.本日库存数量, a.盘点数量, 
	a.盘点单价, a.库存标志 ,a.当日特价销售数量,a.当日特价销售金额,a.当日正价销售数量,a.当日正价销售金额,a.合同扣率,
	a.单品扣率,a.特价扣率,a.执行扣率,a.扣率金额,a.扣率类别,a.累计差价数量,a.累计差价金额,a.差价后成本单价,a.人工指定成本单价
	into #temp_MaxPicWhFormcGoods
	from #temp_PicWhFormcGoods_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
	where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
	and a.iSerno=b.iSerno  
	 

	  ----- 删除临时表中的静态数据
	 delete a
	 from #temp_PicWhFormcGoods_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
	 where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
	 and a.iSerno=b.iSerno
	-- print dbo.getTimeStr(GETDATE())+'00019'	  
	if (select object_id('T_WH_Form_Log_Back'))is not null
	begin 
		insert into PosManagement.dbo.T_WH_Form_Log_Back(
		业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, iAttribute, cSummary, 
		fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, 
		fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, 
		cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, 
		fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
		入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, 
		Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 
		调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 
		销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 
		库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 
		特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价,cStoreNo
		)
		select @SheetDate, a.cGoodsNo, a.dDateTime, cWhNo, cSheetNo, a.iMyIdentity, a.iSerno, iLineNo, iAttribute, cSummary, 
		fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, 
		fMoney_Left, bJiecun, dJiecunDate, a.cSupplierNo, cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, 
		cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, 
		fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
		入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, 
		Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 
		调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 
		销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 
		库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 
		特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价,a.cStoreNo
		from T_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
		where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
		and a.cStoreNo=@cStoreNo
		and a.iSerno=b.iSerno and  a.iAttribute=0
	end

	delete a
	from T_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
	where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
	and a.iSerno=b.iSerno and a.cStoreNo=@cStoreNo
	 
	--print dbo.getTimeStr(GETDATE())+'00020'	  
	 /*操作成本分配表*/
	 
 
    
	insert into Pos_Cost_distribute.dbo.t_Cost_distribute_Log_temp
	(
	操作日期, dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, 
	fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, 
	bJiesuan, cJiesuanNo,cStoreNo
	)
	select @SheetDate,dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, 
	fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
	fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, 
	bJiesuan, cJiesuanNo,cStoreNo
	from Pos_Cost_distribute.dbo.t_Cost_distribute_Log
	with(nolock)
	where isnull(bDone,0)=0 and fQty>=fQty_Cost  
	and cStoreNo=@cStoreNo
	------------- 删除
	delete    Pos_Cost_distribute.dbo.t_Cost_distribute_Log
	where isnull(bDone,0)=0 and fQty>=fQty_Cost  
	and cStoreNo=@cStoreNo

	update T_WH_Form_Log set  当日正价销售数量=0,当日正价销售金额=0,当日特价销售数量=0, 当日特价销售金额=0,扣率金额=0,扣率类别=null 
	where cStoreNo=@cStoreNo
	update t_wh_form_log set  出库数量0=0,出库金额0=0,返厂数量0=0,返厂金额0=0,报损数量0=0,报损金额0=0,
							  调拨出库数量0=0,调拨出库金额0=0,原料出库数量0=0,原料出库金额0=0
	where cStoreNo=@cStoreNo
		                      
	--print dbo.getTimeStr(GETDATE())+'00021'	  
	-------把前一天的销售数量和金额加上
	if (@M1+@Day1)<>'0101'
	begin
		if @Day1='01'
	   begin
		  exec('
			update a set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
			
			exec('
			update a set 
			fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY_1+',0)+isnull(fQty_'+@MMDAY1+',0),
			fQtytj_'+@MMDAY1+'=isnull(fQtytj_'+@MMDAY_1+',0)+isnull(fQtytj_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,fQty_'+@MMDAY_1+',fQtytj_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
			
			exec('
			update a set 
			Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY_1+',0)+isnull(Sale_'+@MMDAY1+',0),
			Saletj_'+@MMDAY1+'=isnull(Saletj_'+@MMDAY_1+',0)+isnull(Saletj_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' a,
			(
			   select  cGoodsNo,cSupNo,Sale_'+@MMDAY_1+',Saletj_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec(' 
		------------修改销售成本记录表 	
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' 
		set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(fQtyIn_'+@MMDAY_1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(fMoneyIn_'+@MMDAY_1+',0)
		where  cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		------------修改数量
		 
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' 
		set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(fQty_'+@MMDAY_1+',0),
		fQtytj_'+@MMDAY1+'=isnull(fQtytj_'+@MMDAY1+',0)+isnull(fQtytj_'+@MMDAY_1+',0)
		where  cYear='''+@Y1+'''    and cStoreNo='''+@cStoreNo+'''
		------------修改金额 

		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' 
		set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(Sale_'+@MMDAY_1+',0),
		Saletj_'+@MMDAY1+'=isnull(Saletj_'+@MMDAY1+',0)+isnull(Saletj_'+@MMDAY_1+',0)
		where  cYear='''+@Y1+'''    and cStoreNo='''+@cStoreNo+'''

		')
		end 
		
	end  else
	begin
		exec('
		 ---- 获取上一年的记录成本数据
		 update a
		set a.fQtyIn_'+@MMDAY1+'=isnull(a.fQtyIn_010131,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
		a.fMoneyIn_'+@MMDAY1+'=isnull(a.fMoneyIn_010131,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a
		where a.cYear='''+@Y1+'''   and a.cStoreNo='''+@cStoreNo+'''
		
		 
	    
		---- 获取上一年的数据
		 update a
		set a.fQty_'+@MMDAY1+'=isnull(a.fQty_010131,0)+isnull(a.fQty_'+@MMDAY1+',0),
		a.fQtytj_'+@MMDAY1+'=isnull(a.fQtytj_010131,0)+isnull(a.fQtytj_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' a 
		where a.cYear='''+@Y1+'''    and a.cStoreNo='''+@cStoreNo+''' 	
		
		 
	 
		update a
		set a.Sale_'+@MMDAY1+'=isnull(a.Sale_010131,0)+isnull(a.Sale_'+@MMDAY1+',0),
		a.Saletj_'+@MMDAY1+'=isnull(a.Saletj_010131,0)+isnull(a.Saletj_'+@MMDAY1+',0)           
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' a 
		where a.cYear='''+@Y1+'''    and a.cStoreNo='''+@cStoreNo+'''
		
		 
		')
	end

	--print dbo.getTimeStr(GETDATE())+'00022'	  
	/*------------------获取会员销售明细-来客数  会员销售--------------*/
	   if (select object_id('tempdb..#temp_GoodsvipSale')) is not null
	   drop table #temp_GoodsvipSale
	   create table #temp_GoodsvipSale(dSaleDate datetime,cSaleSheetno varchar(32),
	   cGoodsno varchar(32),fQuantity money,fLastSettle money,vipCount bigint,
	   cVipNo varchar(32))

		declare @date1 datetime
		declare @date2 datetime
		set @date1=@SheetDate
		set @date2=@SheetDate
 
	insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
	select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo--,vipCount=COUNT(cVipNo)
	from t_SaleSheetDetail with (nolock)
	where dSaleDate=@date1  and cStoreNo=@cStoreNo
	group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
	 
			
	----print dbo.getTimeStr(GETDATE())
	----print 15 
	-----------获取商品总销售来客数

	if (select OBJECT_ID('tempdb..#temp_SaleSheetLk'))is not null drop table #temp_SaleSheetLk
	select cGoodsno,lk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
	viplk=CAST(null as money),fQuantityVip=CAST(null as money),fLastSettleVip=CAST(null as money)
	into #temp_SaleSheetLk
	from #temp_GoodsvipSale
	group by cGoodsno

	 -----------获取商品vip来客数
	--print dbo.getTimeStr(GETDATE())+'00023'	 
	if (select OBJECT_ID('tempdb..#temp_SaleSheetvipLk'))is not null drop table #temp_SaleSheetvipLk
	select cGoodsno,viplk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle)
	into #temp_SaleSheetvipLk
	from #temp_GoodsvipSale
	where ISNULL(cVipNo,'')<>''
	group by cGoodsno
	 
	 
	update a set a.viplk=b.viplk,a.fQuantityVip=b.fQuantity,a.fLastSettleVip=b.fLastSettle
	from #temp_SaleSheetLk a,#temp_SaleSheetvipLk b
	where a.cGoodsno=b.cGoodsno

	CREATE INDEX IX_temp_SaleSheetvipL  ON #temp_SaleSheetvipLk(cGoodsNo) 

	exec('
	if (select object_id(''tempdb..#temp_Vip_0_0101''))is not null
	begin
	  drop table #temp_Vip_0_0101
	end
	select cGoodsNo
	into #temp_Vip_0_0101
	from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+'
	with (nolock) 
	where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''

	CREATE INDEX IX_temp_Vip_0_0101  ON #temp_Vip_0_0101(cGoodsNo) 

	if (select object_id(''tempdb..#temp_Vip_0_0101Null''))is not null
	begin
	  drop table #temp_Vip_0_0101Null
	end

	select a.cGoodsNo,cYear='''+@Y1+'''
	into #temp_Vip_0_0101Null
	from #temp_SaleSheetLk a left join #temp_Vip_0_0101 b
	on a.cGoodsNo=b.cGoodsNO  
	where isnull(b.cGoodsNO,'''')=''''

	insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_01(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_02(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_03(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_04(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_05(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_06(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_07(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_08(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_09(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_10(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_11(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_12(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		

		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_01(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_02(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_03(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_04(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_05(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_06(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_07(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_08(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_09(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_10(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_11(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_12(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		

	 
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_01(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_02(cStoreNo,cGoodsNO,cYear)		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_03(cStoreNo,cGoodsNO,cYear)		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_04(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_05(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_06(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_07(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_08(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_09(cStoreNo,cGoodsNO,cYear)
		
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_10(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_11(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null
		
		insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_12(cStoreNo,cGoodsNO,cYear)
		select  '''+@cStoreNo+''',cGoodsNo,cYear from #temp_Vip_0_0101Null

		if (select object_id(''tempdb..#temp_Vip_0_0101''))is not null
		begin
		  drop table #temp_Vip_0_0101
		end

	')
	 
--print dbo.getTimeStr(GETDATE())+'00024'	 
	exec(' 
	------------修改数量
	update b set 
	b.fQty_'+@MMDAY1+'=isnull(b.fQty_'+@MMDAY1+',0)+isnull(a.fQuantityVip,0) 
	from #temp_SaleSheetLk a,'+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' b
	where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO    
	and b.cStoreNo='''+@cStoreNo+'''
	 
	------------修改会员销售金额
	  
	update b set b.Sale_'+@MMDAY1+'=isnull(b.Sale_'+@MMDAY1+',0)+isnull(a.fLastSettleVip,0)  
	from #temp_SaleSheetLk a,'+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' b
	where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO    
	and b.cStoreNo='''+@cStoreNo+'''

	-------- 修改总来客数 和会员来客数
	 
	update b set b.Qty_'+@MMDAY1+'=isnull(b.Qty_'+@MMDAY1+',0)+isnull(a.viplk,0),
	b.Qtyzs_'+@MMDAY1+'=isnull(b.Qtyzs_'+@MMDAY1+',0)+isnull(a.lk,0) 
	from #temp_SaleSheetLk a,'+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' b
	where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO      
	 and b.cStoreNo='''+@cStoreNo+'''
	 
	')
	--print dbo.getTimeStr(GETDATE())+'00025'	 
	if (@M1+@Day1)<>'0101'
	begin
	 if @Day1='01'
	   begin
			exec('
			update a set 
			fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY_1+',0)+isnull(fQty_'+@MMDAY1+',0) 
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' a,
			(
			   select  cGoodsNo,fQty_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M_1+'
			   where cYear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO 
			and a.cStoreNo='''+@cStoreNo+'''
			')
			
			exec('
			update a set 
			Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY_1+',0)+isnull(Sale_'+@MMDAY1+',0)   
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' a,
			(
			   select  cGoodsNo,Sale_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO  
			and a.cStoreNo='''+@cStoreNo+'''
			')
			
			exec('
			update a set 
			Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY_1+',0)+isnull(Qtyzs_'+@MMDAY1+',0),
			Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY_1+',0)+isnull(Qty_'+@MMDAY1+',0)  
			from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' a,
			(
			   select  cGoodsNo,Qty_'+@MMDAY_1+',Qtyzs_'+@MMDAY_1+'
			   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_'+@M_1+'
			   where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
			) c
			where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO 
			and a.cStoreNo='''+@cStoreNo+'''
			')
	   end else
	   begin
		exec('
		------------修改会员销售数量 
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+'
		set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(fQty_'+@MMDAY_1+',0)
		where cYear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''
		------------修改会员销售金额
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+'
		set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(Sale_'+@MMDAY_1+',0)
		where cYear='''+@Y1+'''   and cStoreNo='''+@cStoreNo+'''
		-------- 修改总来客数 和会员来客数
		update '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+'
		set Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY1+',0)+isnull(Qtyzs_'+@MMDAY_1+',0),
		Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY1+',0)+isnull(Qty_'+@MMDAY_1+',0)
		where cYear='''+@Y1+'''   and cStoreNo='''+@cStoreNo+'''
		')
		end 
	end  else
	begin
		exec('
		---- 获取上一年的数据
		 update a
		set a.fQty_'+@MMDAY1+'=isnull(a.fQty_010131,0)+isnull(a.fQty_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' a 
		where a.cYear='''+@Y1+''' 	 and a.cStoreNo='''+@cStoreNo+'''
		
		
		 
		update a
		set a.Sale_'+@MMDAY1+'=isnull(a.Sale_010131,0)+isnull(a.Sale_'+@MMDAY1+',0)
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' a 
		where a.cYear='''+@Y1+'''	 and a.cStoreNo='''+@cStoreNo+'''
		
		 
		update a
		set a.Qtyzs_'+@MMDAY1+'=isnull(a.Qtyzs_010131,0)+isnull(a.Qtyzs_'+@MMDAY1+',0),
		a.Qty_'+@MMDAY1+'=isnull(a.Qty_010131,0)+isnull(a.Qty_'+@MMDAY1+',0) 
		from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' a 
		where a.cYear='''+@Y1+'''	 and a.cStoreNo='''+@cStoreNo+'''
		
		')
	end

	----print dbo.getTimeStr(GETDATE())+'00026'	 
	update t_Daily_history set bPosWhFormLog=1
	where dDate=@SheetDate and cStoreNo=@cStoreNo
	exec('
	   delete '+@PosWhName+'.dbo.t_WH_Form_Log_1
	   where 业务日期='''+@SheetDate+''' and  cStoreNo='''+@cStoreNo+'''
	   
	   insert into '+@PosWhName+'.dbo.t_WH_Form_Log_1
	   (业务日期,cGoodsNo,dDatetime,cWhno,cSheetNo,iMyIdentity,cStoreNo)
	   values('''+@SheetDate+''','''','''+@SheetDate+''','''','''',0,'''+@cStoreNo+''')
	')
	--------判断是否是每月的第一天 :
	if @Day1='01'
	begin
	   declare @riqi1 varchar(32)
	   declare @riqi2 varchar(32) 
	   set @riqi1=dbo.getdaystr(DATEADD(MONTH,-1,@SheetDate))
	   set @riqi2=dbo.getdaystr(@SheetDate_1)
	    
	   exec('   
		if not exists (select top 1 dDateBgn from '+@PosWhName+'.dbo.t_WH_Form_Log_Month where dDateBgn='''+@riqi1+''' and cStoreNo='''+@cStoreNo+''')  -- 包含在时间断内
		begin	   
		  insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Month
		   (dDateBgn,dDateEnd,cGoodsNo,cSupplierNo,cWhNo,cStoreNo)
		   values('''+@riqi1+''','''+@riqi2+''','''','''','''','''+@cStoreNo+''')
		end
	   ')
	end
	if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
	if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	if(select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
	begin
	 drop table #temp_PicWhFormcGoods_WH_Form_Log
	end
	if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_0'))is not null
	begin
	  drop table #temp_MaxPicWhFormcGoods_0
	end
	if (select object_id('tempdb..#temp_SumcGoodsSaleDate1'))is not null
	begin
	 drop table #temp_SumcGoodsSaleDate1
	end
	if (select object_id('tempdb..#temp_LeftGoods_0'))is not null
	begin
	 drop table #temp_LeftGoods_0
	end 
	if (select object_id('tempdb..#temp_INGoods_0'))is not null
	begin
	 drop table #temp_INGoods_0
	end
	 if (select object_id('tempdb..#temp_DivideGoods_0'))is not null
	begin
	 drop table #temp_DivideGoods_0
	end
	if (select object_id('tempdb..#temp_EffusionGoods_0'))is not null
	begin
	 drop table #temp_EffusionGoods_0
	end
	 if (select object_id('tempdb..#temp_ReturnGoods_0'))is not null
	begin
	 drop table #temp_ReturnGoods_0
	end
	if (select object_id('tempdb..#temp_TfrInGoods_0'))is not null
	begin
	 drop table #temp_TfrInGoods_0
	end
	if (select object_id('tempdb..#temp_OutGoods_0'))is not null
	begin
	 drop table #temp_OutGoods_0
	end
	if (select object_id('tempdb..#temp_RbdGoods_0'))is not null
	begin
	 drop table #temp_RbdGoods_0
	end
	if (select object_id('tempdb..#temp_LossGoods_0'))is not null
	begin
	 drop table #temp_LossGoods_0
	end
	if (select object_id('tempdb..#temp_TfrGoods_0'))is not null
	begin
	 drop table #temp_TfrGoods_0
	end
	if (select object_id('tempdb..#temp_PackGoods_0'))is not null
	begin
	 drop table #temp_PackGoods_0
	end
	if (select object_id('tempdb..#temp_GoodsvipSale')) is not null drop table #temp_GoodsvipSale
	if (select OBJECT_ID('tempdb..#temp_SaleSheetLk'))is not null drop table #temp_SaleSheetLk
	if (select OBJECT_ID('tempdb..#temp_SaleSheetvipLk'))is not null drop table #temp_SaleSheetvipLk

    /*2016-04-01  清空成本分配表...... */
 
	commit tran 
	
	 delete t_TmpWhForm where cGoodsNo='Pos_WH_Form' and cIp=@StrDate
	 set @return=1
	end try
	begin catch
	 rollback  
	 
	  delete t_TmpWhForm where cGoodsNo='Pos_WH_Form' and cIp=@StrDate
	  
	  set @return=0
	end catch
  end
end
GO
