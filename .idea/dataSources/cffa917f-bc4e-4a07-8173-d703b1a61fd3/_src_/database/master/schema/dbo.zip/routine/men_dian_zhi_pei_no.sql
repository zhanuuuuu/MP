create proc men_dian_zhi_pei_no
@Year varchar(20),
@cSupplierNo varchar(20)
as
select dbo.[f_GenStoreInsheetno](@Year,@cSupplierNo) as men_dian_zhi_pei_no
GO
