




/*特定时间段内供货的商品的库存量*/
create     procedure P_Z_GoodsType_SellAmount		
  @date1 datetime,
  @date2 datetime,
  @OutPutTable varchar(32),
  @cGoodsTypeNo varchar(32)    
as
begin
 	select distinct cGoodsNo 
	into #cGoodsNo_In
	from dbo.wh_InWarehouseDetail

	select cGoodsNo_main=a.cGoodsNo,cGoodsNo_sub=b.cGoodsNo
	into #cGoodsNo_Product0
	from t_goods a left join dbo.t_GoodsProducted b
	on a.cProductNo=b.cProductNo
	where isnull(dbo.trim(a.cProductNo),'')<>'' and b.cGoodsNo is not null

	select cGoodsNo=b.cGoodsNo_sub
	into #cGoodsNo_Product_sub
	from #cGoodsNo_In a left join #cGoodsNo_Product0 b
	on a.cGoodsNo=b.cGoodsNo_main
	where b.cGoodsNo_main is not null

	select cGoodsNo=b.cGoodsNo_main
	into #cGoodsNo_Product_main
	from #cGoodsNo_In a left join #cGoodsNo_Product0 b
	on a.cGoodsNo=b.cGoodsNo_sub
	where b.cGoodsNo_sub is not null

  select cGoodsNo
	into #cGoodsNo_all
	from #cGoodsNo_Product_sub
	union all
  select cGoodsNo
	from #cGoodsNo_Product_main
	union all
  select cGoodsNo
	from #cGoodsNo_In

  select distinct cGoodsNo
	into #cGoodsNo_storage
	from #cGoodsNo_all
	where cGoodsNo is not null
/*以上查询出是需要检索库存的商品*/
  select cGoodsNo,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),bAuditing
  into #TempSaleSheetDetail
  from t_SaleSheetDetail
  where dSaleDate between @date1 and @date2
  group by cGoodsNo,bAuditing
  
  select t.cGoodsNo,t.fQuantity,t.fLastSettle,t.bAuditing
  into #cGoodsNo_SaleSheet
  from #TempSaleSheetDetail  t left join #cGoodsNo_storage g
  on t.cGoodsNo=g.cGoodsNo
  where g.cGoodsNo is not null


  select t.cGoodsNo,g.cGoodsName,g.cBarcode,g.cUnit,g.cSpec,g.cGoodsTypeNo,g.cGoodsTypename,t.fQuantity,t.fLastSettle,bAuditing=isnull(t.bAuditing,0)
  into #cGoodsNo_SaleType
  from #cGoodsNo_SaleSheet t left join t_Goods g
  on t.cGoodsNo=g.cGoodsNo
  where g.cGoodsNo is not null
  and g.cGoodsTypeNo like @cGoodsTypeNo+'%'
  
  exec('insert into '+@OutPutTable+'(cGoodsNo,cGoodsName,cGoodsTypeNo,cGoodsTypename,fQuantity,fLastSettle,bAuditing,cUnit,cSpec,cBarcode)select
      cGoodsNo,cGoodsName,cGoodsTypeNo,cGoodsTypename,fQuantity,fLastSettle,bAuditing=case when bAuditing=0 then '' '' else ''√''end,
      cUnit,cSpec,cBarcode
      from #cGoodsNo_SaleType')
   
  select cGoodsTypeNo,cGoodsTypename,fQuantity=isnull(sum(isnull(fQuantity,0)),0),fLastSettle=isnull(sum(isnull(fLastSettle,0)),0),bAuditing=case when bAuditing=0 then ' 'else '√'end
  from #cGoodsNo_SaleType 
  group by cGoodsTypeNo,cGoodsTypename,bAuditing
 


end


GO
