/*
     select cGoodsTypeNo into U_key.dbo.temp_GoodsTypeNobh from t_GoodsType where cGoods
     
     exec p_GetBaiHuoSaleCreateBhStock  '1011','','2016-11-1','2016-11-17','',3
   
*/
CREATE proc [dbo].[p_GetBaiHuoSaleCreateBhStock]
@cStoreNo varchar(32),
@cStoreName varchar(64),
@dDate1 datetime,
@dDate2 datetime,
@cTermID varchar(32),
@dDay int
as
begin 
	if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	create table #temp_Goods(cGoodsNo varchar(32))
	exec('
	   insert into #temp_Goods(cGoodsNo)
	  -- select cGoodsNo 
	  -- from t_cStoreGoods a
			--where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNo=''0110011''
	  
	   select cGoodsNo 
	   from t_cStoreGoods a,U_key.dbo.temp_GoodsTypeNobh'+@cTermID+' b
			where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 
			and ISNULL(a.bUnStock,0)=0
			and ISNULL(a.bfresh,0)=0  			
	 ')
	
	declare @Day int

	set @Day=(DATEDIFF ( DAY , @dDate1 , @dDate2 ))+1
    declare @Pos_Sale varchar(16)
    set @Pos_Sale=(select top 1 Pos_Sale from t_WareHouse where cStoreNo=@cStoreNo)
    
   

    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate1'))is not null  drop table #temp_cGoodsSaleDate1
	create table #temp_cGoodsSaleDate1(cGoodsno varchar(32),fQty money,fQty_zj money,fQty_tj money)
 
    /*
    
	exec('
	insert into #temp_cGoodsSaleDate1(cGoodsno,fQty)
	select a.cGoodsno,fQty=SUM(a.fQuantity) 
	from '+@Pos_Sale+'.dbo.t_SaleSheetDetail a,#temp_Goods b
	with (nolock) 
	where  dSaleDate between '''+@dDate1+''' and '''+@dDate2+''' and a.cGoodsno=b.cGoodsno  
	and a.cStoreNo='''+@cStoreNo+'''  
	group by a.cGoodsno
    ')
    
    */
    
    exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate1,@dDate2,''
    
    
    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
	create table #temp_cGoodsSaleDate(cGoodsno varchar(32),fQty money)
	insert into #temp_cGoodsSaleDate(cGoodsno,fQty)
	select a.cGoodsNo,fQty=isnull(b.fQty,0) 
	from #temp_Goods a left join #temp_cGoodsSaleDate1 b
	on a.cGoodsNo=b.cGoodsno
	
  
    ---生鲜包装转换
    update a
	set a.cGoodsno=b.cGoodsNo_minPackage
	from #temp_cGoodsSaleDate a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
 
	  
	--获取每日的平均值
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateAvg'))is not null  drop table #temp_cGoodsSaleDateAvg
	select cGoodsNo,fQty=SUM(fQty)/@Day 
	into #temp_cGoodsSaleDateAvg
	from #temp_cGoodsSaleDate
	group by cGoodsNo
    
    --- 单号
      declare @SheetNo varchar(32)
      set @SheetNo=(select sheetno=dbo.f_GenBhsheetnoApply(YEAR(getdate()),@cStoreNo))
    
	  if (select OBJECT_ID('tempdb..#temp_GoodsList'))is not null  drop table #temp_GoodsList
	  create table #temp_GoodsList( cSheetno varchar(32),iLineNo [bigint] IDENTITY(1,1) NOT NULL,cGoodsNo varchar(32),
	  cGoodsName varchar(64),cBarcode varchar(32),cUnitedNo varchar(32),  
	  fQuantity money,fInPrice money,fInMoney money,cUnit varchar(32),cSpec varchar(32),fQty_Cur money,fQty money,
	  fPreservationDown money,fPreservation_Soft money,fPreservationUp money,fQty_Order money,fSaleQty money,beizhu varchar(64))
	  
	  declare @cWhNo varchar(32)
	  declare @cWh varchar(32)
	  
	  select top 1 @cWhNo=cwhNo,@cWh=cwh from t_WareHouse where cStoreNo=@cStoreNo
 
	  --insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,cSpec)
	  --select @SheetNo,a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,b.fCKPrice,a.fQty*b.fCKPrice,b.cUnit,b.cSpec
	  --from #temp_cGoodsSaleDateAvg a,t_Goods b
	  --where a.cGoodsNo=b.cGoodsNo
	  
	  if (select OBJECT_ID('tempdb..#temp_GoodsList_0'))is not null  drop table #temp_GoodsList_0
	  select sheetno=@SheetNo,a.cGoodsNo,fQty=isnull(b.fQty,0)
	  into #temp_GoodsList_0
	  from t_Goods a,#temp_cGoodsSaleDateAvg b
	  where a.cGoodsNo=b.cGoodsno
	  
	  insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,
	  cSpec,fQty_Cur,fPreservationDown,fQty,fPreservationUp,fPreservation_Soft)
	  select @SheetNo,a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,
	  fCKPrice=case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end,
	  a.fQty*(case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end),
	  b.cUnit,b.cSpec,fQty_Cur=0,
	  fPreservationDown,fQty,b.fPreservationUp,b.fPreservation_soft
	  from #temp_GoodsList_0 a,t_cStoreGoods b
	  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo 
	  and (isnull(b.fPreservationDown,0)>0 or isnull(b.fPreservation_soft,0)>0 or isnull(a.fQty,0)>0)
	  and ISNULL(b.bUnStock,0)=0
	  and b.cBarcode not like '%X%'
	   
	   
	  declare @dDate varchar(32)
 
	  set @cWHno=(select cWhNo from t_WareHouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1)

      set @dDate=dbo.getDayStr(GETDATE())
		 				
      exec [P_x_SetCheckWh_byGoodsType_logCurQty] @cStoreNo,@dDate,@dDate,@cWHno		  
	 		  
	  update a
	  set a.fQty_Cur=b.EndQty
	  from #temp_GoodsList a,t_goodsKuCurQty_wei b
	  where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo
 
	  -- 小数点进1
	  --update #temp_GoodsList set fQuantity=CEILING(fQuantity)
	  --where cUnit not in ('kg','500g')
	  
	  ---获取在途的补货数量
	  
	  if (select OBJECT_ID('tempdb..#temp_GoodsList_Order'))is not null  drop table #temp_GoodsList_Order
	  select b.cGoodsNo,fQty_Order=SUM(b.fQuantity) 
	  into #temp_GoodsList_Order
	  from WH_BhApply a,WH_BhApplyDetail b  
	  where a.dDate>GETDATE()-15 and a.cSheetno=b.cSheetno 
	  and a.cStoreNo=@cStoreNo 
	  and ISNULL(bExamin,0)=1   -- 表示门店已审核
	  and ISNULL(bPeisong,0)=0  -- 表示总部未配送
	  group by b.cGoodsNo 
	  union all
	  select b.cGoodsNo,fQty_Order=SUM(b.fQuantity) 	 
	  from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
	  where a.dDate>GETDATE()-15 and a.cSheetno=b.cSheetno 
	  and a.cCustomerNo=@cStoreNo 
	  and ISNULL(bExamin,0)=1   -- 表示已审核
	  and ISNULL(bOutYH,0)=0  -- 表示未分拣。
	  group by b.cGoodsNo 
	  union all
	  select b.cGoodsNo,fQty_Order=SUM(b.fQuantity) 	 
	  from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
	  where a.dDate>GETDATE()-15 and a.cSheetno=b.cSheetno 
	  and a.cCustomerNo=@cStoreNo 
	  and ISNULL(bExamin,0)=1   -- 表示已审核
	  and ISNULL(bOutYH,0)=1  -- 表示已分拣。
	  and ISNULL(bReceive,0)=0  -- 表示门店未收货
	  group by b.cGoodsNo 
	  
	  ---生鲜包装转换
      update a
	  set a.cGoodsno=b.cGoodsNo_minPackage,fQty_Order=a.fQty_Order*b.fQty_minPackage
	  from #temp_GoodsList_Order a,t_Goods b
	  where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
      
	  --- 修改在途数量
	  update a set a.fQty_Order=b.fQty_Order
	  from #temp_GoodsList a,
	  (select cGoodsNo,fQty_Order=SUM(fQty_Order)  
	  from #temp_GoodsList_Order group by cGoodsNo) b
	  where a.cGoodsNo=b.cGoodsNo  
	  
      
	  
	  ----判断当前平均销量*可销天数= 可销售库存    与当前库存比较
	   
	  --- 预销售库存>当前库存 时 ，补货数量=库存上限-在途数量
	 
	  -- 当 当前库存＜库存下限是  ， 当前库存>0 时  补货数量=库存上限-当前库存-在途数量
	  update #temp_GoodsList
	  set  fQuantity=0
	  
	  update #temp_GoodsList
	  set  fQuantity=isnull(fPreservationUp,0)-isnull(fQty_Cur,0)-ISNULL(fQty_Order,0)
	  where  isnull(fQty_Cur,0)<ISNULL(fPreservationDown,0)
	  and ISNULL(fQty_Cur,0)>=0
	  
	  
	  ---预销库存数
	  update #temp_GoodsList
	  set  fSaleQty=round(isnull(fQty*@dDay,0),0)
	  
	  -- 当 当前库存<0 时。。  补货数量=最高上限-在途数量
	  update #temp_GoodsList
	  set  fQuantity=isnull(fPreservationUp,0)-ISNULL(fQty_Order,0)
	  where ISNULL(fQty_Cur,0)<0
	  --- 处理补货数量有异常的。。 统一改为0 
	  
	  update #temp_GoodsList
	  set  fQuantity=0
	  where  ISNULL(fQuantity,0)<0
	  
	  ---- 小转大。。
	  /* 
	  if (select OBJECT_ID('tempdb..#temp_GoodsList_MintoMax'))is not null  drop table #temp_GoodsList_MintoMax
	  select a.cGoodsNo,a.fQuantity,cGoods_Parent=b.cGoodsNo,fQty_minPackage,
	  fQty=ROUND(a.fQuantity/b.fQty_minPackage, 0, 1),fQty_left=a.fQuantity-(ROUND(a.fQuantity/b.fQty_minPackage, 0, 1))*fQty_minPackage,
	  fQtySale=ROUND(a.fQty/b.fQty_minPackage, 0, 1),fQtySale_left=a.fQty-(ROUND(a.fQty/b.fQty_minPackage, 0, 1))*fQty_minPackage
	  into #temp_GoodsList_MintoMax
	  from #temp_GoodsList a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo_minPackage
	  and ISNULL(b.bUnStock,0)=0
	  and b.cBarcode not like '%X%'
	  and isnull(b.bWeight,0)=0
	  
	  --- 移除包装完的最小商品信息
      
	  delete a 
	  from #temp_GoodsList a,#temp_GoodsList_MintoMax b
	  where a.cGoodsNo=b.cGoodsNo and b.fQty_left=0
	  
	  --- 修改包装 余数
	  update a set a.fQuantity=b.fQty_left,a.fQty=b.fQtySale_left
	  from #temp_GoodsList a,#temp_GoodsList_MintoMax b
	  where a.cGoodsNo=b.cGoodsNo  
      
      
	  ---插入大包 
	  insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,
	  cSpec,fQty_Cur,fPreservationDown,fQty,fPreservationUp,fPreservation_Soft)	  
	  select @SheetNo,a.cGoods_Parent,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,b.fCKPrice,a.fQty*b.fCKPrice,b.cUnit,b.cSpec,fQty_Cur=0,
	  fPreservationDown=b.fPreservationDown,a.fQtySale,b.fPreservationUp,b.fPreservation_soft
	  from #temp_GoodsList_MintoMax a,t_cStoreGoods b
	  where b.cStoreNo=@cStoreNo and a.cGoods_Parent=b.cGoodsNo 
	  */ 
    
	  exec('
	     insert into U_key.dbo.temp_GoodsListBh'+@cTermID+'(cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQty,fQuantity,
	     fInPrice,fInMoney,cUnit,cSpec,fQty_Cur,fQtyDown,fPreservationUp,fPreservation_soft,fQty_Order,fSaleQty)
	     select cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQty,fQuantity=round(fQuantity,0),fInPrice,fInMoney=round(fQuantity,0)*fInPrice,cUnit,cSpec,fQty_Cur,
	     fPreservationDown,fPreservationUp,fPreservation_soft,fQty_Order,fSaleQty
         from #temp_GoodsList order by iLineNo
	  ')
	  
	
    
end
GO
