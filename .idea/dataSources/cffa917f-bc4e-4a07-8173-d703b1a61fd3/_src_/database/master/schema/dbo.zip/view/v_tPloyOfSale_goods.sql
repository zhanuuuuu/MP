create view v_tPloyOfSale_goods
as
  select cPloyNo,a.cGoodsNo,b.cGoodsName,fQuantity_Ploy,fPrice_SO,dDateStart,cTimeStart,
         dDateEnd,cTimeEnd,iPriority,bSO,bPresent,cPresentPloyNo,cPloyTypeNo,cPloyTypeName,
         bEnabled,cUnitedNo,cGoodsTypeno,cGoodsTypename,cBarcode,cUnit,cSpec,
         fNormalPrice,cProductUnit,cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,
         cLevel,bSuspend,bDeling,bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,
         fVipScore,bProducted,cProductNo
  from t_PloyOfSale a left join t_Goods b
                      on a.cGoodsNo=b.cGoodsNo

GO
