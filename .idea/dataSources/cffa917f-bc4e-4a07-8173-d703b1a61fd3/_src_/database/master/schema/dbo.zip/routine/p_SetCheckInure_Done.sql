








CREATE          procedure [dbo].[p_SetCheckInure_Done]
@cCheckTaskno varchar(32),
@dCheckDate datetime
as
begin
	select distinct a.cGoodsNo 
	into #tempWh_CheckWhDetail  /*bChecked is null 表示本次盘点为待生效的盘点*/
	from dbo.wh_CheckWhDetail a
	left join dbo.wh_CheckWh	b
	on a.cSheetno=b.cSheetno
	where b.cSupplierNo=@cCheckTaskno and b.cSheetno is not null and a.bChecked is null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno/*记录当前即将生效的盘点任务号，以便反操作用*/
	from wh_CheckWhDetail a
	left join #tempWh_CheckWhDetail b
	on a.cGoodsNo=b.cGoodsNo and a.bChecked=0
	where a.bChecked=0  and b.cGoodsNo is not null 
				and a.cSheetno not in 
						(select cSheetno from dbo.wh_CheckWh where cSupplierNo=@cCheckTaskno)
	
	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_EffusionWhDetail a
	right join dbo.wh_EffusionWh b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_ExchangeDetail a
	right join dbo.wh_Exchange b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_InWarehouseDetail a
	right join dbo.wh_InWarehouse b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_LossWarehouseDetail a
	right join dbo.wh_LossWarehouse b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_OutWarehouseDetail a
	right join dbo.wh_OutWarehouse b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_RbdWarehouseDetail a
	right join dbo.wh_RbdWarehouse b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.WH_ReturnGoodsDetail a
	right join dbo.WH_ReturnGoods b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_TfrWarehouseDetail a
	right join dbo.wh_TfrWarehouse b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_PackDetail a
	right join dbo.wh_Pack b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from dbo.wh_DivideWhDetail a
	right join dbo.wh_Divide b
	on a.cSheetno=b.cSheetno and isnull(a.bChecked,0)=0 and b.dDate<=@dCheckDate
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where a.cSheetno is not null and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cChkOperno=@cCheckTaskno
	from t_SaleSheet a
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where isnull(a.bChecked,0)=0 and a.dSaleDate<=@dCheckDate and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from t_SaleSheetDetail a
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where isnull(a.bChecked,0)=0 and a.dSaleDate<=@dCheckDate and c.cGoodsNo is not null

	update a set a.bChecked=1,a.cCheckNo=@cCheckTaskno
	from t_SaleSheet_day a
	right join #tempWh_CheckWhDetail c
	on  c.cGoodsNo=a.cGoodsNo
	where isnull(a.bChecked,0)=0 and a.dSaleDate<=@dCheckDate and c.cGoodsNo is not null

	update dbo.t_CheckTast set bChecked=0/*将当前盘点任务设置成激活状态*/
	where cCheckTaskNo=@cCheckTaskno

	update dbo.t_CheckTast set bChecked=1/*将以前的盘点任务设置成过期标志*/
	where cCheckTaskNo<>@cCheckTaskno and dCheckTask<@dCheckDate

	update dbo.t_CheckTast set bChecked=null/*将后面的盘点任务设置成休眠标志*/
	where cCheckTaskNo<>@cCheckTaskno and dCheckTask>@dCheckDate

	update wh_CheckWhDetail set bChecked=0,cCheckNo=@cCheckTaskno
	where bChecked is null 
				and cSheetno  in 
						(select distinct cSheetno from dbo.wh_CheckWh where cSupplierNo=@cCheckTaskno)

	update a set a.bChecked=b.bChecked
  from wh_CheckWh a left join 
  (select distinct cSheetno,bChecked from wh_CheckWhDetail) b
  on a.cSheetno=b.cSheetno
 
end


GO
