create view v_Client
as
select cClientID=cClentNo,cName=cClentName,
cSex,cID,cMB=cMobile,cTel=cPhone,cZoneID,
cAddr=cAddress,iUnit,dCreated,cClientID_Main
from t_Client
GO
