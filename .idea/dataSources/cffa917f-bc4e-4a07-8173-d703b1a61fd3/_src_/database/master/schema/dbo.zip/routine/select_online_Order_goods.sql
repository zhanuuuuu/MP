 CREATE proc [dbo].[select_online_Order_goods]
 
  @cSheetno varchar(50)
  as
  select a.cSheetno ,a.cStoreNo,a.UserNo,a.Date_time,a.Reality_All_Money,
         b.cGoodsNo,b.cGoodsName,b.Last_Price,b.RealityNum,b.Reality_Money,
         c.cBarcode,c.fNormalPrice,c.bWeight,c.cStoreName,
         d.Describe
         
  from Simple_online.dbo.Order_Table a ,Simple_online.dbo.Order_Details b,
       Posmanagement_main.dbo.t_cStoreGoods c,Simple_online.dbo.Pay_way_Table d
       
  
  where a.cSheetno=b.cSheetno  and a.cStoreNo=c.cStoreNo  and c.cGoodsNo=b.cGoodsNo
        and a.Pay_wayId=d.Pay_wayId and a.cSheetno=@cSheetno
 GO
