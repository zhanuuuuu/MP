 
/*

 
 exec  [p_GetMerchantOneDevice] '2016031916515465095992','自动售货机%20TSO001-北京-001','',''
 
*/

/*
    注册返回状态：1表示当前设备名称已存在；           
            0表示添加异常； 
            5是添加成功
 
*/
 
create  proc [dbo].[p_GetMerchantOneDevice]
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@Name varchar(64),    --设备名称  
@fMoney varchar(64),      -- 营业额
@dDateToDate varchar(64)
as
begin
   
   DECLARE @bgnDate varchar(32)
   DECLARE @endDate varchar(32)
   DECLARE @fMoney0 varchar(16) 
   DECLARE @strSql0 varchar(256)
   SET @strSql0='where 1=1 '
   DECLARE @strSql1 varchar(256)
   SET @strSql1='where 1=1 '
   
   IF @dDateToDate<>'' 
   BEGIN
      set @bgnDate=left(@dDateToDate,10)      
      set @bgnDate=right(@dDateToDate,10)     
      set @strSql0=@strSql0+' and zdriqi between '''+@bgnDate+''' and '''+@bgnDate+''''
   end else
   BEGIN   
      set @strSql0=@strSql0+' and zdriqi between '''+dbo.getDayStr(getdate()-30)+''' and '''+dbo.getDayStr(getdate())+''''
   end
   
   if @fMoney<>'' 
   begin     
      set @fMoney0=replace(@fMoney0,'-',' and ')      
      set @strSql1=@strSql1+' and fMoney between '+@fMoney0+''
   end
   
   declare @PosId varchar(32) 
   select @PosId=posid from t_posstation where cStoreNo=@Merchantid and posname=@Name
    if (select object_id('tempdb..#tmp_SaleList'))is not null
	begin
	  drop table #tmp_SaleList
	end
	
    create table #tmp_SaleList(dSaleDate datetime,fMoney money)
  
   exec('
      insert into #tmp_SaleList(dSaleDate,fMoney)
      select zdriqi,fMoney=sum(shishou) from jiesuan
      '+@strSql0+' and cStoreNo='''+@Merchantid+''' and PosID='''+@PosId+'''
      group by zdriqi
   ')
   
   select posname as name,posid,iType,cAddRess as address,cMapLocation as MapLocation,
   cDescription as Description,dCreateDate as deployDate ,totalSalesAmount=(SELECT sum(fMoney) FROM #tmp_SaleList)
   from t_posstation where cStoreNo=@Merchantid and posname=@Name 
   
   select dSaleDate,fMoney from #tmp_SaleList
   
end
 
--201512081042459907426
--2016031852549-10007
GO
