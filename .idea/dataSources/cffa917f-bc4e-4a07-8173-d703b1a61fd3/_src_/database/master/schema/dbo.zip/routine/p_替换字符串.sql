/*
select * 
into #temp_Goods_11
from t_Goods
where isnull(bWeight,0)=1
*/
create procedure p_替换字符串
as
select cGoodsNo,cGoodsName,substring(cGoodsName,1,patindex('%（进）%',cGoodsName)-1) 
from #temp_Goods_11
where cGoodsName like '%（进）%'

update a
set a.cGoodsname=b.cGoodsname
from t_Goods a,#temp_Goods_11 b
where a.cGoodsNo=b.cGoodsNo


/*
update #temp_Goods_11
set cGoodsName='采购.'+substring(cGoodsName,1,patindex('%（进）%',cGoodsName)-1) 
where cGoodsName like '%（进）%'

select * from #temp_Goods_11
where cGoodsName like '%采购.%'
*/
GO
