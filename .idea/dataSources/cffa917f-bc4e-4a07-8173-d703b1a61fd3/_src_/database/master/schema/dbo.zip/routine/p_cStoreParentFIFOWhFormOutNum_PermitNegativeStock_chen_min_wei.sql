 

/*
先进先出算库存-允许负库存

declare @return int       
exec [p_cStoreFIFOWhFormOutNum_PermitNegativeStock_chen_min_wei] 
'110019',17,'PSOT2016001-000012','000','2016-4-30',1,'01',20,@return output,1,38,760,0,0,''
select @return

*/

CREATE proc [dbo].[p_cStoreParentFIFOWhFormOutNum_PermitNegativeStock_chen_min_wei]
@cGoodsNo varchar(50),    --商品名称
@iAttribute int,          --0入库；1出库；2返厂；3顾客退货入库；4调拨；5报损；6报益；7差价单  17 总部配送出库  18  退货入库  19门店退货出库
@cSheetNo varchar(32),    --单据号
@cStoreNo varchar(32),    --单据号
@SheetDate datetime,      --单据日期
@iLine int,               --商品在单据中的行号
@cWhNo varchar(32),
@QtyOut money,              --出库数量 
@Return int output,        --返回1：库存不足2:内部错误3:数量为0
@bPermitNegativeStock int,  --(0:不允许负库存 1：允许负库存),
@fPrice_sale money,        --出场单价
@fMoney_sale money,        --出场金额
@bAuditing bit=null,
@Ratio money=0,
@RatioType varchar(1)=null  ---   合同扣率为1、商品扣率为2、特价扣率3   格式：1+2+3
as
/*
declare @cGoodsNo varchar(50)    --商品名称
declare @iAttribute int          --0入库；1出库；2返厂；3顾客退货入库；4调拨；5报损；6报益；7差价单
declare @cSheetNo varchar(32)    --单据号
declare @SheetDate datetime      --单据日期
declare @iLine int               --商品在单据中的行号
declare @cWhNo varchar(32)
declare @QtyOut money             --出库数量 
declare @Return int         --返回1：库存不足2:内部错误3:数量为0
declare @bPermitNegativeStock int  --(0:不允许负库存 1：允许负库存),
declare @fPrice_sale money        --出场单价
declare @fMoney_sale money        --出场金额
select @cGoodsNo='10001',@iAttribute=1,@cSheetNo='复合测试',@SheetDate='2010-07-29',
@iLine=99,@cWhNo='01',@QtyOut=1,@Return=0,@bPermitNegativeStock=1,@fPrice_sale=2,@fMoney_sale=20

*/
if @QtyOut<=0 
begin
  set @Return=3 
  select a01=3
  return
end
set @Return=0

set @bPermitNegativeStock=1

--此商品拆分为最小单位商品编码
declare @cGoodsNo_MinGoodsNo varchar(50)
--此商品包装系数
declare @fQty_MinGoods money
--拆分成最小单位商品后的发出数量
declare @fQtyOut_change money

declare @bFresh bit

 
-----生鲜商品不转化包装
select @cGoodsNo_MinGoodsNo=case when isnull(bfresh,0)=0 then 
     case when isnull(cGoodsNo_minPackage,'')='' then cGoodsNo else cGoodsNo_minPackage end
      else cGoodsNo end,
@fQty_MinGoods=case when isnull(bfresh,0)=0 then isnull(fQty_MinPackage,1) else 1 end,
@bFresh=ISNULL(bfresh,0)
from t_goods
where cGoodsNo=@cGoodsNo


if @cGoodsNo<>@cGoodsNo_MinGoodsNo
begin
  set @fQtyOut_change=@fQty_MinGoods*@QtyOut
  set @fPrice_sale= case when @fQty_MinGoods<>0 then  @fPrice_sale/@fQty_MinGoods else @fPrice_sale end
end else
begin
  set @fQtyOut_change=@QtyOut
end

declare @bStorage int
select @bStorage=isnull(bStorage,0) from t_Goods where  cgoodsno=@cGoodsNo_MinGoodsNo
 
if @bStorage<>1 
begin
  return
end
--先得出该货物的库存是否够 
if (select object_id('tempdb..#tmpWhForm'))is not null
begin
  drop table #tmpWhForm
end
if (select object_id('tempdb..#tmpSubQty'))is not null
begin
  drop table #tmpSubQty
end

declare @cStoreName varchar(32)
set @cStoreName=(select cStoreName from t_Store where cStoreNo=@cStoreNo)

declare @SheetType varchar(32)
set @SheetType=case @iAttribute 
                 when 0 then '入库单(补充)'
                 when 1 then '出库单(补充)'
                 when 2 then '返厂单(补充)'
                 when 3 then '顾客退货入库(补充)'
                 when 4 then '调拨单(补充)'
                 when 5 then '报损单(补充)'
                 when 6 then '报溢单(补充)'
                 when 7 then '差价单(补充)'
                 when 8 then '原料出库(补充)'
                 when 9 then '成品入库(补充)'
                 when 10 then '日结(补充)'
                 when 11 then '盘点溢出(补充)'
                 when 12 then '盘点报损(补充)'
                 when 13 then 'Pos客退(补充)'
                 when 16 then '系统初始化(补充)'
                 
                 when 17 then '配送出库单(补充)'
                 when 19 then '退货出库单(补充)'
       else
                 ''
end
 
begin try
 begin tran

 if @bPermitNegativeStock=1 --=1允许负库存
 begin
    --出库时如果成本表中没有此商品,则从t_goods表中去零售价
	if not exists(select cGoodsNo from t_wh_form_log 
	               where cGoodsNo=@cGoodsNo_MinGoodsNo 
	               and cGoodsNo_Parent=@cGoodsNo and cStoreNo=@cStoreNo
	               and isnull(cWhNo,'')=@cWhNo )
	begin
		insert into t_wh_form_log
		(业务日期,
		  cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cSummary,fPrice_in,
		  fQty_in,fMoney_in,
		  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
		  cSupplierNo,cSupplier,iSerNo,
          cGoodsNo_Parent,fQty_minPackage,fQty_In_Parent,库存标志,cStoreNo,cStoreName
		)
		select @SheetDate,cGoodsNo,@SheetDate,@cSheetNo,@iLine,@iAttribute,@SheetType,
		fNormalPrice=case when ISNULL(fCKPrice,0)=0 then 
		case when ISNULL(fPrice_Contract,0)=0 
		then fNormalPrice else fPrice_Contract end else fckprice end,
		0,0,
		0,fQty_out=0,fMOney_out=0,0,fQty_left=0,fMoney_left=0,@cWhNo,cSupNO,cSupName,0,
        @cGoodsNo,@fQty_MinGoods,@QtyOut,1,@cStoreNo,@cStoreName
		from t_Goods
		where  cGoodsNo=@cGoodsNo_MinGoodsNo

        update t_wh_form_log
        set iSerNo=iMyIdentity
        where cGoodsNo=@cGoodsNo_MinGoodsNo and isnull(iSerNo,0)=0
        and cStoreNo=@cStoreNo

	end
 end



	select cGoodsNo,iSerNo,iMyIdentity,fPrice_In=isnull(fPrice_In,0),fQty_in=isnull(fQty_in,0),
    fQty_Out=isnull(fQty_Out,0),cWhNo,fTmpQtyOut=cast(fQty_Out as money),
    cGoodsNo_Parent=isnull(cGoodsNo_Parent,cGoodsNo),fQty_MinGoods=isnull(fQty_minPackage,1),
    iOrderNo=case when isnull(cGoodsNo_Parent,cGoodsNo)=cGoodsNO then 1 else 0 end
	into #tmpWhForm
	from t_wh_form_log
	where cGoodsNo=@cGoodsNo_MinGoodsNo --and isnull(fQty_in,0)!=isnull(fQty_Out,0)
	and cStoreNo=@cStoreNo
	and isnull(cWhNo,'')=@cWhNo
	--2016-02-19   去掉价格排序：低价优先
	--order by fPrice_In,iOrderNo,iSerNo
     order by iOrderNo,iSerNo
 

	declare @spare float --剩余库存 
	select @spare=isnull((sum(isnull(fQty_in,0))-sum(isnull(fQty_Out,0))),0) 
	from #tmpWhForm 
	where cGoodsNo=@cGoodsNo_MinGoodsNo 
	group by cGoodsNo

	set @spare=isnull(@spare,0)


    declare @Maxid int
    declare @MaxRow bigint
    declare @tmpLeafSum money
    
    declare @tmpRemain money  --扣除剩余数量
	declare @Cur_iSerNo bigint
	declare @Cur_fQtyLeft money
	declare @Cur_fQtyOut money
	declare @Cur_fQtyIn money
	
	declare @Exist1 int
	

     
--此商品为最小商品--先出单品，再出复合
if @cGoodsNo=@cGoodsNo_MinGoodsNo
begin
   if(@spare>=@fQtyOut_change) 
	begin  --1 begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
		
		                                                  --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_WhForm')
  		begin
  		  close Cur_WhForm
          deallocate Cur_WhForm
  		end 

		
		declare Cur_WhForm cursor for
		select iSerNo,FQtyLeft=fQty_in-fQty_Out,fQty_out,fQty_in
		from #tmpWhForm
		--2016-02-19   去掉价格排序：低价优先
		--order by fPrice_In,iOrderNo desc,iSerNo 
        order by iOrderNo desc,iSerNo


		open Cur_WhForm
	    
		select @tmpRemain=0,@Cur_iSerNo=0,@Cur_fQtyLeft=0,@Cur_fQtyOut=0,@Cur_fQtyIn=0
		set @tmpRemain=@fQtyOut_change
	    
		fetch next from Cur_WhForm into @Cur_iSerNo,@Cur_fQtyLeft,@Cur_fQtyOut,@Cur_fQtyIn

		while @@fetch_status=0
		begin  --Cur begin
			if @Cur_fQtyOut!=@Cur_fQtyIn
			begin
			   if (@Cur_fQtyLeft>=@tmpRemain)and (@tmpRemain>0)
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=fQty_Out+@tmpRemain
				  where iSerNo=@Cur_iSerNo
		          
				  set @tmpRemain=0
			   end 
			   if(@Cur_fQtyLeft<@tmpRemain)and (@tmpRemain>0)
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=@Cur_fQtyIn
				  where iSerNo=@Cur_iSerNo
		 
				  set @tmpRemain=@tmpRemain-@Cur_fQtyLeft
			   end
			   if @tmpRemain<0
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=fQty_out
				  where iSerNo=@Cur_iSerNo
			   end
			 end
			 fetch next from Cur_WhForm into @Cur_iSerNo,@Cur_fQtyLeft,@Cur_fQtyOut,@Cur_fQtyIn  
		       
		end --Cur end

		close Cur_WhForm
		deallocate Cur_WhForm
		
	end else  --1 end
	begin  --2 begin
      if @bPermitNegativeStock=1
      begin
		  if (select object_id('tempdb..#tmpId0'))is not null
		  begin
			 drop table #tmpId0
		  end
		  

		  --是否存在fQty_in<fQty_Out的记录
     
          if exists
          (
             select iSerNo
             from #tmpWhForm
             where fQty_in<fQty_Out
          )
          begin
             select @MaxRow=iSerNo
             from #tmpWhForm
             where fQty_in<fQty_Out
             
             update #tmpWhForm
			 set fTmpQtyOut=fQty_Out+@fQtyOut_change
			 where iSerNo=@MaxRow
			 and cGoodsNo=@cGoodsNo_MinGoodsNo
   
          end else
          begin
              select ID=identity(int,1,1),iSerNo,FQtyLeft=fQty_in-fQty_Out
			  into #tmpId0
			  from #tmpWhForm
			  --where iOrderNo=1
			  order by iSerNo

			  select @Maxid=max(id) from  #tmpId0
			  set @MaxRow=0
			  select @MaxRow=iSerNo from  #tmpId0  where id=@Maxid
			  update a
			  set a.fTmpQtyOut=@fQtyOut_change-(select isnull((sum(fQty_In)-sum(fQty_Out)),0) 
												 from #tmpWhForm where iSerNo<>@MaxRow  )+a.fQty_Out
			  from #tmpWhForm a
			  where iSerNo=@MaxRow
			  and a.cGoodsNo=@cGoodsNo_MinGoodsNo
			  --and iOrderNo=1

			  update #tmpWhForm
			  set fTmpQtyOut=fQty_in  
			  where  iSerNo<>@MaxRow
			  and cGoodsNo=@cGoodsNo_MinGoodsNo

          end
      end else --@bPermitNegativeStock
      begin
        --不允许负库存
        rollback
        set @Return=-1 
        select a01=-1
        return
      end
	end --2 end

end
	print 10001
--此商品需要拆分   cGoodsNo_Parent,fQty_MinGoods
if @cGoodsNo<>@cGoodsNo_MinGoodsNo
begin
    if(@spare>=@fQtyOut_change) 
	begin  --1 begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
			                                                  --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_WhForm')
  		begin
  		  close Cur_WhForm
          deallocate Cur_WhForm
  		end 
		
		declare Cur_WhForm cursor for
		select iSerNo,FQtyLeft=fQty_in-fQty_Out,fQty_out,fQty_in
		from #tmpWhForm 
--2016-02-19   去掉价格排序：低价优先
		--order by fPrice_In,iOrderNo,iSerNo 
        order by  iOrderNo,iSerNo
        
		open Cur_WhForm	    
		
		select @tmpRemain=0,@Cur_iSerNo=0,@Cur_fQtyLeft=0,@Cur_fQtyOut=0,@Cur_fQtyIn=0
		set @tmpRemain=@fQtyOut_change
	    
		fetch next from Cur_WhForm into @Cur_iSerNo,@Cur_fQtyLeft,@Cur_fQtyOut,@Cur_fQtyIn

		while @@fetch_status=0
		begin  --Cur begin
			if @Cur_fQtyOut!=@Cur_fQtyIn
			begin
			   if (@Cur_fQtyLeft>=@tmpRemain)and (@tmpRemain>0)
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=fQty_Out+@tmpRemain
				  where iSerNo=@Cur_iSerNo
		          
				  set @tmpRemain=0
			   end 
			   if(@Cur_fQtyLeft<@tmpRemain)and (@tmpRemain>0)
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=@Cur_fQtyIn
				  where iSerNo=@Cur_iSerNo
		 
				  set @tmpRemain=@tmpRemain-@Cur_fQtyLeft
			   end
			   if @tmpRemain<0
			   begin
				  update #tmpWhForm
				  set fTmpQtyOut=fQty_out
				  where iSerNo=@Cur_iSerNo
			   end
			 end
			 fetch next from Cur_WhForm into @Cur_iSerNo,@Cur_fQtyLeft,@Cur_fQtyOut,@Cur_fQtyIn  
		       
		end --Cur end

		close Cur_WhForm
		deallocate Cur_WhForm
		
	end else  --1 end
	begin  --2 begin
      if @bPermitNegativeStock=1
      begin
		  if (select object_id('tempdb..#tmpId1'))is not null
		  begin
			 drop table #tmpId1
		  end

		  
		  --如果存在单品，则扣除最后一条单品为负库存
		  --是否存在fQty_in<fQty_Out的记录
     
          if exists
          (
             select iSerNo
             from #tmpWhForm
             where fQty_in<fQty_Out
          )
          begin
             select @MaxRow=iSerNo
             from #tmpWhForm
             where fQty_in<fQty_Out
             
             update #tmpWhForm
			 set fTmpQtyOut=fQty_Out+@fQtyOut_change
			 where iSerNo=@MaxRow
			 and cGoodsNo=@cGoodsNo_MinGoodsNo
   
          end else
          begin
              select ID=identity(int,1,1),iSerNo,FQtyLeft=fQty_in-fQty_Out
			  into #tmpId1
			  from #tmpWhForm
			  --where iOrderNo=1
			  order by iSerNo

			  select @Maxid=max(id) from  #tmpId1
			  set @MaxRow=0
			  select @MaxRow=iSerNo from  #tmpId1  where id=@Maxid
			  update a
			  set a.fTmpQtyOut=@fQtyOut_change-(select isnull((sum(fQty_In)-sum(fQty_Out)),0) 
												 from #tmpWhForm where iSerNo<>@MaxRow  )+a.fQty_Out
			  from #tmpWhForm a
			  where iSerNo=@MaxRow
			  and a.cGoodsNo=@cGoodsNo_MinGoodsNo


			  update #tmpWhForm
			  set fTmpQtyOut=fQty_in  
			  where  iSerNo<>@MaxRow
			  and cGoodsNo=@cGoodsNo_MinGoodsNo

          end
      end else --@bPermitNegativeStock
      begin
        --不允许负库存
        rollback
        set @Return=-1 
        select a01=-1
        return
      end
	end --2 end

end


--更新数据
	select a.cGoodsNo,a.iSerNo,a.fPrice_In,SubQty=b.fTmpQtyOut-a.fQty_Out,a.fQty_Left
	into #tmpSubQty
	from t_wh_form_log a,#tmpWhForm b
	where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and b.fTmpQtyOut!=b.fQty_Out
	and a.cStoreNo=@cStoreNo
	and a.cWhNo=b.cWhNo
	
 
/*---------------------正特价分开----------------*/	

			
	--      select * from #tmpWhForm
			
	--		select * from t_wh_form_log a,#tmpWhForm b
	--where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and b.fTmpQtyOut!=b.fQty_Out
	--and a.cWhNo=b.cWhNo
	
	update a
	set a.fPrice_Out=a.fPrice_In,a.fQty_Out=b.fTmpQtyOut,a.fMoney_Out=a.fPrice_In*b.fTmpQtyOut,
	a.fPrice_Left=a.fPrice_In,a.fQty_Left=a.fQty_In-b.fTmpQtyOut,a.fMoney_Left=(a.fQty_In-b.fTmpQtyOut)*a.fPrice_In,
	a.本日库存数量=a.fQty_In-b.fTmpQtyOut
	from t_wh_form_log a,#tmpWhForm b
	where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and b.fTmpQtyOut!=b.fQty_Out
	and a.cStoreNo=@cStoreNo
	and a.cWhNo=b.cWhNo

	
	--@Ratio money,
 --   @RatioType varchar(1)=null 
 
 ---@fQtyOut_change  都是小包装数量

		

   --处理fPrice_sale，fMoney_sale
   if (select object_id('tempdb..#FIFOLast'))is not null
   begin
     drop table #FIFOLast
   end
   
    select id=identity(int,1,1),a.cGoodsNo,a.iSerno,fPrice_Cost=a.fPrice_In,fQty_Cost=b.SubQty,
    --生鲜商品 采用当前单据发出成本
    fMoney_Cost=case when isnull(@bFresh,0)=0 then a.fPrice_In*b.SubQty else @fPrice_sale*b.SubQty end,  
    
	iAttribute=@iAttribute,cSheetNo=@cSheetNo,iLineNo=@iLine,fQty=b.fQty_Left,
	dDate_Sheet=@SheetDate,dDate_Account=getdate(),cWhNo=@cWhNo,
    fPrice_sale=isnull(@fPrice_sale,0),fMoney_sale=isnull(@fPrice_sale,0)*b.SubQty
    into #FIFOLast
	from #tmpWhForm a,#tmpSubQty b
	where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo
	and isnull(b.SubQty,0)<>0 and a.fTmpQtyOut!=a.fQty_Out
 
	
	if @iAttribute=10
	begin 
	    if isnull(@bAuditing,0)=0
	    begin
			update a
				set
				a.销售数量0=isnull(a.销售数量0,0)+b.fQty_Cost,a.销售金额0=isnull(a.销售金额0,0)+isnull(b.fMoney_sale,0),
				a.正价销售数量=isnull(a.正价销售数量,0)+isnull(b.fQty_Cost,0),
				a.正价销售金额=isnull(a.正价销售金额,0)+isnull(b.fMoney_sale,0),
				a.特价销售数量=isnull(a.特价销售数量,0),
				a.特价销售金额=isnull(a.特价销售金额,0),
				a.当日正价销售数量=isnull(a.当日正价销售数量,0)+isnull(b.fQty_Cost,0),
				a.当日正价销售金额=isnull(a.当日正价销售金额,0)+isnull(b.fMoney_sale,0),
				a.当日特价销售数量=isnull(a.当日特价销售数量,0),
				a.当日特价销售金额=isnull(a.当日特价销售金额,0)
				,a.库存标志=1,
				业务日期=@SheetDate,a.本日库存数量=a.fQty_left,
				合同扣率=case when isnull(@RatioType,0)=1 then @Ratio  else null end,
				特价扣率=case when isnull(@RatioType,0)=3 then @Ratio  else null end,
				单品扣率=case when isnull(@RatioType,0)=2 then @Ratio  else null end,
				执行扣率=case when isnull(@RatioType,0)=0 then @Ratio  else null end,  
				扣率金额=isnull(扣率金额,0)+(@Ratio/100)*b.fMoney_sale,
				扣率类别=case When PATINDEX('%'+@RatioType+'%',扣率类别)>0 then 扣率类别 else substring((isnull(扣率类别,'')+@RatioType),0,6) end
				from t_wh_form_log a,#FIFOLast b
				where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
				and a.cStoreNo=@cStoreNo
				and a.cWhNo=b.cWhNo
		end 
		if @bAuditing=1
	    begin
			update a
				set
				a.销售数量0=isnull(a.销售数量0,0)+b.fQty_Cost,a.销售金额0=isnull(a.销售金额0,0)+isnull(b.fMoney_sale,0),
				a.正价销售数量=isnull(a.正价销售数量,0),
				a.正价销售金额=isnull(a.正价销售金额,0),
				a.特价销售数量=isnull(a.特价销售数量,0)+isnull(b.fQty_Cost,0),
				a.特价销售金额=isnull(a.特价销售金额,0)+isnull(b.fMoney_sale,0),
				a.当日正价销售数量=isnull(a.当日正价销售数量,0),
				a.当日正价销售金额=isnull(a.当日正价销售金额,0),
				a.当日特价销售数量=isnull(a.当日特价销售数量,0)+isnull(b.fQty_Cost,0),
				a.当日特价销售金额=isnull(a.当日特价销售金额,0)+isnull(b.fMoney_sale,0)
				,a.库存标志=1,
				业务日期=@SheetDate,a.本日库存数量=a.fQty_left,
				合同扣率=case when isnull(@RatioType,0)=1 then @Ratio  else null end,
				特价扣率=case when isnull(@RatioType,0)=3 then @Ratio  else null end,
				单品扣率=case when isnull(@RatioType,0)=2 then @Ratio  else null end,
				执行扣率=case when isnull(@RatioType,0)=0 then @Ratio  else null end,  
				扣率金额=isnull(扣率金额,0)+(@Ratio/100)*b.fMoney_sale,
				扣率类别=case When PATINDEX('%'+@RatioType+'%',扣率类别)>0 then 扣率类别 else substring((isnull(扣率类别,'')+@RatioType),0,6) end
				from t_wh_form_log a,#FIFOLast b
				where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
				and a.cStoreNo=@cStoreNo
				and a.cWhNo=b.cWhNo
		end  
	end
    

    
    declare @tmpfMoney money
    set @tmpfMoney=0
    select @tmpfMoney=sum(fMoney_sale) from #FIFOLast
    
    if @tmpfMoney<>@fMoney_sale
    begin
      update #FIFOLast
      set fMoney_sale=fMoney_sale+(@fMoney_sale-@tmpfMoney)
      where [id]=1
    end
 
    
    declare @Pos_Cost varchar(32)
    set @Pos_Cost=(select top 1 Pos_Cost from t_WareHouse where cWhNo=@cWhNo)
   
    exec('
        insert into '+@Pos_Cost+'.dbo.t_Cost_distribute_Log
		(
		   cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,
		   iAttribute,cSheetNo,iLineNo,fQty,dDate_Sheet,dDate_Account,cWhNo,
		   fPrice_sale,fMoney_sale,cStoreNo,cStoreName
		)
		select cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,
		iAttribute,cSheetNo,iLineNo,fQty,dDate_Sheet,getdate(),cWhNo,
		fPrice_sale,fMoney_sale,'''+@cStoreNo+''','''+@cStoreName+'''
		from #FIFOLast
    ')
     
    if @@RowCount=0
   begin
     rollback 
     set @Return=-99  
     select a01=-99
     return
   end
   
   --2016-09-24 调整  
   /*
   declare @ICount int
   set @ICount=(select COUNT(*) from #FIFOLast )
   if @ICount=0 
   begin
      rollback 
      set @Return=-99  
      select a01=-99
      return
   end
   */
   --如果插入记录为0，则抛出异常
   
   
    	/*--------------2014-08-17----------------*/
  -------------------*2015-11-05调整以下*------------------------
	if @iAttribute=1   --- 表示出库  @SheetDate  单据日期
	begin 
		update a
		set a.出库数量0=b.fQty_Cost,a.出库金额0=b.fMoney_Cost,		 
		a.本日库存数量=a.fQty_Left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	
	if @iAttribute=19   --- 表示门店退货出库  @SheetDate  单据日期
	begin 
		update a
		set a.退货出库数量0=isnull(a.退货出库数量0,0)+isnull(b.fQty_Cost,0),a.退货出库金额0=isnull(a.退货出库金额0,0)+isnull(b.fMoney_Cost,0),		 
		a.本日库存数量=isnull(a.fQty_Left,0)
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	
	if @iAttribute=17   --- 表示总部配送出库单  @SheetDate  单据日期
	begin 
		update a
		set a.出库数量0=isnull(a.出库数量0,0)+isnull(b.fQty_Cost,0),a.出库金额0=isnull(a.出库金额0,0)+isnull(b.fMoney_Cost,0),			 
		a.本日库存数量=a.fQty_Left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	
	if @iAttribute=2   --- 表示返厂  @SheetDate  单据日期
	begin 		
		update a
		set a.返厂数量0= b.fQty_Cost,a.返厂金额0=b.fMoney_Cost,	 
		a.本日库存数量=a.fQty_left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	
	if @iAttribute=5   --- 表示报损  @SheetDate  单据日期
	begin 
	    update a
		set a.报损数量0=b.fQty_Cost,a.报损金额0=b.fMoney_Cost, 
		a.本日库存数量=a.fQty_left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo 
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	if @iAttribute=4   --- 表示调拨  @SheetDate  单据日期
	begin 
		update a
		set a.调拨出库数量0=b.fQty_Cost,a.调拨出库金额0=b.fMoney_Cost,	 
		a.本日库存数量=a.fQty_left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo 
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end
	if @iAttribute=8   --- 表示原料出库  @SheetDate  单据日期
	begin 
		update a
		set a.原料出库数量0=b.fQty_Cost,a.原料出库金额0=b.fMoney_Cost,	 
		a.本日库存数量=a.fQty_left
		from t_wh_form_log a,#FIFOLast b
		where a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo 
		and a.cStoreNo=@cStoreNo
		and a.cWhNo=b.cWhNo 
	end 
    
  commit tran
  set @Return=0 
  select a01=0
end try
begin catch
 rollback 
 
 set @Return=2 
 select a01=0
 return
end catch


GO
