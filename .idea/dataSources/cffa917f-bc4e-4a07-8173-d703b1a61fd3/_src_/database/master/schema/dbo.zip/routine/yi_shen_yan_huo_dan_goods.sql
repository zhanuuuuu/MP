CREATE proc [dbo].[yi_shen_yan_huo_dan_goods]
  as
  select   a.cSheetno,a.cCustomerNo,a.cCustomer,a.cStoreNo,a.cStoreName,a.cWhNo,a.cwh,a.dDate,
         b.cGoodsNo,b.cGoodsName,b.cBarcode ,b.cUnitedNo,b.fQuantity,b.fInPrice,b.fInMoney,b.cUnit,b.dProduct,
         c.cDistBoxNo_SortSheetNo ,c.cPalletNo,c.cSheetNo_Pallet, c.cDistBoxNo,
         c.jiesuanno
  from   wh_cStoreOutVerifySheet a,    --配送验货出库单
         wh_cStoreOutVerifySheetDetail b ,  --配送验货出库单详情
         
        (select   DISTINCT  d.cPalletNo,d.cDistBoxNo, d.cDistBoxNo_SortSheetNo,
           e.cSheetNo_Pallet,e.cSheetno ,f.jiesuanno
         from wh_PalletSheetDetail d,wh_cStoreOutVerifySheet e, wh_cStoreOutWarehouse_Sort f 
           where d.cSheetno=e.cSheetNo_Pallet and d.cDistBoxNo_SortSheetNo=f.cSheetno) c
       
        where a.cSheetno=b.cSheetno and a.cSheetno=c.cSheetno  and ISNULL(a.bExamin,0)=1 and ISNULL(a.bReceive,0)=0

GO
