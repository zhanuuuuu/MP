CREATE proc getSheetno

@year  varchar(10),
@cStoreNo  varchar(20)
as
select dbo.f_GenBhsheetnoApply(@year ,@cStoreNo) as Sheetno
GO
