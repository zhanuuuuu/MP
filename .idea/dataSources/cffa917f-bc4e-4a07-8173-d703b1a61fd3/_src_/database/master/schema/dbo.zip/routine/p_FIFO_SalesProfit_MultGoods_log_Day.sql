 
 
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsNo,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='115561' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
		drop table #temp_Goods
		Create Table #temp_Goods (
		cGoodsNo varchar(128),
		cProductNo varchar(128),
		cSupplierNo varchar(128))
 
	if  (select object_id('tempdb..#tempSupNo')) is not null
	drop table #tempSupNo
	select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier
	-- where cSupplierNo='1001'
    insert into #temp_Goods(cGoodsNo,cSupplierNo)
    select distinct a.cGoodsNo,b.cSupplierNo   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where b.cSupplierNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_goods where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    
 exec p_FIFO_SalesProfit_MultGoods_log '2014-12-27','2014-12-31','01'
 go
 exec p_FIFO_SalesProfit_MultGoods_log_Day '2014-12-27','2014-12-31','01'
 
*/
CREATE procedure [dbo].[p_FIFO_SalesProfit_MultGoods_log_Day]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）



    if (select object_id('tempdb..#temp_Goods_1'))is not null drop table #temp_Goods_1

    select distinct a.cGoodsNo,b.cSupplierNo into #temp_Goods_1   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where a.cGoodsNo in (select cGoodsNo from #temp_Goods)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cGoodsNo in (select cGoodsNo from #temp_Goods))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_goods where cGoodsNo in (select cGoodsNo from #temp_Goods))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)

	 if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	select distinct cGoodsNo,cSupplierNo into #tmpCostGoodsList 
	from #temp_Goods_1
-- where cGoodsNo='112187'

if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cSupplierNo into  #tmp_WhGoodsList  from (
select distinct a.cGoodsNo,a.cSupplierNo  
from #tmpCostGoodsList a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsNo,a.cSupplierNo 
from #tmpCostGoodsList a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))=''
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
from #tmpCostGoodsList a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
) a

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

--print dbo.getTimeStr(GETDATE())
--print 2

/*修改主供应商-- 有入库、但是该商品为不管理库存、*/
update a
set a.cSupplierNo=b.cSupNo
from #tmp_WhGoodsList a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=0


declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

declare  @cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money)
  
 /*快照表中的最大日期。。。*/
 
declare @maxWhdDate datetime
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end

-----查最大日结时间内信息@dDateBegin到@dDateEnd
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn)
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1

exec('


--------期初销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_beginQty
	from  #temp_Wh_Goods_beginQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_beginSale
	from  #temp_Wh_Goods_beginSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
	from #temp_SumWh_Goods_beginQty
 
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
----------期初成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_beginCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_beginCost
	from  #temp_Wh_Goods_beginCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney		
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
 
	') 

exec('
	--------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=b.Sale, 
	a.特价销售金额=b.Saletj,
	a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
					
----------期末成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
	into #temp_Wh_Goods_endCost
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost b
	with (nolock) 
	where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
	select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_endCost
	from  #temp_Wh_Goods_endCost
	group by cgoodsno,cSupplierNo
	

    update a 
	set a.fmoney_cost=b.fMoney		
	from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

    ')

 
insert into   #temp_WhFromend(cgoodsno,cWhno,cSupplierno)
select a.cgoodsno,a.cWhno,a.cSupplierno from #temp_WhFrombegin a left join #temp_WhFromend b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
where isnull(b.cGoodsNo,'')='' 
 
 
update a 
set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0),	 
a.fPrice_Avg=case when isnull(a.销售数量0,0)-isnull(b.销售数量0,0)<>0 
then (ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) end,
a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))
from #temp_WhFromend a left join #temp_WhFrombegin b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo




/*注意一品多商的情况*/
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,--销售数量
   fLastSettle money,--卖价
   fMoneyCost money,--进价
   fMoneyRatio money,--毛利
   fRatio money, --毛利率
   bAuditing int,
   fAvg_price money
)

insert into #GetGoodsListFormBase
(	cGoodsNo,bAuditing )
select distinct cGoodsNo,0 from #tmp_WhGoodsList
union all
select  distinct  cGoodsNo,1 from #tmp_WhGoodsList

	--- 取记账之前的数据... 
 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
        create table #temp_ReadyKucun(
		cGoodsNo varchar(32),cUnitedNo varchar(32), csupno varchar(32),csuplierno varchar(32), 
		cGoodsName varchar(64),cBarcode varchar(32),cUnit varchar(32),cSpec varchar(32),
		fNormalPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),bProducted bit ,cProductNo  varchar(32),
		fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
		fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money
)
  
if 	@maxWhdDate<@dDateEnd
begin
	 --select '2',@dDate_1,@dDate_2
	  --exec p_FIFO_SalesProfit_GoodsType_log_wei @dDate_1,@dDate_2,@cWHno
	  
	  if (select OBJECT_ID('tempdb..#temp_goodsForSelect'))is not null drop table #temp_goodsForSelect
      if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_p'))is not null drop table #GetGoodsListFormBase_p
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_R'))is not null drop table #GetGoodsListFormBase_R
      select distinct cGoodsNo  into #temp_goodsForSelect from #tmpCostGoodsList
      
      
	  select dSaleTime=b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing
      into #t_SaleSheetDetail_shelf
      from #temp_goodsForSelect a, t_SaleSheetDetail b
      where (b.dSaleDate between @dDate_1 and @dDate_2) and a.cGoodsNo=b.cGoodsNo and b.cWHno=@cWHno 
      union all
      select c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0'
      from #temp_goodsForSelect a,WH_ReturnGoodsDetail b,WH_ReturnGoods c
      where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dDate_1 and @dDate_2)
            and c.cWHno=@cWHno
            
          
            
      /*---包装转单品*/
			if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
			select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
			into #tmpPackGoodsList
			from t_goods
			where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

			update a
			set a.cGoodsNo=b.cGoodsNo_MinPackage,
					a.fQuantity=a.fQuantity*b.fQty_minPackage
			from #t_SaleSheetDetail_shelf a, #tmpPackGoodsList b
			where a.cGoodsNO=b.cGoodsNO
---销售数量

      select dSaleTime=@dDate1,a.cGoodsNo,a.bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
             fMoneyCost=cast(0 as money),fMoneyRatio=cast(0 as money),fRatio=cast(0 as money),
             cSupno=CAST(null as varchar(32))
      into #GetGoodsListFormBase_p 
      from (
						select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0))
						from #t_SaleSheetDetail_shelf 
						where dSaleTime between @dDate_1 and @dDate_2
						group by cGoodsNo,bAuditing
           ) a
      group by a.cGoodsNo,a.bAuditing
      
     
      
      update a set a.cSupno=b.cSupNo
      from #GetGoodsListFormBase_p a,t_goods b
      where a.cGoodsNo=b.cGoodsNo
--获取供应商最小扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select a.guizuno,a.fRatio
			from t_Supplier_Contract_Ratio a,
			(
				 select guizuno,fMoney1=MIN(fMoney1)
				 from t_Supplier_Contract_Ratio 
				 where isnull(fRatio,0)<>0
				 group by guizuno
			 )b
			where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
	  ) b
	  where a.cSupno=b.guizuno
			
--获取t_goods表扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,fRatio
			from t_goods 
			where isnull(fRatio,0)<>0
	  ) b
	  where a.cGoodsNo=b.cGoodsNo
			
--策略扣率
      update a  
	  set a.fRatio=b.fSupRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
			from t_PloyOfSale
			where (
								(dDateStart between @dDate_1 and @dDate_2)
								or 
								(dDateEnd  between @dDate_1 and @dDate_2)
						)and isnull(fSupRatio,0)<>0
			group by cGoodsNo,dDateStart,dDateEnd
	  ) b
      where a.cGoodsNo=b.cGoodsNo and a.dSaleTime between b.dDateStart and b.dDateEnd 
      and isnull(a.bAuditing,0)=1
	
	 
	  select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
		   fMoneyCost=sum(isnull(fMoneyCost,0)),
		   fMoneyRatio=sum(isnull(fMoneyRatio,0)),fRatio=avg(isnull(fRatio,0))
	  into #GetGoodsListFormBase_R
	  from #GetGoodsListFormBase_p 
	  group by cGoodsNo,bAuditing
	  
	  
	  
	  drop table #GetGoodsListFormBase_p
--销售成本 
/*
	  select cGoodsNo,fPrice_Avg from #temp_end
*/			
      ---平均价
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg0'))is not null drop table #temp_fPrice_Avg0
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg'))is not null drop table #temp_fPrice_Avg
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(c.fCKPrice,0)=0 
      --then c.fNormalPrice
      then c.fPrice_Contract  
      else c.fCKPrice end
      into #temp_fPrice_Avg0
      from #GetGoodsListFormBase a left join t_goods c
      on a.cGoodsNo=c.cGoodsNo
      
  
 -------------------     修改：从入库单中取赠品的进价修改。。。 
     if (select OBJECT_ID('tempdb..#temp_fPrice_InWhouse'))is not null drop table #temp_fPrice_InWhouse

      select a.* into #temp_fPrice_InWhouse
      from (
			  select b.dDate,a.cGoodsNo,a.fInPrice from
		wh_InWarehouseDetail a,wh_InWarehouse b where a.cSheetno=b.cSheetno
		-- and b.dDate between @dDate1 and @dDate2
		 --and  fInPrice=0
      ) a right join #GetGoodsListFormBase b on  a.cGoodsNo=b.cGoodsNo
   --   where a.cGoodsNo=b.cGoodsNo
      order by a.dDate
      
           
      ------获取最新进价为0 的。。。 
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg01'))is not null drop table #temp_fPrice_Avg01
      select a.cGoodsNo,fPrice_Avg=ISNULL(c.fCKPrice,0)
      into #temp_fPrice_Avg01
      from #GetGoodsListFormBase a left join t_goods c
      on a.cGoodsNo=c.cGoodsNo where c.fCKPrice=0
      
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg02'))is not null drop table #temp_fPrice_Avg02

      select a.cGoodsNo,fPrice_Avg=isnull(b.fInPrice,0) 
      into #temp_fPrice_Avg02
      from #temp_fPrice_Avg01 a right join #temp_fPrice_InWhouse b
      on a.cGoodsNo=b.cGoodsNo 
       
      update a set a.fPrice_Avg=b.fPrice_Avg from
      #temp_fPrice_Avg0 a,#temp_fPrice_Avg02 b
      where a.cGoodsNo=b.cGoodsNo 
      
 ---------------  

 /*
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(b.fPrice_Avg,0)=0 then a.fPrice_Avg else b.fPrice_Avg end
      into #temp_fPrice_Avg
      from #temp_fPrice_Avg0 a left join #temp_WhFromend b
      on a.cGoodsNo=b.cGoodsNo 
      */
      
		select a.cGoodsNo,fPrice_Avg=
		case when ISNULL(a.fPrice_Avg,0)=0 then 
		case when ISNULL(b.fCKPrice,0)=0 then
		b.fNormalPrice else b.fCKPrice end
		else a.fPrice_Avg end
		into #temp_fPrice_Avg
		from #temp_fPrice_Avg0 a left join t_Goods b
		on a.cGoodsNo=b.cGoodsNo 
      
      --select * from #temp_fPrice_Avg where fPrice_Avg is null
      
      --select SUM(fPrice_Avg) from #temp_WhFromend      
      --select SUM(fPrice_Avg) from #temp_fPrice_Avg0
 
	  update a
	  set a.fMoneyCost=isnull(a.fQuantity,0)*b.fPrice_Avg	  
	  from #GetGoodsListFormBase_R a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	----  select * from #GetGoodsListFormBase_R	 
	
	--select fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
	--fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio) from #GetGoodsListFormBase_R
	
	  
	  ------扣点
	  update a ---不管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00),
	      a.fMoneyCost=isnull(a.fLastSettle,0)*(1-a.fRatio/100.00)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0
	  
	  update a ---管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00)+isnull(a.fLastSettle,0)-isnull(a.fMoneyCost,0)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
	  --更新到基础表#GetGoodsListFormBase中

	  
	  update a
	  set a.fAvg_price=b.fPrice_Avg	  
	  from #GetGoodsListFormBase a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	  update a
	  set a.fQuantity=isnull(b.fQuantity,0),a.fLastSettle=isnull(b.fLastSettle,0),
		a.fMoneyCost=isnull(b.fMoneyCost,0),
		a.fMoneyRatio=isnull(b.fMoneyRatio,0),a.fRatio=isnull(b.fRatio,0)
	  from #GetGoodsListFormBase a,#GetGoodsListFormBase_R b
	  where a.cGoodsNo=b.cGoodsNo and a.bAuditing=isnull(b.bAuditing,0)
	  
      
	  
	  drop table #GetGoodsListFormBase_R

	  update a
	  set a.cSupNO=case when isnull(a.cSupNO,'')='' then b.cSupNo else a.cSupNO end,
	      a.cGoodsTypeNo=b.cGoodsTypeno,a.cGoodsTypeName=b.cGoodsTypename
	  from #GetGoodsListFormBase a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	insert into #temp_ReadyKucun(cGoodsNo,xsQty,xsMoney,fMoney_Cost,fML,csupno,csuplierno,fCostPrice)
	select cGoodsNo,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
	fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio),cSupNO,'',fAvg_price from #GetGoodsListFormBase
	group by cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,cSupNO,fAvg_price
	
end

if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsNo,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,fml,cSupplierNo,cSupplier,fPrice_Avg
into #temp_goodsKuCunml
from #temp_WhFromend  --where  isnull(fml,0)<>0 
union all
select cGoodsNo,xsQty,xsMoney,fMoney_Cost,fML,csupno,csuplierno,fCostPrice
from #temp_ReadyKucun --where xsQty<>0


if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
select cGoodsNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
cSupplierNo,cSupplier,fPrice_Avg=AVG(fPrice_Avg)
into #temp_SumgoodsKuCunml
from #temp_goodsKuCunml
group by cGoodsNo,cSupplierNo,cSupplier

CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)


if (select OBJECT_ID('tempdb..#temp_goodsKuCun1'))is not null  drop table #temp_goodsKuCun1
select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo=b.cSupNo,b.cSupName,
BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost 
into  #temp_goodsKuCun1
from #temp_SumgoodsKuCunml a,t_Goods b
where a.cGoodsNo=b.cGoodsNo  
order by a.cGoodsNo



if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate, xsQty=SUM(xsQty), xsMoney=SUM(xsMoney), 	 
fCostPrice=avg(fCostPrice),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost),i=0
into  #temp_goodsKuCun
from #temp_goodsKuCun1
group by cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate 
order by cGoodsNo
	  

--	 print dbo.getTimeStr(GETDATE())
--   print 7
---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)
--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
drop table #temp_wh_DiffGoodsNo
select b.cGoodsno,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
where dSaleDate between @dDate1 and @dDate2 
and a.cGoodsno=b.cGoodsNo 
group by b.cGoodsno

CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

update a
set 
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo b
where a.cGoodsNo=b.cGoodsNo  

	   
	   
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCun

--------获取期末前最新的毛利调整数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fNewPrice=a.NewFckprice,dDateTime=max(dDateTime)--,a.cSupNo
into #tmpGoodsRelationKucun_1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno --and a.cSupNo=b.cSupplierNo
group by a.cGoodsNo,a.NewFckprice--,a.cSupNo

---------修改最近调整成本商品的毛利
update a 
set a.fMoney_Cost=ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fML=isnull(a.xsMoney,0)-ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fCostPrice=b.fNewPrice
from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
where a.cGoodsNo=b.cGoodsNo ---and a.cSupplierNo=b.cSupNo

/*------------------*/
    /*--------修改未主供应商防止出现多条数据----2015-05-05------*/
 update  a
 set a.cSupplierNo=b.csupno,a.cSupName=b.csupname 
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno
 
 update  a
 set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*isnull(b.fQty_minPackage,1)
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''
 
 if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last0
 select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
 BeginDate,EndDate,cSupplierNo,b.cSupName,fMoney_Cost=sum(fMoney_Cost),
 fCostPrice=0,
 xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
 fML=sum(isnull(fML,0)),i
 into #temp_goodsKuCun_last0
from #temp_goodsKuCun a,t_Goods b
where a.cGoodsNo=b.cGoodsNo
group by a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,BeginDate,EndDate,cSupplierNo,b.cSupName,i

--if(select object_id('tempdb..##temp_GoodsTypeNoDay')) is not null 
-- drop table ##temp_GoodsTypeNoDay
-- select cGoodsNo,fML,fMoney_Cost,xsQty,xsMoney into ##temp_GoodsTypeNoDay from #temp_goodsKuCun_last0
	 
	   
if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin
     CREATE INDEX IX_temp_temp_goodsKuCun  ON #temp_goodsKuCun(cGoodsTypeno)
 
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,
         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(a.fMoney_Cost,0)<>0
         then case when isnull(a.xsQty,0)<>0 then isnull(a.fMoney_Cost,0)/isnull(a.xsQty,0) else isnull(a.fCostPrice,0) end
         else isnull(a.fCostPrice,0) end,
         fml=isnull(a.fML,0),a.i
      into    #temp_goodsKuCun_last
 -- from #temp_goodsKuCun a,#temp_GoodsTypeNo b
  from #temp_goodsKuCun_last0 a,#temp_GoodsTypeNo b
  where a.cGoodsTypeno=b.cGoodsTypeno


  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i
  from #temp_goodsKuCun_last 
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='合计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last  
  group by  cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last 
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsNo,i
  
end else
begin
 select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(fMoney_Cost,0)<>0
         then case when isnull(xsQty,0)<>0 then isnull(fMoney_Cost,0)/isnull(xsQty,0) else isnull(fCostPrice,0) end
         else isnull(fCostPrice,0) end,
         fML=ISNULL(fML,0),i 
  from #temp_goodsKuCun_last0
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last0
  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
    --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsNo,i
end    
 
	 /*删除临时表*/
	if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
	if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  drop table #temp_wh_DiffPriceWarehouseDetail
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null   drop table #temp_wh_DiffPricecGoodsNo


GO
