/*
[eReport001_ml] 
'2012-04-01','2012-04-30',
'2012-05-01','2012-05-31',
'01','cGoodsTypeNo '
*/
CREATE proc [dbo].[eReport001_ml]
@date1 datetime,  --年份
@date2 datetime, --周次
@date3 datetime,  --环比上年份
@date4 datetime, --环比上周次
@cWhNo varchar(32),
@str varchar(32)
as 
----获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @date3 datetime
--declare @date4 datetime
--declare @cWhNo varchar(32)
--declare @str varchar(32)
--select @date1='2011-06-01',@date2='2011-06-07',
--       @date3='2011-05-25',@date4='2011-06-31',
--       @cWhNo='01',@str='cGoodsTypeNo'
declare @strDate varchar(100)
declare @strDatePre varchar(100)

set @strDate=convert(varchar(100),@date1,23)+'至'+convert(varchar(100),@date2,23)
set @strDatePre=convert(varchar(100),@date3,23)+'至'+convert(varchar(100),@date4,23)+'@'

if(select object_id('tempdb..#tempLeaf')) is not null 	drop table 	#tempLeaf
select cGoodsTypeNo,cGoodsTypeName,cParentNo,ilevel=cast(1 as int),cpath=cast(null as varchar(500)) into #tempLeaf
from t_GoodsType
update #tempLeaf set cpath=cParentNo+'.'+cGoodsTypeNo

declare @num int ,@a int
set @a=1
select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
while (@num)>0
begin
	update a
	set a.cpath=left(b.cpath,charindex('.',b.cpath,1))+a.cpath
	,a.ilevel=case when a.ilevel=null then @a else a.ilevel+@a end
	from #tempLeaf a left join #tempLeaf b
	on left(a.cpath,len(a.cpath)-charindex('.',reverse(a.cpath),1))=right(b.cpath,len(b.cpath)-charindex('.',b.cpath,1))
	where b.cpath is not null
	select @num=COUNT(*) from #tempLeaf where cpath not like '%--%'
end
select cGoodsTypeNo,cGoodsTypename,cPath,iLevel
into #tempGoodsTypePath
from #tempLeaf 
/*以上形成类别列表*/---------------------------------------------------------------------------
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
--where cPath=cPath_leaf

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null

update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null

print convert(varchar(21),getdate(),20)
--查毛利
if(select object_id('tempdb..#temp_dateBase')) is not null drop table  #temp_dateBase
if(select object_id('tempdb..#temp_dateFrist')) is not null drop table  #temp_dateFrist
if(select object_id('tempdb..#temp_dateEnd')) is not null drop table  #temp_dateEnd
create table #temp_dateBase
(cGoodsNo varchar(64),cUnitedNo varchar(64),cGoodsName varchar(64),cBarcode varchar(64),cUnit varchar(64),cSpec varchar(64),
fNormalPrice money,cGoodsTypeno varchar(64),cGoodsTypename varchar(64),bProducted bit,cProductNo varchar(64),
BeginDate datetime,EndDate datetime,cSupplierNo varchar(64),cSupName varchar(64),fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money)

if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
select distinct cGoodsNo into #temp_Goods from t_goods
exec [p_maoli_byGoodsType_for_select] 
@date1,@date2,@cWhNo

select * into #temp_dateFrist
from #temp_dateBase

delete from #temp_dateBase

exec [p_maoli_byGoodsType_for_select] 
@date3,@date4,@cWhNo

select * into #temp_dateEnd
from #temp_dateBase

drop table #temp_dateBase

select dSaleDate=EndDate,cGoodsNo,cGoodsTypeNo,cGoodsTypeName,
fQuantity=xsQty,fLastSettle=xsMoney,fCostPrice,fMoneyCost=fMoney_Cost
into #TmpGoodsBaseInfo
from #temp_dateFrist 
union all
select dSaleDate=EndDate,cGoodsNo,cGoodsTypeNo,cGoodsTypeName,
fQuantity=xsQty,fLastSettle=xsMoney,fCostPrice,fMoneyCost=fMoney_Cost
from #temp_dateEnd

print convert(varchar(21),getdate(),20)
--以上是日结基本信息（商品类型）
select isnull(SUM(xsMoney),1) from #temp_dateFrist -----------------------------------------table0
---------------------------------------------客单价,合计
--if(select object_id('tempdb..#kdj')) is not null  drop table #kdj
--select period_hour=CAST(datepart(hh,jstime) as varchar(4)),sheet_count=COUNT(distinct sheetno),
--shishou_count=SUM(isnull(shishou,0)),
--price_PerClient=SUM(isnull(shishou,0))/case when COUNT(distinct sheetno)<>0 then COUNT(distinct sheetno) else null end 
--into #kdj
--from jiesuan
--where zdriqi between @date1 and @date2
--group by datepart(hh,jstime)
--order by datepart(hh,jstime)
--select * from #kdj
--union all
--select 合计='合计:',sheet_count=COUNT(distinct sheetno),shishou_count=SUM(isnull(shishou,0)),
--price_PerClient=SUM(isnull(shishou,0))/case when COUNT(distinct sheetno)<>0 then COUNT(distinct sheetno) else null end 
--from jiesuan
--where zdriqi between @date1 and @date2 -------------------table1
--@MaxLevel是商品类型最大层数
declare @MaxLevelNo int
set @MaxLevelNo=0 
select @MaxLevelNo=Max(iLevel)from #TmpGoodsLevel 
select num=@MaxLevelNo,data=(convert(varchar(100),@date3,23)+'至'+convert(varchar(100),@date4,23))-------table2
declare @TableName varchar(100)
declare @iserNo int   
set @iserNo=1
while @iserNo<=@MaxLevelNo
begin
	  set @tableName='##tmpGoodsSaleByTypeByPir'+cast(@iserNo as varchar(2))
	  if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=@iserNo
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'
/*	  
select * from #TmpGoodsLevel
select * from #GoodsType
select * from #tmpGoodsType_byLevel
select * from #tmpGoods_byLevel
select * from T_goodstype
select * from ##tmpGoodsSaleByTypeByMonth1
*/
if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select a.dSaleDate,cGoodsTypeNo=b.BaseGoodsTypeNo,cGoodsTypeName=null,jinjia=a.fMoneyCost,a.fLastSettle,
	b.iLevel,b.bLeaf,cParentTypeNo=cast(null as varchar(32))
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo
--select * from #TmpGoodsBaseInfo
    update a
    set a.cParentTypeNo=b.cParentNo
    from #tmpGoods_byLevel a,t_goodsType b
    where a.cGoodsTypeNo=b.cGoodsTypeNo

    if (select object_id('tempdb..#tmpGoods_byLevelOne'))is not null drop table #tmpGoods_byLevelOne
	if (select object_id('tempdb..#tmpGoods0'))is not null drop table #tmpGoods0
-------------查询合计(全部)
select dSaleDate=@strDate,
    cParentTypeNo,jinjia=SUM(ISNULL(jinjia,0)),fLastSettle=sum(isnull(fLastSettle,0))	
    into #tmpGoods_byLevelOne
	from #tmpGoods_byLevel
    where dSaleDate between @date1 and @date2
	group by cParentTypeNo
    union all
    select dSaleDate=@strDatePre,
    cParentTypeNo,jinjia=SUM(ISNULL(jinjia,0)),fLastSettle=sum(isnull(fLastSettle,0))
	from #tmpGoods_byLevel
    where dSaleDate between @date3 and @date4
	group by cParentTypeNo
---------------select * from #tmpGoods_byLevelOne
	--个类别占比
	select dSaleDate=@strDate,cGoodsTypeNo,cGoodsTypeName=null,jinjia=SUM(ISNULL(jinjia,0)),fLastSettle=sum(isnull(fLastSettle,0)),
	iLevel,bLeaf,cParentTypeNo
	into #tmpGoods0
	from #tmpGoods_byLevel
    where dSaleDate between @date1 and @date2
	group by cGoodsTypeNo,iLevel,bLeaf,cParentTypeNo
    union all
    select dSaleDate=@strDatePre,cGoodsTypeNo,cGoodsTypeName=null,jinjia=SUM(ISNULL(jinjia,0)),fLastSettle=sum(isnull(fLastSettle,0)),
	iLevel,bLeaf,cParentTypeNo
	from #tmpGoods_byLevel
    where dSaleDate between @date3 and @date4
	group by cGoodsTypeNo,iLevel,bLeaf,cParentTypeNo
	/*
select * from #tmpGoods0 order by cGoodsTypeNo  
select * from #tmpGoods_byLevelOne order by cParentTypeNo
	*/
	exec('
	if (select object_id(''tempdb..'+@tableName+'''))is not null drop table '+@tableName+' 
	create table '+@tableName+'
	(dSaleDate varchar(32),cGoodsTypeNo varchar(32),cGoodsTypeName varchar(32),jinjia money,fLastSettle money,huanbi real,iLevel int,bLeaf int,cParentTypeNo varchar(32),maoli money,zbl real)
	insert into '+@tableName+'
	(dSaleDate,cGoodsTypeNo,cGoodsTypeName,a.jinjia,fLastSettle,huanbi,iLevel,bLeaf,cParentTypeNo,maoli,zbl)
	select a.dSaleDate,a.cGoodsTypeno,c.cGoodsTypeName,a.jinjia,a.fLastSettle,huanbi=a.iLevel,
    a.iLevel,a.bLeaf,a.cParentTypeNo,maoli=0,zbl=0
	from #tmpGoods0 a left join #tmpGoods_byLevelOne b
	on a.dSaleDate=b.dSaleDate and a.dSaleDate='''+@strDate+''' and a.cParentTypeNo=b.cParentTypeNo 
	left join t_goodsType c
	on a.cGoodsTypeNo=c.cGoodsTypeno
    where a.dSaleDate='''+@strDate+'''
    
    update a 
    set 
    a.huanbi=((a.fLastSettle/case when isnull(b.fLastSettle,0)<>0 then b.fLastSettle*1.000 else null end)-1)*100   
    --a.CostCircle=(a.fMoneyCost/case when isnull(b.fMoneyCost,0)<>0 then b.fMoneyCost*1.000 else null end),
    --a.RatioCircle=((a.fLastSettle-a.fMoneyCost)/case when isnull(((b.fLastSettle-b.fMoneyCost)),0)<>0 then (b.fLastSettle-b.fMoneyCost)*1.000 else null end)
    from '+@tableName+' a left join #tmpGoods0 b
    on  a.cGoodsTypeNo=b.cGoodsTypeNo
    and a.dSaleDate='''+@strDate+''' and b.dSaleDate='''+@strDatePre+'''
    
	update a
		set 
		maoli=(isnull(fLastSettle,0) - jinjia),
		zbl=(isnull(fLastSettle,0) - jinjia)*100/case when isnull(fLastSettle,0)<>0 then fLastSettle*1.000 else null end
		from '+@tableName+' a
		
	select * from '+@tableName+' order by '+@str+'
	')
  set @iserNo=@iserNo+1
end

--select * from ##tmpGoodsSaleByTypeByPir3 where cGoodsTypeNo='8130101'
--select * from #tmpGoods0 where dSaleDate='2011-05-14至2011-06-05@' and cGoodsTypeNo='8130101'
--select * from #tmpGoods0 where dSaleDate='2011-06-06至2011-06-28' and cGoodsTypeNo='8130101'
--		update a 
--		set 
--		a.huanbi=((a.fLastSettle/case when isnull(b.fLastSettle,0)<>0 then b.fLastSettle*1.000 else null end)-1)*100 
--		from ##tmpGoodsSaleByTypeByPir3 a left join #tmpGoods0 b
--		on  a.cGoodsTypeNo=b.cGoodsTypeNo
--		and a.dSaleDate='2011-06-06至2011-06-28' and b.dSaleDate='2011-05-14至2011-06-05@'
GO
