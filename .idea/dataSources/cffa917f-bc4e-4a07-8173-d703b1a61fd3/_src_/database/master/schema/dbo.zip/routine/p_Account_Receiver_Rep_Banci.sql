 /*

[p_Account_Receiver_Rep_Banci]  '','2016-12-12','2016-12-12','1010','晚班'

*/

CREATE  procedure [dbo].[p_Account_Receiver_Rep_Banci]
@guizuno varchar(32),
@date1 datetime,
@date2 datetime,
@cStoreNo varchar(32),
@cBanci varchar(16)
as
begin
  declare @iLineNo_Banci int
  set @iLineNo_Banci=3
  if @cBanci='早班' 
  begin
    set @iLineNo_Banci=1
  end 
   if @cBanci='中班' 
  begin
    set @iLineNo_Banci=2
  end  
  
  update jiesuan_PerDayDiff
  set chayi=shishou-yingshou
  where zdriqi between @date1 and @date2
  
  /*生成报表的列*/
  select fMoney_Save=sum(isnull(fMoney_Save,0)),cOpertorNo,cOperName,dSaleDate
	into #temp_t_Vip_Save
	from t_Vip_Save a,t_Warehouse b
  where dSaleDate between @date1 and  @date2
  and a.cStoreNo=b.cWhNo
   and ( b.cStoreNo=@cStoreNo)
  group by cOpertorNo,cOperName,dSaleDate
  
  
/*  
  select detail,sum(shishou) shishou 
  into #jiesuan_detail
	from jiesuan
  where  zdriqi between @date1 and  @date2
  group by detail
*/
   select shishou=sum(isnull(yingshou,0)),
  detail=detail+'应收'
	into #jiesuan_detail0_jiesuan_PerDayDiff_1
	from jiesuan_PerDayDiff a,t_Pass b
  where zdriqi between @date1 and  @date2 and isnull(yingshou,0)<>0
  and a.shouyinyuanno=b.[user]
  and b.cStoreNo=@cStoreNo
  group by detail
  
  --select * from jiesuan_PerDayDiff
  
  select shishou=sum(isnull(shishou,0)),
  detail=detail+'实收'
	into #jiesuan_detail0_jiesuan_PerDayDiff_2
	from jiesuan_PerDayDiff a,t_Pass b
  where zdriqi between @date1 and  @date2 and isnull(shishou,0)<>0
  and a.shouyinyuanno=b.[user]
  and b.cStoreNo=@cStoreNo
  group by detail  
  
  select shishou=sum(isnull(chayi,0)),
  detail=detail+'长短款'
	into #jiesuan_detail0_jiesuan_PerDayDiff_3
	from jiesuan_PerDayDiff a,t_Pass b
  where zdriqi between @date1 and  @date2 
  and a.shouyinyuanno=b.[user]
  and b.cStoreNo=@cStoreNo
  group by detail   
  
  
 
  
  select detail,sum(shishou) shishou 
  into #jiesuan_detail0
	from jiesuan
  --where  zdriqi between @date1 and  @date2
  --and cStoreNo=@cStoreNo  and isnull(shishou,0)<>0
  where  cStoreNo=@cStoreNo and zdriqi between @date1 and  @date2+2
		and cBanci_ID between dbo.getDayStr(@date1)+'_1' and dbo.getDayStr(@date2)+'_3'
		and iLineNo_Banci=@iLineNo_Banci
		 and isnull(bOnline,0)=0
  group by detail
 
 
  select detail,shishou 
  into #jiesuan_detail
	from #jiesuan_detail0
	union all
  select detail='电子钱包',shishou=sum(isnull(fMoney_Save,0))
  from #temp_t_Vip_Save

	union all
  select detail,shishou
  from #jiesuan_detail0_jiesuan_PerDayDiff_1  
	union all
  select detail,shishou
  from #jiesuan_detail0_jiesuan_PerDayDiff_2  
  union all
  select detail,shishou
  from #jiesuan_detail0_jiesuan_PerDayDiff_3   
  
   

 
  declare detail_cursor cursor
  for
  select detail from #jiesuan_detail
  order by detail
  
  declare @detail varchar(32)
  
  open detail_cursor
  fetch next from detail_cursor
  into @detail
  create table #account_detail
  (
     收银员No varchar(32) COLLATE Chinese_PRC_CI_AS ,
     收银员 varchar(32) COLLATE Chinese_PRC_CI_AS ,
     结算日期 varchar(32) COLLATE Chinese_PRC_CI_AS 
	)

  declare @cAddFields varchar(4000)
  set @cAddFields=''
  declare @strtmp varchar(4000)
  set @strtmp=''
  declare @strtmp_group varchar(4000)
  set @strtmp_group=''
  declare @strtmp_Clear varchar(4000)
  set @strtmp_Clear='update #account_detail_last set '
  while @@fetch_status=0
  begin
    set @cAddFields=@cAddFields+@detail+' varchar(32),'
    set @strtmp=@strtmp+'''0'','
    set @strtmp_group=@strtmp_group+@detail+'=cast(sum(cast('+@detail+' as money)) as varchar(32)),'
    set @strtmp_Clear=@strtmp_Clear+@detail+'=case when cast('+@detail+' as money)=0 then ''-'' else '+@detail+' end,'
		fetch next from detail_cursor
    into @detail
  end
  set @cAddFields=@cAddFields+' 合计 varchar(32)'
  set @strtmp=@strtmp+'''0'''
  set @strtmp_group=@strtmp_group+' 合计=cast(sum(cast(合计 as money)) as varchar(32))'
  set @strtmp_Clear=@strtmp_Clear+' 合计=case when cast(合计 as money)=0 then ''-'' else 合计 end'
  print @strtmp_group
  
  exec( 'alter table #account_detail add '+@cAddFields)      
  close detail_cursor
  deallocate detail_cursor

	select shouyinyuanno,shouyinyuanmc,detail,zdriqi=dbo.getdaystr(zdriqi),
	sum(mianzhi) mianzhi,sum(zhaoling) zhaoling,sum(shishou) shishou
  into #jiesuan
	from jiesuan 
  where  cStoreNo=@cStoreNo and zdriqi between @date1 and  @date2+2
		and cBanci_ID between dbo.getDayStr(@date1)+'_1' and dbo.getDayStr(@date2)+'_3'
		and iLineNo_Banci=@iLineNo_Banci
		 and isnull(bOnline,0)=0
		
	group by  shouyinyuanno,shouyinyuanmc,detail,zdriqi
  union all
	select shouyinyuanno=cOpertorNo,shouyinyuanmc=cOperName,detail='电子钱包',zdriqi=dbo.getdaystr(dSaleDate),
	 mianzhi=sum(fMoney_Save),zhaoling=0, shishou=sum(fMoney_Save)
	from #temp_t_Vip_Save
	where dSaleDate between @date1 and  @date2
	group by  cOpertorNo,cOperName,dSaleDate

  union all
  select a.shouyinyuanno,shouyinyuanmc,
  detail=detail+'应收'
  ,zdriqi=dbo.getdaystr(a.zdriqi),SUM(a.yingshou) mianzhi,zhaoling=0,SUM(a.yingshou) shishou 
	from jiesuan_PerDayDiff a ,t_Pass b
  where a.zdriqi between @date1 and  @date2 and isnull(a.yingshou,0)<>0
  and a.shouyinyuanno=b.[user] and b.cStoreNo=@cStoreNo
  group by a.shouyinyuanno,a.shouyinyuanmc, a.detail,a.zdriqi
  
  union all
  select a.shouyinyuanno,shouyinyuanmc,
  detail=detail+'实收'
  ,zdriqi=dbo.getdaystr(a.zdriqi),SUM(a.shishou) mianzhi,zhaoling=0,SUM(a.shishou) shishou 
	from jiesuan_PerDayDiff a ,t_Pass b
  where a.zdriqi between @date1 and  @date2 and isnull(a.shishou,0)<>0
  and a.shouyinyuanno=b.[user] and b.cStoreNo=@cStoreNo
  group by a.shouyinyuanno,a.shouyinyuanmc, a.detail,a.zdriqi
  
  union all
  select a.shouyinyuanno,shouyinyuanmc,
  detail=detail+'长短款'
  ,zdriqi=dbo.getdaystr(a.zdriqi),SUM(a.chayi) mianzhi,zhaoling=0,SUM(a.chayi) shishou 
	from jiesuan_PerDayDiff a ,t_Pass b
  where a.zdriqi between @date1 and  @date2 
  and a.shouyinyuanno=b.[user] and b.cStoreNo=@cStoreNo
  group by a.shouyinyuanno,a.shouyinyuanmc, a.detail,a.zdriqi
    

	
	
  
  declare jiesuan_cursor cursor
  for
  select shouyinyuanno,shouyinyuanmc,detail,zdriqi,shishou=cast(shishou as char(32))
  from #jiesuan
  order by zdriqi,shouyinyuanno,shouyinyuanmc,detail
 
  select shouyinyuanno,shouyinyuanmc,zdriqi=dbo.getdaystr(zdriqi),shishou=cast(sum(isnull(shishou,0)) as char(32))
  into #jiesuan_heji
  from #jiesuan
  where detail not like '%应收' and detail not like '%实收' and detail not like '%长短款'
  group by shouyinyuanno,shouyinyuanmc,zdriqi
  


  declare @shouyinyuanno varchar(32)
  declare @shouyinyuanmc varchar(32)
  declare @zdriqi varchar(32)
  declare @shishou varchar(32)

  open jiesuan_cursor
  fetch next from jiesuan_cursor
  into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou

  while @@fetch_status=0
  begin
		if (select 收银员No from #account_detail 
				where 收银员No=@shouyinyuanno and 收银员=@shouyinyuanmc and 结算日期=@zdriqi) is null
    begin
      exec('insert into #account_detail select '''+@shouyinyuanno+''','''+@shouyinyuanmc+''','''+@zdriqi+''','+@strtmp)
    end
    exec('update #account_detail set '+@detail+'=dbo.trim('''+@shishou
					+''') where 收银员No='''+@shouyinyuanno+'''  and 收银员='''+@shouyinyuanmc+'''  and 结算日期='''+@zdriqi+'''')

    fetch next from jiesuan_cursor
		into @shouyinyuanno,@shouyinyuanmc,@detail,@zdriqi,@shishou     
  end

  close jiesuan_cursor
  deallocate jiesuan_cursor 


  update a set a.合计=dbo.trim(b.shishou)
  from #account_detail a
  left join #jiesuan_heji b
  on a.收银员No=b.shouyinyuanno and a.收银员=b.shouyinyuanmc and cast(a.结算日期 as datetime)=cast(b.zdriqi as datetime)

 
  if dbo.trim(@guizuno)='' 
  begin
    exec('
    select * into #account_detail_last from #account_detail
    
    union all
    select 收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail '
    +@strtmp_Clear
    +' select * from #account_detail_last')
  end else
  begin
    exec('
    select * into #account_detail_last from #account_detail where 收银员No='''+@guizuno+''' '+'
    
    union all
    select 收银员No=''总计'',收银员=null,结算日期=null,'+@strtmp_group
    +' from #account_detail where 收银员No='''+@guizuno+''' '
    +@strtmp_Clear
    +' select * from #account_detail_last')
  end
  --exec(@strtmp_Clear)

end


 GO
