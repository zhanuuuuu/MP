
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsno,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='115561' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
		drop table #temp_Goods
		Create Table #temp_Goods (
		cGoodsNo varchar(128),
		cProductNo varchar(128),
		cSupplierNo varchar(128))
 
	if  (select object_id('tempdb..#tempSupNo')) is not null
	drop table #tempSupNo
	select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier
	-- where cSupplierNo='1001'
    insert into #temp_Goods(cGoodsno,cSupplierNo)
    select distinct a.cGoodsno,b.cSupplierNo   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where b.cSupplierNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsno,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_goods where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsno,a.cSupno from  t_goods a
    where  a.cSupNo in (select cSupplierNo from #tempSupNo)

if (select object_id('U_Key.dbo.temp_Goods'))is not null
drop table U_Key.dbo.temp_Goods
-- 取相应类别下的商品。。。 				
 select cGoodsNo into  U_Key.dbo.temp_Goods from t_Goods
 where isnull(bfresh,0)=1
  

exec p_ParentFresh_SalesProfit_MultGoods_log_TermID_test  '000', '2016-12-12','2016-12-12', '00','12122105416490'

*/
CREATE procedure [dbo].[p_ParentFreSh_SalesProfit_MultGoods_log_TermID_test]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cTermID varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）
 --print dbo.getTimeStr(GETDATE())+'  0000'	
 
if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
create table #tmpCostGoodsList(cGoodsNo varchar(32))
exec('
   insert into #tmpCostGoodsList(cGoodsno)
   select distinct cGoodsno  
   from U_Key.dbo.temp_Goods'+@cTermID+'
')

 
-- where cGoodsNo='112187'
 --print dbo.getTimeStr(GETDATE())+'  00001'	
 
 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
 
select distinct a.cGoodsno,cSupplierNo=b.cSupNo 
into  #tmp_WhGoodsList 
from #tmpCostGoodsList a,t_Goods b
where a.cgoodsno=b.cgoodsno  

 
CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

 --print dbo.getTimeStr(GETDATE())+'  00002'	
 

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

declare  @cdbname varchar(32)
declare  @Rdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@Rdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

--print dbo.getTimeStr(GETDATE())+'  0001'	

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money)
  
 /*快照表中的最大日期。。。*/
 
declare @maxWhdDate datetime
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock)   where cStoreNo='''+@cStoreNo+'''  ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end

--print dbo.getTimeStr(GETDATE())+'   0002'	
-----查最大日结时间内信息@dDateBegin到@dDateEnd
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn)
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@maxWhdDate) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@maxWhdDate) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
	if(@bY1<>@eY1)
	begin
		set @tj='1'
    end else
    begin
      if @bM1=@eM1
      begin
      exec('
		--------配送出库 
		
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cGoodsno,cSupplierNo,fQty1=sum(fQty1)-sum(fQty0), fMoney1=sum(fMoney1)-sum(fMoney0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endQty
		group by cGoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromend(cGoodsno,cSupplierNo,销售数量0,销售金额0)
		select cGoodsno,cSupplierNo,isnull(fQty1,0) ,isnull(fMoney1,0)		 
		from #temp_SumWh_Goods_endSale
	 		
	----------期末入库
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

		')
	  end else
	  begin
	    set @tj='1' 
	  end
    end
    if @tj='1'
    begin
         exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyInPc_'+@MMDAY_1+',fMoney1=b.fMoneyInPc_'+@MMDAY_1+',
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,cSupplierno,fQty=sum(fQty1), fMoney1=sum(fMoney1) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cGoodsno,cSupplierNo
			
			 
			
			insert into #temp_WhFrombegin(cGoodsno,cSupplierNo,销售数量0,销售金额0	)
			select cGoodsno,cSupplierNo,fQty,fMoney1
			from #temp_SumWh_Goods_beginQty
		     
							
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		 
			') 

		exec('
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 		
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		  


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cSupplierno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cGoodsno,cSupplierNo
			
		 
			 
			
			insert into #temp_WhFromend(cGoodsno,cSupplierNo,销售数量0,销售金额0)
			select cGoodsno,cSupplierNo,fQty,fMoney
			from #temp_SumWh_Goods_endQty
		  	
		----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

			')

			update a 
			set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
			a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 			 
			a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0),	 
			a.fPrice_Avg=case when isnull(a.销售数量0,0)-isnull(b.销售数量0,0)<>0 
			then (ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) end,
			a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))
			from #temp_WhFromend a left join #temp_WhFrombegin b
			on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    end
end else
begin
    if @M1=@M_1
    begin
      --print dbo.getTimeStr(GETDATE())+'   0003'	
	exec('
		--------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyInPc_'+@MMDAY_1+',fMoney0=b.fMoneyInPc_'+@MMDAY_1+' 
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cGoodsno,cSupplierno,fQty1=sum(fQty1)-sum(fQty0), fMoney1=sum(fMoney1)-sum(fMoney0) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cGoodsno,cSupplierNo
		 
		 
		 
		
		insert into #temp_WhFromend(cGoodsno,cSupplierNo,销售数量0,销售金额0)
		select cGoodsno,cSupplierNo,fQty1,fMoney1
		from #temp_SumWh_Goods_endQty
	  
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyInPc_'+@MMDAY_1+',fMoney0=b.fMoneyInPc_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

		')
	--print dbo.getTimeStr(GETDATE())+'   0004'		
	end else
	begin
	  exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,cSupplierno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cGoodsno,cSupplierNo
			
		 
			 
			
			insert into #temp_WhFrombegin(cGoodsno,cSupplierNo,销售数量0,销售金额0)
			select cGoodsno,cSupplierNo,fQty,fMoney
			from #temp_SumWh_Goods_beginQty
		 
			  
		----------期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		 
			') 

		exec('
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 	
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  b.cGoodsNo=a.cGoodsNo 
		 

			 


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cSupplierno,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cGoodsno,cSupplierNo
			
			 
			 
			 
			
			insert into #temp_WhFromend(cGoodsno,cSupplierNo,销售数量0,销售金额0)
			select cGoodsno,cSupplierNo,fQty,fMoney	
			from #temp_SumWh_Goods_endQty
		 
		 
							
		----------期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cSupplierNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 

			')

		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
		a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
		a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
		a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
		a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0),	 
		a.fPrice_Avg=case when isnull(a.销售数量0,0)-isnull(b.销售数量0,0)<>0 
		then (ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))
		from #temp_WhFromend a left join #temp_WhFrombegin b
		on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	end   
end


/*注意一品多商的情况*/
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,--销售数量
   fLastSettle money,--卖价
   fMoneyCost money,--进价
   fMoneyRatio money,--毛利
   fRatio money, --毛利率
   bAuditing int,
   fAvg_price money
)

insert into #GetGoodsListFormBase
(	cGoodsno )
select distinct cGoodsno from #tmp_WhGoodsList
 

	--- 取记账之前的数据... 
 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
        create table #temp_ReadyKucun(
		cGoodsNo varchar(32),cUnitedNo varchar(32), csupno varchar(32),csuplierno varchar(32), 
		cGoodsName varchar(64),cBarcode varchar(32),cUnit varchar(32),cSpec varchar(32),
		fNormalPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),bProducted bit ,cProductNo  varchar(32),
		fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
		fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money
)
--print dbo.getTimeStr(GETDATE())+'  0005'	 
if 	@maxWhdDate<@dDateEnd
begin
	 --select '2',@dDate_1,@dDate_2
	  --exec p_FIFO_SalesProfit_GoodsType_log_wei @dDate_1,@dDate_2,@cWHno
	  
	  if (select OBJECT_ID('tempdb..#temp_goodsForSelect'))is not null drop table #temp_goodsForSelect
      if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_p'))is not null drop table #GetGoodsListFormBase_p
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_R'))is not null drop table #GetGoodsListFormBase_R
      select distinct cGoodsNo  into #temp_goodsForSelect from #tmpCostGoodsList
      
      
	  select dSaleTime=b.dSaleDate,a.cGoodsno,b.fQuantity,b.fLastSettle,b.bAuditing
      into #t_SaleSheetDetail_shelf
      from #temp_goodsForSelect a, t_SaleSheetDetail b
      where (b.dSaleDate between @dDate_1 and @dDate_2) and a.cGoodsNo=b.cGoodsNo 
      and b.cStoreNo=@cStoreNo and b.cWHno=@cWHno 
      union all
      select c.dDate,a.cGoodsno,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0'
      from #temp_goodsForSelect a,WH_ReturnGoodsDetail b,WH_ReturnGoods c
      where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dDate_1 and @dDate_2)
      and c.cStoreNo=@cStoreNo and c.cWHno=@cWHno 
            
      
---销售数量

      select dSaleTime=@dDate1,a.cGoodsno,a.bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
             fMoneyCost=cast(0 as money),fMoneyRatio=cast(0 as money),fRatio=cast(0 as money),
             cSupno=CAST(null as varchar(32))
      into #GetGoodsListFormBase_p 
      from (
						select cGoodsno,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0))
						from #t_SaleSheetDetail_shelf 
						where dSaleTime between @dDate_1 and @dDate_2
						group by cGoodsno,bAuditing
           ) a
      group by a.cGoodsno,a.bAuditing
      
      
 
	 
	  select cGoodsno,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
		   fMoneyCost=sum(isnull(fMoneyCost,0)),
		   fMoneyRatio=sum(isnull(fMoneyRatio,0)),fRatio=avg(isnull(fRatio,0))
	  into #GetGoodsListFormBase_R
	  from #GetGoodsListFormBase_p 
	  group by cGoodsno 
	  
	  update a
	  set  a.fQuantity=b.fQuantity,
	       a.fLastSettle=b.fLastSettle
	  from #GetGoodsListFormBase a,#GetGoodsListFormBase_R b
	  where a.cGoodsNo=b.cGoodsNo
----------------------------------------------------------------------    
	  drop table #GetGoodsListFormBase_p
--销售成本 
/*
	  select cGoodsno,fPrice_Avg from #temp_end
*/		
      if (select OBJECT_ID('tempdb..#temp_fPrice_OutFresh'))is not null drop table #temp_fPrice_OutFresh
	  select b.cGoodsNo,b.fQuantity,b.fInMoney into #temp_fPrice_OutFresh 
	  from wh_cStoreOutWarehouse a,wh_cStoreOutWarehouseDetail b
	  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
	  and a.cStoreNo=@cStoreNo 
	  and ISNULL(a.bExamin,0)=1
	  --and ISNULL(a.bfresh,0)=1
	  
	   
	  
	  if (select OBJECT_ID('tempdb..#temp_fPrice_OutFreshGoods'))is not null drop table #temp_fPrice_OutFreshGoods
	  select b.cGoodsNo,fQuantity=sum(b.fQuantity),fInMoney=sum(b.fInMoney) into #temp_fPrice_OutFreshGoods
	  from #temp_fPrice_OutFresh b,#tmp_WhGoodsList a
	  where a.cGoodsNo=b.cGoodsNo
	  group by b.cGoodsNo 
	  
	  
	  
	  update a
	  set  a.fQuantity=isnull(a.fQuantity,0)+ISNULL(b.fQuantity,0),
	       a.fLastSettle=isnull(a.fLastSettle,0)+ISNULL(b.fInMoney,0)
	  from #GetGoodsListFormBase a,#temp_fPrice_OutFreshGoods b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	  
	  --- 获取时间段入库金额
	  if (select OBJECT_ID('tempdb..#temp_fPrice_InFresh'))is not null drop table #temp_fPrice_InFresh
	  select b.cGoodsNo,b.fQuantity,b.fInMoney into #temp_fPrice_InFresh from wh_InWarehouse a,wh_InWarehouseDetail b
	  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
	  and a.cStoreNo=@cStoreNo and ISNULL(a.bExamin,0)=1
	  
	  if (select OBJECT_ID('tempdb..#temp_fPrice_InFreshGoods'))is not null drop table #temp_fPrice_InFreshGoods
	  select b.cGoodsNo,fQuantity=sum(b.fQuantity),fInMoney=sum(b.fInMoney) into #temp_fPrice_InFreshGoods
	  from #temp_fPrice_InFresh b,#tmp_WhGoodsList a
	  where a.cGoodsNo=b.cGoodsNo
	  group by b.cGoodsNo
	 
	  
	  
	  
	  update a
	  set a.fMoneyCost=isnull(b.fInMoney,0),
	  fMoneyRatio=ISNULL(a.fLastSettle,0)-isnull(b.fInMoney,0)
	  from #GetGoodsListFormBase a,#temp_fPrice_InFreshGoods b
	  where a.cGoodsNo=b.cGoodsNo 
	   
      
		insert into #temp_ReadyKucun(cGoodsno,xsQty,xsMoney,fMoney_Cost,fML,csupno,csuplierno,fCostPrice)
		select cGoodsno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
		fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio),cSupNO,'',fAvg_price from #GetGoodsListFormBase
		group by cGoodsno,cSupNO,cGoodsTypeNo,cGoodsTypeName,cSupNO,fAvg_price
	
end
--print dbo.getTimeStr(GETDATE())+'   0006'	
 
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsno,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,fml,fPrice_Avg
into #temp_goodsKuCunml
from #temp_WhFromend   
union all
select cGoodsno,xsQty,xsMoney,fMoney_Cost,fML,fCostPrice
from #temp_ReadyKucun 


if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
select cGoodsno,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),fPrice_Avg=AVG(fPrice_Avg)
into #temp_SumgoodsKuCunml
from #temp_goodsKuCunml
group by cGoodsno 

CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)


if (select OBJECT_ID('tempdb..#temp_goodsKuCun1'))is not null  drop table #temp_goodsKuCun1
select a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo=b.cSupNo,b.cSupName,
BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost 
into  #temp_goodsKuCun1
from #temp_SumgoodsKuCunml a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
order by a.cGoodsNo

--print dbo.getTimeStr(GETDATE())+'  0007'	 

if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate, xsQty=SUM(xsQty), xsMoney=SUM(xsMoney), 	 
fCostPrice=avg(fCostPrice),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost),i=0
into  #temp_goodsKuCun
from #temp_goodsKuCun1
group by cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate 
order by cGoodsNo
	  
--print dbo.getTimeStr(GETDATE())+'  0008'	
 
 
 if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last0
 select a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
 BeginDate,EndDate,cSupplierNo,b.cSupName,fMoney_Cost=sum(fMoney_Cost),
 fCostPrice=0,
 xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
 fML=sum(isnull(fML,0)),i
 into #temp_goodsKuCun_last0
from #temp_goodsKuCun a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=@cStoreNo
group by a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,BeginDate,EndDate,cSupplierNo,b.cSupName,i

--if(select object_id('tempdb..##temp_GoodsTypeNoDay')) is not null 
-- drop table ##temp_GoodsTypeNoDay
-- select cGoodsno,xsQty,xsMoney into ##temp_GoodsTypeNoDay from #temp_goodsKuCun_last0
--print dbo.getTimeStr(GETDATE())+'  0010'		 
	   
if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin
     CREATE INDEX IX_temp_temp_goodsKuCun  ON #temp_goodsKuCun(cGoodsTypeno)
 
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.cGoodsno,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,
         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(a.fMoney_Cost,0)<>0
         then case when isnull(a.xsQty,0)<>0 then isnull(a.fMoney_Cost,0)/isnull(a.xsQty,0) else isnull(a.fCostPrice,0) end
         else isnull(a.fCostPrice,0) end,
         fml=isnull(a.fML,0),a.i
      into    #temp_goodsKuCun_last
 -- from #temp_goodsKuCun a,#temp_GoodsTypeNo b
  from #temp_goodsKuCun_last0 a,#temp_GoodsTypeNo b
  where a.cGoodsTypeno=b.cGoodsTypeno


  select cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i
  from #temp_goodsKuCun_last 
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='合计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last  
  group by  cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last 
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsno,i
  
end else
begin
 select cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(fMoney_Cost,0)<>0
         then case when isnull(xsQty,0)<>0 then isnull(fMoney_Cost,0)/isnull(xsQty,0) else isnull(fCostPrice,0) end
         else isnull(fCostPrice,0) end,
         fML=ISNULL(fML,0),i 
  from #temp_goodsKuCun_last0
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last0
  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
    --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsno,i
end    
 
 
	 /*删除临时表*/
	if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
 
	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun

GO
