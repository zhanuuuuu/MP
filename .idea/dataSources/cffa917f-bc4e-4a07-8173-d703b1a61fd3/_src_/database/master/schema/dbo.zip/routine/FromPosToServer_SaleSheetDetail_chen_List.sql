


CREATE proc [dbo].[FromPosToServer_SaleSheetDetail_chen_List]
@Pos_Day varchar(32),
@iDays  varchar(3)
as
begin
exec('
  --declare @iDays int
 -- set @iDays=2
	begin try
		begin tran
		
		 /*老版本兼容，现在可以注释掉 
			update a
			set a.cWhno=b.cWhno
			from '+@Pos_Day+'.dbo.t_SaleSheetDetail a,t_WareHouse b
			where a.dSaleDate>=(getdate()-'+@iDays+') and isnull(b.bMainSale,0)=1 
		
			update a
			set a.cWhno=b.cWhno
			from dbo.t_SaleSheetDetail a,t_WareHouse b
			where a.dSaleDate>=(getdate()-'+@iDays+') and isnull(b.bMainSale,0)=1 
		 */
					

      select distinct b.cSaleSheetno,b.cWhNo
      into #pos_SaleSheetDetail 
      from dbo.t_SaleSheetDetail a right join '+@Pos_Day+'.dbo.t_SaleSheetDetail  b 
      on a.dSaleDate=b.dSaleDate and a.cSaleSheetno=b.cSaleSheetno and a.cWhNo=b.cWhNo
      where  (b.dSaleDate>=(getdate()-'+@iDays+'))
      and a.cSaleSheetno is null
	  
      ---删除以上传的数据
      delete a 
      from #pos_SaleSheetDetail a,dbo.t_SaleSheetDetail b
      where dSaleDate >=(getdate() -'+@iDays+') 
      and a.cSaleSheetno=b.cSaleSheetno and a.cWhNo=b.cWhNo
     
       

	select a.cSaleSheetno,a.cWhNo
	into #temp_sheetno_pos
	from dbo.t_SaleSheetDetail a,#pos_SaleSheetDetail b
	where  (dSaleDate>=(getdate()-'+@iDays+')) and a.cSaleSheetno=b.cSaleSheetno
	and a.cWhNo=b.cWhNo
			
      update a set a.bPost=1
      from '+@Pos_Day+'.dbo.t_SaleSheetDetail a,#temp_sheetno_pos b
      where  a.dSaleDate >=( getdate()-'+@iDays+') and a.cSaleSheetno=b.cSaleSheetno
      and a.cWhNo=b.cWhNo
      

      delete a 
      from #pos_SaleSheetDetail a,#temp_sheetno_pos b
      where a.cSaleSheetno=b.cSaleSheetno and a.cWhNo=b.cWhNo
			
      
      drop table #temp_sheetno_pos

		  select cWhno,cSaleSheetno,cGoodsNo,fQuantity=sum(isnull(fQuantity,0)) 
			into #temp_PosSale_15		
			from (select distinct cSaleSheetno,iSeed,cGoodsNo,fQuantity,bDownCurWH,dSaleDate,cWhno 
						from '+@Pos_Day+'.dbo.t_SaleSheetDetail
						where dSaleDate >=( getdate()-'+@iDays+') and isnull(bDownCurWH,0)=0
						) a
			group by a.cWhno,a.cSaleSheetno,a.cGoodsNo

			insert into	dbo.t_SaleSheetDetail
			(
				cSaleSheetno,iSeed,cGoodsNo,cGoodsName,cBarCode,cOperatorno,cOperatorName,
				cVipCardno,bAuditing,cChkOperno,cChkOper,bSettle,fVipScore,fPrice,fNormalSettle,
				bVipPrice,fVipPrice,bVipRate,fVipRate,fQuantity,fAgio,fLastSettle0,fLastSettle,
				cManager,cManagerno,dSaleDate,cSaleTime,dFinanceDate,cWorkerno,cWorker,				 
				cVipNo,bBalance,jiesuanno,cStationNo,tag_daily,cWHno,
        bHidePrice,bHideQty ,bWeight,
        fNormalVipScore ,bExchange ,fSupRatio_exchange,bPresent,bSend,bLimited,fVipScore_cur,cStoreNo

			)
			select distinct a.cSaleSheetno,a.iSeed,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.cOperatorno,a.cOperatorName,
				a.cVipCardno,a.bAuditing,a.cChkOperno,a.cChkOper,a.bSettle,a.fVipScore,a.fPrice,a.fNormalSettle,
				a.bVipPrice,a.fVipPrice,a.bVipRate,a.fVipRate,a.fQuantity,a.fAgio,a.fLastSettle0,a.fLastSettle,
				a.cManager,a.cManagerno,a.dSaleDate,a.cSaleTime,a.dFinanceDate,a.cWorkerno,a.cWorker,			 
				a.cVipNo,a.bBalance,a.jiesuanno,a.cStationNo,a.tag_daily,a.cWhno,
			a.bHidePrice,a.bHideQty ,a.bWeight,
			a.fNormalVipScore ,a.bExchange ,a.fSupRatio_exchange,a.bPresent,a.bSend,a.bLimited,a.fVipScore_cur,c.cStoreNo
			from '+@Pos_Day+'.dbo.t_SaleSheetDetail as a , #pos_SaleSheetDetail b,v_Posstation c
			where  a.dSaleDate >=( getdate()-'+@iDays+') and a.cSaleSheetno=b.cSaleSheetno
            and a.cWhNo=c.cWhNo
		 select cWhno,cGoodsNo,fQuantity=sum(fQuantity) 
		 into #temp_PosSale_15_set
		 from #temp_PosSale_15
		 group by cWhno,cGoodsNo
     
      /*  实时库存：存储过程作业代替
      insert into dbo.t_Goods_CurWH (cWHno,cGoodsNo,fQty_CurWH,cStoreNo)
      select h.cWhNo,h.cGoodsNo,h.fQty_CurWH,j.cStoreNo from (
      select distinct b.cWHno,b.cGoodsNo,fQty_CurWH=0
      from t_Goods_CurWH a right join #temp_PosSale_15_set b 
					on a.cWhno=b.cWHno and a.cGoodsNo=b.cGoodsNo 
			where a.cGoodsNo is null
			) h,v_Posstation j
			where h.cWhNo=j.cWhNo 

			update a
			set a.fQty_sale=isnull(a.fQty_sale,0)+isnull(b.fQuantity,0),
			a.fQty_CurWH=isnull(a.fQty_CurWH,0)-isnull(b.fQuantity,0)
			from t_Goods_CurWH a,
			#temp_PosSale_15_set b
			where  a.cGoodsNo=b.cGoodsNo 
					 and a.cWHno=b.cWhno
		*/

			update a
			set a.bDownCurWH=1
			from '+@Pos_Day+'.dbo.t_SaleSheetDetail a,#temp_PosSale_15 b
			where a.dSaleDate >=( getdate()-'+@iDays+') and 
			a.cSaleSheetno=b.cSaleSheetno and a.cWhno=b.cWhNo

			update a
			set a.bPost=1
			from '+@Pos_Day+'.dbo.t_SaleSheetDetail a,#pos_SaleSheetDetail b
			where a.dSaleDate >=( getdate()-'+@iDays+') and a.cSaleSheetno=b.cSaleSheetno
			and a.cWhNo=b.cWhNo
			

  ----------2015-04-21 记录当时的商品的销售日期----  
             insert into dbo.[t_GetGoods_InOut] (cGoodsNo,Last_SaleDate)
			 select distinct b.cGoodsNo,getdate()
			 from t_GetGoods_InOut a right join #temp_PosSale_15_set b 
							on a.cGoodsNo=b.cGoodsNo 
			 where a.cGoodsNo is null

			update a
			set a.Last_SaleDate=getdate() 
			from t_GetGoods_InOut a,
			#temp_PosSale_15_set b
			where  a.cGoodsNo=b.cGoodsNo  
			
			
			drop table #pos_SaleSheetDetail
			drop table #temp_PosSale_15
			drop table #temp_PosSale_15_set
			


		commit tran
	end try
	begin catch
		rollback
		
	end catch
')	
end

/*
 FromPosToServer_SaleSheetDetail_chen	
*/

GO
