 
 
/*
  p_GetCardHistoryLog_Store '90001682'
*/
create proc p_GetCardHistoryLog_Store
@cardno varchar(32)
as
begin
  if (select OBJECT_ID('tempdb..#temp_MoneyCardLog'))is not null
  drop table #temp_MoneyCardLog
  
  select  b.cardno,a.dSaleDate,cSaleSheetNo,fMoney_o,fLeftMoney_o,fMoney,fLeftMoney,a.cOperNo,cPosNo,
  b.date1,b.date2,cOperName=cast(null as varchar(64)),PosName=cast(null as varchar(32)),a.cWhNo,
  cStoreName=cast(null as varchar(64)),ly='CustLOG'
  into #temp_MoneyCardLog
  from supermarket.dbo.[Moneycard_Cust_Log] a,supermarket.dbo.Moneycard b
  where a.cMoneyNo=b.cardno and b.cardno=@cardno
  
  
  
  update a set a.cOperName=b.Name
  from #temp_MoneyCardLog a,t_Pass b
  where a.cOperNo=b.[user]
 
  
  update a set a.PosName=b.posname
  from #temp_MoneyCardLog a,t_PosStation b
  where a.cPosNo=b.posid
  
  
   update a set a.cStoreName=b.cStoreName
  from #temp_MoneyCardLog a,
  (select a.cWhNo,b.cStoreName from t_WareHouse a,t_Store b where a.cStoreNo=b.cStoreNo) b
  where a.cWhNo=b.cwhNo
  
   
  select cardno,dSaleDate,cSaleSheetNo,fMoney_o,fLeftMoney_o,fMoney,fLeftMoney,cOperNo,cPosNo,
  date1,date2,cOperName,PosName,cStoreName,ly
  from #temp_MoneyCardLog
  
  order by dSaleDate
  
  
  
end
GO
