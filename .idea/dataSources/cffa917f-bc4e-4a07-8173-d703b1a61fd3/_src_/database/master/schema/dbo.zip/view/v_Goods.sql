
 
 
CREATE VIEW [dbo].[v_Goods]
AS
SELECT     ISNULL(a.bUnStock, 0) AS bUnStock, ISNULL(a.iNumOfSup, 0) AS iNumOfSup, a.fRatio, a.fPrice_Contract, a.fQty_created, a.cGoodsNo_minPackage, 
                      a.cGoodsNo_minPackage_tmp, a.fQty_minPackage, a.fVipPrice_student, ISNULL(a.fPackRatio, 1) AS fPackRatio, a.fVipScore_base, a.bHidePrice, 
                      a.bHideQty, a.bUpdate, a.pinpaino, a.pinpai, a.cZoneNo, a.cZoneName, c.fValue_con, c.fValue_Score, a.fLastRatio, a.cCkPriceInSheetno, a.cGoodsNo, 
                      a.cUnitedNo, a.cGoodsName, a.cGoodsTypeno, c.cGoodsTypename, a.cBarcode, a.cUnit, a.cSpec, a.fNormalPrice, a.cProductUnit, a.cHelpCode, 
                      a.cTaxRate, a.fPreservationUp, a.fPreservationDown, a.fPreservation_soft, a.cLevel, a.bSuspend, a.bDeling, a.bDeled, a.dSuspendDate1, 
                      a.dSuspendDate2, a.dDelingDate1, a.dDelingDate2, a.fVipScore, a.bProducted, a.cProductNo, b.fSize, b.fWeight, b.fColor, a.bShenHe, a.bNoVipPrice, 
                      a.fVipPrice, a.bPiCi, a.bWeight, a.bCared, a.fCKPrice AS fLastCostPrice, a.fCKPrice, a.cSupNo, a.cSupName, a.bStorage, a.dCreateDate, b.bBaozhuang, 
                      b.fQty_Baozhuang, b.fPrice_Baozhuang_In, b.fPrice_Baozhuang_Out, b.cXinghao, d.cBarcode AS cBarcode_minPackage, 
                      d.cGoodsName AS cGoodsName_minPackage, a.fFreshDays, a.O2O, 
					  a.fPfPrice,a.fDbPrice,a.bfresh,a.fLossRatio, 
                      a.bTestSale,a.TestSalebgn,a.TestSaleend,a.bStop,
                      a.cJijieMonth,a.cJijie,a.bjijie,a.cLength,a.cWidth,a.cHeight,a.bUpDatePrice,a.bDaZhe,a.bClear,a.bReturnMoney,
                      a.bMoneycard,a.fMoneyValue,a.fBhRate,a.fDhRate,a.fPsprice,a.bOnePSPrice,a.ikongzhi,
                      a.fDpRate,a.bBuhuo
FROM         dbo.t_Goods AS a LEFT OUTER JOIN
                      dbo.t_Goods AS d ON dbo.trim(ISNULL(a.cGoodsNo_minPackage_tmp, ' ')) <> '' AND a.cGoodsNo_minPackage_tmp = d.cGoodsNo LEFT OUTER JOIN
                      dbo.t_GoodsItems AS b ON a.cGoodsNo = b.cGoodsNo LEFT OUTER JOIN
                      dbo.t_GoodsType AS c ON a.cGoodsTypeno = c.cGoodsTypeno


GO
