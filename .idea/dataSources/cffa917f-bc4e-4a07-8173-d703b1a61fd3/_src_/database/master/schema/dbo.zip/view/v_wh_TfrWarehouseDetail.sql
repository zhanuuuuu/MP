

CREATE   view v_wh_TfrWarehouseDetail
as
 select b.cSheetno,cIntoWhNo,cIntoWh,cOperatorNo,cOperator,dFillin,cFillinTime,cProcureDptno,cProcureDpt,b.fMoney,cManagerNo,cManager,
        bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,b.bPost,cToWhNo,cToWh,dDate,cTime,
        iLineNo,a.cGoodsNo,c.cGoodsName,c.cUnitedNo,fQuantity,fPrice,fTaxrate,bTax,fTaxPrice,
        fTaxMoney,fLastMoney,dProduct,fTimes,cProductSerno,bChecked,cCheckNo,dCheck,cGoodsTypeno,cGoodsTypename,cBarcode,
        cUnit,cSpec,fNormalPrice,cProductUnit,cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,cLevel,
        bSuspend,bDeling,bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,fVipScore,bProducted,
        cProductNo
 from wh_TfrWarehouseDetail a left join wh_TfrWarehouse b
                              on a.cSheetno=b.cSheetno
                              left join  t_Goods c
                              on a.cGoodsNo=c.cGoodsNo


GO
