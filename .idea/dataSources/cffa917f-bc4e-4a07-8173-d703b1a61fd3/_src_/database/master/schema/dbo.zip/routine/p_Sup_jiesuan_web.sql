
/*
 p_Sup_jiesuan_web '2011-05-26','2011-05-26','5af276a7fba2e87b'
 
 select * from U_key.dbo.s_5af276a7fba2e87b
*/
create proc p_Sup_jiesuan_web
@date1 datetime,
@date2 datetime,
@keys varchar(32)
as
begin
exec('
if(select OBJECT_ID(''temp..#temp_Sup_jiesuan'')) is not null
drop table #temp_Sup_jiesuan
select 
 jiesuanno,jiesuanriqi,riqi1,riqi2,cSupNo,cSupName,jiesuanjine,InMoney,xiaoshoujine,xiaoshou_zj,xiaoshou_tj,InComeMoney,koudianjine
,koudian_zj,koudian_tj,Rbdmoney,feiyongjine,payoutMoney,zoneMoney,qita
into #temp_Sup_jiesuan
 from t_supplier_jiesuan where jiesuanriqi between '''+@date1+''' and '''+@date2+'''
 --select * from #temp_Sup_jiesuan

if (select object_id(''U_key.dbo.s_'+@keys+'''))is not null 
drop table U_key.dbo.s_'+@keys+'
select * into  U_key.dbo.s_'+@keys+'  from #temp_Sup_jiesuan
 union all
 select jiesuanno=''总计:'',jiesuanriqi='''',riqi1='''+@date1+''',riqi2='''+@date2+''',cSupNo='''',cSupName='''',
 sum(jiesuanjine),sum(InMoney),sum(xiaoshoujine),sum(xiaoshou_zj),sum(xiaoshou_tj),sum(InComeMoney),sum(koudianjine)
,sum(koudian_zj),sum(koudian_tj),sum(Rbdmoney),sum(feiyongjine),sum(payoutMoney),sum(zoneMoney),sum(qita) from #temp_Sup_jiesuan

')
 end
GO
