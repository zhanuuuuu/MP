/*    

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods   where  cGoodsNo in ('211673','14508')-- or cgoodsno='2100226' or cgoodsno='210122'
--or cgoodsno in('210223','210231','210261','210423')

exec [P_x_SetCheckWh_byGoodsType_log_1]
'2013-8-1','2013-8-31','01' 
exec [P_x_SetCheckWh_byGoodsType_log]
'2013-8-1','2013-8-31','01' 


/*
 790.868 557.588
*/
*/
/*按供应商查库存*/
CREATE procedure [dbo].[P_x_SetCheckWh_byGoodsType_log_1]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32)--,/*是仓库No*/
--@bJiaGong bit
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-04-02' set @dDateEnd='2012-04-02'  set @cWhNo='02' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods 

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select cGoodsNo into #tmpCostGoodsList from #temp_Goods
--print dbo.gettimestr(getdate())
--print 1
/*从快照表中取数据。。。*/
if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
select distinct a.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1 into  #tmp_WhGoodsList_1  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>'' and ISNULL(b.bStorage,0)=1   ---- 大包装
union all
select distinct a.cGoodsNo ,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))='' and ISNULL(b.bStorage,0)=1   --- 小包装
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''  -- 获取大包装下的笑包装
and ISNULL(b.bStorage,0)=1
union all
select distinct cGoodsNo=b.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cGoodsNo_minPackage  
and ISNULL(b.bStorage,0)=1

CREATE INDEX IX_WhGoodsList_1  ON #tmp_WhGoodsList_1(cGoodsNo)

--print dbo.gettimestr(getdate())
--print 2
--if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
--select distinct a.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1 into  #tmp_WhGoodsList_1  
--from #temp_Goods a,t_goods b
--where a.cgoodsno=b.cgoodsno
--and isnull(b.cGoodsNo_minPackage,'')<>'' and ISNULL(b.bStorage,0)=1   ---- 大包装
--union all
--select distinct a.cGoodsNo ,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0
--from #temp_Goods a,t_goods b
--where a.cgoodsno=b.cgoodsno
--and isnull(b.cGoodsNo_minPackage,'')='' and ISNULL(b.bStorage,0)=1   --- 小包装
--union all
--select distinct cGoodsNo=b.cGoodsNo_minPackage,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=0    ---有关联包装的 供应商不一致的。。 
--from #temp_Goods a,t_goods b
--where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''  -- 获取大包装下的笑包装
--and ISNULL(b.bStorage,0)=1
--union all
--select distinct cGoodsNo=b.cGoodsNo,b.cGoodsNo_minPackage,b.fQty_minPackage,bbox=1    ---获取小包装的大包装商品
--from #temp_Goods a,t_goods b
--where a.cgoodsno=b.cGoodsNo_minPackage  
--and ISNULL(b.bStorage,0)=1


if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage,bbox 
into #tmp_WhGoodsList from  #tmp_WhGoodsList_1

 
 CREATE INDEX IX_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno


if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fMoney_left money,fPrice_Avg money,
  fMoney_cost money,fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money,
  期初盘点 money,期末盘点 money,期初账面库存 money,期末账面库存 money,fAvgMoney_Diff money)
  
 /*快照表中的最大日期。。。*/

 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

/*结转表中取数据*/

declare @dDate1 datetime
declare @dDate2 datetime
declare @BgndDate1 datetime
 declare @i int
set @i=1
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
			        
					set @dDate1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
					set @BgndDate1=@dDate1
					--set @i=0
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate1='2000-01-01'
					set @dDate2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
					set @BgndDate1=@dDate1
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
	    set @i=0
		set @dDate1=@dDateBgn
		set @dDate2=@dDateEnd 	 
		set @BgndDate1=@maxWhdDate+1
		
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
	insert into #temp_WhFrombegin([cGoodsNo],[cWHno]) 
	select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
	insert into #temp_WhFromend  ([cGoodsNo],[cWHno]) 
	select distinct cGoodsNo,@cWhNo from  #tmp_WhGoodsList 
	
	
	CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
	CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
 
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额

	--if @dDateBgn<=@maxWhdDate
	--begin
	--    set @i=1
	declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
    set @strDateEnd=dbo.getdaystr(@maxWhdDate)
    set @strBgn=dbo.getdaystr(@dDateBgn)  
		--set @SQLstr= '	 
					 exec(' if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
					select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				b.Pos客退数量1, b.Pos客退金额1,
					b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
					b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0,b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, b.盘点数量,b.iAttribute,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
				   --fMoney_left=isnull(b.调拨入库金额1,0)+
				   --     isnull(b.退货入库金额1,0)+isnull(b.入库金额1,0)-
				   --     isnull(b.报损金额0,0)-isnull(b.返厂金额0,0)-
				   --     isnull(b.调拨出库金额0,0)-isnull(b.原料出库金额0,0)-isnull(b.销售金额0,0)

						into #temp_Wh_Goods_begin
						from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					  where b.业务日期='''+@strDateBgn+''' and b.cWHno='''+@cWHno+''' and  a.cGoodsNo=b.cGoodsNo 
					 
					  union all             
					 select 业务日期,a.cgoodsno,a.cWHno,b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				b.Pos客退数量1, b.Pos客退金额1,
					b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
					b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0,b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, b.盘点数量,b.iAttribute,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
				   --fMoney_left=isnull(b.调拨入库金额1,0)+isnull(b.退货入库金额1,0)+isnull(b.入库金额1,0)-isnull(b.报损金额0,0)-isnull(b.返厂金额0,0)-isnull(b.调拨出库金额0,0)-isnull(b.原料出库金额0,0)-isnull(b.销售金额0,0)
             		from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					  where  b.业务日期='''+@strDateBgn+''' and  a.cGoodsNo=b.cGoodsNo 
					  and b.cWHno='+@cWHno+'  
					 
						
			          if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			         select cgoodsno,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
					Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
					  本日库存数量=SUM(isnull(本日库存数量,0)), 
					   盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fMoney_left=sum(fMoney_left)
					   into #temp_SumWh_Goods_begin
						from #temp_Wh_Goods_begin
		              group by cgoodsno,cWHno		
		              		              
		       --- select * from          #temp_SumWh_Goods_begin      
		              
					  update a 
					  set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
					  a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
					  a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,
					  a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
					  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
					  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
					  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
					  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
					  a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
					  a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
					  a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
					  a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
					  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
					  a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
					  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1, 
					   a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
					   a.期初库存=b.本日库存数量,
				   a.fPrice_Avg=b.fPrice_Avg,
				   a.fmoney_cost=b.fmoney_cost,
				   fMoney_left=b.fMoney_left
					  from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
					  where a.cGoodsNo=b.cGoodsNo ---and b.业务日期='''+@strDateBgn+''' 
					  and b.cWHno='+@cWHno+'
					 ')
 
					exec('if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
					select 业务日期,a.cgoodsno,b.dDateTime,a.cWHno,b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				b.Pos客退数量1, b.Pos客退金额1,
					b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
					b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0,b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, b.盘点数量,b.iAttribute,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
				  -- fMoney_left=isnull(b.调拨入库金额1,0)+isnull(b.退货入库金额1,0)+isnull(b.入库金额1,0)-isnull(b.报损金额0,0)-isnull(b.返厂金额0,0)-isnull(b.调拨出库金额0,0)-isnull(b.原料出库金额0,0)-isnull(b.销售金额0,0)
             	  into #temp_Wh_Goods_end
					  from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					  where b.业务日期='''+@strDateEnd+''' and  a.cGoodsNo=b.cGoodsNo 
					  and b.cWHno='''+@cWHno+'''					   
					  union all             
					  select 业务日期,a.cgoodsno,b.dDateTime,a.cWHno,
					b.销售数量0, b.销售金额0, 
				  b.特价销售数量, b.特价销售金额, 
				  b.正价销售数量, b.正价销售金额,
				b.Pos客退数量1, b.Pos客退金额1,
					b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
					b.退货入库数量1, b.退货入库金额1, 
				  b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				  b.报损数量0,b.报损金额0, b.返厂数量0, b.返厂金额0, 
				  b.调拨出库数量0, b.调拨出库金额0, 
				  b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				  b.成品入库数量1, b.成品入库金额1, 
				   本日库存数量=b.fQty_left, b.盘点数量,b.iAttribute,
				   fPrice_Avg=b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fMoney_Left=b.fMoney_Left
				   --fMoney_left=isnull(b.调拨入库金额1,0)+isnull(b.退货入库金额1,0)+isnull(b.入库金额1,0)-isnull(b.报损金额0,0)-isnull(b.返厂金额0,0)-isnull(b.调拨出库金额0,0)-isnull(b.原料出库金额0,0)-isnull(b.销售金额0,0)
					  from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					  where  b.业务日期 between '''+@strDateBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo 				
					 and b.cWHno='+@cWHno+'   and  b.iAttribute<>20	
					 

		             
		           if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			         select cgoodsno,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),					
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 					
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 					  
					   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_Avg),
					   fmoney_cost=sum(fmoney_cost),
					   fmoney_left=sum(isnull(fmoney_left,0))					   
					   into #temp_SumWh_Goods_end
						from #temp_Wh_Goods_end
		              group by cgoodsno,cWHno		              
		            
		            	 
		        
		              update a 
					  set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
					  a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
					  a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,					  
					  a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
					  a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
					  a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
					  a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
					  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
					  a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0,					  
					   a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
					   a.期末库存=b.本日库存数量,
					   fPrice_Avg=b.fPrice_Avg,
					   fmoney_cost=b.fmoney_cost,
					   fmoney_left=isnull(b.fmoney_left,0)				   
					  from #temp_WhFromend a ,#temp_SumWh_Goods_end b
					  where a.cGoodsNo=b.cGoodsNo
					   and b.cWHno='''+@cWHno+'''
					  -----------------获取时间段的入库数量--------------------			    
			     
	 	      if (select OBJECT_ID(''tempdb..#temp_IN_Goods_end''))is not null  drop table #temp_IN_Goods_end
	             select  cgoodsno,cWHno, Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  					  
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0))	
					  into #temp_IN_Goods_end	
	             from #temp_Wh_Goods_end
	             where dDatetime between '''+@strBgn+''' and '''+@strDateEnd+'''
	             group by  cgoodsno,cWHno	        
	                     
	        
	             update a
	             set a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
					  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
					  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
					  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
					  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1, 
					  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
	               from #temp_WhFromend a ,#temp_IN_Goods_end b
					  where a.cGoodsNo=b.cGoodsNo
					   and b.cWHno='''+@cWHno+'''
					   
				
					')
					
--print dbo.gettimestr(getdate())
--print 5
	---	exec (@SQLstr+@SQLstr1)
		
		-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
			 --- 结束日期数据-（开始日期-1）数据 得出时间段数据    
                     update a 
					 set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
					 a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
					  a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
					  a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
					  a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
					  a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),					
					  a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
					  a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
					  a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
					  a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),					  
					  a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
					  a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
					  a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
					  a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
					  a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
					  a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
					  a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
					  a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),			      
					  a.期初库存=isnull(b.期初库存,0), 
					  a.期末库存=isnull(a.期末库存,0), 
					  a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
					  a.期初账面库存=isnull(b.期初库存,0), 
					  a.期末账面库存=isnull(a.期末库存,0), 
				  a.fPrice_Avg=a.fPrice_Avg,
				  a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
				  a.fMoney_left=ISNULL(a.fMoney_left,0)
			from #temp_WhFromend a,#temp_WhFrombegin b
			where a.cGoodsNo=b.cGoodsNo 


--- 取记账之前的数据... 
	 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	create table #temp_ReadyKucun(
	cGoodsNo varchar(32),cUnitedNo varchar(32),BgnQty money,EndQty money,
			rkQty money,thrkQty money,ckQty money,fcQty money,
			dbQty money,bsQty money,byQty money,djQty money,xsQty money,
			ylckQty money,cprkQty money,dbrkQty money,fEndQuantity_Diff   money,
			fCKPriceMoney money,avgInPriceMoney money,fNormalPriceMoney money						
	)

if @maxWhdDate<@dDateEnd
begin
    
      -- exec P_x_SetCheckWh_byGoodsType_Wei @dDate1,@dDate2,@cWhNo,1
      -------期末前最新盘点日期-----------------------------------------------------
   
  if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	select distinct b.cGoodsNo,b.cSupNo into #tmpPloyOfGoodsinfo  
	from #temp_Goods a,t_goods b
	where a.cgoodsno=b.cgoodsno
	and ISNULL(b.bStorage,0)=1
	and a.cGoodsNo is not null

   declare @dMaxDailyDate datetime
	set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)
    if @dMaxDailyDate>@dDate2
    begin
      set @dMaxDailyDate=@dDate2
    end

---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	
	    select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
 		fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,t_SaleSheet_Day b 
		 with (nolock) 
		where b.dSaleDate between @BgndDate1 and @dDate2 and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo 
		union all
		select dSaleDate=isnull(b.dSaleDate,@dDate2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
		fQuantity=isnull(b.fQuantity,0),fMoney=isnull(b.fLastSettle,0)
		from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b		
		where b.dSaleDate>=@BgndDate1 and b.dSaleDate between (@dMaxDailyDate+1) and @dDate2 and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo	
		
		select dDateTime=b.dSaleDate,a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo 
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno
		where c.dDate between @BgndDate1 and @dDate2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
	    union all
		select @dDate2,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
        
		if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
		select distinct a.cGoodsNO,b.cGoodsNo_minPackage,b.fQty_minPackage into  #tmpPackGoodsList  
		from #tmpPloyOfGoodsinfo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(b.cGoodsNo_minPackage,'')<>''
		and ISNULL(b.bStorage,0)=1
         
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money),
		cGoodsName=cast(null as varchar(64)),cUnitedNo=cast(null as varchar(32)),
		cBarcode=cast(null as varchar(32)),cUnit=cast(null as varchar(32)),
		cSpec=cast(null as varchar(32)),fNormalPrice=cast(null as money),
		cGoodsTypeno=cast(null as varchar(32)),cGoodsTypename=cast(null as varchar(100)),
		cSupName=cast(null as varchar(100)),
		BeginDate=cast(null as datetime),EndDate=cast(null as datetime),
		rkQty=cast(0 as money),thrkQty=cast(0 as money),
		ckQty=cast(0 as money),fcQty=cast(0 as money),dbQty=cast(0 as money),
		bsQty=cast(0 as money),byQty=cast(0 as money),djQty=cast(0 as money),
		xsQty=cast(0 as money),ylckQty=cast(0 as money),cprkQty=cast(0 as money),
		dbrkQty=cast(0 as money),fCKPrice=cast(0 as money),avgInPrice=cast(0 as money),
		fCKPriceMoney=cast(0 as money),fNormalPriceMoney=cast(0 as money),
		avgInPriceMoney=cast(0 as money),fEndQuantity_Diff=cast(0 as money)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsNo,cWhNo

		update a
		set a.cSupNo=b.cSupNo
		from #GoodsCurStorageList a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(a.cSupNo,'-')='-'

		update a
		set a.cGoodsName=b.cGoodsName,a.cUnitedNo=b.cUnitedNo,a.cBarcode=b.cBarcode,a.cSupplierNo=b.cSupNo,
		a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.fNormalPrice=b.fNormalPrice,
		a.cGoodsTypeno=b.cGoodsTypeno,
		a.cGoodsTypename=b.cGoodsTypename,a.EndDate=@dDate2,a.fCKPrice=b.fCKPrice
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo 

		update a
		set a.cSupName=b.cSupName
		from #tmpGoodsListInfo_1 a,t_supplier b
		where a.cSupplierNo=b.cSupNo
           
--end
/*
select * from #GoodsCurStorageList where iAttribute<>9999

select cGOodsNO,fQuantity=sum(fQuantity),iAttribute,fMoney=sum(fMoney) 
from #GoodsCurStorageList 
where iAttribute<>9999
group by cGoodsNo,iAttribute
order by cGoodsNo
*/
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 
		
		--更新期初库存
		update a
		set a.BeginQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
		  select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime <@dDateBgn
			group by cGoodsNo		  
		)b
		where a.cGoodsNo=b.cGoodsNo
		
		--更新入库数量
 
		update a
		set a.rkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=0
			group by cGoodsNo 
		)b
		where a.cGoodsNo=b.cGoodsNo 
 
		--更新客退数量
		update a
		set a.thrkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=3
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		--更新出库数量
		update a
		set a.ckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=1
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新返厂数量
		update a
		set a.fcQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=2
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新调拨数量
		update a
		set a.dbQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDate1 and @dDate2 and (iAttribute=41 or iAttribute=40)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报损数量
		update a
		set a.bsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=5
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报溢数量
		update a
		set a.byQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=6
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新销售数量
		update a
		set a.xsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDate1 and @dDate2 and (iAttribute=20 or iAttribute=21)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新原料出库数量
		update a
		set a.ylckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=8
			group by cGoodsNo

		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新成品入库数量
		update a
		set a.cprkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDate1 and @dDate2 and iAttribute=9
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo
	
	--平均进价
		if (select OBJECT_ID('tempdb..#tmpAvgCost'))is not null drop table #tmpAvgCost
		select cGoodsNo,cWhNo,avgCost=avg(fPrice_in)
		into #tmpAvgCost
		from t_wh_form
		where dDateTime <=@dDate2 and iAttribute=0
		group by cGoodsNo,cWhNo

		update a
		set a.avginPrice=b.avgCost
		from #tmpGoodsListInfo_1 a,#tmpAvgCost b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo

		update a
		set a.avginPrice=b.fckPrice
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(a.avginPrice,0)=0
	
	   

       insert into   #temp_ReadyKucun(cGoodsNo, BgnQty, EndQty,rkQty, thrkQty, ckQty, fcQty,
		   dbQty, bsQty, byQty, djQty, xsQty,ylckQty, cprkQty, dbrkQty, fEndQuantity_Diff,fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney)
       select cGoodsNo, BeginQty, EndQty,
		   rkQty, thrkQty, ckQty, fcQty,
		   dbQty, bsQty, byQty, djQty, xsQty,
		   ylckQty, cprkQty, dbrkQty, fEndQuantity_Diff,fCKPrice*EndQty,fNormalPrice*EndQty,avginPrice*EndQty
		    from #tmpGoodsListInfo_1   
	 
	  
   end
 
   if @i=0 
   begin 
        update #temp_WhFromend
		set 
		  入库数量1=0,  退货入库数量1=0,
		  出库数量0=0, 返厂数量0=0, 
		  调拨出库数量0=0, 报损数量0=0, 
		  报溢金额1=0,  差价数量=0,
		  销售数量0=0,  原料出库数量0=0, 
		  成品入库数量1=0,  调拨入库数量1=0,
		  盘点数量=0,期初库存=期末库存
   end
 
   	--------------------盘点
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	--select a.cGoodsNo,dDate=MAX(b.dCheckTask)
	select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd0
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo 
	where b.dCheckTask<@dDateBgn
	--and isnull(b.bActive,0)=1 
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmp_WhGoodsList)
	group by a.cGoodsNo
	order by a.cGoodsNo
 
	--select * from  #templast_pd0
	----------期末日期的前的所有盘点差异。
	if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	--select a.cGoodsNo,dDate=MAX(b.dCheckTask)
	select a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
	into #templast_pd1
	from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
	on a.cCheckTaskNo=b.cCheckTaskNo 
	where b.dCheckTask between @dDateBgn and @dDateEnd
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmp_WhGoodsList)
	group by a.cGoodsNo
	order by a.cGoodsNo
---select * from  #templast_pd1
 
	if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo='XXXXXX',cSupName='超市盘点'
    into #templast_pdcGoodsNo
    from #templast_pd0
	union all
	select cGoodsNo,BeginQty=convert(money,0),EndQty=convert(money,0),fmoney_Diff=convert(money,0),cSupplierNo='XXXXXX',cSupName='超市盘点' 
	from #templast_pd1

 
		----- 修改盘点期初数量
		update a
		set a.BeginQty=b.fQuantity_Diff
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		----- 修改盘点期末数量
		update a
		set a.EndQty=b.fQuantity_Diff,
		a.fmoney_Diff=isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd0 b
		where a.cGoodsNo=b.cGoodsNo
		
		update a
		set a.EndQty=isnull(a.EndQty,0)+isnull(b.fQuantity_Diff,0),
		a.fmoney_Diff=isnull(a.fmoney_Diff,0)+isnull(b.fmoney_Diff,0)
		from #templast_pdcGoodsNo a,#templast_pd1 b
		where a.cGoodsNo=b.cGoodsNo	
	 

		
		update a
		set a.期初库存=isnull(a.期初库存,0)+isnull(b.BeginQty,0),
		a.期末库存=isnull(a.期末库存,0)+isnull(b.EndQty,0),
	    a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.BeginQty,0)*a.fPrice_Avg,
	    a.fMoney_left=ISNULL(a.fMoney_left,0),
	    a.期初账面库存=isnull(a.期初库存,0),
	    a.期末账面库存=isnull(a.期末库存,0),
	    a.期初盘点=isnull(b.BeginQty,0),
	    a.期末盘点=isnull(b.EndQty,0),
	    a.fAvgMoney_Diff=isnull(b.fmoney_Diff,0)
		from #temp_WhFromend a,#templast_pdcGoodsNo b
		where a.cGoodsNo=b.cGoodsNo
 
 
	update b
	set --b.期初库存=case when @i=1 then b.期初库存 else isnull(a.BgnQty,0)+isnull(b.期初库存,0) end,
	   b.期初库存=isnull(a.BgnQty,0)+isnull(b.期初库存,0),
	  b.期末库存=isnull(a.EndQty,0)+isnull(b.期末库存,0), 
	  b.入库数量1=isnull(a.rkQty,0)+isnull(b.入库数量1,0), 
	  b.退货入库数量1=isnull(a.thrkQty,0)+isnull(b.退货入库数量1,0),
      b.出库数量0=isnull(a.ckQty,0)+isnull(b.出库数量0,0), 
      b.返厂数量0=isnull(a.fcQty,0)+isnull(b.返厂数量0,0), 
      b.调拨出库数量0=isnull(a.dbQty,0)+isnull(b.调拨出库数量0,0),
      b.报损数量0=isnull(a.bsQty,0)+isnull(b.报损数量0,0), 
      b.报溢金额1=isnull(a.byQty,0)+isnull(b.报溢金额1,0), 
      b.差价数量=isnull(a.djQty,0)+isnull(b.差价数量,0),
      b.销售数量0=isnull(a.xsQty,0)+isnull(b.销售数量0,0), 
      b.原料出库数量0=isnull(a.ylckQty,0)+isnull(b.原料出库数量0,0), 
      b.成品入库数量1=isnull(a.cprkQty,0)+isnull(b.成品入库数量1,0), 
      b.调拨入库数量1=isnull(a.dbrkQty,0)+ isnull(b.调拨入库数量1,0),
      b.盘点数量=isnull(a.fEndQuantity_Diff,0)+isnull(b.盘点数量,0),
      b.fmoney_cost=isnull(b.fmoney_cost,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
	  b.fMoney_left=isnull(b.fMoney_left,0)+isnull(a.EndQty,0)*b.fPrice_Avg,
	  b.期初账面库存=isnull(b.期初账面库存,0)+isnull(a.BgnQty,0),
	  b.期末账面库存=isnull(b.期末账面库存,0)+isnull(a.EndQty,0)
	from #temp_ReadyKucun a left join #temp_WhFromend b
	on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is not null 	
	
	

	insert into #temp_WhFromend(
	  cGoodsNo, 期初库存, 期末库存, 入库数量1, 退货入库数量1,
      出库数量0, 返厂数量0, 调拨出库数量0, 报损数量0, 报溢金额1, 差价数量,
      销售数量0, 原料出库数量0, 成品入库数量1, 调拨入库数量1,
      盘点数量,fCKPriceMoney,fNormalPriceMoney,fmoney_left
	)
	select a.cGoodsNo,a.BgnQty,a.EndQty,
		  a.rkQty,a.thrkQty,a.ckQty,a.fcQty,
		  a.dbQty,a.bsQty,a.byQty,a.djQty,a.xsQty,
		  a.ylckQty,a.cprkQty,a.dbrkQty,a.fEndQuantity_Diff,a.fCKPriceMoney,a.fNormalPriceMoney,a.avgInPriceMoney
	from #temp_ReadyKucun a left join #temp_WhFromend b
	on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is  null		
 
         /*差价2014-10-18*/
    	 ---------获取时间段内的差价表。。---------
		 if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  
		 drop table #temp_wh_DiffPriceWarehouseDetail
		 select a.cGoodsNo,b.cWhNo,fMoney_diff=sum(a.fMoney_diff),fQuantity=sum(a.fQuantity)
		 into #temp_wh_DiffPriceWarehouseDetail
		 from wh_DiffPriceWarehouseDetail a,wh_DiffPriceWarehouse b
		 where b.dDate<=@dDateEnd  and a.cSheetno=b.cSheetno
		 group by a.cGoodsNo,b.cWhNo 
		 
		 if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_diff '))is not null  
		 drop table #tmp_WhGoodsList_diff 
		 select distinct cGoodsNo,cwhno=@cWhNo into #tmp_WhGoodsList_diff from  #tmp_WhGoodsList_1 
		
	    if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null  
	    drop table #temp_wh_DiffPricecGoodsNo
		select  a.cGoodsNo,a.cWhNo,a.fMoney_diff,a.fQuantity 
		into #temp_wh_DiffPricecGoodsNo 
		from #temp_wh_DiffPriceWarehouseDetail a,#tmp_WhGoodsList_diff b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cwhno
	
 
	update a set a.fMoney_left=a.fMoney_left-b.fMoney_diff
	from #temp_WhFromend a,#temp_wh_DiffPricecGoodsNo b
	where a.cGoodsNo=b.cGoodsNo

 
		  /*2014-10-02修改数量、大小包装*/
	 update a 
	 set a.cGoodsNo=b.cGoodsNo_minPackage,
	 a.入库数量1=a.入库数量1*b.fQty_minPackage,a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,
	 a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.销售数量0=a.销售数量0*b.fQty_minPackage,
     a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
     a.本日库存数量=a.本日库存数量*b.fQty_minPackage,a.期初库存=a.期初库存*b.fQty_minPackage,
     a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,
     a.出库数量0=a.出库数量0*b.fQty_minPackage,
     a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
     a.期末库存=a.期末库存*b.fQty_minPackage,
     a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,
     a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage,
     a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,
     a.差价数量=a.差价数量*b.fQty_minPackage,
     a.盘点数量=a.盘点数量*b.fQty_minPackage,
     a.期初账面库存=isnull(a.期初账面库存,0)*b.fQty_minPackage,
	    a.期末账面库存=isnull(a.期末账面库存,0)*b.fQty_minPackage,
	    a.期初盘点=isnull(a.期初盘点,0)*b.fQty_minPackage,
	    a.期末盘点=isnull(a.期末盘点,0)*b.fQty_minPackage	 
	 from #temp_WhFromend  a,(select distinct cGoodsNo,cGoodsNo_minPackage,fQty_minPackage from #tmp_WhGoodsList where bbox=1) b
	 where a.cGoodsNo=b.cGoodsNo
	 
 
	 if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
     select cGoodsNo,
		  入库数量1=SUM(入库数量1), 入库金额1=SUM(入库金额1), 
		   Pos客退数量1=SUM(Pos客退数量1), Pos客退金额1=SUM(Pos客退金额1), 
		  退货入库数量1=SUM(退货入库数量1), 退货入库金额1=SUM(退货入库金额1),   
		  出库数量0=SUM(出库数量0), 出库金额0=SUM(出库金额0), 
		  返厂数量0=SUM(返厂数量0), 返厂金额0=SUM(返厂金额0), 
		  报溢数量1=SUM(报溢数量1), 
		  调拨入库数量1=SUM(调拨入库数量1), 调拨出库数量0=SUM(调拨出库数量0), 
		  原料出库数量0=SUM(原料出库数量0), 报损数量0=SUM(报损数量0), 
		  销售数量0=SUM(销售数量0), 销售金额0=SUM(销售金额0), 
		  特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 
		  正价销售数量=SUM(正价销售数量), 正价销售金额=SUM(正价销售金额), 
		  本日库存数量=SUM(本日库存数量),  期初库存=SUM(期初库存),期末库存=SUM(期末库存), 
		  差价数量=sum(差价数量),盘点数量=SUM(盘点数量),
		  报溢金额1=sum(报溢金额1),成品入库数量1=SUM(成品入库数量1),
		  fMoney_left=SUM(fMoney_left),fmoney_cost=SUM(fMoney_cost),
		  期初账面库存=SUM(期初账面库存),
	      期末账面库存=SUM(期末账面库存),
	      期初盘点=SUM(期初盘点),
	      期末盘点=SUM(期末盘点),
	      fAvgMoney_Diff=SUM(fAvgMoney_Diff)
         into #temp_goodsKuCun_1
         from   #temp_WhFromend
         group by cGoodsNo
 
 
 
      if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null 
      drop table #tmpGoodsListInfo_2
         select GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename,
           b.bProducted ,b.cProductNo,
			BeginDate=@dDateBgn,BeginQty=sum(ISNULL(a.期初库存,0)),期初账面库存=SUM(a.期初账面库存),期初盘点=SUM(a.期初盘点),
			EndDate=@dDateEnd,EndQty=sum(isnull(a.期末库存,0)),期末账面库存=SUM(a.期末账面库存),期末盘点=SUM(a.期末盘点),
			rkQty=sum(isnull(a.入库数量1,0)),thrkQty=sum(isnull(退货入库数量1,0)),ckQty=sum(isnull(出库数量0,0)),fcQty=sum(isnull(返厂数量0,0)),
			dbQty=sum(isnull(调拨出库数量0,0)),bsQty=sum(isnull(报损数量0,0)),byQty=sum(isnull(报溢金额1,0)),
			djQty=sum(isnull(差价数量,0)),xsQty=sum(isnull(销售数量0,0)),
			ylckQty=sum(isnull(原料出库数量0,0)),cprkQty=sum(isnull(成品入库数量1,0)),dbrkQty=sum(isnull(调拨入库数量1,0)),
			fCKPrice=sum(isnull(b.fCKPrice,0)),fNormalPrice=isnull(b.fNormalPrice,0),--,avgInPrice=isnull(avgInPrice,0),
			fCKPriceMoney=sum(isnull(b.fCKPrice,0)*isnull(a.期末库存,0)),
			fNormalPriceMoney=sum(isnull(fNormalPrice,0)*isnull(a.期末库存,0)),avgInPriceMoney=sum(isnull(fmoney_left,0)),
			fEndQuantity_Diff=sum(isnull(a.盘点数量,0)),
			fAvgMoney_Diff=SUM(fAvgMoney_Diff)
			into #tmpGoodsListInfo_2
			from #temp_goodsKuCun_1 a,t_Goods b
          where a.cgoodsno=b.cGoodsno 
          group by a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,b.cGoodsTypename,
           b.bProducted ,b.cProductNo,b.fNormalPrice,b.fCKPrice

--if(select object_id('tempdb..##temp_Kucuntype_new')) is not null 
--      drop table ##temp_Kucuntype_new
--	select cGoodsNo=GoodsNo_Pdt,rk=sum(rkQty), ck=sum(ckQty), fc=sum(ckQty),xs=sum(xsQty),bgn=sum(BeginQty),qend=sum(EndQty)  
--	 into ##temp_Kucuntype_new
--	from #tmpGoodsListInfo_2
--	group by GoodsNo_Pdt
          
        
           select GoodsNo_Pdt ,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
			BeginDate,BeginQty=ISNULL(BeginQty,0),期初账面库存,期初盘点差异=期初盘点,
			EndDate,EndQty=isnull(EndQty,0),期末账面库存,期末盘点差异=期末盘点,
			rkQty=isnull(rkQty,0),thrkQty=isnull(thrkQty,0),ckQty=isnull(ckQty,0),fcQty=isnull(fcQty,0),
			dbQty=isnull(dbQty,0),bsQty=isnull(bsQty,0),byQty=isnull(byQty,0),djQty=isnull(djQty,0),xsQty=isnull(xsQty,0),
			ylckQty=isnull(ylckQty,0),cprkQty=isnull(cprkQty,0),dbrkQty=isnull(dbrkQty,0),
			fCKPrice=isnull(fCKPrice,0),fNormalPrice=isnull(fNormalPrice,0),--avgInPrice=isnull(avgInPrice,0),
			fCKPriceMoney=isnull(fCKPriceMoney,0),fNormalPriceMoney=isnull(fNormalPriceMoney,0),avgInPriceMoney=isnull(avgInPriceMoney,0),
			fAvgMoney_Diff=isnull(fAvgMoney_Diff,0),
			期末运营库存金额=isnull(fAvgMoney_Diff,0)+isnull(avgInPriceMoney,0),
			fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
			from #tmpGoodsListInfo_2 
			where BeginDate is not null
			union all
			select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
			BeginDate,BeginQty=sum(ISNULL(BeginQty,0)),期初账面库存=SUM(期初账面库存),期初盘点差异=SUM(期初盘点),
			EndDate,EndQty=sum(isnull(EndQty,0)),期末账面库存=SUM(期末账面库存),期末盘点差异=SUM(期末盘点),
			rkQty=sum(isnull(rkQty,0)),thrkQty=sum(isnull(thrkQty,0)),ckQty=sum(isnull(ckQty,0)),fcQty=sum(isnull(fcQty,0)),
			dbQty=sum(isnull(dbQty,0)),bsQty=sum(isnull(bsQty,0)),byQty=sum(isnull(byQty,0)),djQty=sum(isnull(djQty,0)),xsQty=sum(isnull(xsQty,0)),
			ylckQty=sum(isnull(ylckQty,0)),cprkQty=sum(isnull(cprkQty,0)),dbrkQty=sum(isnull(dbrkQty,0)),
			fCKPrice=null,fNormalPrice=null,--avgInPrice=null,
			fCKPriceMoney=sum(isnull(fCKPriceMoney,0)),fNormalPriceMoney=sum(isnull(fNormalPriceMoney,0)),avgInPriceMoney=sum(isnull(avgInPriceMoney,0)),
			fAvgMoney_Diff=sum(isnull(fAvgMoney_Diff,0)),
			期末运营库存金额=sum(isnull(fAvgMoney_Diff,0))+sum(isnull(avgInPriceMoney,0)),
			fEndQuantity_Diff=sum(isnull(fEndQuantity_Diff,0))
			from #tmpGoodsListInfo_2 
			where BeginDate is not null
			group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
			union all
			select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
			BeginDate,BeginQty=sum(ISNULL(BeginQty,0)),期初账面库存=SUM(期初账面库存),期初盘点差异=SUM(期初盘点),
			EndDate,EndQty=sum(isnull(EndQty,0)),期末账面库存=SUM(期末账面库存),期末盘点差异=SUM(期末盘点),
			rkQty=sum(isnull(rkQty,0)),thrkQty=sum(isnull(thrkQty,0)),ckQty=sum(isnull(ckQty,0)),fcQty=sum(isnull(fcQty,0)),
			dbQty=sum(isnull(dbQty,0)),bsQty=sum(isnull(bsQty,0)),byQty=sum(isnull(byQty,0)),djQty=sum(isnull(djQty,0)),xsQty=sum(isnull(xsQty,0)),
			ylckQty=sum(isnull(ylckQty,0)),cprkQty=sum(isnull(cprkQty,0)),dbrkQty=sum(isnull(dbrkQty,0)),
			fCKPrice=null,fNormalPrice=null,--avgInPrice=null,
			fCKPriceMoney=sum(isnull(fCKPriceMoney,0)),fNormalPriceMoney=sum(isnull(fNormalPriceMoney,0)),avgInPriceMoney=sum(isnull(avgInPriceMoney,0)),
			fAvgMoney_Diff=sum(isnull(fAvgMoney_Diff,0)),
			期末运营库存金额=sum(isnull(fAvgMoney_Diff,0))+sum(isnull(avgInPriceMoney,0)),
			fEndQuantity_Diff=sum(isnull(fEndQuantity_Diff,0))
			from #tmpGoodsListInfo_2 
			where BeginDate is not null
			group by BeginDate,EndDate
			order by cGoodsTypeno,GoodsNo_Pdt
			
		 
			 /*删除临时表*/
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList_1'))is not null drop table #tmp_WhGoodsList_1
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
      
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	    if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	   if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	   if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
	    if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
	    if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
	    if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	    if(select object_id('tempdb..#templast_pd1')) is not null drop table #templast_pd1
	    if(select object_id('tempdb..#templast_pdcGoodsNo')) is not null drop table #templast_pdcGoodsNo
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun_1'))is not null  drop table #temp_goodsKuCun_1
	    if(select object_id('tempdb..#tmpGoodsListInfo_2')) is not null drop table #tmpGoodsListInfo_2


GO
