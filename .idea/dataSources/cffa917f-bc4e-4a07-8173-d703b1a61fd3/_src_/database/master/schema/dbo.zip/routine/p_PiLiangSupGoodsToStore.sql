/*
exec p_PiLiangSupGoodstoStore '1001','05241921315930','888','系统维护'
*/
CREATE proc [dbo].[p_PiLiangSupGoodsToStore]
@cSupNO varchar(32),
@cTermID varchar(32),
@cOpertNo varchar(32),
@cOpertName varchar(32)
as
begin
   --获取下载门店。。

	if (select OBJECT_ID('tempdb..#temp_cStoreNo'))is not null  drop table #temp_cStoreNo
	create table #temp_cStoreNo(cStoreNo varchar(32),cSupNo varchar(32))
	
	if (select OBJECT_ID('tempdb..#temp_cStoreNoGoods'))is not null  drop table #temp_cStoreNoGoods
	create table #temp_cStoreNoGoods(cGoodsNO varchar(32),cSupNo varchar(32))

	exec(' 
	   insert into #temp_cStoreNo(cStoreNo,cSupNo)
	   select cStoreNo,'''+@cSupNO+'''
	   from U_key.dbo.temp_cStoreXiafa'+@cTermID+'
	   
	   insert into #temp_cStoreNoGoods(cGOodsNo,cSupNo)
	   select cGoodsNO,'''+@cSupNO+''' from U_key.dbo.temp_tableXiafa'+@cTermID+'
	')
	---获取已下发到门店的供应商
	
	if (select OBJECT_ID('tempdb..#temp_cStoreNoSup'))is not null  drop table #temp_cStoreNoSup	
	select a.cSupNo,a.cSupName,a.cStoreNo,a.cStoreName,a.cSupNoMain 
	into #temp_cStoreNoSup
	from t_SupplierStore a,#temp_cStoreNo b
	where a.cStoreNo=b.cStoreNo and a.cSupNoMain=b.cSupNo
	----获取待下发到门店商品
	if (select OBJECT_ID('tempdb..#temp_GoodsList'))is not null  drop table #temp_GoodsList
	select a.cGoodsNo,b.cSupNo,b.cSupName,b.cStoreNo,b.cStoreName,b.cSupNoMain 
	into #temp_GoodsList 
	from #temp_cStoreNoGoods a,#temp_cStoreNoSup b
	where a.cSupNo=b.cSupNoMain
	
 
	
	---获取门店已有商品
	delete a
	from #temp_GoodsList a,t_cStoreGoods b
	where a.cStoreNo=b.cStoreNo and a.cGoodsNo=b.cGoodsNo
	
 
	
	insert into t_cStoreGoods(
	cGoodsNo, cStoreNo, cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
	cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fVipPrice, cProductUnit, 
	cHelpCode, cTaxRate, cHezuoFangshi, cLevel, 
	bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
	fVipScore, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
	cSupNo, cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
	bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
	fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
	iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
	fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
	fPrice_Contract, fRatio, cUpdatePici, dUpdate, dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
	fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
	bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
	cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
	bMoneycard, fMoneyValue
	)
	select a.cGoodsNo, b.cStoreNo,b.cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
	cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fNormalPrice, cProductUnit, 
	cHelpCode, cTaxRate, cHezuoFangshi,  cLevel, 
	bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
	a.fNormalPrice, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
	b.cSupNo, b.cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
	bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
	fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
	iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
	fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
	fPrice_Contract, fRatio, cUpdatePici, GETDATE(), dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
	fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
	bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
	cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
	bMoneycard, fMoneyValue
	from t_Goods a,#temp_GoodsList b
	where a.cGoodsNo=b.cGoodsNo --and a.cSupNo=b.cSupNoMain
 


	insert into t_ChangeGoods(cGoodsNo,cStoreNo)
	select a.cGoodsNo,b.cStoreNo
	from t_Goods a,#temp_GoodsList b
	where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNoMain

    ---插入日志
     
	 ---写入日志
	declare @opertion varchar(256)
	
    set @opertion=dbo.getDayStr(GETDATE())+'批量下发商品信息到门店'

	exec p_Log @cOpertNo,@cOpertName,@opertion,'下发到门店'
	
end
GO
