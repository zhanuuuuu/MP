


CREATE    function f_GenInsheetno
(@cYear varchar(4),@cSupplierNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
	 --declare @iPatIndex int
   declare @strTemp varchar(32)
	 declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from wh_InWarehouse
                  where (cSupplierNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear
												)
												or
												(substring(cSheetno,7,PatIndex('%-%',cSheetno)-7)=@cSupplierNo
												 and datename(yyyy,dDate)=@cYear	
												)
                 )
	 
   if @cMaxSerno is null 
   begin
     set @strTemp='IN'+@cYear+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strTemp='IN'+@cYear+@cSupplierNo+'-'+@cMaxSerno
   end
   return  @strTemp

end


GO
