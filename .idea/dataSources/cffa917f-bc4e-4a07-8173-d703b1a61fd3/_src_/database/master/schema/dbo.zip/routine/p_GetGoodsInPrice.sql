/*
  p_GetGoodsInPrice '2014-11-25'
  
  select * from t_Goods_List_Public_YhTemp where csupno='1016'
*/
create procedure p_GetGoodsInPrice
@dStockDate datetime
as
begin
    declare @iMaxPre_Days int 
    declare @iMaxOver_Days int 

    set @iMaxPre_Days=0   
    set @iMaxOver_Days=0  
    

    select @iMaxPre_Days=max(isnull(iPre_Days,0)),@iMaxOver_Days=max(isnull(iOver_Days,0))  
    from t_supplier      
  
    if(select object_id('tempdb..#temp_GoodsList')) is not null drop table #temp_GoodsList  
    
    select a.cGoodsNo,a.cSupNo,iPre_Days=isnull(b.iPre_Days,0),iOver_Days=isnull(b.iOver_Days,0),
    fPrice_Contract=
    case when ISNULL(a.fPrice_Contract,0)=0 then isnull(a.fCKPrice,0) else a.fPrice_Contract end,
    a.fNormalPrice,fInPrice=a.fPrice_Contract,fPrice_SO=a.fNormalPrice,cBeizhu=CAST(null as varchar(128)),
    bInPricePlan=0   
    into #temp_GoodsList
    from t_Goods a,t_supplier b
    where a.cSupNo=b.cSupNo    

    if(select object_id('tempdb..#temp_InPricePlan')) is not null drop table #temp_InPricePlan  
    select cGoodsNo,fInPrice,fPrice_SO,dDateStart,dDateEnd,  
    cBeizhu='促销档期:'+cPloyNo+'['+dbo.getDayStr(dDateStart)+'至'+dbo.getDayStr(dDateEnd)+']'+'特进价'
    into #temp_InPricePlan  
    from t_PloyOfSale   
    where isnull(fInPrice,0)>0 and 
    (@dStockDate between (dDateStart-@iMaxPre_Days) and (dDateEnd+@iMaxOver_Days)
    )
 
    update a 
    set a.cBeizhu=b.cBeizhu,
    a.fInPrice=b.fInPrice,
    a.fPrice_SO=b.fPrice_SO,bInPricePlan=1
    from #temp_GoodsList a,#temp_InPricePlan b
    where a.cGoodsNo=b.cGoodsNo and
    (@dStockDate between (b.dDateStart-a.iPre_Days) and (b.dDateEnd+a.iOver_Days)
    )
    
    if(select object_id('t_Goods_List_Public_YhTemp')) is not null 
    begin 
       drop table t_Goods_List_Public_YhTemp
       select cGoodsNo,cSupNo,iPre_Days,iOver_Days,
       fPrice_Contract,fNormalPrice,fInPrice,fPrice_SO,cBeizhu,
       bInPricePlan into t_Goods_List_Public_YhTemp
       from #temp_GoodsList             
       CREATE INDEX IX_t_Goods_List_Public_YhTemp ON t_Goods_List_Public_YhTemp(cGoodsNo)
    end  else
    begin
        select cGoodsNo,cSupNo,iPre_Days,iOver_Days,
       fPrice_Contract,fNormalPrice,fInPrice,fPrice_SO,cBeizhu,
       bInPricePlan into t_Goods_List_Public_YhTemp
       from #temp_GoodsList      
       
       CREATE INDEX IX_t_Goods_List_Public_YhTemp ON t_Goods_List_Public_YhTemp(cGoodsNo)
    end
    
    
 
    if(select object_id('tempdb..#temp_Goods_List_Public')) is not null 
    begin
      delete from #temp_Goods_List_Public
      insert into #temp_Goods_List_Public(cGoodsNo,cSupNo,iPre_Days,iOver_Days,
       fPrice_Contract,fNormalPrice,fInPrice,fPrice_SO,cBeizhu,
       bInPricePlan)
      select cGoodsNo,cSupNo,iPre_Days,iOver_Days,
       fPrice_Contract,fNormalPrice,fInPrice,fPrice_SO,cBeizhu,
       bInPricePlan
      from #temp_GoodsList
    end  
 
    select cGoodsNo,cSupNo,iPre_Days,iOver_Days,
    fPrice_Contract,fNormalPrice,fInPrice,fPrice_SO,cBeizhu,
    bInPricePlan
    from #temp_GoodsList

 
/*
    select cGoodsNo,fInPrice,fPrice_SO,dDateStart,dDateEnd,  
    cBeizhu='促销档期:'+cPloyNo+'['+dbo.getDayStr(dDateStart)+'至'+dbo.getDayStr(dDateEnd)+']'+'特进价'   
    into #temp_InPricePlan  
    from t_PloyOfSale   
    where isnull(fInPrice,0)>0
    and (@dStockDate between (dDateStart-@iPre_Days) and (dDateEnd+@iOver_Days))  
*/
end
GO
