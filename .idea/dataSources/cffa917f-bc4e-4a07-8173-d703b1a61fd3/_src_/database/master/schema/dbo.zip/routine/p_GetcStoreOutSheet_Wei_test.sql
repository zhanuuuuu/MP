
/*
  exec p_GetcStoreOutSheet_Wei_test '1010','PSOT20171010-000033'
*/

CREATE proc p_GetcStoreOutSheet_Wei_test
@cStoreNo varchar(32),
@cSheetNo varchar(32)
as
if (select OBJECT_ID('tempdb..#temp_cStoreOutWhareGoodsList'))is not null  drop table #temp_cStoreOutWhareGoodsList
select distinct a.cGoodsNo into #temp_cStoreOutWhareGoodsList from 
wh_cStoreOutWarehouseDetail a left join t_Goods b on a.cGoodsNo=b.cGoodsNo
where a.cSheetno=@cSheetNo and isnull(a.fQuantity,0)<>0

 

 
-------获取总部有库存商品
if (select OBJECT_ID('tempdb..#temp_cStoreOutGoods'))is not null  drop table #temp_cStoreOutGoods
select a.cGoodsNo into #temp_cStoreOutGoods
from t_goodsKuCurQty_wei a,#temp_cStoreOutWhareGoodsList b
where a.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
and ISNULL(a.EndQty,0)>0

if (select OBJECT_ID('tempdb..#temp_cStoreOutWhareGoods'))is not null  drop table #temp_cStoreOutWhareGoods
select a.fPacks,iSeed=IDENTITY(int,1,1),a.cSheetno,a.iLineNo,a.cGoodsNo,  a.cGoodsName,cGoodsName01=a.cGoodsName+isnull(b.cSpec,''),
a.cBarcode,a.cUnitedNo,a.fQuantity,a.fInPrice,a.fInMoney,a.fTaxrate,a.bTax,a.fTaxPrice,
a.fTaxMoney,a.fNoTaxPrice,a.fNoTaxMoney,a.dProduct,a.fTimes,a.cProductSerno,
b.cUnit,b.cSpec,a.dCheck,fPackRatio=isnull(b.fPackRatio,1),cBeizhu=cBeizhu,cGoodsTypeNo,cGoodsTypeName
into #temp_cStoreOutWhareGoods
from wh_cStoreOutWarehouseDetail a,t_Goods b,#temp_cStoreOutGoods c 
where a.cSheetno=@cSheetNo  and a.cGoodsNo=b.cGoodsNo and b.cGoodsNo=c.cGoodsNo 
and a.cGoodsNo=c.cGoodsNo and isnull(a.fQuantity,0)<>0
order by iLineNo

 


insert into #temp_cStoreOutWhareGoods(
cSheetno,iLineNo,cGoodsNo,cGoodsName,cGoodsName01,cGoodsTypeName,fPackRatio,cGoodsTypeNo,cBeizhu
)
values('以下为库存<=0商品',99999,'','以下为库存<=0商品','以下为库存<=0商品','以下为库存<=0商品',0,'','0')


insert into #temp_cStoreOutWhareGoods(
 fPacks,cSheetno,iLineNo,cGoodsNo,cGoodsName,cGoodsName01,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,fTaxrate,
 bTax,fTaxPrice,fTaxMoney,fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,
 cUnit,cSpec,dCheck,fPackRatio,cBeizhu,cGoodsTypeNo,cGoodsTypeName
)
select a.fPacks,a.cSheetno,a.iLineNo,a.cGoodsNo,  a.cGoodsName,cGoodsName01=a.cGoodsName+isnull(b.cSpec,''),
a.cBarcode,a.cUnitedNo,a.fQuantity,a.fInPrice,a.fInMoney,a.fTaxrate,a.bTax,a.fTaxPrice,
a.fTaxMoney,a.fNoTaxPrice,a.fNoTaxMoney,a.dProduct,a.fTimes,a.cProductSerno,
b.cUnit,b.cSpec,a.dCheck,fPackRatio=isnull(b.fPackRatio,1),cBeizhu=cBeizhu,cGoodsTypeNo,cGoodsTypeName
from wh_cStoreOutWarehouseDetail a,t_Goods b 
where a.cSheetno=@cSheetNo  and a.cGoodsNo=b.cGoodsNo and isnull(a.fQuantity,0)<>0
and a.iLineNo not in(select iLineNo from #temp_cStoreOutWhareGoods)
order by iLineNo

---------当前库存大于0商品

select a.fPacks,a.cSheetno,iLineNo=iSeed,a.cGoodsNo,  a.cGoodsName,cGoodsName01=a.cGoodsName+isnull(a.cSpec,''),
a.cBarcode,a.cUnitedNo,a.fQuantity,a.fInPrice,a.fInMoney,a.fTaxrate,a.bTax,a.fTaxPrice,
a.fTaxMoney,a.fNoTaxPrice,a.fNoTaxMoney,a.dProduct,a.fTimes,a.cProductSerno,
a.cUnit,a.cSpec,a.dCheck,fPackRatio=isnull(a.fPackRatio,1),cBeizhu=cBeizhu,cGoodsTypeNo,cGoodsTypeName
from #temp_cStoreOutWhareGoods a
union all  
select fPacks=sum(isnull(fPacks,0)),cSheetno=null,iLineNo=999999 ,cGoodsNo='合计:',cGoodsName=null,cGoodsName01=null,
cBarcode=null,cUnitedNo=null,fQuantity=sum(isnull(fQuantity,0)),fInPrice=null,fInMoney=ROUND(sum(isnull(fInMoney,0)),2),
fTaxrate=null,bTax=null,fTaxPrice=null,fTaxMoney=sum(isnull(fTaxMoney,0)),fNoTaxPrice=null,fNoTaxMoney=sum(isnull(fNoTaxMoney,0)),
dProduct=null,fTimes=null,cProductSerno=null,cUnit=null,cSpec=null,
dChecK=null,fPackRatio=null,cBeizhu=null,cGoodsTypeNo=null,cGoodsTypeName=null
from #temp_cStoreOutWhareGoods
order by iSeed
GO
