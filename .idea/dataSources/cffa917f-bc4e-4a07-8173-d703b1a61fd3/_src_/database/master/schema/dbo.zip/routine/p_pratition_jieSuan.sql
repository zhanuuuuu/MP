/*
exec p_pratition_jieSuan '2006'
exec p_pratition_jieSuan '2007'
exec p_pratition_jieSuan '2009'
*/
/*
创建分区时间段
*/
create proc p_pratition_jieSuan
@setDatetime char(4)
as
begin
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_01]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-01-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_02]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-02-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_03]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-03-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_04]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-04-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_05]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-05-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_06]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-06-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_07]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-07-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_08]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-08-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_09]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-09-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_10]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-10-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_11]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-11-01')
	alter partition scheme jieSuanPartScheme
	next used [jieSuan_12]
	alter partition function jieSuanPartFun()
	split range(@setDatetime+'-12-01')

end


GO
