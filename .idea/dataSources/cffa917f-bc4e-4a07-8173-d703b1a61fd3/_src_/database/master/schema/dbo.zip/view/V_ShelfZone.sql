CREATE VIEW [dbo].[V_ShelfZone]
AS
--SELECT     cShelfName, cShelfNo, cZoneNo
--FROM         dbo.t_Shelf
select cZoneNo,cZoneName,cFatherZoneNo,cStoreNo from t_Zone 
union all
select cShelfNo,cShelfName,a.cZoneNo,b.cStoreNo from dbo.t_Shelf a,t_Zone b
where a.cZoneNo=b.cZoneNo
GO
