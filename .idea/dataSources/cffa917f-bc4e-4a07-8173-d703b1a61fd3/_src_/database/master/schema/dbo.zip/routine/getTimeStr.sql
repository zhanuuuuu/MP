


CREATE     function dbo.getTimeStr 
(@theDatetime datetime) returns varchar(16)
AS
begin
return (datename(hh,@theDatetime)+':'+
       case when len(datename(mi,@theDatetime))=1 
            then '0'+datename(mi,@theDatetime)
            else datename(mi,@theDatetime)
       end
       +':'+
       case when len(datename(ss,@theDatetime))=1 
            then '0'+datename(ss,@theDatetime)
            else datename(ss,@theDatetime)
       end

      )
end


GO
