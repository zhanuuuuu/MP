/*
select cSupNo into #admin_cSupNo from t_goods 
exec [eReport003_cSupNO-1]
'2012-04-16','2012-04-16','01'
*/
CREATE procedure [dbo].[eReport003_cSupNO-1]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as
--declare @dDate1 datetime,@dDate2 datetime,@cWHno varchar(32)
--select @dDate1='2011-11-01',@dDate2='2011-12-01',@cWHno='01'
--select cSupNo into #admin_cSupNo from t_goods 

--print  '01 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods 
select cGoodsNo into #temp_Goods from t_goods where bStorage=1 and cSupNo in 
(select cSupNo from #admin_cSupNo)
  
if(select object_id('tempdb..#temp_dateBase')) is not null drop table  #temp_dateBase
if(select object_id('tempdb..#temp_dateFrist')) is not null drop table  #temp_dateFrist
if(select object_id('tempdb..#temp_dateEnd')) is not null drop table  #temp_dateEnd
create table #temp_dateBase
(GoodsNo_Pdt varchar(64),cUnitedNo varchar(64),cGoodsName varchar(128),cBarcode varchar(64),cUnit varchar(64),cSpec varchar(64),
fNormalPrice money,cGoodsTypeno varchar(64),cGoodsTypename varchar(64),bProducted bit,cProductNo varchar(64),
BeginDate datetime,EndDate datetime,xsQty money,xsMoney money,fQty_CurWH money)

--查销售、库存
exec [p_saleAndkucun_byGoodsType_for_select] 
@dDate1,@dDate2,@cWhNo

select * into #temp_dateFrist
from #temp_dateBase

drop table #temp_dateBase

if (select object_id('tempdb..#temp_ready'))is not null drop table #temp_ready
if (select object_id('tempdb..#temp_ready1'))is not null drop table #temp_ready1
select cSupplierNo=CAST(null as varchar(50)),cSupName=CAST(null as varchar(50)),b.GoodsNo_Pdt,b.cGoodsName,
       b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,
       b.xsQty,b.xsMoney,EndQty=fQty_CurWH,b.BeginDate,fQty_CurWH,
       c_kun=cast(null as varchar(10)),c_type=CAST(null as varchar(50)),sale_days=CAST(null as money)
into #temp_ready1 
from #temp_dateFrist b
  
update a
set a.cSupplierNo=b.cSupNo,a.cSupName=b.cSupName
from #temp_ready1 a,t_goods b
where a.GoodsNo_Pdt=b.cGoodsNo

update #temp_ready1
set sale_days=
case when fQty_CurWH<0 then null else fQty_CurWH end/
case when xsQty=0 then null else xsQty end * 
case when DateDiff(d,@dDate1,@dDate2)=0 then 1 else DateDiff(d,@dDate1,@dDate2)end

update a
set c_kun='负库存'
from #temp_ready1 a
where fQty_CurWH<0

update #temp_ready1
set c_type='零销售',sale_days=1000
where xsQty=0

create table #temp_ready
(id int identity,cSupplierNo varchar(50),cSupName varchar(50),GoodsNo_Pdt varchar(50),cGoodsName varchar(50),cBarcode varchar(50),cUnit varchar(50),
cSpec varchar(50),fNormalPrice varchar(50),cGoodsTypeno varchar(50),cGoodsTypename varchar(50),xsQty money,xsMoney money,fQty_CurWH money,
BeginDate datetime,EndDate datetime,c_kun varchar(10),c_type varchar(50),sale_days real
)
insert into #temp_ready 
(cSupplierNo,cSupName,GoodsNo_Pdt,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,xsQty,xsMoney,fQty_CurWH,
BeginDate,EndDate,c_kun,c_type,sale_days)
select cSupplierNo,cSupName,GoodsNo_Pdt,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,xsQty,xsMoney,fQty_CurWH,
BeginDate,EndDate=@dDate2,c_kun,c_type,sale_days from #temp_ready1 where c_type is null order by c_kun desc,sale_days asc,xsMoney desc

declare @count int
declare @count_20 int
declare @count_80 int
select @count=COUNT(*) from #temp_ready where c_type is null
set @count_20=@count*0.2
set @count_80=@count*0.8
--select @count , @count_20, @count_80
update #temp_ready 
set c_type='畅销商品'
where id<=@count_20

update #temp_ready 
set c_type='一般商品'
where id<=@count_80 and id>@count_20

update #temp_ready 
set c_type='滞销商品'
where id>@count_80 

update #temp_ready
set c_kun='高库存'
where isnull(sale_days,0)>=20

update #temp_ready
set c_kun='低库存'
where isnull(sale_days,0)<=7

update #temp_ready
set c_kun='正常库存'
where c_kun is null

update #temp_ready
set c_type='零销售',sale_days=null
where xsQty=0

update a
set c_kun='负库存'
from #temp_ready a
where fQty_CurWH<0

select cSupplierNo as 供应商NO,cSupName as 供应商名称,GoodsNo_Pdt as 商品NO,'['+cBarcode+']' as 商品条码,cGoodsName as 商品名称,
cUnit as 规格,fNormalPrice as 售价,包装=cSpec,销售数量=isnull(xsQty,0),销售金额=isnull(xsMoney,0),库存数量=isnull(fQty_CurWH,0),
库存状态=c_kun,库存周转天数=sale_days,销售状态=c_type,cGoodsTypeno as 类别NO,cGoodsTypename as 类别名称,
BeginDate as 期初日期,EndDate as 期末日期
from #temp_ready
order by cSupplierNo,sale_days asc,xsMoney desc

--print  '04 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())


GO
