CREATE  proc [dbo].[fenjian_no]

@year varchar(20),
@no varchar(20)
as
select dbo.f_GencStoreOutsheetno_Sort(@year,@no) as fenjian_no
GO
