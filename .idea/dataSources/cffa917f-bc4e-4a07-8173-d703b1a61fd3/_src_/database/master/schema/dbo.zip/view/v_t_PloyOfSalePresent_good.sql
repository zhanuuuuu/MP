create view v_t_PloyOfSalePresent_good
as
  select cPresentPloyNo,a.cGoodsNo,b.cGoodsName,fQuantity_Present,cUnitedNo,
         cGoodsTypeno,cGoodsTypename,cBarcode,cUnit,cSpec,
         fNormalPrice,cProductUnit,cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,
         cLevel,bSuspend,bDeling,bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,
         fVipScore,bProducted,cProductNo
  from T_PloyOfSalePresent a left join t_Goods b
                             on a.cGoodsNo=b.cGoodsNo
GO
