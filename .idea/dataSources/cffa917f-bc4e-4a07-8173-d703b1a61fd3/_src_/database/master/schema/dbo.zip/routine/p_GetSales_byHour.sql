

/*
 exec p_GetSales_byHour '2015-12-27','2015-12-27','PosID asc'
*/


CREATE      procedure [dbo].[p_GetSales_byHour]
@cStoreNo varchar(32),
@datetime1 datetime,
@datetime2 datetime,
@orderbyField varchar(32)
as
begin
/*
	select lsdno=a.cSaleSheetno,shishou=a.fLastSettle,zdriqi=a.dSaleDate,PosID=b.PosName,
				 Hourpart=datepart(hh,cast('2000-01-01 '+a.cSaleTime as datetime)) 
	into #lsd_temp 
	from t_SaleSheet a left join dbo.t_posstation b
							 on substring(a.cSaleSheetno,1,2)=b.posid
	where a.dSaleDate between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)
*/
  ------**********从p_Account_Ref 获取结算信息***********-----
  if (select OBJECT_ID('tempdb..#temp_Jiesuan'))is not null drop table #temp_Jiesuan
    create table #temp_Jiesuan(zdriqi datetime,detail varchar(32),theyear varchar(32),themonth varchar(32),
	mianzhi money,zhaoling money,shishou money,
	shouyinyuanno varchar(32),shouyinyuanmc varchar(32),sheetno varchar(32),jiaozhang money,jstime datetime,cStoreNo varchar(32))
declare @date1 datetime
declare @date2 datetime
set @date1=@datetime1-1
set @date2=@datetime2+1

--exec p_Account_Ref @date1,@date2
   
     
     insert into #temp_Jiesuan(zdriqi,theyear,themonth,detail,
	mianzhi,zhaoling,shishou,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo)
		select zdriqi,theyear=cast(year(zdriqi) as varchar(4)),themonth=cast(month(zdriqi) as varchar(2)),detail,
	sum(mianzhi),sum(zhaoling),sum(shishou),shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo
	from jiesuan
	where zdriqi between @date1 and @date2    and (cStoreNo=@cStoreNo)
	 and isnull(bOnline,0)=0 
	group by  cast(year(zdriqi) as varchar(4)),cast(month(zdriqi) as varchar(2)),detail,
	zdriqi,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo
 
-----


  select cSaleSheetno=sheetno,fLastSettle=sum(isnull(shishou,0)),dSaleDate=zdriqi,cSaleTime=jstime,cStoreNo
	into #jiesuan
	--from jiesuan
	from #temp_Jiesuan
	where zdriqi between @datetime1-1 and @datetime2+1
	group by sheetno,zdriqi,jstime,cStoreNo

	select lsdno=a.cSaleSheetno,shishou=a.fLastSettle,zdriqi=a.dSaleDate,PosID=b.PosName,
				 Hourpart=datepart(hh,cast('2000-01-01 '+a.cSaleTime as datetime)) 
	into #lsd_temp 
	from #jiesuan a left join dbo.t_posstation b
							 on substring(a.cSaleSheetno,1,2)=b.posid
	where a.dSaleDate between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)
	and a.cStoreNo=b.cStoreNo and a.cStoreNo=@cStoreNo

	select a.PosID,PosSales=isnull((select sum(shishou) from #lsd_temp where PosID=a.PosID),0),
				 a.Hourpart,HourPartSales=sum(a.shishou)
	into #lsd_temp_1
	from #lsd_temp a  
	group by a.PosID,a.Hourpart

--select * from #lsd_temp_1 order by PosID,Hourpart

	create table #CubeList
	(
		PosID varchar(32),PosSales money,TotalSales money,H0 money,H1 money,H2 money,H3 money,H4 money,H5 money,H6 money,
		H7 money,H8 money,H9 money,H10 money,H11 money,H12 money,H13 money,H14 money,H15 money,H16 money,
		H17 money,H18 money,H19 money,H20 money,H21 money,H22 money,H23 money
	) 
  declare @PosID varchar(32) 
  declare @PosSales Money
	declare @HourPart int
	declare @HourPartSales money

	declare crCubeList cursor
	for
	select PosID,PosSales,Hourpart,HourPartSales from #lsd_temp_1 

  open crCubeList
	fetch next from crCubeList
	into @PosID,@PosSales,@Hourpart,@HourPartSales

	declare @strtmpPosID varchar(32)
	declare @strtmpPosSales varchar(32)
	declare @strtmpHourpart varchar(2)
	declare @strtmpHourPartSales varchar(32)
   
	while @@fetch_status=0 
	begin
		if (select count(PosID) from #CubeList where PosID=@PosID)=0
		begin
			insert into #CubeList (PosID,PosSales) values (@PosID,@PosSales)
		end 

		  set @strtmpHourpart=dbo.trim(cast(@Hourpart as varchar(2)))
		  set @strtmpPosID=@PosID
		  set @strtmpPosSales=cast(@PosSales as varchar(32))
		  set @strtmpHourPartSales=cast(@HourPartSales as varchar(32))

    	exec('update #CubeList set H'+@strtmpHourpart+'='+@strtmpHourPartSales+'
              where PosID='''+@PosID+'''

					')
		
		fetch next from crCubeList
		into @PosID,@PosSales,@Hourpart,@HourPartSales
	end

 	CLOSE crCubeList
  DEALLOCATE crCubeList

  update #CubeList set TotalSales=(select sum(PosSales) from #CubeList)
  --exec(' select * from  #CubeList order by '+@orderbyField)
  exec(' select PosID,PosSales,TotalSales,H0,H1,H2,H3,H4,H5,H6,
		H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,
		H17,H18,H19,H20,H21,H22,H23 
		from  #CubeList 
        union all
        select PosID=''合计：'',sum(PosSales),sum(TotalSales),sum(H0),sum(H1),sum(H2),sum(H3),sum(H4),sum(H5),sum(H6),
		sum(H7),sum(H8),sum(H9),sum(H10),sum(H11),sum(H12),sum(H13),sum(H14),sum(H15),sum(H16),
		sum(H17),sum(H18),sum(H19),sum(H20),sum(H21),sum(H22),sum(H23) 
		from  #CubeList 
        order by '+@orderbyField)
end


GO
