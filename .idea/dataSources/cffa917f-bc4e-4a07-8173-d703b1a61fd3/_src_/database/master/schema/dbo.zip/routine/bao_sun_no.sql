CREATE proc [dbo].[bao_sun_no]
@Year  varchar(20),
@cStore varchar(20)
as  
select dbo.[f_GenBaoSunSheetno]  (@Year,@cStore) as bao_sun_no
GO
