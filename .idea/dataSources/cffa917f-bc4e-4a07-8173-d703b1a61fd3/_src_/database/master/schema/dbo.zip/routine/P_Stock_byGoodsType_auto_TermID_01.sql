/*
  if (select OBJECT_ID('U_Key.dbo.temp_Goods'))is not null drop table U_Key.dbo.temp_Goods
select cGoodsNo into U_Key.dbo.temp_Goods from t_Goods   where  isnull(bStorage,0)=1

exec [P_Stock_byGoodsType_auto_TermID_01] '2016-12-10','2016-12-10','00' ,'','','000'
go

 exec P_Stock_byGoodsType_auto_TermID_01 '2000-01-01', '2016-12-14', '00', 1,'12141038524980','000'
 
*/
CREATE    procedure [dbo].[P_Stock_byGoodsType_auto_TermID_01] ----智能采购系统 采购辅助系统
@dBeginDate datetime,
@dEndDate datetime,
@WHno varchar(32),
@bJiaGong bit,
@cTermID varchar(32),
@cStoreNo varchar(32)
as
begin 



if(select object_id('tempdb..#temp_dateBaseForKuCun1')) is not null drop table  #temp_dateBaseForKuCun1
create table #temp_dateBaseForKuCun1
(cGoodsNo varchar(64),cGoodsTypeno varchar(64),BeginQty money,EndQty money,
 rkQty money,thrkQty money,ckQty money,fcQty money,dbQty money,bsQty money,byQty money,djQty money,
 xsQty money,ylckQty money,cprkQty money,dbrkQty money,
 fCKPrice money,fNormalPrice money,avgInPrice money,
 fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money,
 fEndQuantity_Diff money)
 
   if (select object_id('tempdb..#temp_Goods')) is not null 
 drop table #temp_Goods
 create table #temp_Goods(cGoodsNo varchar(32)) 
 exec('
   insert into #temp_Goods(cGoodsNo)
   select cGoodsNo from U_key.dbo.temp_Goods'+@cTermID+'
 ')
 

-- exec [P_x_SetCheckWh_byGoodsType] 
--@dBeginDate,@dEndDate,@WHno,@bJiaGong

exec [P_x_SetCheckWh_byGoodsType_log_TermID] @cStoreNo,@dBeginDate,@dEndDate,@WHno,@cTermID
 

--合并  开始
    select distinct 
           /*t_goods*/
           GoodsNo_Pdt=a.cGoodsNo,b.fCKPrice,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
           /*期初*/
           BeginDate=@dBeginDate,BeginQty=a.BeginQty,
           /*期末*/
           EndDate=@dEndDate,EndQty=a.EndQty,
           /*平均进价*/
           avgInPrice=a.avgInPrice,          
           a.rkQty,a.thrkQty,a.ckQty,a.fcQty,a.dbQty,a.bsQty,a.byQty,a.djQty,a.xsQty,DivideQty=a.cprkQty,PackQty=a.ylckQty,
           /*平均进价金额*/
           a.avgInPriceMoney,
           /*t_goods进价金额*/
           a.fCKPriceMoney,
           /*售价金额*/
           a.fNormalPriceMoney,
           /*期间盘点差异*/
           a.fEndQuantity_Diff,
           /*取自t_goods*/
           b.fPreservationUp,b.fPreservationDown,b.fPreservation_soft
    into #temp_goodsKuCun1 
    from #temp_dateBaseForKuCun1 a,t_goods b
    where a.cGoodsNo=b.cGoodsNo
   
   
--select * from #temp_dateBaseForKuCun1   
    
drop table #temp_dateBaseForKuCun1
--合并  结束

 if (select object_id('tempdb..#temp_result')) is not null 
   drop table #temp_result
   create table #temp_result (iLineNo int identity(1,1),bStocking bit DEFAULT ((0)),bSelected bit DEFAULT ((0)),
   cGoodsNo varchar(32),cUnitedNo varchar(32),cGoodsName varchar(64), cBarcode  varchar(32),cUnit  varchar(32)
   ,cSpec  varchar(32),cGoodsTypeno  varchar(32),  cGoodsTypename  varchar(64),bProducted bit,cProductNo  varchar(32), 
   BeginDate datetime,BeginQty money,EndDate datetime,EndQty money, rkQty money,thrkQty money,ckQty money,fcQty money,  
   dbQty money,bsQty money,byQty money,djQty money,xsQty money,DivideQty money,PackQty money, fCKPrice money,
   fNormalPrice money,avgInPrice money,  fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money, 
   fEndQuantity_Diff money,fPreservationUp money ,fPreservationDown money , fPreservation_soft money,fPrice_lowest money,
   fPrice_Highest money,fPrice_Last money, fQty_Adv money,fQty_Exe Money,fPrice_Exe money,cSupplierNo varchar(32),
   cSupplier varchar(64),fPrice_Contract money ,fQty_OnWay money,fMoney_OnWay money,fPackRatio money)  
 
  
    delete from #temp_result
    insert into #temp_result
    (cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	 rkQty,thrkQty,ckQty,fcQty,dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
     fCKPrice,fNormalPrice,avgInPrice,
     fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
     fEndQuantity_Diff,
     fPreservationUp ,fPreservationDown ,fPreservation_soft 
    )
    select cGoodsNo=GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
	      BeginDate,BeginQty=isnull(BeginQty,0),EndDate,EndQty=isnull(EndQty,0),
	      rkQty=isnull(rkQty,0),thrkQty=isnull(thrkQty,0),ckQty=isnull(ckQty,0),fcQty=isnull(fcQty,0),
	      dbQty=isnull(dbQty,0),bsQty=isnull(bsQty,0),byQty=isnull(byQty,0),djQty=isnull(djQty,0),xsQty=isnull(xsQty,0),
          DivideQty=isnull(DivideQty,0) ,PackQty=isnull(PackQty,0) ,
          fCKPrice=isnull(fCKPrice,0),fNormalPrice=isnull(fNormalPrice,0),avgInPrice=isnull(avgInPrice,0),
          fCKPriceMoney=isnull(fCKPriceMoney,0),fNormalPriceMoney=isnull(fNormalPriceMoney,0),avgInPriceMoney=isnull(avgInPriceMoney,0),
          fEndQuantity_Diff=isnull(fEndQuantity_Diff,0),
          fPreservationUp ,fPreservationDown ,fPreservation_soft 
	  from #temp_goodsKuCun1
	  order by cGoodsTypeno,GoodsNo_Pdt
	  

	
  
/*最优库存fPreservation_soft*/
  update #temp_result
  set fQty_Adv=null  

  update #temp_result
  set fQty_Adv=fPreservation_soft-EndQty  
  where isnull(fPreservation_soft,0)>0 and isnull(fPreservation_soft,0)>isnull(EndQty,0)
  
  update a set a.fPrice_Highest=b.fPrice_In
  from #temp_result a,(select cGoodsNo,fPrice_In=max(fInPrice) from dbo.wh_InWarehouseDetail  group by cGoodsNo )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.fPrice_lowest=b.fPrice_In
  from #temp_result a,(select cGoodsNo,fPrice_In=min(fInPrice) from  dbo.wh_InWarehouseDetail where fInPrice>0 group by cGoodsNo )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.fPrice_Last=b.fPrice_In
  from #temp_result a,
  (select distinct c.cGoodsNo,fPrice_In=c.fInPrice 
   from  
		( select p.cGoodsNo,p.fInPrice,dDateTime=q.dDate
		  from wh_InWarehouseDetail p,wh_InWarehouse q
		  where p.cSheetno=q.cSheetno
		)c,
		(select x.cGoodsNo,dDateTime=max(x.dDateTime) 
	 	 from 
   		     (select distinct n.cGoodsNo,dDateTime=m.dDate
   		 	  from dbo.wh_InWarehouse m,dbo.wh_InWarehouseDetail n
     		  where m.cSheetno=n.cSheetno
   		     )x  
   		 group by x.cGoodsNo
		) d
   where c.fInPrice>0  and c.cGoodsNo=d.cGoodsNo and c.dDateTime=d.dDateTime
  )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,a.bStocking=b.bStocking
  from #temp_result a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
   

			if (select OBJECT_ID('tempdb..#temp_Goods_Package'))is not null
			drop table #temp_Goods_Package
			if (select OBJECT_ID('tempdb..#temp_Goods_Package_Qty_0'))is not null
			drop table #temp_Goods_Package_Qty_0

			if (select OBJECT_ID('tempdb..#temp_Goods_Package_Qty_1'))is not null
			drop table #temp_Goods_Package_Qty_1
			if (select OBJECT_ID('tempdb..#temp_Goods_Package_Qty_2'))is not null
			drop table #temp_Goods_Package_Qty_2

			if (select OBJECT_ID('tempdb..#temp_Goods_Package_Qty'))is not null
			drop table #temp_Goods_Package_Qty

			select cGoodsNo,
			cGoodsNo_minPackage=case when ltrim(isnull(cGoodsNo_minPackage,''))='' then cGoodsNo_minPackage_tmp else cGoodsNo_minPackage end,
			fQty_minPackage,fPackRatio
			into #temp_Goods_Package
			from t_Goods
			where ltrim(isnull(cGoodsNo_minPackage_tmp,''))<>'' and isnull(bStorage,0)=1
			and isnull(bDeled,0)=0
			union 
			select cGoodsNo,
			cGoodsNo_minPackage=null,
			fQty_minPackage=null,fPackRatio
			from t_Goods
			where ltrim(isnull(cGoodsNo_minPackage_tmp,''))='' and isnull(bStorage,0)=1
			and isnull(bDeled,0)=0

			--select * from #temp_Goods_Package

			select a.cGoodsNo,a.cGoodsNo_minPackage,a.fQty_minPackage,a.fPackRatio,
			b.fQty_CurWH,cWHno=case when b.cWHno is null then @WHno else b.cWHno end
			into #temp_Goods_Package_Qty_0
			from #temp_Goods_Package a left join dbo.t_Goods_CurWH b
			on a.cGoodsNo=b.cGoodsNo and b.cWHno=@WHno
			select cGoodsNo,cGoodsNo_minPackage,fQty_minPackage,fPackRatio,
			fQty_CurWH,cWHno,
			fQty_CurWH_United=case when cGoodsNo_minPackage is null then fQty_CurWH else fQty_CurWH*fQty_minPackage end
			into #temp_Goods_Package_Qty_1
			from #temp_Goods_Package_Qty_0

			select cGoodsNo,fQty_minPackage,fPackRatio,
			fQty_CurWH,cWHno,fQty_CurWH_United
			into #temp_Goods_Package_Qty_2
			from #temp_Goods_Package_Qty_1
			where cGoodsNo_minPackage is null
			union all
			select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage,fPackRatio,
			fQty_CurWH,cWHno,fQty_CurWH_United
			from #temp_Goods_Package_Qty_1
			where cGoodsNo_minPackage is not null

			select cGoodsNo,fQty_CurWH_United=sum(isnull(fQty_CurWH_United,0))
			into #temp_Goods_Package_Qty
			from #temp_Goods_Package_Qty_2
			group by cGoodsNo

			select a.cGoodsNo,a.fQty_CurWH_United,
			fPreservationUp=isnull(b.fPreservationUp,0),
			fPreservationDown=isnull(b.fPreservationDown,0),
			fPreservation_soft=isnull(b.fPreservation_soft,0),
			b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.cGoodsTypeno,
			b.cGoodsTypename,b.bProducted,b.cProductNo
			into #temp_Goods_Package_Qty_result
			from #temp_Goods_Package_Qty a,t_Goods b
			where a.cGoodsNo=b.cGoodsNo

      select a.cGoodsNo,b.fQty_minPackage,b.cGoodsNo_minPackage_tmp
      into #temp_result_haveChild 
			from #temp_result a,t_Goods b
      where a.cGoodsNo=b.cGoodsNo and ltrim(isnull(b.cGoodsNo_minPackage_tmp,''))<>'' and isnull(b.bStorage,0)=1
			and isnull(b.bDeled,0)=0


      update a 
      set a.rkQty=a.rkQty+c.rkQty*b.fQty_minPackage,
          a.thrkQty=a.thrkQty+c.thrkQty*b.fQty_minPackage,
		  a.ckQty=a.ckQty+c.ckQty*b.fQty_minPackage,
		  a.fcQty=a.fcQty+c.fcQty*b.fQty_minPackage,
		  a.dbQty=a.dbQty+c.dbQty*b.fQty_minPackage,
		  a.bsQty=a.bsQty+c.bsQty*b.fQty_minPackage,
		  a.byQty=a.byQty+c.byQty*b.fQty_minPackage,
		  a.djQty=a.djQty+c.djQty*b.fQty_minPackage,
		  a.xsQty=a.xsQty+c.xsQty*b.fQty_minPackage,
		  a.DivideQty=a.DivideQty+c.DivideQty*b.fQty_minPackage,
		  a.PackQty=a.PackQty+c.PackQty*b.fQty_minPackage,
          a.fCKPrice=a.fCKPrice/case when b.fQty_minPackage>0 then  b.fQty_minPackage else null end,
          a.fNormalPrice=a.fNormalPrice/case when b.fQty_minPackage>0 then  b.fQty_minPackage else null end,
          a.avgInPrice=a.avgInPrice/case when b.fQty_minPackage>0 then  b.fQty_minPackage else null end
      from #temp_result a,#temp_result_haveChild b,#temp_result c
      where a.cGoodsNo=b.cGoodsNo_minPackage_tmp and c.cGoodsNo=b.cGoodsNo
       
      delete from #temp_result
      where cGoodsNo in (select cGoodsNo from #temp_result_haveChild)

      update a 
      set a.cUnitedNo=b.cUnitedNo,a.cGoodsName=b.cGoodsName,a.cBarcode=b.cBarcode,
		  a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.cGoodsTypeno=b.cGoodsTypeno,
		  a.cGoodsTypename=b.cGoodsTypename,a.bProducted=b.bProducted,a.cProductNo=b.cProductNo
	  from  #temp_result a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo

    update a 
      set a.EndQty=b.fQty_CurWH_United,a.fPreservationUp=b.fPreservationUp,
	      a.fPreservationDown=b.fPreservationDown,
		  a.fPreservation_soft=b.fPreservation_soft
	  from  #temp_result a,#temp_Goods_Package_Qty_result b
	  where a.cGoodsNo=b.cGoodsNo



			if (select OBJECT_ID('tempdb..#temp_Goods_Stock_OnWay'))is not null
			drop table #temp_Goods_Stock_OnWay
			  
    select y.cGoodsNo,y.fInMoney,y.fQuantity,cGoodsNo_child=z.cGoodsNo_minPackage,fQty_minPackage=isnull(z.fQty_minPackage,0),
    cGoodsNo_Result=CAST(null as varchar(32)),fQuantity_Result=CAST(null as money),cGoodsName_Result=CAST(null as varchar(64))
    into #temp_Goods_Stock_OnWay  
    from 
    (
			select x.cGoodsNo,fInMoney=sum(x.fInMoney),fQuantity=sum(x.fQuantity)
			from ( 
			select b.cSheetno,a.iLineNo,a.cGoodsNo,a.fInMoney,a.fQuantity
			from WH_StockDetail a,WH_Stock b
			where a.cSheetno=b.cSheetno and isnull(b.bReceive,0)=0
			and b.dDate<=@dEndDate 
			) x 
			group by cGoodsNo
	  ) y left join t_Goods z on y.cGoodsNo=z.cGoodsNo
	  
	  update #temp_Goods_Stock_OnWay
	  set cGoodsNo_Result=case when dbo.trim(isnull(cGoodsNo_child,''))='' then cGoodsNo else cGoodsNo_child end,
	  fQuantity_Result=case when dbo.trim(isnull(cGoodsNo_child,''))='' then fQuantity else fQuantity*fQty_minPackage end
	  update a set a.cGoodsName_Result=b.cGoodsName
	  from #temp_Goods_Stock_OnWay a,t_Goods b
	  where a.cGoodsNo_Result=b.cGoodsNo
	  
--	  alter table #temp_result add fQty_OnWay money,fMoney_OnWay money
	  
	  update a set a.fQty_OnWay=b.fQuantity_Result,a.fMoney_OnWay=b.fInMoney
	  from #temp_result a,#temp_Goods_Stock_OnWay b
	  where a.cGoodsNo=b.cGoodsNo_Result
	  drop table #temp_Goods_Stock_OnWay
	  
	  
	  update #temp_result set fQty_OnWay=null,fMoney_OnWay=null
	  where isnull(fQty_OnWay,0)=0
	  
	  
	  
	  
	    exec('
     insert into U_key.dbo.temp_result'+@cTermID+' 
    (bStocking,bSelected,cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff,fPreservationUp ,fPreservationDown , fPreservation_soft,fPrice_lowest,
   fPrice_Highest,fPrice_Last, fQty_Adv,fQty_Exe,fPrice_Exe,cSupplierNo,
   cSupplier ,fPackRatio,fQty_OnWay,fMoney_OnWay
    )
    select bStocking,bSelected,cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff,fPreservationUp ,fPreservationDown , fPreservation_soft,fPrice_lowest,
   fPrice_Highest,fPrice_Last, fQty_Adv,fQty_Exe,fPrice_Exe,cSupplierNo,
   cSupplier ,fPackRatio,fQty_OnWay,fMoney_OnWay
           from  #temp_result
           
  ')
	  
	   
	  --bReceive
     
      

/*
   fPrice_adv,fPrice_Exe,fPrice_lowest,fPrice_Highest,fPrice_last
*/

end

--[P_Stock_byGoodsType] '2008-11-23','2009-11-24','01'

GO
