/*
create table #tmpTypeCurQtyList(cTypeNo varchar(32))
create table #tmpSupCurQtyList(cSupNo varchar(32))

if (select object_id('tempdb..#tmpGoodsCurQtyList'))is not null
drop table #tmpGoodsCurQtyList
select cGoodsNo  into #tmpGoodsCurQtyList from 
t_Goods  where CGoodsno in ('110007')

exec p_Analyse_Acc '2015-04-05','2015-4-30','01',0

*/
 

CREATE procedure [dbo].[p_Analyse_Acc]
@dDate1 datetime,  -- 开始日期
@dDate2 datetime,  -- 结束日期
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商

as
begin
	--select cGoodsNo into #temp_Goods from t_Goods where cGoodsNo like '2103100%' order by cGoodsNo

if (select object_id('tempdb..#temp_Goods'))is not null
drop table #temp_Goods

select cGoodsNo,cGoodsName,cUnit,cSpec,cSupNO,cSupName,cGoodsTypeno,cGoodsTypeName,fCkPrice
into #temp_Goods
from t_goods
where isnull(bstorage,0)=1
and(
     ( 
        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpGoodsCurQtyList)
      )
      or
     ( 
        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpTypeCurQtyList)
     )
     or
     ( 
        (@Type=2)and cSupNo in(select distinct cSupNo from #tmpSupCurQtyList)
     )
)
declare @maxDaily datetime
select @maxDaily=max(dDate) from t_Daily_history
if @dDate2>@maxDaily
begin
   set @dDate2=@maxDaily
end


declare @maxWhDate datetime,@PosName varchar(32)
select @PosName=Pos_WH_Form from t_WareHouse

if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(dDateEnd),''2000-01-01'') from '+@PosName+'.dbo.t_WH_Form_Log_Month  with (nolock) ')
set @maxWhDate=(select dDate from #temp_maxWhdDate)



declare @d1 datetime
set @d1=CAST((cast(YEAR(@dDate1) as varchar(16))+'-'+cast(MONTH(@dDate1) as varchar(16))+'-01') AS DATETIME)

if @maxWhDate<@dDate1
begin
    select dDateBgn,a.cGoodsNo,cSupplierNo,a.cWHno,
				  a.销售数量0, a.销售金额0, 
				  a.特价销售数量, a.特价销售金额, 
				  a.正价销售数量, a.正价销售金额,
				  a.Pos客退数量1, a.Pos客退金额1,
				  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
				  a.退货入库数量1, a.退货入库金额1, 
				  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
				  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
				  a.调拨出库数量0, a.调拨出库金额0, 
				  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
				  a.成品入库数量1, a.成品入库金额1 
	into #temp_GoodsLog_Month
    from Pos_WH_Form.dbo.t_WH_Form_Log_Month a,#temp_Goods b
    where dDateEnd=@maxWhDate and a.cGoodsNo=b.cGoodsNo
    
    
    -----------获取期初的信息
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  a.销售数量0, a.销售金额0, 
					  a.特价销售数量, a.特价销售金额, 
					  a.正价销售数量, a.正价销售金额,
					  a.Pos客退数量1, a.Pos客退金额1,
					  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
					  a.退货入库数量1, a.退货入库金额1, 
					  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
					  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
					  a.调拨出库数量0, a.调拨出库金额0, 
					  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
					  a.成品入库数量1, a.成品入库金额1,
					  a.fQty_Left,a.fMoney_Left
	into #temp_WhFormbgn
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@dDate1-1 and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  a.销售数量0, a.销售金额0, 
					  a.特价销售数量, a.特价销售金额, 
					  a.正价销售数量, a.正价销售金额,
					  a.Pos客退数量1, a.Pos客退金额1,
					  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
					  a.退货入库数量1, a.退货入库金额1, 
					  a.调拨入库数量1, a.调拨入库金额1,  
					  a.出库数量0, a.出库金额0, 
					  a.报损数量0, a.报损金额0, 
					  a.返厂数量0, a.返厂金额0, 
					  a.调拨出库数量0, a.调拨出库金额0, 
					  a.差价数量, a.差价金额, 
					  a.原料出库数量0, a.原料出库金额0, 
					  a.成品入库数量1, a.成品入库金额1,
					  a.fQty_Left,a.fMoney_Left
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期 between @maxWhDate and @dDate1-1 and a.cGoodsNo=b.cGoodsNo  and a.iAttribute<>20
	union all
        -----------获取期初的信息
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					  0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@maxWhDate and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					    0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期=@maxWhDate and a.cGoodsNo=b.cGoodsNo and a.iAttribute<>20
 
 
    
    select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=null, Pos客退金额1=null,
					  入库数量1=null, 入库金额1=null, 报溢数量1=null, 报溢金额1=null, 
					   退货入库数量1=null,  退货入库金额1=null, 
					   调拨入库数量1=null,  调拨入库金额1=null,   
					   出库数量0=SUM(出库数量0),  出库金额0=SUM(出库金额0), 
					   报损数量0=SUM(报损数量0), 报损金额0=SUM(报损金额0),  返厂数量0=SUM(返厂数量0),  返厂金额0=SUM(返厂金额0), 
					   调拨出库数量0=SUM(调拨出库数量0),  调拨出库金额0=SUM(调拨出库金额0), 
					   差价数量=null,  差价金额=null,  原料出库数量0=SUM(原料出库数量0),  原料出库金额0=SUM(原料出库金额0), 
					   成品入库数量1=null,  成品入库金额1=null,
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into #temp_WhFormbgn_heji
    from #temp_WhFormbgn a
    group by  a.cgoodsno,a.cSupplierNo,a.cWHno
    
    --------获取这个时间段的入库。
    update a
    set   a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
		  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1,
		  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
		  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
		  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
		  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
		  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
		  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
		  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
		  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
		  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
		  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
    from #temp_WhFormbgn_heji a,#temp_WhFormbgn b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    and b.dDateTime between @maxWhDate and @dDate1-1
     

    
    ----期末
    select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
				  a.销售数量0, a.销售金额0, 
				  a.特价销售数量, a.特价销售金额, 
				  a.正价销售数量, a.正价销售金额,
				  a.Pos客退数量1, a.Pos客退金额1,
				  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
				  a.退货入库数量1, a.退货入库金额1, 
				  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
				  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
				  a.调拨出库数量0, a.调拨出库金额0, 
				  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
				  a.成品入库数量1, a.成品入库金额1,
				  a.fQty_Left,a.fMoney_Left
		into #temp_WhFormend
		from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
		where 业务日期=@dDate2 and a.cGoodsNo=b.cGoodsNo
		union all
		select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
						  a.销售数量0, a.销售金额0, 
						  a.特价销售数量, a.特价销售金额, 
						  a.正价销售数量, a.正价销售金额,
						  a.Pos客退数量1, a.Pos客退金额1,
						  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
						  a.退货入库数量1, a.退货入库金额1, 
						  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
						  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
						  a.调拨出库数量0, a.调拨出库金额0, 
						  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
						  a.成品入库数量1, a.成品入库金额1,
						  a.fQty_Left,a.fMoney_Left
		from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
		where 业务日期 between @maxWhDate and @dDate2 and a.cGoodsNo=b.cGoodsNo
			union all
        -----------获取期初的信息
	    select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					 0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@maxWhDate and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					  0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期=@maxWhDate and a.cGoodsNo=b.cGoodsNo and a.iAttribute<>20

    select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=null, Pos客退金额1=null,
					  入库数量1=null, 入库金额1=null, 报溢数量1=null, 报溢金额1=null, 
					   退货入库数量1=null,  退货入库金额1=null, 
					   调拨入库数量1=null,  调拨入库金额1=null,   
					    出库数量0=SUM(出库数量0),  出库金额0=SUM(出库金额0), 
					   报损数量0=SUM(报损数量0), 报损金额0=SUM(报损金额0),  返厂数量0=SUM(返厂数量0),  返厂金额0=SUM(返厂金额0), 
					   调拨出库数量0=SUM(调拨出库数量0),  调拨出库金额0=SUM(调拨出库金额0), 
					   差价数量=null,  差价金额=null,  原料出库数量0=SUM(原料出库数量0),  原料出库金额0=SUM(原料出库金额0), 
					   成品入库数量1=null,  成品入库金额1=null,
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into #temp_WhFormend_heji
    from #temp_WhFormend a
    group by  a.cgoodsno,a.cSupplierNo,a.cWHno
    
 
    
    --------获取这个时间段的入库。
    update a
    set   a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
		  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1,
		  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
		  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
		  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
		  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
		  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
		  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
		  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
		  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
		  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
		  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
    from #temp_WhFormend_heji a,#temp_WhFormend b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    and b.dDateTime between @dDate1 and @dDate2
 
    -------------------大转小。。。防止期初状态为大包装、期末状态为小包装不统一的现象。。
	update a
	set a.销售数量0=a.销售数量0*b.fQty_minPackage,a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
		a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,a.入库数量1=a.入库数量1*b.fQty_minPackage,a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
		a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,a.报损数量0=a.报损数量0*b.fQty_minPackage,
		a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage
		,a.差价数量=a.差价数量*b.fQty_minPackage
		,a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,a.成品入库数量1=a.成品入库数量1*b.fQty_minPackage,
		a.fQty_Left=a.fQty_Left*b.fQty_minPackage
	from #temp_WhFormbgn_heji a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


	update a
	set a.销售数量0=a.销售数量0*b.fQty_minPackage,a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
		a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,a.入库数量1=a.入库数量1*b.fQty_minPackage,a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
		a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,a.报损数量0=a.报损数量0*b.fQty_minPackage,
		a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage
		,a.差价数量=a.差价数量*b.fQty_minPackage
		,a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,a.成品入库数量1=a.成品入库数量1*b.fQty_minPackage,
		a.fQty_Left=a.fQty_Left*b.fQty_minPackage
	from #temp_WhFormend_heji a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

	-------------合并
	select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=sum(a.Pos客退数量1), Pos客退金额1=sum(a.Pos客退金额1),
					  入库数量1=sum(a.入库数量1), 入库金额1=sum(a.入库金额1),
					   报溢数量1=sum(a.报溢数量1), 报溢金额1=sum(a.报溢金额1), 
					  退货入库数量1=sum(a.退货入库数量1), 退货入库金额1=sum(a.退货入库金额1), 
					  调拨入库数量1=sum(a.调拨入库数量1), 调拨入库金额1=sum(a.调拨入库金额1),  
					  出库数量0=sum(a.出库数量0), 出库金额0=sum(a.出库金额0), 
					  报损数量0=sum(a.报损数量0), 报损金额0=sum(a.报损金额0), 
					  返厂数量0=sum(a.返厂数量0), 返厂金额0=sum(a.返厂金额0), 
					  调拨出库数量0=sum(a.调拨出库数量0), 调拨出库金额0=sum(a.调拨出库金额0), 
					  差价数量=sum(a.差价数量), 差价金额=sum(a.差价金额), 
					  原料出库数量0=sum(a.原料出库数量0), 原料出库金额0=sum(a.原料出库金额0), 
					  成品入库数量1=sum(a.成品入库数量1), 成品入库金额1=sum(a.成品入库金额1),
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into  #temp_WhFormbgn0		  
	from  #temp_WhFormbgn_heji a
	group by  a.cgoodsno,a.cSupplierNo,a.cWHno
	
	update a
	set   a.Pos客退数量1=isnull(a.Pos客退数量1,0)+isnull(b.Pos客退数量1,0), a.Pos客退金额1=isnull(a.Pos客退金额1,0)+isnull(b.Pos客退金额1,0),
	      a.入库数量1=isnull(a.入库数量1,0)+isnull(b.入库数量1,0), a.入库金额1=isnull(a.入库金额1,0)+isnull(b.入库金额1,0),
		  a.报溢数量1=isnull(a.报溢数量1,0)+isnull(b.报溢数量1,0), a.报溢金额1=isnull(a.报溢金额1,0)+isnull(b.报溢金额1,0), 
		  a.退货入库数量1=isnull(a.退货入库数量1,0)+isnull(b.退货入库数量1,0), a.退货入库金额1=isnull(a.退货入库金额1,0)+isnull(b.退货入库金额1,0), 
		  a.调拨入库数量1=isnull(a.调拨入库数量1,0)+isnull(b.调拨入库数量1,0), a.调拨入库金额1=isnull(a.调拨入库金额1,0)+isnull(b.调拨入库金额1,0),  
		  a.出库数量0=isnull(a.出库数量0,0)+isnull(b.出库数量0,0), a.出库金额0=isnull(a.出库金额0,0)+isnull(b.出库金额0,0), 
		  a.报损数量0=isnull(a.报损数量0,0)+isnull(b.报损数量0,0), a.报损金额0=isnull(a.报损金额0,0)+isnull(b.报损金额0,0), 
		  a.返厂数量0=isnull(a.返厂数量0,0)+isnull(b.返厂数量0,0), a.返厂金额0=isnull(a.返厂金额0,0)+isnull(b.返厂金额0,0), 
		  a.调拨出库数量0=isnull(a.调拨出库数量0,0)+isnull(b.调拨出库数量0,0), a.调拨出库金额0=isnull(a.调拨出库金额0,0)+isnull(b.调拨出库金额0,0), 
		  a.差价数量=isnull(a.差价数量,0)+isnull(b.差价数量,0), a.差价金额=isnull(a.差价金额,0)+isnull(b.差价金额,0), 
		  a.原料出库数量0=isnull(a.原料出库数量0,0)+isnull(b.原料出库数量0,0), a.原料出库金额0=isnull(a.原料出库金额0,0)+isnull(b.原料出库金额0,0), 
		  a.成品入库数量1=isnull(a.成品入库数量1,0)+isnull(b.成品入库数量1,0), a.成品入库金额1=isnull(a.成品入库金额1,0)+isnull(b.成品入库金额1,0),
		  a.销售数量0=isnull(a.销售数量0,0)+isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)+isnull(b.销售金额0,0),
		  a.特价销售数量=isnull(a.特价销售数量,0)+isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)+isnull(b.特价销售金额,0),
		  a.正价销售数量=isnull(a.正价销售数量,0)+isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)+isnull(b.正价销售金额,0)
	from #temp_WhFormbgn0 a,#temp_GoodsLog_Month b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	

	select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=sum(a.Pos客退数量1), Pos客退金额1=sum(a.Pos客退金额1),
					  入库数量1=sum(a.入库数量1), 入库金额1=sum(a.入库金额1),
					   报溢数量1=sum(a.报溢数量1), 报溢金额1=sum(a.报溢金额1), 
					  退货入库数量1=sum(a.退货入库数量1), 退货入库金额1=sum(a.退货入库金额1), 
					  调拨入库数量1=sum(a.调拨入库数量1), 调拨入库金额1=sum(a.调拨入库金额1),  
					  出库数量0=sum(a.出库数量0), 出库金额0=sum(a.出库金额0), 
					  报损数量0=sum(a.报损数量0), 报损金额0=sum(a.报损金额0), 
					  返厂数量0=sum(a.返厂数量0), 返厂金额0=sum(a.返厂金额0), 
					  调拨出库数量0=sum(a.调拨出库数量0), 调拨出库金额0=sum(a.调拨出库金额0), 
					  差价数量=sum(a.差价数量), 差价金额=sum(a.差价金额), 
					  原料出库数量0=sum(a.原料出库数量0), 原料出库金额0=sum(a.原料出库金额0), 
					  成品入库数量1=sum(a.成品入库数量1), 成品入库金额1=sum(a.成品入库金额1),
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into  #temp_WhFormend0		  
	from  #temp_WhFormend_heji a
	group by  a.cgoodsno,a.cSupplierNo,a.cWHno
 
    update a
	set   a.Pos客退数量1=isnull(a.Pos客退数量1,0)+isnull(b.Pos客退数量1,0), a.Pos客退金额1=isnull(a.Pos客退金额1,0)+isnull(b.Pos客退金额1,0),
	      a.入库数量1=isnull(a.入库数量1,0)+isnull(b.入库数量1,0), a.入库金额1=isnull(a.入库金额1,0)+isnull(b.入库金额1,0),
		  a.报溢数量1=isnull(a.报溢数量1,0)+isnull(b.报溢数量1,0), a.报溢金额1=isnull(a.报溢金额1,0)+isnull(b.报溢金额1,0), 
		  a.退货入库数量1=isnull(a.退货入库数量1,0)+isnull(b.退货入库数量1,0), a.退货入库金额1=isnull(a.退货入库金额1,0)+isnull(b.退货入库金额1,0), 
		  a.调拨入库数量1=isnull(a.调拨入库数量1,0)+isnull(b.调拨入库数量1,0), a.调拨入库金额1=isnull(a.调拨入库金额1,0)+isnull(b.调拨入库金额1,0),  
		  a.出库数量0=isnull(a.出库数量0,0)+isnull(b.出库数量0,0), a.出库金额0=isnull(a.出库金额0,0)+isnull(b.出库金额0,0), 
		  a.报损数量0=isnull(a.报损数量0,0)+isnull(b.报损数量0,0), a.报损金额0=isnull(a.报损金额0,0)+isnull(b.报损金额0,0), 
		  a.返厂数量0=isnull(a.返厂数量0,0)+isnull(b.返厂数量0,0), a.返厂金额0=isnull(a.返厂金额0,0)+isnull(b.返厂金额0,0), 
		  a.调拨出库数量0=isnull(a.调拨出库数量0,0)+isnull(b.调拨出库数量0,0), a.调拨出库金额0=isnull(a.调拨出库金额0,0)+isnull(b.调拨出库金额0,0), 
		  a.差价数量=isnull(a.差价数量,0)+isnull(b.差价数量,0), a.差价金额=isnull(a.差价金额,0)+isnull(b.差价金额,0), 
		  a.原料出库数量0=isnull(a.原料出库数量0,0)+isnull(b.原料出库数量0,0), a.原料出库金额0=isnull(a.原料出库金额0,0)+isnull(b.原料出库金额0,0), 
		  a.成品入库数量1=isnull(a.成品入库数量1,0)+isnull(b.成品入库数量1,0), a.成品入库金额1=isnull(a.成品入库金额1,0)+isnull(b.成品入库金额1,0),
		  a.销售数量0=isnull(a.销售数量0,0)+isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)+isnull(b.销售金额0,0),
		  a.特价销售数量=isnull(a.特价销售数量,0)+isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)+isnull(b.特价销售金额,0),
		  a.正价销售数量=isnull(a.正价销售数量,0)+isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)+isnull(b.正价销售金额,0)
    from #temp_WhFormend0 a,#temp_GoodsLog_Month b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    
      
select a.cgoodsno,a.cSupplierNo,a.cWHno,
				  销售数量_1=a.销售数量0, 销售金额_1=a.销售金额0, 
				  特价销售数量_1=a.特价销售数量, 特价销售金额_1=a.特价销售金额, 
				  正价销售数量_1=a.正价销售数量, 正价销售金额_1=a.正价销售金额,
				  Pos客退数量_1=a.Pos客退数量1, Pos客退金额_1=a.Pos客退金额1,
				  入库数量_1=a.入库数量1, 入库金额_1=a.入库金额1, 报溢数量_1=a.报溢数量1, 报溢金额_1=a.报溢金额1, 
				  退货入库数量_1=a.退货入库数量1, 退货入库金额_1=a.退货入库金额1, 
				  调拨入库数量_1=a.调拨入库数量1, 调拨入库金额_1=a.调拨入库金额1,  
				  出库数量_1=a.出库数量0, 出库金额_1=a.出库金额0, 
				  报损数量_1=a.报损数量0, 报损金额_1=a.报损金额0, 
				  返厂数量_1=a.返厂数量0, 返厂金额_1=a.返厂金额0, 
				  调拨出库数量_1=a.调拨出库数量0, 调拨出库金额_1=a.调拨出库金额0, 
				  差价数量_1=a.差价数量, 差价金额_1=a.差价金额, 
				  原料出库数量_1=a.原料出库数量0, 原料出库金额_1=a.原料出库金额0, 
				  成品入库数量_1=a.成品入库数量1, 成品入库金额_1=a.成品入库金额1,
				  fQty_Left_1=a.fQty_Left,fMoney_Left_1=a.fMoney_Left,
				  ------以上期末
				  ------期间
				  销售数量=a.销售数量0-b.销售数量0, 销售金额=a.销售金额0-b.销售金额0, 
				  特价销售数量=a.特价销售数量-b.特价销售数量, 特价销售金额=a.特价销售金额-b.特价销售金额, 
				  正价销售数量=a.正价销售数量-b.正价销售数量, 正价销售金额=a.正价销售金额-b.正价销售金额,
				  Pos客退数量=a.Pos客退数量1-b.Pos客退数量1, Pos客退金额=a.Pos客退金额1-b.Pos客退金额1,
				  入库数量=a.入库数量1-b.入库数量1, 入库金额=a.入库金额1-b.入库金额1, 
				  报溢数量=a.报溢数量1-b.报溢数量1, 报溢金额=a.报溢金额1-b.报溢金额1, 
				  退货入库数量=a.退货入库数量1-b.退货入库数量1, 退货入库金额=a.退货入库金额1-b.退货入库金额1, 
				  调拨入库数量=a.调拨入库数量1-b.调拨入库数量1, 调拨入库金额=a.调拨入库金额1-b.调拨入库金额1,  
				  出库数量=a.出库数量0-b.出库数量0, 出库金额=a.出库金额0-b.出库金额0, 
				  报损数量=a.报损数量0-b.报损数量0, 报损金额=a.报损金额0-b.报损金额0, 
				  返厂数量=a.返厂数量0-b.返厂数量0, 返厂金额=a.返厂金额0-b.返厂金额0, 
				  调拨出库数量=a.调拨出库数量0-b.调拨出库数量0, 调拨出库金额=a.调拨出库金额0-b.调拨出库金额0, 
				  差价数量=a.差价数量-b.差价数量, 差价金额=a.差价金额-b.差价金额, 
				  原料出库数量=a.原料出库数量0-b.原料出库数量0, 原料出库金额=a.原料出库金额0-b.原料出库金额0, 
				  成品入库数量=a.成品入库数量1-b.成品入库数量1, 成品入库金额=a.成品入库金额1-b.成品入库金额1,
				  fQty_Left=a.fQty_Left-b.fQty_Left,fMoney_Left=a.fMoney_Left-b.fMoney_Left,
				 --  以下期初
				  销售数量_0=b.销售数量0, 销售金额_0=b.销售金额0, 
				  特价销售数量_0=b.特价销售数量, 特价销售金额_0=b.特价销售金额, 
				  正价销售数量_0=b.正价销售数量, 正价销售金额_0=b.正价销售金额,
				  Pos客退数量_0=b.Pos客退数量1, Pos客退金额_0=b.Pos客退金额1,
				  入库数量_0=b.入库数量1, 入库金额_0=b.入库金额1, 报溢数量_0=b.报溢数量1, 报溢金额_0=b.报溢金额1, 
				  退货入库数量_0=b.退货入库数量1, 退货入库金额_0=b.退货入库金额1, 
				  调拨入库数量_0=b.调拨入库数量1, 调拨入库金额_0=b.调拨入库金额1,  
				  出库数量_0=b.出库数量0, 出库金额_0=b.出库金额0, 
				  报损数量_0=b.报损数量0, 报损金额_0=b.报损金额0, 
				  返厂数量_0=b.返厂数量0, 返厂金额_0=b.返厂金额0, 
				  调拨出库数量_0=b.调拨出库数量0, 调拨出库金额_0=b.调拨出库金额0, 
				  差价数量_0=b.差价数量, 差价金额_0=b.差价金额, 
				  原料出库数量_0=b.原料出库数量0, 原料出库金额_0=b.原料出库金额0, 
				  成品入库数量_0=b.成品入库数量1, 成品入库金额_0=b.成品入库金额1,
				  fQty_Left_0=b.fQty_Left,fMoney_Left_0=b.fMoney_Left
into #temp_Result
from #temp_WhFormend0 a left join #temp_WhFormbgn0 b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo


 
 
select  a.cGoodsNo,'开始日期'=@dDate1,'结束日期'=@dDate2,a.cWhNo,
  '期初库存数量'=a.fQty_Left_0,
	'期间库存变化数量'=a.fQty_Left,
	'fQty_CurWH'=a.fQty_Left_1,

  '期初累计销售金额'=a.销售金额_0,
  '期初累计销售数量'=a.销售数量_0,
  '期初累计正价销售金额'=a.正价销售金额_0,
  '期初累计正价销售数量'=a.正价销售数量_0,
  '期初累计特价销售金额'=a.特价销售金额_0,
  '期初累计特价销售数量'=a.特价销售数量_0,

	'期间累计销售金额'=a.销售金额,
	'期间累计销售数量'=a.销售数量,
	'期间累计正价销售金额'=a.正价销售金额,
	'期间累计正价销售数量'=a.正价销售数量,
	'期间累计特价销售金额'=a.特价销售金额,
	'期间累计特价销售数量'=a.特价销售数量,

  '期末累计销售金额'=a.销售金额_1,
  '期末累计销售数量'=a.销售数量_1,
  '期末累计正价销售金额'=a.正价销售金额_1,
  '期末累计正价销售数量'=a.正价销售数量_1,
  '期末累计特价销售金额'=a.特价销售金额_1,
  '期末累计特价销售数量'=a.特价销售数量_1,

	'期初累计采购入库数量'=a.入库数量_0,
	'期初累计采购入库金额'=a.入库金额_0,
	'期间采购入库数量'=a.入库数量,
	'期间采购入库金额'=a.入库金额,
	'期末累计采购入库数量'=a.入库数量_1,
	'期末累计采购入库金额'=a.入库金额_1,

	'期初累计调拨入库数量'=a.调拨入库数量_0,
	'期初累计调拨入库金额'=a.调拨入库金额_0,
	'期间调拨入库数量'=a.调拨入库数量,
	'期间调拨入库金额'=a.调拨入库金额,
	'期末累计调拨入库数量'=a.调拨入库数量_1,
	'期末累计调拨入库金额'=a.调拨入库金额_1,

	'期初累计客退数量'=a.退货入库数量_0,
	'期初累计客退金额'=a.退货入库金额_0,
	'期间客退数量'=a.退货入库数量,
	'期间客退金额'=a.退货入库金额,
	'期末累计客退数量'=a.退货入库数量_1,
	'期末累计客退金额'=a.退货入库金额_1,

	'期初累计报溢数量'=a.报溢数量_0,
	'期初累计报溢金额'=a.报溢金额_0,
	'期间报溢数量'=a.报溢数量,
	'期间报溢金额'=a.报溢金额,
	'期末累计报溢数量'=a.报溢数量_1,
	'期末累计报溢金额'=a.报溢金额_1,

	'期初累计成品入库数量'=a.成品入库数量_0,
	'期初累计成品入库金额'=a.成品入库金额_0,
	'期间成品入库数量'=a.成品入库数量,
	'期间成品入库金额'=a.成品入库金额,
	'期末累计成品入库数量'=a.成品入库数量_1,
	'期末累计成品入库金额'=a.成品入库数量_1,

	'期初累计返厂数量'=a.返厂数量_0,
	'期初累计返厂金额'=a.返厂金额_0,
	'期间返厂数量'=a.返厂数量,
	'期间返厂金额'=a.返厂金额,
	'期末累计返厂数量'=a.返厂数量_1,
	'期末累计返厂金额'=a.返厂金额_1,

	'期初累计出库数量'=a.出库数量_0,
	'期初累计出库金额'=a.出库金额_0,
	'期间出库数量'=a.出库数量,
	'期间出库金额'=a.出库金额,
	'期末累计出库数量'=a.出库数量_1,
	'期末累计出库金额'=a.出库金额_1,

	'期初累计调拨出库数量'=a.调拨出库数量_0,
	'期初累计调拨出库金额'=a.调拨出库金额_0,
	'期间调拨出库数量'=a.调拨出库数量,
	'期间调拨出库金额'=a.调拨出库金额,
	'期末累计调拨出库数量'=a.调拨出库数量_1,
	'期末累计调拨出库金额'=a.调拨出库金额_1,

	'期初累计报损数量'=a.报损数量_0,
	'期初累计报损金额'=a.报损金额_0,
	'期间报损数量'=a.报损数量,
	'期间报损金额'=a.报损金额,
	'期末累计报损数量'=a.报损数量_1,
	'期末累计报损金额'=a.报损金额_1,

	'期初累计原料出库数量'=a.原料出库数量_0,
	'期初累计原料出库金额'=a.原料出库金额_0,
	'期间原料出库数量'=a.原料出库数量,
	'期间原料出库金额'=a.原料出库金额,
	'期末累计原料出库数量'=a.原料出库数量_1,
	'期末累计原料出库金额'=a.原料出库金额_1,
  b.cGoodsName,b.cUnit,b.cSpec,b.cSupNo,b.cSupName,b.cGoodsTypeno,b.cGoodsTypename,
	b.fCKPrice
  from #temp_Result a,t_Goods b
  where a.cGoodsNO=b.cGoodsNo
   
end else
begin   
     
   if (select OBJECT_ID('tempdb..#temp_GoodsLog_Month_1'))is not null drop table #temp_GoodsLog_Month_1
   select dDateBgn,a.cGoodsNo,cSupplierNo,a.cWHno,
				  a.销售数量0, a.销售金额0, 
				  a.特价销售数量, a.特价销售金额, 
				  a.正价销售数量, a.正价销售金额,
				  a.Pos客退数量1, a.Pos客退金额1,
				  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
				  a.退货入库数量1, a.退货入库金额1, 
				  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
				  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
				  a.调拨出库数量0, a.调拨出库金额0, 
				  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
				  a.成品入库数量1, a.成品入库金额1 
	into #temp_GoodsLog_Month_1
    from Pos_WH_Form.dbo.t_WH_Form_Log_Month a,#temp_Goods b
    where dDateBgn=DATEADD(MONTH,-1,@d1) and a.cGoodsNo=b.cGoodsNo
    
    if (select OBJECT_ID('tempdb..#temp_WhFormbgn_1'))is not null drop table #temp_WhFormbgn_1
    -----------获取期初的信息
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  a.销售数量0, a.销售金额0, 
					  a.特价销售数量, a.特价销售金额, 
					  a.正价销售数量, a.正价销售金额,
					  a.Pos客退数量1, a.Pos客退金额1,
					  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
					  a.退货入库数量1, a.退货入库金额1, 
					  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
					  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
					  a.调拨出库数量0, a.调拨出库金额0, 
					  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
					  a.成品入库数量1, a.成品入库金额1,
					  a.fQty_Left,a.fMoney_Left
	into #temp_WhFormbgn_1
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@dDate1-1 and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  a.销售数量0, a.销售金额0, 
					  a.特价销售数量, a.特价销售金额, 
					  a.正价销售数量, a.正价销售金额,
					  a.Pos客退数量1, a.Pos客退金额1,
					  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
					  a.退货入库数量1, a.退货入库金额1, 
					  a.调拨入库数量1, a.调拨入库金额1,  
					  a.出库数量0, a.出库金额0, 
					  a.报损数量0, a.报损金额0, 
					  a.返厂数量0, a.返厂金额0, 
					  a.调拨出库数量0, a.调拨出库金额0, 
					  a.差价数量, a.差价金额, 
					  a.原料出库数量0, a.原料出库金额0, 
					  a.成品入库数量1, a.成品入库金额1,
					  a.fQty_Left,a.fMoney_Left
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期 between @d1-1 and @dDate1-1 and a.cGoodsNo=b.cGoodsNo  and a.iAttribute<>20
	union all
        -----------获取期初的信息
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					  0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@d1-1 and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					    0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期=@d1-1 and a.cGoodsNo=b.cGoodsNo and a.iAttribute<>20
 
 
    if (select OBJECT_ID('tempdb..#temp_WhFormbgn_heji_1'))is not null drop table #temp_WhFormbgn_heji_1
    select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=null, Pos客退金额1=null,
					  入库数量1=null, 入库金额1=null, 报溢数量1=null, 报溢金额1=null, 
					   退货入库数量1=null,  退货入库金额1=null, 
					   调拨入库数量1=null,  调拨入库金额1=null,   
					   出库数量0=SUM(出库数量0),  出库金额0=SUM(出库金额0), 
					   报损数量0=SUM(报损数量0), 报损金额0=SUM(报损金额0),  返厂数量0=SUM(返厂数量0),  返厂金额0=SUM(返厂金额0), 
					   调拨出库数量0=SUM(调拨出库数量0),  调拨出库金额0=SUM(调拨出库金额0), 
					   差价数量=null,  差价金额=null,  原料出库数量0=SUM(原料出库数量0),  原料出库金额0=SUM(原料出库金额0), 
					   成品入库数量1=null,  成品入库金额1=null,
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into #temp_WhFormbgn_heji_1
    from #temp_WhFormbgn_1 a
    group by  a.cgoodsno,a.cSupplierNo,a.cWHno
    
    --------获取这个时间段的入库。
 
    update a
    set   a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
		  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1,
		  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
		  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
		  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
		  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
		  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
		  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
		  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
		  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
		  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
		  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
    from #temp_WhFormbgn_heji_1 a,#temp_WhFormbgn_1 b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    and b.dDateTime between @d1-1 and @dDate1-1
     

    if (select OBJECT_ID('tempdb..#temp_WhFormend_1'))is not null drop table #temp_WhFormend_1
    ----期末
    select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
				  a.销售数量0, a.销售金额0, 
				  a.特价销售数量, a.特价销售金额, 
				  a.正价销售数量, a.正价销售金额,
				  a.Pos客退数量1, a.Pos客退金额1,
				  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
				  a.退货入库数量1, a.退货入库金额1, 
				  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
				  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
				  a.调拨出库数量0, a.调拨出库金额0, 
				  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
				  a.成品入库数量1, a.成品入库金额1,
				  a.fQty_Left,a.fMoney_Left
		into #temp_WhFormend_1
		from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
		where 业务日期=@dDate2 and a.cGoodsNo=b.cGoodsNo
		union all
		select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
						  a.销售数量0, a.销售金额0, 
						  a.特价销售数量, a.特价销售金额, 
						  a.正价销售数量, a.正价销售金额,
						  a.Pos客退数量1, a.Pos客退金额1,
						  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, 
						  a.退货入库数量1, a.退货入库金额1, 
						  a.调拨入库数量1, a.调拨入库金额1,  a.出库数量0, a.出库金额0, 
						  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, 
						  a.调拨出库数量0, a.调拨出库金额0, 
						  a.差价数量, a.差价金额, a.原料出库数量0, a.原料出库金额0, 
						  a.成品入库数量1, a.成品入库金额1,
						  a.fQty_Left,a.fMoney_Left
		from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
		where 业务日期 between @d1-1 and @dDate2 and a.cGoodsNo=b.cGoodsNo
			union all
        -----------获取期初的信息
	    select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					 0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_1 a,#temp_Goods b
	where 业务日期=@d1-1 and a.cGoodsNo=b.cGoodsNo
	union all
	select dDateTime,a.cgoodsno,a.cSupplierNo,a.cWHno,
					  -a.销售数量0, -a.销售金额0, 
					  -a.特价销售数量, -a.特价销售金额, 
					  -a.正价销售数量, -a.正价销售金额,
					  0, 0,
					  0, 0, 0, 0, 
					  0, 0, 
					  0, 0,  
					  -a.出库数量0, -a.出库金额0, 
					  -a.报损数量0, -a.报损金额0, 
					  -a.返厂数量0, -a.返厂金额0, 
					  -a.调拨出库数量0, -a.调拨出库金额0, 
					  0, 0, -a.原料出库数量0, -a.原料出库金额0,
					  0, 0,
					  0,0 
	from Pos_WH_Form.dbo.t_WH_Form_Log_0 a,#temp_Goods b
	where 业务日期=@d1-1 and a.cGoodsNo=b.cGoodsNo and a.iAttribute<>20

    if (select OBJECT_ID('tempdb..#temp_WhFormend_heji_1'))is not null drop table #temp_WhFormend_heji_1
    select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=null, Pos客退金额1=null,
					  入库数量1=null, 入库金额1=null, 报溢数量1=null, 报溢金额1=null, 
					   退货入库数量1=null,  退货入库金额1=null, 
					   调拨入库数量1=null,  调拨入库金额1=null,   
					    出库数量0=SUM(出库数量0),  出库金额0=SUM(出库金额0), 
					   报损数量0=SUM(报损数量0), 报损金额0=SUM(报损金额0),  返厂数量0=SUM(返厂数量0),  返厂金额0=SUM(返厂金额0), 
					   调拨出库数量0=SUM(调拨出库数量0),  调拨出库金额0=SUM(调拨出库金额0), 
					   差价数量=null,  差价金额=null,  原料出库数量0=SUM(原料出库数量0),  原料出库金额0=SUM(原料出库金额0), 
					   成品入库数量1=null,  成品入库金额1=null,
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into #temp_WhFormend_heji_1
    from #temp_WhFormend_1 a
    group by  a.cgoodsno,a.cSupplierNo,a.cWHno
    
 
    
    --------获取这个时间段的入库。
    update a
    set   a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
		  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1,
		  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
		  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
		  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
		  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
		  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
		  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
		  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
		  a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
		  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
		  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
    from #temp_WhFormend_heji_1 a,#temp_WhFormend_1 b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    and b.dDateTime between @d1-1 and @dDate2
 
    -------------------大转小。。。防止期初状态为大包装、期末状态为小包装不统一的现象。。
	update a
	set a.销售数量0=a.销售数量0*b.fQty_minPackage,a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
		a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,a.入库数量1=a.入库数量1*b.fQty_minPackage,a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
		a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,a.报损数量0=a.报损数量0*b.fQty_minPackage,
		a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage
		,a.差价数量=a.差价数量*b.fQty_minPackage
		,a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,a.成品入库数量1=a.成品入库数量1*b.fQty_minPackage,
		a.fQty_Left=a.fQty_Left*b.fQty_minPackage
	from #temp_WhFormbgn_heji_1 a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


	update a
	set a.销售数量0=a.销售数量0*b.fQty_minPackage,a.特价销售数量=a.特价销售数量*b.fQty_minPackage,a.正价销售数量=a.正价销售数量*b.fQty_minPackage,
		a.Pos客退数量1=a.Pos客退数量1*b.fQty_minPackage,a.入库数量1=a.入库数量1*b.fQty_minPackage,a.报溢数量1=a.报溢数量1*b.fQty_minPackage,
		a.退货入库数量1=a.退货入库数量1*b.fQty_minPackage,a.调拨入库数量1=a.调拨入库数量1*b.fQty_minPackage,a.报损数量0=a.报损数量0*b.fQty_minPackage,
		a.返厂数量0=a.返厂数量0*b.fQty_minPackage,a.调拨出库数量0=a.调拨出库数量0*b.fQty_minPackage
		,a.差价数量=a.差价数量*b.fQty_minPackage
		,a.原料出库数量0=a.原料出库数量0*b.fQty_minPackage,a.成品入库数量1=a.成品入库数量1*b.fQty_minPackage,
		a.fQty_Left=a.fQty_Left*b.fQty_minPackage
	from #temp_WhFormend_heji_1 a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

	-------------合并
	if (select OBJECT_ID('tempdb..#temp_WhFormbgn0_1'))is not null drop table #temp_WhFormbgn0_1
	select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=sum(a.Pos客退数量1), Pos客退金额1=sum(a.Pos客退金额1),
					  入库数量1=sum(a.入库数量1), 入库金额1=sum(a.入库金额1),
					   报溢数量1=sum(a.报溢数量1), 报溢金额1=sum(a.报溢金额1), 
					  退货入库数量1=sum(a.退货入库数量1), 退货入库金额1=sum(a.退货入库金额1), 
					  调拨入库数量1=sum(a.调拨入库数量1), 调拨入库金额1=sum(a.调拨入库金额1),  
					  出库数量0=sum(a.出库数量0), 出库金额0=sum(a.出库金额0), 
					  报损数量0=sum(a.报损数量0), 报损金额0=sum(a.报损金额0), 
					  返厂数量0=sum(a.返厂数量0), 返厂金额0=sum(a.返厂金额0), 
					  调拨出库数量0=sum(a.调拨出库数量0), 调拨出库金额0=sum(a.调拨出库金额0), 
					  差价数量=sum(a.差价数量), 差价金额=sum(a.差价金额), 
					  原料出库数量0=sum(a.原料出库数量0), 原料出库金额0=sum(a.原料出库金额0), 
					  成品入库数量1=sum(a.成品入库数量1), 成品入库金额1=sum(a.成品入库金额1),
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into  #temp_WhFormbgn0_1		  
	from  #temp_WhFormbgn_heji_1 a
	group by  a.cgoodsno,a.cSupplierNo,a.cWHno
 
	
	update a
	set   a.Pos客退数量1=isnull(a.Pos客退数量1,0)+isnull(b.Pos客退数量1,0), a.Pos客退金额1=isnull(a.Pos客退金额1,0)+isnull(b.Pos客退金额1,0),
	      a.入库数量1=isnull(a.入库数量1,0)+isnull(b.入库数量1,0), a.入库金额1=isnull(a.入库金额1,0)+isnull(b.入库金额1,0),
		  a.报溢数量1=isnull(a.报溢数量1,0)+isnull(b.报溢数量1,0), a.报溢金额1=isnull(a.报溢金额1,0)+isnull(b.报溢金额1,0), 
		  a.退货入库数量1=isnull(a.退货入库数量1,0)+isnull(b.退货入库数量1,0), a.退货入库金额1=isnull(a.退货入库金额1,0)+isnull(b.退货入库金额1,0), 
		  a.调拨入库数量1=isnull(a.调拨入库数量1,0)+isnull(b.调拨入库数量1,0), a.调拨入库金额1=isnull(a.调拨入库金额1,0)+isnull(b.调拨入库金额1,0),  
		  a.出库数量0=isnull(a.出库数量0,0)+isnull(b.出库数量0,0), a.出库金额0=isnull(a.出库金额0,0)+isnull(b.出库金额0,0), 
		  a.报损数量0=isnull(a.报损数量0,0)+isnull(b.报损数量0,0), a.报损金额0=isnull(a.报损金额0,0)+isnull(b.报损金额0,0), 
		  a.返厂数量0=isnull(a.返厂数量0,0)+isnull(b.返厂数量0,0), a.返厂金额0=isnull(a.返厂金额0,0)+isnull(b.返厂金额0,0), 
		  a.调拨出库数量0=isnull(a.调拨出库数量0,0)+isnull(b.调拨出库数量0,0), a.调拨出库金额0=isnull(a.调拨出库金额0,0)+isnull(b.调拨出库金额0,0), 
		  a.差价数量=isnull(a.差价数量,0)+isnull(b.差价数量,0), a.差价金额=isnull(a.差价金额,0)+isnull(b.差价金额,0), 
		  a.原料出库数量0=isnull(a.原料出库数量0,0)+isnull(b.原料出库数量0,0), a.原料出库金额0=isnull(a.原料出库金额0,0)+isnull(b.原料出库金额0,0), 
		  a.成品入库数量1=isnull(a.成品入库数量1,0)+isnull(b.成品入库数量1,0), a.成品入库金额1=isnull(a.成品入库金额1,0)+isnull(b.成品入库金额1,0),
		  a.销售数量0=isnull(a.销售数量0,0)+isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)+isnull(b.销售金额0,0),
		  a.特价销售数量=isnull(a.特价销售数量,0)+isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)+isnull(b.特价销售金额,0),
		  a.正价销售数量=isnull(a.正价销售数量,0)+isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)+isnull(b.正价销售金额,0)
	from #temp_WhFormbgn0_1 a,#temp_GoodsLog_Month_1 b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	

	
    if (select OBJECT_ID('tempdb..#temp_WhFormend0_1'))is not null drop table #temp_WhFormend0_1
	select  a.cgoodsno,a.cSupplierNo,a.cWHno,
					  销售数量0=sum(a.销售数量0), 销售金额0=sum(a.销售金额0), 
					  特价销售数量=sum(a.特价销售数量), 特价销售金额=sum(a.特价销售金额), 
					  正价销售数量=sum(a.正价销售数量), 正价销售金额=sum(a.正价销售金额),
					  Pos客退数量1=sum(a.Pos客退数量1), Pos客退金额1=sum(a.Pos客退金额1),
					  入库数量1=sum(a.入库数量1), 入库金额1=sum(a.入库金额1),
					   报溢数量1=sum(a.报溢数量1), 报溢金额1=sum(a.报溢金额1), 
					  退货入库数量1=sum(a.退货入库数量1), 退货入库金额1=sum(a.退货入库金额1), 
					  调拨入库数量1=sum(a.调拨入库数量1), 调拨入库金额1=sum(a.调拨入库金额1),  
					  出库数量0=sum(a.出库数量0), 出库金额0=sum(a.出库金额0), 
					  报损数量0=sum(a.报损数量0), 报损金额0=sum(a.报损金额0), 
					  返厂数量0=sum(a.返厂数量0), 返厂金额0=sum(a.返厂金额0), 
					  调拨出库数量0=sum(a.调拨出库数量0), 调拨出库金额0=sum(a.调拨出库金额0), 
					  差价数量=sum(a.差价数量), 差价金额=sum(a.差价金额), 
					  原料出库数量0=sum(a.原料出库数量0), 原料出库金额0=sum(a.原料出库金额0), 
					  成品入库数量1=sum(a.成品入库数量1), 成品入库金额1=sum(a.成品入库金额1),
					  fQty_Left=sum(a.fQty_Left),fMoney_Left=sum(a.fMoney_Left)
	into  #temp_WhFormend0_1	  
	from  #temp_WhFormend_heji_1 a
	group by  a.cgoodsno,a.cSupplierNo,a.cWHno
 
    update a
	set   a.Pos客退数量1=isnull(a.Pos客退数量1,0)+isnull(b.Pos客退数量1,0), a.Pos客退金额1=isnull(a.Pos客退金额1,0)+isnull(b.Pos客退金额1,0),
	      a.入库数量1=isnull(a.入库数量1,0)+isnull(b.入库数量1,0), a.入库金额1=isnull(a.入库金额1,0)+isnull(b.入库金额1,0),
		  a.报溢数量1=isnull(a.报溢数量1,0)+isnull(b.报溢数量1,0), a.报溢金额1=isnull(a.报溢金额1,0)+isnull(b.报溢金额1,0), 
		  a.退货入库数量1=isnull(a.退货入库数量1,0)+isnull(b.退货入库数量1,0), a.退货入库金额1=isnull(a.退货入库金额1,0)+isnull(b.退货入库金额1,0), 
		  a.调拨入库数量1=isnull(a.调拨入库数量1,0)+isnull(b.调拨入库数量1,0), a.调拨入库金额1=isnull(a.调拨入库金额1,0)+isnull(b.调拨入库金额1,0),  
		  a.出库数量0=isnull(a.出库数量0,0)+isnull(b.出库数量0,0), a.出库金额0=isnull(a.出库金额0,0)+isnull(b.出库金额0,0), 
		  a.报损数量0=isnull(a.报损数量0,0)+isnull(b.报损数量0,0), a.报损金额0=isnull(a.报损金额0,0)+isnull(b.报损金额0,0), 
		  a.返厂数量0=isnull(a.返厂数量0,0)+isnull(b.返厂数量0,0), a.返厂金额0=isnull(a.返厂金额0,0)+isnull(b.返厂金额0,0), 
		  a.调拨出库数量0=isnull(a.调拨出库数量0,0)+isnull(b.调拨出库数量0,0), a.调拨出库金额0=isnull(a.调拨出库金额0,0)+isnull(b.调拨出库金额0,0), 
		  a.差价数量=isnull(a.差价数量,0)+isnull(b.差价数量,0), a.差价金额=isnull(a.差价金额,0)+isnull(b.差价金额,0), 
		  a.原料出库数量0=isnull(a.原料出库数量0,0)+isnull(b.原料出库数量0,0), a.原料出库金额0=isnull(a.原料出库金额0,0)+isnull(b.原料出库金额0,0), 
		  a.成品入库数量1=isnull(a.成品入库数量1,0)+isnull(b.成品入库数量1,0), a.成品入库金额1=isnull(a.成品入库金额1,0)+isnull(b.成品入库金额1,0),
		  a.销售数量0=isnull(a.销售数量0,0)+isnull(b.销售数量0,0),a.销售金额0=isnull(a.销售金额0,0)+isnull(b.销售金额0,0),
		  a.特价销售数量=isnull(a.特价销售数量,0)+isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)+isnull(b.特价销售金额,0),
		  a.正价销售数量=isnull(a.正价销售数量,0)+isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)+isnull(b.正价销售金额,0)
    from #temp_WhFormend0_1 a,#temp_GoodsLog_Month_1 b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    
    
      
select a.cgoodsno,a.cSupplierNo,a.cWHno,
				  销售数量_1=a.销售数量0, 销售金额_1=a.销售金额0, 
				  特价销售数量_1=a.特价销售数量, 特价销售金额_1=a.特价销售金额, 
				  正价销售数量_1=a.正价销售数量, 正价销售金额_1=a.正价销售金额,
				  Pos客退数量_1=a.Pos客退数量1, Pos客退金额_1=a.Pos客退金额1,
				  入库数量_1=a.入库数量1, 入库金额_1=a.入库金额1, 报溢数量_1=a.报溢数量1, 报溢金额_1=a.报溢金额1, 
				  退货入库数量_1=a.退货入库数量1, 退货入库金额_1=a.退货入库金额1, 
				  调拨入库数量_1=a.调拨入库数量1, 调拨入库金额_1=a.调拨入库金额1,  
				  出库数量_1=a.出库数量0, 出库金额_1=a.出库金额0, 
				  报损数量_1=a.报损数量0, 报损金额_1=a.报损金额0, 
				  返厂数量_1=a.返厂数量0, 返厂金额_1=a.返厂金额0, 
				  调拨出库数量_1=a.调拨出库数量0, 调拨出库金额_1=a.调拨出库金额0, 
				  差价数量_1=a.差价数量, 差价金额_1=a.差价金额, 
				  原料出库数量_1=a.原料出库数量0, 原料出库金额_1=a.原料出库金额0, 
				  成品入库数量_1=a.成品入库数量1, 成品入库金额_1=a.成品入库金额1,
				  fQty_Left_1=a.fQty_Left,fMoney_Left_1=a.fMoney_Left,
				  ------以上期末
				  ------期间
				  销售数量=a.销售数量0-b.销售数量0, 销售金额=a.销售金额0-b.销售金额0, 
				  特价销售数量=a.特价销售数量-b.特价销售数量, 特价销售金额=a.特价销售金额-b.特价销售金额, 
				  正价销售数量=a.正价销售数量-b.正价销售数量, 正价销售金额=a.正价销售金额-b.正价销售金额,
				  Pos客退数量=a.Pos客退数量1-b.Pos客退数量1, Pos客退金额=a.Pos客退金额1-b.Pos客退金额1,
				  入库数量=a.入库数量1-b.入库数量1, 入库金额=a.入库金额1-b.入库金额1, 
				  报溢数量=a.报溢数量1-b.报溢数量1, 报溢金额=a.报溢金额1-b.报溢金额1, 
				  退货入库数量=a.退货入库数量1-b.退货入库数量1, 退货入库金额=a.退货入库金额1-b.退货入库金额1, 
				  调拨入库数量=a.调拨入库数量1-b.调拨入库数量1, 调拨入库金额=a.调拨入库金额1-b.调拨入库金额1,  
				  出库数量=a.出库数量0-b.出库数量0, 出库金额=a.出库金额0-b.出库金额0, 
				  报损数量=a.报损数量0-b.报损数量0, 报损金额=a.报损金额0-b.报损金额0, 
				  返厂数量=a.返厂数量0-b.返厂数量0, 返厂金额=a.返厂金额0-b.返厂金额0, 
				  调拨出库数量=a.调拨出库数量0-b.调拨出库数量0, 调拨出库金额=a.调拨出库金额0-b.调拨出库金额0, 
				  差价数量=a.差价数量-b.差价数量, 差价金额=a.差价金额-b.差价金额, 
				  原料出库数量=a.原料出库数量0-b.原料出库数量0, 原料出库金额=a.原料出库金额0-b.原料出库金额0, 
				  成品入库数量=a.成品入库数量1-b.成品入库数量1, 成品入库金额=a.成品入库金额1-b.成品入库金额1,
				  fQty_Left=a.fQty_Left-b.fQty_Left,fMoney_Left=a.fMoney_Left-b.fMoney_Left,
				 --  以下期初
				  销售数量_0=b.销售数量0, 销售金额_0=b.销售金额0, 
				  特价销售数量_0=b.特价销售数量, 特价销售金额_0=b.特价销售金额, 
				  正价销售数量_0=b.正价销售数量, 正价销售金额_0=b.正价销售金额,
				  Pos客退数量_0=b.Pos客退数量1, Pos客退金额_0=b.Pos客退金额1,
				  入库数量_0=b.入库数量1, 入库金额_0=b.入库金额1, 报溢数量_0=b.报溢数量1, 报溢金额_0=b.报溢金额1, 
				  退货入库数量_0=b.退货入库数量1, 退货入库金额_0=b.退货入库金额1, 
				  调拨入库数量_0=b.调拨入库数量1, 调拨入库金额_0=b.调拨入库金额1,  
				  出库数量_0=b.出库数量0, 出库金额_0=b.出库金额0, 
				  报损数量_0=b.报损数量0, 报损金额_0=b.报损金额0, 
				  返厂数量_0=b.返厂数量0, 返厂金额_0=b.返厂金额0, 
				  调拨出库数量_0=b.调拨出库数量0, 调拨出库金额_0=b.调拨出库金额0, 
				  差价数量_0=b.差价数量, 差价金额_0=b.差价金额, 
				  原料出库数量_0=b.原料出库数量0, 原料出库金额_0=b.原料出库金额0, 
				  成品入库数量_0=b.成品入库数量1, 成品入库金额_0=b.成品入库金额1,
				  fQty_Left_0=b.fQty_Left,fMoney_Left_0=b.fMoney_Left
into #temp_Result_1
from #temp_WhFormend0_1 a left join #temp_WhFormbgn0_1 b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo


 
 
select  a.cGoodsNo,'开始日期'=@dDate1,'结束日期'=@dDate2,a.cWhNo,
  '期初库存数量'=a.fQty_Left_0,
	'期间库存变化数量'=a.fQty_Left,
	'fQty_CurWH'=a.fQty_Left_1,

  '期初累计销售金额'=a.销售金额_0,
  '期初累计销售数量'=a.销售数量_0,
  '期初累计正价销售金额'=a.正价销售金额_0,
  '期初累计正价销售数量'=a.正价销售数量_0,
  '期初累计特价销售金额'=a.特价销售金额_0,
  '期初累计特价销售数量'=a.特价销售数量_0,

	'期间累计销售金额'=a.销售金额,
	'期间累计销售数量'=a.销售数量,
	'期间累计正价销售金额'=a.正价销售金额,
	'期间累计正价销售数量'=a.正价销售数量,
	'期间累计特价销售金额'=a.特价销售金额,
	'期间累计特价销售数量'=a.特价销售数量,

  '期末累计销售金额'=a.销售金额_1,
  '期末累计销售数量'=a.销售数量_1,
  '期末累计正价销售金额'=a.正价销售金额_1,
  '期末累计正价销售数量'=a.正价销售数量_1,
  '期末累计特价销售金额'=a.特价销售金额_1,
  '期末累计特价销售数量'=a.特价销售数量_1,

	'期初累计采购入库数量'=a.入库数量_0,
	'期初累计采购入库金额'=a.入库金额_0,
	'期间采购入库数量'=a.入库数量,
	'期间采购入库金额'=a.入库金额,
	'期末累计采购入库数量'=a.入库数量_1,
	'期末累计采购入库金额'=a.入库金额_1,

	'期初累计调拨入库数量'=a.调拨入库数量_0,
	'期初累计调拨入库金额'=a.调拨入库金额_0,
	'期间调拨入库数量'=a.调拨入库数量,
	'期间调拨入库金额'=a.调拨入库金额,
	'期末累计调拨入库数量'=a.调拨入库数量_1,
	'期末累计调拨入库金额'=a.调拨入库金额_1,

	'期初累计客退数量'=a.退货入库数量_0,
	'期初累计客退金额'=a.退货入库金额_0,
	'期间客退数量'=a.退货入库数量,
	'期间客退金额'=a.退货入库金额,
	'期末累计客退数量'=a.退货入库数量_1,
	'期末累计客退金额'=a.退货入库金额_1,

	'期初累计报溢数量'=a.报溢数量_0,
	'期初累计报溢金额'=a.报溢金额_0,
	'期间报溢数量'=a.报溢数量,
	'期间报溢金额'=a.报溢金额,
	'期末累计报溢数量'=a.报溢数量_1,
	'期末累计报溢金额'=a.报溢金额_1,

	'期初累计成品入库数量'=a.成品入库数量_0,
	'期初累计成品入库金额'=a.成品入库金额_0,
	'期间成品入库数量'=a.成品入库数量,
	'期间成品入库金额'=a.成品入库金额,
	'期末累计成品入库数量'=a.成品入库数量_1,
	'期末累计成品入库金额'=a.成品入库数量_1,

	'期初累计返厂数量'=a.返厂数量_0,
	'期初累计返厂金额'=a.返厂金额_0,
	'期间返厂数量'=a.返厂数量,
	'期间返厂金额'=a.返厂金额,
	'期末累计返厂数量'=a.返厂数量_1,
	'期末累计返厂金额'=a.返厂金额_1,

	'期初累计出库数量'=a.出库数量_0,
	'期初累计出库金额'=a.出库金额_0,
	'期间出库数量'=a.出库数量,
	'期间出库金额'=a.出库金额,
	'期末累计出库数量'=a.出库数量_1,
	'期末累计出库金额'=a.出库金额_1,

	'期初累计调拨出库数量'=a.调拨出库数量_0,
	'期初累计调拨出库金额'=a.调拨出库金额_0,
	'期间调拨出库数量'=a.调拨出库数量,
	'期间调拨出库金额'=a.调拨出库金额,
	'期末累计调拨出库数量'=a.调拨出库数量_1,
	'期末累计调拨出库金额'=a.调拨出库金额_1,

	'期初累计报损数量'=a.报损数量_0,
	'期初累计报损金额'=a.报损金额_0,
	'期间报损数量'=a.报损数量,
	'期间报损金额'=a.报损金额,
	'期末累计报损数量'=a.报损数量_1,
	'期末累计报损金额'=a.报损金额_1,

	'期初累计原料出库数量'=a.原料出库数量_0,
	'期初累计原料出库金额'=a.原料出库金额_0,
	'期间原料出库数量'=a.原料出库数量,
	'期间原料出库金额'=a.原料出库金额,
	'期末累计原料出库数量'=a.原料出库数量_1,
	'期末累计原料出库金额'=a.原料出库金额_1,
  b.cGoodsName,b.cUnit,b.cSpec,b.cSupNo,b.cSupName,b.cGoodsTypeno,b.cGoodsTypename,
	b.fCKPrice
  from #temp_Result_1 a,t_Goods b
  where a.cGoodsNO=b.cGoodsNo
   
end


end
GO
