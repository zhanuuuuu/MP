CREATE procedure p_PeriodVipScore
@cVipNo varchar(32),
@dDate1 datetime,
@dDate2 datetime
as
begin



 select cVipNo,fOperatorValue=SUM(fOperatorValue)
 into #temp_VipScoreDetail
 from
 (
  select cVipNo,fOperatorValue=-fOperatorValue
  from t_VipScoreDetail
  where dbo.getdaystr(cDate) between @dDate1 and @dDate2
  and (cVipNo=@cVipNo or @cVipNo='')
  union all
  select cVipno,fOperatorValue=fScore
  from t_VipAward
  where dbo.getdaystr(dAwardDate) between @dDate1 and @dDate2
  and (cVipNo=@cVipNo or @cVipNo='')
 ) a 
 group by a.cVipNo
  
  select a.cVipNo,fVipScore_cur=SUM(a.fVipScore_cur)
  into #temp_Vip_Salesheetdetail
  from
  (
		select distinct cSaleSheetno,fVipScore_cur,cVipNo
		from t_salesheetdetail
		where dSaleDate between @dDate1 and @dDate2
		and dbo.trim(ISNULL(cVipNo,''))<>''
    and (cVipNo=@cVipNo or @cVipNo='')
  ) a
  group by a.cVipNo
  
  insert into t_Award_Vip_Done
  (dDate2, cVipNo, dDate1, cAwardName, fCurValue, fCurValue_Pos, fCurValue_MP, 
  fVipScore_Period_Pos, fVipScore_Period_Mp, 
  fVipScore_Period_Pos_Sub, fVipScore_Period_Mp_Sub
  )  
  select dDate2=@dDate2,a.cVipNo,dDate1=@dDate1,cAwardName=null,c.fCurValue,c.fCurValue_Pos,c.fCurValue_MP,
  
  fVipScore_Period_Pos=ISNULL(a.fVipScore_cur,0)-ISNULL(b.fOperatorValue,0),
  fVipScore_Period_Mp=null,
  fVipScore_Period_Pos_Sub=null,fVipScore_Period_Mp_Sub=null
  --into #temp_Result_vip
  from #temp_Vip_Salesheetdetail a left join #temp_VipScoreDetail b on a.cVipNo=b.cVipNo
  left join t_vip c on a.cVipNo=c.cVipno
  where c.fCurValue is not null
  
  update a set a.dDate_MinCust=b.dDate_MinCust,a.dDate_MaxCust=b.dDate_MaxCust
  from t_Award_Vip_Done a,
  (  
		select cVipno,dDate_MinCust=min(dSaledate),dDate_MaxCust=max(dSaledate)
		from t_SaleSheetDetail
		where dSaleDate between @dDate1 and @dDate2
		and cVipno is not null 
		group by  cVipno  
  ) b
  where a.cVipNo=b.cVipNo
  
  if (select OBJECT_ID('tempdb..#temp_VipScoreDetail'))is not null drop table #temp_VipScoreDetail
  if (select OBJECT_ID('tempdb..#temp_Vip_Salesheetdetail'))is not null drop table #temp_Vip_Salesheetdetail


end
GO
