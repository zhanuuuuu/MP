
CREATE       procedure [dbo].[p_SumSupplierFee_list]
@supNo varchar(64),
@date1 datetime,
@date2 datetime
as
begin
	/*计算商户的POP、电费、导购员提成、扣税等费用*/
	select feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno,bJiesuan=cast(0 as bit)
	from dbo.t_Supplier_fee
	where isnull(jiesuanover,0)=0 and cSupplierNo=@supNo 
				and riqi2 <= @date2
	union all
	select feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno,bJiesuan=cast(1 as bit)
	from t_Supplier_fee_Waiting_InMoney
	where cSupplierNo=@supNo
				
				
	
end

GO
