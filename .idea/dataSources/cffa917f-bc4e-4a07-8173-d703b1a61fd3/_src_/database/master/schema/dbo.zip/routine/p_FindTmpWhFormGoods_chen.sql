
CREATE proc p_FindTmpWhFormGoods_chen
@GoodsTable varchar(32)
as
exec('
  select dDate,cGoodsNo,cIp 
  from t_TmpWhForm 
  where dbo.getDayStr(dDate)=dbo.getDayStr(getdate())
  and cGoodsNo in( 
                     select distinct cGoodsNo from '+@GoodsTable+
                 ')' 
)

/*
create table #tmp
(cgoodsNo varchar(32))
insert into #tmp(cgoodsno)values ('10101')

p_FindTmpWhFormGoods_chen '#tmp'

*/

GO
