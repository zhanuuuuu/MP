

CREATE view v_Spxx_Qu
as
--select spno,Mingcheng,guizuno,guizu,quno,qu,fRatio,jingyingfangshi,cGoodsTypeno,cGoodsTypename
  select spno=a.cGoodsNo,Mingcheng=c.cGoodsName,c.cGoodsTypeno,c.cGoodsTypename,c.cBarcode,c.cUnit,c.cSpec,
	a.cSupNo,b.cSupName 
	from
	(
				select g.cGoodsNo,g.cSupNo
			 	from
				(
					select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
					a.cSpec,a.fVipScore,a.fNormalPrice,a.fVipPrice,
					a.cSupNo,a.cSupName,a.fInMoney,cGoodsNo_eStop=b.cGoodsNo   
					from 			
					(		select f.* 
							from
							(
							
							select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
							a.cSpec,a.cProductUnit,a.fVipScore,a.fNormalPrice,a.fVipPrice,
							b.cSupNo,b.cSupName,b.fInMoney 
							from  t_Goods a , t_Supplier_goods b where a.cGoodsNo=b.cGoodsNo
							
							union 
							
							select e.cGoodsNo,e.cGoodsName,e.cBarcode,e.cUnit,
							e.cSpec,e.cProductUnit,e.fVipScore,e.fNormalPrice,e.fVipPrice,
							e.cSupNo,e.cSupName,e.fInMoney 
							from  
							(select distinct c.cGoodsNo,c.cGoodsName,
											c.cBarcode,c.fInPrice as fInMoney,c.cUnit,c.cSpec,c.cProductUnit,c.fVipScore,c.fNormalPrice,c.fVipPrice,
											wh_InWarehouse.cSupplierNo as cSupNo,wh_InWarehouse.cSupplier as cSupName,c.cHelpCode
								from 
										(select distinct wh_InWarehouseDetail.cSheetno,wh_InWarehouseDetail.cGoodsNo,wh_InWarehouseDetail.cGoodsName,
											wh_InWarehouseDetail.cBarcode,wh_InWarehouseDetail.fInPrice,
											t_Goods.cHelpCode,t_Goods.cUnit,t_Goods.cSpec,t_Goods.cProductUnit,
											t_Goods.fVipScore,t_Goods.fNormalPrice,t_Goods.fVipPrice
											from wh_InWarehouseDetail ,t_Goods  where wh_InWarehouseDetail.cGoodsNo=t_Goods.cGoodsNo
										) c, wh_InWarehouse where c.cSheetno=wh_InWarehouse.cSheetno
							) e 
							) f
							where f.cGoodsno is not null
			   ) a left join  t_Supplier_goods_eStop b on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
				) g
				where g.cGoodsNo_eStop is null
				group by g.cGoodsNo,g.cSupNo
	)  a
	, dbo.t_Supplier b 
	, dbo.t_Goods c 
	where a.cSupNo=b.cSupNo and a.cGoodsNo=c.cGoodsNo


GO
