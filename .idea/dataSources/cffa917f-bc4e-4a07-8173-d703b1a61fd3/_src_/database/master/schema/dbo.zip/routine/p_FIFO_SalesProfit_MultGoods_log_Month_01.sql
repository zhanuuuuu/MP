 
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsNo,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='11576' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
		 drop table #temp_Goods
		Create Table #temp_Goods (
		cGoodsNo varchar(128),
		cProductNo varchar(128),
		cSupplierNo varchar(128))
 
		if  (select object_id('tempdb..#tempSupNo')) is not null
		 drop table #tempSupNo
		select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier
	-- where cSupplierNo='1001'
    insert into #temp_Goods(cGoodsNo,cSupplierNo)
    select distinct a.cGoodsNo,b.cSupplierNo   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where b.cSupplierNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsNo,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_goods where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    
   --- select * from #temp_Goods where cGoodsno='11800'
    ---12217
    
 delete #temp_Goods where cGoodsno<>'29947'

exec p_FIFO_SalesProfit_MultGoods_log_fenpei '2013-8-27','2013-12-25','02'
 
*/
CREATE procedure [dbo].[p_FIFO_SalesProfit_MultGoods_log_Month_01]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cdbname varchar(32)
as  --查询某时段 商品销售利润（含顾客退货）
 declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money)
  
 /*快照表中的最大日期。。。*/

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end

	-----查最大日结时间内信息@dDateBegin到@dDateEnd
  if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
 select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 
 
 	CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
	CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
	CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
	declare @strDateBgn varchar(32)
	declare @strDateEnd varchar(32)
    declare @strBgn varchar(32)
    set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
    set @strDateEnd=dbo.getdaystr(@maxWhdDate)
    set @strBgn=dbo.getdaystr(@dDateBgn)
	--set @SQLstr= '
	exec('
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
				select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
				 b.特价销售数量, b.特价销售金额, 
				 b.正价销售数量, b.正价销售金额,
				 b.Pos客退数量1, b.Pos客退金额1,
				 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				 b.退货入库数量1, b.退货入库金额1, 
				 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				 b.调拨出库数量0, b.调拨出库金额0, 
				 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				 b.成品入库数量1, b.成品入库金额1, 
				 b.本日库存数量, b.盘点数量,
				 b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fml=b.销售金额0-b.fPrice_In*b.销售数量0 
					into #temp_Wh_Goods_begin
					---from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+'''  and a.cGoodsNo=b.cGoodsNo 
				  ---and a.cSupplierNo=b.cSupplierNo 
				  and b.cWHno='+@cWHno+' 			 
				  union all             
				 select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
				 b.特价销售数量, b.特价销售金额, 
				 b.正价销售数量, b.正价销售金额,
				 b.Pos客退数量1, b.Pos客退金额1,
				 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				 b.退货入库数量1, b.退货入库金额1, 
				 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				 b.调拨出库数量0, b.调拨出库金额0, 
				 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				 b.成品入库数量1, b.成品入库金额1, 
				 b.本日库存数量, b.盘点数量,
				 b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fml=b.销售金额0-b.fPrice_In*b.销售数量0 
				   --	from #temp_WhFrombegin a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
				   from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where b.业务日期='''+@strDateBgn+'''  and  a.cGoodsNo=b.cGoodsNo 
				  ---and a.cSupplierNo=b.cSupplierNo 
				  and b.cWHno='+@cWHno+' and  b.iAttribute<>20				  
				  
			--  select * from #temp_Wh_Goods_begin
					
		           if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
			         select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
					Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
					  本日库存数量=SUM(isnull(本日库存数量,0)), 
					   盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_In),
					   fmoney_cost=sum(fmoney_cost),
					   fml=SUM(fml)
					   into #temp_SumWh_Goods_begin
						from #temp_Wh_Goods_begin
		              group by cgoodsno,cSupplierNo,cWHno		
	              
				  --update a 
				  --set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
				  --a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
				  --a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,
				  --a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
				  --a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
				  --a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
				  --a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
				  --a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
				  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
				  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
				  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
				  --a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
				  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 
				  --a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1, 
				  -- a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
				  -- a.期初库存=b.本日库存数量,
				  --  a.fPrice_Avg=b.fPrice_Avg,
					 --  a.fmoney_cost=b.fmoney_cost,
					 --  a.fml=b.fml
				  --from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
				  --where a.cGoodsNo=b.cGoodsNo 
				  --and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'
				  
				  insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
				  Pos客退数量1,Pos客退金额1,入库数量1,入库金额1,报溢数量1,报溢金额1,退货入库数量1,退货入库金额1,调拨入库数量1,调拨入库金额1,
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  成品入库数量1,成品入库金额1,本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fml)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
				  Pos客退数量1,Pos客退金额1,入库数量1,入库金额1,报溢数量1,报溢金额1,退货入库数量1,退货入库金额1,调拨入库数量1,调拨入库金额1,
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  成品入库数量1,成品入库金额1,本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml
				  from #temp_SumWh_Goods_begin
				  
				 ' )
	--set @SQLstr1='
--	print dbo.getTimeStr(GETDATE())
--print 3 
	exec('
				 if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
				select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
				 b.特价销售数量, b.特价销售金额, 
				 b.正价销售数量, b.正价销售金额,
				 b.Pos客退数量1, b.Pos客退金额1,
				 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				 b.退货入库数量1, b.退货入库金额1, 
				 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				 b.调拨出库数量0, b.调拨出库金额0, 
				 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				 b.成品入库数量1, b.成品入库金额1, 
				 b.本日库存数量, b.盘点数量,
				 b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fml=b.销售金额0-b.fPrice_In*b.销售数量0 
				   	into #temp_Wh_Goods_end
					---from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
					 with (nolock) 
				  where b.业务日期='''+@strDateEnd+'''  and  a.cGoodsNo=b.cGoodsNo 
				  ---and a.cSupplierNo=b.cSupplierNo 
				  and b.cWHno='+@cWHno+' 
				  union all             
				  select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
				 b.特价销售数量, b.特价销售金额, 
				 b.正价销售数量, b.正价销售金额,
				 b.Pos客退数量1, b.Pos客退金额1,
				 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
				 b.退货入库数量1, b.退货入库金额1, 
				 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
				 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
				 b.调拨出库数量0, b.调拨出库金额0, 
				 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
				 b.成品入库数量1, b.成品入库金额1, 
				 b.本日库存数量, b.盘点数量,
				 b.fPrice_In,
				   fmoney_cost=b.fPrice_In*b.销售数量0,
				   fml=b.销售金额0-b.fPrice_In*b.销售数量0 
				-- from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
				from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
					 with (nolock) 
				  where  b.业务日期 between '''+@strDateBgn+'''  and '''+@strDateEnd+'''  and a.cGoodsNo=b.cGoodsNo 
				---  and a.cSupplierNo=b.cSupplierNo 
				  and b.cWHno='+@cWHno+' and  b.iAttribute<>20
		
				 --- select * from #temp_Wh_Goods_end
				       
	             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			         select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
					  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
					  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
					Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
					  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
					  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
					  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
					  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
					  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
					  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
					   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
					   fPrice_Avg=AVG(fPrice_In),
					   fmoney_cost=sum(fmoney_cost),
					   fml=SUM(fml)
					   into #temp_SumWh_Goods_end
						from #temp_Wh_Goods_end
		              group by cgoodsno,cSupplierNo,cWHno	
		              
                ---  select * from #temp_SumWh_Goods_end
	             
				  --update a
				  --set a.销售数量0=b.销售数量0, a.销售金额0=b.销售金额0, 
				  --a.特价销售数量=b.特价销售数量, a.特价销售金额=b.特价销售金额, 
				  --a.正价销售数量=b.正价销售数量, a.正价销售金额=b.正价销售金额,				
				  --a.出库数量0=b.出库数量0, a.出库金额0=b.出库金额0, 
				  --a.报损数量0=b.报损数量0, a.报损金额0=b.报损金额0, 
				  --a.返厂数量0=b.返厂数量0, a.返厂金额0=b.返厂金额0, 
				  --a.调拨出库数量0=b.调拨出库数量0, a.调拨出库金额0=b.调拨出库金额0, 
				  --a.差价数量=b.差价数量, a.差价金额=b.差价金额, 
				  --a.原料出库数量0=b.原料出库数量0, a.原料出库金额0=b.原料出库金额0, 				   
				  -- a.本日库存数量=b.本日库存数量, a.盘点数量=b.盘点数量,
				  -- a.期末库存=b.本日库存数量,
				  --  a.fPrice_Avg=b.fPrice_Avg,
					 --  a.fmoney_cost=b.fmoney_cost,
					 --  a.fml=b.fml
				  --from #temp_WhFromend a ,#temp_SumWh_Goods_end b
				  --where a.cGoodsNo=b.cGoodsNo 
				  --and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'
				  
				  insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fml)
				  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
				  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
				  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml
				  from #temp_SumWh_Goods_end
	 
				  -----------------获取时间段的入库数量--------------------
	                           
				  
				  	  if (select OBJECT_ID(''tempdb..#temp_IN_Goods_end''))is not null  drop table #temp_IN_Goods_end
	             select  cgoodsno,cSupplierNo,cWHno, Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
					入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
					报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
					退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
					  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  					  
					  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0))
					  into #temp_IN_Goods_end
	             from #temp_Wh_Goods_end
	             where dDatetime between '''+@strBgn+''' and '''+@strDateEnd+'''
	             group by  cgoodsno,cSupplierNo,cWHno
	                           
	            update a
	            set a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
				  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
				  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
				  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
				  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
				  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
	            from #temp_WhFromend a ,#temp_IN_Goods_end b
				  where a.cGoodsNo=b.cGoodsNo 				
				  and a.cSupplierNo=b.cSupplierNo and b.cWHno='+@cWHno+'                   
				')
---exec (@SQLstr+@SQLstr1)
insert into   #temp_WhFromend(cgoodsno,cWhno,cSupplierno)
select a.cgoodsno,a.cWhno,a.cSupplierno from #temp_WhFrombegin a left join #temp_WhFromend b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
where isnull(b.cGoodsNo,'')='' 
--	print dbo.getTimeStr(GETDATE())
--print 4


	-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
		 --- 结束日期数据-（开始日期-1）数据 得出时间段数据    
		 update a 
		 set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		 a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
				  a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
				  a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
				  a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
				  a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),				
				  a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
				  a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
				  a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
				  a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),				  
				  a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
				  a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
				  a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
				  a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
				  a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
				  a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
				  a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
				  a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),
				  a.期初库存=isnull(b.期初库存,0), 
				  a.期末库存=isnull(a.期末库存,0), 
				  a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
			      a.fPrice_Avg=a.fPrice_Avg,
				  a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
				  a.fml=isnull(a.fml,0)-isnull(b.fml,0)
		from #temp_WhFromend a,#temp_WhFrombegin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

		------------获取联营供应商的扣点	
 if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
CREATE TABLE #temp_WhKouDian ([cGoodsNo] [varchar](32) NOT NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,fPrice_Avg money,fmoney_koudian money,fMoney_cost money)
	--print dbo.getTimeStr(GETDATE())
	--print 5
 
exec('
          if (select OBJECT_ID(''tempdb..#temp_WhForm0_Goods_end''))is not null  drop table #temp_WhForm0_Goods_end
         select a.cgoodsno,b.cSupplierNo,b.cSupplier,销售数量0=isnull(b.当日正价销售数量,0)+isnull(b.当日特价销售数量,0), 
          销售金额0=isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0), 
		  特价销售数量=b.当日特价销售数量, 特价销售金额=b.当日特价销售金额, 
		  正价销售数量=b.当日正价销售数量, 正价销售金额=b.当日正价销售金额,
		  koudian=b.扣率金额,fMoney_cost=(isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0)-isnull(b.扣率金额,0))	
		  into #temp_WhForm0_Goods_end				 
		  --from #temp_WhFromend a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
		  from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where  b.业务日期 between '''+@strBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo  
		  and b.cWHno='+@cWHno+' and  b.iAttribute=20
		  
          insert into #temp_WhKouDian
          ([cGoodsNo],cSupplierNo,cSupplier,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fmoney_koudian,fMoney_cost)          
          select cgoodsno,cSupplierNo,cSupplier,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		  特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 正价销售数量=SUM(正价销售数量), 
		  正价销售金额=SUM(正价销售金额),koudian=sum(koudian),fMoney_cost=SUM(isnull(fMoney_cost,0))					 
		  from #temp_WhForm0_Goods_end	
		  group by cgoodsno,cSupplierNo,cSupplier
')	
--select sum(销售金额0),sum(fml),sum(fmoney_Cost) from #temp_WhFromend
--select sum(销售金额0),sum(fml),sum(fmoney_Cost) from #temp_WhFrombegin
--select sum(销售金额0),sum(fmoney_koudian),sum(fmoney_Cost) from #temp_WhKouDian 

	 --select * from #temp_WhFromend
	-------处理管理库存那些成本为空的
--	print dbo.getTimeStr(GETDATE())
--print 6
	/*注意一品多商的情况*/
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,--销售数量
   fLastSettle money,--卖价
   fMoneyCost money,--进价
   fMoneyRatio money,--毛利
   fRatio money, --毛利率
   bAuditing int,
   fAvg_price money
)

insert into #GetGoodsListFormBase
(	cGoodsNo,bAuditing )
select distinct cGoodsNo,0 from #tmp_WhGoodsList
union all
select  distinct  cGoodsNo,1 from #tmp_WhGoodsList

	--- 取记账之前的数据... 
 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
        create table #temp_ReadyKucun(
		cGoodsNo varchar(32),cUnitedNo varchar(32), csupno varchar(32),csuplierno varchar(32), 
		cGoodsName varchar(64),cBarcode varchar(32),cUnit varchar(32),cSpec varchar(32),
		fNormalPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),bProducted bit ,cProductNo  varchar(32),
		fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
		fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money
)
  
if 	@maxWhdDate<@dDateEnd
begin
	 --select '2',@dDate_1,@dDate_2
	  --exec p_FIFO_SalesProfit_GoodsType_log_wei @dDate_1,@dDate_2,@cWHno
	  
	  if (select OBJECT_ID('tempdb..#temp_goodsForSelect'))is not null drop table #temp_goodsForSelect
      if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_p'))is not null drop table #GetGoodsListFormBase_p
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_R'))is not null drop table #GetGoodsListFormBase_R
      select distinct cGoodsNo  into #temp_goodsForSelect from #tmpCostGoodsList
      
      
	  select dSaleTime=b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing
      into #t_SaleSheetDetail_shelf
      from #temp_goodsForSelect a, t_SaleSheetDetail b
      where (b.dSaleDate between @dDate_1 and @dDate_2) and a.cGoodsNo=b.cGoodsNo and b.cWHno=@cWHno 
      union all
      select c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0'
      from #temp_goodsForSelect a,WH_ReturnGoodsDetail b,WH_ReturnGoods c
      where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dDate_1 and @dDate_2)
            and c.cWHno=@cWHno
            
          
            
      /*---包装转单品*/
			if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
			select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
			into #tmpPackGoodsList
			from t_goods
			where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

			update a
			set a.cGoodsNo=b.cGoodsNo_MinPackage,
					a.fQuantity=a.fQuantity*b.fQty_minPackage
			from #t_SaleSheetDetail_shelf a, #tmpPackGoodsList b
			where a.cGoodsNO=b.cGoodsNO
---销售数量

      select dSaleTime=@dDate1,a.cGoodsNo,a.bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
             fMoneyCost=cast(0 as money),fMoneyRatio=cast(0 as money),fRatio=cast(0 as money),
             cSupno=CAST(null as varchar(32))
      into #GetGoodsListFormBase_p 
      from (
						select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0))
						from #t_SaleSheetDetail_shelf 
						where dSaleTime between @dDate_1 and @dDate_2
						group by cGoodsNo,bAuditing
           ) a
      group by a.cGoodsNo,a.bAuditing
      
     
      
      update a set a.cSupno=b.cSupNo
      from #GetGoodsListFormBase_p a,t_goods b
      where a.cGoodsNo=b.cGoodsNo
--获取供应商最小扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select a.guizuno,a.fRatio
			from t_Supplier_Contract_Ratio a,
			(
				 select guizuno,fMoney1=MIN(fMoney1)
				 from t_Supplier_Contract_Ratio 
				 where isnull(fRatio,0)<>0
				 group by guizuno
			 )b
			where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
	  ) b
	  where a.cSupno=b.guizuno
			
--获取t_goods表扣率
	  update a  
	  set a.fRatio=b.fRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,fRatio
			from t_goods 
			where isnull(fRatio,0)<>0
	  ) b
	  where a.cGoodsNo=b.cGoodsNo
			
--策略扣率
      update a  
	  set a.fRatio=b.fSupRatio
	  from #GetGoodsListFormBase_p a,
	  (
			select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
			from t_PloyOfSale
			where (
								(dDateStart between @dDate_1 and @dDate_2)
								or 
								(dDateEnd  between @dDate_1 and @dDate_2)
						)and isnull(fSupRatio,0)<>0
			group by cGoodsNo,dDateStart,dDateEnd
	  ) b
      where a.cGoodsNo=b.cGoodsNo and a.dSaleTime between b.dDateStart and b.dDateEnd 
      and isnull(a.bAuditing,0)=1
	
	 
	  select cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
		   fMoneyCost=sum(isnull(fMoneyCost,0)),
		   fMoneyRatio=sum(isnull(fMoneyRatio,0)),fRatio=avg(isnull(fRatio,0))
	  into #GetGoodsListFormBase_R
	  from #GetGoodsListFormBase_p 
	  group by cGoodsNo,bAuditing
	  
	  
	  
	  drop table #GetGoodsListFormBase_p
--销售成本 
/*
	  select cGoodsNo,fPrice_Avg from #temp_end
*/			
      ---平均价
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg0'))is not null drop table #temp_fPrice_Avg0
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg'))is not null drop table #temp_fPrice_Avg
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(c.fCKPrice,0)=0 
      --then c.fNormalPrice
      then c.fPrice_Contract  
      else c.fCKPrice end
      into #temp_fPrice_Avg0
      from #GetGoodsListFormBase a left join t_goods c
      on a.cGoodsNo=c.cGoodsNo
      
  
 -------------------     修改：从入库单中取赠品的进价修改。。。 
     if (select OBJECT_ID('tempdb..#temp_fPrice_InWhouse'))is not null drop table #temp_fPrice_InWhouse

      select a.* into #temp_fPrice_InWhouse
      from (
			  select b.dDate,a.cGoodsNo,a.fInPrice from
		wh_InWarehouseDetail a,wh_InWarehouse b where a.cSheetno=b.cSheetno
		-- and b.dDate between @dDate1 and @dDate2
		 --and  fInPrice=0
      ) a right join #GetGoodsListFormBase b on  a.cGoodsNo=b.cGoodsNo
   --   where a.cGoodsNo=b.cGoodsNo
      order by a.dDate
      
           
      ------获取最新进价为0 的。。。 
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg01'))is not null drop table #temp_fPrice_Avg01
      select a.cGoodsNo,fPrice_Avg=ISNULL(c.fCKPrice,0)
      into #temp_fPrice_Avg01
      from #GetGoodsListFormBase a left join t_goods c
      on a.cGoodsNo=c.cGoodsNo where c.fCKPrice=0
      
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg02'))is not null drop table #temp_fPrice_Avg02

      select a.cGoodsNo,fPrice_Avg=isnull(b.fInPrice,0) 
      into #temp_fPrice_Avg02
      from #temp_fPrice_Avg01 a right join #temp_fPrice_InWhouse b
      on a.cGoodsNo=b.cGoodsNo 
      
    
      
      update a set a.fPrice_Avg=b.fPrice_Avg from
      #temp_fPrice_Avg0 a,#temp_fPrice_Avg02 b
      where a.cGoodsNo=b.cGoodsNo 
      
 ---------------  

 /*
      select a.cGoodsNo,fPrice_Avg=case when ISNULL(b.fPrice_Avg,0)=0 then a.fPrice_Avg else b.fPrice_Avg end
      into #temp_fPrice_Avg
      from #temp_fPrice_Avg0 a left join #temp_WhFromend b
      on a.cGoodsNo=b.cGoodsNo 
      */
      
            select a.cGoodsNo,fPrice_Avg=
            case when ISNULL(a.fPrice_Avg,0)=0 then 
				case when ISNULL(b.fCKPrice,0)=0 then
				b.fNormalPrice else b.fCKPrice end
             else a.fPrice_Avg end
      into #temp_fPrice_Avg
      from #temp_fPrice_Avg0 a left join t_Goods b
      on a.cGoodsNo=b.cGoodsNo 
      
      --select * from #temp_fPrice_Avg where fPrice_Avg is null
      
      --select SUM(fPrice_Avg) from #temp_WhFromend      
      --select SUM(fPrice_Avg) from #temp_fPrice_Avg0
 
	  update a
	  set a.fMoneyCost=isnull(a.fQuantity,0)*b.fPrice_Avg	  
	  from #GetGoodsListFormBase_R a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	----  select * from #GetGoodsListFormBase_R	 
	
	--select fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
	--fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio) from #GetGoodsListFormBase_R
	
	  
	  ------扣点
	  update a ---不管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00),
	      a.fMoneyCost=isnull(a.fLastSettle,0)*(1-a.fRatio/100.00)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0
	  
	  update a ---管库存
	  set a.fMoneyRatio=isnull(a.fLastSettle,0)*(a.fRatio/100.00)+isnull(a.fLastSettle,0)-isnull(a.fMoneyCost,0)
	  from #GetGoodsListFormBase_R a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
	  --更新到基础表#GetGoodsListFormBase中

	  
	  update a
	  set a.fAvg_price=b.fPrice_Avg	  
	  from #GetGoodsListFormBase a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	  update a
	  set a.fQuantity=isnull(b.fQuantity,0),a.fLastSettle=isnull(b.fLastSettle,0),
		a.fMoneyCost=isnull(b.fMoneyCost,0),
		a.fMoneyRatio=isnull(b.fMoneyRatio,0),a.fRatio=isnull(b.fRatio,0)
	  from #GetGoodsListFormBase a,#GetGoodsListFormBase_R b
	  where a.cGoodsNo=b.cGoodsNo and a.bAuditing=isnull(b.bAuditing,0)
	  
      
	  
	  drop table #GetGoodsListFormBase_R

	  update a
	  set a.cSupNO=case when isnull(a.cSupNO,'')='' then b.cSupNo else a.cSupNO end,
	      a.cGoodsTypeNo=b.cGoodsTypeno,a.cGoodsTypeName=b.cGoodsTypename
	  from #GetGoodsListFormBase a,t_goods b
	  where a.cGoodsNo=b.cGoodsNo
	  
	  
	insert into #temp_ReadyKucun(cGoodsNo,xsQty,xsMoney,fMoney_Cost,fML,csupno,csuplierno,fCostPrice)
	select cGoodsNo,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
	fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio),cSupNO,'',fAvg_price from #GetGoodsListFormBase
	group by cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,cSupNO,fAvg_price
	
end




    if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
      select cGoodsNo,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,fml,cSupplierNo,cSupplier,fPrice_Avg
      into #temp_goodsKuCunml
      from #temp_WhFromend  --where  isnull(fml,0)<>0
      union all
      select  cGoodsNo,销售数量0, 销售金额0,fMoney_Cost,fmoney_koudian,cSupplierNo,cSupplier,fPrice_Avg
      from #temp_WhKouDian --where 销售数量0<>0
      union all
      select cGoodsNo,xsQty,xsMoney,fMoney_Cost,fML,csupno,csuplierno,fCostPrice
      from #temp_ReadyKucun --where xsQty<>0
 
 
	 --update a set a.cSupplier=b.cSupName,a.cSupplierNo=b.csupno
     -- from #temp_goodsKuCunml a,t_goods b
	 --where a.cGoodsNo=b.cGoodsNo
	 
	
      if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
      select cGoodsNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
       cSupplierNo,cSupplier,fPrice_Avg=AVG(fPrice_Avg)
      into #temp_SumgoodsKuCunml
      from #temp_goodsKuCunml
      group by cGoodsNo,cSupplierNo,cSupplier
      
      	CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)
 
      
      if (select OBJECT_ID('tempdb..#temp_goodsKuCun1'))is not null  drop table #temp_goodsKuCun1
      select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
      b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo=b.cSupNo,b.cSupName,
      BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
	  fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost 
        into  #temp_goodsKuCun1
	  from #temp_SumgoodsKuCunml a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo  
	  order by a.cGoodsNo
	  
 
	  
	  if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
      select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
      cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
      BeginDate,EndDate, xsQty=SUM(xsQty), xsMoney=SUM(xsMoney), 	 
	  fCostPrice=avg(fCostPrice),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost),i=0
      into  #temp_goodsKuCun
	  from #temp_goodsKuCun1
	  group by cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
      cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
      BeginDate,EndDate 
	  order by cGoodsNo
	  

--	 print dbo.getTimeStr(GETDATE())
--   print 7
---------获取时间段内的差价表。。---------
	  	if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
		drop table #tmp_WhGoodsList_begin_1
		select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 
		
		CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)
		--------表示当前分配的差价单的供应商在当前的列表中存在
		if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
		drop table #temp_wh_DiffGoodsNo
		select b.cGoodsno,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo
		from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
		where dSaleDate between @dDate1 and @dDate2 
		and a.cGoodsno=b.cGoodsNo 
        group by b.cGoodsno
		
       CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)
 
	   update a
	   set 
	   a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
	   a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
	   from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo b
	   where a.cGoodsNo=b.cGoodsNo  
	 
	   
	   
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCun

--------获取期末前最新的毛利调整数
     if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
      drop table #tmpGoodsRelationKucun_1
		select a.cGoodsNo,fNewPrice=a.NewFckprice,dDateTime=max(dDateTime)--,a.cSupNo
		into #tmpGoodsRelationKucun_1
		from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
		where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno --and a.cSupNo=b.cSupplierNo
		group by a.cGoodsNo,a.NewFckprice--,a.cSupNo
			
	---------修改最近调整成本商品的毛利
	 update a 
	 set a.fMoney_Cost=ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
	 a.fML=isnull(a.xsMoney,0)-ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
	 a.fCostPrice=b.fNewPrice
	 from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
	 where a.cGoodsNo=b.cGoodsNo ---and a.cSupplierNo=b.cSupNo
 
/*------------------*/
    /*--------修改未主供应商防止出现多条数据----2015-05-05------*/
 update  a
 set a.cSupplierNo=b.csupno,a.cSupName=b.csupname
 --,a.cGoodsNo=ISNULL(b.cGoodsNo_minPackage,a.cGoodsNo),
 --a.xsQty=a.xsQty*(case when ISNULL(b.fQty_minPackage,0)=0 then 1 else b.fQty_minPackage end)
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno
 
 update  a
 set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*isnull(b.fQty_minPackage,1)
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''
 
 if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last0
 select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
 BeginDate,EndDate,cSupplierNo,b.cSupName,fMoney_Cost=sum(fMoney_Cost),
 fCostPrice=0,
 xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
 fML=sum(isnull(fML,0)),i
 into #temp_goodsKuCun_last0
  from #temp_goodsKuCun a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
 group by a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
 b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,BeginDate,EndDate,cSupplierNo,b.cSupName,i
 
if(select object_id('tempdb..##temp_GoodsTypeNo')) is not null 
 drop table ##temp_GoodsTypeNo
 select cGoodsNo,fML,fMoney_Cost,xsQty,xsMoney into ##temp_GoodsTypeNo from #temp_goodsKuCun_last0
	 
	   
if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin
     CREATE INDEX IX_temp_temp_goodsKuCun  ON #temp_goodsKuCun(cGoodsTypeno)
 
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,
         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(a.fMoney_Cost,0)<>0
         then case when isnull(a.xsQty,0)<>0 then isnull(a.fMoney_Cost,0)/isnull(a.xsQty,0) else isnull(a.fCostPrice,0) end
         else isnull(a.fCostPrice,0) end,
         fml=isnull(a.fML,0),a.i
      into    #temp_goodsKuCun_last
 -- from #temp_goodsKuCun a,#temp_GoodsTypeNo b
 from #temp_goodsKuCun_last0 a,#temp_GoodsTypeNo b
  where a.cGoodsTypeno=b.cGoodsTypeno


  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i
  from #temp_goodsKuCun_last 
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='合计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last  
  group by  cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last 
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsNo,i
  
end else
begin
   select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(fMoney_Cost,0)<>0
         then case when isnull(xsQty,0)<>0 then isnull(fMoney_Cost,0)/isnull(xsQty,0) else isnull(fCostPrice,0) end
         else isnull(fCostPrice,0) end,
         fML=ISNULL(fML,0),i
  --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno,cGoodsTypename,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
 -- from #temp_goodsKuCun  
   --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by cGoodsTypeno,cGoodsTypename,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo=null,cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
    --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsNo,i
end    
  

	/*获取时间段的入库记录 日期以单据日期为判断。*/

	 /*删除临时表*/
	if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
	if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  drop table #temp_wh_DiffPriceWarehouseDetail
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null   drop table #temp_wh_DiffPricecGoodsNo
GO
