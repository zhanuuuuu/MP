

CREATE    procedure [dbo].[P_Z_addScoreTo_t_vip_1]
 @cVipno varchar(16),
 @score money,
 @cOperatorno varchar(16)
as
begin
	declare @curValue money
  declare @cVipName varchar(16)
  declare @fCurValue money
  

	select @curValue=fCurValue,
         @cVipName=cVipName
	from t_Vip
	where cVipno=@cVipno

  select @cVipName=cVipName
  from t_Vip where cVipNo=@cVipNo
  set @fCurValue=isnull(@curValue,0)+isnull(@score,0)
  
  
  update t_Vip
  set  fCurValue=isnull(@curValue,0)+isnull(@score,0),
  fCurValue_Pos=isnull(@curValue,0)+isnull(@score,0)
  where cVipno=@cVipno
  insert t_VipScoreDetail(cOperatorno,cVipName,cVipNo,fCurValue,
                          fCurValue_Pos,fOperatorValue,fPrimalValue,cDate)
  values(
       @cOperatorno,@cVipName,@cVipno,@fCurValue,0,@score,@curValue,getdate() 
     )
end


GO
