/*
     if (select OBJECT_ID('tempdb..#temp_cGoods'))is not null drop table #temp_cGoods
      select a.cSheetno,a.cGoodsNo,a.fInPrice,a.fNoTaxPrice
     into #temp_cGoods
	    from t_MencGoodsPriceDetail a,t_MencGoodsPrice b
	    where a.cSheetno=b.cSheetno and b.cSheetno='MSP201308-000001'
	    
	      if (select OBJECT_ID('tempdb..#temp_NocGoods'))is not null drop table #temp_NocGoods
               
                      select b.cGoodsNo into #temp_NocGoods 
                      from pos001.dbo.t_Goods a right join #temp_cGoods b
                      on a.cGoodsNo=b.cGoodsNo where isnull(a.cGoodsNO,'')=''
     if (select OBJECT_ID('tempdb..#temp_cGoods'))is not null drop table #temp_cGoods
        select a.cGoodsNo
        into #temp_cGoods
	    from t_Goods a 
	    where isnull(a.bPosX,0)=1                   
                    
 exec p_Frompos001ToPosX_wei_Goods 'pos001'

*/ 
create proc p_Frompos001ToPosX_wei_Goods
@PosName varchar(32)--- 门店数据库名称
as
begin
 exec ('
  if (select OBJECT_ID(''tempdb..#temp_NocGoods''))is not null drop table #temp_NocGoods
               
                      select b.cGoodsNo into #temp_NocGoods 
                      from '+@PosName+'.dbo.t_Goods a right join #temp_cGoods b
                      on a.cGoodsNo=b.cGoodsNo where isnull(a.cGoodsNO,'''')=''''
                      
------------- 以上是门店没有的商品

    
  if (select OBJECT_ID(''tempdb..#temp_GoodsType''))is not null drop table #temp_GoodsType
  --- 类别   
   select b.[cGoodsTypeno],b.[cGoodsTypename],b.[cParentNo]
           ,b.[cDetail],b.[bWeight],b.[fValue_con],b.[fValue_Score]
           ,b.[Color_idNo],b.[cDeptNo],b.[cDept],b.[cPath] 
           into #temp_GoodsType from '+@PosName+'.dbo.t_GoodsType a right join 
   pos001.dbo.t_GoodsType b on a.cGoodsTypeno=b.cGoodsTypeno
   where isnull(a.cGoodsTypeno,'''')=''''
   
  
   insert into '+@PosName+'.dbo.t_GoodsType(
            [cGoodsTypeno],[cGoodsTypename],[cParentNo]
           ,[cDetail],[bWeight],[fValue_con],[fValue_Score]
           ,[Color_idNo],[cDeptNo],[cDept],[cPath])
   select  [cGoodsTypeno],[cGoodsTypename],[cParentNo]
           ,[cDetail],[bWeight],[fValue_con],[fValue_Score]
           ,[Color_idNo],[cDeptNo],[cDept],[cPath] from #temp_GoodsType
  --- 地区
   select b.* into #temp_Supplier_Regionalism from '+@PosName+'.dbo.t_Supplier_Regionalism a right join 
   pos001.dbo.t_Supplier_Regionalism b on a.cRegNo=b.cRegNo
   where isnull(a.cRegNo,'''')=''''         
    
    
    insert into   '+@PosName+'.dbo.t_Supplier_Regionalism(cRegNo,cRegName,cParentNo)     
    select cRegNo,cRegName,cParentNo from #temp_Supplier_Regionalism
  
	
  --------------获取
  if (select OBJECT_ID(''tempdb..#temp_NocSupNo''))is not null drop table #temp_NocSupNo
  select distinct cSupNo into #temp_NocSupNo from t_Goods a,#temp_NocGoods b
  where a.cGoodsNo=b.cGoodsNo
  
    if (select OBJECT_ID(''tempdb..#temp_cSupNo''))is not null drop table #temp_cSupNo
     select b.[cSupNo],b.[cSupName],b.[cSupAbbName] ,b.[cContractNo],b.[cTrade],b.[cAddress],b.[cPostCode]
           ,b.[cRegCode],b.[cBank],b.[cAccount],b.[dDevDate],b.[cLPerson],b.[cPhone],b.[cFax],b.[cEmail],b.[cSupPerson]
           ,b.[cBP] ,b.[cMobile],b.[cPPerson],b.[iDisRate],b.[iCreGrade],b.[iCreLine],b.[iCreDate],b.[cPayCond]
           ,b.[cSupIAddress],b.[cSupIType],b.[cSupHeadCode],b.[cSupDepart],b.[iAPMoney],b.[dLastDate],b.[iLastMoney]
           ,b.[dLRDate],b.[iLRMoney],b.[bEnd],b.[dEndDate],b.[iFrequency],b.[bSupTax],b.[cRegNo] ,b.[cPassword],
           b.[cHezuoFangshi],b.[cHelpCode],b.[SecDogNo],b.[bContractPrice],b.[bLastPrice],b.[bRatio_without_Rbd] 
           into #temp_cSupNo from dbo.#temp_NocSupNo a,pos001.dbo.t_Supplier b where a.cSupNo=b.cSupNo
 
  
  
   --- 供应商   
         INSERT INTO '+@PosName+'.dbo.[t_Supplier]
           ([cSupNo],[cSupName],[cSupAbbName] ,[cContractNo],[cTrade],[cAddress],[cPostCode]
           ,[cRegCode],[cBank],[cAccount],[dDevDate],[cLPerson],[cPhone],[cFax],[cEmail],[cSupPerson]
           ,[cBP] ,[cMobile],[cPPerson],[iDisRate],[iCreGrade],[iCreLine],[iCreDate],[cPayCond]
           ,[cSupIAddress],[cSupIType],[cSupHeadCode],[cSupDepart],[iAPMoney],[dLastDate],[iLastMoney]
           ,[dLRDate],[iLRMoney],[bEnd],[dEndDate],[iFrequency],[bSupTax],[cRegNo] ,[cPassword],
           [cHezuoFangshi],[cHelpCode],[SecDogNo],[bContractPrice],[bLastPrice],[bRatio_without_Rbd])
        select 
           b.[cSupNo],b.[cSupName],b.[cSupAbbName] ,b.[cContractNo],b.[cTrade],b.[cAddress],b.[cPostCode]
           ,b.[cRegCode],b.[cBank],b.[cAccount],b.[dDevDate],b.[cLPerson],b.[cPhone],b.[cFax],b.[cEmail],b.[cSupPerson]
           ,b.[cBP] ,b.[cMobile],b.[cPPerson],b.[iDisRate],b.[iCreGrade],b.[iCreLine],b.[iCreDate],b.[cPayCond]
           ,b.[cSupIAddress],b.[cSupIType],b.[cSupHeadCode],b.[cSupDepart],b.[iAPMoney],b.[dLastDate],b.[iLastMoney]
           ,b.[dLRDate],b.[iLRMoney],b.[bEnd],b.[dEndDate],b.[iFrequency],b.[bSupTax],b.[cRegNo] ,b.[cPassword],
           b.[cHezuoFangshi],b.[cHelpCode],b.[SecDogNo],b.[bContractPrice],b.[bLastPrice],b.[bRatio_without_Rbd]
            from  '+@PosName+'.dbo.t_supplier a right join #temp_cSupNo b on  a.csupno=b.cSupNo 
            where ISNULL(a.cSupno,'''')=''''           
                      
           --------------获取
  if (select OBJECT_ID(''tempdb..#temp_NocSupNoContract''))is not null drop table #temp_NocSupNoContract
  
  select a.cContractNo, b.cSupNo, a.cSupName, a.cSupAbbName, a.cTrade, a.cAddress, a.cPostCode, a.cRegCode, a.cBank, 
a.cAccount, a.dDevDate, a.cLPerson, a.cPhone, a.cFax, a.cEmail, a.cSupPerson, a.cBP, a.cMobile, a.cPPerson, a.iDisRate, 
a.iCreGrade, a.iCreLine, a.iCreDate, a.cPayCond, a.cSupIAddress, a.cSupIType, a.cSupHeadCode, a.cSupDepart, 
a.dEndDate, a.bSupTax, a.cZoneNo, a.cBalanceType, a.cBalanceTypeNo, a.cRegNo, a.cHezuoFangshi, a.cHelpCode, 
a.iDays  into #temp_NocSupNoContract
from t_Supplier_Contract a,#temp_cSupNo b
where a.cSupNo=b.cSupNo
        
        
         INSERT INTO '+@PosName+'.dbo.t_Supplier_Contract
         (cContractNo, cSupNo, cSupName, cSupAbbName, cTrade, cAddress, cPostCode, cRegCode, cBank, 
cAccount, dDevDate, cLPerson, cPhone, cFax, cEmail, cSupPerson, cBP, cMobile, cPPerson, iDisRate, 
iCreGrade, iCreLine, iCreDate, cPayCond, cSupIAddress, cSupIType, cSupHeadCode, cSupDepart, 
dEndDate, bSupTax, cZoneNo, cBalanceType, cBalanceTypeNo, cRegNo, cHezuoFangshi, cHelpCode, 
iDays)
        select b.cContractNo, b.cSupNo, b.cSupName, b.cSupAbbName, b.cTrade, b.cAddress, b.cPostCode, b.cRegCode, b.cBank, 
b.cAccount, b.dDevDate, b.cLPerson, b.cPhone, b.cFax, b.cEmail, b.cSupPerson, b.cBP, b.cMobile, b.cPPerson, b.iDisRate, 
b.iCreGrade, b.iCreLine, b.iCreDate, b.cPayCond, b.cSupIAddress, b.cSupIType, b.cSupHeadCode, b.cSupDepart, 
b.dEndDate, b.bSupTax, b.cZoneNo, b.cBalanceType, b.cBalanceTypeNo, b.cRegNo, b.cHezuoFangshi, b.cHelpCode, 
b.iDays
from '+@PosName+'.dbo.t_Supplier_Contract a right join #temp_NocSupNoContract b on  a.csupno=b.cSupNo 
            where ISNULL(a.cSupno,'''')=''''     
                        
  --- 商品信息   
     
    INSERT INTO '+@PosName+'.dbo.[t_Goods]
           ([cGoodsNo],[cUnitedNo],[cGoodsName],[cGoodsTypeno],[cGoodsTypename],[cBarcode],[cUnit]
           ,[cSpec],[fNormalPrice],[fVipPrice],[cProductUnit],[cHelpCode],[cTaxRate],[cHezuoFangshi]
           ,[fPreservationUp],[fPreservationDown],[cLevel],[bSuspend],[bDeling],[bDeled],[dSuspendDate1]
           ,[dSuspendDate2],[dDelingDate1],[dDelingDate2],[fVipScore],[bProducted],[cProductNo],[bStock]
           ,[bPiCi],[bShenHe],[bWeight],[bCared],[fCKPrice],[cSupNo],[cSupName],[bStorage],[bBaozhuang]
           ,[fQty_Baozhuang],[fPrice_Baozhuang],[cParentNo],[bNoVipPrice],[dCreateDate],[cCkPriceInSheetno]
           ,[fLastCostPrice],[fLastRatio],[cZoneNo],[cZoneName],[fPrice_BaozhuangClient],[pinpaino]
           ,[pinpai],[bHidePrice],[bHideQty],[iGoodsStatus],[cSeasonNo],[cPersonNo],[iSex] ,[fPreservation_soft]
           ,[bUpdate],[bStocking],[fVipScore_base],[fVipPrice_student],[cGoodsNo_minPackage],[fQty_minPackage]
           ,[fPackRatio],[cGoodsNo_minPackage_tmp],[bQty_created],[cSheetNo_StockVerify],[fQty_created]
           ,[fPrice_Contract],[fRatio],[cUpdatePici],[dUpdate],[dCheckSupNo],[cCheckSupNo],[bUnStock])  
    select a.[cGoodsNo],a.[cUnitedNo],a.[cGoodsName],a.[cGoodsTypeno],a.[cGoodsTypename],a.[cBarcode],a.[cUnit]
           ,a.[cSpec],a.[fNormalPrice],a.[fVipPrice],a.[cProductUnit],a.[cHelpCode],a.[cTaxRate],a.[cHezuoFangshi]
           ,a.[fPreservationUp],a.[fPreservationDown],a.[cLevel],a.[bSuspend],a.[bDeling],a.[bDeled],a.[dSuspendDate1]
           ,a.[dSuspendDate2],a.[dDelingDate1],a.[dDelingDate2],a.[fVipScore],a.[bProducted],a.[cProductNo],a.[bStock]
           ,a.[bPiCi],a.[bShenHe],a.[bWeight],a.[bCared],a.[fCKPrice],a.[cSupNo],a.[cSupName],a.[bStorage],a.[bBaozhuang]
           ,a.[fQty_Baozhuang],a.[fPrice_Baozhuang],a.[cParentNo],a.[bNoVipPrice],a.[dCreateDate],a.[cCkPriceInSheetno]
           ,a.[fLastCostPrice],a.[fLastRatio],a.[cZoneNo],a.[cZoneName],a.[fPrice_BaozhuangClient],a.[pinpaino]
           ,a.[pinpai],a.[bHidePrice],a.[bHideQty],a.[iGoodsStatus],a.[cSeasonNo],a.[cPersonNo],a.[iSex] ,a.[fPreservation_soft]
           ,a.[bUpdate],a.[bStocking],a.[fVipScore_base],a.[fVipPrice_student],a.[cGoodsNo_minPackage],a.[fQty_minPackage]
           ,a.[fPackRatio],a.[cGoodsNo_minPackage_tmp],a.[bQty_created],a.[cSheetNo_StockVerify],a.[fQty_created]
           ,a.[fPrice_Contract],a.[fRatio],a.[cUpdatePici],a.[dUpdate],a.[dCheckSupNo],a.[cCheckSupNo],a.[bUnStock] 
           from t_Goods a, #temp_NocGoods b
           where a.cGoodsNo=b.cGoodsNo
            

           ')
end
GO
