/*    
  declare @return varchar(32)
  exec [p_cStoreBhApplyTocStoreOut_test] 'BHSQ20171099-000008',@return output
  select @return  
*/
CREATE proc [dbo].[p_cStoreBhApplyTocStoreOut]
@cSheetNo varchar(32),--- 补货单号。
@return varchar(32) output    -- 正确返回配送出库单号、异常返回0
as
begin

   update WH_BhApply set jiesuanno='APP',bExamin=0
   where cSheetNo=@cSheetNo
   
   set @return=1
   
   
   /*
   declare @cStoreNo varchar(32)
   declare @dDAte datetime
   select @cStoreNo=cStoreNo,@dDAte=dDate from WH_BhApply
   where cSheetno=@cSheetNo
   
   declare @fQtyCount int
   
   select @fQtyCount=COUNT(*) from WH_BhApplyDetail
   where cSheetno=@cSheetNo and ISNULL(fQuantity,0)>0
   
  if @fQtyCount=0  --表示没有需要提交的数据
  begin
     set @return=1        -- 正确返回1      
  end else
  begin 
  begin try
  begin tran
      --生成配送出库单号
      declare @cOutSheetno varchar(32)
      select @cOutSheetno=dbo.f_GencStoreOutsheetno(CAST(Year(@dDAte) as varchar),@cStoreNo)
      
      --- 生成出库批次号
      declare @cOutSerNo varchar(32)
      
      set @cOutSerNo=(select dbo.[f_cStoreOutPcSerNo](@dDAte,@cStoreNo))
      
	   ---插入单据
	   insert into wh_cStoreOutWarehouse  (    
	   cSheetno,cCustomerNo,cCustomer,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,    
	   bExamin,cWhNo,cWh,dDate,cTime,cBeizhu1,cBeizhu2,cStoreNo,cStoreName,StoreInSheetNo,cOutSerNo,bfresh)  
	   select   @cOutSheetno,a.cStoreNo,a.cStoreName,cOperatorNo,cOperator,cFillEmpNo,cFillEmp,    
	   dFillin,cFillinTime,cStockDptno,cStockDpt,fMoney,     1,b.cWhNo,b.cWh,    
	   dDate,cTime,cBeizhu1,cBeizhu2,b.cStoreNo,b.cStoreName,cSheetno ,@cOutSerNo,a.bfresh
	   from WH_BhApply a,v_StoreParent b 
	   where  cSheetno=@cSheetNo 
	   and a.cStoreNo=b.cStoreNo1
	   
	   ---获取实时库存
         if (select OBJECT_ID('tempdb..#temp_Goods'))is not null  drop table #temp_Goods         
         select cGoodsNo into #temp_Goods  
         from WH_BhApplyDetail
         where cSheetNo=@cSheetNo 
         
         if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
         create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
         declare @dDate1 varchar(32) set @dDate1=dbo.getDayStr(GETDATE())
         declare @cWhNo varchar(32) 
         
         declare @cStorePrent varchar(32)
         set @cStorePrent=(select cParentNo from t_Store where cStoreNo=@cStoreNo)
         
         
         select top 1 @cWhNo=cWhNo from t_WareHouse where cStoreNo=@cStorePrent and ISNULL(bMainSale,0)=1
         
        
          exec P_x_SetCheckWh_byGoodsType_logCurQty_Out @cStorePrent,@dDate1,@dDate1,@cWhNo 
         -- exec [P_x_SetCheckWh_byGoodsType_logCurQty]   @cStorePrent,@dDate,@dDate,@cWhNo 
 
          
        ---获取当前库存大于0 
        if (select OBJECT_ID('tempdb..#temp_cStoreOutGoods'))is not null  drop table  #temp_cStoreOutGoods
        select a.cGoodsNo,EndQty into  #temp_cStoreOutGoods 
        from #temp_goodsKuCurQty a,#temp_Goods b 
        where a.cGoodsNo=b.cGoodsNo and ISNULL(a.EndQty,0)>0
        
	  
	   update a
       --set  a.cBeizhu=cast(cast(ROUND(a.fQuantity/ISNULL(b.fPackRatio,1), 0, 1) as int) as varchar)
       set  a.cBeizhu=cast(ROUND(a.fQuantity/ISNULL(b.fPackRatio,1),2) as varchar),
       a.fInPrice=ISNULL(b.fPsprice,0),
       fInMoney=ISNULL(a.fQuantity,0)*ISNULL(b.fPsprice,0),
       fTaxMoney=ISNULL(a.fQuantity,0)*ISNULL(a.fTaxPrice,0)
       from WH_BhApplyDetail a,t_Goods b
       where cSheetNo=@cSheetNo and a.cGoodsNo=b.cGoodsNo 
       and ISNULL(a.fQuantity,0)>0 and ISNULL(b.fPackRatio,1)>1

	  -- 插入明细  	  
	  
	    if (select OBJECT_ID('tempdb..#temp_cStoreOutWhareGoods'))is not null  drop table #temp_cStoreOutWhareGoods
		select a.fPacks,iSeed=IDENTITY(int,1,1),a.cSheetno,a.iLineNo,a.cGoodsNo,  a.cGoodsName,cGoodsName01=a.cGoodsName,
		a.cBarcode,a.cUnitedNo,a.fQuantity,fInPrice=isnull(b.fPsprice,0),a.fInMoney,a.fTaxrate,a.bTax,a.fTaxPrice,
		a.fTaxMoney,a.fNoTaxPrice,a.fNoTaxMoney,a.dProduct,a.fTimes,a.cProductSerno,
		b.cUnit,b.cSpec,a.dCheck,fPackRatio=isnull(b.fPackRatio,1),
		cBeizhu=cBeizhu,cGoodsTypeNo,cGoodsTypeName,
		fQty=case when isnull(a.fQuantity,0)>isnull(c.EndQty,0) 
		then isnull(c.EndQty,0) else isnull(a.fQuantity,0) end,EndQty
		into #temp_cStoreOutWhareGoods
		from WH_BhApplyDetail a,t_Goods b,#temp_cStoreOutGoods c
		where a.cSheetno=@cSheetNo  and a.cGoodsNo=b.cGoodsNo and b.cGoodsNo=c.cGoodsNo 
		and a.cGoodsNo=c.cGoodsNo and isnull(a.fQuantity,0)<>0 and ISNULL(b.fPsprice,0)>0		
		order by iLineNo
        
        ---根据数量分配
		update  #temp_cStoreOutWhareGoods  
		set fQuantity=fQty,fInMoney=fQty*fInPrice,
		fTaxMoney=fQty*fTaxPrice,fNoTaxMoney=fQty*fNoTaxPrice
		
		
	  
      insert into dbo.wh_cStoreOutWarehouseDetail  
      (cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,    
      fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,    
      fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,    cUnit,cSpec,cBeizhu,fQty_Cur  )  
      select @cOutSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,  
	--	fQuantity,fInPrice=case when ISNULL(b.fPsprice,0)=0 
	--then case when ISNULL(b.fCKPrice,0)=0 
	--then case when ISNULL(b.fPrice_Contract,0)=0 
	--then fNormalPrice else fPrice_Contract 
	--end else b.fCKPrice end else b.fPsprice end,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,  
	    fQuantity,fInPrice,fInMoney,fTaxrate,fTaxPrice,fTaxMoney,  
		fNoTaxPrice,fNoTaxMoney,dProduct,fTimes,cProductSerno,cUnit,cSpec,cBeizhu,EndQty
		from #temp_cStoreOutWhareGoods	
		order by iLineNo
	      
      update WH_BhApply set bPeisong=1,OutSheetNo=@cOutSheetno ,jiesuanno='APP'
      where cSheetNo=@cSheetNo
      
      
      commit tran
	  set @return=@cOutSheetno        -- 正确返回1 
  end try
  begin catch
	 rollback 
     set @return='0'        ---  异常 返回 0
  end catch
 
  end 
  */
end
GO
