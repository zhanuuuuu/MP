/*

p_GetWeekDayOrderRate '1007','2016-12-26'

select * from t_cStoreOrderBhXs

 
*/

CREATE proc p_GetWeekDayOrderRate
@cStoreNo varchar(32),
@dDate0 datetime
as
begin


declare @dDate datetime
set @dDate=@dDate0


declare @WeekDay varchar(16)
set @WeekDay=datename(weekday, @dDate)
 
if @WeekDay='星期一' 
begin
		-----------获取前一周的销量、得出当前周的周系数
		
		----获取每周对应日期
		declare @dDate1_4 datetime
		set @dDate1_4=@dDate-28
		
		declare @dDate1 datetime
		set @dDate1=@dDate-7
		declare @dDate2 datetime
		set @dDate2=@dDate-6
		declare @dDate3 datetime
		set @dDate3=@dDate-5
		declare @dDate4 datetime
		set @dDate4=@dDate-4
		declare @dDate5 datetime
		set @dDate5=@dDate-3
		declare @dDate6 datetime
		set @dDate6=@dDate-2
		declare @dDate7 datetime
		set @dDate7=@dDate-1
 
		
		-----构造临时生鲜信息表
		if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
		create table #temp_Goods(cGoodsNo varchar(32))
		
		insert into #temp_Goods(cGoodsNo)
		select cGoodsNo 
		from t_cStoreGoods 
		where  cStoreNo=@cStoreNo  
		and ISNULL(bfresh,0)=1  
		
		-----获取整周销量
		
		if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate1'))is not null  drop table #temp_cGoodsSaleDate1
	    create table #temp_cGoodsSaleDate1(cGoodsno varchar(32),fQty money,fQty_zj money,fQty_tj money,dWeekDay varchar(32))
	    
	    declare @fWeekDayMoney money
	    
	    ---前28天 的日销平均
	    
	    declare @dOpen datetime
	    set @dOpen=(select a.dOpenDate 
	    from t_OpenDate a,t_WareHouse b
	    where a.cStoreNo=b.cWhNo and b.cStoreNo=@cStoreNo)
	    declare @dDay int     --- 天数
	    if @dDate1_4<@dOpen   --- 取有效天数
	    begin
	       set @dDate1_4=@dOpen 
	       set @dDay=(DATEDIFF ( DAY , @dDate1_4 , @dDate7 ))+1
	    end else
	    begin
	       set @dDay=28
	    end
	    
 
        
		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate1_4,@dDate7,''
		
		set @fWeekDayMoney=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		----获取周平均值
		declare @fAvgWeekDay money
		if ISNULL(@fWeekDayMoney,0)=0  
		begin
		   set @fAvgWeekDay=1
		end else
		begin		   
		   set @fAvgWeekDay=@fWeekDayMoney/@dDay
		end
		
		---获取最近的增长系数
		
        declare @dRatio money
		set @dRatio=(select top 1 isnull(fBhRate,1.05) from t_cStoreOrderBhXs where dDate=@dDate7)
		
		-----获取周一销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney1 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate1,@dDate1,''
		
		set @fWeekDayMoney1=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney1=1
		end
		----
		delete from t_cStoreOrderBhXs where dDate=@dDate and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate,@cStoreNo,datename(weekday, @dDate),@fWeekDayMoney1/@fAvgWeekDay,@fWeekDayMoney1/@fAvgWeekDay,@dRatio)
		
		-----获取周二销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney2 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate2,@dDate2,''
		
		set @fWeekDayMoney2=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney2=1
		end
		----
		delete from t_cStoreOrderBhXs where dDate=(@dDate+1) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+1,@cStoreNo,datename(weekday, @dDate+1),@fWeekDayMoney2/@fAvgWeekDay,@fWeekDayMoney2/@fAvgWeekDay,@dRatio)
		
		-----获取周三销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney3 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate3,@dDate3,''
		
		set @fWeekDayMoney3=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney3=1
		end
		
		delete from t_cStoreOrderBhXs where dDate=(@dDate+2) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+2,@cStoreNo,datename(weekday, @dDate+2),@fWeekDayMoney3/@fAvgWeekDay,@fWeekDayMoney3/@fAvgWeekDay,@dRatio)
		
		-----获取周四销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney4 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate4,@dDate4,''
		
		set @fWeekDayMoney4=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney4=1
		end
		----
		delete from t_cStoreOrderBhXs where dDate=(@dDate+3) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+3,@cStoreNo,datename(weekday, @dDate+3),@fWeekDayMoney4/@fAvgWeekDay,@fWeekDayMoney4/@fAvgWeekDay,@dRatio)
		
		-----获取周五销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney5 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate5,@dDate5,''
		
		set @fWeekDayMoney5=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney5=1
		end
		----
		delete from t_cStoreOrderBhXs where dDate=(@dDate+4) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+4,@cStoreNo,datename(weekday, @dDate+4),@fWeekDayMoney5/@fAvgWeekDay,@fWeekDayMoney5/@fAvgWeekDay,@dRatio)
		
		-----获取周六销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney6 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate6,@dDate6,''
		
		set @fWeekDayMoney6=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney6=1
		end
		
		delete from t_cStoreOrderBhXs where dDate=(@dDate+5) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+5,@cStoreNo,datename(weekday, @dDate+5),@fWeekDayMoney6/@fAvgWeekDay,@fWeekDayMoney6/@fAvgWeekDay,@dRatio)
		
        -----获取周日销量
		
	    truncate table #temp_cGoodsSaleDate1
	    
	    declare @fWeekDayMoney7 money

		exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate7,@dDate7,''
		
		set @fWeekDayMoney7=(select SUM(fQty) from #temp_cGoodsSaleDate1)
		
		if @fAvgWeekDay=1 
		begin
		  set @fWeekDayMoney7=1
		end
		
		delete from t_cStoreOrderBhXs where dDate=(@dDate+6) and cStoreNo=@cStoreNo
		
		insert into t_cStoreOrderBhXs(dDate,cStoreNo,dWeek,fOrderXs1,fOrderXs0,fBhRate)
		values(@dDate+6,@cStoreNo,datename(weekday, @dDate+6),@fWeekDayMoney7/@fAvgWeekDay,@fWeekDayMoney7/@fAvgWeekDay,@dRatio)
		
		
		
		 
		---设置本周对应的日期、 和周

end

end
GO
