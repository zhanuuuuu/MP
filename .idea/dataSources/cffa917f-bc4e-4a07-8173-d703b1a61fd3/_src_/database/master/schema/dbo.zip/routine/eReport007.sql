/*
[eReport007]
'2012-03-01','2012-03-31'
*/
CREATE procedure [dbo].[eReport007]
@begintime datetime,
@endtime datetime
as  
--declare @begintime datetime,@endtime datetime
--select @begintime='2012-01-01',@endtime='2012-02-01'


----------------------------------<<<<<<<<<?///////////////////////////////////////

if(select OBJECT_ID('tempdb..#temp_salesheetDetail')) is not null drop table #temp_salesheetDetail
create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNO varchar(32),
cSaleSheetno varchar(64))
 if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@begintime ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@endtime) b
			where a.DataBaseName=b.DataBaseName
				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
                      
						insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						cSaleSheetno)
						select dSaleDate,cGoodsNo,
						cSaleSheetno
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@begintime+''' and '''+@endtime+'''
   
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
		
				  
			insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						cSaleSheetno)
			select dSaleDate,cGoodsNo,
						cSaleSheetno
			from dbo.t_salesheetDetail 
			where dSaleDate between @SalesheetDate+1 and @endtime
------------------------------


if(select object_id('tempdb..#info')) is not null 	drop table #info
select distinct b.cSaleSheetno,c.cSupNo
into #info
--from t_SaleSheetDetail b left join t_goods c
from #temp_salesheetDetail b left join t_goods c
on b.cGoodsNo=c.cGoodsNo
where b.dSaleDate between @begintime and @endtime




if(select object_id('tempdb..#sup_count')) is not null 	drop table #sup_count
create table #sup_count
(csupno varchar(50),csupname varchar(100),num int)

declare @csupno varchar(32)
declare @i int
declare crcSupNo cursor for
select cSupNo from t_supplier order by cSupNo
open crcSupNo
fetch next from crcSupNo
into @csupno
while @@Fetch_Status=0
begin
    select @i=count(cSaleSheetno) from #info where cSupNo=@csupno
    insert into #sup_count(csupno,num)values(@csupno,@i)
    fetch next from crcSupNo into @csupno
    set @i=0
end
CLOSE crcSupNo
DEALLOCATE crcSupNo

select a.csupno,b.cSupName,a.num,date1=@begintime,date2=@endtime
from #sup_count a left join t_supplier b
on a.csupno=b.cSupNo
	
	--if(select object_id('tempdb..#a')) is not null 	drop table #a
	
	--select a.* 
	--into #a
	--from t_supplier a left join #info b
	--on a.cSupNo=b.cSupNo
	--order by a.cSupNo 
	
	--select a.cSupNo ,a.cSupName,num=COUNT(cSupNo) from 
	--#a a
	--group by a.cSupNo ,a.cSupName
	--order by cSupNo

GO
