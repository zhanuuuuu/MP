
CREATE proc p_InStoreGoodsToStore
@cStoreNo1 varchar(32),
@cStoreNo2 varchar(32)
as 
begin

    if(select object_id('tempdb..#temp_StoreGoods0')) is not null
	begin
		drop table 	#temp_StoreGoods0
	end 	
	
	select cGoodsNo into #temp_StoreGoods0 from t_cStoreGoods 
	where cStoreNo=@cStoreNo1 and isnull(bWeight,0)=0 and isnull(bfresh,0)=0

	if(select object_id('tempdb..#temp_StoreGoods1')) is not null
	begin
		drop table 	#temp_StoreGoods1
	end 	
	
	select cGoodsNo into #temp_StoreGoods1 from t_cStoreGoods 
	where cStoreNo=@cStoreNo2 and isnull(bWeight,0)=0 and isnull(bfresh,0)=0
	
	if(select object_id('tempdb..#temp_StoreGoodsNull')) is not null
	begin
		drop table 	#temp_StoreGoodsNull
	end 	
	select a.cGoodsNo into #temp_StoreGoodsNull  from 
	#temp_StoreGoods1 a left join #temp_StoreGoods0 b
	on a.cGoodsNo=b.cGoodsNo
	where isnull(b.cGOodsNo,'')=''
	
	----获取主供应商。
	if(select object_id('tempdb..#temp_StoreGoodsNullSup')) is not null
	begin
		drop table 	#temp_StoreGoodsNullSup
	end 
	select a.cGoodsNo,a.cSupNo 
	into #temp_StoreGoodsNullSup
	from t_Goods a,#temp_StoreGoodsNull b
	where a.cGoodsNo=b.cGoodsNO
	
	---获取门店供应商
	if(select object_id('tempdb..#temp_StoreGoodsNullSupStore')) is not null
	begin
		drop table 	#temp_StoreGoodsNullSupStore
	end 
	select a.cSupNo,a.cSupName,b.cGoodsNo,a.cStoreNo,a.cStoreName
	into #temp_StoreGoodsNullSupStore
	from t_SupplierStore a,#temp_StoreGoodsNullSup b
	where a.cSupNoMain=b.cSupNo
	and a.cStoreNo=@cStoreNo1

	
	    insert into t_cStoreGoods(
		cGoodsNo, cStoreNo, cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fVipPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, fPreservationUp, fPreservationDown, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		fVipScore, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		cSupNo, cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, dUpdate, dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		)
	    select a.cGoodsNo, b.cStoreNo,b.cStoreName, cUnitedNo, cGoodsName, cGoodsTypeno, 
		cGoodsTypename, cBarcode, cUnit, cSpec, fNormalPrice, fNormalPrice, cProductUnit, 
		cHelpCode, cTaxRate, cHezuoFangshi, a.fPreservationUp, a.fPreservationDown, cLevel, 
		bSuspend, bDeling, bDeled, dSuspendDate1, dSuspendDate2, dDelingDate1, dDelingDate2, 
		a.fNormalPrice, bProducted, cProductNo, bStock, bPiCi, bShenHe, bWeight, bCared, fCKPrice,
		b.cSupNo, b.cSupName, bStorage, bBaozhuang, fQty_Baozhuang, fPrice_Baozhuang, cParentNo, 
		bNoVipPrice, dCreateDate, cCkPriceInSheetno, fLastCostPrice, fLastRatio, cZoneNo, cZoneName, 
		fPrice_BaozhuangClient, pinpaino, pinpai, bHidePrice, bHideQty, iGoodsStatus, cSeasonNo, cPersonNo, 
		iSex, fPreservation_soft, bUpdate, bStocking, fVipScore_base, fVipPrice_student, cGoodsNo_minPackage, 
		fQty_minPackage, fPackRatio, cGoodsNo_minPackage_tmp, bQty_created, cSheetNo_StockVerify, fQty_created,
		fPrice_Contract, fRatio, cUpdatePici, GETDATE(), dCheckSupNo, cCheckSupNo, bUnStock, iNumOfSup, bDownLoad, 
		fAddRatio_Cal, fInPrice_cuxiao, dDate1_cuxiao, dDate2_cuxiao, fFreshDays, O2O, cGoodsImage, isPrint,
		bPosX, fPfPrice, fDbPrice, bfresh, fLossRatio, bTestSale, TestSalebgn, TestSaleend, bStop, cJijie, 
		cJijieMonth, bJijie, cLength, cWidth, cHeight, bUpDatePrice, bNew, bDaZhe, bClear, bReturnMoney,
		bMoneycard, fMoneyValue
		from t_cStoreGoods a,#temp_StoreGoodsNullSupStore b
		where a.cStoreNo=@cStoreNo2 and a.cGoodsNo=b.cGoodsNo
		
		
		insert into t_cStoreGoodsKuWei(cStoreNo,cGoodsNo,fPreservationUp,fPreservationDown,fPreserPaimian,dUpdAte,
		fPreservationDown_Old,fPreservationUp_Old,AnQuan_Xs,Songhuo_Tianshu)
		select b.cStoreNo,b.cGoodsNo,fPreservationUp,fPreservationDown,fPreserPaimian,dUpdAte,
		fPreservationDown_Old,fPreservationUp_Old,AnQuan_Xs,Songhuo_Tianshu
		from t_cStoreGoodsKuWei a,#temp_StoreGoodsNullSupStore b
		where a.cStoreNo=@cStoreNo2 and a.cGoodsNo=b.cGoodsNo
		
		
end
GO
