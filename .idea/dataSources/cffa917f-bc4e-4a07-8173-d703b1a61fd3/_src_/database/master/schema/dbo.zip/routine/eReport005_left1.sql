CREATE procedure [dbo].[eReport005_left1]
@date1 datetime,
@date2 datetime,
@sj1 int,@sj2 int
as
begin
/*
eReport005_left
@date1='2012-06-01',@date2='2012-06-07',@sj1=9,@sj2=22,
@ctypeno='@@61@@,@@62@@,@@63@@,@@8100102@@,@@8100103@@,@@8100104@@,@@8100105@@,@@8100106@@,@@8100107@@,@@81002@@,@@8100201@@,@@8100202@@,@@8100203@@,@@8100204@@,@@8100205@@,@@8100206@@,@@8100207@@,@@8100208@@,@@@@,@@@@'

*/
--获取年份周次的开始结束日期
--declare @date1 datetime
--declare @date2 datetime
--declare @sj1 int
--declare @sj2 int
--declare @No varchar(32)
--declare @ctypeno varchar(8000)
--select @date1='2011-06-01',@date2='2011-06-07',@sj1=9,@sj2=13,@No='',
----@ctypeno='@@8100102@@,@@8100104@@,@@8100106@@,@@81501@@,@@8150101@@,@@8150102@@,@@8150103@@,@@8150104@@,@@8150105@@,@@8150106@@,@@8150107@@'
--@ctypeno='@@810@@,@@81001@@,@@8100101@@,@@8100102@@,@@8100103@@,@@8100104@@,@@8100105@@,@@8100106@@,@@8100107@@,@@81002@@,@@8100201@@,@@8100202@@,@@8100203@@,@@8100204@@,@@8100205@@,@@8100206@@,@@8100207@@,@@8100208@@,@@@@,@@@@'
--set @ctypeno=REPLACE ( @ctypeno , '@@' , '''' )
--select @ctypeno

--if(select object_id('tempdb..#tempLevel1')) is not null drop table #tempLevel1
if(select object_id('tempdb..#tempLevel')) is not null drop table #tempLevel
if(select object_id('tempdb..#tempLeaf')) is not null drop table #tempLeaf
create table #tempLevel (cGoodsTypeNo varchar(32),cPath varchar(1024),iLevel int )

create table #tempLeaf (cGoodsTypeNo varchar(50),cParentNo varchar(50))
insert into #tempLeaf
 select a.cGoodsTypeNo,a.cParentNo
        from dbo.t_GoodsType a left join t_GoodsType b
        on a.cGoodsTypeNo =b.cParentNo 
        where b.cGoodsTypeNo is  null and a.cGoodsTypeno in (select * from #admin_tgoodstype)
        order by a.cParentNo,a.cGoodsTypeNo


declare @cGoodsTypeNo varchar(32)
declare @cParentNo varchar(32)
declare @cPath varchar(1024)
declare @iPathlevel int
declare @cGoodsTypeNo_var varchar(32)
declare crGoodsTypeNo cursor for
select cGoodsTypeNo,cParentNo from #tempLeaf
order by cParentNo,cGoodsTypeNo
open crGoodsTypeNo
fetch next from crGoodsTypeNo
into @cGoodsTypeNo,@cParentNo
set @cGoodsTypeNo_var=@cGoodsTypeNo
set @cPath=''
set @iPathlevel=1
while @@Fetch_Status=0
begin
	while isnull((select top 1 cParentNo from t_GoodsType 
								where cGoodsTypeNo=@cGoodsTypeNo_var 
											and @cGoodsTypeNo_var is not null
								)
								,''
							)<>'--'
	begin
		set @iPathlevel=@iPathlevel+1
		set @cPath= '.'+@cGoodsTypeNo_var+@cPath
		set @cGoodsTypeNo_var=
						isnull((select top 1 cParentNo from t_GoodsType 
										where cGoodsTypeNo=@cGoodsTypeNo_var 
													and @cGoodsTypeNo_var is not null
										),'')
	end				
	set @cPath='--.'+@cGoodsTypeNo_var+@cPath
	insert into #tempLevel (cGoodsTypeNo,cPath,iLevel)
	values (@cGoodsTypeNo,@cPath,@iPathlevel)
	fetch next from crGoodsTypeNo
	into @cGoodsTypeNo,@cParentNo
	set @cGoodsTypeNo_var=@cGoodsTypeNo
	set @cPath=''
	set @iPathlevel=1
end
CLOSE crGoodsTypeNo
DEALLOCATE crGoodsTypeNo

--select * 
--into #tempLevel
--from #tempLevel1 
--where cGoodsTypeNo like '%'+@No+'%'

if(select object_id('tempdb..#tempPath')) is not null
begin
	drop table 	#tempPath
end 
create table #tempPath (cGoodsTypeNo varchar(32),cPath varchar(1024),cPath_leaf  varchar(1024),iLevel int )
insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
select cGoodsTypeNo,cPath,cPath,iLevel from #tempLevel
declare @cPath_p varchar(1024)
declare @cPath_leaf varchar(1024)
declare @cMyTypeNo varchar(32)
declare @iLevel int
declare @i int
declare @iLength int
declare @cPath_var int
declare cur_Path cursor for
select cGoodsTypeNo,cPath,iLevel 
from #tempLevel
order by cGoodsTypeNo
open cur_Path
fetch next from cur_Path
into @cGoodsTypeNo,@cPath_leaf,@iLevel
while @@Fetch_Status=0
begin
	set @i=1
	set @cPath=substring(@cPath_leaf,4,datalength(@cPath_leaf)-3)
	set @cPath_p='.'+@cPath+'.'
	while @i<@iLevel
	begin
		set @iLength=patindex('%.%',@cPath)
		set @cMyTypeNo=substring(@cPath,1,@iLength-1)
		delete from #tempPath
		where cGoodsTypeNo=@cMyTypeNo and cPath_leaf=@cPath_leaf
		insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
		values(@cMyTypeNo,
		substring( 
		substring('.'+@cPath_leaf+'.',1,patindex('%.'+@cMyTypeNo+'.%','.'+@cPath_leaf+'.')+datalength(@cMyTypeNo)),
		2,1024), @cPath_leaf,@i	)
		set @cPath=substring(@cPath,@iLength+1,1024)
		set @cPath_p='.'+@cPath+'.'
		set @i=@i+1
	end
	fetch next from cur_Path
	into @cGoodsTypeNo,@cPath_leaf,@iLevel
end
CLOSE cur_Path
DEALLOCATE cur_Path

if (select object_id('tempdb..#tempGoodsTypePath'))is not null drop table #tempGoodsTypePath
select a.cGoodsTypeNo,b.cGoodsTypename,a.cPath,a.cPath_leaf,a.iLevel
into #tempGoodsTypePath 
from #tempPath a,t_GoodsType b
where a.cGoodsTypeno=b.cGoodsTypeNo
/*以上形成类别列表*/
if (select object_id('tempdb..#TmpGoodsLevel'))is not null drop table #TmpGoodsLevel
select distinct cGoodsTypeNo,iLevel,bLeaf=cast(null as bit)
into #TmpGoodsLevel  --drop table #TmpGoodsLevel
from #tempGoodsTypePath order by cGoodsTypeNo,ilevel

if (select object_id('tempdb..#GoodsType'))is not null drop table #GoodsType
select cGoodsTypeNo,cPath='.'+cPath+'.',iLevel 
into #GoodsType --drop table #GoodsType
from #tempGoodsTypePath
where cPath=cPath_leaf

update a
set bLeaf=1  
from #TmpGoodsLevel a left join #GoodsType b
on a.cGoodsTypeNo=b.cGoodsTypeNo
where b.cGoodsTypeNo is not null
update #TmpGoodsLevel
set bLeaf=0
where bLeaf is null

----------------------------------<<<<<<<<<?///////////////////////////////////////

if(select OBJECT_ID('tempdb..#temp_salesheetDetail')) is not null drop table #temp_salesheetDetail
create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNO varchar(32),fLastSettle money,cSaleTime varchar(16))
 if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName
				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('
                      
						insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime)
						select dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime
						from '+@InfoName1+'.dbo.t_salesheetDetail 
						where dSaleDate between '''+@date1+''' and '''+@date2+'''
   
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
		
				  
			insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime)
			select dSaleDate,cGoodsNo,
						fLastSettle,cSaleTime
			from dbo.t_salesheetDetail 
			where dSaleDate between @SalesheetDate+1 and @date2
 
 
    if (select object_id('tempdb..#TmpGoodsBaseInfo'))is not null drop table #TmpGoodsBaseInfo
--select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,fLastSettle=sum(a.fLastSettle),sj=datepart(hh,cSaleTime)
--into #TmpGoodsBaseInfo
--from t_SaleSheetDetail a left join t_goods b
--on a.cGoodsNo=b.cGoodsNo left join #TmpGoodsLevel c 
--on b.cGoodsTypeno=c.cGoodsTypeNo 
--where c.bLeaf=1 and dSaleDate between @date1 and @date2
--and datepart(hh,cSaleTime) between @sj1 and @sj2 
--group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,datepart(hh,cSaleTime)

select a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,fLastSettle=sum(a.fLastSettle),sj=datepart(hh,cSaleTime)
into #TmpGoodsBaseInfo
--from t_SaleSheetDetail a left join t_goods b
from #temp_salesheetDetail a left join t_goods b
on a.cGoodsNo=b.cGoodsNo left join #TmpGoodsLevel c 
on b.cGoodsTypeno=c.cGoodsTypeNo 
where c.bLeaf=1 and dSaleDate between @date1 and @date2
and datepart(hh,cSaleTime) between @sj1 and @sj2 
group by a.dSaleDate,b.cGoodsTypeNo,b.cGoodsTypename,datepart(hh,cSaleTime)
       
------------------------------<>>>>>>>>>>>>>>>>>>>>???????????????????????????????	  
if (select object_id('tempdb..#tmpGoodsType_byLevel'))is not null
	  drop table #tmpGoodsType_byLevel
	  select BaseGoodsTypeNo=a.cGoodsTypeNo,LeafGoodsTypeNo=b.cGoodsTypeNo,
      a.iLevel,a.bLeaf
	  into #tmpGoodsType_byLevel
	  from #TmpGoodsLevel a,#GoodsType b
	  where a.iLevel=1
	  and b.cPath like '%.'+a.cGoodsTypeNo+'.%'

if (select object_id('tempdb..#tmpGoods_byLevel'))is not null
	drop table #tmpGoods_byLevel 
	select a.dSaleDate,b.BaseGoodsTypeNo,cGoodsTypeName=null,fLastSettle=SUM(a.fLastSettle),a.sj
	into #tmpGoods_byLevel
	from #TmpGoodsBaseInfo a, #tmpGoodsType_byLevel b
	where a.cGoodsTypeNo=b.LeafGoodsTypeNo
	group by a.dSaleDate,b.BaseGoodsTypeNo,a.sj
	order by a.dSaleDate,b.BaseGoodsTypeNo,a.sj

if (select object_id('tempdb..#last'))is not null drop table #last 
if (select object_id('tempdb..#last1'))is not null drop table #last1 
select a.dSaleDate,a.BaseGoodsTypeNo,b.cGoodsTypename,a.fLastSettle,合计=CAST(null as Money),a.sj
into #last 
from #tmpGoods_byLevel a left join t_GoodsType b 
on a.BaseGoodsTypeNo=b.cGoodsTypeno

select 类别NO=BaseGoodsTypeNo,类别名称=cGoodsTypename,
销售金额=sum(fLastSettle),日期=convert(char(10),dSaleDate,120) 
into #last1
from #last 
group by dSaleDate,BaseGoodsTypeNo,cGoodsTypename
order by BaseGoodsTypeNo,dSaleDate

select * from #last1
union all
select '合计:',null,isnull(SUM(fLastSettle),0),null  from #last 
--declare @date varchar(32)
--declare @TypeNo varchar(32)
--declare @money money
--declare @money1 money
--declare @sj int
--set @money=0
--set @sj=9
--declare c cursor for
--select distinct dSaleDate,BaseGoodsTypeNo from #last

--open c
--fetch next from c
--into @date,@TypeNo
--while @@Fetch_Status=0
--begin
--    while @sj<=(select MAX(sj) from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo)
--	begin 
--		(select @money1=fLastSettle from #last where dSaleDate=@date and BaseGoodsTypeNo=@TypeNo and sj=@sj)
--		set @money =@money + @money1
--		update a set a.合计=@money from #last a 
--		where sj=@sj and dSaleDate=@date and BaseGoodsTypeNo=@TypeNo
--		set @sj=@sj+1 
--	end 
--	fetch next from c
--into @date,@TypeNo
--set @money=0
--set @sj=9
--end
--CLOSE c
--DEALLOCATE c

--select 日期=convert(char(10),dSaleDate,120),类别NO=BaseGoodsTypeNo,类别名称=cGoodsTypename,
--销售金额=fLastSettle,合计,时间=sj from #last
--order by dsaledate,basegoodstypeno,sj

end


GO
