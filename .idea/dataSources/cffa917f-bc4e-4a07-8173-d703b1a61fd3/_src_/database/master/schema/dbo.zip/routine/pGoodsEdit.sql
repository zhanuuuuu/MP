
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pGoodsEdit]
	@ModifyID [tinyint],  --1:添加 2:修改
	@cStoreNo [varchar](32),
	@cStoreName [varchar](64),
	@cGoodsNo [varchar](32),
	@cUnitedNo [varchar](32),
	@cGoodsName [varchar](64),
	@cGoodsTypeno [varchar](32),
	@cGoodsTypename [varchar](50),
	@cBarcode [varchar](32),
	@cUnit [varchar](16),
	@cSpec [varchar](32),
	@fNormalPrice [money],
--	@fVipPrice [money],
	@cProductUnit [varchar](64),
	@cHelpCode [varchar](32),
	@cTaxRate [money] ,
	@fPreservationUp [money],
	@fPreservationDown [money],
	@cLevel [varchar](32),
--	[bSuspend] [bit] NULL,
--	[bDeling] [bit] NULL,
--	[bDeled] [bit] NULL,
--	[dSuspendDate1] [datetime] NULL,
--	[dSuspendDate2] [datetime] NULL,
--	[dDelingDate1] [datetime] NULL,
--	[dDelingDate2] [datetime] NULL,
	@fVipScore [money],
--	[bProducted] [bit] NULL,
--	[cProductNo] [varchar](32) NULL,
--	@bStock [bit],
--	[bPiCi] [bit] NULL,
--	[bShenHe] [bit] NULL,
	@bWeight [bit],
	@bCared [bit],
	@fCKPrice [money],
	@cSupNo [varchar](32),
	@cSupName [varchar](98),
	@bStorage [bit], --管控库存
--	[bBaozhuang] [bit] NULL,
--	[fQty_Baozhuang] [money] NULL,
--	[fPrice_Baozhuang] [money] NULL,
--	[cParentNo] [varchar](32) NULL,
--	[bNoVipPrice] [bit] NULL,
--	[dCreateDate] [datetime] NULL,
--	[cCkPriceInSheetno] [varchar](32) NULL,
--	[fLastCostPrice] [money] NULL,
--	[fLastRatio] [money] NULL,
	@cZoneNo [varchar](32),
	@cZoneName [varchar](64),
--	[fPrice_BaozhuangClient] [money] NULL,
	@pinpaino [varchar](32),
	@pinpai [varchar](64),
	@bHidePrice [bit],
	@bHideQty [bit],
--	[iGoodsStatus] [smallint] NULL,
--	[cSeasonNo] [varchar](32) NULL,
--	[cPersonNo] [varchar](32) NULL,
--	[iSex] [smallint] NULL,
	@fPreservation_soft [money],
	@bUpdate [bit],
--	@bStocking [bit],
	@fVipScore_base [money],
--	[fVipPrice_student] [money] NULL, -- 特殊会员价：默认和零售价一致
--	[cGoodsNo_minPackage] [varchar](32) NULL,
	@fQty_minPackage [money],
	@fPackRatio [money],
	@cGoodsNo_minPackage_tmp [varchar](32),
--	[bQty_created] [bit] NULL,
--	[cSheetNo_StockVerify] [varchar](32) NULL,
--	[fQty_created] [money] NULL,
	@fPrice_Contract [money],
	@fRatio [money],
--	[cUpdatePici] [varchar](32) NULL,
--	[dUpdate] [datetime] NULL,
--	[dCheckSupNo] [datetime] NULL,
--	[cCheckSupNo] [varchar](32) NULL,
	@bUnStock [bit],
--	[iNumOfSup] [int] NULL,
--	[bDownLoad] [bit] NULL,
--	[fAddRatio_Cal] [money] NULL,
--	[fInPrice_cuxiao] [money] NULL,
--	[dDate1_cuxiao] [datetime] NULL,
--	[dDate2_cuxiao] [datetime] NULL,
	@fFreshDays [varchar](16),
--	[bChange] [char](2) NULL,
--	[bChangedDate] [datetime] NULL,
	@O2O [char](2),
	@cGoodsImage [image],
--	[isPrint] [bit] NULL,
--	[bPosX] [bit] NULL,
	@fPfPrice [money],
	@fDbPrice [money],
	@bfresh [bit],
	@fLossRatio [money],
--	[fCkPriceLimit] [money] NULL,
--	[bTestSale] [bit] NULL,
--	[TestSalebgn] [datetime] NULL,
--	[TestSaleend] [datetime] NULL,
--	[bStop] [bit] NULL,
--	[cJijie] [varchar](32) NULL,
--	[cJijieMonth] [varchar](32) NULL,
--	[bJijie] [bit] NULL,
	@cLength [money],
	@cWidth [money],
	@cHeight [money],
	@bUpDatePrice [bit],
--	[bNew] [bit] NULL,
	@bDaZhe [bit],
	@bClear [bit],
	@bReturnMoney [bit],
--	[bStorageToNull] [bit] NULL,
	@bMoneycard [bit],
	@fMoneyValue [money],
--	[isPrintApp] [bit] NULL,
--	[fBhRate] [money] NULL,
--	[fDhRate] [money] NULL,
	@fPsprice [money],
	@bOnePSPrice [bit],
	@ikongzhi [int],
	@bBuhuo [bit],
	@fDpRate [money],  --单品配送加价率
	@fWeight [char](16),
	@fColor  [char](16),
	@cXinghao [varchar] (32),
	@UserNo [varchar](32),
	@UserName [varchar](64),
	@StationName [varchar](64)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS(
		      SELECT 1 FROM t_Goods
		      WHERE ((cGoodsNo =  @cUnitedNo) OR (cUnitedNo =  @cUnitedNo) OR (cBarcode =  @cUnitedNo)) AND (cGoodsNo <> @cGoodsNo)
		     )	
	BEGIN
		RAISERROR ('统一内码:[%s]已经存在,请检查后重试..', 16 , 1,@cUnitedNo)
		SET NOCOUNT OFF
		RETURN
	END
	
	--错误计数变量
	DECLARE @ErrorCount INT
	SET @ErrorCount = 0
	SET XACT_ABORT  ON
	BEGIN TRAN	
	
	IF @ModifyID = 1 
	BEGIN
		--商品信息表
		INSERT INTO t_Goods
		(cGoodsNo, cUnitedNo, cGoodsName, cGoodsTypeno, cGoodsTypename, cBarcode, cUnit, cSpec, 
		 fNormalPrice, fVipPrice, cProductUnit, cHelpCode, cTaxRate, fPreservationUp, fPreservationDown, 
		 cLevel, fVipScore, bWeight, bCared, fCKPrice, cSupNo, cSupName, bStorage, cZoneNo, cZoneName, 
		 pinpaino, pinpai, bHidePrice, bHideQty, fPreservation_soft, bUpdate, fVipScore_base, fQty_minPackage, 
		 fPackRatio, cGoodsNo_minPackage_tmp, fPrice_Contract, fRatio, bUnStock, fFreshDays, O2O, fPfPrice, 
		 fDbPrice, bfresh, fLossRatio, cLength, cWidth, cHeight, bUpDatePrice, bDaZhe, bClear, bReturnMoney, 
		 bMoneycard, fMoneyValue, fPsprice, bOnePSPrice, ikongzhi, bBuhuo, fDpRate, cGoodsImage)
		VALUES
		(@cGoodsNo, @cUnitedNo, @cGoodsName, @cGoodsTypeno, @cGoodsTypename, @cBarcode, @cUnit, @cSpec,
		 @fNormalPrice, @fNormalPrice, @cProductUnit, @cHelpCode, @cTaxRate, @fPreservationUp, @fPreservationDown,
		 @cLevel, @fVipScore, @bWeight, @bCared, @fCKPrice, @cSupNo, @cSupName, @bStorage, @cZoneNo, @cZoneName,
		 @pinpaino, @pinpai, @bHidePrice, @bHideQty, @fPreservation_soft, @bUpdate, @fVipScore_base, @fQty_minPackage,
		 @fPackRatio, @cGoodsNo_minPackage_tmp, @fPrice_Contract, @fRatio, @bUnStock, @fFreshDays, @O2O, @fPfPrice,
		 @fDbPrice, @bfresh, @fLossRatio, @cLength, @cWidth, @cHeight, @bUpDatePrice, @bDaZhe, @bClear, @bReturnMoney,
		 @bMoneycard, @fMoneyValue, @fPsprice, @bOnePSPrice, @ikongzhi, @bBuhuo, @fDpRate, @cGoodsImage)
		 
		SET @ErrorCount = @ErrorCount + @@ERROR
		
		--商品信息附属表
		INSERT INTO t_GoodsItems
		(cGoodsNo,fWeight,fColor,cXinghao)
		VALUES
		(@cGoodsNo,@fWeight,@fColor,@cXinghao)
		
		SET @ErrorCount = @ErrorCount + @@ERROR 

		--门店商品信息表
		INSERT INTO t_cStoreGoods
		(cStoreNo, cStoreName, cGoodsNo, cUnitedNo, cGoodsName, cGoodsTypeno, cGoodsTypename, cBarcode, cUnit, cSpec, 
		 fNormalPrice, fVipPrice, cProductUnit, cHelpCode, cTaxRate, fPreservationUp, fPreservationDown, 
		 cLevel, fVipScore, bWeight, bCared, fCKPrice, cSupNo, cSupName, bStorage, cZoneNo, cZoneName, 
		 pinpaino, pinpai, bHidePrice, bHideQty, fPreservation_soft, bUpdate, fVipScore_base, fQty_minPackage, 
		 fPackRatio, cGoodsNo_minPackage_tmp, fPrice_Contract, fRatio, bUnStock, fFreshDays, O2O, fPfPrice, 
		 fDbPrice, bfresh, fLossRatio, cLength, cWidth, cHeight, bUpDatePrice, bDaZhe, bClear, bReturnMoney, 
		 bMoneycard, fMoneyValue, fPsprice, bOnePSPrice, ikongzhi, bBuhuo, fDpRate, cGoodsImage)
		VALUES
		(@cStoreNo, @cStoreName, @cGoodsNo, @cUnitedNo, @cGoodsName, @cGoodsTypeno, @cGoodsTypename, @cBarcode, @cUnit, @cSpec,
		 @fNormalPrice, @fNormalPrice, @cProductUnit, @cHelpCode, @cTaxRate, @fPreservationUp, @fPreservationDown,
		 @cLevel, @fVipScore, @bWeight, @bCared, @fCKPrice, @cSupNo, @cSupName, @bStorage, @cZoneNo, @cZoneName,
		 @pinpaino, @pinpai, @bHidePrice, @bHideQty, @fPreservation_soft, @bUpdate, @fVipScore_base, @fQty_minPackage,
		 @fPackRatio, @cGoodsNo_minPackage_tmp, @fPrice_Contract, @fRatio, @bUnStock, @fFreshDays, @O2O, @fPfPrice,
		 @fDbPrice, @bfresh, @fLossRatio, @cLength, @cWidth, @cHeight, @bUpDatePrice, @bDaZhe, @bClear, @bReturnMoney,
		 @bMoneycard, @fMoneyValue, @fPsprice, @bOnePSPrice, @ikongzhi, @bBuhuo, @fDpRate, @cGoodsImage)
		 
		SET @ErrorCount = @ErrorCount + @@ERROR 
		
		--供商对应商品信息表
		INSERT INTO t_Supplier_goods
		(cSupNo,cSupName,cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fInMoney,cGoodsTypeno,cGoodsTypename)
        VALUES
        (@cSupNo,@cSupName,@cGoodsNo,@cUnitedNo,@cGoodsName,@cBarcode,@cUnit,@cSpec,@fckprice,@cGoodsTypeno,@cGoodsTypename)
    
		SET @ErrorCount = @ErrorCount + @@ERROR 
		
		UPDATE  t_posstation SET bDownLoad=1
		
		SET @ErrorCount = @ErrorCount + @@ERROR
			
	END
	
	IF @ModifyID = 2
	BEGIN
		--更新商品信息表
		UPDATE t_Goods
		SET
		cUnitedNo = @cUnitedNo, cGoodsName = @cGoodsName, cGoodsTypeno = @cGoodsTypeno, cGoodsTypename = @cGoodsTypename,
		cBarcode = @cBarcode, cUnit = @cUnit, cSpec = @cSpec, fNormalPrice = @fNormalPrice, fVipPrice = @fNormalPrice,
		cProductUnit = @cProductUnit, cHelpCode = @cHelpCode, cTaxRate = @cTaxRate, fPreservationUp = @fPreservationUp,
		fPreservationDown = @fPreservationDown, cLevel = @cLevel, fVipScore = @fVipScore, bWeight = @bWeight, bCared = @bCared,
		fCKPrice = @fCKPrice, cSupNo = @cSupNo, cSupName = @cSupName, bStorage = @bStorage, cZoneNo = @cZoneNo,
		cZoneName = @cZoneName, pinpaino = @pinpaino, pinpai = @pinpai, bHidePrice = @bHidePrice, bHideQty = @bHideQty,
		fPreservation_soft = @fPreservation_soft, bUpdate = @bUpdate, fVipScore_base = @fVipScore_base,
		fQty_minPackage = @fQty_minPackage,fPackRatio = @fPackRatio, cGoodsNo_minPackage_tmp = @cGoodsNo_minPackage_tmp,
		fPrice_Contract = @fPrice_Contract, fRatio = @fRatio, bUnStock = @bUnStock, fFreshDays = @fFreshDays, O2O = @O2O,
		fPfPrice = @fPfPrice, fDbPrice = @fDbPrice, bfresh = @bfresh, fLossRatio = @fLossRatio, cLength = @cLength,
		cWidth = @cWidth, cHeight = @cHeight, bUpDatePrice = @bUpDatePrice, bDaZhe = @bDaZhe, bClear = @bClear,
		bReturnMoney = @bReturnMoney, bMoneycard = @bMoneycard, fMoneyValue = @fMoneyValue, fPsprice = @fPsprice,
		bOnePSPrice = @bOnePSPrice, ikongzhi = @ikongzhi, bBuhuo = @bBuhuo, fDpRate = @fDpRate, cGoodsImage = @cGoodsImage,
		dUpdate = GETDATE()
		WHERE cGoodsNo = @cGoodsNo
		 
		SET @ErrorCount = @ErrorCount + @@ERROR	
		
		--更新门店信息表中非本店信息,不含价格
		UPDATE t_cStoreGoods
		SET
		cUnitedNo = @cUnitedNo, cGoodsName = @cGoodsName, cGoodsTypeno = @cGoodsTypeno, cGoodsTypename = @cGoodsTypename,
		cBarcode = @cBarcode, cUnit = @cUnit, cSpec = @cSpec, 
		cProductUnit = @cProductUnit, cHelpCode = @cHelpCode, cTaxRate = @cTaxRate,
		cLevel = @cLevel, bWeight = @bWeight, bCared = @bCared,
		cSupNo = @cSupNo, cSupName = @cSupName, bStorage = @bStorage, cZoneNo = @cZoneNo,
		cZoneName = @cZoneName, pinpaino = @pinpaino, pinpai = @pinpai, bHidePrice = @bHidePrice, bHideQty = @bHideQty,
		bUpdate = @bUpdate,
		fQty_minPackage = @fQty_minPackage, cGoodsNo_minPackage_tmp = @cGoodsNo_minPackage_tmp,
		bUnStock = @bUnStock, fFreshDays = @fFreshDays, O2O = @O2O,
		fDbPrice = @fDbPrice, bfresh = @bfresh, fLossRatio = @fLossRatio, cLength = @cLength,
		cWidth = @cWidth, cHeight = @cHeight, bUpDatePrice = @bUpDatePrice, bDaZhe = @bDaZhe, bClear = @bClear,
		bReturnMoney = @bReturnMoney, bMoneycard = @bMoneycard, fMoneyValue = @fMoneyValue, fPsprice = @fPsprice,
		bOnePSPrice = @bOnePSPrice, ikongzhi = @ikongzhi, bBuhuo = @bBuhuo, fDpRate = @fDpRate, cGoodsImage = @cGoodsImage,
		dUpdate = GETDATE()
		WHERE cStoreNo <> @cStoreNo AND cGoodsNo = @cGoodsNo
		
		SET @ErrorCount = @ErrorCount + @@ERROR	
		
		--更新门店信息表中本店信息,含价格
		UPDATE t_cStoreGoods
		SET
		cUnitedNo = @cUnitedNo, cGoodsName = @cGoodsName, cGoodsTypeno = @cGoodsTypeno, cGoodsTypename = @cGoodsTypename,
		cBarcode = @cBarcode, cUnit = @cUnit, cSpec = @cSpec, fNormalPrice = @fNormalPrice, fVipPrice = @fNormalPrice,
		cProductUnit = @cProductUnit, cHelpCode = @cHelpCode, cTaxRate = @cTaxRate, fPreservationUp = @fPreservationUp,
		fPreservationDown = @fPreservationDown, cLevel = @cLevel, fVipScore = @fVipScore, bWeight = @bWeight, bCared = @bCared,
		fCKPrice = @fCKPrice, cSupNo = @cSupNo, cSupName = @cSupName, bStorage = @bStorage, cZoneNo = @cZoneNo,
		cZoneName = @cZoneName, pinpaino = @pinpaino, pinpai = @pinpai, bHidePrice = @bHidePrice, bHideQty = @bHideQty,
		fPreservation_soft = @fPreservation_soft, bUpdate = @bUpdate, fVipScore_base = @fVipScore_base,
		fQty_minPackage = @fQty_minPackage,fPackRatio = @fPackRatio, cGoodsNo_minPackage_tmp = @cGoodsNo_minPackage_tmp,
		fPrice_Contract = @fPrice_Contract, fRatio = @fRatio, bUnStock = @bUnStock, fFreshDays = @fFreshDays, O2O = @O2O,
		fPfPrice = @fPfPrice, fDbPrice = @fDbPrice, bfresh = @bfresh, fLossRatio = @fLossRatio, cLength = @cLength,
		cWidth = @cWidth, cHeight = @cHeight, bUpDatePrice = @bUpDatePrice, bDaZhe = @bDaZhe, bClear = @bClear,
		bReturnMoney = @bReturnMoney, bMoneycard = @bMoneycard, fMoneyValue = @fMoneyValue, fPsprice = @fPsprice,
		bOnePSPrice = @bOnePSPrice, ikongzhi = @ikongzhi, bBuhuo = @bBuhuo, fDpRate = @fDpRate, cGoodsImage = @cGoodsImage,
		dUpdate = GETDATE()
		WHERE cStoreNo = @cStoreNo AND cGoodsNo = @cGoodsNo		
		
		--更新供商商品表价格
		UPDATE t_Supplier_Goods SET
		fInMoney=@fPrice_Contract
		WHERE
		cSupNo=@cSupNo AND cGoodsNo=@cGoodsNo
		
		SET @ErrorCount = @ErrorCount + @@ERROR	
		
		--更新商品附属信息表
		UPDATE t_GoodsItems
		SET 
		fWeight = @fWeight, fColor = @fColor, cXinghao = @cXinghao
		WHERE 
		cGoodsNo = @cGoodsNo
		
		SET @ErrorCount = @ErrorCount + @@ERROR 
		
		--更新门店同步表
		DELETE  t_ChangeGoods WHERE cGoodsNo = @cGoodsNo AND (ISNULL(bAction, 0) = 0)
		SET @ErrorCount = @ErrorCount + @@ERROR	
		
		INSERT INTO t_ChangeGoods(cGoodsNo,cStoreNo)
		SELECT cGoodsNo ,cStoreNo FROM t_cStoreGoods WHERE cGoodsNo = @cGoodsNo				
		SET @ErrorCount = @ErrorCount + @@ERROR	
		
		
		IF @bfresh = 1
		BEGIN
			UPDATE t_Goods SET
			cGoodsNo_minPackage = @cGoodsNo_minPackage_tmp, fQty_minPackage = @fQty_minPackage, cGoodsNo_minPackage_tmp = @cGoodsNo_minPackage_tmp
			WHERE cGoodsNo = @cGoodsNo
			
			SET @ErrorCount = @ErrorCount + @@ERROR
			
			
			UPDATE A SET
			A.cGoodsNo_minPackage_tmp = B.cGoodsNo_minPackage_tmp,
			A.fQty_minPackage = B.fQty_minPackage,
			A.cGoodsNo_minPackage = B.cGoodsNo_minPackage
			FROM t_cStoreGoods A ,t_Goods B
            WHERE A.cGoodsNo = B.cGoodsNo AND a.cGoodsNo = @cGoodsNo
            
            SET @ErrorCount = @ErrorCount + @@ERROR
		END
		ELSE
		BEGIN
			UPDATE t_Goods SET
			cGoodsNo_minPackage_tmp = @cGoodsNo_minPackage_tmp,
			fQty_minPackage = @fQty_minPackage
			WHERE cGoodsNo = @cGoodsNO AND (dbo.trim(isnull(cGoodsNo_minPackage,' '))='');
			
			SET @ErrorCount = @ErrorCount + @@ERROR
			
			UPDATE A SET
			A.cGoodsNo_minPackage_tmp = B.cGoodsNo_minPackage_tmp,
			A.fQty_minPackage = B.fQty_minPackage,
			A.cGoodsNo_minPackage = B.cGoodsNo_minPackage
			FROM t_cStoreGoods A, t_Goods B
			WHERE A.cGoodsNo=B.cGoodsNO AND A.cGoodsNo = @cGoodsNo
			SET @ErrorCount = @ErrorCount + @@ERROR
		END
		
	END
	
	--主货区
	DELETE FROM t_zone_Goods WHERE ISNULL(bMain, 0) = 1 AND cGoodsNo = @cGoodsNo
	SET @ErrorCount = @ErrorCount + @@ERROR	
	IF @cZoneNo <> '' 
	BEGIN	
		INSERT INTO t_zone_Goods
		(cZoneNo,cZoneName,cGoodsNo,cGoodsName,cBarcode,bMain,cSupNo,cSupName,dInDate,cInTime)
		VALUES
		(@cZoneNO, @cZoneName, @cGoodsNo, @cGoodsName, @cBarcode, 1, @cStoreNo, @cSupName,
		 CONVERT(varchar(12) , getdate(), 111 ),CONVERT(varchar(100), GETDATE(), 24))
    END
	SET @ErrorCount = @ErrorCount + @@ERROR	
	
	--更新日志
	IF (EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.tables WHERE TABLE_NAME ='t_Log'))
	BEGIN
		INSERT INTO t_Log
		(UserNo ,UserName,Operation,OperTime,StationName)
		VALUES
		(@UserNo ,@UserName,
		 '编辑商品信息 编号:' + @cGoodsNo + '参考进价:' +  CONVERT(varchar(50), @fPrice_Contract) +
         '零售价:' + CONVERT(varchar(50), @fNormalPrice) + '会员价:' + CONVERT(varchar(50), @fNormalPrice) +
         '会员积分:' + CONVERT(varchar(50), @fVipScore) + '批发价:' + CONVERT(varchar(50), @fPfPrice) +
		 '调拨价:' +  CONVERT(varchar(50), @fDbPrice) + '供应商:' + @cSupNo + ' ' + @cSupName +
		 '管理库存:' + CoNVERT(char(1),@bStorage),
		 GETDATE(),@StationName)
		 
		SET @ErrorCount = @ErrorCount + @@ERROR
	END
	
	IF @ErrorCount = 0
		COMMIT TRAN
	ELSE
	BEGIN
		RAISERROR ('商品信息编辑失败,请检查后重试', 16 , 1)
		ROLLBACK TRAN
	END	
	SET NOCOUNT OFF
END

GO
