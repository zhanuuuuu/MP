

CREATE   view v_wh_InWarehouseDetail
as
 select b.cSheetno,iLineNo,a.cGoodsNo,c.cGoodsName,c.cUnitedNo,fQuantity,fPrice,
        fTaxrate,bTax,fTaxPrice,fTaxMoney,fLastMoney,dProduct,
        fTimes,cProductSerno,b.bPost,bChecked,cCheckNo,dCheck,
        cSupplierNo,cSupplier,cOperatorNo,cOperator,dFillin,cFillinTime,
        cProcureDptno,cProcureDpt,b.fMoney,cManagerNo,cManager,bAgree,
        cExaminerNo,cExaminer,bExamin,cWhNo,cWh,dDate,cTime,cGoodsTypeno,
        cGoodsTypename,cBarcode,cUnit,cSpec,fNormalPrice,cProductUnit,
        cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,cLevel,bSuspend,bDeling,
        bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,fVipScore,
        bProducted,cProductNo
 from wh_InWarehouseDetail a left join wh_InWarehouse b
                             on a.cSheetno=b.cSheetno
                             left join t_Goods c
                             on a.cGoodsNo=c.cGoodsNo


GO
