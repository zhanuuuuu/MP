

CREATE proc [dbo].[p_PackRetByClient]
	@SupNO varchar(32),
	@date datetime,
	@MySql varchar(200)
as
begin
exec('
	if (select object_id(''tempdb..#temp_PackIN''))is not null
	begin
		drop table #temp_PackIN	
	end
	if (select object_id(''tempdb..#temp_PackRet''))is not null
	begin
		drop table #temp_PackRet	
	end
	if (select object_id(''tempdb..#temp_PackLost''))is not null
	begin
		drop table #temp_PackLost	
	end
	if (select object_id(''tempdb..#temp_Pack''))is not null
	begin
		drop table #temp_Pack	
	end
	--截止某天收到供应商包装总数
	select a.cPackNo,fQuantity=sum(isnull(a.fQuantity,0)),fMoney=sum(isnull(a.fInMoney,0))
	into #temp_PackIN
	from t_PackOutWarehouseDetail a,t_PackOutWarehouse b
	where a.cSheetNo=b.cSheetNo and isnull(b.bExamin,0)=1
    and isnull(b.cClientNo,'''')='''+@SupNO+''' 
	and b.dDate<='''+@date+'''
	group by a.cPackNo

	--截止某天返还供应商包装总数
	select a.cPackNo,fQuantity=sum(isnull(a.fQty_Baozhuang,0)),fMoney=sum(isnull(a.fMoney_Baozhuang,0))
	into #temp_PackRet
	from t_PackRetDetail a,t_PackRet b
	where a.cSheetNo=b.cSheetNo and isnull(b.bExamin,0)=1
    and isnull(b.cClientNo,'''')='''+@SupNO+''' 
	and b.dDate<='''+@date+'''
	group by a.cPackNo

	--截止某天丢失包装总数
	select a.cPackNo,fQuantity=sum(isnull(a.fQuantity,0)),fMoney=sum(isnull(a.fInMoney,0))
	into #temp_PackLost
	from t_PackLostDetail a,t_PackLost b
	where a.cSheetNo=b.cSheetNo and isnull(b.bExamin,0)=1
    and isnull(b.cClientNo,'''')='''+@SupNO+''' 
	and b.dDate<='''+@date+'''
	group by a.cPackNo

	select a.cPackNo,fQuantity=isnull(a.fQuantity,0)-isnull(b.fQuantity,0)-isnull(c.fQuantity,0),
	fMoney=isnull(a.fMoney,0)-isnull(b.fMoney,0)-isnull(c.fMoney,0)
    into #temp_Pack
	from #temp_PackIN a left join #temp_PackRet b 
	on a.cPackNo=b.cPackNo
	left join #temp_PackLost c
	on a.cPackNo=c.cPackNo
    where isnull(a.fQuantity,0)-isnull(b.fQuantity,0)-isnull(c.fQuantity,0)>0

    select a.cPackNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,b.cUnit,b.cSpec,a.fQuantity,
    fPrice=isnull(b.fQty_Baozhuang,0)*isnull(b.fPrice_BaozhuangClient,0),
    fMoney=(isnull(b.fQty_Baozhuang,0)*isnull(b.fPrice_BaozhuangClient,0))*isnull(a.fQuantity,0)
    from #temp_Pack a left join v_goods b
    on a.cPackNo=b.cGoodsNo '+@MySql
)

end

--p_PackRetByClient '100','2009-3-4','where a.cPackNo like ''%2%'''


GO
