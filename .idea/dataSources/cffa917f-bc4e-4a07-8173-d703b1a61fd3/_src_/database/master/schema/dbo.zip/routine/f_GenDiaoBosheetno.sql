



CREATE     function f_GenDiaoBosheetno
(@cYear varchar(4),@cWhNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.wh_TfrWarehouse
                  where cWhNo=@cWhNo
                        and datename(yyyy,dDate)=@cYear
                 )
   if @cMaxSerno is null 
   begin
     return  'DB'+@cYear+@cWhNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'DB'+@cYear+@cWhNo+'-'+@cMaxSerno 
   end

  return '' 
end


GO
