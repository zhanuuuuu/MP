create view v_GoodsType
as
select * from t_GoodsType where ISNULL(bfresh,0)=1
GO
