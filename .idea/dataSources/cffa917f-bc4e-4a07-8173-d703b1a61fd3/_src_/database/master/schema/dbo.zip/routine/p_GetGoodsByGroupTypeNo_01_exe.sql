

/*
    select * from T_GroupType where cParentno='--'
调用方法：
  1)所有商品 
    p_GetGoodsByGroupTypeNo_01 '006','--'
  2)选择若干组 @GroupTypeNo=',部组编号1,部组编号2,...部组编号n,'
    p_GetGoodsByGroupTypeNo_01 ',101,102,103,'
 
 select * from T_GroupType_GoodsType where cGoodsTypeNo='00110001'
 
 select * from t_cStoreGoods a,T_GroupType_GoodsType b 
 where a.cStoreNo='006' and a.cGoodsTypeNo=b.cGoodsTypeNo
  
  p_GetGoodsByGroupTypeNo_01 '1004',',11,10,13,'
  
  p_GetGoodsByGroupTypeNo_01 '1004',',11,12,10,13,'
                                         
*/

 

CREATE Procedure p_GetGoodsByGroupTypeNo_01_exe
@cStoreNo varchar(32),
@GroupTypeNo varchar(256)
as
begin
	if (select object_id('tempdb..#temp_GoodsList'))is not null
	drop table #temp_GoodsList

	select cStoreNo,cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename
	into #temp_GoodsList
	from t_cStoreGoods
	where cStoreNo=@cStoreNo and cGoodsTypeno
	in
	(
	select x.cGroupTypeNo
	from
	(
		select cGroupTypeNo=cGoodsTypeNo,cGroupTypeName=cGoodsTypeName,cParentNo=cGroupTypeNo, cPath
		from dbo.T_GroupType_GoodsType
	) x,(select cPath from T_GroupType where PATINDEX('%,'+cGroupTypeNo+',%',@GroupTypeNo)>0 or @GroupTypeNo='--') y
	where PATINDEX(y.cPath+'%',x.cPath)=1 
	)
	and isnull(bDeled,0)=0 and isnull(bStock,0)=1  and isnull(bSuspend,0)=0
	and ISNULL(bStop,0)=0   
	order by cGoodsTypeno
	delete from #temp_Goods
	insert into #temp_Goods(cGoodsNo) select  cGoodsNo from #temp_GoodsList
	/*
	select cStoreNo,cGoodsNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename
	from #temp_GoodsList
	*/
	if (select object_id('tempdb..#temp_GoodsList'))is not null
	drop table #temp_GoodsList

end




/*
select * from T_GroupType
*/
GO
