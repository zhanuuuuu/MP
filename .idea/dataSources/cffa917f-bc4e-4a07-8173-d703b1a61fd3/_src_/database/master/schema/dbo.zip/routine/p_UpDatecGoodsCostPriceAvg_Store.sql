
/*

declare @return int
exec p_cGoodsCostPriceAvg  '2016-07-06',@return output
select @return
 

*/
CREATE proc [dbo].[p_UpDatecGoodsCostPriceAvg_Store]
@cStoreNo varchar(32),
@SheetDate datetime,
@cGoodsNo varchar(32),
@fAvgPrice money,
@cOpertionNo varchar(32),
@cOpertionName varchar(64),
@return int output
as 
begin
	declare @Y1 varchar(8)
	declare @M1  varchar(8)
	declare @Day1  varchar(8)
	set @M1=MONTH(@SheetDate)
	set @Day1=day(@SheetDate)
	set @Y1=YEAR(@SheetDate)
	if LEN(@M1)=1 
	begin
	   set @M1='0'+@M1
	end
	if LEN(@Day1)=1 
	begin
	   set @Day1='0'+@Day1
	end
	declare @MMDD varchar(8)
	set @MMDD=@M1+@Day1
	
	declare @Y2 varchar(8)
	declare @M2  varchar(8)
	declare @Day2  varchar(8)
	set @M2=MONTH(@SheetDate-1)
	set @Day2=day(@SheetDate-1)
	set @Y2=YEAR(@SheetDate-1)
	if LEN(@M2)=1 
	begin
	   set @M2='0'+@M2
	end
	if LEN(@Day2)=1 
	begin
	   set @Day2='0'+@Day2
	end
	declare @MMDD2 varchar(8)
	set @MMDD2=@M2+@Day2
	
    declare @PosWhName varchar(32)
	set @PosWhName=(select top  1 Pos_WH_Form from t_WareHouse where cStoreNo=@cStoreNo and isnull(Pos_WH_Form,'')<>'')
    begin try
    begin tran 
              update t_cGoodsCostException set fOutPrice=@fAvgPrice,bShenhe=1,
	          cOpertionNo=@cOpertionNo,cOpertionName=@cOpertionName,
	          Beizhu=Beizhu+' 处理前发出成本:'+CAST(fAvgPrice as varchar)+' 处理后发出成本：'+CAST(@fAvgPrice as varchar) 
	          where cStoreNo=@cStoreNo and dDate=@SheetDate and cGoodsNo=@cGoodsNo
	          
			  exec('  
				update b set 
				b.fAvgIn_'+@MMDD+'='+@fAvgPrice+' 		 
				from '+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+'  b
				where b.cYear='''+@Y1+''' and  cStoreNo='''+@cStoreNo+'''  and b.cGoodsNo='''+@cGoodsNo+'''	 
	          ')
      
      if @Y2=@Y1 
      begin
		  if @M2=@M1
		  begin
		      --- 获取每日成本
		      /*
		        @MMDD  为当天数据字段
		        @MMDD2 为前一天数据字段
		        
		        t_cGoodsCostException  成本异常表
		      */
	           
		      exec('
		          -- 成本
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=isnull(a.fMoneyIn_'+@MMDD2+',0)+(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+''' and a.cYear=b.cYear and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  -- 报损 	
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=isnull(a.fMoneyIn_'+@MMDD2+',0)+(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+''' and a.cYear=b.cYear and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  -- 出库	
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=isnull(a.fMoneyIn_'+@MMDD2+',0)+(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+'''  and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+''' and a.cYear=b.cYear and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  	
			      -- 返厂	
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=isnull(a.fMoneyIn_'+@MMDD2+',0)+(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cYear=b.cYear and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  --调拨出
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=isnull(a.fMoneyIn_'+@MMDD2+',0)+(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
	 
				  --剩余 
				  
	              --数量当天减前一天*移动加权成本+前一天成本
	              update a set 
				  a.fMoney_'+@MMDD+'=(isnull(a.fQty_'+@MMDD+',0)-isnull(a.fQty_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'+isnull(a.fMoney_'+@MMDD2+',0)
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  --入库			 
				  
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'+isnull(a.fMoneyIn_'+@MMDD2+',0)
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  --报益
			 
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'+isnull(a.fMoneyIn_'+@MMDD2+',0)
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  --调拨入			 
				  
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'+isnull(a.fMoneyIn_'+@MMDD2+',0)
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				  --客退
		 
				  
				  update a set 
				  a.fMoneyIn_'+@MMDD+'=(isnull(a.fQtyIn_'+@MMDD+',0)-isnull(a.fQtyIn_'+@MMDD2+',0))*b.fAvgIn_'+@MMDD+'+isnull(a.fMoneyIn_'+@MMDD2+',0)
				  from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
				  where a.cYear='''+@Y1+''' and a.cYear=b.cYear and a.cStoreNo=b.cStoreNo and a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO
				  and a.cGoodsNo='''+@cGoodsNo+'''	 
				  
				') 
						      
		  end else
		  begin		   
		     
		  
		      exec(' 
		            if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost1''))is not null  drop table #temp_Wh_Goods_endCost1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_endCost1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''	 
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost2''))is not null  drop table #temp_Wh_Goods_endCost2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_endCost2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_endCost
					from #temp_Wh_Goods_endCost2 a left join #temp_Wh_Goods_endCost1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostPrice''))is not null  drop table #temp_Wh_Goods_endCostPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_endCostPrice
					from #temp_Wh_Goods_endCost a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+'''  and a.cGoodsno=b.cGoodsno  and  a.cGoodsNo='''+@cGoodsNo+'''
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a,#temp_Wh_Goods_endCostPrice b
				   where a.cYear='''+@Y1+'''  and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   and  a.cGoodsNo='''+@cGoodsNo+''' and a.cStoreNo='''+@cStoreNo+'''
				   
				   ---报损
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss1''))is not null  drop table #temp_Wh_Goods_end_Loss1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Loss1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss2''))is not null  drop table #temp_Wh_Goods_end_Loss2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Loss2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss''))is not null  drop table #temp_Wh_Goods_end_Loss
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Loss
					from #temp_Wh_Goods_end_Loss2 a left join #temp_Wh_Goods_end_Loss1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_LossPrice''))is not null  drop table #temp_Wh_Goods_end_LossPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_LossPrice
					from #temp_Wh_Goods_end_Loss a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
				 
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a,#temp_Wh_Goods_end_LossPrice b
				   where a.cYear='''+@Y1+'''  and a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				   
				   
				  ---出库
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out1''))is not null  drop table #temp_Wh_Goods_end_Out1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Out1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out2''))is not null  drop table #temp_Wh_Goods_end_Out2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Out2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out''))is not null  drop table #temp_Wh_Goods_end_Out
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Out
					from #temp_Wh_Goods_end_Out2 a left join #temp_Wh_Goods_end_Out1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_OutPrice''))is not null  drop table #temp_Wh_Goods_end_OutPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_OutPrice
					from #temp_Wh_Goods_end_Out a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a,#temp_Wh_Goods_end_OutPrice b
				   where a.cYear='''+@Y1+'''  and a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   ---返厂
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd1''))is not null  drop table #temp_Wh_Goods_end_Rbd1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Rbd1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd2''))is not null  drop table #temp_Wh_Goods_end_Rbd2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Rbd2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd''))is not null  drop table #temp_Wh_Goods_end_Rbd
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Rbd
					from #temp_Wh_Goods_end_Rbd2 a left join #temp_Wh_Goods_end_Rbd1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_RbdPrice''))is not null  drop table #temp_Wh_Goods_end_RbdPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_RbdPrice
					from #temp_Wh_Goods_end_Rbd a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a,#temp_Wh_Goods_end_RbdPrice b
				   where a.cYear='''+@Y1+'''  and a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   --调拨出
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr1''))is not null  drop table #temp_Wh_Goods_end_Tfr1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Tfr1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr2''))is not null  drop table #temp_Wh_Goods_end_Tfr2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Tfr2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr''))is not null  drop table #temp_Wh_Goods_end_Tfr
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Tfr
					from #temp_Wh_Goods_end_Tfr2 a left join #temp_Wh_Goods_end_Tfr1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrPrice''))is not null  drop table #temp_Wh_Goods_end_TfrPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_TfrPrice
					from #temp_Wh_Goods_end_Tfr a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+''' and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a,#temp_Wh_Goods_end_TfrPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				 
				   
				  --剩余
			 
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left1''))is not null  drop table #temp_Wh_Goods_end_Left1
					select cGoodsno,cSupNo,fQty=sum(fQty_'+@MMDD2+'),fMoney=sum(fMoney_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Left1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''  
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left2''))is not null  drop table #temp_Wh_Goods_end_Left2
					select cGoodsno,cSupNo,fQty=sum(fQty_'+@MMDD+'),fMoney=sum(fMoney_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Left2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left''))is not null  drop table #temp_Wh_Goods_end_Left
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Left
					from #temp_Wh_Goods_end_Left2 a left join #temp_Wh_Goods_end_Left1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_LeftPrice''))is not null  drop table #temp_Wh_Goods_end_LeftPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_LeftPrice
					from #temp_Wh_Goods_end_Left a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoney_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' a,#temp_Wh_Goods_end_LeftPrice b
				   where a.cYear='''+@Y1+'''   and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				 --入库
		 
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In1''))is not null  drop table #temp_Wh_Goods_end_In1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_In1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In2''))is not null  drop table #temp_Wh_Goods_end_In2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_In2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In''))is not null  drop table #temp_Wh_Goods_end_In
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_In
					from #temp_Wh_Goods_end_In2 a left join #temp_Wh_Goods_end_In1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_InPrice''))is not null  drop table #temp_Wh_Goods_end_InPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_InPrice
					from #temp_Wh_Goods_end_In a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' a,#temp_Wh_Goods_end_InPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				  --报益
				 
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion1''))is not null  drop table #temp_Wh_Goods_end_Effusion1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Effusion1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+''' 
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion2''))is not null  drop table #temp_Wh_Goods_end_Effusion2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Effusion2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion''))is not null  drop table #temp_Wh_Goods_end_Effusion
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Effusion
					from #temp_Wh_Goods_end_Effusion2 a left join #temp_Wh_Goods_end_Effusion1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_EffusionPrice''))is not null  drop table #temp_Wh_Goods_end_EffusionPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_EffusionPrice
					from #temp_Wh_Goods_end_Effusion a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a,#temp_Wh_Goods_end_EffusionPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				    --调拨入
				    
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn1''))is not null  drop table #temp_Wh_Goods_end_TfrIn1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_TfrIn1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn2''))is not null  drop table #temp_Wh_Goods_end_TfrIn2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_TfrIn2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn''))is not null  drop table #temp_Wh_Goods_end_TfrIn
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_TfrIn
					from #temp_Wh_Goods_end_TfrIn2 a left join #temp_Wh_Goods_end_TfrIn1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrInPrice''))is not null  drop table #temp_Wh_Goods_end_TfrInPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_TfrInPrice
					from #temp_Wh_Goods_end_TfrIn a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a,#temp_Wh_Goods_end_TfrInPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				    --客退
			 
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return1''))is not null  drop table #temp_Wh_Goods_end_Return1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Return1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M2+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return2''))is not null  drop table #temp_Wh_Goods_end_Return2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Return2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return''))is not null  drop table #temp_Wh_Goods_end_Return
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Return
					from #temp_Wh_Goods_end_Return2 a left join #temp_Wh_Goods_end_Return1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_ReturnPrice''))is not null  drop table #temp_Wh_Goods_end_ReturnPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_ReturnPrice
					from #temp_Wh_Goods_end_Return a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a,#temp_Wh_Goods_end_ReturnPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				     
				') 
		  end
	  end else
	  begin
	    
	
	     exec('
		          if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost1''))is not null  drop table #temp_Wh_Goods_endCost1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_endCost1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost2''))is not null  drop table #temp_Wh_Goods_endCost2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_endCost2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_endCost
					from #temp_Wh_Goods_endCost2 a left join #temp_Wh_Goods_endCost1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostPrice''))is not null  drop table #temp_Wh_Goods_endCostPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_endCostPrice
					from #temp_Wh_Goods_endCost a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a,#temp_Wh_Goods_endCostPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO
				   and a.cSupNo=b.cSupNo
				   
				   
				    ---报损
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss1''))is not null  drop table #temp_Wh_Goods_end_Loss1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Loss1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss2''))is not null  drop table #temp_Wh_Goods_end_Loss2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Loss2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Loss''))is not null  drop table #temp_Wh_Goods_end_Loss
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Loss
					from #temp_Wh_Goods_end_Loss2 a left join #temp_Wh_Goods_end_Loss1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_LossPrice''))is not null  drop table #temp_Wh_Goods_end_LossPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_LossPrice
					from #temp_Wh_Goods_end_Loss a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a,#temp_Wh_Goods_end_LossPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				  ---出库
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out1''))is not null  drop table #temp_Wh_Goods_end_Out1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Out1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out2''))is not null  drop table #temp_Wh_Goods_end_Out2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Out2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Out''))is not null  drop table #temp_Wh_Goods_end_Out
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Out
					from #temp_Wh_Goods_end_Out2 a left join #temp_Wh_Goods_end_Out1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_OutPrice''))is not null  drop table #temp_Wh_Goods_end_OutPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_OutPrice
					from #temp_Wh_Goods_end_Out a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a,#temp_Wh_Goods_endCostPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   ---返厂
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd1''))is not null  drop table #temp_Wh_Goods_end_Rbd1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Rbd1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd2''))is not null  drop table #temp_Wh_Goods_end_Rbd2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Rbd2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Rbd''))is not null  drop table #temp_Wh_Goods_end_Rbd
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Rbd
					from #temp_Wh_Goods_end_Rbd2 a left join #temp_Wh_Goods_end_Rbd1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_RbdPrice''))is not null  drop table #temp_Wh_Goods_end_RbdPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_RbdPrice
					from #temp_Wh_Goods_end_Rbd a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a,#temp_Wh_Goods_end_RbdPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   --调拨出
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr1''))is not null  drop table #temp_Wh_Goods_end_Tfr1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Tfr1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr2''))is not null  drop table #temp_Wh_Goods_end_Tfr2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Tfr2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Tfr''))is not null  drop table #temp_Wh_Goods_end_Tfr
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Tfr
					from #temp_Wh_Goods_end_Tfr2 a left join #temp_Wh_Goods_end_Tfr1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrPrice''))is not null  drop table #temp_Wh_Goods_end_TfrPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_TfrPrice
					from #temp_Wh_Goods_end_Tfr a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a,#temp_Wh_Goods_end_TfrPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				 
				  
				    --剩余
			 
				  
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left1''))is not null  drop table #temp_Wh_Goods_end_Left1
					select cGoodsno,cSupNo,fQty=sum(fQty_'+@MMDD2+'),fMoney=sum(fMoney_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Left1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left2''))is not null  drop table #temp_Wh_Goods_end_Left2
					select cGoodsno,cSupNo,fQty=sum(fQty_'+@MMDD+'),fMoney=sum(fMoney_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Left2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Left''))is not null  drop table #temp_Wh_Goods_end_Left
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Left
					from #temp_Wh_Goods_end_Left2 a left join #temp_Wh_Goods_end_Left1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_LeftPrice''))is not null  drop table #temp_Wh_Goods_end_LeftPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_LeftPrice
					from #temp_Wh_Goods_end_Left a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoney_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' a,#temp_Wh_Goods_end_LeftPrice b
				   where a.cYear='''+@Y1+'''   and  a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				   --入库
				   
				 
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In1''))is not null  drop table #temp_Wh_Goods_end_In1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_In1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In2''))is not null  drop table #temp_Wh_Goods_end_In2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_In2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_In''))is not null  drop table #temp_Wh_Goods_end_In
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_In
					from #temp_Wh_Goods_end_In2 a left join #temp_Wh_Goods_end_In1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_InPrice''))is not null  drop table #temp_Wh_Goods_end_InPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_InPrice
					from #temp_Wh_Goods_end_In a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' a,#temp_Wh_Goods_end_InPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+'''  and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				  --报益
				    
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion1''))is not null  drop table #temp_Wh_Goods_end_Effusion1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Effusion1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+''' 
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion2''))is not null  drop table #temp_Wh_Goods_end_Effusion2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Effusion2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Effusion''))is not null  drop table #temp_Wh_Goods_end_Effusion
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Effusion
					from #temp_Wh_Goods_end_Effusion2 a left join #temp_Wh_Goods_end_Effusion1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_EffusionPrice''))is not null  drop table #temp_Wh_Goods_end_EffusionPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_EffusionPrice
					from #temp_Wh_Goods_end_Effusion a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a,#temp_Wh_Goods_end_EffusionPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				   
				    --调拨入 
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn1''))is not null  drop table #temp_Wh_Goods_end_TfrIn1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_TfrIn1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn2''))is not null  drop table #temp_Wh_Goods_end_TfrIn2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_TfrIn2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''   and  cStoreNo='''+@cStoreNo+''' and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrIn''))is not null  drop table #temp_Wh_Goods_end_TfrIn
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_TfrIn
					from #temp_Wh_Goods_end_TfrIn2 a left join #temp_Wh_Goods_end_TfrIn1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_TfrInPrice''))is not null  drop table #temp_Wh_Goods_end_TfrInPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_TfrInPrice
					from #temp_Wh_Goods_end_TfrIn a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a,#temp_Wh_Goods_end_TfrInPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				    --客退
				    
				 
				  if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return1''))is not null  drop table #temp_Wh_Goods_end_Return1
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD2+'),fMoney=sum(fMoneyIn_'+@MMDD2+') 			 
					into #temp_Wh_Goods_end_Return1
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M2+'
					with (nolock) 
					where cyear='''+@Y2+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					 
					
				    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return2''))is not null  drop table #temp_Wh_Goods_end_Return2
					select cGoodsno,cSupNo,fQty=sum(fQtyIn_'+@MMDD+'),fMoney=sum(fMoneyIn_'+@MMDD+') 			 
					into #temp_Wh_Goods_end_Return2
					from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+'
					with (nolock) 
					where cyear='''+@Y1+'''  and  cStoreNo='''+@cStoreNo+'''  and  cGoodsNo='''+@cGoodsNo+'''
					group by cGoodsno,cSupNo
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_Return''))is not null  drop table #temp_Wh_Goods_end_Return
					select a.cGoodsno,a.cSupNo,fQty=isnull(a.fQty,0)-isnull(b.fQty,0),fMoney=isnull(b.fMoney,0)			 
					into #temp_Wh_Goods_end_Return
					from #temp_Wh_Goods_end_Return2 a left join #temp_Wh_Goods_end_Return1 b
					on a.cGoodsno=b.cGoodsno and a.cSupNo=b.cSupNo
					
					
					if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end_ReturnPrice''))is not null  drop table #temp_Wh_Goods_end_ReturnPrice
					select a.cGoodsno,a.cSupNo,fMoney=isnull(a.fMoney,0)+a.fQty*b.fAvgIn_'+@MMDD+'			 
					into #temp_Wh_Goods_end_ReturnPrice
					from #temp_Wh_Goods_end_Return a,'+@PosWhName+'.dbo.t_WH_Form_Log_CostPrice_'+@M1+' b
					where b.cYear='''+@Y1+'''  and  b.cStoreNo='''+@cStoreNo+''' and a.cGoodsno=b.cGoodsno
		          
		      
				   update a set 
				   a.fMoneyIn_'+@MMDD+'=isnull(b.fMoney,0)
				   from '+@PosWhName+'.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a,#temp_Wh_Goods_end_ReturnPrice b
				   where a.cYear='''+@Y1+'''  and  a.cStoreNo='''+@cStoreNo+''' and a.cGoodsNO=b.cGoodsNO and a.cSupNo=b.cSupNo
				   
				  
				') 	
	  end
		--- 按每日成本 修改成本金额
		commit tran  
	   set @return=1
     end try
	 begin catch
	   rollback 
	   set @return=0
	 end catch
end
GO
