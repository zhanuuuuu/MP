
create  function dbo.getWeekDayStr
(@time datetime,@iswitch int)
returns varchar(6)
as
begin
   declare @str varchar(6)
    if @iswitch=0
        begin
             select @str= case when datepart(dw,@time)=1 then '周日'
                     when datepart(dw,@time)=7 then '周六'
                     when datepart(dw,@time)=6 then '周五'
                     when datepart(dw,@time)=5 then '周四'
                     when datepart(dw,@time)=4 then '周三'
                     when datepart(dw,@time)=3 then '周二'
                     else '周一'
                  end 
       end  
    else
      begin
          select @str=case when datepart(dw,@time)=1 then '星期日'
                     when datepart(dw,@time)=7 then '星期六'
                     when datepart(dw,@time)=6 then '星期五'
                     when datepart(dw,@time)=5 then '星期四'
                     when datepart(dw,@time)=4 then '星期三'
                     when datepart(dw,@time)=3 then '星期二'
                     else '星期一'
                  end 
      end
 return @str
end

GO
