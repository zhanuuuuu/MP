 /*
 #tmpSupList
if (select object_id('tempdb..#tmpSupList'))is not null drop table #tmpSupList
		create table #tmpSupList(supno varchar(32))
		insert into #tmpSupList(supno)select distinct csupno from t_Goods
   p_NoSaleGoodsSupStock '2012-10-01','2012-10-20'
   
   select * from t_GoodsType where cGoodsTypeno like '4%'
 */
 create proc p_NoSaleGoodsSupStock
 @dDateBgn datetime,
 @dDateEnd datetime
 as
 begin 
		
		if (select object_id('tempdb..#temp_Goods'))is not null
		drop table #temp_Goods
-- 取相应类别下的商品。。。 				
 select cGoodsNo into #temp_Goods from t_goods  
 where cSupNo in (select supno from #tmpSupList)
 and ISNULL(bStorage,0)=1



----- 获取库存
    select distinct b.cGoodsNo,b.cGoodsName,
   b.cUnit,b.cSpec
    into #tmpSaleGoodsUnion
    from wh_InWarehouse a left join wh_InWarehouseDetail b
    on a.cSheetNo=b.cSheetNo
   -- where a.dDate <=@dDateEnd
   where a.dDate between @dDateBgn and @dDateEnd
      and b.cGoodsNo in (select cGoodsNo from #temp_Goods)
---- 入库 箱码 转 单品
if (select OBJECT_ID('tempdb..#tmpSaleGoodsUnion1'))is not null drop table #tmpSaleGoodsUnion1
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #tmpSaleGoodsUnion1
from t_goods a, #tmpSaleGoodsUnion b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1

--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#tmpSaleGoodsUnion0'))is not null drop table #tmpSaleGoodsUnion0
select distinct cGoodsNo into #tmpSaleGoodsUnion0 
from #tmpSaleGoodsUnion1 a
where ISNULL(a.bIsPack,0)=0
union all
select cGoodsNo_MinPackage 
from #tmpSaleGoodsUnion1
where ISNULL(bIsPack,0)=1

if(select object_id('tempdb..#temp_SaledateBaseForKuCun')) is not null 
drop table #temp_SaledateBaseForKuCun
create table #temp_SaledateBaseForKuCun(cGoodsNo varchar(32),cGoodsTypeno varchar(32),EndQty money,XsQty money)

 declare @cWhNo varchar(32)
 set @cWhNo=(select top 1 cWhNo from t_WareHouse)


declare @bJiaGong bit
exec [p_NoSaleGoodsTypeStock_byGoodsType] @dDateBgn,@dDateEnd,@cWhNo,@bJiaGong

     select distinct a.cGoodsNo,c.EndQty,c.xsQty
    into #tmpSaleGoods
    from #tmpSaleGoodsUnion0 a, #temp_SaledateBaseForKuCun c
    where a.cGoodsNo=c.cGoodsNo and isnull(c.xsQty,0)=0
    

   select a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,
   b.cGoodsTypeno,cGoodsTypename,fQty_CurWh=isnull(a.EndQty,0),xsQty=isnull(a.xsQty,0),cSupplierNo=b.cSupNo,cSupplier=b.cSupName
   into #temp_goodsNoSale
    from #tmpSaleGoods a,t_Goods b
    where a.cGoodsNo=b.cGoodsNo


SELECT ROW_NUMBER() OVER(order by fQty_CurWh desc) AS pos,* FROM #temp_goodsNoSale

end
 GO
