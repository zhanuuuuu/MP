/*
1：订单类型，如 2、手工补货单、3、自动补货单等 【iAuto】
2：订单生成日期区间 [dDate]
3：订单完结日期区间 [EndTime]
4：订单所属设备名称 [posname]
5：订单所属设备所在地区 [cAddRess]
6：订单金额区间       [fmoney]
7：订单商品件数区间 [先不考虑]
8：订单状态，等待送货等等 其他条件  [先不考虑]

*/
CREATE proc p_GetOrderList
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@strWhere varchar(8000)
as
begin
  if @strWhere='' 
  BEGIN
     set @strWhere='1=1'
  end
   
  exec('
	select csheetNo as orderID,iAuto as Type,dDate as creationTime,endTime ,a.fMoney as money,b.posname,
	iState=''状态''
	from WH_BhApply a,t_posstation b
	where a.cStoreNo='''+@Merchantid+''' and a.cStoreNo=b.cStoreNo and 
	a.posid=b.posid  and  '+@strWhere+'
	order by dDate
  ')
    
end

GO
