/*
exec p_pratition_SaleSheetDay '2006'
exec p_pratition_SaleSheetDay '2007'
exec p_pratition_SaleSheetDay '2009'
*/
/*
创建分区时间
*/
create proc p_pratition_SaleSheetDay
@setDatetime char(4)
as
begin
	alter partition scheme SaleSheetDayPartScheme 
	next used [SaleSheetDay_01]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-01-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_02]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-02-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_03]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-03-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_04]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-04-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_05]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-05-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_06]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-06-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_07]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-07-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_08]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-08-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_09]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-09-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_10]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-10-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_11]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-11-01')
	alter partition scheme SaleSheetDayPartScheme
	next used [SaleSheetDay_12]
	alter partition function SaleSheetDayPartFun()
	split range(@setDatetime+'-12-01')

end


GO
