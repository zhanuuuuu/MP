

CREATE       procedure [dbo].[P_Z_getRdbWareHouse_wind_MVC_Pro]
  @cSupplierNo varchar(16),
  @EndDate datetime, 
	@station varchar(64),
  @cTelMinDate varchar(32),@cStoreNo varchar(32)
as
begin
	 declare @strtmp varchar(32)
	 set @strtmp=dbo.getDayStr(@EndDate)
   exec('
   if(select object_id(''U_key.dbo.TempRbdWareHouse_'+@cSupplierNo+'''))is not null
   drop table U_key.dbo.TempRbdWareHouse_'+@cSupplierNo+'
    select cStation='''+@station+''',a.cStoreNo,a.cStoreName,a.cSheetno,a.cSupplierNo,a.cSupplier,
          a.cOperatorNo,a.cOperator,
          a.cExaminerNo,a.cExaminer,
          a.cWhNo,a.cWh,
          a.fMoney,
          dDate=dbo.getDayStr(a.dDate),

       bFoot=case when a.bExamin=1 and  isnull(a.bBalance,0)=0 then 1
               else 0
           end,
        
            bExamin=case when isnull(a.bExamin,0)=1 then 1
                        else 0
                   end,
        bBalance=case when a.bBalance=1 then 1
                   else 0
                   end,
        cDetail=''返厂单''
                 
    into U_key.dbo.TempRbdWareHouse_'+@cSupplierNo+'
    from wh_RbdWareHouse a,t_Supplier b
    where  a.cSupplierNo=b.cSupNo and b.cSupNo='''+@cSupplierNo+''' 
         and (isnull(a.bBalance,0)<>1)
         and isnull(a.bReason_FinanceCheck,0)=1
         and a.cStoreNo='''+@cStoreNo+'''
         and ISNULL(a.bExamin,0)=1 
     
		')
end


GO
