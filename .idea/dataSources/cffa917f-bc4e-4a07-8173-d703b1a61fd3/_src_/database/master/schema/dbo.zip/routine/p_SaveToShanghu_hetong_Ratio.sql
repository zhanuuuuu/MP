

CREATE   procedure [dbo].[p_SaveToShanghu_hetong_Ratio]
@guizuno varchar(32),
@cTermID varchar(32)
as
begin
  if (select OBJECT_ID('tempdb..#Shanghu_hetong_Ratio'))is not null
drop table #Shanghu_hetong_Ratio
create table #Shanghu_hetong_Ratio(guizu varchar(64),guizuno varchar(32),fMoney money,fRatio money)

exec('
  insert into #Shanghu_hetong_Ratio(guizu,guizuno,fMoney,fRatio)
  select guizu,guizuno,fMoney,fRatio from U_key.dbo.Shanghu_hetong_Ratio'+@cTermID+'
')

  declare @minValue money
  declare @iRec money
  declare @guizu varchar(64)
  set @guizu=(select top 1 guizu from #Shanghu_hetong_Ratio where guizuno=@guizuno)
  select a.guizuno,a.guizu,fMoney1=a.fMoney,fMoney2=isnull(b.fMoney,999999999),a.fRatio
  into #t0
  from #Shanghu_hetong_Ratio a
  left join #Shanghu_hetong_Ratio b
  on b.guizuno=a.guizuno and a.fMoney<b.fMoney
  where a.guizuno=@guizuno

  select guizuno,guizu,fMoney1,fMoney2=min(fMoney2),fRatio
  into #t1
  from #t0
  group by guizuno,guizu,fMoney1,fRatio
  
  set @iRec=(select count(guizuno) from #t1)
  set @minValue=(select min(fMoney1) from #t1)
  declare @minRatio money
  set @minRatio=(select top 1 fRatio from #t1 where fMoney1=@minValue)
  if @minValue>0
  begin
		insert into #t1(guizuno,guizu,fMoney1,fMoney2,fRatio)
    values (@guizuno,@guizu,0,@minValue,@minRatio)
	end 
/*
  insert into #t1 (guizuno,guizu,fMoney1,fMoney2,fRatio)
  select top 1 guizuno,guizu,-999999999,@minValue,fRatio 
  from #t1 where fMoney1=@minValue
*/
  delete from t_Supplier_Contract_Ratio where guizuno=@guizuno
  insert into t_Supplier_Contract_Ratio (guizuno,guizu,fMoney1,fMoney2,fRatio)
  select guizuno,guizu,fMoney1,fMoney2,fRatio from #t1
  
  

end


GO
