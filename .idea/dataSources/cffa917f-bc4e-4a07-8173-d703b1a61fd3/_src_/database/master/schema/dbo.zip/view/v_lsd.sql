
CREATE  view v_lsd
as
  select lsdno=a.cSaleSheetno,yingshou=sum(a.fLastSettle),mlt=0,
				shishou=sum(a.fLastSettle),xsyno=a.cOperatorno,xsy=a.cOperatorName,
				zdriqi=a.dSaleDate
	from t_SaleSheet a
	group by a.cSaleSheetno,a.cOperatorno,a.cOperatorName,a.dSaleDate


GO
