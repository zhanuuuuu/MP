
/*
 储值卡601112
	p_MoneycardCust_qry20130219 '601188'
*/
create procedure [dbo].[p_MoneycardCust_qry1]
@cardno varchar(32)
as 
begin
/*
	if dbo.trim(@cardno)<>''
  begin
*/
-------------
 
		select  a.sheetno,jstime=max(a.jstime),
		fLastSettle=isnull((select sum(shishou) from posmanagement.dbo.jiesuan where sheetno=a.sheetno),0),
		zdriqi=max(a.zdriqi)
		into #tempJiesuan_POS
		from posmanagement.dbo.jiesuan a
		where  a.jstype like '储值卡%' and substring(a.jstype,len('储值卡')+1,32)=@cardno
		group by a.sheetno
 
		
	 
		select a.sheetno,jstime=max(a.jstime),
		fLastSettle=isnull((select sum(shishou) from posmanagement.dbo.jiesuan where sheetno=a.sheetno),0),zdriqi=max(a.zdriqi)
		into #tempJiesuan_MP
		from supermarket.dbo.jiesuan a
		where a.jstype like '储值卡%' and substring(a.jstype,len('储值卡')+1,32)=@cardno
		group by a.sheetno
		
 -------------------
 
		select MoneycardNo=@cardno,a.dSaleDate,a.cSaleSheetno,a.cGoodsNo,a.cGoodsName,a.cBarCode,a.fQuantity,a.fPrice,
		a.fLastSettle,cSaleTime=b.jstime,a.cVipNo,cMarket='超市'
		into #tempQryResult
		from
		t_salesheetdetail a ,#tempJiesuan_POS b
		where  a.dSaleDate=b.zdriqi and  a.cSaleSheetno=b.sheetno 
      
		union all

		select MoneycardNo=@cardno,dSaleDate=a.lsriqi,cSaleSheetno=a.lsdno,cGoodsNo=a.spno,
		cGoodsName=a.mingcheng,cBarCode=a.tiaoma,fQuantity=a.shuliang,fPrice=a.danjia,
		fLastSettle=a.jine,cSaleTime=b.jstime,cVipNo=a.vipno,cMarket='商场'
		from
			(select f.lsriqi,f.lsdno,f.spno,f.mingcheng,f.tiaoma,f.shuliang,f.danjia,
			f.jine,f.lstime,g.vipno
			from
			supermarket.dbo.lsdsp f,supermarket.dbo.lsd g 
			where  substring(f.lsdno,1,14) in (select sheetno from #tempJiesuan_MP) and f.lsdno=g.lsdno 
			) a,#tempJiesuan_MP b
		where  a.lsriqi=b.zdriqi and substring(a.lsdno,1,14)=b.sheetno --a.lsdno=b.sheetno

		select MoneycardNo,dSaleDate,cSaleTime,cSaleSheetno,cGoodsNo,cGoodsName,cBarCode,fQuantity,fPrice,
		fLastSettle,cVipNo,cMarket
		from #tempQryResult
		union all
		select MoneycardNo='小计',dSaleDate=zdriqi,cSaleTime=jstime,cSaleSheetno=sheetno,cGoodsNo='ZZZZZZ',
		cGoodsName=null,cBarCode=null,fQuantity=null,fPrice=null,fLastSettle,cVipNo=null,cMarket='超市'
      from #tempJiesuan_POS
		union all
		select MoneycardNo='小计',dSaleDate=zdriqi,cSaleTime=jstime,cSaleSheetno=sheetno,cGoodsNo='ZZZZZZ',
		cGoodsName=null,cBarCode=null,fQuantity=null,fPrice=null,fLastSettle,cVipNo=null,cMarket='商场'
    from #tempJiesuan_MP
		order by MoneycardNo,cSaleTime,cSaleSheetno


end

--select * from #tempMoneycard
GO
