/*
入库单据插入成本表中
declare @i int
exec p_FIFOInWareHouse_PermitNegativeStock_chen 'IN20099044-000020',@i output
select @i
select * from dbo.wh_InWarehouseDetail where cSheetNO='IN20099044-000019' 
select * from wh_inwarehouse where baccount=0
select * from t_wh_form_log

declare @p4 int
exec p_FIFOInWareHouse_PermitNegativeStock_chen_min_wei 'IN20151019-000018',@p4 output,1
select @p4

*/
CREATE  proc [dbo].[p_FIFOInWareHouse_PermitNegativeStock_chen_min_wei]
@cSheetNo varchar(32),
@return int output,
@bPermitNegativeStock int  --(0:不允许负库存 1：允许负库存)
as
/*
declare @cSheetNo varchar(32)
declare @return int
declare @bPermitNegativeStock int
select @cSheetNo='IN20101031-000001',@return=0,@bPermitNegativeStock=1
*/
begin try
  begin tran
if (select object_id('tempdb..#tmpInWareHouse'))is not null
drop table #tmpInWareHouse
if (select object_id('tempdb..#tmpNegativeStock'))is not null
drop table #tmpNegativeStock

--入库
if (select object_id('tempdb..#tmpInWareHouse_Group'))is not null
drop table #tmpInWareHouse_Group

select a.cSheetNo,cGoodsNo_Parent=a.cGoodsNo,cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo),
a.iLineNo,b.cSupplierNo,b.cSupplier,b.dDate,
fInPrice_Parent=isnull(a.fInPrice,0),fQuantity_Parent=isnull(a.fQuantity,0),
fQty_MinPackage=isnull(c.fQty_MinPackage,1),
fInPrice=isnull(a.fInPrice,0),fInMoney=isnull(a.fInMoney,0),b.cWhNo,
fQuantity=case when c.cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo) then isnull(a.fQuantity,0)
          else isnull(a.fQuantity,0)*isnull(c.fQty_MinPackage,1)
          end,
fQty_tmpIn=cast(0 as money),
iOrder=case when c.cGoodsNo=isnull(c.cGoodsNo_minPackage,c.cGoodsNo) then 1
          else 0
          end,
销售数量0=CAST(0 as money),
销售金额0=CAST(0 as money)
into #tmpInWareHouse_Group
from wh_InWarehouseDetail a,wh_InWarehouse b,t_goods c
where a.cSheetNo=b.cSheetNo and a.cGoodsNo=c.cGoodsNo
and a.cSheetNo=@cSheetNo
and a.cGoodsNo in(select cGoodsNO from t_goods where isnull(bStorage,0)=1)  
order by a.iLineNo
/*包装转化*/

update a 
set a.cGoodsNo_Parent=b.cGoodsNo_minPackage,
fInPrice_Parent=case when isnull(b.fQty_minPackage,1)=0 then 1 else fInPrice_Parent/isnull(b.fQty_minPackage,1) end,
fQuantity_Parent=fQuantity_Parent*isnull(b.fQty_minPackage,1),
fQty_MinPackage=0,iOrder=1
from #tmpInWareHouse_Group a,t_goods b
where a.cGoodsNo=b.cGoodsNo_minPackage and a.cGoodsNo_Parent<>a.cGoodsNo

/*---------2015-01-18---------*/
select cSheetNo,cGoodsNo_Parent,cGoodsNo,iLineNo=CAST(1 as int),cSupplierNo,cSupplier,dDate,
fInPrice_Parent=SUM(fInMoney)/SUM(fQuantity_Parent),fQuantity_Parent=SUM(fQuantity_Parent),
fQty_MinPackage,fInPrice=SUM(fInMoney)/SUM(fQuantity),fInMoney=SUM(fInMoney),cWhNo,
fQuantity=SUM(fQuantity),fQty_tmpIn,iOrder,
销售数量0=CAST(0 as money),
销售金额0=CAST(0 as money)
into #tmpInWareHouse
from #tmpInWareHouse_Group 
group by cSheetNo,cGoodsNo_Parent,cGoodsNo,cSupplierNo,cSupplier,dDate,
fQty_MinPackage,cWhNo,fQty_tmpIn,iOrder,销售数量0,销售金额0

if (select object_id('tempdb..#tmpInWareHouse_topLine'))is not null
drop table #tmpInWareHouse_topLine
select top 1 cSheetNo,cGoodsNo,iLineNo into #tmpInWareHouse_topLine from #tmpInWareHouse_Group
where ISNULL(fInPrice,0)<>0

update a set a.iLineNo=b.iLineNo
from #tmpInWareHouse a,#tmpInWareHouse_topLine b
where a.cSheetno=b.cSheetNo and a.cGoodsNo=b.cSheetNo
/*---------------2015-01-18----------------*/

update #tmpInWareHouse
set finPrice=fInMoney/(fquantity*1.00)
where ISNULL(fquantity,0)<>0


--入库单商品负库存情况
select distinct a.cGoodsNo,a.iSerNo,a.cWhNo,fQtyLeft=a.fQty_Out-a.fQty_in,a.fQty_Left,
iOrder=case when ISNULL(a.cGoodsNo_Parent,a.cGoodsNO)=a.cGoodsNO then 1
        else 0 end,
 a.销售数量0,a.销售金额0,
 --Xsmoney=case when ISNULL(a.销售金额0,0)>0 then a.销售金额0-(a.销售金额0/a.销售数量0)*a.fQty_In else 0 end,
 --Xsfqty=a.销售数量0-a.fQty_In  
 Xsmoney=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then a.销售金额0-(a.销售金额0/a.销售数量0)*(a.fQty_in) else 0 end,
 Xsfqty=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then a.销售数量0-a.fQty_In else 0 end,iAttribute
into #tmpNegativeStock
from t_wh_form_log a,#tmpInWareHouse b
where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo
and a.fQty_Out-a.fQty_in>0


if (select object_id('tempdb..#tmpNegativeStock_Rijie'))is not null
drop table #tmpNegativeStock_Rijie

select cGoodsNo,iSerNo=1,cWhNo,
fQtyLeft=SUM(fQtyLeft),fQty_Left=SUM(fQty_Left),iOrder,
销售数量0=SUM(销售数量0),销售金额0=SUM(销售金额0),Xsmoney=SUM(Xsmoney),Xsfqty=SUM(Xsfqty)
into #tmpNegativeStock_Rijie
from #tmpNegativeStock
where isnull(iAttribute,0)=10
group by cGoodsNo,cWhNo,iOrder

/**********************以下2015-07-29调整***************************/
  --判断游标是否存在
if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='NegativeInWh_Rijie')
begin
  close NegativeInWh_Rijie
  deallocate NegativeInWh_Rijie
end 

declare  NegativeInWh_Rijie cursor
for
select  cGoodsNo,iSerNo,cWhNo,fQtyLeft,销售数量0,销售金额0,Xsmoney,Xsfqty
from #tmpNegativeStock_Rijie
order by iOrder,iserNo

open NegativeInWh_Rijie

declare @CurGoodsNo_Rijie varchar(32)
declare @CurSerno_Rijie money
declare @CurWhNo_Rijie varchar(32)
declare @CurFqty_Rijie money
declare @销售数量0_Rijie money
declare @销售金额0_Rijie money
declare @Xsmoney_Rijie money
declare @Xsfqty_Rijie money
select @CurGoodsNo_Rijie='',@CurSerno_Rijie=0,@CurWhNo_Rijie='',@CurFqty_Rijie=0,@销售数量0_Rijie=0,@销售金额0_Rijie=0,@Xsmoney_Rijie=0,@Xsfqty_Rijie=0
fetch next from NegativeInWh_Rijie into @CurGoodsNo_Rijie,@CurSerno_Rijie,@CurWhNo_Rijie,@CurFqty_Rijie,@销售数量0_Rijie,@销售金额0_Rijie,@Xsmoney_Rijie,@Xsfqty_Rijie
--select @CurGoodsNo+'  '+cast(@CurSerno as varchar(10))+'   '+cast(@CurFqty as varchar(10))
while @@fetch_status=0
begin
	declare @spare_Rijie float --剩余库存 
	select @spare_Rijie=sum(fQuantity)
	from #tmpInWareHouse 
	where cGoodsNo=@CurGoodsNo_Rijie and cWhNo=@CurWhNo_Rijie
	group by cGoodsNo
	
    set @spare_Rijie=isnull(@spare_Rijie,0)
  
   if(@spare_Rijie>=@CurFqty_Rijie) 
   begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
		update a 
		set a.fQty_tmpIn=ISNULL(a.fQty_tmpIn,0)+
		case when 
			( select @CurFqty_Rijie-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <=a.iLineNo and cWhNo=@CurWhNo_Rijie
			)>=0 
		then a.fQuantity
		else 
			case when 
				(select @CurFqty_Rijie-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <a.iLineNo and cWhNo=@CurWhNo_Rijie
				)<0 then 0 
			else 
			   (select @CurFqty_Rijie-isnull(sum(fQuantity),0)
				from #tmpInWareHouse 
				where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <a.iLineNo  and cWhNo=@CurWhNo_Rijie
               ) 
			end 
        end,
        a.销售数量0=isnull(a.销售数量0,0)+
        case when 
			( select @CurFqty_Rijie-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <=a.iLineNo and cWhNo=@CurWhNo_Rijie
			)>=0 
		then @Xsfqty_Rijie
		else 
			case when 
				(select @CurFqty_Rijie-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <a.iLineNo and cWhNo=@CurWhNo_Rijie
				)<0 then 0 
			else 
			    @Xsfqty_Rijie
			   
			end 
        end,
        a.销售金额0=isnull(a.销售金额0,0)+
        case when 
			( select @CurFqty_Rijie-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <=a.iLineNo and cWhNo=@CurWhNo_Rijie
			)>=0 
		then @Xsmoney_Rijie
		else 
			case when 
				(select @CurFqty_Rijie-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo_Rijie and iLineNo <a.iLineNo and cWhNo=@CurWhNo_Rijie
				)<0 then 0 
			else 
			    @Xsmoney_Rijie			    
			end 
        end 
		from #tmpInWareHouse a 
		where a.cGoodsNo=@CurGoodsNo_Rijie and cWhNo=@CurWhNo_Rijie
    end else
    begin
	   --负库存 
	  declare @MaxRow_Rijie int
	  declare @tmpLeafSum_Rijie money
	  select @MaxRow_Rijie=max(iLineNo) from #tmpInWareHouse where cGoodsNo=@CurGoodsNo_Rijie and cWhNo=@CurWhNo_Rijie
	     
          update a
		  set a.fQty_tmpIn=isnull(a.fQty_tmpIn,0)+@CurFqty_Rijie-(
                                      select isnull(sum(fQuantity),0) 
                                      from #tmpInWareHouse 
                                      where cGoodsNo=@CurGoodsNo_Rijie and iLineNo<@MaxRow_Rijie and cWhNo=@CurWhNo_Rijie
                                     ),
                                     a.销售数量0=isnull(a.销售数量0,0)+@Xsfqty_Rijie,
                                     a.销售金额0=isnull(a.销售金额0,0)+@Xsmoney_Rijie
		  from #tmpInWareHouse a
		  where a.cGoodsNo=@CurGoodsNo_Rijie and iLineNo=@MaxRow_Rijie and cWhNo=@CurWhNo_Rijie
		  /*2014-12-14*/
		   update #tmpInWareHouse 
		  set fQty_tmpIn=isnull(fQty_tmpIn,0)+fQuantity 
		  where cGoodsNo=@CurGoodsNo_Rijie and iLineNo<@MaxRow_Rijie and cWhNo=@CurWhNo_Rijie
		  
 
   end   
   fetch next from NegativeInWh_Rijie into @CurGoodsNo_Rijie,@CurSerno_Rijie,@CurWhNo_Rijie,@CurFqty_Rijie,@销售数量0_Rijie,@销售金额0_Rijie,@Xsmoney_Rijie,@Xsfqty_Rijie
end

close NegativeInWh_Rijie
deallocate NegativeInWh_Rijie

 
---------以上为日结补充的。----

---移除日结补充的。
---delete #tmpNegativeStock where isnull(iAttribute,0)=10

if (select object_id('tempdb..#tmpNegativeStock_1'))is not null
drop table #tmpNegativeStock_1

select cGoodsNo,iSerNo,cWhNo,fQtyLeft,fQty_Left,iOrder,销售数量0,销售金额0,Xsmoney,Xsfqty
into #tmpNegativeStock_1
from #tmpNegativeStock
where isnull(iAttribute,0)<>10

                          --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='NegativeInWh')
  		begin
  		  close NegativeInWh
          deallocate NegativeInWh
  		end 

declare  NegativeInWh cursor
for
select  cGoodsNo,iSerNo,cWhNo,fQtyLeft,销售数量0,销售金额0,Xsmoney,Xsfqty
--from #tmpNegativeStock
from #tmpNegativeStock_1
order by iOrder,iserNo

open NegativeInWh

declare @CurGoodsNo varchar(32)
declare @CurSerno money
declare @CurWhNo varchar(32)
declare @CurFqty money
declare @销售数量0 money
declare @销售金额0 money
declare @Xsmoney money
declare @Xsfqty money
select @CurGoodsNo='',@CurSerno=0,@CurWhNo='',@CurFqty=0,@销售数量0=0,@销售金额0=0,@Xsmoney=0,@Xsfqty=0
fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty,@销售数量0,@销售金额0,@Xsmoney,@Xsfqty
--select @CurGoodsNo+'  '+cast(@CurSerno as varchar(10))+'   '+cast(@CurFqty as varchar(10))
while @@fetch_status=0
begin
	declare @spare float --剩余库存 
	select @spare=sum(fQuantity)
	from #tmpInWareHouse 
	where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	group by cGoodsNo

    set @spare=isnull(@spare,0)
   if(@spare>=@CurFqty) 
   begin 
		--根据入库日期采用先进先出原则对货物的库存进行处理
		update a 
		set a.fQty_tmpIn=ISNULL(a.fQty_tmpIn,0)+ 
		case when 
			( select @CurFqty-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo and iLineNo <=a.iLineNo and cWhNo=@CurWhNo
			)>=0 
		then a.fQuantity
		else 
			case when 
				(select @CurFqty-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo and cWhNo=@CurWhNo
				)<0 then 0 
			else 
			   (select @CurFqty-isnull(sum(fQuantity),0)
				from #tmpInWareHouse 
				where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo  and cWhNo=@CurWhNo
               ) 
			end 
        end,
        a.销售数量0=ISNULL(a.销售数量0,0)+
        case when 
			( select @CurFqty-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo and iLineNo <=a.iLineNo and cWhNo=@CurWhNo
			)>=0 
		then @Xsfqty
		else 
			case when 
				(select @CurFqty-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo and cWhNo=@CurWhNo
				)<0 then 0 
			else 
			   @Xsfqty			 
			end 
        end,
        a.销售金额0=ISNULL(a.销售金额0,0)+
        case when 
			( select @CurFqty-isnull(sum(fQuantity),0)
			  from #tmpInWareHouse 
			  where cGoodsNo=@CurGoodsNo and iLineNo <=a.iLineNo and cWhNo=@CurWhNo
			)>=0 
		then @Xsmoney
		else 
			case when 
				(select @CurFqty-isnull(sum(fQuantity),0)
				 from #tmpInWareHouse 
				 where cGoodsNo=@CurGoodsNo and iLineNo <a.iLineNo and cWhNo=@CurWhNo
				)<0 then 0 
			else 
			   @Xsmoney			 
			end 
        end 
		from #tmpInWareHouse a 
		where a.cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
    end else
    begin
	   --负库存 
	  declare @MaxRow int
	  declare @tmpLeafSum money
	  select @MaxRow=max(iLineNo) from #tmpInWareHouse where cGoodsNo=@CurGoodsNo and cWhNo=@CurWhNo
	 	    
          update a
		  set a.fQty_tmpIn=ISNULL(a.fQty_tmpIn,0)+@CurFqty-(
                                      select isnull(sum(fQuantity),0) 
                                      from #tmpInWareHouse 
                                      where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
                                     ),
                                     a.销售数量0=ISNULL(a.销售数量0,0)+@Xsfqty,
                                     a.销售金额0=ISNULL(a.销售金额0,0)+@Xsmoney
		  from #tmpInWareHouse a
		  where a.cGoodsNo=@CurGoodsNo and iLineNo=@MaxRow and cWhNo=@CurWhNo
		  /*2014-12-14*/
		   update #tmpInWareHouse
		  --set fQty_tmpIn=fQuantity,销售数量0=@Xsfqty,销售金额0=@Xsmoney
		  set fQty_tmpIn=ISNULL(fQty_tmpIn,0)+fQuantity 
		  where cGoodsNo=@CurGoodsNo and iLineNo<@MaxRow and cWhNo=@CurWhNo
		  
	 -- end else
	 -- begin
	--	 update #tmpWhForm
	--	 set fQty_Out=fQty_Out+@QtyOut
	--	 where cGoodsNo=@cGoodsNo and iSerNo=@MaxRow and cWhNo=@CurWhNo
	--  end
   end   
   fetch next from NegativeInWh into @CurGoodsNo,@CurSerno,@CurWhNo,@CurFqty,@销售数量0,@销售金额0,@Xsmoney,@Xsfqty
end

close NegativeInWh
deallocate NegativeInWh
 
/*以上2015-07-29调整***************************/
update a
set a.fQty_Out=a.fQty_in,fMoney_Out=a.fMoney_in,a.fPrice_out=a.fPrice_in,
    a.fQty_left=0,a.fPrice_left=a.fPrice_in,a.fMoney_left=0,
    a.本日库存数量=0,
    --销售数量0=a.fQty_in,
    --销售金额0=(a.销售金额0/a.销售数量0)*a.fQty_In,
    --正价销售数量=a.fQty_in,
    --正价销售金额=(a.销售金额0/a.销售数量0)*a.fQty_In,
     销售数量0=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then a.fQty_in else a.销售数量0 end ,
     销售金额0=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then (a.销售金额0/a.销售数量0)*(isnull(a.fQty_in,0)) else a.销售金额0 end ,
     正价销售数量=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then a.fQty_in else a.销售数量0 end ,
     正价销售金额=case when ISNULL(a.销售数量0,0)>isnull(a.fQty_in,0) then (a.销售金额0/a.销售数量0)*(isnull(a.fQty_in,0)) else a.销售金额0 end ,
     特价销售数量=0,特价销售金额=0
from t_wh_form_log a,#tmpNegativeStock b
where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo and a.cWhNo=b.cWhNo

 

insert into t_wh_form_log
(业务日期,
  cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cSummary,fPrice_in,fQty_in,fMoney_in,
  fPrice_out,fQty_out,fMOney_out,fPrice_left,fQty_left,fMoney_left,cWhNo,
  cSupplierNo,cSupplier,iSerNo,cGoodsNo_Parent,fQty_minPackage,fQty_In_Parent,
  入库数量1,入库金额1,本日库存数量,销售数量0,销售金额0,正价销售数量,正价销售金额
)
select dDate,cGoodsNo,dDate,cSheetNo,iLineNo,0,'入库单',fInPrice,fQuantity,fInMoney,
fPrice_out=fInPrice,fQty_out=fQty_tmpIn,fMOney_out=fQty_tmpIn*fInPrice,
fInPrice,fQty_left=fQuantity-fQty_tmpIn,fMoney_left=(fQuantity-fQty_tmpIn)*fInPrice,
cWhNo,cSupplierNO,cSupplier,0,cGoodsNO_Parent,fQty_MinPackage,fquantity_Parent,
fQuantity,fInMoney,(fQuantity-fQty_tmpIn),销售数量0,销售金额0,销售数量0,销售金额0
from #tmpInWareHouse 


update t_wh_form_log
set iSerNo=iMyIdentity
where iAttribute=0 and cSheetNo=@cSheetNo and isnull(iSerNo,0)=0


if @bPermitNegativeStock=1
begin
      --声明一刚插入成本表中行的游标
      --产生负库存的情况，修正负库存
      
                                --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='CurCostTable')
  		begin
  		  close CurCostTable
          deallocate CurCostTable
  		end 
      
      declare  CurCostTable cursor
      for
      select cGoodsNo,iSerNo,fPrice_In,cWhNo,fQty_In,iAttribute
      from t_wh_form_log
      where iAttribute=0 and cSheetNo=@cSheetNo and fQty_in>0 and fQty_out>0
      order by iserNo

      open CurCostTable
      declare @cGoodsNo varchar(32)
      declare @iLineNo int
      declare @fPrice_In Money
      declare @fQty_In_Orient money
      declare @iSerno_Orient bigint
      declare @cWhNo varchar(32)
      declare @iAttribute_orient int

      declare @id bigint
      declare @fQty_Cost money
      declare @fQty_Pre money
      declare @iAttribute int
      declare @dDate_Sheet datetime
      declare @iLineNo_Orient bigint
      declare @fPrice_sale money
      declare @fMoney_sale  money

      declare @fQty_leiji money
      declare @fQty_left money

      declare @tmpMoney money
      declare @tmpMoney2 money
      declare @MaxId int
      declare @SheetNO_supply varchar(64)

      fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
      while @@fetch_status=0 
      begin
        
      --以下解决负库存的成本分配问题
      if (select object_id('tempdb..#temp_Record_Preview'))is not null
      drop table #temp_Record_Preview
      if (select object_id('tempdb..#temp_Record_null'))is not null
      drop table #temp_Record_null

      select id,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,
        fPrice_sale,fMoney_sale
      into #temp_Record_Preview--需要处理的不合法成本分配记录
      from Pos_Cost_distribute.dbo.t_Cost_distribute_Log
      where isnull(bDone,0)=0 and fQty<fQty_Cost and cWhNo=@cWhNo and cGoodsNo=@cGoodsNo

      select iMyid=identity(int,1,1),id=cast(null as bigint),bDone_set=cast(0 as bit),dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,
        fPrice_sale,fMoney_sale
      into #temp_Record_null--存放已处理完毕待插入成本分配表的  原来不合法成本分配记录
      from Pos_Cost_distribute.dbo.t_Cost_distribute_Log
      where 1<>1

      set @fQty_leiji=0
      set @fQty_left=@fQty_In_Orient
      
                                      --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_Record_Preview')
  		begin
  		  close Cur_Record_Preview
          deallocate Cur_Record_Preview
  		end 

      declare  Cur_Record_Preview cursor
      for
      select id,fQty_Cost,fQty_Pre=fQty,iAttribute,dDate_Sheet,iLineNo,fPrice_sale,fMoney_sale,cSheetNO
      from #temp_Record_Preview
      order by id

      open Cur_Record_Preview
      fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient,@fPrice_sale,@fMoney_sale,@SheetNO_supply
      while @@fetch_status=0 
      begin
            set @tmpMoney2=0

            if @fQty_Pre>0
            begin                     
              select @tmpMoney2=fPrice_sale*fQty
              from Pos_Cost_distribute.dbo.t_Cost_distribute_Log a
              where id=@id                      

	          update a
              set fQty_Cost=fQty,fMoney_sale=fPrice_sale*fQty,fMoney_Cost=fPrice_Cost*fQty
              from Pos_Cost_distribute.dbo.t_Cost_distribute_Log a
              where id=@id 

              
	          insert into #temp_Record_null
	          (id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,fPrice_sale,fMoney_sale)
	          values
	          (@id,0,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost-@fQty_Pre,@fPrice_In*(@fQty_Cost-@fQty_Pre),@iAttribute,@SheetNO_supply,@iLineNo_Orient,@fQty_left,0,@cWhNo,@fPrice_sale,@fPrice_sale*(@fQty_Cost-@fQty_Pre))  
        	  
        	  set @fQty_left=@fQty_left-(@fQty_Cost-@fQty_Pre)	
        	  			
            end else
            begin
		      insert into #temp_Record_null
		      (id,bDone_set,dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,cWhNo,fPrice_sale,fMoney_sale)
		      values
		      (@id,1,@dDate_Sheet,@cGoodsNo,@iSerno_Orient,@fPrice_In,@fQty_Cost,@fPrice_In*@fQty_Cost,@iAttribute,@SheetNO_supply,@iLineNo_Orient,@fQty_left,0,@cWhNo,@fPrice_sale,@fPrice_sale*(@fQty_Cost))
		      set @fQty_left=@fQty_left-@fQty_Cost
            end
         
            --如果分配后的总金额<>@fMoney_sale ，则把误差加到第一条
            set @tmpMoney=0
            set @MaxId=0
            select @tmpMoney=sum(fMoney_sale)+@tmpMoney2 from #temp_Record_null where id=@id
            select @MaxId=min(iMyid) from #temp_Record_null where id=@id
            if @tmpMoney<>@fMoney_sale 
            begin
              update #temp_Record_null
              set fMoney_sale=fMoney_sale+(@fMoney_sale-@tmpMoney)
              where id=@id and iMyid=@MaxId      
            end
            

        fetch next from Cur_Record_Preview into @id,@fQty_Cost,@fQty_Pre,@iAttribute,@dDate_Sheet,@iLineNo_Orient,@fPrice_sale,@fMoney_sale,@SheetNO_supply
      end
      close Cur_Record_Preview
      deallocate Cur_Record_Preview

      update a
      set a.bDone=b.bDone_set
      from Pos_Cost_distribute.dbo.t_Cost_distribute_Log a,#temp_Record_null b
      where a.id=b.id

      insert into Pos_Cost_distribute.dbo.t_Cost_distribute_Log
      (dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,dDate_Account,cWhNo,fPrice_sale,fMoney_sale)
      select dDate_sheet,cGoodsNo,iSerno,fPrice_Cost,fQty_Cost,fMoney_Cost,iAttribute,cSheetno,iLineNo,fQty,bDone,getdate(),cWhNo,fPrice_sale,fMoney_sale
      from #temp_Record_null


      --以上解决负库存的成本分配问题

      fetch next from CurCostTable into @cGoodsNo,@iSerno_Orient,@fPrice_In,@cWhNo,@fQty_In_Orient,@iAttribute_orient
      end
      close CurCostTable
      deallocate CurCostTable

end


update wh_InWarehouse
set bAccount=1,bAccount_log=1
where cSheetno=@cSheetNo

commit tran
set @return=0
end try
begin catch
 rollback 
set @return=1
end catch

--select * from #tmpInWareHouse
--select * from t_wh_form_log
GO
