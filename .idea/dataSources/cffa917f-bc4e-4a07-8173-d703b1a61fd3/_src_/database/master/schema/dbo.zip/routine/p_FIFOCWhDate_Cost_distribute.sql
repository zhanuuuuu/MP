

-----------------------------------------  从各个数据库中取日销售v  t_SaleSheet_Day
  ------2012-10-15 通用报表 供应商时段插叙  销售结转---------------------------------------------------------------  
  /*
exec p_FIFOCWhDate_Cost_distribute  '2013-01-01','2013-10-20'

select * from t_Cost_distribute
    */
create proc [dbo].[p_FIFOCWhDate_Cost_distribute]
@date1 datetime,
@date2 datetime
as
begin

  if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
    create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor
			 insert into #temp_SaleSheetInfor(databasename)
			 select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName

				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from #temp_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin			
                    exec('
                     
                    
						insert into #FIFOCWhDate_Cost_distribute(cGoodsNo,fQty_Cost,fMoney_Cost,fMoney_sale,dDate_Sheet,iSerno,bDone,cWhNo,iAttribute)
						select cGoodsNo,fQty_Cost,fMoney_Cost,fMoney_sale,dDate_Sheet,iSerno,bDone,cWhNo,iAttribute
						from '+@InfoName1+'.dbo.t_Cost_distribute 
						where  dDate_Sheet between '''+@date1+''' and '''+@date2+'''
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
			
		
				  
	insert into #FIFOCWhDate_Cost_distribute(cGoodsNo,fQty_Cost,fMoney_Cost,fMoney_sale,dDate_Sheet,iSerno,bDone,cWhNo,iAttribute)
						select cGoodsNo,fQty_Cost,fMoney_Cost,fMoney_sale,dDate_Sheet,iSerno,bDone,cWhNo,iAttribute
						from dbo.t_Cost_distribute 
						where  dDate_Sheet between @date1 and @date2

     
end
GO
