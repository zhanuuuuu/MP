/*
p_Qry_Data '2010-02-25','2010-03-25','04'
*/

CREATE procedure p_Qry_Data
@dDate1 datetime,
@dDate2 datetime,
@cWhNo varchar(32)
as
begin
	select cGoodsNo into #temp_Goods from t_Goods where cGoodsNo like '2103100%'

  declare @dDate_Daily datetime
  select @dDate_Daily=max(dDate) from dbo.t_Daily_history where cWHno=@cWhNo

  select cGoodsNo,dSaleDate_Prior=max(dSaleDate)
	into #temp_Goods_Date_Prior0
  from dbo.t_SaleSheet_Day
	where dSaleDate<@dDate1 and cWHno=@cWhNo and cGoodsNo in (select cGoodsNo from #temp_Goods)
	group by cGoodsNo
  
  select a.cGoodsNo,iSeed=min(b.iSeed),a.dSaleDate_Prior
  into #temp_Goods_Date_Prior
  from #temp_Goods_Date_Prior0 a, t_SaleSheet_Day b
  where  a.dSaleDate_Prior=b.dSaleDate and b.cWHno=@cWhNo and a.cGoodsNo=b.cGoodsNo
	group by a.cGoodsNo,a.dSaleDate_Prior

  select cGoodsNo,dSaleDate_last=max(dSaleDate)
	into #temp_Goods_Date_Last0
  from dbo.t_SaleSheet_Day
	where dSaleDate <= @dDate2 and cWHno=@cWhNo 
	and cGoodsNo in (select cGoodsNo from #temp_Goods)
	group by cGoodsNo

  select a.cGoodsNo,iSeed=min(b.iSeed),a.dSaleDate_last
  into #temp_Goods_Date_Last
  from #temp_Goods_Date_Last0 a, t_SaleSheet_Day b
  where  a.dSaleDate_last=b.dSaleDate and b.cWHno=@cWhNo and a.cGoodsNo=b.cGoodsNo
	group by a.cGoodsNo,a.dSaleDate_last 

  select	a.dSaleDate,a.cWHno,a.cGoodsNo,a.fMoney_Addon,a.fQty_Addon,
	a.fMoney_Addon_0,a.fQty_Addon_0,a.fMoney_Addon_1,a.fQty_Addon_1
  into #temp_Sale_Prior
  from dbo.t_SaleSheet_Day a,#temp_Goods_Date_Prior b
  where a.dSaleDate=b.dSaleDate_Prior and a.cWHno=@cWhNo and a.cGoodsNo =b.cGoodsNo and a.iSeed=b.iSeed

  select	a.dSaleDate,a.cWHno,a.cGoodsNo,a.fMoney_Addon,a.fQty_Addon,
	a.fMoney_Addon_0,a.fQty_Addon_0,a.fMoney_Addon_1,a.fQty_Addon_1
  into #temp_Sale_Last
  from dbo.t_SaleSheet_Day a,#temp_Goods_Date_Last b
  where a.dSaleDate=b.dSaleDate_last and a.cWHno=@cWhNo and a.cGoodsNo =b.cGoodsNo and a.iSeed=b.iSeed
  
  select cGoodsNo,bAuditing=isnull(bAuditing,0),
	fMoney_Sale=sum(isnull(fLastSettle,0)),fQuantity=sum(isnull(fQuantity,0))
  into #temp_Sale_NoDaily
	from dbo.t_SaleSheetDetail
  where @dDate_Daily is not null 
	and dSaleDate>@dDate_Daily and dSaleDate<=@dDate2
  and cWHno=@cWhNo
  group by cGoodsNo,isnull(bAuditing,0)


  select a.cGoodsNo,dDate1=@dDate1,dDate2=@dDate2,cWhNo=@cWhNo,
	fMoney_Sale=(isnull(c.fMoney_Addon,0)-isnull(b.fMoney_Addon,0)),
	fQty_Addon=(isnull(c.fQty_Addon,0)-isnull(b.fQty_Addon,0)),
	fMoney_Addon_0=(isnull(c.fMoney_Addon_0,0)-isnull(b.fMoney_Addon_0,0)),
	fQty_Addon_0=(isnull(c.fQty_Addon_0,0)-isnull(b.fQty_Addon_0,0)),
	fMoney_Addon_1=(isnull(c.fMoney_Addon_1,0)-isnull(b.fMoney_Addon_1,0)),
	fQty_Addon_1=(isnull(c.fQty_Addon_1,0)-isnull(b.fQty_Addon_1,0))
  into #temp_Result
	from #temp_Goods a left join #temp_Sale_Prior b on a.cGoodsNo=b.cGoodsNo
										 left join #temp_Sale_Last  c on a.cGoodsNo=c.cGoodsNo

  update a
  set a.fMoney_Sale=a.fMoney_Sale+b.fMoney_Sale,
  a.fQty_Addon=a.fQty_Addon+b.fQuantity,
  a.fMoney_Addon_0=a.fMoney_Addon_0+b.fMoney_Sale,
  a.fQty_Addon_0=a.fQty_Addon_0+b.fQuantity
  from #temp_Result a,#temp_Sale_NoDaily b
  where a.cGoodsNo=b.cGoodsNo and b.bAuditing=0
  
  update a
  set a.fMoney_Sale=a.fMoney_Sale+b.fMoney_Sale,
  a.fQty_Addon=a.fQty_Addon+b.fQuantity,
  a.fMoney_Addon_1=a.fMoney_Addon_1+b.fMoney_Sale,
  a.fQty_Addon_1=a.fQty_Addon_1+b.fQuantity
  from #temp_Result a,#temp_Sale_NoDaily b
  where a.cGoodsNo=b.cGoodsNo and b.bAuditing=1

  select  cGoodsNo,dDate1,dDate2,cWhNo,
	fMoney_Sale,fQty_Addon,fMoney_Addon_0,fQty_Addon_0,fMoney_Addon_1,fQty_Addon_1
  from #temp_Result   
  
end
GO
