


CREATE    view v_Shelf_Part
as
  select a.cShelfNo,b.cShelfName,cShelfPart,fSize,fHirePrice_Year,fHirePrice_Month,fHirePrice_Day,
         b.cZoneNo,c.cZoneName,cSalesDeptNo,cSalesDept
  from t_Shelf_Part a left join t_Shelf b
                       on  a.cShelfNo=b.cShelfNo
                       left join t_Zone c
                       on b.cZoneNo=c.cZoneNo


GO
