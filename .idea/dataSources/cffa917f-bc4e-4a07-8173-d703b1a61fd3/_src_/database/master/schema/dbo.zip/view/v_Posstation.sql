
CREATE view v_Posstation
as
select a.cStoreNo,a.cWhNo,b.posid
from t_WareHouse a,t_posstation b
where a.cWhNo=b.cWHno
GO
