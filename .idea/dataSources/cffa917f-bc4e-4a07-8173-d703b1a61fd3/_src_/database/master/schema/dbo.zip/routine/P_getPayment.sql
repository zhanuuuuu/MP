



CREATE  procedure P_getPayment
  @cSupplierNo varchar(32),
	@station varchar(32)
as
begin
--	declare @strtmp varchar(32)
--	set @strtmp=dbo.getDayStr(@EndDate)
exec('
	if  (select object_id(''tempdb..##TempBalanceFlag_'+@cSupplierNo+''')) is not null 
	drop table ##TempBalanceFlag_'+@cSupplierNo+'
	select cStation='''+@station+''' into ##TempBalanceFlag_'+@cSupplierNo+' 

	if  (select object_id(''tempdb..##TempJiesuan_'+@cSupplierNo+''')) is not null 
	drop table ##TempJiesuan_'+@cSupplierNo+'

	select cStaion='''+@station+''',cCheck=space(2),jiesuanno,cSupNo,cSupName,shenheren,jiesuanjine,InMoney,RbdMoney,
         xiaoshoujine,feiyongjine,payoutMoney,zoneMoney,koudianjine,xiaoshou_zj,xiaoshou_tj,koudian_zj,
         koudian_tj,qita,jiesuanriqi,shenhe,fukuan,cBalanceType,cBalanceTypeNo,cWh,cWhNo

	into ##TempJiesuan_'+@cSupplierNo+'
	from dbo.t_supplier_jiesuan
	where cSupNo='''+@cSupplierNo+''' and isnull(fukuan,0)=0

--  select * from  ##TempJiesuan_'+@cSupplierNo+'

  ')

end


GO
