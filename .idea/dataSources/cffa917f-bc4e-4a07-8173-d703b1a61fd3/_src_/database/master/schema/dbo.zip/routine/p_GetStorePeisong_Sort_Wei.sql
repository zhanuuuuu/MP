/*
exec p_GetStorePeisong_Sort_Wei '2016-10-15','10151857368320'
*/
CREATE proc [dbo].[p_GetStorePeisong_Sort_Wei]
@dDate datetime,
@cTermID varchar(32)
as
begin
    if (select object_id('tempdb..#tmp_Store'))is not null drop table #tmp_Store
	create table #tmp_Store(cStoreNo varchar(32),cStoreName varchar(64))
	exec('
	   insert into #tmp_Store(cStoreNo,cStoreName)
	   select distinct a.cStoreNo,b.cStoreName
	   from U_Key.dbo.temp_Store'+@cTermID+' a,t_Store b
	   where a.cStoreNo=b.cStoreNo   
	')
	
  
	
	if (select object_id('tempdb..#tmp_ShipSheet'))is not null drop table #tmp_ShipSheet
	select a.dDate,a.cSheetno,cTruckID,cDriverNo,cDriverName,
	b.cSheetNo_YH,b.cStoreNo,b.cStoreName
	into #tmp_ShipSheet
	from [wh_ShipSheet] a,wh_ShipOutYhSheetDetail b
	where a.dDate=@dDate and a.cSheetno=b.cSheetno  
	
 
    if (select object_id('tempdb..#tmp_StoreSortGoods'))is not null drop table #tmp_StoreSortGoods
	select a.cStoreNo,a.cStoreName,fQty=sum(b.fQuantity),b.cGoodsNo,b.cGoodsName,b.cSheetno  
	into #tmp_StoreSortGoods
	from #tmp_ShipSheet a,wh_cStoreOutVerifySheetDetail b
	where   a.cSheetNo_YH=b.cSheetno --and ISNULL(a.bfresh,0)=1
	group by a.cStoreNo,a.cStoreName,b.cGoodsNo,b.cGoodsName,b.cSheetno
	
 
	if (select object_id('tempdb..#tmp_StoreOutGoods0'))is not null drop table #tmp_StoreOutGoods0
	select cStoreName=replace(b.cStoreName,'-',''),a.fQty,a.cGoodsNo,a.cGoodsName 
	into #tmp_StoreOutGoods0
	from #tmp_StoreSortGoods a, #tmp_Store b
	where a.cStoreNo=b.cStoreNo
	order by a.cStoreNo
	
 
DECLARE @sql VARCHAR(8000)
DECLARE @sql1 VARCHAR(8000)

SET @sql=''  --初始化变量 @sql
SET @sql1=''  --初始化变量 @sql

SELECT @sql= @sql+',' +cStoreName ,
@sql1= @sql1+',' +cStoreName+'=isnull('+cStoreName+',0)'
FROM #tmp_Store GROUP BY cStoreName --变量多值赋值

SET @sql= replace(STUFF(@sql,1,1,''),'-','')--去掉首个','
SET @sql1= replace(STUFF(@sql1,1,1,''),'-','')--去掉首个','
 
 
exec('
 select  cGoodsNo as 商品编号,cGoodsName as 商品名称,'+@sql1+' 
 from   #tmp_StoreOutGoods0 t
 PIVOT
 (sum(fQty) FOR  cStoreName IN ('+@sql+') )  a
 ')
 
end
GO
