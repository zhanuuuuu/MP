/*

   if(select object_id('tempdb..#temp_Goods')) is not null
	begin
		drop table 	#temp_Goods
	end 	
	select cGoodsNo into #temp_Goods from t_Goods
	where csupno='3004' --and cGoodsNo in ('415531','415537')
	
	declare @return int
exec [p_GetSupplierTempJiesuan_联营] '2015-05-01','2015-05-31','3004',''
select @return


*/

CREATE   procedure [dbo].[p_GetSupplierTempJiesuan_联营]
@dDate1 datetime,
@dDate2 datetime,
@supNo varchar(64),
@cWHno varchar(32)
as
begin

   declare @jiesuanNo varchar(64)
   set @jiesuanNo=(select sheetno=dbo.f_GenJiesuanNo(CAST(YEAR(@dDate2) as varchar(16)),@supNo))

 
  
  declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
  select distinct @cdbname=Pos_WH_Form,@cWhno=cWhNo from dbo.t_WareHouse  where isnull(bMainSale,0)=1


/*获取商品信息*/
if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select distinct cGoodsNo into #temp_Goods 
from  t_Goods b
where  cSupNo=@supNo

	if(select object_id('tempdb..#temp_SupplierRatio')) is not null
	begin
		drop table 	#temp_SupplierRatio
	end 
	if(select object_id('tempdb..#temp_SupplierSales')) is not null
	begin
		drop table 	#temp_SupplierSales
	end 
	if(select object_id('tempdb..#temp_SupplierSales_ratio')) is not null
	begin
		drop table 	#temp_SupplierSales_ratio
	end 

	/*注意一品多商的情况*/
	if(select object_id('tempdb..#temp_Sale_Cost_distribute')) is not null
	begin
		drop table 	#temp_Sale_Cost_distribute
	end 
	declare @guizu varchar(64)


  declare @dDate_MaxAccount datetime
  select @dDate_MaxAccount=isnull(max(dDate),'2000-01-01') 
	from dbo.t_Daily_history
  where isnull(bAccount,0)=1 --and cWhno=@cWHno
  
  ---------------------------- 从销售备份中取数据
  
 if (select OBJECT_ID('tempdb..#temp_SaleSheet_Day_Sal'))is not null drop table #temp_SaleSheet_Day_Sal
create  table #temp_SaleSheet_Day_Sal(dSaleDate datetime,cGoodsNo varchar(32),iSeed varchar(32),fQuantity money,fLastSettle money,fProfitsRatio money,cWHno varchar(32),bAuditing bit)
if (select OBJECT_ID('tempdb..#temp_Cost_distribute_Sal'))is not null drop table #temp_Cost_distribute_Sal
create  table #temp_Cost_distribute_Sal(cGoodsNo varchar(32),bDone bit,iAttribute int,cWHno varchar(32),iSerno varchar(32),iLineNo int,fPrice_Cost money,fQty_Cost money,fMoney_Cost money,dDate_Sheet datetime,fMoney_sale money)
 if (select OBJECT_ID('tempdb..#temp_salesheetdetail_Sal'))is not null drop table #temp_salesheetdetail_Sal
create  table #temp_salesheetdetail_Sal(dSaleDate datetime,cGoodsNo varchar(32),fQuantity money,fLastSettle money,bAuditing bit)
	

   if exists (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@dDate1)  -- 包含在时间断内
   begin
     --select 1
       exec p_SumSupplier_Sale @dDate1,@dDate2,@dDate_MaxAccount
       if not exists  (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@dDate2)
       begin     
			insert into #temp_SaleSheet_Day_Sal(dSaleDate,cGoodsNo,iSeed,fQuantity,fLastSettle,fProfitsRatio,cWHno,bAuditing)	
			select c.dSaleDate,c.cGoodsNo,c.iSeed,c.fQuantity,c.fLastSettle,c.fProfitsRatio,c.cWHno,c.bAuditing
		  --into #temp_SaleSheet_Day
			from t_SaleSheet_Day c,#temp_Goods a
			where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
			 and a.cGoodsNo=c.cGoodsNo
         
       end
   end else
   begin  
     
		insert into #temp_SaleSheet_Day_Sal(dSaleDate,cGoodsNo,iSeed,fQuantity,fLastSettle,fProfitsRatio,cWHno,bAuditing)	
		select c.dSaleDate,c.cGoodsNo,c.iSeed,c.fQuantity,c.fLastSettle,c.fProfitsRatio,c.cWHno,c.bAuditing
	  --into #temp_SaleSheet_Day
		from t_SaleSheet_Day c,#temp_Goods a
		where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
		 and a.cGoodsNo=c.cGoodsNo
  
	   insert into #temp_salesheetdetail_Sal(dSaleDate,cGoodsNo,fQuantity,fLastSettle,bAuditing)	
	   select a.dSaleDate,a.cGoodsNo,a.fQuantity,a.fLastSettle,a.bAuditing
	   from t_salesheetdetail a,#temp_Goods b
		where a.dSaleDate >@dDate_MaxAccount and a.dSaleDate between @dDate1 and @dDate2  and a.cGoodsNo=b.cGoodsNo
		
   end
  -----------------------------
  

if (select OBJECT_ID('tempdb..#temp_SaleSheet_Day'))is not null drop table #temp_SaleSheet_Day
create  table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),iSeed int ,fQuantity money,fLastSettle money,fProfitsRatio money,cWHno varchar(32),bAuditing bit)

 insert into #temp_SaleSheet_Day(dSaleDate,	cGoodsNo,iSeed,fQuantity,fLastSettle,fProfitsRatio,cWHno,bAuditing)
  select c.dSaleDate,	c.cGoodsNo,c.iSeed,c.fQuantity,c.fLastSettle,c.fProfitsRatio,c.cWHno,c.bAuditing
 -- into #temp_SaleSheet_Day
  --from t_SaleSheet_Day c,#temp_Goods a
  from #temp_SaleSheet_Day_Sal c,#temp_Goods a
	where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
	 and a.cGoodsNo=c.cGoodsNo
--------------------------------------

	select c.cGoodsNo,c.bAuditing,dDateTime=case when a.dDateTime is not null then a.dDateTime else c.dSaleDate end,
	a.iSerno,a.cSupplierNo,a.cSupplier,
	a.fPrice_In,a.fQty_In,a.fMoney_In,a.cWhNo,
	iLineNo=case when b.iLineNo is not null then b.iLineNo else 1 end,
	b.fPrice_Cost,fQty_Cost=case when b.fQty_Cost is not null then  b.fQty_Cost else c.fQuantity end,b.fMoney_Cost,
  dDate_Sheet=case when b.dDate_Sheet is not null then b.dDate_Sheet else c.dSaleDate end
	,fMoney_sale_whole=c.fLastSettle,fQty_Sale_whole=c.fQuantity,c.fProfitsRatio,
--	fMoney_sale_distribute=cast(0 as money),fQty_sale_distribute=cast(0 as money),IDENTITY(int, 1,1) AS iSeedNo
	fMoney_sale_distribute=b.fMoney_sale,fQty_sale_distribute=b.fQty_Cost,IDENTITY(int, 1,1) AS iSeedNo

	into #temp_Sale_Cost_distribute
	from #temp_SaleSheet_Day c 
			-- left join dbo.t_Cost_distribute b 
			left join #temp_Cost_distribute_Sal b 
				on c.dSaleDate=b.dDate_Sheet and c.cGoodsNo=b.cGoodsNo and b.iLineNo=c.iSeed
           and b.dDate_Sheet<=@dDate_MaxAccount and b.dDate_Sheet between @dDate1 and @dDate2 
           and isnull(b.bDone,0)=0 and b.iAttribute=10 and b.cWHno=c.cWHno 
       left join dbo.t_WH_Form a
        on a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and a.cWhNo=c.cWHno
	where c.dSaleDate<=@dDate_MaxAccount and c.dSaleDate between @dDate1 and @dDate2
 -- and b.dDate_Sheet<=@dDate_MaxAccount and b.dDate_Sheet between @dDate1 and @dDate2 
--	and c.cWHno=@cWHno
--	and isnull(b.bDone,0)=0 and b.iAttribute=10
	

	--alter table #temp_Sale_Cost_distribute  add iSeedNo int identity(1,1)
	/*以下处理四舍五入造成的 销售金额 损耗*/
      /*如果存在损耗，则将损耗 认为指定在iSeedNo= max(iSeedNo) 的记录上*/
/*
	update a
	set a.fQty_sale_distribute=a.fQty_Cost,
	fMoney_sale_distribute
	=case when a.fQty_Sale_whole<>0 then a.fMoney_sale_whole*a.fQty_Cost/a.fQty_Sale_whole
	 else 0
	 end
	from #temp_Sale_Cost_distribute a
  update a
  set a.fMoney_sale_distribute=a.fMoney_sale_distribute+(y.fMoney_sale_whole-y.fMoney_sale_distribute)
  from #temp_Sale_Cost_distribute a,
  ( select x.* from
		(
			select cGoodsNo,dDateTime,fMoney_sale_whole,iLineNo,fMoney_sale_distribute=sum(fMoney_sale_distribute),
			iSeedNo=max(iSeedNo)
			from #temp_Sale_Cost_distribute
			group by cGoodsNo,dDateTime,fMoney_sale_whole,iLineNo
		) x where x.fMoney_sale_whole<>fMoney_sale_distribute
  )y
  where a.iSeedNo=y.iSeedNo and a.cGoodsNo=y.cGoodsNo
*/
	/*以上处理四舍五入造成的 销售金额 损耗*/

  update #temp_Sale_Cost_distribute
  set fMoney_sale_distribute=fMoney_sale_whole,fQty_sale_distribute=fQty_Sale_whole
  where iSerno is null

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=a.fMoney_sale_distribute
  from #temp_Sale_Cost_distribute a,dbo.t_Goods b--供应商为空
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null
--select * from #temp_Sale_Cost_distribute

--select * from t_Goods where cGoodsNo='32051019'

	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost=sum(fQty_Cost),fMoney_Cost=sum(fMoney_Cost),
	fMoney_sale_distribute=sum(fMoney_sale_distribute),bAuditing
	into #temp_Sale_Cost_distribute_Daily
	from #temp_Sale_Cost_distribute
  group by cSupplierNo,cSupplier,dDate_Sheet,cGoodsNo,bAuditing

  /*以下计算（预估） 计算未参加日结记账的销售毛利*/
  
  select a.dSaleDate,a.cGoodsNo,a.fQuantity,a.fLastSettle,a.bAuditing
  into #temp_salesheetdetail0
  --from t_salesheetdetail a,#temp_Goods b
    from #temp_salesheetdetail_Sal a,#temp_Goods b
	where a.dSaleDate >@dDate_MaxAccount and  a.dSaleDate between @dDate1 and @dDate2 and a.cGoodsNo=b.cGoodsNo
  union all
	select e.dSaleDate,e.cGoodsNo,e.fQuantity,e.fLastSettle,e.bAuditing ---顾客退货单
	from
  (
		select c.cGoodsNo,c.cGoodsName,c.cBarCode,fQuantity=-c.fQuantity,fLastSettle=-c.fInMoney,dSaleDate=d.dDate,bAuditing=0
		from dbo.WH_ReturnGoodsDetail c,dbo.WH_ReturnGoods d ,#temp_Goods k
		where  d.dDate between @dDate1 and @dDate2 and c.cSheetno=d.cSheetno and c.cGoodsNo=k.cGoodsNo
  ) e
  

--select * from #temp_salesheetdetail0

	select cGoodsNo,cSupplierNo=cast(null as varchar(32)),cSupplier=cast(null as varchar(64)),
	dDate_Sheet=dSaleDate,fQty_Cost=sum(fQuantity),fMoney_Cost=cast(0 as money),
  fMoney_sale_distribute=sum(fLastSettle),bAuditing
  into #temp_salesheetdetail 
	from #temp_salesheetdetail0  
	where dSaleDate >@dDate_MaxAccount and  dSaleDate between @dDate1 and @dDate2 
	group by cGoodsNo,dSaleDate ,bAuditing   

  update a
  set a.cSupplierNo=b.cSupplierNo,a.cSupplier=b.cSupplier,
  a.fMoney_Cost=a.fQty_Cost*b.fPrice_In
  from #temp_salesheetdetail a,
  (
		select k.cGoodsNo,k.dDateTime,k.iSerno,k.cSupplierNo,k.cSupplier,
		k.fPrice_In,k.fQty_In,k.fMoney_In
		from dbo.T_WH_Form k,
    (
      select cGoodsNo,iSerno=max(iSerno) --取最近一次成本
      from T_WH_Form
  		where dDateTime<=@dDate2 and cSupplierNo=@supNo
      group by cGoodsNo

    ) j
		where k.cGoodsNo=j.cGoodsNo and k.dDateTime<=@dDate2 and k.iSerno=j.iSerno
			 and k.cSupplierNo=@supNo
		
  ) b
  where a.cGoodsNo=b.cGoodsNo and b.fPrice_In is not null

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=fMoney_sale_distribute
  from #temp_salesheetdetail a,dbo.t_Goods b--没有记账成本
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null


  /*以上计算（预估） 计算未参加日结记账的销售毛利*/

  update a
  set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,
  a.fMoney_Cost=fMoney_sale_distribute
  from #temp_Sale_Cost_distribute_Daily a,dbo.t_Goods b--没有记账成本
  where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo is null

--select * into ##temp_Sale_Cost_distribute from #temp_Sale_Cost_distribute

  select b.*,fProfitRatio=cast(null as money),fMoney_Profit_sum=cast(0 as money),fProfitRatio_avg=cast(null as money),
  fMoney_0=cast(null as money),fProfit_0=cast(null as money),--正价销售、毛利
	fMoney_1=cast(null as money),fProfit_1=cast(null as money) ,--特价销售、毛利
  
  fProfit_Ratio_0=cast(null as money),--正价销售、扣点
	fProfit_Ratio_1=cast(null as money), --特价销售、扣点
  fRatio_Goods=CAST(null as Money)          -----------------------fRatio_Goods记录单品扣率

	into #temp_Sale_Cost
  from
  (
	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost,fMoney_Cost,fMoney_sale_distribute,cDetail='记账',bAuditing
  from #temp_Sale_Cost_distribute_Daily
	union all
	select cGoodsNo,cSupplierNo,cSupplier,dDate_Sheet,
	fQty_Cost,fMoney_Cost,fMoney_sale_distribute,cDetail='未记账',bAuditing
  from #temp_salesheetdetail
	) b
	
	update a set a.fRatio_Goods=b.fRatio,bAuditing=1    -----单品扣率计入特价
	from #temp_Sale_Cost a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and isnull(b.fRatio,0)>0
	
/*
	create table #temp_sale_Auditing01  --记录供应商正特价销售金额
  (
     cSupplierNo varchar(32),fSale_1 money,fSale_0 money,fProfit_1 money,fProfit_0 money,fDayRatio money
	)
*/

	select 	a.cSupplierNo,
	fMoney_sale_distribute_0=a.fMoney_sale_distribute,fMoney_sale_distribute_1=b.fMoney_sale_distribute
	into #temp_sale_Auditing01
	from
		(
		select cSupplierNo,fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0))
		from #temp_Sale_Cost
		where isnull(bAuditing,0)=0
		group by cSupplierNo
		) a left join
		(
		select cSupplierNo,fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0))
		from #temp_Sale_Cost
		where isnull(bAuditing,0)=1
		group by cSupplierNo
		) b
		on a.cSupplierNo=b.cSupplierNo

	select 	b.cSupplierNo,
	fMoney_sale_distribute_0=a.fMoney_sale_distribute,fMoney_sale_distribute_1=b.fMoney_sale_distribute
	into #temp_sale_Auditing10
	from
		(select cSupplierNo,fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0))
		from #temp_Sale_Cost
		where isnull(bAuditing,0)=0
		group by cSupplierNo
		) a right join
		(select cSupplierNo,fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0))
		from #temp_Sale_Cost
		where isnull(bAuditing,0)=1
		group by cSupplierNo
		) b
		on a.cSupplierNo=b.cSupplierNo

	select cSupplierNo,fMoney_sale_distribute_0,fMoney_sale_distribute_1,
	fProfit_1=cast(0 as money),fProfit_0=cast(0 as money),fDayRatio=cast(0 as money)
	into #temp_sale_Auditing_list
	from #temp_sale_Auditing01
  union 
	select cSupplierNo,fMoney_sale_distribute_0,fMoney_sale_distribute_1,
	fProfit_1=cast(0 as money),fProfit_0=cast(0 as money),fDayRatio=cast(0 as money)
	from #temp_sale_Auditing10

  declare @iPeriodDays int
  set @iPeriodDays=datediff(day,@dDate1,@dDate2)+1

	select cSupNo=a.guizuno,fMoney1=-99999999,fMoney2=0,fRatio=b.fRatio,b.iDays
	into #temp_SupplierRatio
	from
	(
		select guizuno,fMoney1=min(fMoney1)
		from dbo.t_Supplier_Contract_Ratio
		group by guizuno
	) a,t_Supplier_Contract_Ratio b
	where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1
	union all
	select cSupNo=guizuno,fMoney1=fMoney1*@iPeriodDays/iDays,
	fMoney2=case when fMoney2=999999999 then fMoney2 else fMoney2*@iPeriodDays/iDays end,
	fRatio,iDays
	from dbo.t_Supplier_Contract_Ratio

	select cSupNo=c.cSupplierNo,fMoney_sale=sum(c.fMoney_sale_distribute_0)
	into #temp_SupplierSales
	from #temp_sale_Auditing_list c
	where c.fMoney_sale_distribute_0 is not null
	group by c.cSupplierNo

	select a.cSupNo,a.fMoney1,a.fMoney2,a.fRatio,b.fMoney_sale,
	fMoney_Exe=cast(0 as money),fMoney_Ref=cast(0 as money)
	into #temp_SupplierSales_ratio
	from #temp_SupplierRatio a,#temp_SupplierSales b
	where a.cSupNo=b.cSupNo
/*
	update #temp_SupplierSales_ratio
	set fMoney_Ref=fMoney_sale-fMoney1

	update #temp_SupplierSales_ratio
	set fMoney_Ref=0
	where fMoney1<=-99999999

	update #temp_SupplierSales_ratio
	set fMoney_Exe=fMoney2-fMoney1
	where fMoney2<999999999 and fMoney1>=0

	update #temp_SupplierSales_ratio
	set fMoney_Exe=fMoney_sale-fMoney1
	where fMoney2=999999999
*/
update #temp_SupplierSales_ratio
	set fMoney_Ref=fMoney2-fMoney1

	update #temp_SupplierSales_ratio
	set fMoney_Ref=fMoney_sale-fMoney1
	where fMoney1<fMoney_sale and fMoney_sale<=fMoney2
	
	update #temp_SupplierSales_ratio
	set fMoney_Ref=0
	where fMoney1<=-99999999
	
	update #temp_SupplierSales_ratio
	set fMoney_Ref=0
	where fMoney1>fMoney_sale
	
	update #temp_SupplierSales_ratio
	set fMoney_Exe=fMoney_Ref
	
	--update #temp_SupplierSales_ratio
	--set fMoney_Ref=fMoney_sale-fMoney1

	--update #temp_SupplierSales_ratio
	--set fMoney_Ref=0
	--where fMoney1<=-99999999

	--update #temp_SupplierSales_ratio
	--set fMoney_Exe=fMoney2-fMoney1
	--where fMoney2<=999999999 and fMoney1>=0 and fMoney_Ref>=0

	--update #temp_SupplierSales_ratio
	--set fMoney_Exe=fMoney_sale-fMoney1
	--where fMoney2=999999999

	--update #temp_SupplierSales_ratio
	--set fMoney_Exe=0
	--where fMoney2<=999999999 and fMoney1>=0 and fMoney_Ref<0

	--update #temp_SupplierSales_ratio
	--set fMoney_Exe=fMoney_Ref
	--where fMoney2<=999999999 and fMoney1>=0 and fMoney_Ref<=fMoney2 and fMoney_Ref>=0

	select cSupplierNo=cSupNo,fMoney_sale,fRatio_Money=sum(fMoney_Exe*fRatio/100.00)
  into #temp_sale_Auditing_list_0
  from #temp_SupplierSales_ratio
  group by cSupNo,fMoney_sale
	
  
  update #temp_Sale_Cost
  set fMoney_Cost=fMoney_sale_distribute
  where fMoney_Cost is null

  update #temp_Sale_Cost
  set fMoney_0=fMoney_Sale_distribute,fProfit_0=fMoney_Sale_distribute-fMoney_Cost
  where isnull(bAuditing,0)=0

  update #temp_Sale_Cost
  set fMoney_1=fMoney_Sale_distribute,fProfit_1=fMoney_Sale_distribute-fMoney_Cost
  where isnull(bAuditing,0)=1

  update a set a.fProfitRatio=b.fRatio,fMoney_0=a.fMoney_Sale_distribute,
  fProfit_0=a.fMoney_Sale_distribute*b.fRatio/100,
	fProfit_Ratio_0=a.fMoney_Sale_distribute*b.fRatio/100
  
  from #temp_Sale_Cost a,
  (
		select cSupplierNo,fRatio_Money,fRatio=case when fMoney_sale<>0 then fRatio_Money/fMoney_sale*100 else 0 end
    from #temp_sale_Auditing_list_0
/*
    select cSupplierNo=guizuno,fRatio=max(fRatio)
    from dbo.t_Supplier_Contract_Ratio
    group by  guizuno
*/
  ) b
  where a.cSupplierNo=b.cSupplierNo and isnull(a.bAuditing,0)=0

--select * from #temp_Sale_Cost
 

  update #temp_Sale_Cost
  set fMoney_Profit_sum=(fMoney_Sale_distribute-fMoney_Cost)+fMoney_Sale_distribute*isnull(fProfitRatio,0)/100

  update #temp_Sale_Cost 
  set fProfitRatio_avg=case when isnull(fMoney_Sale_distribute,0)<>0
											  then fMoney_Profit_sum/fMoney_Sale_distribute*100 else null end

--select * from #temp_Sale_Cost

/* 以下处理策略活动t_PloyOfSale的毛利变动*/

--------------------------------------
--------------2013-09-24 特价扣点没有-----假如结算的开始日期 和结束如期 都在某一个策略日期段内获取不到相应的策略商品--------------
------------------------------------------
/*  改动前
  select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
  into #temp_PloyOfSale
  from t_PloyOfSale
  where (dDateStart between @dDate1 and @dDate2)
   or (dDateEnd  between @dDate1 and @dDate2)
	group by cGoodsNo,dDateStart,dDateEnd
*/	
/*  改动后*/

  select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
  into #temp_PloyOfSale
  from t_PloyOfSale
  where (@dDate1 between dDateStart and dDateEnd)
   or (@dDate2  between dDateStart and dDateEnd)
   or (dDateStart between @dDate1 and @dDate2)
   or (dDateEnd  between @dDate1 and @dDate2)
	group by cGoodsNo,dDateStart,dDateEnd
	


  insert into #temp_PloyOfSale(cGoodsNo,dDateStart,dDateEnd,fSupRatio)
  select cGoodsNo,dDateStart=@dDate1,dDateEnd=@dDate2,fSupRatio=fRatio
  from t_Goods
  where cSupNo=@supNo and ISNULL(fRatio,0)>0 and cGoodsNo not in (select cGoodsNo from #temp_PloyOfSale)

	select  a.cGoodsNo,a.dDate_Sheet,a.fMoney_sale_distribute,
					a.fQty_Cost,a.bAuditing,b.dDateStart,b.dDateEnd,fSupRatio=isnull(b.fSupRatio,0)
	into #t_SaleSheetDetail_bybAuditing
	from #temp_Sale_Cost a
	left join #temp_PloyOfSale b on a.dDate_Sheet between b.dDateStart and b.dDateEnd
	     and b.cGoodsNo=a.cGoodsNo
  where isnull(a.bAuditing,0)=1 and b.dDateStart is not null
  
 

  update a
  set a.fMoney_Profit_sum=a.fMoney_Sale_distribute*b.fSupRatio/100.00,
  a.fMoney_Cost=a.fMoney_Sale_distribute*(1-b.fSupRatio/100.00),
  a.fProfit_1=a.fMoney_1*b.fSupRatio/100.00,
  a.fProfit_Ratio_1=a.fMoney_1*b.fSupRatio/100.00
  from #temp_Sale_Cost a,#t_SaleSheetDetail_bybAuditing b
  where a.cGoodsNo=b.cGoodsNo and a.dDate_Sheet between b.dDateStart and b.dDateEnd and isnull(a.bAuditing,0)=1
  
-- select * from #temp_Sale_Cost where cGoodsNo='36137'
/* 以上处理策略活动的毛利变动*/

  select cGoodsNo,cSupplierNo,cSupplier,fQty_Cost=sum(isnull(fQty_Cost,0)),
  fMoney_sale_distribute=sum(isnull(fMoney_sale_distribute,0)),
  fProfitRatio,
  fProfitRatio_avg=case when sum(isnull(fMoney_Sale_distribute,0))<>0
											  then sum(isnull(fMoney_Profit_sum,0))/sum(isnull(fMoney_Sale_distribute,0))*100 
									 else null end,
  fMoney_Profit_sum=sum(isnull(fMoney_Profit_sum,0)),
  fCostPrice=case when sum(isnull(fQty_Cost,0))<>0
											  then sum(isnull(fMoney_Cost,0))/sum(isnull(fQty_Cost,0))
									 else null end,
  fMoney_Cost=sum(isnull(fMoney_Cost,0)),
	fML=sum(isnull(fMoney_Profit_sum,0)),
  fMoney_0=sum(isnull(fMoney_0,0)),fProfit_0=sum(isnull(fProfit_0,0)),--正价销售、毛利
	fMoney_1=sum(isnull(fMoney_1,0)),fProfit_1=sum(isnull(fProfit_1,0)), --特价销售、毛利
  fProfit_Ratio_0=sum(isnull(fProfit_Ratio_0,0)),--正价扣点
	fProfit_Ratio_1=sum(isnull(fProfit_Ratio_1,0)) --特价扣点
  into #temp_Sale_Cost99
  from #temp_Sale_Cost
  group by cGoodsNo,cSupplierNo,cSupplier,fProfitRatio

  select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
				b.cGoodsTypeno,b.cGoodsTypename,bProducted=null,cProductNo=null,
        BeginDate=@dDate1,EndDate=@dDate2,a.cSupplierNo,cSupName=a.cSupplier,
        xsQty=isnull(a.fQty_Cost,0),xsMoney=isnull(a.fMoney_sale_distribute,0),
				a.fProfitRatio,a.fProfitRatio_avg,a.fMoney_Profit_sum,
				fCostPrice=case when isnull(a.fQty_Cost,0)<>0 
									      then a.fMoney_Cost/a.fQty_Cost else null end,
        a.fMoney_Cost,
				fML=a.fMoney_Profit_sum,a.fMoney_0,a.fProfit_0,a.fMoney_1,a.fProfit_1,a.fProfit_Ratio_0,a.fProfit_Ratio_1
  into #temp_goodsKuCun
  from #temp_Sale_Cost99 a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo



  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,fProfitRatio,fMoney_Profit_sum,fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),fML=isnull(xsMoney,0)-isnull(fMoney_Cost,0)
					,fMoney_0,fProfit_0,fMoney_1,fProfit_1,fProfit_Ratio_0,fProfit_Ratio_1
  into #temp_goodsKuCun_result
  from #temp_goodsKuCun
  where cSupplierNo=@supNo

  select	fMoney_Cost=sum(isnull(xsMoney,0))-sum(isnull(fProfit_0,0))-sum(isnull(fProfit_1,0)),fMoney_Profit_sum=sum(isnull(fMoney_Profit_sum,0)),
	xsMoney=sum(isnull(xsMoney,0)),fML=sum(isnull(fML,0)),fMoney_0=sum(isnull(fMoney_0,0)),
  fProfit=sum(isnull(fProfit_0,0))+sum(isnull(fProfit_1,0)),
	fProfit_0=sum(isnull(fProfit_0,0)),fMoney_1=sum(isnull(fMoney_1,0)),fProfit_1=sum(isnull(fProfit_1,0)),

  fProfit_Ratio=case when sum(isnull(xsMoney,0))<>0 
	then  (sum(isnull(fProfit_0,0))+sum(isnull(fProfit_1,0)))*100/sum(isnull(xsMoney,0)) 
  else 0
	end,
  fProfit_Ratio_0=sum(isnull(fProfit_Ratio_0,0)),fProfit_Ratio_1=sum(isnull(fProfit_Ratio_1,0)),
  fProfit_Ratio_koudian=sum(isnull(fProfit_Ratio_0,0))+sum(isnull(fProfit_Ratio_1,0)),
  cSupplierNo=@supNo
   into #temp_WhFromend_Output
	from #temp_goodsKuCun_result
	
 
-----------费用
 

----获得费用
if (select object_id('tempdb..#temp_SupplierFee_list'))is not null
drop table #temp_SupplierFee_list
create table #temp_SupplierFee_list
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,riqi1 datetime,riqi2 datetime,serno varchar(32),bJiesuan bit)
insert into #temp_SupplierFee_list(feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno,bJiesuan)

exec p_SumSupplierFee_list @supNo,@dDate1,@dDate2

------合并费用
declare @feiyongjine money

set @feiyongjine=(
select feiyongjine=SUM(feiyongjine) from #temp_SupplierFee_list)


update t_Supplier_fee set tempJiesuanno=null 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

update t_Supplier_fee set tempJiesuanno=@jiesuanNo 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

-------供应商获取租金
declare @feiyongZone money
if (select object_id('tempdb..#temp_Supplier_Zone'))is not null
drop table #temp_Supplier_Zone
create table #temp_Supplier_Zone
(cContractNo varchar(32),cZoneNo varchar(32),cZoneName varchar(64),feiyongjine money,riqi1 datetime,riqi2 datetime)
insert into #temp_Supplier_Zone(cContractNo,cZoneNo,cZoneName,feiyongjine,riqi1,riqi2)
exec p_SumSupplierZone_list @supNo,@dDate1,@dDate2

set @feiyongZone=(select SUM(feiyongjine) from #temp_Supplier_Zone)
 
update dbo.t_Zone_Contract_History  set tempJiesuanno=null 
where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate between @dDate1 and @dDate2

update dbo.t_Zone_Contract  set tempJiesuanno=null  
where  isnull(jiesuanover,0)=0 and cSupNo=@supNo	


update dbo.t_Zone_Contract_History  set tempJiesuanno=@jiesuanNo 
where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate between @dDate1 and @dDate2

update dbo.t_Zone_Contract  set tempJiesuanno=@jiesuanNo  
where  isnull(jiesuanover,0)=0 and cSupNo=@supNo	

----供应商支出
declare @feiyongPayout money
if (select object_id('tempdb..#temp_Supplier_Payout'))is not null
drop table #temp_Supplier_Payout
create table #temp_Supplier_Payout
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,serno varchar(32),riqi1 datetime,riqi2 datetime)

update t_Supplier_Payout set tempJiesuanno=null 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

insert into #temp_Supplier_Payout(feiyongno,feiyong,feiyongjine,serno,riqi1,riqi2)
exec p_SumSupplierPayout_list  @supNo,@dDate1,@dDate2

set @feiyongPayout=(select SUM(feiyongjine) from #temp_Supplier_Payout)

update t_Supplier_Payout set tempJiesuanno=@jiesuanNo 
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2
 
--- 供应商进账单

declare @feiyongIncome money
if (select object_id('tempdb..#temp_Supplier_Income'))is not null
drop table #temp_Supplier_Income
create table #temp_Supplier_Income
(feiyongno varchar(32),feiyong varchar(32),feiyongjine money,riqi1 datetime,riqi2 datetime,serno varchar(32))

update t_Supplier_Income set tempJiesuanno=null
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2

insert into #temp_Supplier_Income(feiyongno,feiyong,feiyongjine,riqi1,riqi2,serno)
exec p_SumSupplierIncome_list  @supNo,@dDate1,@dDate2

set @feiyongIncome=(select SUM(feiyongjine) from #temp_Supplier_Income)

update t_Supplier_Income set tempJiesuanno=@jiesuanNo
where  isnull(jiesuanover,0)=0 and cSupplierNo=@supNo and riqi2<=@dDate2
	
	if (select object_id('tempdb..#temp_SuperListOver'))is not null
begin 
    update a
    set a.jiesuanno=@jiesuanNo,a.xsMoney=b.xsMoney,a.截至期末库存金额=0,
    a.可销天数=0, 
    a.上月进货金额=0,
    a.上月返厂金额=0,
	a.未结算进货金额=0,a.未结算返厂金额=0,
	a.未结算差价金额=0,
	a.feiyongjine=isnull(@feiyongjine,0)+isnull(@feiyongPayout,0)+isnull(@feiyongIncome,0)+ISNULL(@feiyongZone,0),
	a.销售扣点金额=isnull(fProfit_Ratio_koudian,0), 
	a.预结算金额=(isnull(b.xsMoney,0)-isnull(fProfit_Ratio_koudian,0)-isnull(@feiyongPayout,0)-isnull(@feiyongIncome,0)-ISNULL(@feiyongZone,0)),	
	a.当前库存金额=0,
	a.预结进货金额=0,
	a.预结算入库单据='',
	
	a.xiaoshou_zj=b.fMoney_0,	 
	a.xiaoshou_tj=b.fMoney_1, 
    a.koudina_zj=b.fProfit_Ratio_0,
    a.koudian_tj=b.fProfit_Ratio_1,
    a.payoutMoney=isnull(@feiyongPayout,0),
    a.cZoneMoney=isnull(@feiyongZone,0),
    a.qtMoney=isnull(@feiyongIncome,0) 
    from #temp_SuperListOver a,#temp_WhFromend_Output b
    where a.cSupNo=b.cSupplierNo    
    
    
end

  drop table #temp_goodsKuCun_result
	drop table #temp_goodsKuCun
	drop table #temp_Sale_Cost99
	drop table #temp_SaleSheet_Day
	--group by 
  

 /*  
    declare @xiaoshou_zj_ratio money
    set @xiaoshou_zj_ratio=isnull((select sum(fKoudianMoney) from #Shanghu_hetong_Ratio),0)

		select supno=@supno,supname=@guizu,
					--	xiaoshou=@xiaoshou_zj+@xiaoshou_tj,
						xiaoshou=@xiaoshou,
						xiaoshou_ratio=@xiaoshou_zj_ratio+@xiaoshou_tj_ratio,
						xiaoshou_zj=@xiaoshou_zj,
						xiaoshou_zj_ratio=@xiaoshou_zj_ratio,
            xiaoshou_tj=@xiaoshou_tj,
						xiaoshou_tj_ratio= @xiaoshou_tj_ratio 
*/					 	
    return 1


	
end


GO
