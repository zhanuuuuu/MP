
/*
exec p_createJieSuanFilegroup 'PosManagement'
*/
/*
存储过程作用：
为指定数据库创建文件组
*/

create proc p_createJieSuanFilegroup
@MyDatebaseName varchar(64)
as
begin
exec('
	use '+@MyDatebaseName+'
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_01]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_02]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_03]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_04]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_05]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_06]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_07]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_08]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_09]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_10]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_11]
	
	alter database '+@MyDatebaseName+' add filegroup [jieSuan_12]
	
    alter database '+@MyDatebaseName+' add filegroup [FG_jieSuan]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_01'',
		filename=''e:\SQL_jieSuan\jieSuan_01.ndf''
	)to filegroup [jieSuan_01]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_02'',
		filename=''e:\SQL_jieSuan\jieSuan_02.ndf''
	)to filegroup [jieSuan_02]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_03'',
		filename=''e:\SQL_jieSuan\jieSuan_03.ndf''
	)to filegroup [jieSuan_03]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_04'',
		filename=''e:\SQL_jieSuan\jieSuan_04.ndf''
	)to filegroup [jieSuan_04]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_05'',
		filename=''e:\SQL_jieSuan\jieSuan_05.ndf''
	)to filegroup [jieSuan_05]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_06'',
		filename=''e:\SQL_jieSuan\jieSuan_06.ndf''
	)to filegroup [jieSuan_06]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_07'',
		filename=''e:\SQL_jieSuan\jieSuan_07.ndf''
	)to filegroup [jieSuan_07]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_08'',
		filename=''e:\SQL_jieSuan\jieSuan_08.ndf''
	)to filegroup [jieSuan_08]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_09'',
		filename=''e:\SQL_jieSuan\jieSuan_09.ndf''
	)to filegroup [jieSuan_09]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_10'',
		filename=''e:\SQL_jieSuan\jieSuan_10.ndf''
	)to filegroup [jieSuan_10]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_11'',
		filename=''e:\SQL_jieSuan\jieSuan_11.ndf''
	)to filegroup [jieSuan_11]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_12'',
		filename=''e:\SQL_jieSuan\jieSuan_12.ndf''
	)to filegroup [jieSuan_12]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_a'',
		filename=''e:\SQL_jieSuan\jieSuan_a.ndf''
	)to filegroup [FG_jieSuan]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_b'',
		filename=''e:\SQL_jieSuan\jieSuan_b.ndf''
	)to filegroup [FG_jieSuan]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_c'',
		filename=''e:\SQL_jieSuan\jieSuan_c.ndf''
	)to filegroup [FG_jieSuan]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''jieSuan_d'',
		filename=''e:\SQL_jieSuan\jieSuan_d.ndf''
	)to filegroup [FG_jieSuan]
	
')
end


GO
