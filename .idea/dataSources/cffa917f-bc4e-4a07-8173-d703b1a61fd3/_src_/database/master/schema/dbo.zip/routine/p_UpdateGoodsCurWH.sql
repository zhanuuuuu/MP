/*
select *
from t_GOods
where cGoodsNo in
(
select cGoodsNo from  t_Goods_curWH
where fQty_CurWH<0
)

select *
from t_CheckTast_GoodsDetail
where cGoodsNo in
(
select cGoodsNo from  t_Goods_curWH
where fQty_CurWH<0
)

select *
from t_CheckTast_GoodsDetail
where cGoodsNo='42001084'

select *
from t_Goods_curWH
where cGoodsNo='42001084'

select *
from t_Goods
where cGoodsNo='42001084'

	select cGoodsNo,fQty_Rbd=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_RbdWarehouseDetail
	where cGoodsNo='42001084'
	group by cGoodsNo
	
	select *
	from dbo.wh_RbdWarehouseDetail
	where cGoodsNo='42001084'
select * from wh_RbdWarehouse
where cSheetno='RB20114018-000002'

	select *
	from dbo.wh_RbdWarehouseDetail
	where cSheetno='RB20114018-000002'
	
select *
from dbo.t_Cost_distribute
where cGoodsNo='42001082'
and iAttribute=2	

select *
from dbo.t_Cost_distribute
where cGoodsNo='42001084'
and iAttribute=2

p_UpdateGoodsCurWH '01'
*/

CREATE procedure [dbo].[p_UpdateGoodsCurWH]
@cWhNo varchar(32)
as
begin

    declare @MaxDailyDate datetime
    set @MaxDailyDate=(
    select MAX(dDate) from t_Daily_history)

	update a
	set 
	a.fQty_In=b.fQty_In,
	a.fQty_TfrIn=c.fQty_TfrIn,
	a.fQty_Return=d.fQty_Return,
	a.fQty_Effusion=e.fQty_Effusion,
	a.fQty_Divide=f.fQty_Divide,
	a.fQty_Pack=g.fQty_Pack,
	a.fQty_Out=h.fQty_Out,
	a.fQty_trf=i.fQty_trf,
	a.fQty_Rbd=j.fQty_Rbd,
	a.fQty_Exchange=k.fQty_Exchange,
	a.fQty_Loss=l.fQty_Loss,
	a.fQty_sale=m.fQty_sale

	from dbo.t_Goods_CurWH a
	left join
	(
	select cGoodsNo,fQty_in=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_InWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_InWarehouse 
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) b 
	on a.cGoodsNo=b.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_TfrIn=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_TfrInWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_TfrInWarehouse 
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) c
	on a.cGoodsNo=c.cGoodsNo

	left join

	(
	select cGoodsNo,fQty_Return=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.WH_ReturnGoodsDetail
	where  cSheetno in 
		(select cSheetno from dbo.WH_ReturnGoods 
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) d
	on a.cGoodsNo=d.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Effusion=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_EffusionWhDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_EffusionWh 
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) e
	on a.cGoodsNo=e.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Divide=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_DivideWhDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_Divide
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) f
	on a.cGoodsNo=f.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Pack=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_PackDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_Pack
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)

	group by cGoodsNo
	) g
	on a.cGoodsNo=g.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Out=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_OutWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_OutWarehouse
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) h
	on a.cGoodsNo=h.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_trf=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_TfrWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_TfrWarehouse
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) i
	on a.cGoodsNo=i.cGoodsNo

	left join

	(
	select cGoodsNo,fQty_Rbd=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_RbdWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_RbdWarehouse
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) j
	on a.cGoodsNo=j.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Exchange=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_ExchangeDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_Exchange
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) k
	on a.cGoodsNo=k.cGoodsNo

	left join
	(
	select cGoodsNo,fQty_Loss=isnull(sum(isnull(fQuantity,0)),0)
	from dbo.wh_LossWarehouseDetail
	where  cSheetno in 
		(select cSheetno from dbo.wh_LossWarehouse
		where isnull(bExamin,0)=1 and cWhNo=@cWhNo)
	group by cGoodsNo
	) l
	on a.cGoodsNo=l.cGoodsNo
	left join
	(
	  --  select cGoodsNo,fQty_sale=sum(fQty_sale) 
	  --  from (
			--select cGoodsNo,fQty_sale=sum(fQuantity) 
			--from t_SaleSheet_Day 
			--where dSaleDate<=@MaxDailyDate
			--and cWhNo=@cWhNo
			--group by cGoodsNo	
			--union all
			--select cGoodsNo,SUM(fQuantity)
			--from t_SaleSheetDetail
			--where dSaleDate>@MaxDailyDate 
			--and cWhNo=@cWhNo
			--group by cGoodsNo	
		 -- ) aa
		 -- group by cGoodsNo	
		 
		
			select cGoodsNo,fQty_sale=SUM(fQuantity)
			from t_SaleSheetDetail
			where cWhNo=@cWhNo
			group by cGoodsNo	
		  
	) m
	on a.cGoodsNo=m.cGoodsNo
	
	
	update t_Goods_CurWH
	set 
	fQty_CurWH=isnull(fQty_In,0)
	+isnull(fQty_TfrIn,0)
	+isnull(fQty_Return,0)
	+isnull(fQty_Effusion,0)
	+isnull(fQty_Divide,0)
	-isnull(fQty_Pack,0)
	-isnull(fQty_Out,0)
	-isnull(fQty_trf,0)
	-isnull(fQty_Rbd,0)
	-isnull(fQty_Exchange,0)
	-isnull(fQty_Loss,0)
	-isnull(fQty_sale,0)
	+isnull(fQty_Check_Diff,0)

end


GO
