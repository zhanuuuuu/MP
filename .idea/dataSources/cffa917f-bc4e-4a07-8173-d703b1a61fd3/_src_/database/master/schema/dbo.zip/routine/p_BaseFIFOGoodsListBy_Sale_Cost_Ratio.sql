/*
待查商品表 #t_goods(cGoodsNo)
if(select object_id('tempdb..#t_goods'))is not null
drop table #t_goods   
select cGoodsNo 
into #t_goods
from t_goods where cGoodsNo='10251001'

返回值说明 返回商品时段合计
(cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,bAuditing,fQuantity,fLastSettle,fMoneyCost,fMoneyRatio,fRatio)
cGoodsNo,
cSupNO,
cGoodsTypeNo,
cGoodsTypeName,
fQuantity       时段销售数量合计
fLastSettle     时段销售金额合计
fMoneyCost      时段销售成本合计
fMoneyRatio     时段销售毛利合计
fRatio          时段销售毛利率
bAuditing       是否特价(1特价)
成本参考：成本表+供应商扣率+策略扣率

p_BaseFIFOGoodsListBy_Sale_Cost_Ratio '2010-09-18','2010-09-18','01'

*/
CREATE proc [dbo].[p_BaseFIFOGoodsListBy_Sale_Cost_Ratio]
@dDateBgn datetime,  --时段开始日期
@dDateEnd datetime,  --时段截止日期
@cWhNo varchar(32)
as
--select @dDateBgn='2010-09-18',@dDateEnd='2010-09-22'
--SET @cWhNo='01'


if (select object_id('tempdb..#tmp_saleSheetDay'))is not null
drop table #tmp_saleSheetDay
if (select object_id('tempdb..#tmpCostPrice'))is not null
drop table #tmpCostPrice
if (select object_id('tempdb..#tmpCostMoney'))is not null
drop table #tmpCostMoney
if (select object_id('tempdb..#TmpGoodsBaseInfo'))is not null
drop table #TmpGoodsBaseInfo
if (select object_id('tempdb..#tmpSupTotal0'))is not null
drop table #tmpSupTotal0
if (select object_id('tempdb..#tmpSupTotal1'))is not null
drop table #tmpSupTotal1
if (select object_id('tempdb..#tmpSupSaleDay0'))is not null
drop table #tmpSupSaleDay0
if (select object_id('tempdb..#tmpSupSaleDay1'))is not null
drop table #tmpSupSaleDay1
if (select object_id('tempdb..#TmpGoodsBaseInfo1'))is not null
drop table #TmpGoodsBaseInfo1




declare @dDate_daily datetime  --日结日期
declare @dDate_account datetime  --日结日期

select @dDate_daily=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history
where isnull(cWHNO,'')=@cWhNo


select @dDate_account=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history 
where ISNULL(bAccount,0)=1
and isnull(cWHNO,'')=@cWhNo


--取商品(管理库存，未管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null
drop table #tmpPloyOfGoodsinfo
select distinct a.cGoodsNo
into #tmpPloyOfGoodsinfo
from #t_goods a,t_goods b 
where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1

if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfoNull'))is not null
drop table #tmpPloyOfGoodsinfoNull
select distinct a.cGoodsNo
into #tmpPloyOfGoodsinfoNull
from #t_goods a,t_goods b
where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0


--未日结商品，从成本分配表中找最近一次成本
if (select OBJECT_ID('tempdb..#tmpNoExistDailyGoods0'))is not null
drop table #tmpNoExistDailyGoods0

select a.cGoodsNo,b.cSupNo,fPrice_Cost=c.fPrice_In
into #tmpNoExistDailyGoods0
from #tmpPloyOfGoodsinfo a left join 
(
   select cGoodsNO,cSupNO=cSupplierNo,iMaxISerNo=max(iSerNo)
   from t_Wh_Form
   where dDateTime<=@dDate_account and isnull(cWhNo,'')=@cWhNo
   group by cGoodsNO,cSupplierNo
) b
on a.cGoodsNo=b.cGoodsNo
left join t_Wh_Form c
on b.cGoodsNO=c.cGoodsNO and b.iMaxISerNo=c.iSerNo and c.dDateTime<=@dDate_account
and isnull(c.cWhNo,'')=@cWhNo

--如果此商品一直未记账，则更新供应商为主供应商
update a
set a.cSupNO=b.cSupNo
from #tmpNoExistDailyGoods0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo
and a.cSupNo is null

update a
set a.fPrice_Cost=b.fCKPrice
from #tmpNoExistDailyGoods0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo 
and a.fPrice_Cost is null

--日结表中更改库存标志商品
/*
if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange0'))is not null
drop table #tmpGoodsStorageChange0
select cGoodsNo,countNum=count(distinct bstorage)
into #tmpGoodsStorageChange0
from t_saleSheet_Day
group by cGoodsNo having(count(distinct bstorage))>1
*/
/*--------修改 上面--------*/
if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange0'))is not null
drop table #tmpGoodsStorageChange0
create table #tmpGoodsStorageChange0(cGoodsNo varchar(32),countNum int)

--exec p_SupSale_Day

if (select OBJECT_ID('tempdb..#tmp_SaleSheetInfor'))is not null
drop table #tmp_SaleSheetInfor
create table #tmp_SaleSheetInfor(cGoodsNo varchar(32),countNum int)

				  declare SaleSheetInfor_cursor1 cursor
				  for
				  select databasename
				  from t_SaleSheetInfor
				 
				  declare @InfoName1 varchar(32)

				  open SaleSheetInfor_cursor1
				  fetch next from SaleSheetInfor_cursor1
				  into @InfoName1

				  while @@fetch_status=0
				  begin					
                    exec('				
					    insert into #tmp_SaleSheetInfor(cGoodsNo,countNum)
						select cGoodsNo,countNum=count(distinct bstorage)
						from '+@InfoName1+'.dbo.t_SaleSheet_Day 
					    group by cGoodsNo having(count(distinct bstorage))>1
					  ')					  
					fetch next from SaleSheetInfor_cursor1
					into @InfoName1
				  end

				  close SaleSheetInfor_cursor1
				  deallocate SaleSheetInfor_cursor1
				  
                insert into #tmp_SaleSheetInfor(cGoodsNo,countNum)
				select cGoodsNo,countNum=count(distinct bstorage)
				from dbo.t_SaleSheet_Day 
			    group by cGoodsNo having(count(distinct bstorage))>1
			    
		insert into #tmpGoodsStorageChange0			    
		select 	 cGoodsNo,countNum=SUM(countNum) from #tmp_SaleSheetInfor	   
		group by cGoodsNo 

---------------------------------
if (select OBJECT_ID('tempdb..#tmpGoodsStorageChange'))is not null
drop table #tmpGoodsStorageChange
select a.cGoodsNO
into #tmpGoodsStorageChange
from #tmpGoodsStorageChange0 a,t_goods b
where a.cGoodsNo=b.cGoodsNO and isnull(b.bStorage,0)=1

--************--从各个分库中获取总数--****************

------*********从各个分开中取数据*********--------
----- 销售表
 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fPrice money,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
 ------  日结表 

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fNormalPrice money,fLastSettle money ,bauditing bit,bStorage bit,cWHno varchar(32))
------  成本表

    if(select object_id('tempdb..#temp_Cost_distribute')) is not null drop table #temp_Cost_distribute
	create table #temp_Cost_distribute(dDate_Sheet datetime,cGoodsNo varchar(32),
	fPrice_Cost money ,fQty_Cost money,fMoney_Cost money,iLineNo int,fPrice_sale money,fMoney_sale money,
	iAttribute int ,bdone bit,iSerNo bigint,cWHno varchar(32))
	
	exec p_SupSale_Ref @dDateBgn,@dDateEnd,@cWhNo
	----------------------------

--商品成本表链接日结表，日结表中取出是否为特价
if (select OBJECT_ID('tempdb..#tmpPloyOfGoods_Money0'))is not null
drop table #tmpPloyOfGoods_Money0

select b.dDate_Sheet,a.cGoodsNo,cSupNo=t.cSupplierNo,b.fPrice_Cost,b.fQty_Cost,
b.fMoney_Cost,b.iLineNo,b.fPrice_sale,b.fMoney_sale,bAuditing=ISNULL(c.bauditing,0),
bDaily=1,iType=0
into #tmpPloyOfGoods_Money0
from #tmpPloyOfGoodsinfo a left join t_Cost_distribute b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=10 and ISNULL(b.bdone,0)=0
left join ---t_SaleSheet_Day c
#temp_SaleSheet_Day c
on b.dDate_Sheet=c.dSaleDate and b.iLineNo=c.iSeed and b.cGoodsNo=c.cGoodsNo
and b.cWhNo=c.cWHno
left join t_Wh_Form t
on b.iSerNo=t.iSerNo and b.cGoodsNo=t.cGoodsNo
where  b.dDate_Sheet between @dDateBgn and @dDateEnd
       and dDate_Sheet<=@dDate_account
       and isnull(b.cWhNo,'')=@cWhNo
       

union all  --日结但未记账的商品(销售)
select b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfo a left join ---t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between @dDateBgn and @dDateEnd
and b.dSaleDate>=@dDate_account+1
and b.dSaleDate<=@dDate_daily
and isnull(b.cWhNo,'')=@cWhNo

union all  --未日结的商品从销售单中取
select b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfo a left join --t_SaleSheetDetail b
#temp_salesheetDetail b
on  a.cGoodsNo=b.cGoodsNo
where b.dSaleDate between @dDateBgn and @dDateEnd
and b.dSaleDate>=@dDate_daily+1
and isnull(b.cWhNo,'')=@cWhNo

union all --前台销售退货
select b.dDateTime,a.cGoodsNo,b.cSupplierNo,b.fPrice_In,-b.fQty_In,
-b.fMoney_In,b.iLineNo,c.fNormalPrice,-c.fLastSettle,bAuditing=ISNULL(c.bauditing,0),
bDaily=1,iType=0
from #tmpPloyOfGoodsinfo a left join T_WH_Form b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=13 
left join --t_SaleSheet_Day c
#temp_SaleSheet_Day c
on b.dDateTime=c.dSaleDate and b.iLineNo=c.iSeed and b.cGoodsNo=c.cGoodsNo
and b.cWhNo=c.cWHno
where b.dDateTime between @dDateBgn and @dDateEnd
and b.dDateTime<=@dDate_account
and isnull(b.cWhNo,'')=@cWhNo


union all --已记账顾客退货
select b.dDateTime,a.cGoodsNo,b.cSupplierNo,b.fPrice_In,-b.fQty_In,
-b.fMoney_In,b.iLineNo,c.fInPrice,-c.fInMoney,bAuditing=0,
bDaily=1,iType=1
from #tmpPloyOfGoodsinfo a left join T_WH_Form b
on a.cGoodsNo=b.cGoodsNo and ISNULL(b.iAttribute,0)=3 
left join WH_ReturnGoodsDetail c
on b.iLineNo=c.iLineNo and b.cSheetNo=c.cSheetNo and b.cGoodsNo=c.cGoodsNo
where b.dDateTime between @dDateBgn and @dDateEnd
and isnull(b.cWhNo,'')=@cWhNo


union all --未记账顾客退货
select c.dDate,a.cGoodsNo,null,null,fQuantity=-isnull(b.fQuantity,0),
null,b.iLineNo,fPrice=isnull(b.fInPrice,0),fLastSettle=-isnull(b.fInMoney,0),
bAuditing=0,bDaily=0,iType=1
from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
where c.dDate between @dDateBgn and @dDateEnd and isnull(c.baccount,0)=0
and isnull(c.cWhNo,'')=@cWhNo

--不管理库存商品
union all  
select b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfoNull a left join ---t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo
where b.dSaleDate between @dDateBgn and @dDateEnd 
and b.dSaleDate<=@dDate_daily
and isnull(b.fQuantity,0)<>0 
and isnull(b.cWhNo,'')=@cWhNo


union all  
select b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpPloyOfGoodsinfoNull a left join --t_SaleSheetDetail b
#temp_salesheetDetail b
on  a.cGoodsNo=b.cGoodsNo
where b.dSaleDate between @dDateBgn and @dDateEnd 
and b.dSaleDate>=@dDate_daily+1
and isnull(b.cWhNo,'')=@cWhNo

union all 
select c.dDate,a.cGoodsNo,null,null,fQuantity=-isnull(b.fQuantity,0),
null,b.iLineNo,fPrice=isnull(b.fInPrice,0),fLastSettle=-isnull(b.fInMoney,0),
bAuditing=0,bDaily=0,iType=1
from #tmpPloyOfGoodsinfoNull a left join WH_ReturnGoodsDetail b
on  a.cGoodsNo=b.cGoodsNo
left join WH_ReturnGoods c
on b.cSheetNo=c.cSheetNo
where c.dDate between @dDateBgn and @dDateEnd 
and isnull(c.cWhNo,'')=@cWhNo

--以前管理库存，现更改为不管理库存的商品

union all 
select b.dSaleDate,a.cGoodsNo,null,null,fQuantity=isnull(b.fQuantity,0),
null,b.iSeed,fPrice=isnull(b.fNormalPrice,0),fLastSettle=isnull(b.fLastSettle,0),
bAuditing=ISNULL(b.bauditing,0),bDaily=0,iType=0
from #tmpGoodsStorageChange a left join --t_SaleSheet_Day b
#temp_SaleSheet_Day b
on  a.cGoodsNo=b.cGoodsNo
where isnull(b.fQuantity,0)<>0
and b.dSaleDate between @dDateBgn and @dDateEnd
and isnull(b.bStorage,0)=0
and isnull(b.cWhNo,'')=@cWhNo

update a
set a.cSupNo=b.cSupNo
from #tmpPloyOfGoods_Money0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo
and a.cSupNo is null
--更新未记账商品的成本，销售
update a
set a.fPrice_Cost=b.fPrice_Cost,fMoney_Cost=isnull(b.fPrice_Cost,0)*isnull(a.fqty_Cost,0)
from #tmpPloyOfGoods_Money0 a,#tmpNoExistDailyGoods0 b
where a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
and bDaily=0 

update a
set a.fPrice_Cost=b.fCKPrice,fMoney_Cost=isnull(b.fCKPrice,0)*isnull(a.fqty_Cost,0)
from #tmpPloyOfGoods_Money0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo
and a.fPrice_Cost is null

--------从分库 总获取数据---------------------------**********************************************************


--不管理库存商品成本金额=销售金额
update a
set fMoney_Cost=fMoney_sale
from #tmpPloyOfGoods_Money0 a,t_goods b
where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0


--获取供应商最小扣率
if (select OBJECT_ID('tempdb..#tmpPloy_SupMinRatio'))is not null
drop table #tmpPloy_SupMinRatio
select a.guizuno,a.fRatio
into #tmpPloy_SupMinRatio
from t_Supplier_Contract_Ratio a,
(
   select guizuno,fMoney1=MIN(fMoney1)
   from t_Supplier_Contract_Ratio 
   where isnull(fRatio,0)<>0
   group by guizuno
 )b
where a.guizuno=b.guizuno and a.fMoney1=b.fMoney1

--获取供应商扣率
update a
set a.fMoney_Cost=((100.00-b.fRatio)/100.00)*a.fMoney_Sale
from #tmpPloyOfGoods_Money0 a,#tmpPloy_SupMinRatio b
where a.cSupNo=b.guizuno 
and isnull(b.fRatio,0)<>0


--策略扣率
  if (select OBJECT_ID('tempdb..#temp_PloyOfSale'))is not null
  drop table #temp_PloyOfSale
  if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_bybAuditing'))is not null
  drop table #t_SaleSheetDetail_bybAuditing
  select cGoodsNo,dDateStart,dDateEnd,fSupRatio=max(fSupRatio)
  into #temp_PloyOfSale
  from t_PloyOfSale
  where (
            (dDateStart between @dDateBgn and @dDateEnd)
            or 
            (dDateEnd  between @dDateBgn and @dDateEnd)
        )and isnull(fSupRatio,0)<>0
  group by cGoodsNo,dDateStart,dDateEnd

  select  a.cGoodsNo,a.dDate_Sheet,a.fMoney_sale,
		  a.fQty_Cost,a.bAuditing,b.dDateStart,b.dDateEnd,fSupRatio=isnull(b.fSupRatio,0)
  into #t_SaleSheetDetail_bybAuditing
  from #tmpPloyOfGoods_Money0 a left join #temp_PloyOfSale b 
  on a.dDate_Sheet between b.dDateStart and b.dDateEnd
  and b.cGoodsNo=a.cGoodsNo
  where isnull(a.bAuditing,0)=1 and b.dDateStart is not null

  update a
  set a.fMoney_Cost=a.fMoney_Sale*(1-b.fSupRatio/100.00)
  from #tmpPloyOfGoods_Money0 a,#t_SaleSheetDetail_bybAuditing b
  where a.cGoodsNo=b.cGoodsNo and a.dDate_Sheet between b.dDateStart and b.dDateEnd 
  and isnull(a.bAuditing,0)=1

------------------------------------------------------------------------------------------------------
--select * from #tmpPloyOfGoods_Money0  where cgoodsno='22051025'
--select * from #t_SaleSheetDetail_bybAuditing where cgoodsno='22051025'
---------------------------------------------------------------------------------------------
--转换为单品
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null
drop table #tmpPackGoodsList
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

update a
set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQty_Cost=a.fQty_Cost*b.fQty_minPackage
from #tmpPloyOfGoods_Money0 a,#tmpPackGoodsList b
where a.cGoodsNO=b.cGoodsNO

select dSaleDate=dDate_Sheet,cGoodsNo,fQuantity=fQty_Cost,fLastSettle=isnull(fMoney_sale,0),
fCostPrice=fPrice_Cost,fMoneyCost=isnull(fMoney_Cost,0),bAuditing
into #tmpCostMoney
from #tmpPloyOfGoods_Money0


select a.dSaleDate,a.cGoodsNo,b.cSupNo,b.cGoodsTypeNo,b.cGoodsTypeName,
a.fQuantity,a.fLastSettle,a.fMoneyCost,bAuditing,
fMoneyRatio=isnull(a.fLastSettle,0)-isnull(a.fMoneyCost,0),
fRatio=((a.fLastSettle-a.fMoneyCost)/case when isnull(a.fLastSettle,0)<>0 then a.fLastSettle 
                                     else null end)*100
into #TmpGoodsBaseInfo  
from #tmpCostMoney a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
where b.cGoodsNo is not null


select cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,bAuditing,fQuantity=sum(isnull(fQuantity,0)),
fLastSettle=sum(isnull(fLastSettle,0)),fMoneyCost=sum(isnull(fMoneyCost,0)),
fMoneyRatio=sum(isnull(fMoneyRatio,0)),
fRatio=case when sum(isnull(fLastSettle,0))<>0 then sum(isnull(fMoneyRatio,0))/sum(isnull(fLastSettle,0))*100.00
            else null end
from #TmpGoodsBaseInfo
group by cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,bAuditing
order by cGoodsNo,cSupNO,bAuditing


GO
