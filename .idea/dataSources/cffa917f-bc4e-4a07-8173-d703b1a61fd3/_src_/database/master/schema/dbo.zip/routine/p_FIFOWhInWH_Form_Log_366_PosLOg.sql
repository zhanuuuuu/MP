
/*

  declare @d1 datetime 
  declare @d2 datetime 
  declare @i int
  set @d1='2015-12-19'
  set @d2='2015-12-19'
  set @i=1
  while @d1<=@d2
  begin   
	  declare @return int
	  exec p_FIFOWhInWH_Form_Log_366_PosLOg @d1,@return output
	  select @return ,@d1
	  
	  set @d1=@d1+1
  end
 
*/
CREATE proc [dbo].[p_FIFOWhInWH_Form_Log_366_PosLOg]
@SheetDate datetime,
@return int output
as 
declare @SheetDate_1 datetime 
set @SheetDate_1=@SheetDate-1
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@SheetDate)
set @Day1=day(@SheetDate)
set @Y1=YEAR(@SheetDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @M_1=MONTH(@SheetDate_1)
set @Day_1=day(@SheetDate_1)
set @Y_1=YEAR(@SheetDate_1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1


declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@SheetDate set @dDateEnd=@SheetDate  

declare @PosWhName varchar(32)
set @PosWhName=(select top 1 Pos_WH_Form from t_WareHouse where isnull(Pos_WH_Form,'')<>'')
 
exec('
    update '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' set fQtytj_'+@MMDAY1+'=null,fQty_'+@MMDAY1+'=null
    where cYear='''+@Y1+'''
')
exec('
    update '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' set Saletj_'+@MMDAY1+'=null,Sale_'+@MMDAY1+'=null
    where cYear='''+@Y1+'''
    ')
exec('
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' set fQty_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+'  set Sale_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' set Qty_'+@MMDAY1+'=null,Qtyzs_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M1+'  set fQty_'+@MMDAY1+'=null,fMoney_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null  
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'  set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null 
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''
	')
exec('
	update '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
 ')
exec('
	update '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+'  set fQtyIn_'+@MMDAY1+'=null,fMoneyIn_'+@MMDAY1+'=null
	where cYear='''+@Y1+'''

    ')

begin try
 begin tran

-------经销管理库存------
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,扣率金额 money,
  fQty_Left money, fPrice_Left money, fMoney_Left money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
 入库数量1 money, 入库金额1 money, 报溢数量1 money, 报溢金额1 money, 退货入库数量1 money, 退货入库金额1 money, 
  调拨入库数量1 money, 调拨入库金额1 money, Pos客退数量1 money, Pos客退金额1 money, 出库数量0 money, 出库金额0 money, 
  报损数量0 money, 报损金额0 money, 返厂数量0 money, 返厂金额0 money, 调拨出库数量0 money, 调拨出库金额0 money, 差价数量 money, 
  差价金额 money, 原料出库数量0 money, 原料出库金额0 money, 成品入库数量1 money, 成品入库金额1 money, 销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,扣率金额 money,
  fQty_Left money, fPrice_Left money, fMoney_Left money)
  
/*快照表中的最大日期。。。*/

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo) 
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@SheetDate-1)
set @strDateEnd=dbo.getdaystr(@SheetDate)
set @strBgn=dbo.getdaystr(@dDateBgn)
--print  dbo.getTimeStr(GETDATE())
--print  1
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
	select 业务日期,b.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
	b.特价销售数量, b.特价销售金额, 
	b.正价销售数量, b.正价销售金额,
	b.Pos客退数量1, b.Pos客退金额1,
	b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
	b.退货入库数量1, b.退货入库金额1, 
	b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
	b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
	b.调拨出库数量0, b.调拨出库金额0, 
	b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
	b.成品入库数量1, b.成品入库金额1, 
	b.本日库存数量, b.盘点数量,
	b.fPrice_In,
	fmoney_cost=b.fPrice_In*b.销售数量0,
	fml=b.销售金额0-b.fPrice_In*b.销售数量0,
	b.fQty_Left, b.fMoney_Left 
	into #temp_Wh_Goods_begin 
	from  '+@PosWhName+'.dbo.t_WH_Form_log_1 b
	with (nolock) 
	where b.业务日期='''+@strDateBgn+'''  

	union all             
	select 业务日期,b.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
	b.特价销售数量, b.特价销售金额, 
	b.正价销售数量, b.正价销售金额,
	b.Pos客退数量1, b.Pos客退金额1,
	b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
	b.退货入库数量1, b.退货入库金额1, 
	b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
	b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
	b.调拨出库数量0, b.调拨出库金额0, 
	b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
	b.成品入库数量1, b.成品入库金额1, 
	b.本日库存数量, b.盘点数量,
	b.fPrice_In,
	fmoney_cost=b.fPrice_In*b.销售数量0,
	fml=b.销售金额0-b.fPrice_In*b.销售数量0,
	b.fQty_Left, b.fMoney_Left  				 
	from  '+@PosWhName+'.dbo.t_WH_Form_log_0 b
	with (nolock) 
	where b.业务日期='''+@strDateBgn+'''  
	and  b.iAttribute<>20				  



	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
	select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
	特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
	正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
	Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
	入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
	报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
	退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
	调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
	出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
	报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
	返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
	调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
	差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
	原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
	成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
	本日库存数量=SUM(isnull(本日库存数量,0)), 
	盘点数量=SUM(isnull(盘点数量,0)),
	fPrice_Avg=AVG(fPrice_In),
	fmoney_cost=sum(fmoney_cost),
	fml=SUM(fml),
	fQty_Left=sum(fQty_Left),fMoney_Left=sum(fMoney_Left) 
	into #temp_SumWh_Goods_begin
	from #temp_Wh_Goods_begin
	group by cgoodsno,cSupplierNo,cWHno		


	insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	Pos客退数量1,Pos客退金额1,入库数量1,入库金额1,报溢数量1,报溢金额1,退货入库数量1,退货入库金额1,调拨入库数量1,调拨入库金额1,
	出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
	成品入库数量1,成品入库金额1,本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fml,fQty_Left,fMoney_Left)
	select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	Pos客退数量1,Pos客退金额1,入库数量1,入库金额1,报溢数量1,报溢金额1,退货入库数量1,退货入库金额1,调拨入库数量1,调拨入库金额1,
	出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
	成品入库数量1,成品入库金额1,本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml,fQty_Left,fMoney_Left
	from #temp_SumWh_Goods_begin
			  
			 ' )
--print  dbo.getTimeStr(GETDATE())
--print  2
exec('
			 if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select 业务日期,b.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
			 b.特价销售数量, b.特价销售金额, 
			 b.正价销售数量, b.正价销售金额,
			 b.Pos客退数量1, b.Pos客退金额1,
			 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
			 b.退货入库数量1, b.退货入库金额1, 
			 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
			 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
			 b.调拨出库数量0, b.调拨出库金额0, 
			 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
			 b.成品入库数量1, b.成品入库金额1, 
			 b.本日库存数量, b.盘点数量,
			 b.fPrice_In,
			   fmoney_cost=b.fPrice_In*b.销售数量0,
			   fml=b.销售金额0-b.fPrice_In*b.销售数量0,
			    b.fQty_Left,b.fMoney_Left
			  into #temp_Wh_Goods_end					 
				from  '+@PosWhName+'.dbo.t_WH_Form_log_1 b
				 with (nolock) 
			  where b.业务日期='''+@strDateEnd+'''  
			  union all             
			  select 业务日期,b.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
			 b.特价销售数量, b.特价销售金额, 
			 b.正价销售数量, b.正价销售金额,
			 b.Pos客退数量1, b.Pos客退金额1,
			 b.入库数量1, b.入库金额1, b.报溢数量1, b.报溢金额1, 
			 b.退货入库数量1, b.退货入库金额1, 
			 b.调拨入库数量1, b.调拨入库金额1,  b.出库数量0, b.出库金额0, 
			 b.报损数量0, b.报损金额0, b.返厂数量0, b.返厂金额0, 
			 b.调拨出库数量0, b.调拨出库金额0, 
			 b.差价数量, b.差价金额, b.原料出库数量0, b.原料出库金额0, 
			 b.成品入库数量1, b.成品入库金额1, 
			 b.本日库存数量, b.盘点数量,
			 b.fPrice_In,
			   fmoney_cost=b.fPrice_In*b.销售数量0,
			   fml=b.销售金额0-b.fPrice_In*b.销售数量0 ,b.fQty_Left,b.fMoney_Left 
			from  '+@PosWhName+'.dbo.t_WH_Form_log_0 b
			with (nolock) 
			  where  b.业务日期 between '''+@strDateBgn+'''  and '''+@strDateEnd+'''  
			  and  b.iAttribute<>20
 
			       
             if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		         select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
				  特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
				  正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),
				Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
				入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
				报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
				退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
				  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  
				  出库数量0=SUM(isnull(出库数量0,0)), 出库金额0=SUM(isnull(出库金额0,0)), 
				  报损数量0=SUM(isnull(报损数量0,0)), 报损金额0=SUM(isnull(报损金额0,0)), 
				  返厂数量0=SUM(isnull(返厂数量0,0)), 返厂金额0=SUM(isnull(返厂金额0,0)), 
				  调拨出库数量0=SUM(isnull(调拨出库数量0,0)), 调拨出库金额0=SUM(isnull(调拨出库金额0,0)), 
				  差价数量=SUM(isnull(差价数量,0)), 差价金额=SUM(isnull(差价金额,0)), 
				  原料出库数量0=SUM(isnull(原料出库数量0,0)), 原料出库金额0=SUM(isnull(原料出库金额0,0)), 
				  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0)), 
				   本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
				   fPrice_Avg=AVG(fPrice_In),
				   fmoney_cost=sum(fmoney_cost),
				   fml=SUM(fml),fQty_Left=sum(fQty_Left),fMoney_Left=sum(fMoney_Left)
				   into #temp_SumWh_Goods_end
					from #temp_Wh_Goods_end
	              group by cgoodsno,cSupplierNo,cWHno	
	              
     
			  insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
			  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
			  本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fml,fQty_Left,fMoney_Left)
			  select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
			  出库数量0,出库金额0,报损数量0,报损金额0,返厂数量0,返厂金额0,调拨出库数量0,调拨出库金额0,差价数量,差价金额,原料出库数量0,原料出库金额0,
			  本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml,fQty_Left,fMoney_Left
			  from #temp_SumWh_Goods_end
 
			  -----------------获取时间段的入库数量--------------------
                           
			  
			 if (select OBJECT_ID(''tempdb..#temp_IN_Goods_end''))is not null  drop table #temp_IN_Goods_end
             select  cgoodsno,cSupplierNo,cWHno, Pos客退数量1=SUM(isnull(Pos客退数量1,0)), Pos客退金额1=SUM(isnull(Pos客退金额1,0)),
				入库数量1=SUM(isnull(入库数量1,0)), 入库金额1=SUM(isnull(入库金额1,0)), 
				报溢数量1=SUM(isnull(报溢数量1,0)), 报溢金额1=SUM(isnull(报溢金额1,0)), 
				退货入库数量1=SUM(isnull(退货入库数量1,0)), 退货入库金额1=SUM(isnull(退货入库金额1,0)), 
				  调拨入库数量1=SUM(isnull(调拨入库数量1,0)), 调拨入库金额1=SUM(isnull(调拨入库金额1,0)),  					  
				  成品入库数量1=SUM(isnull(成品入库数量1,0)), 成品入库金额1=SUM(isnull(成品入库金额1,0))
				  into #temp_IN_Goods_end
             from #temp_Wh_Goods_end
             where dDatetime between '''+@strBgn+''' and '''+@strDateEnd+'''
             group by  cgoodsno,cSupplierNo,cWHno
                           
            update a
            set a.Pos客退数量1=b.Pos客退数量1, a.Pos客退金额1=b.Pos客退金额1,
			  a.入库数量1=b.入库数量1, a.入库金额1=b.入库金额1, 
			  a.报溢数量1=b.报溢数量1, a.报溢金额1=b.报溢金额1, 
			  a.退货入库数量1=b.退货入库数量1, a.退货入库金额1=b.退货入库金额1, 
			  a.调拨入库数量1=b.调拨入库数量1, a.调拨入库金额1=b.调拨入库金额1,  
			  a.成品入库数量1=b.成品入库数量1, a.成品入库金额1=b.成品入库金额1
              from #temp_WhFromend a ,#temp_IN_Goods_end b
			  where a.cGoodsNo=b.cGoodsNo 				
			  and a.cSupplierNo=b.cSupplierNo  
			  
			 if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		    if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		     if (select OBJECT_ID(''tempdb..#temp_IN_Goods_end''))is not null  drop table #temp_IN_Goods_end
                   
			')
--print  dbo.getTimeStr(GETDATE())
--print  3
 
insert into   #temp_WhFromend(cgoodsno,cWhno,cSupplierno)
select a.cgoodsno,a.cWhno,a.cSupplierno from #temp_WhFrombegin a left join #temp_WhFromend b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
where isnull(b.cGoodsNo,'')='' 

-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
--- 结束日期数据-（开始日期-1）数据 得出时间段数据    
update a 
set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),				
a.出库数量0=isnull(a.出库数量0,0)-isnull(b.出库数量0,0), 
a.出库金额0=isnull(a.出库金额0,0)-isnull(b.出库金额0,0),
a.报损数量0=isnull(a.报损数量0,0)-isnull(b.报损数量0,0), 
a.报损金额0=isnull(a.报损金额0,0)-isnull(b.报损金额0,0),				  
a.返厂数量0=isnull(a.返厂数量0,0)-isnull(b.返厂数量0,0), 
a.返厂金额0=isnull(a.返厂金额0,0)-isnull(b.返厂金额0,0),
a.调拨出库数量0=isnull(a.调拨出库数量0,0)-isnull(b.调拨出库数量0,0), 
a.调拨出库金额0=isnull(a.调拨出库金额0,0)-isnull(b.调拨出库金额0,0),
a.差价数量=isnull(a.差价数量,0)-isnull(b.差价数量,0), 
a.差价金额=isnull(a.差价金额,0)-isnull(b.差价金额,0),
a.原料出库数量0=isnull(a.原料出库数量0,0)-isnull(b.原料出库数量0,0), 
a.原料出库金额0=isnull(a.原料出库金额0,0)-isnull(b.原料出库金额0,0),
a.期初库存=isnull(b.期初库存,0), 
a.期末库存=isnull(a.期末库存,0), 
a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
a.fPrice_Avg=a.fPrice_Avg,
a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
a.fml=isnull(a.fml,0)-isnull(b.fml,0)
from #temp_WhFromend a,#temp_WhFrombegin b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo


--print  dbo.getTimeStr(GETDATE())
--print  4
 ------------获取联营供应商的扣点	
 
if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
CREATE TABLE #temp_WhKouDian ([cGoodsNo] [varchar](32) NOT NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,fPrice_Avg money,fmoney_koudian money,fMoney_cost money,
扣率金额 money)

 
exec('
          if (select OBJECT_ID(''tempdb..#temp_WhForm0_Goods_end''))is not null  drop table #temp_WhForm0_Goods_end
         select b.cgoodsno,b.cSupplierNo,销售数量0=isnull(b.当日正价销售数量,0)+isnull(b.当日特价销售数量,0), 
          销售金额0=isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0), 
		  特价销售数量=b.当日特价销售数量, 特价销售金额=b.当日特价销售金额, 
		  正价销售数量=b.当日正价销售数量, 正价销售金额=b.当日正价销售金额,
		  koudian=b.扣率金额,fMoney_cost=(isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0)-isnull(b.扣率金额,0))	
		  into #temp_WhForm0_Goods_end				  
		  from  '+@PosWhName+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where  b.业务日期 between '''+@strBgn+''' and '''+@strDateEnd+'''  
		  and  b.iAttribute=20
		  
          insert into #temp_WhKouDian
          ([cGoodsNo],cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fmoney_koudian,fMoney_cost)          
          select cgoodsno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		  特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 正价销售数量=SUM(正价销售数量), 
		  正价销售金额=SUM(正价销售金额),koudian=sum(koudian),fMoney_cost=SUM(isnull(fMoney_cost,0))					 
		  from #temp_WhForm0_Goods_end	
		  group by cgoodsno,cSupplierNo
		  
		  if (select OBJECT_ID(''tempdb..#temp_WhForm0_Goods_end''))is not null  drop table #temp_WhForm0_Goods_end
     
')	
 

if (select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
begin
 drop table #temp_PicWhFormcGoods_WH_Form_Log
end
   
select cGoodsNo,销售数量0, 销售金额0,fMoney_Cost,fml,cSupplierNo,fPrice_Avg,fQty_Left, fPrice_Left, fMoney_Left,
入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0,
原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 
特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量,扣率金额
into #temp_PicWhFormcGoods_WH_Form_Log
from #temp_WhFromend  
union all
select  cGoodsNo,销售数量0, 销售金额0,fMoney_Cost,fmoney_koudian,cSupplierNo,fPrice_Avg,fQty_Left=0, fPrice_Left=0, fMoney_Left=0,
入库数量1=0, 入库金额1=0, 报溢数量1=0, 报溢金额1=0, 退货入库数量1=0, 退货入库金额1=0, 
调拨入库数量1=0, 调拨入库金额1=0, Pos客退数量1=0, Pos客退金额1=0, 出库数量0=0, 出库金额0=0, 
报损数量0=0, 报损金额0=0, 返厂数量0=0, 返厂金额0=0, 调拨出库数量0=0, 调拨出库金额0=0, 
原料出库数量0=0, 原料出库金额0=0, 成品入库数量1=0, 成品入库金额1=0, 
特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量=0,扣率金额
from #temp_WhKouDian  
    
       
CREATE INDEX IX_tmp_PicWhFormcGoods_WH_Form_Log  ON #temp_PicWhFormcGoods_WH_Form_Log(cGoodsNo)
 
if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_0'))is not null
begin
  drop table #temp_MaxPicWhFormcGoods_0
end
select cGoodsNo,cSupplierNo,
fQuantity=sum(isnull(销售数量0,0)),
fLastSettle=sum(isnull(销售金额0,0)), 
fQuantity1=sum(isnull(特价销售数量,0)),
fLastSettle1=sum(isnull(特价销售金额,0)) 
into #temp_MaxPicWhFormcGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
group by  cGoodsNo,cSupplierNo
---合并

if (select object_id('tempdb..#temp_SumcGoodsSaleDate1'))is not null
begin
 drop table #temp_SumcGoodsSaleDate1
end
select  cGoodsNo,fQuantity=SUM(销售数量0),cSupNo=cSupplierNo,
fMoney_Cost=SUM(fMoney_Cost)
into #temp_SumcGoodsSaleDate1
from #temp_PicWhFormcGoods_WH_Form_Log
group by cGoodsNo,cSupplierNo

--print  dbo.getTimeStr(GETDATE())+'  100001'
CREATE INDEX IX_temp_MaxPicWhFormcGoods_0  ON #temp_MaxPicWhFormcGoods_0(cGoodsNo)
exec('
if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101''))is not null
begin
  drop table #temp_Log_Day_Qty_0_0101
end
select cGoodsNo,cSupno into #temp_Log_Day_Qty_0_0101 
from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''

--print  dbo.getTimeStr(GETDATE())+''  11''

CREATE INDEX IX_temp_Log_Day_Qty_0_0101  ON #temp_Log_Day_Qty_0_0101(cGoodsNo)

if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101Null''))is not null
begin
  drop table #temp_Log_Day_Qty_0_0101Null
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_Log_Day_Qty_0_0101Null
from #temp_MaxPicWhFormcGoods_0 a left join #temp_Log_Day_Qty_0_0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

---销售成本
insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null


--print  dbo.getTimeStr(GETDATE())+''  12''
---销售数量
insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

--print  dbo.getTimeStr(GETDATE())+''  13''
---销售金额
insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Qty_0_0101Null

--print  dbo.getTimeStr(GETDATE())+''  14''

if (select object_id(''tempdb..#temp_Log_Day_Qty_0_0101''))is not null
begin
  drop table #temp_Log_Day_Qty_0_0101
end

')

exec('  
--print  dbo.getTimeStr(GETDATE())+''  15''
------------修改销售成本记录表
update b set 
fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(a.fMoney_Cost,0) 
from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#temp_SumcGoodsSaleDate1 a
where  b.cYear='''+@Y1+'''  and b.cGoodsNo=a.cGoodsNo and b.cSupNo=a.cSupNo  

--print  dbo.getTimeStr(GETDATE())+''  16''

------------修改数量
update b set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
fQtytj_'+@MMDAY1+'=isnull(fQtytj_'+@MMDAY1+',0)+isnull(a.fQuantity1,0)
from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#temp_MaxPicWhFormcGoods_0 a
where b.cYear='''+@Y1+'''   and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo

 --print  dbo.getTimeStr(GETDATE())+''  17''
------------修改金额

update b set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(a.fLastSettle,0),
Saletj_'+@MMDAY1+'=isnull(Saletj_'+@MMDAY1+',0)+isnull(a.fLastSettle1,0)
from '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#temp_MaxPicWhFormcGoods_0 a
where  b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo  

  --print  dbo.getTimeStr(GETDATE())+''  18''
')
 
--print  dbo.getTimeStr(GETDATE())+'  100002'
 
-------------******************获取当天剩余库存***********************88----------------
exec('
if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101''))is not null
begin
  drop table #temp_Log_Day_Left_1_0101
end
select cGoodsNo,cSupno into #temp_Log_Day_Left_1_0101 
from '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''

--print  dbo.getTimeStr(GETDATE())+''  21''

if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101NUll''))is not null
begin
  drop table #temp_Log_Day_Left_1_0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_Log_Day_Left_1_0101NUll
from #temp_MaxPicWhFormcGoods_0 a left join #temp_Log_Day_Left_1_0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

insert into '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_Log_Day_Left_1_0101NUll

--print  dbo.getTimeStr(GETDATE())+''  22''

if (select object_id(''tempdb..#temp_Log_Day_Left_1_0101''))is not null
begin
  drop table #temp_Log_Day_Left_1_0101
end

')

if (select object_id('tempdb..#temp_LeftGoods_0'))is not null
begin
 drop table #temp_LeftGoods_0
end 
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(fQty_Left,0)),
fLastSettle=sum(isnull(fMoney_Left,0)) 
into #temp_LeftGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
group by cGoodsNo,cSupplierNo
 
--print  dbo.getTimeStr(GETDATE())+'  23'
if @MMDAY1<>'0101'
begin 
exec(' 
------------修改剩余库存数量和金额

update b set 
b.fQty_'+@MMDAY1+'=isnull(a.fQuantity,0),
b.fMoney_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#temp_LeftGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo

')
end else
begin
  exec(' 
  ---- 获取上一年的数据
 
    
    update b set 
	b.fQty_'+@MMDAY1+'31=isnull(a.fQty1231,0),
	b.fMoney_'+@MMDAY1+'31=isnull(a.fMoney1231,0)  
	from '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,(
	     select cGoodsNo,cSupNo,
		 fQty1231=isnull(fQty_'+@MMDAY_1+',0),
		 fMoney1231=isnull(fMoney_'+@MMDAY_1+',0) 
		 from '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M_1+'
		 with (nolock) 
		 where cYear='''+@Y_1+'''
	) a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupNo
	
------------修改剩余库存数量和金额
	update b set 
	b.fQty_'+@MMDAY1+'=isnull(a.fQuantity,0),
	b.fMoney_'+@MMDAY1+'=isnull(a.fLastSettle,0)  
	from '+@PosWhName+'_Left.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b,#temp_LeftGoods_0 a
	where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo

	')
end

--print  dbo.getTimeStr(GETDATE())+'  100003'
 
---------------------取当天的所有入库、出库、报损、返厂、成本
----一、---------取当天入库数表：t_WH_Form_Log_Day_IN
if (select object_id('tempdb..#temp_INGoods_0'))is not null
begin
 drop table #temp_INGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(入库数量1,0)),
fLastSettle=sum(isnull(入库金额1,0)) 
into #temp_INGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
where isnull(入库数量1,0)>0
group by cGoodsNo,cSupplierNo

---入库
exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_In0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_In0101
from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  
    
--print  dbo.getTimeStr(GETDATE())+''  31''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101NUll''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_In0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_In0101NUll
from #temp_INGoods_0 a left join #temp_t_WH_Form_Log_Day_In0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll


insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll

insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_In0101NUll


if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_In0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_In0101
end
') 

--print  dbo.getTimeStr(GETDATE())+'  35'

exec(' 
------------修改入库数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#temp_INGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo  
 
')
--print  dbo.getTimeStr(GETDATE())+'  36'
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	   exec('
		update '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+' set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		where  cYear='''+@Y1+'''  
		')
    end
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_INGoods_0_1231''))is not null
	begin
	  drop table #temp_INGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),
    fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_INGoods_0_1231
    from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  37''
    CREATE INDEX IX_temp_INGoods_0_1231  ON #temp_INGoods_0_1231(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_INGoods_0_0101''))is not null
	begin
	  drop table #temp_INGoods_0_0101
	end
    select cGoodsNo,cSupno into #temp_INGoods_0_0101 
    from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''
    
    --print  dbo.getTimeStr(GETDATE())+''  38''
    
    CREATE INDEX IX_temp_INGoods_0_0101  ON #temp_INGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_INGoods_0_0101NULL''))is not null
	begin
	  drop table #temp_INGoods_0_0101NULL
	end
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_INGoods_0_0101NULL
	from #temp_INGoods_0_1231 a left join #temp_INGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_01(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_02(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_03(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_04(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_05(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_06(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_07(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_09(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_10(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_11(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	insert into '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_12(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo,cSupNo,cYear from #temp_INGoods_0_0101NULL
	
	
	 --print  dbo.getTimeStr(GETDATE())+''  39''
	 
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)  
	from '+@PosWhName+'_In.dbo.t_WH_Form_Log_Day_In_'+@M1+' a, #temp_INGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo 
	
	 --print  dbo.getTimeStr(GETDATE())+''  301''
	 
	if (select object_id(''tempdb..#temp_INGoods_0_1231''))is not null
	begin
	  drop table #temp_INGoods_0_1231
	end
	if (select object_id(''tempdb..#temp_INGoods_0_0101''))is not null
	begin
	  drop table #temp_INGoods_0_0101
	end
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100004'
 
-------成品入库：t_WH_Form_Log_Day_Divide
 if (select object_id('tempdb..#temp_DivideGoods_0'))is not null
begin
 drop table #temp_DivideGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(成品入库数量1,0)),
fLastSettle=sum(isnull(成品入库金额1,0)) 
into #temp_DivideGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
where isnull(成品入库数量1,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101''))is not null
begin
drop table #temp_t_WH_Form_Log_Day_Divide0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Divide0101
from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  
 --print  dbo.getTimeStr(GETDATE())+''  41''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101NUll''))is not null
begin
drop table #temp_t_WH_Form_Log_Day_Divide0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_Divide0101NUll
from #temp_DivideGoods_0 a left join #temp_t_WH_Form_Log_Day_Divide0101 b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

 
insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Divide0101NUll

 --print  dbo.getTimeStr(GETDATE())+''  42''
 
 if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Divide0101''))is not null
begin
drop table #temp_t_WH_Form_Log_Day_Divide0101
end

')


exec(' 
------------修改成品入库数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' b,#temp_DivideGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo

')
 --print  dbo.getTimeStr(GETDATE())+'  43'
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	     exec('
			update '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			where  cYear='''+@Y1+'''  
			')
    end
  
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_DivideGoods_0_1231''))is not null
	begin
	  drop table #temp_DivideGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_DivideGoods_0_1231
    from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
     --print  dbo.getTimeStr(GETDATE())+''  44''
     
    if (select object_id(''tempdb..#temp_DivideGoods_0_0101''))is not null
	begin
	  drop table #temp_DivideGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_DivideGoods_0_0101
    from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  45''
       
    CREATE INDEX IX_temp_DivideGoods_0_1231  ON #temp_DivideGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_DivideGoods_0_0101  ON #temp_DivideGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_DivideGoods_0_0101NUll''))is not null
	begin
	  drop table #temp_DivideGoods_0_0101NUll
	end
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_DivideGoods_0_0101NUll
	from #temp_DivideGoods_0_1231 a left join #temp_DivideGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
    
    insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
	insert into '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_DivideGoods_0_0101NUll
	
    --print  dbo.getTimeStr(GETDATE())+''  46''
    
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)    
	from '+@PosWhName+'_Divide.dbo.t_WH_Form_Log_Day_Divide_'+@M1+' a, #temp_DivideGoods_0_1231 b
	where a.cYear='''+@Y1+'''	and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo 
	  
	 --print  dbo.getTimeStr(GETDATE())+''  47''
	 
	 if (select object_id(''tempdb..#temp_DivideGoods_0_1231''))is not null
	begin
	  drop table #temp_DivideGoods_0_1231
	end
	
	if (select object_id(''tempdb..#temp_DivideGoods_0_0101''))is not null
	begin
	  drop table #temp_DivideGoods_0_0101
	end
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100005'
 
-------t_WH_Form_Log_Day_Effusion[报益单]


if (select object_id('tempdb..#temp_EffusionGoods_0'))is not null
begin
 drop table #temp_EffusionGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(报溢数量1,0)),
fLastSettle=sum(isnull(报溢金额1,0)) 
into #temp_EffusionGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
where isnull(报溢数量1,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Effusion0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Effusion0101
from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  51''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101NUll''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Effusion0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_Effusion0101NUll
from #temp_EffusionGoods_0 a left join #temp_t_WH_Form_Log_Day_Effusion0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Effusion0101NUll

--print  dbo.getTimeStr(GETDATE())+''  52''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Effusion0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Effusion0101
end

')

exec(' 
------------修改报溢数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' b,#temp_EffusionGoods_0 a  
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
') 
--print  dbo.getTimeStr(GETDATE())+'  53'
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 

   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	       exec('
			update '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' set 
			fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
			fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
			where  cYear='''+@Y1+'''  
			')
    end
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_EffusionGoods_0_1231''))is not null
	begin
	  drop table #temp_EffusionGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_EffusionGoods_0_1231
    from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  54''
    
    if (select object_id(''tempdb..#temp_EffusionGoods_0_0101''))is not null
	begin
	  drop table #temp_EffusionGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_EffusionGoods_0_0101
    from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  55''
    
    CREATE INDEX IX_temp_EffusionGoods_0_1231  ON #temp_EffusionGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_EffusionGoods_0_0101  ON #temp_EffusionGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_EffusionGoods_0_0101NULL''))is not null
	begin
	  drop table #temp_EffusionGoods_0_0101NULL
	end
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_EffusionGoods_0_0101NULL
	from #temp_EffusionGoods_0_1231 a left join #temp_EffusionGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
    
    insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL
	
	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL
	
	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL
	
	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL

	insert into '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_EffusionGoods_0_0101NULL
	
	--print  dbo.getTimeStr(GETDATE())+''  56''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)      
	from '+@PosWhName+'_Effusion.dbo.t_WH_Form_Log_Day_Effusion_'+@M1+' a, #temp_EffusionGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
	
	if (select object_id(''tempdb..#temp_EffusionGoods_0_1231''))is not null
	begin
	  drop table #temp_EffusionGoods_0_1231
	end
	
	   if (select object_id(''tempdb..#temp_EffusionGoods_0_0101''))is not null
	begin
	  drop table #temp_EffusionGoods_0_0101
	end
	
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100006'
 
-------t_WH_Form_Log_Day_Return[退货入库] 3


 if (select object_id('tempdb..#temp_ReturnGoods_0'))is not null
begin
 drop table #temp_ReturnGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(退货入库数量1,0)),
fLastSettle=sum(isnull(退货入库金额1,0)) 
into #temp_ReturnGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
where isnull(退货入库数量1,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101''))is not null
begin
   drop table #temp_t_WH_Form_Log_Day_Return0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Return0101
from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  61''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101NUll''))is not null
begin
   drop table #temp_t_WH_Form_Log_Day_Return0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
into #temp_t_WH_Form_Log_Day_Return0101NUll
from #temp_ReturnGoods_0 a left join #temp_t_WH_Form_Log_Day_Return0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''
    
insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_01(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_02(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_03(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_04(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_05(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_06(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_07(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_08(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_09(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_10(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_11(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_12(cGoodsNO,cSupNo,cYear)
select  cGoodsNo, cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Return0101NUll

--print  dbo.getTimeStr(GETDATE())+''  62''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Return0101''))is not null
begin
   drop table #temp_t_WH_Form_Log_Day_Return0101
end

')

exec(' 
------------修改退货入库数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+' b,#temp_ReturnGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo

') 
--print  dbo.getTimeStr(GETDATE())+'  63'
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec('
	update '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end  
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_ReturnGoods_0_1231''))is not null
	begin
	  drop table #temp_ReturnGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_ReturnGoods_0_1231
    from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  64''
    
    if (select object_id(''tempdb..#temp_ReturnGoods_0_0101''))is not null
	begin
	  drop table #temp_ReturnGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_ReturnGoods_0_0101
    from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  65''
    
    CREATE INDEX IX_temp_ReturnGoods_0_0101  ON #temp_ReturnGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_ReturnGoods_0_0101  ON #temp_ReturnGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_ReturnGoods_0_0101Null''))is not null
	begin
	  drop table #temp_ReturnGoods_0_0101Null
	end
	
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	into #temp_ReturnGoods_0_0101Null
	from #temp_ReturnGoods_0_1231 a left join #temp_ReturnGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
		
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	
	insert into '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_ReturnGoods_0_0101Null
	--print  dbo.getTimeStr(GETDATE())+''  66''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)      
	from '+@PosWhName+'_Return.dbo.t_WH_Form_Log_Day_Return_'+@M1+' a, #temp_ReturnGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
	if (select object_id(''tempdb..#temp_ReturnGoods_0_1231''))is not null
	begin
	  drop table #temp_ReturnGoods_0_1231
	end
	
	if (select object_id(''tempdb..#temp_ReturnGoods_0_0101''))is not null
	begin
	  drop table #temp_ReturnGoods_0_0101
	end
	
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100007'
 
-------t_WH_Form_Log_Day_TfrIn[调拨入库]

if (select object_id('tempdb..#temp_TfrInGoods_0'))is not null
begin
 drop table #temp_TfrInGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(调拨入库数量1,0)),
fLastSettle=sum(isnull(调拨入库金额1,0)) 
into #temp_TfrInGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log 
where isnull(调拨入库数量1,0)>0
group by cGoodsNo,cSupplierNo
exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_TfrIn0101
	end
    select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_TfrIn0101
    from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  71''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101Null''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_TfrIn0101Null
end

select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_TfrIn0101Null
from #temp_TfrInGoods_0 a left join #temp_t_WH_Form_Log_Day_TfrIn0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null

insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_TfrIn0101Null
 

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_TfrIn0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_TfrIn0101
end
	
')
--print  dbo.getTimeStr(GETDATE())+'  72'

exec(' 
------------修改调拨入库数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#temp_TfrInGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo 
')
--print  dbo.getTimeStr(GETDATE())+'  73'
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	 exec('
	update '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
  
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_TfrInGoods_0_1231''))is not null
	begin
	  drop table #temp_TfrInGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_TfrInGoods_0_1231
    from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  74''
    
   if (select object_id(''tempdb..#temp_TfrInGoods_0_0101''))is not null
	begin
	  drop table #temp_TfrInGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_TfrInGoods_0_0101
    from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  75''
    
    CREATE INDEX IX_temp_TfrInGoods_0_1231  ON #temp_TfrInGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_TfrInGoods_0_0101  ON #temp_TfrInGoods_0_0101(cGoodsNo)
    
    
    if (select object_id(''tempdb..#temp_TfrInGoods_0_0101Null''))is not null
	begin
	  drop table #temp_TfrInGoods_0_0101Null
	end
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	into #temp_TfrInGoods_0_0101Null
	from #temp_TfrInGoods_0_1231 a left join #temp_TfrInGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null
	insert into '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrInGoods_0_0101Null 
	
	--print  dbo.getTimeStr(GETDATE())+''  76''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)        
	from '+@PosWhName+'_TfrIn.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' a, #temp_TfrInGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
	if (select object_id(''tempdb..#temp_TfrInGoods_0_1231''))is not null
	begin
	  drop table #temp_TfrInGoods_0_1231
	end
	   if (select object_id(''tempdb..#temp_TfrInGoods_0_0101''))is not null
	begin
	  drop table #temp_TfrInGoods_0_0101
	end
 
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100008'
 
----------------***************出库、返厂、报损、***********************---------------
/*出库单t_WH_Form_Log_Day_Out[出库单]*/

if (select object_id('tempdb..#temp_OutGoods_0'))is not null
begin
 drop table #temp_OutGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(出库数量0,0)),
fLastSettle=sum(isnull(出库金额0,0)) 
into #temp_OutGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where isnull(出库数量0,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Out0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Out0101
from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  81''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101Null''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Out0101Null
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
into #temp_t_WH_Form_Log_Day_Out0101Null
from #temp_OutGoods_0 a left join #temp_t_WH_Form_Log_Day_Out0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_01(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_02(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_03(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_04(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_05(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_06(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_07(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_08(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_09(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_10(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_11(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null
insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_12(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Out0101Null

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Out0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Out0101
end


')
--print  dbo.getTimeStr(GETDATE())+'  82'

exec(' 
------------修改出库数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+' b,#temp_OutGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
')
-----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec('
	update '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
   
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_OutGoods_0_1231''))is not null
	begin
	  drop table #temp_OutGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_OutGoods_0_1231
    from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  83''
    
     if (select object_id(''tempdb..#temp_OutGoods_0_0101''))is not null
	begin
	  drop table #temp_OutGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_OutGoods_0_0101
    from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  84''
    
    CREATE INDEX IX_temp_OutGoods_0_1231  ON #temp_OutGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_OutGoods_0_0101  ON #temp_OutGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_OutGoods_0_0101Null''))is not null
	begin
	  drop table #temp_OutGoods_0_0101Null
	end
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	into #temp_OutGoods_0_0101Null
	from #temp_OutGoods_0_1231 a left join #temp_OutGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''
	
	
    insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
    insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	insert into '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_OutGoods_0_0101Null
	
	--print  dbo.getTimeStr(GETDATE())+''  85''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)        
	from '+@PosWhName+'_Out.dbo.t_WH_Form_Log_Day_Out_'+@M1+' a, #temp_OutGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
    if (select object_id(''tempdb..#temp_OutGoods_0_1231''))is not null
	begin
	  drop table #temp_OutGoods_0_1231
	end
    if (select object_id(''tempdb..#temp_OutGoods_0_0101''))is not null
	begin
	  drop table #temp_OutGoods_0_0101
	end
    ')
end

--print  dbo.getTimeStr(GETDATE())+'  100009'
 
/*返厂单t_WH_Form_Log_Day_Rbd[返厂单]*/

if (select object_id('tempdb..#temp_RbdGoods_0'))is not null
begin
 drop table #temp_RbdGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(返厂数量0,0)),
fLastSettle=sum(isnull(返厂金额0,0)) 
into #temp_RbdGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where isnull(返厂数量0,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Rbd0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Rbd0101
from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  91''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101Null''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Rbd0101Null
end

select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+''' 
into #temp_t_WH_Form_Log_Day_Rbd0101Null
from #temp_RbdGoods_0 a left join #temp_t_WH_Form_Log_Day_Rbd0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_01(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_02(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_03(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_04(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_05(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_06(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_07(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_08(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_09(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_10(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_11(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_12(cGoodsNO,cSupNo,cYear)
select  cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Rbd0101Null
--print  dbo.getTimeStr(GETDATE())+''  92''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Rbd0101''))is not null
	begin
	  drop table #temp_t_WH_Form_Log_Day_Rbd0101
	end

')


exec(' 
------------修改返厂数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' b,#temp_RbdGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
')
 -----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec('
	update '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
   
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_RbdGoods_0_1231''))is not null
	begin
	  drop table #temp_RbdGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),
    fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_RbdGoods_0_1231
    from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  93''
    
    if (select object_id(''tempdb..#temp_RbdGoods_0_0101''))is not null
	begin
	  drop table #temp_RbdGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_RbdGoods_0_0101
    from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  94''
    
    CREATE INDEX IX_temp_RbdGoods_0_1231  ON #temp_RbdGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_RbdGoods_0_0101  ON #temp_RbdGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_RbdGoods_0_0101NUll''))is not null
	begin
	  drop table #temp_RbdGoods_0_0101NUll
	end
    
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_RbdGoods_0_0101NUll
	from #temp_RbdGoods_0_1231 a left join #temp_RbdGoods_0_0101 b
	on   a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
	
    
    insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	insert into '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_RbdGoods_0_0101NUll
	
	--print  dbo.getTimeStr(GETDATE())+''  95''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0) ,
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)       
	from '+@PosWhName+'_Rbd.dbo.t_WH_Form_Log_Day_Rbd_'+@M1+' a, #temp_RbdGoods_0_1231 b
	where  a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	
	if (select object_id(''tempdb..#temp_RbdGoods_0_1231''))is not null
	begin
	  drop table #temp_RbdGoods_0_1231
	end
		if (select object_id(''tempdb..#temp_RbdGoods_0_0101''))is not null
	begin
	  drop table #temp_RbdGoods_0_0101
	end 
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100010'
 
/*报损 单t_WH_Form_Log_Day_Loss[报损单]*/


if (select object_id('tempdb..#temp_LossGoods_0'))is not null
begin
 drop table #temp_LossGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(报损数量0,0)),
fLastSettle=sum(isnull(报损金额0,0)) 
into #temp_LossGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where isnull(报损数量0,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Loss0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Loss0101
from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  

--print  dbo.getTimeStr(GETDATE())+''  101''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101Null''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Loss0101Null
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_Loss0101Null
from #temp_LossGoods_0 a left join #temp_t_WH_Form_Log_Day_Loss0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null
insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Loss0101Null

    --print  dbo.getTimeStr(GETDATE())+''  102''
    
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Loss0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Loss0101
end

')

exec(' 
------------修改报损单数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' b,#temp_LossGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo   
')
 -----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	 exec('
	update '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
   
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_LossGoods_0_1231''))is not null
	begin
	  drop table #temp_LossGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_LossGoods_0_1231
    from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  103''
        
    if (select object_id(''tempdb..#temp_LossGoods_0_0101''))is not null
	begin
	  drop table #temp_LossGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_LossGoods_0_0101
    from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  104''
        
    CREATE INDEX IX_temp_LossGoods_0_1231  ON #temp_LossGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_LossGoods_0_0101  ON #temp_LossGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_LossGoods_0_0101Null''))is not null
	begin
	  drop table #temp_LossGoods_0_0101Null
	end
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_LossGoods_0_0101Null
	from #temp_LossGoods_0_1231 a left join #temp_LossGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	insert into '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_LossGoods_0_0101Null
	
	--print  dbo.getTimeStr(GETDATE())+''  105''
	    
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)        
	from '+@PosWhName+'_Loss.dbo.t_WH_Form_Log_Day_Loss_'+@M1+' a, #temp_LossGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
	if (select object_id(''tempdb..#temp_LossGoods_0_1231''))is not null
	begin
	  drop table #temp_LossGoods_0_1231
	end
	    if (select object_id(''tempdb..#temp_LossGoods_0_0101''))is not null
	begin
	  drop table #temp_LossGoods_0_0101
	end
	 
    ')
end
--print  dbo.getTimeStr(GETDATE())+'  100011'
 
 /*调拨出库单t_WH_Form_Log_Day_Tfr[调拨出库]*/

if (select object_id('tempdb..#temp_TfrGoods_0'))is not null
begin
 drop table #temp_TfrGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(调拨出库数量0,0)),
fLastSettle=sum(isnull(调拨出库金额0,0)) 
into #temp_TfrGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where isnull(调拨出库数量0,0)>0
group by cGoodsNo,cSupplierNo

 exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Tfr0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Tfr0101
from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  
    
 --print  dbo.getTimeStr(GETDATE())+''  111''
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101Null''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Tfr0101Null
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_Tfr0101Null
from #temp_TfrGoods_0 a left join #temp_t_WH_Form_Log_Day_Tfr0101 b
on a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo 
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null
insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear from #temp_t_WH_Form_Log_Day_Tfr0101Null

--print  dbo.getTimeStr(GETDATE())+''  112''

 if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Tfr0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Tfr0101
end
	
')

exec(' 
------------修改调拨数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#temp_TfrGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
')
 -----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec('
	update '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
   
end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_TfrGoods_0_1231''))is not null
	begin
	  drop table #temp_TfrGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_TfrGoods_0_1231
    from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  113''
      
    if (select object_id(''tempdb..#temp_TfrGoods_0_0101''))is not null
	begin
	  drop table #temp_TfrGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_TfrGoods_0_0101
    from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  114''
    
    CREATE INDEX IX_temp_TfrGoods_0_1231  ON #temp_TfrGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_TfrGoods_0_0101  ON #temp_TfrGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_TfrGoods_0_0101Null''))is not null
	begin
	  drop table #temp_TfrGoods_0_0101Null
	end
	
	select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	into #temp_TfrGoods_0_0101Null
	from #temp_TfrGoods_0_1231 a left join #temp_TfrGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo    
	where isnull(b.cGoodsNO,'''')=''''
	
    
    insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	insert into '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_TfrGoods_0_0101Null
	
	--print  dbo.getTimeStr(GETDATE())+''  115''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)          
	from '+@PosWhName+'_Tfr.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' a, #temp_TfrGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
	if (select object_id(''tempdb..#temp_TfrGoods_0_1231''))is not null
	begin
	  drop table #temp_TfrGoods_0_1231
	end
     if (select object_id(''tempdb..#temp_TfrGoods_0_0101''))is not null
	begin
	  drop table #temp_TfrGoods_0_0101
	end
    ')
end

--print  dbo.getTimeStr(GETDATE())+'  100012'
 
/*原料出库单t_WH_Form_Log_Day_Pack[原料出库单]*/

if (select object_id('tempdb..#temp_PackGoods_0'))is not null
begin
 drop table #temp_PackGoods_0
end
select cGoodsNo,cSupplierNo,fQuantity=sum(isnull(原料出库数量0,0)),
fLastSettle=sum(isnull(原料出库金额0,0)) 
into #temp_PackGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where isnull(原料出库数量0,0)>0
group by cGoodsNo,cSupplierNo

exec('
if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Pack0101
end
select cGoodsNo,cSupNo into #temp_t_WH_Form_Log_Day_Pack0101
from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+'
with (nolock) 
where cYear='''+@Y1+'''  
    
--print  dbo.getTimeStr(GETDATE())+''  121''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101NUll''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Pack0101NUll
end
select a.cGoodsNo,a.cSupplierNo,cYear='''+@Y1+'''
into #temp_t_WH_Form_Log_Day_Pack0101NUll
from #temp_PackGoods_0 a left join #temp_t_WH_Form_Log_Day_Pack0101 b
on  a.cGoodsNo=b.cGoodsNO and a.cSupplierNo=b.cSupNo   
where isnull(b.cGoodsNO,'''')=''''

insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_01(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_02(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_03(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_04(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_05(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_06(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_07(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_09(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_10(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_11(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll
insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_12(cGoodsNO,cSupNo,cYear)
select cGoodsNo,cSupplierNo,cYear  from #temp_t_WH_Form_Log_Day_Pack0101NUll

--print  dbo.getTimeStr(GETDATE())+''  122''

if (select object_id(''tempdb..#temp_t_WH_Form_Log_Day_Pack0101''))is not null
begin
  drop table #temp_t_WH_Form_Log_Day_Pack0101
end
')


exec(' 
------------修改原料出库单数量、金额
update b set 
b.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn_'+@MMDAY1+',0)+isnull(a.fQuantity,0),
b.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn_'+@MMDAY1+',0)+isnull(a.fLastSettle,0)  
from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' b,#temp_PackGoods_0 a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO and b.cSupNo=a.cSupplierNo
')
 -----把前一天数据加上
if @MMDAY1<>'0101'
begin 
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec('
	update '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' set 
	fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
	where  cYear='''+@Y1+'''  
    ')
    end 
   
end  else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_PackGoods_0_1231''))is not null
	begin
	  drop table #temp_PackGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_PackGoods_0_1231
    from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  123''
    
    if (select object_id(''tempdb..#temp_PackGoods_0_0101''))is not null
	begin
	  drop table #temp_PackGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_PackGoods_0_0101
    from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
     --print  dbo.getTimeStr(GETDATE())+''  124''
    
    CREATE INDEX IX_temp_PackGoods_0_1231  ON #temp_PackGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_PackGoods_0_0101  ON #temp_PackGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_PackGoods_0_0101Null''))is not null
	begin
	  drop table #temp_PackGoods_0_0101Null
	end
    
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_PackGoods_0_0101Null
	from #temp_PackGoods_0_1231 a left join #temp_PackGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo    
	where isnull(b.cGoodsNO,'''')=''''
	
    insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_01(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_02(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_01(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_03(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_04(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_05(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_06(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_07(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	insert into '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_08(cGoodsNO,cSupNo,cYear)
	select  cGoodsNo, cSupNo,cYear from #temp_PackGoods_0_0101Null
	--print  dbo.getTimeStr(GETDATE())+''  125''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)          
	from '+@PosWhName+'_Pack.dbo.t_WH_Form_Log_Day_Pack_'+@M1+' a, #temp_PackGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	
    if (select object_id(''tempdb..#temp_PackGoods_0_1231''))is not null
	begin
	  drop table #temp_PackGoods_0_1231
	end
    if (select object_id(''tempdb..#temp_PackGoods_0_0101''))is not null
	begin
	  drop table #temp_PackGoods_0_0101
	end
    ')
end
---print  dbo.getTimeStr(GETDATE())+'  100013'
 
if (@M1+@Day1)<>'0101'
begin
   if @Day1='01'
   begin
      exec('
		update a set 
		fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY_1+',0)+isnull(fQtyIn_'+@MMDAY1+',0),
		fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY_1+',0)+isnull(fMoneyIn_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQtyIn_'+@MMDAY_1+',fMoneyIn_'+@MMDAY_1+'
		   from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
		
		exec('
		update a set 
		fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY_1+',0)+isnull(fQty_'+@MMDAY1+',0),
		fQtytj_'+@MMDAY1+'=isnull(fQtytj_'+@MMDAY_1+',0)+isnull(fQtytj_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,fQty_'+@MMDAY_1+',fQtytj_'+@MMDAY_1+'
		   from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
		
		exec('
		update a set 
		Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY_1+',0)+isnull(Sale_'+@MMDAY1+',0),
		Saletj_'+@MMDAY1+'=isnull(Saletj_'+@MMDAY_1+',0)+isnull(Saletj_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' a,
		(
		   select  cGoodsNo,cSupNo,Sale_'+@MMDAY_1+',Saletj_'+@MMDAY_1+'
		   from '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO and a.cSupNo=c.cSupNo 
		')
   end else
   begin
	exec(' 
	------------修改销售成本记录表
    update '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' 
	set fQtyIn_'+@MMDAY1+'=isnull(fQtyIn_'+@MMDAY1+',0)+isnull(fQtyIn_'+@MMDAY_1+',0),
	fMoneyIn_'+@MMDAY1+'=isnull(fMoneyIn_'+@MMDAY1+',0)+isnull(fMoneyIn_'+@MMDAY_1+',0)
	where cYear='''+@Y1+'''  
	------------修改数量
	 
	update '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' 
	set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(fQty_'+@MMDAY_1+',0),
	fQtytj_'+@MMDAY1+'=isnull(fQtytj_'+@MMDAY1+',0)+isnull(fQtytj_'+@MMDAY_1+',0)
    where cYear='''+@Y1+'''  
	------------修改金额 

	update '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' 
	set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(Sale_'+@MMDAY_1+',0),
	Saletj_'+@MMDAY1+'=isnull(Saletj_'+@MMDAY1+',0)+isnull(Saletj_'+@MMDAY_1+',0)
	where cYear='''+@Y1+'''   

	')
    end 
	
end  else
begin
    exec('
     ---- 获取上一年的记录成本数据
    if (select object_id(''tempdb..#temp_CostGoods_0_1231''))is not null
	begin
	  drop table #temp_CostGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQtyIn1231=isnull(fQtyIn_'+@MMDAY_1+',0),fMoneyIn1231=isnull(fMoneyIn_'+@MMDAY_1+',0)
    into #temp_CostGoods_0_1231
    from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  131''
    
    if (select object_id(''tempdb..#temp_CostGoods_0_0101''))is not null
	begin
	  drop table #temp_CostGoods_0_0101
	end
    select cGoodsNo,cSupNo
    into #temp_CostGoods_0_0101
    from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+'
    with (nolock)     
    where cYear='''+@Y1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  132''
    
    CREATE INDEX IX_temp_CostGoods_0_1231  ON #temp_CostGoods_0_1231(cGoodsNo)
    CREATE INDEX IX_temp_CostGoods_0_0101  ON #temp_CostGoods_0_0101(cGoodsNo)
    
    if (select object_id(''tempdb..#temp_CostGoods_0_0101Null''))is not null
	begin
	  drop table #temp_CostGoods_0_0101Null
	end
    select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
    into #temp_CostGoods_0_0101Null
	from #temp_CostGoods_0_1231 a left join #temp_CostGoods_0_0101 b
	on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
	where isnull(b.cGoodsNO,'''')=''''
    
    
    insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	
	--print  dbo.getTimeStr(GETDATE())+''  133''
	
	update a
	set a.fQtyIn_'+@MMDAY1+'=isnull(b.fQtyIn1231,0)+isnull(a.fQtyIn_'+@MMDAY1+',0),
	a.fMoneyIn_'+@MMDAY1+'=isnull(b.fMoneyIn1231,0)+isnull(a.fMoneyIn_'+@MMDAY1+',0),
	a.fQtyIn_'+@MMDAY1+'31=isnull(b.fQtyIn1231,0),
	a.fMoneyIn_'+@MMDAY1+'31=isnull(b.fMoneyIn1231,0)          
	from '+@PosWhName+'_Cost.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' a, #temp_CostGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo  
    
    --print  dbo.getTimeStr(GETDATE())+''  134''
    
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_QtyGoods_0_1231''))is not null
	begin
	  drop table #temp_QtyGoods_0_1231
	end
    select cGoodsNo,cSupNo,fQty1231=isnull(fQty_'+@MMDAY_1+',0),fQtytj1231=isnull(fQtytj_'+@MMDAY_1+',0)
    into #temp_QtyGoods_0_1231
    from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
     --print  dbo.getTimeStr(GETDATE())+''  135''
     
 --   if (select object_id(''tempdb..#temp_QtyGoods_0_0101''))is not null
	--begin
	--  drop table #temp_QtyGoods_0_0101
	--end
 --   select cGoodsNo,cSupNo
 --   into #temp_QtyGoods_0_0101
 --   from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+'
 --   with (nolock) 
 --   where cYear='''+@Y1+'''  
    
     --print  dbo.getTimeStr(GETDATE())+''  136''
    
    CREATE INDEX IX_temp_QtyGoods_0_1231  ON #temp_QtyGoods_0_1231(cGoodsNo)
 --   CREATE INDEX IX_temp_QtyGoods_0_0101  ON #temp_QtyGoods_0_0101(cGoodsNo)
    
    
 --   insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+'(cGoodsNO,cSupNo,cYear)
	--select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	--from #temp_QtyGoods_0_1231 a left join #temp_QtyGoods_0_0101 b
	--on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo    
	--where isnull(b.cGoodsNO,'''')=''''
	
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_01(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_02(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_03(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_04(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_05(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_06(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_07(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_08(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_09(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_10(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_11(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	insert into '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_12(cGoodsNO,cSupNo,cYear)
	select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
	
	 --print  dbo.getTimeStr(GETDATE())+''  137''
	
	update a
	set a.fQty_'+@MMDAY1+'=isnull(b.fQty1231,0)+isnull(a.fQty_'+@MMDAY1+',0),
	a.fQtytj_'+@MMDAY1+'=isnull(b.fQtytj1231,0)+isnull(a.fQtytj_'+@MMDAY1+',0),
	a.fQty_'+@MMDAY1+'31=isnull(b.fQty1231,0),
	a.fQtytj_'+@MMDAY1+'31=isnull(b.fQtytj1231,0)            
	from '+@PosWhName+'_Qty.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' a, #temp_QtyGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   	
	
	--print  dbo.getTimeStr(GETDATE())+''  138''
	
	if (select object_id(''tempdb..#temp_SaleGoods_0_1231''))is not null
	begin
	  drop table #temp_SaleGoods_0_1231
	end
    select cGoodsNo,cSupNo,Sale1231=isnull(Sale_'+@MMDAY_1+',0),Saletj1231=isnull(Saletj_'+@MMDAY_1+',0)
    into #temp_SaleGoods_0_1231
    from '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    --print  dbo.getTimeStr(GETDATE())+''  139''
    
 --   insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+'(cGoodsNO,cSupNo,cYear)
	--select a.cGoodsNo,a.cSupNo,cYear='''+@Y1+''' 
	--from #temp_SaleGoods_0_1231 a left join #temp_QtyGoods_0_0101 b
	--on  a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   
	--where isnull(b.cGoodsNO,'''')=''''
	
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_01(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_02(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_03(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_04(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_05(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_06(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_07(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_08(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_09(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_10(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_11(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    insert into '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_12(cGoodsNO,cSupNo,cYear)
    select cGoodsNo,cSupNo,cYear from #temp_CostGoods_0_0101Null
    
    --print  dbo.getTimeStr(GETDATE())+''  1311''
	
	update a
	set a.Sale_'+@MMDAY1+'=isnull(b.Sale1231,0)+isnull(a.Sale_'+@MMDAY1+',0),
	a.Saletj_'+@MMDAY1+'=isnull(b.Saletj1231,0)+isnull(a.Saletj_'+@MMDAY1+',0),
	a.Sale_'+@MMDAY1+'31=isnull(b.Sale1231,0),
	a.Saletj_'+@MMDAY1+'31=isnull(b.Saletj1231,0)              
	from '+@PosWhName+'_Sale.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' a, #temp_SaleGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO and a.cSupNo=b.cSupNo   	
	

	if (select object_id(''tempdb..#temp_CostGoods_0_1231''))is not null
	begin
	   drop table #temp_CostGoods_0_1231
	end
	if (select object_id(''tempdb..#temp_CostGoods_0_0101''))is not null
	begin
	   drop table #temp_CostGoods_0_0101
	end
	if (select object_id(''tempdb..#temp_QtyGoods_0_1231''))is not null
	begin
	   drop table #temp_QtyGoods_0_1231
	end
	if (select object_id(''tempdb..#temp_QtyGoods_0_0101''))is not null
	begin
	drop table #temp_QtyGoods_0_0101
	end
	if (select object_id(''tempdb..#temp_SaleGoods_0_1231''))is not null
	begin
	   drop table #temp_SaleGoods_0_1231
	end
	
    ')
end
--print  dbo.getTimeStr(GETDATE())
--print  14
/*------------------获取会员销售明细-来客数  会员销售--------------*/

   if (select object_id('tempdb..#temp_GoodsvipSale')) is not null
   drop table #temp_GoodsvipSale
   create table #temp_GoodsvipSale(dSaleDate datetime,cSaleSheetno varchar(32),
   cGoodsno varchar(32),fQuantity money,fLastSettle money,vipCount bigint,
   cVipNo varchar(32))

	declare @date1 datetime
	declare @date2 datetime
	set @date1=@SheetDate
	set @date2=@SheetDate
 
   if exists (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date1)  -- 包含在时间断内
   begin
	if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
	create table #temp_SaleSheetInfor(databasename varchar(64))
	declare @SalesheetDate datetime
	select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

	insert into #temp_SaleSheetInfor(databasename)
	select a.databasename from (
	select * from t_SaleSheetInfor
	where SaleEnd>=@date1 ) a,(
	select * from t_SaleSheetInfor
	where SaleBegin<=@date2) b
	where a.DataBaseName=b.DataBaseName

	declare SaleSheetInfor_cursor1 cursor
	for
	select databasename
	from #temp_SaleSheetInfor

	declare @InfoName1 varchar(32)

	open SaleSheetInfor_cursor1
	fetch next from SaleSheetInfor_cursor1
	into @InfoName1

	  while @@fetch_status=0
	  begin		 
        exec('	
                insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo
				from '+@InfoName1+'.dbo.t_SaleSheetDetail with (nolock)
				where dSaleDate='''+@date1+'''  --and ISNULL(cVipNo,'''')<>''''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
		  ')					  
		fetch next from SaleSheetInfor_cursor1
		into @InfoName1
	  end

	  close SaleSheetInfor_cursor1
	  deallocate SaleSheetInfor_cursor1
	  
		if not exists  (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date2)
		begin  	   
			    insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo
				from t_SaleSheetDetail with (nolock)
				--where dSaleDate=@date1  --and ISNULL(cVipNo,'')<>''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
			 
		end		
		end else
		begin   
				insert into #temp_GoodsvipSale(dSaleDate,cGoodsno,cSaleSheetno,fQuantity,fLastSettle,cVipNo)
				select dSaleDate,cGoodsNo,cSaleSheetno,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),cVipNo--,vipCount=COUNT(cVipNo)
				from t_SaleSheetDetail with (nolock)
				where dSaleDate=@date1  --and ISNULL(cVipNo,'')<>''
				group by dSaleDate,cGoodsNo,cSaleSheetno,cVipNo
		end
		
--print  dbo.getTimeStr(GETDATE())
--print  15 
-----------获取商品总销售来客数

if (select OBJECT_ID('tempdb..#temp_SaleSheetLk'))is not null drop table #temp_SaleSheetLk
select cGoodsno,lk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
viplk=CAST(null as money),fQuantityVip=CAST(null as money),fLastSettleVip=CAST(null as money)
into #temp_SaleSheetLk
from #temp_GoodsvipSale
group by cGoodsno

 -----------获取商品vip来客数
 
if (select OBJECT_ID('tempdb..#temp_SaleSheetvipLk'))is not null drop table #temp_SaleSheetvipLk
select cGoodsno,viplk=COUNT(*),fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle)
into #temp_SaleSheetvipLk
from #temp_GoodsvipSale
where ISNULL(cVipNo,'')<>''
group by cGoodsno
 
 
update a set a.viplk=b.viplk,a.fQuantityVip=b.fQuantity,a.fLastSettleVip=b.fLastSettle
from #temp_SaleSheetLk a,#temp_SaleSheetvipLk b
where a.cGoodsno=b.cGoodsno

CREATE INDEX IX_temp_SaleSheetvipL  ON #temp_SaleSheetvipLk(cGoodsNo) 

exec('
    if (select object_id(''tempdb..#temp_Vip_0_0101''))is not null
	begin
	  drop table #temp_Vip_0_0101
	end
    select cGoodsNo
    into #temp_Vip_0_0101
    from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    CREATE INDEX IX_temp_Vip_0_0101  ON #temp_Vip_0_0101(cGoodsNo) 

    if (select object_id(''tempdb..#temp_Vip_0_0101Null''))is not null
	begin
	  drop table #temp_Vip_0_0101Null
	end

    select a.cGoodsNo,cYear='''+@Y1+'''
    into #temp_Vip_0_0101Null
	from #temp_SaleSheetLk a left join #temp_Vip_0_0101 b
	on a.cGoodsNo=b.cGoodsNO  
	where isnull(b.cGoodsNO,'''')=''''
	
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_01(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_02(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_03(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_04(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_05(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_06(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_07(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_08(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_09(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_10(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_11(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_12(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	

	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_01(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_02(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_03(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_04(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_05(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_06(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_07(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_08(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_09(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_10(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_11(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_12(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	

 
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_01(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_02(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_03(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_04(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_05(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_06(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_07(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_08(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_09(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_10(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_11(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_12(cGoodsNO,cYear)
	select  cGoodsNo,cYear from #temp_Vip_0_0101Null
	
	if (select object_id(''tempdb..#temp_Vip_0_0101''))is not null
	begin
	  drop table #temp_Vip_0_0101
	end

')
--print  dbo.getTimeStr(GETDATE())
--print  15

exec(' 
------------修改数量
update b set 
b.fQty_'+@MMDAY1+'=isnull(b.fQty_'+@MMDAY1+',0)+isnull(a.fQuantityVip,0) 
from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' b,#temp_SaleSheetLk a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO    
 
------------修改会员销售金额
  
update b set b.Sale_'+@MMDAY1+'=isnull(b.Sale_'+@MMDAY1+',0)+isnull(a.fLastSettleVip,0)  
from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' b,#temp_SaleSheetLk a
where b.cYear='''+@Y1+''' and b.cGoodsNo=a.cGoodsNO    

 
-------- 修改总来客数 和会员来客数
update b set b.Qty_'+@MMDAY1+'=isnull(b.Qty_'+@MMDAY1+',0)+isnull(a.viplk,0),
b.Qtyzs_'+@MMDAY1+'=isnull(b.Qtyzs_'+@MMDAY1+',0)+isnull(a.lk,0) 
from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' b,#temp_SaleSheetLk a
where b.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO      
 
 
')
--print  dbo.getTimeStr(GETDATE())
--print  16
if (@M1+@Day1)<>'0101'
begin
   if @Day1='01'
   begin
        exec('
		update a set 
		fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY_1+',0)+isnull(fQty_'+@MMDAY1+',0) 
		from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' a,
		(
		   select  cGoodsNo,fQty_'+@MMDAY_1+'
		   from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO 
		')
		
		exec('
		update a set 
		Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY_1+',0)+isnull(Sale_'+@MMDAY1+',0)   
		from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' a,
		(
		   select  cGoodsNo,Sale_'+@MMDAY_1+'
		   from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO  
		')
		
		exec('
		update a set 
		Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY_1+',0)+isnull(Qtyzs_'+@MMDAY1+',0),
		Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY_1+',0)+isnull(Qty_'+@MMDAY1+',0)  
		from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' a,
		(
		   select  cGoodsNo,Qty_'+@MMDAY_1+',Qtyzs_'+@MMDAY_1+'
		   from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M_1+'
		   where cYear='''+@Y1+'''  
		) c
		where a.cYear='''+@Y1+''' and  a.cGoodsNo=c.cGoodsNO 
		')
   end else
   begin
	exec('
	------------修改会员销售数量 
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+'
	set fQty_'+@MMDAY1+'=isnull(fQty_'+@MMDAY1+',0)+isnull(fQty_'+@MMDAY_1+',0)
	where cYear='''+@Y1+'''  
	------------修改会员销售金额
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+'
	set Sale_'+@MMDAY1+'=isnull(Sale_'+@MMDAY1+',0)+isnull(Sale_'+@MMDAY_1+',0)
	where cYear='''+@Y1+'''  
	-------- 修改总来客数 和会员来客数
	update '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+'
	set Qtyzs_'+@MMDAY1+'=isnull(Qtyzs_'+@MMDAY1+',0)+isnull(Qtyzs_'+@MMDAY_1+',0),
	Qty_'+@MMDAY1+'=isnull(Qty_'+@MMDAY1+',0)+isnull(Qty_'+@MMDAY_1+',0)
	where cYear='''+@Y1+'''  
	')
    end 

end else
begin
    exec('
    ---- 获取上一年的数据
    if (select object_id(''tempdb..#temp_QtyVipGoods_0_1231''))is not null
	begin
	  drop table #temp_QtyVipGoods_0_1231
	end
    select cGoodsNo,fQty1231=isnull(fQty_'+@MMDAY_1+',0)
    into #temp_QtyVipGoods_0_1231
    from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
   if (select object_id(''tempdb..#temp_QtyVipGoods_0_0101''))is not null
	begin
	  drop table #temp_QtyVipGoods_0_0101
	end
    select cGoodsNo
    into #temp_QtyVipGoods_0_0101
    from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+'
    with (nolock) 
    where cYear='''+@Y1+'''  
    
    CREATE INDEX IX_temp_QtyVipGoods_0_0101  ON #temp_QtyVipGoods_0_0101(cGoodsNo) 

    
    if (select object_id(''tempdb..#temp_VipGoodsNull''))is not null
	begin
	  drop table #temp_VipGoodsNull
	end
    select a.cGoodsNo,cYear='''+@Y1+''' 
    into #temp_VipGoodsNull
	from #temp_QtyVipGoods_0_1231 a left join #temp_QtyVipGoods_0_0101 b
	on a.cGoodsNo=b.cGoodsNO 
	where isnull(b.cGoodsNO,'''')=''''
    
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_01(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_02(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_03(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_04(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_05(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_06(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_07(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_08(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_09(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_10(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_11(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_12(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull 
	
	update a
	set a.fQty_'+@MMDAY1+'=isnull(b.fQty1231,0)+isnull(a.fQty_'+@MMDAY1+',0),
	a.fQty_'+@MMDAY1+'31=isnull(b.fQty1231,0)
	from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_QtyVip_'+@M1+' a, #temp_QtyVipGoods_0_1231 b
	where a.cYear='''+@Y1+''' and a.cGoodsNo=b.cGoodsNO    	
	
	
	if (select object_id(''tempdb..#temp_SaleVipGoods_0_1231''))is not null
	begin
	  drop table #temp_SaleVipGoods_0_1231
	end
    select cGoodsNo,Sale1231=isnull(Sale_'+@MMDAY_1+',0)
    into #temp_SaleVipGoods_0_1231
    from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_01(cGoodsNO,cYear) 
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_02(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_03(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_04(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_05(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_06(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_07(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_08(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_09(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_10(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_11(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_12(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull 
	
	
	update a
	set a.Sale_'+@MMDAY1+'=isnull(b.Sale1231,0)+isnull(a.Sale_'+@MMDAY1+',0),
	a.Sale_'+@MMDAY1+'31=isnull(b.Sale1231,0) 
	from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_SaleVip_'+@M1+' a, #temp_SaleVipGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cYear='''+@Y1+'''	
	
 
	if (select object_id(''tempdb..#temp_VipCountGoods_0_1231''))is not null
	begin
	  drop table #temp_VipCountGoods_0_1231
	end
    select cGoodsNo,Qtyzs1231=isnull(Qtyzs_'+@MMDAY_1+',0),Qty1231=isnull(Qty_'+@MMDAY_1+',0)
    into #temp_VipCountGoods_0_1231
    from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M_1+'
    with (nolock) 
    where cYear='''+@Y_1+'''  
    
    insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_01(cGoodsNO,cYear) 
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_02(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_03(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_04(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_05(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_06(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_07(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_08(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_09(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_10(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_11(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull
	insert into '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_12(cGoodsNO,cYear)
	select cGoodsNo,cYear from #temp_VipGoodsNull 
	
	update a
	set a.Qtyzs_'+@MMDAY1+'=isnull(b.Qtyzs1231,0)+isnull(a.Qtyzs_'+@MMDAY1+',0),
	a.Qty_'+@MMDAY1+'=isnull(b.Qty1231,0)+isnull(a.Qty_'+@MMDAY1+',0),
	a.Qtyzs_'+@MMDAY1+'31=isnull(b.Qtyzs1231,0),
	a.Qty_'+@MMDAY1+'31=isnull(b.Qty1231,0)
	from '+@PosWhName+'_Vip.dbo.t_WH_Form_Log_Day_VipCount_'+@M1+' a, #temp_VipCountGoods_0_1231 b
	where a.cGoodsNo=b.cGoodsNO and a.cYear='''+@Y1+'''	
	
	
	 if (select object_id(''tempdb..#temp_QtyVipGoods_0_1231''))is not null
	begin
	  drop table #temp_QtyVipGoods_0_1231
	end
	 if (select object_id(''tempdb..#temp_QtyVipGoods_0_0101''))is not null
	begin
	  drop table #temp_QtyVipGoods_0_0101
	end
	 if (select object_id(''tempdb..#temp_VipGoodsNull''))is not null
	begin
	  drop table #temp_VipGoodsNull
	end
			if (select object_id(''tempdb..#temp_SaleVipGoods_0_1231''))is not null
	begin
	  drop table #temp_SaleVipGoods_0_1231
	end 
	if (select object_id(''tempdb..#temp_VipCountGoods_0_1231''))is not null
	begin
	  drop table #temp_VipCountGoods_0_1231
	end
	
    ')
end

update t_Daily_history set bPosWhFormLog=1
where dDate=@SheetDate

if @Day1='01'
begin
   declare @riqi1 varchar(32)
   declare @riqi2 varchar(32) 
   set @riqi1=dbo.getdaystr(DATEADD(MONTH,-1,@SheetDate))
   set @riqi2=dbo.getdaystr(@SheetDate_1)   
    
   exec('   
    if not exists (select top 1 dDateBgn from '+@PosWhName+'.dbo.t_WH_Form_Log_Month where dDateBgn='''+@riqi1+''')  -- 包含在时间断内
	begin
	  insert into '+@PosWhName+'.dbo.t_WH_Form_Log_Month
	   (dDateBgn,dDateEnd,cGoodsNo,cSupplierNo,cWhNo)
	   values('''+@riqi1+''','''+@riqi2+''','''','''','''')
	end
   ')
end

--print  dbo.getTimeStr(GETDATE())
--print  17

  commit tran 
 set @return=1
end try
begin catch
  rollback   
  set @return=0
  
end catch

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
if (select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
begin
 drop table #temp_PicWhFormcGoods_WH_Form_Log
end
if (select object_id('tempdb..#temp_MaxPicWhFormcGoods_0'))is not null
begin
  drop table #temp_MaxPicWhFormcGoods_0
end
if (select object_id('tempdb..#temp_SumcGoodsSaleDate1'))is not null
begin
 drop table #temp_SumcGoodsSaleDate1
end
if (select object_id('tempdb..#temp_LeftGoods_0'))is not null
begin
 drop table #temp_LeftGoods_0
end 
if (select object_id('tempdb..#temp_INGoods_0'))is not null
begin
 drop table #temp_INGoods_0
end
 if (select object_id('tempdb..#temp_DivideGoods_0'))is not null
begin
 drop table #temp_DivideGoods_0
end
if (select object_id('tempdb..#temp_EffusionGoods_0'))is not null
begin
 drop table #temp_EffusionGoods_0
end
 if (select object_id('tempdb..#temp_ReturnGoods_0'))is not null
begin
 drop table #temp_ReturnGoods_0
end
if (select object_id('tempdb..#temp_TfrInGoods_0'))is not null
begin
 drop table #temp_TfrInGoods_0
end
if (select object_id('tempdb..#temp_OutGoods_0'))is not null
begin
 drop table #temp_OutGoods_0
end
if (select object_id('tempdb..#temp_RbdGoods_0'))is not null
begin
 drop table #temp_RbdGoods_0
end
if (select object_id('tempdb..#temp_LossGoods_0'))is not null
begin
 drop table #temp_LossGoods_0
end
if (select object_id('tempdb..#temp_TfrGoods_0'))is not null
begin
 drop table #temp_TfrGoods_0
end
if (select object_id('tempdb..#temp_PackGoods_0'))is not null
begin
 drop table #temp_PackGoods_0
end
   if (select object_id('tempdb..#temp_GoodsvipSale')) is not null
   drop table #temp_GoodsvipSale
if (select OBJECT_ID('tempdb..#temp_SaleSheetLk'))is not null drop table #temp_SaleSheetLk
if (select OBJECT_ID('tempdb..#temp_SaleSheetvipLk'))is not null drop table #temp_SaleSheetvipLk


GO
