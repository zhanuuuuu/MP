 
 create proc p_UpcStoreGoodsDazhe
 @cStoreNo varchar(32),
 @cGoodsNo varchar(32),
 @bDazhe int,
 @cUnit varchar(16),
 @cOpertNo varchar(32),
 @cOpertName varchar(64)
 as
 begin
     update t_cStoreGoods set bDaZhe=@bDazhe,cUnit=@cUnit
     where cStoreNo=@cStoreNo and cGoodsNo=@cGoodsNo
     
     delete t_ChangeGoods where cStoreNo=@cStoreNo and cGoodsNo=@cGoodsNo
     insert into t_ChangeGoods(cGoodsNo,cStoreNo)
     values(@cGoodsNo,@cStoreNo)
     declare @opertion varchar(256)
     set @opertion='修改商品信息打折:'+cast(@bDazhe as varchar)+' 单位:'+@cUnit
     ---写入日志
     exec p_Log @cOpertNo,@cOpertName,@opertion,'手机调整'
 end
 GO
