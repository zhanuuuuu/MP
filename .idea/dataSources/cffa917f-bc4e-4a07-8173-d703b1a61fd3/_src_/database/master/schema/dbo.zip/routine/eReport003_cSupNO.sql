CREATE procedure [dbo].[eReport003_cSupNO]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as
--declare @dBeginDate datetime,@dEndDate datetime,@cWHno varchar(32)
--select @dBeginDate='2011-11-01',@dEndDate='2011-12-01',@cWHno='01'
if (select OBJECT_ID('tempdb..#t_Goods'))is not null drop table #t_Goods 

select cGoodsNo,cSupplierNo=cSupNo into #t_goods from t_goods where bStorage=1 and cSupNo in 
(--'81004'----'83017'--'82023','81001','82034'
select cSupNo from #admin_cSupNo
--select cSupNo from t_Supplier
)
--select cGoodsNo,cSupplierNo=cSupNo into #t_Goods from t_goods where cSupNo ='81004' and bStorage=1
  
  declare @dMaxDailyDate datetime
  set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)

  declare @dBeginDate_detail datetime
  set @dBeginDate_detail=case when @dMaxDailyDate>=@dDate1 then @dMaxDailyDate+1 else  @dDate2 end
--                销售单                 开始    
if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf 
  select a.cGoodsNo,b.fQuantity,b.fLastSettle,
         h0=0, h1=0, h2=0, h3=0, h4=0, h5=0, h6=0, h7=0, h8=0, h9=0, h10=0,h11=0,
         h12=0,h13=0,h14=0,h15=0,h16=0,h17=0,h18=0,h19=0,h20=0,h21=0,h22=0,h23=0,
         h0_q=0, h1_q=0, h2_q=0, h3_q=0, h4_q=0, h5_q=0, h6_q=0, h7_q=0, h8_q=0, h9_q=0, h10_q=0,h11_q=0,
         h12_q=0,h13_q=0,h14_q=0,h15_q=0,h16_q=0,h17_q=0,h18_q=0,h19_q=0,h20_q=0,h21_q=0,h22_q=0,h23_q=0
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      ,t_SaleSheetDetail b
        where 
        
       (b.dSaleDate between @dBeginDate_detail and @dDate2)
       and a.cGoodsNo=b.cGoodsNo 
       and b.cWHno=@cWHno
       and isnull(tag_daily,0)=0  --未日结
  union all
  select a.cGoodsNo,b.fQuantity,b.fLastSettle,
         b.h0, b.h1, b.h2, b.h3, b.h4, b.h5, b.h6, b.h7, b.h8, b.h9, b.h10,b.h11,
         b.h12,b.h13,b.h14,b.h15,b.h16,b.h17,b.h18,b.h19,b.h20,b.h21,b.h22,b.h23,
         b.h0_q, b.h1_q, b.h2_q, b.h3_q, b.h4_q, b.h5_q, b.h6_q, b.h7_q, b.h8_q, b.h9_q, b.h10_q,b.h11_q,
         b.h12_q,b.h13_q,b.h14_q,b.h15_q,b.h16_q,b.h17_q,b.h18_q,b.h19_q,b.h20_q,b.h21_q,b.h22_q,b.h23_q
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       t_SaleSheet_Day b
         where 
  (b.dSaleDate between @dDate1 and @dDate2)
  and a.cGoodsNo=b.cGoodsNo
       and b.cWHno=@cWHno
  
  union all
  select a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,
         h0=0, h1=0, h2=0, h3=0, h4=0, h5=0, h6=0, h7=0, h8=0, h9=0, h10=0,h11=0,
         h12=0,h13=0,h14=0,h15=0,h16=0,h17=0,h18=0,h19=0,h20=0,h21=0,h22=0,h23=0,
         h0_q=0, h1_q=0, h2_q=0, h3_q=0, h4_q=0, h5_q=0, h6_q=0, h7_q=0, h8_q=0, h9_q=0, h10_q=0,h11_q=0,
         h12_q=0,h13_q=0,h14_q=0,h15_q=0,h16_q=0,h17_q=0,h18_q=0,h19_q=0,h20_q=0,h21_q=0,h22_q=0,h23_q=0
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c
         where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dDate1 and @dDate2)
         and c.cWhNo=@cWHno

if (select OBJECT_ID('tempdb..#t_SaleSheetDetail1'))is not null drop table #t_SaleSheetDetail1 
  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney,
         sum(isnull(h0,0)) as h0,   sum(isnull(h1,0)) as h1,   sum(isnull(h2,0)) as h2, 
         sum(isnull(h3,0)) as h3,   sum(isnull(h4,0)) as h4,   sum(isnull(h5,0)) as h5,
         sum(isnull(h6,0)) as h6,   sum(isnull(h7,0)) as h7,   sum(isnull(h8,0)) as h8,
         sum(isnull(h9,0)) as h9,   sum(isnull(h10,0)) as h10, sum(isnull(h11,0)) as h11,
         sum(isnull(h12,0)) as h12, sum(isnull(h13,0)) as h13, sum(isnull(h14,0)) as h14,
         sum(isnull(h15,0)) as h15, sum(isnull(h16,0)) as h16, sum(isnull(h17,0)) as h17,
         sum(isnull(h18,0)) as h18, sum(isnull(h19,0)) as h19,sum(isnull(h20,0)) as h20, 
         sum(isnull(h21,0)) as h21, sum(isnull(h22,0)) as h22,sum(isnull(h23,0)) as h23,
         sum(isnull(h0_q,0)) as h0_q,   sum(isnull(h1_q,0)) as h1_q,   sum(isnull(h2_q,0)) as h2_q, 
         sum(isnull(h3_q,0)) as h3_q,   sum(isnull(h4_q,0)) as h4_q,   sum(isnull(h5_q,0)) as h5_q,
         sum(isnull(h6_q,0)) as h6_q,   sum(isnull(h7_q,0)) as h7_q,   sum(isnull(h8_q,0)) as h8_q,
         sum(isnull(h9_q,0)) as h9_q,   sum(isnull(h10_q,0)) as h10_q, sum(isnull(h11_q,0)) as h11_q,
         sum(isnull(h12_q,0)) as h12_q, sum(isnull(h13_q,0)) as h13_q, sum(isnull(h14_q,0)) as h14_q,
         sum(isnull(h15_q,0)) as h15_q, sum(isnull(h16_q,0)) as h16_q, sum(isnull(h17_q,0)) as h17_q,
         sum(isnull(h18_q,0)) as h18_q, sum(isnull(h19_q,0)) as h19_q,sum(isnull(h20_q,0)) as h20_q, 
         sum(isnull(h21_q,0)) as h21_q, sum(isnull(h22_q,0)) as h22_q,sum(isnull(h23_q,0)) as h23_q
  into #t_SaleSheetDetail1  --销售单
  from #t_SaleSheetDetail_shelf
  group by cGoodsNo
--               销售单                 结束 

--合并  开始
if (select OBJECT_ID('tempdb..#temp_goodsKuCun1_NoZero'))is not null drop table #temp_goodsKuCun1_NoZero 
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dDate1,EndDate=@dDate2,a.cSupplierNo,o.cSupName,
                  m.h0, m.h1, m.h2, m.h3, m.h4, m.h5, m.h6, m.h7, m.h8, m.h9, m.h10,m.h11,
                  m.h12,m.h13,m.h14,m.h15,m.h16,m.h17,m.h18,m.h19,m.h20,m.h21,m.h22,m.h23,
                  m.h0_q, m.h1_q, m.h2_q, m.h3_q, m.h4_q, m.h5_q, m.h6_q, m.h7_q, m.h8_q, m.h9_q, m.h10_q,m.h11_q,
                  m.h12_q,m.h13_q,m.h14_q,m.h15_q,m.h16_q,m.h17_q,m.h18_q,m.h19_q,m.h20_q,m.h21_q,m.h22_q,m.h23_q,
                  xsQty=m.qty,xsMoney=m.fLastMoney,y.fQty_CurWH
      into #temp_goodsKuCun1_NoZero from #t_Goods a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , t_Supplier o --on a.cSupplierNo=o.cSupNo
                             , #t_SaleSheetDetail1 m --on a.GoodsNo_Pdt=m.GoodsNo
												     , t_Goods_CurWH y 		
                             where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=y.cGoodsNo and a.cGoodsNo=m.cGoodsNo and a.cSupplierNo=o.cSupNo
                                     and y.cWHno=@cWHno
--合并  结束
         if (select object_id('tempdb..#temp_ready'))is not null drop table #temp_ready
         if (select object_id('tempdb..#temp_ready1'))is not null drop table #temp_ready1
         select cSupplierNo,cSupName,GoodsNo_Pdt,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fQty_CurWH=isnull(fQty_CurWH,0),BeginDate,EndDate,c_kun=cast(null as varchar(10)),
         c_type=CAST(null as varchar(50)),sale_days=CAST(null as int)
         into #temp_ready1
		 from #temp_goodsKuCun1_NoZero
		 	  
update #temp_ready1
set sale_days=
case when fQty_CurWH<0 then null else fQty_CurWH end/
case when xsQty=0 then null else xsQty end * 
case when DateDiff(d,@dDate1,@dDate2)=0 then 1 else DateDiff(d,@dDate1,@dDate2)end

update a
set c_kun='负库存'
from #temp_ready1 a
where fQty_CurWH<0

update #temp_ready1
set c_type='零销售',sale_days=1000
where xsQty=0

create table #temp_ready
(id int identity,cSupplierNo varchar(50),cSupName varchar(50),GoodsNo_Pdt varchar(50),cGoodsName varchar(50),cBarcode varchar(50),cUnit varchar(50),
cSpec varchar(50),fNormalPrice varchar(50),cGoodsTypeno varchar(50),cGoodsTypename varchar(50),xsQty money,xsMoney money,fQty_CurWH money,
BeginDate datetime,EndDate datetime,c_kun varchar(10),c_type varchar(50),sale_days real
)
insert into #temp_ready 
(cSupplierNo,cSupName,GoodsNo_Pdt,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,xsQty,xsMoney,fQty_CurWH,
BeginDate,EndDate,c_kun,c_type,sale_days)
select * from #temp_ready1 where c_type is null order by c_kun desc,sale_days asc,xsMoney desc
insert into #temp_ready
(cSupplierNo,cSupName,GoodsNo_Pdt,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,xsQty,xsMoney,fQty_CurWH,
BeginDate,EndDate,c_kun,c_type,sale_days)
select * from #temp_ready1 where c_type is not null order by c_kun desc,sale_days asc,xsMoney desc

declare @count int
declare @count_20 int
declare @count_80 int
select @count=COUNT(*) from #temp_ready where c_type is null
set @count_20=@count*0.2
set @count_80=@count*0.8
--select @count , @count_20, @count_80
update #temp_ready 
set c_type='畅销商品'
where id<=@count_20

update #temp_ready 
set c_type='一般商品'
where id<=@count_80 and id>@count_20

update #temp_ready 
set c_type='滞销商品'
where id>@count_80 

update #temp_ready
set c_kun='高库存'
where sale_days>20

update #temp_ready
set c_kun='低库存'
where sale_days<7

update #temp_ready
set c_kun='正常库存'
where c_kun is null

update #temp_ready
set c_type='零销售',sale_days=null
where xsQty=0

select cSupplierNo as 供应商NO,cSupName as 供应商名称,GoodsNo_Pdt as 商品NO,'['+cBarcode+']' as 商品条码,cGoodsName as 商品名称,
cUnit as 规格,fNormalPrice as 售价,包装=cSpec,销售数量=isnull(xsQty,0),销售金额=isnull(xsMoney,0),库存数量=isnull(fQty_CurWH,0),
库存状态=c_kun,库存周转天数=sale_days,销售状态=c_type,cGoodsTypeno as 类别NO,cGoodsTypename as 类别名称,
BeginDate as 期初日期,EndDate as 期末日期
from #temp_ready order by sale_days asc,xsMoney desc


GO
