/*
返回：0 异常
      1 成功
      2 删除失败：已审核或者是已收货
*/

CREATE proc p_DeleteBhOrder
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@cSheetNoList varchar(8000), --补货单集合
@return int output        --返回值
as
begin
  begin try 
  begin tran
	if (select object_id('tempdb..#tmp_List'))is not null
	begin
	  drop table #tmp_List
	end
	create table #tmp_List(cSheetNo varchar(32)) 
	insert into #tmp_List(cSheetNo)
	select * from dbo.SplitStr(@cSheetNoList,',')
	
	if (select object_id('tempdb..#tmp_SheetList'))is not null
	begin
	  drop table #tmp_SheetList
	end
	
	select cSheetno into #tmp_SheetList
	from WH_BhApply a,#tmp_List b
	where a.cStoreNo=@Merchantid and a.cSheetno=b.cSheetNo
	and isnull(a.bExamin,0)=0 and isnull(a.bReceive,0)=0
	
	delete a 
	from WH_BhApplyDetail a,#tmp_SheetList b
	where a.cSheetno=b.cSheetno
	
	delete a 
	from WH_BhApply a,#tmp_SheetList b
	where a.cSheetno=b.cSheetno
	
	
	if @@rowcount>0
	BEGIN
	  set @return=1
	end else
	BEGIN
	  set @return=2 
	end	
	
	commit tran
    
	end try
	begin catch  
	   rollback  
	  set @return=0
	end catch
end
GO
