CREATE proc p_UpMerchantDevice
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@name varchar(64),    --
@iType int,   -- 设备类型设备类型，其取值由运营商而非商家来确 定。参考取值如下： 
--1：先付钱后取货自动售货机 2：先开门取货后付钱自动售货机 3：开放式货架 4：无人值守便利店
@cAddRess varchar(64),--'设备地址',
@cMapLocation varchar(32), --'经纬度',
@cDescription  varchar(256),--'描述',
@dCreateDate varchar(32),-- '投放时间'           
@return int output        --返回值
as
begin
      begin try 
	  begin tran
		  update t_posstation SET iType=CASE WHEN @iType=0 THEN iType ELSE @iType end,
		  cAddRess=CASE WHEN @cAddRess='' THEN cAddRess ELSE @cAddRess end,
		  cMapLocation=CASE WHEN @cMapLocation='' THEN cMapLocation ELSE @cMapLocation end,
		  cDescription=CASE WHEN @cDescription='' THEN cDescription ELSE @cDescription end,
		  dCreateDate=CASE WHEN @dCreateDate='' THEN dCreateDate ELSE @dCreateDate end
          where cStoreNo=@Merchantid  and posname=@name  
          IF @@rowcount=1
          begin          
            set @return=1
          end else
          begin            
            set @return=2
          end
		  commit tran	    
		end try
		begin catch  
		   rollback  
		   set @return=0
		end catch
end
GO
