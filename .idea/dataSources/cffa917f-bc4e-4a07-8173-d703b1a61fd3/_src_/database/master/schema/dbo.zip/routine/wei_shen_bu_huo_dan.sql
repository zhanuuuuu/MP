    CREATE proc [dbo].[wei_shen_bu_huo_dan]
    @dDate1 datetime,  --- 日期1
    @dDate2 datetime,  --- 日期    
    @cStoreno  varchar(20)
    as
    select a.cSheetno,cStoreNo,cStoreName,cOperator,cOperatorNo,fInMoney as Z_fInMoney,
    cGoodsNo,cGoodsName,cBarcode,fQuantity,fInPrice,fInMoney,cUnit
    
     from WH_BhApply a,WH_BhApplyDetail  b 
    where a.cSheetno=b.cSheetno and dDate between 
    @dDate1 and @dDate2 and cStoreNo=@cStoreno 
    and  ISNULL(a.bPeisong ,0)=0 and ISNULL(MbExamin ,0)=0

    GO
