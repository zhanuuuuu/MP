


CREATE function [dbo].[f_GenPalletSheet]
(@cYear varchar(4),@mm varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.wh_PalletSheet
                  where datename(yyyy,dDate)=@cYear and datename(MM,dDate)=@mm
                 )
   if @cMaxSerno is null 
   begin
     return  'TP'+@cYear+@mm+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'TP'+@cYear+@mm+'-'+@cMaxSerno 
   end

  return '' 
end


GO
