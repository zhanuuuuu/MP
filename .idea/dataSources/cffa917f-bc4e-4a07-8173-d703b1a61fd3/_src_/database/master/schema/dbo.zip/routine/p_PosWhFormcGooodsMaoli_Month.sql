/*

  p_PosWhFormcGooodsMaoli_Month '2013-08-01','2013-09-30','01','Pos_Wh_Form'
  
*/
create proc p_PosWhFormcGooodsMaoli_Month
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32),
@DbName varchar(32)
as
begin
   declare @dDate1 varchar(32)
   declare @dDate2 varchar(32)
 
   set @dDate1=dbo.getdaystr(DATEADD(MONTH,-1,@dDateBgn))
   set @dDate2=dbo.getdaystr(CAST((cast(YEAR(@dDateEnd) as varchar(16))+'-'+cast(MONTH(@dDateEnd) as varchar(16))+'-01') AS DATETIME))
   
	if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods
	select distinct cGoodsNo into #temp_WhFromGoods from #tmp_WhGoodsList

	CREATE INDEX IX_temp_WhFromGoods  ON #temp_WhFromGoods(cGoodsNo)
                                        
	if(select object_id('tempdb..#temp_WhFromheji_Month')) is not null drop table #temp_WhFromheji_Month
	CREATE TABLE #temp_WhFromheji_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(64) null,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money)
	
	if(select object_id('tempdb..#temp_WhFromendheji_Month')) is not null drop table #temp_WhFromendheji_Month
	CREATE TABLE #temp_WhFromendheji_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(64) null,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money)
	------获取基础的库存-----
 
     -------获取时间段内的进销存-------
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_heji_month''))is not null  drop table #temp_Wh_Goods_heji_month
	select a.[cGoodsNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_heji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate1+''' and a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_monthheji''))is not null  drop table #temp_SumWh_Goods_monthheji
	select cgoodsno,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),			  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goods_monthheji
	from  #temp_Wh_Goods_heji_month
	group by cgoodsno
				
	insert into #temp_WhFromheji_Month([cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	fMoney_cost,fPrice_Avg,fml)
	select [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goods_monthheji    

')
 
 exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endheji_month''))is not null  drop table #temp_Wh_Goods_endheji_month
	select a.[cGoodsNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_endheji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate2+''' and a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endmonthheji''))is not null  drop table #temp_SumWh_Goods_endmonthheji
	select cgoodsno,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),			  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goods_endmonthheji
	from  #temp_Wh_Goods_endheji_month
	group by cgoodsno
				
	insert into #temp_WhFromendheji_Month([cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	fMoney_cost,fPrice_Avg,fml)
	select [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goods_endmonthheji    

')
 
 
    
   update a
   set a.销售数量=isnull(a.销售数量,0)-isnull(b.销售数量,0),a.销售金额=isnull(a.销售金额,0)-isnull(b.销售金额,0),
   a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
   a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
   a.fMoney_cost=isnull(a.fMoney_cost,0)-isnull(b.fMoney_cost,0),a.fml=isnull(a.fml,0)-isnull(b.fml,0)
   from #temp_WhFromendheji_Month a,#temp_WhFromheji_Month b
   where a.cGoodsNo=b.cGoodsNo
 
	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
	select cGoodsNo,xsQty=销售数量, xsMoney=销售金额,fMoney_Cost,fml,cSupplierNo,cSupplier,fPrice_Avg
	into #temp_goodsKuCunml
	from #temp_WhFromendheji_Month  --where  isnull(fml,0)<>0

 
      if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
      select cGoodsNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
       cSupplierNo,cSupplier,fPrice_Avg=AVG(fPrice_Avg)
      into #temp_SumgoodsKuCunml
      from #temp_goodsKuCunml
      group by cGoodsNo,cSupplierNo,cSupplier
      
      CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)
 
      
      if (select OBJECT_ID('tempdb..#temp_goodsKuCun1'))is not null  drop table #temp_goodsKuCun1
      select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
      b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo=b.cSupNo,b.cSupName,
      BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
	  fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost 
      into  #temp_goodsKuCun1
	  from #temp_SumgoodsKuCunml a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo  
	  order by a.cGoodsNo
	  
 
	  
	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
	select cGoodsNo,cUnitedNo,cGoodsName,cSupplierNo,cSupName,cBarcode,cUnit,cSpec,fNormalPrice,
	cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
	BeginDate,EndDate,
	xsQty=SUM(xsQty), xsMoney=SUM(xsMoney), 	 
	fCostPrice=avg(fCostPrice),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost),i=0
	into  #temp_goodsKuCun
	from #temp_goodsKuCun1
	group by cGoodsNo,cUnitedNo,cGoodsName,cSupplierNo,cSupName,cBarcode,cUnit,cSpec,fNormalPrice,
	cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
	BeginDate,EndDate
	order by cGoodsNo
	
	
    /*--------修改未主供应商防止出现多条数据----2015-05-05------*/
 update  a
 set a.cSupplierNo=b.csupno,a.cSupName=b.csupname
 --,a.cGoodsNo=ISNULL(b.cGoodsNo_minPackage,a.cGoodsNo),
 --a.xsQty=a.xsQty*(case when ISNULL(b.fQty_minPackage,0)=0 then 1 else b.fQty_minPackage end)
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno
 
 update  a
 set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*isnull(b.fQty_minPackage,1)
 from #temp_goodsKuCun a,t_Goods b
 where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''
 
 if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last0
 select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
 BeginDate,EndDate,cSupplierNo,b.cSupName,fMoney_Cost=sum(fMoney_Cost),
 fCostPrice=0,
 xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
 fML=sum(isnull(fML,0)),i
 into #temp_goodsKuCun_last0
  from #temp_goodsKuCun a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
 group by a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
 b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,BeginDate,EndDate,cSupplierNo,b.cSupName,i
 
	
 
if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null 
begin
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,
         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
         fCostPrice=case when isnull(a.fMoney_Cost,0)<>0
         then case when isnull(a.xsQty,0)<>0 then isnull(a.fMoney_Cost,0)/isnull(a.xsQty,0) else isnull(a.fCostPrice,0) end
         else isnull(a.fCostPrice,0) end,
         fML=isnull(a.fML,0),a.i
      into    #temp_goodsKuCun_last
  --from #temp_goodsKuCun a,#temp_GoodsTypeNo b
  from #temp_goodsKuCun_last0 a,#temp_GoodsTypeNo b
  where a.cGoodsTypeno=b.cGoodsTypeno
  
  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i
  from #temp_goodsKuCun_last 
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last  
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last 
  group by BeginDate,EndDate
  order by cSupplierNo,cGoodsNo,i
  
end else
begin
   select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
            --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(fMoney_Cost,0)<>0
         then case when isnull(xsQty,0)<>0 then isnull(fMoney_Cost,0)/isnull(xsQty,0) else isnull(fCostPrice,0) end
         else isnull(fCostPrice,0) end,
         fML=ISNULL(fML,0),i
   --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
   --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
    --from #temp_goodsKuCun 
  from #temp_goodsKuCun_last0
  group by BeginDate,EndDate
  order by cSupplierNo,cGoodsNo,i
end    
  
 
end
GO
