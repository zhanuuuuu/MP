CREATE proc getPei_song_yan_no

@year varchar(20),
@cCustomerNo varchar(20)
as
select  dbo.f_GencStoreOutsheetno_YH  (@year ,@cCustomerNo ) as Pei_song_yan_no
GO
