/*

  select cgoodsno into  #temp_GoodsByClient from t_Goods
  
  exec [p_GoodsByClient_List] '2015-05-01','2015-05-01'
  
*/
CREATE procedure [dbo].[p_GoodsByClient_List]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime
as
begin

	if(select object_id('tempdb..#temp_GoodsByClient_01')) is not null
	begin
		drop table #temp_GoodsByClient_01
	end 
	if(select object_id('tempdb..#temp_GoodsByClient_03')) is not null
	begin
		drop table #temp_GoodsByClient_03
	end 	
	if(select object_id('tempdb..#temp_GoodsByClient_02')) is not null
	begin
		drop table #temp_GoodsByClient_02
	end 
	
  select distinct cGoodsNo,cSaleSheetno,dSaleDate
  into #temp_GoodsByClient_011 
  from t_SaleSheetDetail
  where dSaleDate between @dDate1 and @dDate2
  
  and cGoodsNo in (select cGoodsNo from #temp_GoodsByClient)
    and ((@cStoreNo='--') and 1=1) 
		 or((@cStoreNo!='--')and cStoreNo=@cStoreNo)
		 
  group by dSaleDate,cSaleSheetno,cGoodsNo

  select cGoodsNo,iSerno=1,dSaleDate,iCount=COUNT(*),cBeizhu='',fMoney=cast(0.00 as money),fPrice_PerClient=cast(0.00 as money)
  into #temp_GoodsByClient_01
  from #temp_GoodsByClient_011
  group by dSaleDate,cGoodsNo
    
  select cGoodsNo,dSaleDate,fMoney=SUM(isnull(fLastSettle,0))
  into #temp_GoodsByClient_03 
  from t_SaleSheetDetail
  where dSaleDate between @dDate1 and @dDate2
  and cGoodsNo in (select cGoodsNo from #temp_GoodsByClient)
    and ((@cStoreNo='--') and 1=1) 
		 or((@cStoreNo!='--')and cStoreNo=@cStoreNo)
  group by dSaleDate,cGoodsNo
  
  update a set a.fMoney=b.fMoney,
  a.fPrice_PerClient=case when isnull(a.iCount,0)<>0 then isnull(b.fMoney,0)/a.iCount else 0.00 end
  from #temp_GoodsByClient_01 a,#temp_GoodsByClient_03 b
  where a.cGoodsNo=b.cGoodsNo and a.dSaleDate=b.dSaleDate
  
  
  select cGoodsNo,iSerno=1,dSaleDate,iCount,cBeizhu='',fMoney=isnull(fMoney,0),
  fPrice_PerClient=ISNULL(fPrice_PerClient,0),i=0
  into #temp_GoodsByClient_02
  from #temp_GoodsByClient_01
  union all
  select cGoodsNo,iSerno=99,dSaleDate=null,iCount=SUM(iCount),cBeizhu='小计:',fMoney=SUM(isnull(fMoney,0)),
  fPrice_PerClient=case when SUM(isnull(iCount,0))<>0 then SUM(isnull(fMoney,0))/SUM(isnull(iCount,0)) else 0.00 end
  ,i=1
  from #temp_GoodsByClient_01
    group by cGoodsNo
    union all
  select cGoodsNo='0',iSerno=9,dSaleDate=null,iCount=SUM(iCount),cBeizhu='总计:',fMoney=SUM(isnull(fMoney,0)),
  fPrice_PerClient=case when SUM(isnull(iCount,0))<>0 then SUM(isnull(fMoney,0))/SUM(isnull(iCount,0)) else 0.00 end
  ,i=2
  from #temp_GoodsByClient_01

  
  select a.cGoodsNo,a.iSerno,a.dSaleDate,a.iCount,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
  b.cGoodsTypename,b.cGoodsTypeno,a.cBeizhu,a.fMoney,a.fPrice_PerClient
  into #temp_GoodsLast
  from #temp_GoodsByClient_02 a 
  left join t_Goods b on a.cGoodsNo=b.cGoodsNo 
  --union all
  --select  cGoodsNo=null,iSerno=null,dSaleDate=null,iCount=SUM(iCount),cGoodsName=null,
  --cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
  --cGoodsTypename=null,cGoodsTypeno=null,cBeizhu='总计:',fMoney=SUM(fMoney),fPrice_PerClient=
  --from #temp_GoodsByClient_02 a 
  --left join t_Goods b on a.cGoodsNo=b.cGoodsNo
  --where cBeizhu='小计:'
  order by b.cGoodsTypeno,a.cGoodsNo,a.iSerno,a.dSaleDate 
  
  update #temp_GoodsLast set cGoodsTypeno='999999999'
  where ISNULL(cGoodsTypeno,'')=''
 
  select * from #temp_GoodsLast a
   order by a.cGoodsTypeno
   --,a.cGoodsNo,a.iSerno
   
	if(select object_id('tempdb..#temp_GoodsByClient_01')) is not null
	begin
		drop table #temp_GoodsByClient_01
	end 
	if(select object_id('tempdb..#temp_GoodsByClient_02')) is not null
	begin
		drop table #temp_GoodsByClient_02
	end 	  
end
GO
