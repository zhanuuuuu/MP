/*

select max(业务日期) from  Pos_WH_Form.dbo.t_WH_Form_log_1

select max(业务日期) from  Pos_WH_Form.dbo.t_WH_Form_log
declare @i int
 exec p_FIFOWhInWH_Form_Log_1 '2015-03-02',@i output
  select @i
  
*/
CREATE proc [dbo].[p_FIFOWhInWH_Form_Log_Day]
@SheetDate datetime,
@return int output
as
begin

begin try
begin tran

 /*将不管理库存商品保存到t_WH_Form_Log--*/
 if (select object_id('tempdb..#temp_cGoodsSaleDate0'))is not null
   begin
     drop table #temp_cGoodsSaleDate0
   end
select dSaleDate,cWHno,cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing 
into #temp_cGoodsSaleDate0 from t_SaleSheet_Day 
with(nolock)
where dSaleDate=@SheetDate and bStorage=0

 if (select object_id('tempdb..#temp_cGoodsSaleAll'))is not null
   begin
     drop table #temp_cGoodsSaleAll
   end
select cGoodsNo,fQuantity=CAST(null as money),fLastSettle=CAST(null as money),bAuditing=0
into #temp_cGoodsSaleAll from t_Goods
with(nolock)
where  bStorage=0
union all
select cGoodsNo,fQuantity=CAST(null as money),fLastSettle=CAST(null as money),bAuditing=1
from t_Goods
with(nolock)
where  bStorage=0

 

update a
set a.fLastSettle=b.fLastSettle,a.fQuantity=b.fQuantity,a.bAuditing=b.bAuditing
from #temp_cGoodsSaleAll a,#temp_cGoodsSaleDate0 b
where a.cGoodsNo=b.cGoodsNo and a.bAuditing=b.bAuditing

 
 
if (select object_id('tempdb..#temp_cGoodsSaleDate'))is not null
begin
 drop table #temp_cGoodsSaleDate
end
   
  select cGoodsNo,fQuantity,fLastSettle,bAuditing into #temp_cGoodsSaleDate from #temp_cGoodsSaleAll
  
 
  
---412084
---412089
---------转最小
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
select a.cGoodsNo,a.cGoodsNo_MinPackage,fQty_minPackage=isnull(a.fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods a,#temp_cGoodsSaleDate b
where a.cGoodsNo=b.cGoodsNO and a.cGoodsNo<>isnull(a.cGoodsNo_minPackage,a.cGoodsNo)

update a set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
from #temp_cGoodsSaleDate a,#tmpPackGoodsList b
where a.cGoodsNo=b.cGoodsNo

if (select object_id('tempdb..#temp_SumcGoodsSaleDate'))is not null
begin
 drop table #temp_SumcGoodsSaleDate
end
select  cGoodsNo,fQuantity=SUM(isnull(fQuantity,0)),fLastSettle=SUM(isnull(fLastSettle,0)),bAuditing 
into #temp_SumcGoodsSaleDate
from #temp_cGoodsSaleDate 
group by  cGoodsNo,bAuditing


			
			
if (select object_id('tempdb..#temp_WhFormcGoods'))is not null
begin
  drop table #temp_WhFormcGoods
end

create table #temp_WhFormcGoods(
aa int,cWHno varchar(32),cgoodsno varchar(32),销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,
当日特价销售数量 money,当日特价销售金额 money,当日正价销售数量 money,当日正价销售金额 money,合同扣率 money,
单品扣率 money,特价扣率 money,扣率金额 money,执行扣率 money)
  

insert into   #temp_WhFormcGoods(cGoodsNo)
select distinct  cGoodsNo from #temp_SumcGoodsSaleDate
  
-----
update a set a.销售数量0=ISNULL(a.销售数量0,0)+b.fQuantity,a.销售金额0=ISNULL(a.销售金额0,0)+b.fLastSettle,
a.特价销售数量=b.fQuantity,a.特价销售金额=b.fLastSettle,
a.当日特价销售数量=b.fQuantity,a.当日特价销售金额=b.fLastSettle
from #temp_WhFormcGoods a,#temp_SumcGoodsSaleDate b
where a.cGoodsNo=b.cGoodsNo and b.bAuditing=1

update a set a.销售数量0=ISNULL(a.销售数量0,0)+b.fQuantity,a.销售金额0=ISNULL(a.销售金额0,0)+b.fLastSettle,
a.正价销售数量=b.fQuantity,a.正价销售金额=b.fLastSettle,
a.当日正价销售数量=b.fQuantity,a.当日正价销售金额=b.fLastSettle
from #temp_WhFormcGoods a,#temp_SumcGoodsSaleDate b
where a.cGoodsNo=b.cGoodsNo and b.bAuditing=0

/*存临时表*/
if (select object_id('tempdb..#temp_DangqianSaleSheetDate'))is not null
begin
 drop table #temp_DangqianSaleSheetDate
end
  select 业务日期=@SheetDate,a.cGoodsNo,dDateTime=@SheetDate,
  cSheetNo='不管库存',iLineNo=0,iAttribute=20,cWhNo,
  b.cSupNo,b.cSupName,销售数量0, 销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,库存标志=0,
  a.当日特价销售数量,a.当日特价销售金额,a.当日正价销售数量,a.当日正价销售金额,a.合同扣率,单品扣率=b.fRatio,a.特价扣率,扣率金额,执行扣率
  into #temp_DangqianSaleSheetDate
  from #temp_WhFormcGoods a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo 
 
  
/*取上次的不管库存商品销售记录*/
 declare @PosWhName varchar(32)
 declare @chwno varchar(32)
 select @PosWhName=Pos_WH_Form,@chwno=cWhNo from t_WareHouse where bMainSale=1
 
if (select object_id('tempdb..#temp_ShangSaleSheetDate'))is not null
begin
drop table #temp_ShangSaleSheetDate
end
create table #temp_ShangSaleSheetDate(
   dDateTime datetime,cWHno varchar(32),cSheetNo varchar(32),cgoodsno varchar(32),iLineNo int,iAttribute int,
   cSupplierNo varchar(32),cSupplier varchar(32),
   销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,
  当日特价销售数量 money,当日特价销售金额 money,当日正价销售数量 money,当日正价销售金额 money,合同扣率 money,单品扣率 money,特价扣率 money,扣率金额 money,执行扣率 money
  )
  declare @ShangDate datetime
  set @ShangDate=@SheetDate-1
  
  insert into #temp_ShangSaleSheetDate(cGoodsno,dDateTime,cSheetNo,iLineNo,iAttribute,cWhNo,
  cSupplierNo,cSupplier ,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,当日特价销售数量,当日特价销售金额,
  当日正价销售数量,当日正价销售金额,合同扣率,单品扣率,特价扣率,扣率金额,执行扣率 )
exec('
select distinct  cGoodsno,dDateTime='''+@SheetDate+''',cSheetNo=''不管库存'',iLineNo=0,iAttribute=20, cWhNo,
   cSupplierNo, cSupplier , 销售数量0,  销售金额0, 
   特价销售数量,  特价销售金额,  正价销售数量,  正价销售金额,当日特价销售数量=0,当日特价销售金额=0,
  当日正价销售数量=0,当日正价销售金额=0,合同扣率=0,单品扣率=0,特价扣率=0,扣率金额=0
  ,执行扣率=0
  from  '+@PosWhName+'.dbo.t_WH_Form_log_0  
     with (nolock)
  where  dDateTime='''+@ShangDate+''' and  iAttribute=20
')

---- 防止供应商修改名字
update a set a.cSupplier=b.cSupName
from #temp_ShangSaleSheetDate a,t_Supplier b
where a.cSupplierNo=b.cSupNo

  ------2015-04-17 调整。--防止联营修改供应商  
	   if (select object_id('tempdb..#temp_TiaozhengSuper'))is not null
	   begin
		 drop table #temp_TiaozhengSuper
	   end	
	-----表示当天联营直接修改供应商	     
	  select a.cGoodsno,cSupplierNo=b.cSupNo 
	  into #temp_TiaozhengSuper
	  from #temp_ShangSaleSheetDate a,t_Goods b
	  where a.cgoodsno=b.cGoodsNo and a.cSupplierNo<>b.cSupNo
	---- 把前一天销售调整为0  
	  --update a
	  --set 销售数量0=0, 销售金额0=0,特价销售数量=0, 特价销售金额=0, 正价销售数量=0, 正价销售金额=0
	  --from #temp_ShangSaleSheetDate a,#temp_TiaozhengSuper b
	  --where a.cgoodsno=b.cgoodsno and a.cSupplierNo=b.cSupplierNo

	if (select object_id('tempdb..#temp_SuperOld'))is not null
	begin
	drop table #temp_SuperOld
	end
	select a.cGoodsno,cSupplierNo=b.cSupNo 
	into #temp_SuperOld
	from #temp_ShangSaleSheetDate a,t_Goods b
	where a.cgoodsno=b.cGoodsNo and a.cSupplierNo=b.cSupNo


if (select object_id('tempdb..#temp_DangqianSaleSheetDate_cGoods'))is not null
	begin
	 drop table #temp_DangqianSaleSheetDate_cGoods
	end		 
/*当前日期与上次的日期合并。。。*/
  select cGoodsno,dDateTime,cSheetNo,iLineNo,iAttribute,cWHno=@chwno,cSupNo,cSupName,iMyIdentity=0, 销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额  ,当日特价销售数量,当日特价销售金额,
  当日正价销售数量,当日正价销售金额,合同扣率,单品扣率,特价扣率,扣率金额,执行扣率 
  into #temp_DangqianSaleSheetDate_cGoods
  from #temp_DangqianSaleSheetDate 
  union all
  /*
  select cGoodsno,dDateTime,cSheetNo,iLineNo,iAttribute,cWHno,cSupplierNo,cSupplier,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,当日特价销售数量=convert(money,0),当日特价销售金额=convert(money,0),
  当日正价销售数量=convert(money,0),当日正价销售金额=convert(money,0),合同扣率=convert(money,0),单品扣率=convert(money,0),
  特价扣率=convert(money,0),扣率金额=convert(money,0),执行扣率=convert(money,0)
  from #temp_ShangSaleSheetDate
  */
    select a.cGoodsno,dDateTime,cSheetNo,iLineNo,iAttribute,cWHno,a.cSupplierNo,cSupplier,iMyIdentity=20,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,当日特价销售数量=convert(money,0),当日特价销售金额=convert(money,0),
  当日正价销售数量=convert(money,0),当日正价销售金额=convert(money,0),合同扣率=convert(money,0),单品扣率=convert(money,0),
  特价扣率=convert(money,0),扣率金额=convert(money,0),执行扣率=convert(money,0)
  from #temp_ShangSaleSheetDate a,#temp_TiaozhengSuper b
  where a.cgoodsno=b.cgoodsno and a.cSupplierNo<>b.cSupplierNo 
    union all 
    select a.cGoodsno,dDateTime,cSheetNo,iLineNo,iAttribute,cWHno ,a.cSupplierNo,cSupplier,iMyIdentity=0,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,当日特价销售数量=convert(money,0),当日特价销售金额=convert(money,0),
  当日正价销售数量=convert(money,0),当日正价销售金额=convert(money,0),合同扣率=convert(money,0),单品扣率=convert(money,0),
  特价扣率=convert(money,0),扣率金额=convert(money,0),执行扣率=convert(money,0)
  from #temp_ShangSaleSheetDate a,#temp_SuperOld b
   where a.cgoodsno=b.cgoodsno and a.cSupplierNo=b.cSupplierNo
  
  
   CREATE INDEX IX_tmp_DangqianSaleSheetDate_cGoods  ON #temp_DangqianSaleSheetDate_cGoods(cGoodsNo)
   

   if (select object_id('tempdb..#temp_SaleSheetDate_cGoodsheji'))is not null
   begin
	 drop table #temp_SaleSheetDate_cGoodsheji
   end		   
 select 业务日期=@SheetDate,cGoodsno,dDateTime=@SheetDate,cSheetNo,iLineNo,iAttribute,cWHno,iMyIdentity,cSupNo,cSupName, 
  销售数量0=sum(isnull(销售数量0,0)), 销售金额0=sum(isnull(销售金额0,0)), 
  特价销售数量=sum(isnull(特价销售数量,0)), 特价销售金额=sum(isnull(特价销售金额,0)), 正价销售数量=sum(isnull(正价销售数量,0)), 
  正价销售金额=sum(isnull(正价销售金额,0)) ,库存标志=0 
  ,当日特价销售数量=sum(isnull(当日特价销售数量,0)),当日特价销售金额=sum(isnull(当日特价销售金额,0)),
  当日正价销售数量=sum(isnull(当日正价销售数量,0)),当日正价销售金额=sum(isnull(当日正价销售金额,0)),
  合同扣率=convert(money,0),单品扣率=convert(money,0),特价扣率=convert(money,0),扣率金额=convert(money,0),执行扣率=convert(money,0)
  into #temp_SaleSheetDate_cGoodsheji
  from #temp_DangqianSaleSheetDate_cGoods
  group by cGoodsno,cSheetNo,iLineNo,iAttribute,cWHno,cSupNo,cSupName,iMyIdentity
  
 
  -----------获取合同扣率
  ----- 获取特价扣率	 
		if (select OBJECT_ID('tempdb..#tmpcGoodsHetongRatio'))is not null  drop table #tmpcGoodsHetongRatio
		select b.cGoodsNo,a.guizuno,fRatio=max(a.fRatio) into #tmpcGoodsHetongRatio from t_Supplier_Contract_Ratio a,#temp_SaleSheetDate_cGoodsheji b
        where a.guizuno=b.cSupNo     
        group by  b.cGoodsNo,a.guizuno
        
        update a
	    set a.合同扣率=b.fRatio,
	    a.扣率金额=Convert(money,(convert(money,b.fRatio)/100)*(isnull(当日特价销售金额,0)+isnull(当日正价销售金额,0))),
	    执行扣率=b.fRatio
	    from #temp_SaleSheetDate_cGoodsheji a,#tmpcGoodsHetongRatio b
	    where a.cGoodsNo=b.cGoodsNo 
	    	
	
        update a
	    set a.单品扣率=b.fRatio
	    from #temp_SaleSheetDate_cGoodsheji a,t_Goods b
	    where a.cGoodsNo=b.cGoodsNo 
	 
	               
        update #temp_SaleSheetDate_cGoodsheji
         set 扣率金额=Convert(money,(convert(money,单品扣率)/100)*(isnull(当日特价销售金额,0)+isnull(当日正价销售金额,0))),
        执行扣率=单品扣率
	    where ISNULL(单品扣率,0)<>0    	    
	       
        ----- 获取特价扣率
	    if (select OBJECT_ID('tempdb..#tmpcGoodsPloyOfSale'))is not null  drop table #tmpcGoodsPloyOfSale
	    select fSupRatio,cPloyNo,a.cGoodsNo,dDateStart,dDateEnd 
	    into #tmpcGoodsPloyOfSale
	    from dbo.t_PloyOfSale a,#temp_SaleSheetDate_cGoodsheji b
        where a.cGoodsNo=b.cGoodsNo and  @SheetDate between dDateStart and dDateEnd 	    
	    update a
	    set a.特价扣率=b.fSupRatio
	    from #temp_SaleSheetDate_cGoodsheji a,#tmpcGoodsPloyOfSale b
	    where a.cGoodsNo=b.cGoodsNo     
	      
	    
        update #temp_SaleSheetDate_cGoodsheji 
        set 扣率金额=Convert(money,(convert(money,特价扣率)/100)*(isnull(当日特价销售金额,0)+isnull(当日正价销售金额,0))),
        执行扣率=特价扣率
	    where ISNULL(特价扣率,0)<>0
	    
 
 /*不管理库存商品数据保存到静态数据表中。。。*/
--delete from Pos_WH_Form.dbo.t_WH_Form_Log
-- where 业务日期='2013-10-29 00:00:00.000' and iAttribute='20'

--select 业务日期, cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cWhNo,iMyIdentity,
--  cSupNo,cSupName,销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,库存标志,当日特价销售数量,当日特价销售金额,
--  当日正价销售数量,当日正价销售金额,合同扣率,
--		单品扣率,特价扣率 from #temp_SaleSheetDate_cGoodsheji


 exec('
 delete '+@PosWhName+'.dbo.t_WH_Form_log_0 where 业务日期='''+@SheetDate+''' and  iAttribute=20
  
  insert into '+@PosWhName+'.dbo.t_WH_Form_log_0
(业务日期, cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cWhNo,iMyIdentity,
  cSupplierNo,cSupplier,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,库存标志,
  当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,单品扣率,特价扣率,扣率金额,执行扣率
)
select 业务日期, cGoodsNo,dDateTime,cSheetNo,iLineNo,iAttribute,cWhNo,iMyIdentity,cSupNo,cSupName,销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,库存标志,当日特价销售数量,当日特价销售金额,
  当日正价销售数量,当日正价销售金额,合同扣率,单品扣率,特价扣率,扣率金额,执行扣率 from #temp_SaleSheetDate_cGoodsheji
		
')

--select 业务日期,0,cGoodsNo,dDateTime,
--cSheetNo,iLineNo,iAttribute,cWhNo,
--  cSupNo,cSupName,销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额,库存标志 
--  from #temp_DangqianSaleSheetDate_cGoods

/*----------------------------------2014-08-19以上为获取不管理库存商品的销售------------------------------------*/  
  
--delete Pos_WH_Form.dbo.t_WH_Form_Log where 业务日期='2013-10-29'

/*动静分开。。。获取相对静态数据*/

------------------------------------------下面是生成快照插入数据----------------------------------------------------------------------------
/*
    ---------------- 判断静态数据是否存在    
 */
 
	if (select object_id('t_Log_Error'))is  null
	begin
	   CREATE TABLE [dbo].t_Log_Error(
			dDateTime [datetime] NULL,
			cGoodsNo [varchar](64) NULL,
			iSerno  bigint NULL, 
			cSheetNo [varchar](64) NULL,
			iMyIdentity bigint)
	end
	exec('
	if (select object_id(''tempdb..#temp_PosWhForm_Log_cGoods_0''))is not null
	begin
	  drop table #temp_PosWhForm_Log_cGoods_0
	end
	 -- 获取出错误记录
	 select  b.cGoodsNo,b.cSheetNo,a.dDateTime,b.iMyIdentity, b.iSerno
	 into #temp_PosWhForm_Log_cGoods_0
	 from Pos_WH_Form.dbo.t_WH_Form_log_0 a,dbo.t_WH_Form_log b
	 where a.业务日期='''+@ShangDate+''' 
	 and a.iMyIdentity=b.iMyIdentity and a.iSerno=b.iSerno and a.cGoodsNo=b.cGoodsNo and a.iAttribute<>20 
	 
	 --插入错误记录
	 insert into t_Log_Error(cGoodsNo,cSheetNo,dDateTime,iMyIdentity,iSerno)
	 select cGoodsNo,cSheetNo,dDateTime,iMyIdentity,iSerno
	 from #temp_PosWhForm_Log_cGoods_0
	 
	 --- 移除错误记录
	 delete a
	 from t_WH_Form_log a,#temp_PosWhForm_Log_cGoods_0 b
	 where a.dDateTime=b.dDateTime and a.cGoodsNo=b.cGoodsNo and a.cSheetNo=b.cSheetNo and a.iSerno=b.iSerno and a.iMyIdentity=b.iMyIdentity
	 
	 ')
 
	if (select object_id('tempdb..#temp_JingWhFormcGoods_0'))is not null
	begin
	 drop table #temp_JingWhFormcGoods_0
	end

	if (select object_id('tempdb..#temp_PicWhFormcGoods_WH_Form_Log'))is not null
	begin
	 drop table #temp_PicWhFormcGoods_WH_Form_Log
	end
 select 业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
  iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
  fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
  cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
  dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
  cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
  入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
  调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
  报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
  差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
  盘点单价, 库存标志 ,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
		单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
  into #temp_PicWhFormcGoods_WH_Form_Log
  from T_WH_Form_Log    with(nolock)
  ---where 业务日期=@SheetDate
  
   CREATE INDEX IX_tmp_PicWhFormcGoods_WH_Form_Log  ON #temp_PicWhFormcGoods_WH_Form_Log(cGoodsNo)
 
 ---- 取当前批次中库存为0的商品。。。。
select dDateTime,cGoodsNo,iMyIdentity,iSerno,iLineNo,iAttribute,cSummary,fPrice_In,fQty_In,fMoney_In,
fPrice_Out,fQty_Out,fMoney_Out,fQty_Left,fPrice_Left,fMoney_Left,cSupplierNo,cSupplier,当日特价销售数量,当日正价销售数量
into #temp_JingWhFormcGoods_0
from #temp_PicWhFormcGoods_WH_Form_Log
where fQty_In=fQty_Out and fQty_Left=0 
-- and iAttribute<>10

 CREATE INDEX IX_tmp_JingWhFormcGoods_0  ON #temp_JingWhFormcGoods_0(cGoodsNo)
 
/*防止有静态手动改成动态时。即把原来的不是最大批次号改成最大批次号。。*/
---------------------- 2015-03-16-------------------------------
/*
if (select object_id('tempdb..#temp_MaxiSerno'))is not null
begin
 drop table #temp_MaxiSerno
end
select cgoodsno,cSupplierNo,iSerno=MAX(iSerno)
into #temp_MaxiSerno
from #temp_PicWhFormcGoods_WH_Form_Log 
where iAttribute<>10 and iAttribute<>13
group by cgoodsno,cSupplierNo

---------- 在判断批次中为0商品批次号不是最大批次
if (select object_id('tempdb..#temp_NoMaxPicWhFormcGoods_0'))is not null
begin
 drop table #temp_NoMaxPicWhFormcGoods_0
end
 select distinct a.dDateTime,b.cGoodsNo,b.cSupplierNo ,a.iSerno,a.iMyIdentity
into #temp_NoMaxPicWhFormcGoods_0
from #temp_JingWhFormcGoods_0 a,#temp_MaxiSerno b
 where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
 and a.iSerno<b.iSerno 
 */

if (select object_id('tempdb..#temp_MaxiSerno'))is not null
begin
 drop table #temp_MaxiSerno
end
select cgoodsno,iSerno=MAX(iSerno)
into #temp_MaxiSerno
from #temp_PicWhFormcGoods_WH_Form_Log 
--where iAttribute<>10 and iAttribute<>13
where  iAttribute<>13
group by cgoodsno

---------- 在判断批次中为0商品批次号不是最大批次
if (select object_id('tempdb..#temp_NoMaxPicWhFormcGoods_0'))is not null
begin
 drop table #temp_NoMaxPicWhFormcGoods_0
end
 select distinct a.dDateTime,b.cGoodsNo,a.iSerno,a.cSupplierNo,a.iMyIdentity
into #temp_NoMaxPicWhFormcGoods_0
from #temp_JingWhFormcGoods_0 a,#temp_MaxiSerno b
 where a.cGoodsNo=b.cGoodsNo and a.iSerno<b.iSerno 
 ---------------------- 2015-03-16-------------------------------
 
 exec(' 
  insert into '+@PosWhName+'.dbo.t_WH_Form_Log_0(
  业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
  iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
  fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
  cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
  dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
  cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
  入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
  调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
  报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
  差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
  盘点单价, 库存标志,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
		单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
  )
  select '''+@SheetDate+''', a.cGoodsNo, a.dDateTime, a.cWhNo, a.cSheetNo, a.iMyIdentity, a.iSerno, a.iLineNo, 
  a.iAttribute, a.cSummary, a.fPrice_Tran, a.fPrice_In, a.fQty_In, a.fMoney_In, a.fPrice_Out, a.fQty_Out, 
  a.fMoney_Out, a.fQty_Left, a.fPrice_Left, a.fMoney_Left, a.bJiecun, a.dJiecunDate, a.cSupplierNo, 
  a.cSupplier, a.cReason, a.bSupplierPay, a.fMoneyACC_SpplierPay, a.cJiesuanno_Last, a.iSerno_Cost_Distribute, 
  a.dDate_sheet_Cost_Distribute, a.cGoodsNo_Parent, a.fQty_minPackage, a.fQty_In_Parent, a.bChangePrice, 
  a.cChangePriceBillNo, a.fQty_Diff, a.fPrice_In_OnSheet, a.fMoney_In_OnSheet, 
  a.入库数量1, a.入库金额1, a.报溢数量1, a.报溢金额1, a.退货入库数量1, a.退货入库金额1, 
  a.调拨入库数量1, a.调拨入库金额1, a.Pos客退数量1, a.Pos客退金额1, a.出库数量0, a.出库金额0, 
  a.报损数量0, a.报损金额0, a.返厂数量0, a.返厂金额0, a.调拨出库数量0, a.调拨出库金额0, a.差价数量, 
  a.差价金额, a.原料出库数量0, a.原料出库金额0, a.成品入库数量1, a.成品入库金额1, a.销售数量0, a.销售金额0, 
  a.特价销售数量, a.特价销售金额, a.正价销售数量, a.正价销售金额, a.本日库存数量, a.盘点数量, 
  a.盘点单价, a.库存标志 ,a.当日特价销售数量,a.当日特价销售金额,a.当日正价销售数量,a.当日正价销售金额,a.合同扣率,
		a.单品扣率,a.特价扣率,a.执行扣率,a.扣率金额,a.扣率类别,a.累计差价数量,a.累计差价金额,a.差价后成本单价,a.人工指定成本单价
  from #temp_PicWhFormcGoods_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
  where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
  and a.iSerno=b.iSerno  
  ')
  ----- 删除临时表中的静态数据
 delete a
 from #temp_PicWhFormcGoods_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
 where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
 and a.iSerno=b.iSerno
 
if (select object_id('T_WH_Form_Log_Back'))is not null
begin
	insert into PosManagement.dbo.T_WH_Form_Log_Back(
	业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, iAttribute, cSummary, 
	fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, 
	fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, 
	cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, 
	fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
	入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, 
	Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 
	调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 
	销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 
	库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 
	特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价
	)
	select @SheetDate, a.cGoodsNo, a.dDateTime, cWhNo, cSheetNo, a.iMyIdentity, a.iSerno, iLineNo, iAttribute, cSummary, 
	fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, fMoney_Out, fQty_Left, fPrice_Left, 
	fMoney_Left, bJiecun, dJiecunDate, a.cSupplierNo, cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, 
	cJiesuanno_Last, iSerno_Cost_Distribute, dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, 
	fQty_In_Parent, bChangePrice, cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
	入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 调拨入库数量1, 调拨入库金额1, 
	Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 
	调拨出库金额0, 差价数量, 差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 
	销售金额0, 特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 盘点单价, 
	库存标志, 当日特价销售数量, 当日特价销售金额, 当日正价销售数量, 当日正价销售金额, 合同扣率, 单品扣率, 
	特价扣率, 执行扣率, 扣率金额, 扣率类别, 累计差价数量, 累计差价金额, 差价后成本单价, 人工指定成本单价
	from T_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
	where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
	and a.iSerno=b.iSerno and  a.iAttribute=0
  
end

 delete a
 from T_WH_Form_Log a,#temp_NoMaxPicWhFormcGoods_0 b
 where  a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and a.iMyIdentity=b.iMyIdentity
 and a.iSerno=b.iSerno
 
 
 
  /*移除动态表中有的数据*/
  exec('
   delete '+@PosWhName+'.dbo.t_WH_Form_Log_1 where 业务日期='''+@SheetDate+'''
  
  insert into '+@PosWhName+'.dbo.t_WH_Form_Log_1(
  业务日期, cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
  iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
  fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
  cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
  dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
  cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
  入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
  调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
  报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
  差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
  盘点单价, 库存标志,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
		单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
  )
  select '''+@SheetDate+''', cGoodsNo, dDateTime, cWhNo, cSheetNo, iMyIdentity, iSerno, iLineNo, 
  iAttribute, cSummary, fPrice_Tran, fPrice_In, fQty_In, fMoney_In, fPrice_Out, fQty_Out, 
  fMoney_Out, fQty_Left, fPrice_Left, fMoney_Left, bJiecun, dJiecunDate, cSupplierNo, 
  cSupplier, cReason, bSupplierPay, fMoneyACC_SpplierPay, cJiesuanno_Last, iSerno_Cost_Distribute, 
  dDate_sheet_Cost_Distribute, cGoodsNo_Parent, fQty_minPackage, fQty_In_Parent, bChangePrice, 
  cChangePriceBillNo, fQty_Diff, fPrice_In_OnSheet, fMoney_In_OnSheet, 
  入库数量1, 入库金额1, 报溢数量1, 报溢金额1, 退货入库数量1, 退货入库金额1, 
  调拨入库数量1, 调拨入库金额1, Pos客退数量1, Pos客退金额1, 出库数量0, 出库金额0, 
  报损数量0, 报损金额0, 返厂数量0, 返厂金额0, 调拨出库数量0, 调拨出库金额0, 差价数量, 
  差价金额, 原料出库数量0, 原料出库金额0, 成品入库数量1, 成品入库金额1, 销售数量0, 销售金额0, 
  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额, 本日库存数量, 盘点数量, 
  盘点单价, 库存标志 ,当日特价销售数量,当日特价销售金额,当日正价销售数量,当日正价销售金额,合同扣率,
		单品扣率,特价扣率,执行扣率,扣率金额,扣率类别,累计差价数量,累计差价金额,差价后成本单价,人工指定成本单价
  from #temp_PicWhFormcGoods_WH_Form_Log
  ')
  
 /*操作成本分配表*/

 insert into Pos_Cost_distribute.dbo.t_Cost_distribute_Log_temp
 (
  操作日期, dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, 
  fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
  fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, 
  bJiesuan, cJiesuanNo
 )
 select @SheetDate,dDate_Sheet, cGoodsNo, iSerno, iMyIdentity, fPrice_Tran, 
  fPrice_Cost, fQty_Cost, fMoney_Cost, iAttribute, cSheetNo, iLineNo, 
  fQty, dDate_Account, bDone, cWhNo, id, fPrice_sale, fMoney_sale, 
  bJiesuan, cJiesuanNo
  from Pos_Cost_distribute.dbo.t_Cost_distribute_Log
  with(nolock)
  where isnull(bDone,0)=0 and fQty>fQty_Cost  
   ------------- 删除
   delete    Pos_Cost_distribute.dbo.t_Cost_distribute_Log
   where isnull(bDone,0)=0 and fQty>fQty_Cost  
 
 update T_WH_Form_Log set  当日正价销售数量=0,当日正价销售金额=0,当日特价销售数量=0, 当日特价销售金额=0,扣率金额=0,扣率类别=null 
 
commit tran
 --print 1
 set @return=1
end try
begin catch
 rollback 
 --print 0
  set @return=0
end catch

end
GO
