
/*
  [p_StoreGOodsUpdate_wei_test] 'UP201703-000020','00'
*/
CREATE proc [dbo].[p_StoreGOodsUpdate_wei]
@cSheetNo varchar(32),
@cStoreNo varchar(32)
as
begin 

	    if (select OBJECT_ID('tempdb..#tmp_Store'))is not null drop table #tmp_Store
		create table #tmp_Store(cStoreNo varchar(32))
	 
		if (select OBJECT_ID('tempdb..#tmp_StoreGoods'))is not null drop table #tmp_StoreGoods
		select cGoodsNo,fNormalPrice,fDbPrice,fPfPrice,fPsprice 
		into #tmp_StoreGoods
		from t_StoreGoodsUpdateDetail
		where cSheetNo=@cSheetNo
		

		---所有都改
		if @cStoreNo='--' 
		begin  
		     update a
		     set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
		     a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		     a.fVipScore_base=b.fNormalPrice,
		     a.fVipScore=round(b.fNormalPrice*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2),
		     a.fVipPrice=b.fNormalPrice,
		     a.fVipPrice_Student=b.fNormalPrice
		     from t_Goods a,#tmp_StoreGoods b,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
		     
		     update a
		     set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
		     a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		     a.fVipScore_base=b.fNormalPrice,
		     a.fVipScore=round(b.fNormalPrice*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2)
		     ,a.fVipPrice=b.fNormalPrice,
		     a.fVipPrice_Student=b.fNormalPrice
		     from t_cStoreGoods a,#tmp_StoreGoods b,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
		     
		     ----获取称重商品的采购管理码
		     if (select OBJECT_ID('tempdb..#tmp_cGoodsMin'))is not null drop table #tmp_cGoodsMin
		     select cGoodsNo=a.cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
		     b.fNormalPrice,b.fDbPrice,b.fPfPrice,b.fPsprice
		     into #tmp_cGoodsMin 
		     from t_Goods a,#tmp_StoreGoods b
		     where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
		     and ISNULL(a.bWeight,0)=1
		     
		     update a
		     set a.fNormalPrice=b.fNormalPrice/b.fQty_minPackage,a.fDbPrice=b.fDbPrice/b.fQty_minPackage,
		     a.fPfPrice=b.fPfPrice/b.fQty_minPackage,a.fPsprice=b.fPsprice/b.fQty_minPackage,
		     a.fVipScore_base=b.fNormalPrice/b.fQty_minPackage,
		     a.fVipScore=round((b.fNormalPrice/b.fQty_minPackage)*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2)
		     ,a.fVipPrice=b.fNormalPrice/b.fQty_minPackage,
		     a.fVipPrice_Student=b.fNormalPrice/b.fQty_minPackage
		     from t_Goods a,#tmp_cGoodsMin b,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
		     
		     update a
		     set a.fNormalPrice=b.fNormalPrice/b.fQty_minPackage,a.fDbPrice=b.fDbPrice/b.fQty_minPackage,
		     a.fPfPrice=b.fPfPrice/b.fQty_minPackage,a.fPsprice=b.fPsprice/b.fQty_minPackage,
		     a.fVipScore_base=b.fNormalPrice/b.fQty_minPackage,
		     a.fVipScore=round((b.fNormalPrice/b.fQty_minPackage)*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2)
		     ,a.fVipPrice=b.fNormalPrice/b.fQty_minPackage,
		     a.fVipPrice_Student=b.fNormalPrice/b.fQty_minPackage
		     from t_cStoreGoods a,#tmp_cGoodsMin b,t_GoodsType c
		     where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
	 
		     
		     delete a
			 from t_ChangeGoods a, #tmp_StoreGoods b
		     where a.cGoodsNo=b.cGoodsNo 
			 
			 insert into t_ChangeGoods(cStoreNo,cGoodsNo)
			 select a.cStoreNo,b.cGoodsNo					 
			 from t_cStoreGoods a,#tmp_StoreGoods b
		     where a.cGoodsNo=b.cGoodsNo
		     
             update t_StoreGoodsUpdate
			 set bExamin=1		     
			 where cSheetNo=@cSheetNo  
		     
		end else
		begin
		           declare @cStoreNo01 varchar(32)
		           set @cStoreNo01=(select top 1 cParentNo from t_Store where cStoreNo=@cStoreNo)
		           
		           if ISNULL(@cStoreNo01,'')='--'
		           begin
		               
		                 update a
						 set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
						 a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		                 a.fVipScore_base=b.fNormalPrice,
		                 a.fVipScore=round((b.fNormalPrice)*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2)
		                 ,a.fVipPrice=b.fNormalPrice,
		                 a.fVipPrice_Student=b.fNormalPrice
						 from t_Goods a,#tmp_StoreGoods b,t_GoodsType c
		                 where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
					     
						 update a
						 set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
						 a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		                 a.fVipScore_base=b.fNormalPrice,
		                 a.fVipScore=round((b.fNormalPrice)*c.fValue_Score/case when isnull(c.fValue_con,0)<>0 then isnull(c.fValue_con,0) else  1 end,2)
		                 ,a.fVipPrice=b.fNormalPrice,
		                 a.fVipPrice_Student=b.fNormalPrice
						 from t_cStoreGoods a,#tmp_StoreGoods b,t_GoodsType c
		                 where a.cGoodsNo=b.cGoodsNo and a.cGoodsTypeno=c.cGoodsTypeno
		                 and a.cStoreNo=@cStoreNo
					     
						 update t_StoreGoodsUpdate
						 set bExamin=1		     
						 where cSheetNo=@cSheetNo   			 
		           end else
		           begin 
		      
							if (select OBJECT_ID('tempdb..#tmp_StoreAll'))is not null drop table #tmp_StoreAll		     
							select cStoreNo=cRegNo,cStoreName=cRegName,cParentNo 
							into #tmp_StoreAll
							from t_Store_Regionalism 
							union all
							select cStoreNo,cStoreName,cRegNo from t_Store 
							union all
							select '--','总公司',cParentNo='ALL'
							order by cRegNo
							
					 
							if exists(select cStoreNo from #tmp_StoreAll where cParentNo=@cStoreNo)
							begin						 
								insert into #tmp_Store(cStoreNo)			 
								select cStoreNo from #tmp_StoreAll where cParentNo=@cStoreNo 
							end else
							begin
								insert into #tmp_Store(cStoreNo) values(@cStoreNo)	
							 
							end 
							
							 
							
							 update a
							 set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
							 a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		                     a.fVipScore_base=b.fNormalPrice,
		                     a.fVipScore=round((b.fNormalPrice)*d.fValue_Score/case when isnull(d.fValue_con,0)<>0 then isnull(d.fValue_con,0) else  1 end,2)		      
							 ,a.fVipPrice=b.fNormalPrice,
		                     a.fVipPrice_Student=b.fNormalPrice
							 from t_cStoreGoods a,#tmp_StoreGoods b,#tmp_Store c,t_GoodsType d
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 and  a.cGoodsTypeno=d.cGoodsTypeno
				             
				             -----处理总部基本信息
				           if exists(select * from #tmp_Store a,t_Store b
										 where a.cStoreNo=b.cStoreNo
										 and b.cParentNo='--')
							begin						 
								 update a
								 set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
								 a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
								 a.fVipScore_base=b.fNormalPrice,
								 a.fVipScore=round((b.fNormalPrice)*d.fValue_Score/case when isnull(d.fValue_con,0)<>0 then isnull(d.fValue_con,0) else  1 end,2)		      
								 ,a.fVipPrice=b.fNormalPrice,
		                         a.fVipPrice_Student=b.fNormalPrice
								 from t_Goods a,#tmp_StoreGoods b,t_GoodsType d
								 where a.cGoodsNo=b.cGoodsNo   and  a.cGoodsTypeno=d.cGoodsTypeno
							end 
				             
				             
				             
				             update a
							 set a.fNormalPrice=b.fNormalPrice,a.fDbPrice=b.fDbPrice,
							 a.fPfPrice=b.fPfPrice,a.fPsprice=b.fPsprice,
		                     a.fVipScore_base=b.fNormalPrice,
		                     a.fVipScore=round((b.fNormalPrice)*d.fValue_Score/case when isnull(d.fValue_con,0)<>0 then isnull(d.fValue_con,0) else  1 end,2)		      
							 ,a.fVipPrice=b.fNormalPrice,
		                     a.fVipPrice_Student=b.fNormalPrice
							 from t_cStoreGoods a,#tmp_StoreGoods b,#tmp_Store c,t_GoodsType d
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 and  a.cGoodsTypeno=d.cGoodsTypeno
							 
							 ----获取称重商品的采购管理码
							 if (select OBJECT_ID('tempdb..#tmp_cGoodsMin0'))is not null drop table #tmp_cGoodsMin0
							 select cGoodsNo=cGoodsNo_minPackage,fQty_minPackage=ISNULL(fQty_minPackage,1),
							 b.fNormalPrice,b.fDbPrice,b.fPfPrice,b.fPsprice
							 into #tmp_cGoodsMin0 
							 from t_Goods a,#tmp_StoreGoods b
							 where a.cGoodsNo=b.cGoodsNo and isnull(a.cGoodsNo_minPackage,'')<>''
							 and ISNULL(a.bWeight,0)=1
							 
		      
							 update a
							 set a.fNormalPrice=b.fNormalPrice/b.fQty_minPackage,a.fDbPrice=b.fDbPrice/b.fQty_minPackage,
							 a.fPfPrice=b.fPfPrice/b.fQty_minPackage,a.fPsprice=b.fPsprice/b.fQty_minPackage,
		                     a.fVipScore_base=b.fNormalPrice/b.fQty_minPackage,
		                     a.fVipScore=round((b.fNormalPrice/b.fQty_minPackage)*d.fValue_Score/case when isnull(d.fValue_con,0)<>0 then isnull(d.fValue_con,0) else  1 end,2)
							 ,a.fVipPrice=b.fNormalPrice/b.fQty_minPackage,
		                         a.fVipPrice_Student=b.fNormalPrice/b.fQty_minPackage
							 from t_cStoreGoods a,#tmp_cGoodsMin0 b,#tmp_Store c,t_GoodsType d
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 and  a.cGoodsTypeno=d.cGoodsTypeno
							 
		 
							 delete a
							 from t_ChangeGoods a,#tmp_StoreGoods b,#tmp_Store c
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 
							 insert into t_ChangeGoods(cStoreNo,cGoodsNo)
							 select a.cStoreNo,b.cGoodsNo					 
							 from t_cStoreGoods a,#tmp_StoreGoods b,#tmp_Store c
							 where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=c.cStoreNo
							 
							 update t_StoreGoodsUpdate
							 set bExamin=1		     
							 where cSheetNo=@cSheetNo  
					 end 
		end
		
end
GO
