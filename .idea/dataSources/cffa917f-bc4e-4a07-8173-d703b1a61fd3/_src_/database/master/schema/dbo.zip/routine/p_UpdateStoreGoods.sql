 


create proc p_UpdateStoreGoods
@cStoreNo varchar(32),
@cStoreIp varchar(32)
as
begin
    update a set a.cGoodsName=b.cGoodsName,a.cGoodsTypeno=b.cGoodsTypeno,a.cGoodsTypename=b.cGoodsTypename,
	a.cBarcode=b.cBarcode,a.cUnit=b.cUnit, a.cSpec=b.cSpec,
	a.cProductUnit=b.cProductUnit,a.cHelpCode=b.cHelpCode,
	a.cHezuoFangshi=b.cHezuoFangshi,
	a.fPreservationUp=b.fPreservationUp,a.fPreservationDown=b.fPreservationDown,
	a.cLevel=b.cLevel,a.bSuspend=b.bSuspend,a.bDeling=b.bDeling, a.bDeled=b.bDeled,
	a.dSuspendDate1=b.dSuspendDate1,a.dSuspendDate2=b.dSuspendDate2,a.dDelingDate2=b.dDelingDate2,
	a.bProducted=b.bProducted,a.cProductNo=b.cProductNo,a.bStock=b.bStock,
	a.bWeight=b.bWeight,
	a.bCared=b.bCared,a.cSupNo=b.cSupNo,a.cSupName=b.cSupName,
	a.bStorage=b.bStorage,a.bBaozhuang=b.bBaozhuang,a.cParentNo=b.cParentNo,
	a.bNoVipPrice=b.bNoVipPrice,   
	a.cZoneNo=b.cZoneNo,a.cZoneName=b.cZoneName, 
	a.pinpaino=b.pinpaino,a.pinpai=b.pinpai,a.bHidePrice=b.bHidePrice,a.bHideQty=b.bHideQty,
	a.iGoodsStatus=b.iGoodsStatus,a.cSeasonNo=b.cSeasonNo,a.cPersonNo=b.cPersonNo,
	a.bStocking=b.bStocking, 
	a.cGoodsNo_minPackage=b.cGoodsNo_minPackage,a.fQty_minPackage=b.fQty_minPackage,
	a.bfresh=b.bfresh
	from  dbo.t_cStoreGoods a, t_Goods b
	where a.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
	
end
GO
