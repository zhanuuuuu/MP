


CREATE  procedure [dbo].[p_x_SalesProfitABC_byGoodsType_wind]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit
as
begin 
/*一下形成类别列表*/
			if(select object_id('tempdb..#tempLevel')) is not null
			begin
				drop table 	#tempLevel
			end 
			create table #tempLevel (cGoodsTypeNo varchar(32),cPath varchar(1024),iLevel int )

			if(select object_id('tempdb..#tempLeaf')) is not null
			begin
				drop table 	#tempLeaf
			end 

			select a.cGoodsTypeNo,a.cParentNo
			into #tempLeaf
			from dbo.t_GoodsType a left join t_GoodsType b
			on   a.cGoodsTypeNo =b.cParentNo 
			where b.cGoodsTypeNo is  null
			order by a.cParentNo,a.cGoodsTypeNo

			declare @cGoodsTypeNo varchar(32)
			declare @cParentNo varchar(32)
			declare @cPath varchar(1024)
			declare @iPathlevel int


			declare @cGoodsTypeNo_var varchar(32)

			declare crGoodsTypeNo cursor for
			select cGoodsTypeNo,cParentNo from #tempLeaf
			order by cParentNo,cGoodsTypeNo
		  
			open crGoodsTypeNo

			fetch next from crGoodsTypeNo
			into @cGoodsTypeNo,@cParentNo
			
			set @cGoodsTypeNo_var=@cGoodsTypeNo
			set @cPath=''
			set @iPathlevel=1
			while @@Fetch_Status=0
			begin
				while isnull((select top 1 cParentNo from t_GoodsType 
											where cGoodsTypeNo=@cGoodsTypeNo_var 
														and @cGoodsTypeNo_var is not null
											)
											,''
										)<>'--'
				begin
					set @iPathlevel=@iPathlevel+1
					set @cPath= '.'+@cGoodsTypeNo_var+@cPath
					set @cGoodsTypeNo_var=
									isnull((select top 1 cParentNo from t_GoodsType 
													where cGoodsTypeNo=@cGoodsTypeNo_var 
																and @cGoodsTypeNo_var is not null
													),'')
				end				
				set @cPath='--.'+@cGoodsTypeNo_var+@cPath
				--print @cGoodsTypeNo

				insert into #tempLevel (cGoodsTypeNo,cPath,iLevel)
				values (@cGoodsTypeNo,@cPath,@iPathlevel)

				fetch next from crGoodsTypeNo
				into @cGoodsTypeNo,@cParentNo
				set @cGoodsTypeNo_var=@cGoodsTypeNo
				set @cPath=''
				set @iPathlevel=1
			end
		  
		CLOSE crGoodsTypeNo
		DEALLOCATE crGoodsTypeNo

			if(select object_id('tempdb..#tempPath')) is not null
			begin
				drop table 	#tempPath
			end 
			create table #tempPath (cGoodsTypeNo varchar(32),cPath varchar(1024),cPath_leaf  varchar(1024),iLevel int )

			insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
			select cGoodsTypeNo,cPath,cPath,iLevel 
			from #tempLevel
		/*	
			declare @cGoodsTypeNo varchar(32)
			declare @cPath varchar(1024)
		*/
			declare @cPath_p varchar(1024)
			declare @cPath_leaf varchar(1024)
			declare @cMyTypeNo varchar(32)
			declare @iLevel int
			declare @i int
			declare @iLength int
			declare @cPath_var int

			declare cur_Path cursor for
			select cGoodsTypeNo,cPath,iLevel 
			from #tempLevel
			order by cGoodsTypeNo

			open cur_Path

			fetch next from cur_Path
			into @cGoodsTypeNo,@cPath_leaf,@iLevel
			while @@Fetch_Status=0
			begin
				set @i=1
				set @cPath=substring(@cPath_leaf,4,datalength(@cPath_leaf)-3)
				set @cPath_p='.'+@cPath+'.'
				while @i<@iLevel
				begin
					set @iLength=patindex('%.%',@cPath)
					--print @cPath
					--print @iLength
					set @cMyTypeNo=substring(@cPath,1,@iLength-1)
					delete from #tempPath
					where cGoodsTypeNo=@cMyTypeNo and cPath_leaf=@cPath_leaf

					insert into #tempPath(cGoodsTypeNo,cPath,cPath_leaf,iLevel)
					values(@cMyTypeNo,
		--			 substring(substring(@cPath_p,1,patindex('%.'+@cMyTypeNo+'.%',@cPath_p)+datalength(@cMyTypeNo)),2,1024),
					substring( 
					substring('.'+@cPath_leaf+'.',1,patindex('%.'+@cMyTypeNo+'.%','.'+@cPath_leaf+'.')+datalength(@cMyTypeNo)),
					2,1024
					),
					 @cPath_leaf,@i
					)
					
					set @cPath=substring(@cPath,@iLength+1,1024)
		--			set @cPath_var=substring(@cPath_var,@iLength+1,datalength(@cPath_var)-@iLength)
					set @cPath_p='.'+@cPath+'.'

					set @i=@i+1
				end
				fetch next from cur_Path
				into @cGoodsTypeNo,@cPath_leaf,@iLevel
			end

		CLOSE cur_Path
		DEALLOCATE cur_Path

  	select a.cGoodsTypeNo,b.cGoodsTypename,a.cPath,a.cPath_leaf,a.iLevel
		into #tempGoodsTypePath
	  from #tempPath a,t_GoodsType b
		where a.cGoodsTypeno=b.cGoodsTypeNo
/*以上形成类别列表*/


	 	declare @dLastDaily datetime
    select @dLastDaily=max(dDate) from dbo.t_Daily_history
		if @dLastDaily is null 
		begin
			set @dLastDaily='2000-01-01'
		end
		--set @dLastDaily='2000-01-01'
	
		if(select object_id('tempdb..#temp_Goods_supplier')) is not null
		begin
			drop table 	#temp_Goods_supplier
		end 

		if(select object_id('tempdb..#tempSaleSheet_Day_unique')) is not null
		begin
			drop table 	#tempSaleSheet_Day_unique
		end 

		if(select object_id('tempdb..#tempLastWH')) is not null
		begin
			drop table 	#tempLastWH
		end 

		if(select object_id('tempdb..#tempLastInfor')) is not null
		begin
			drop table 	#tempLastInfor
		end 

		if(select object_id('tempdb..#temp_SupplierGoods')) is not null
		begin
			drop table 	#temp_SupplierGoods
		end 

		if(select object_id('tempdb..#temp_SaleSheetDetail_shelf')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_shelf
		end 
		if(select object_id('tempdb..#temp_Goods_existSupplier')) is not null
		begin
			drop table 	#temp_Goods_existSupplier
		end 

		if(select object_id('tempdb..#temp_Goods_NotexistSupplier')) is not null
		begin
			drop table 	#temp_Goods_NotexistSupplier
		end 

		if(select object_id('tempdb..#temp_AllGoodsSupplier')) is not null
		begin
			drop table 	#temp_AllGoodsSupplier
		end 

	select y.cGoodsNo,cSupplierNo=min(y.cSupplierNo)  --如果是一品多商，则取cSupplierNo最小的
	into #temp_AllGoodsSupplier
	from
	( 
	 select distinct k.cGoodsNo,k.cSupplierNo
		from
		(
			select cGoodsNo,cSupplierNo=cSupNo 
			from t_supplier_Goods 
			union 
			select distinct p.cGoodsno,q.cSupplierNo from dbo.wh_InWarehouseDetail p,wh_InWarehouse q
			where p.cSheetno=q.cSheetno 
		) k  left join 
		(select distinct cGoodsNo,cSupplierNo=cSupNo from t_Supplier_goods_eStop 

		) j 
		on k.cGoodsNo=j.cGoodsNo and k.cSupplierNo=j.cSupplierNo
		where j.cGoodsNo is  null 
	) y
	group by y.cGoodsNo

	select a.cGoodsNo,a.cSupplierNo
	into #temp_Goods_existSupplier
	from #temp_AllGoodsSupplier a , #temp_Goods b
	where a.cGoodsNo=b.cGoodsNo

	select b.cGoodsNo,cSupplierNo=null
	into #temp_Goods_NotexistSupplier
	from #temp_AllGoodsSupplier a right join #temp_Goods b
	on a.cGoodsNo=b.cGoodsNo
	where a.cGoodsNo is null

		if(select object_id('tempdb..#temp_Goods_selected')) is not null
		begin
			drop table 	#temp_Goods_selected
		end 

  select distinct cGoodsNo,cSupplierNo 
	into #temp_Goods_selected 
	from #temp_Goods_existSupplier
/*以上将需要查询的商品信息转换成 带 供应上的信息*/


  select distinct cGoodsNo,cSupplierNo into #temp_Goods_supplier from #temp_Goods_selected

--select * from #temp_Goods_NotexistSupplier

		if(select object_id('tempdb..#temp_supplier_selected')) is not null
		begin
			drop table 	#temp_supplier_selected
		end 
   select distinct cSupplierNo into #temp_supplier_selected from #temp_Goods_selected
	
--                销售单                 开始 
		select b.cGoodsNo,a.cSupplierNo,b.dSaleDate,b.fQuantity,b.fLastSettle,b.tag_daily,cGoodsNo_b=b.cGoodsNo  --统计最近一次日结后的销售
		into #temp_SaleSheetDetail_shelf 
		from #temp_Goods_supplier a , t_SaleSheetDetail b
		where a.cGoodsNo=b.cGoodsNo and (b.dSaleDate between @dBeginDate and @dEndDate)  and isnull(b.tag_daily,0)=0 

		if(select object_id('tempdb..#temp_SaleSheetDetail_perDay')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_perDay
		end 


		select x.cGoodsNo,x.cSupplierNo,x.dSaleDate,fQuantity=sum(isnull(x.fQuantity,0)),
					fLastSettle=sum(isnull(x.fLastSettle,0)),fCostMoney=cast(null as money),
					cHezuofangshi=cast('' as varchar(32))
		into #temp_SaleSheetDetail_perDay
		from #temp_SaleSheetDetail_shelf x
		group by x.dSaleDate,x.cGoodsNo,x.cSupplierNo

		update a	set a.fCostMoney=b.fLastCostPrice*a.fQuantity
		from #temp_SaleSheetDetail_perDay a,t_goods b
		where a.cGoodsNo=b.cGoodsNo
/*以下开始处理成本*/
		if(select object_id('tempdb..#temp_Supplier_zulin')) is not null
		begin
			drop table 	#temp_Supplier_zulin
		end 
		if(select object_id('tempdb..#temp_Supplier_Hezuofangshi')) is not null
		begin
			drop table 	#temp_Supplier_Hezuofangshi
		end 
 			
    select distinct a.cHezuofangshi, cSupNo= b.cSupplierNo
		into #temp_Supplier_Hezuofangshi
    from dbo.t_Supplier_Contract a ,#temp_supplier_selected b
		where a.cSupNo=b.cSupplierNo
    --group by  cHezuofangshi,cSupNo

		create index ix_temp_Supplier_Hezuofangshi_cSupNo
    on 	#temp_Supplier_Hezuofangshi (cSupNo)


		if(select object_id('tempdb..#temp_Supplier_Goods_Hezuofangshi')) is not null
		begin
			drop table 	#temp_Supplier_Goods_Hezuofangshi
		end 


		if(select object_id('tempdb..#temp_supplier_Goods_IN')) is not null
		begin
			drop table 	#temp_supplier_Goods_IN
		end 

        select distinct a.cGoodsNo,a.cSupNo,b.cHezuofangshi
				into #temp_supplier_Goods_IN
        from t_supplier_Goods a,#temp_Supplier_Hezuofangshi b
        where a.cSupNo=b.cSupNo
				union all
        select distinct a.cGoodsNo,cSupNo=b.cSupplierNo,c.cHezuofangshi
        from WH_INwarehousedetail a ,WH_INwarehouse b, #temp_Supplier_Hezuofangshi c 
				where  a.cSheetno=b.cSheetno and b.cSupplierNo=c.cSupNo
		

		if(select object_id('tempdb..#temp_Supplier_goods_eStop')) is not null
		begin
			drop table 	#temp_Supplier_goods_eStop
		end 

			select distinct e.cGoodsNo,e.cSupNo 
			into #temp_Supplier_goods_eStop
			from t_Supplier_goods_eStop e,#temp_Supplier_Hezuofangshi f
      where e.cSupNo=f.cSupNo

    select distinct c.cGoodsNo,c.cSupNo,c.cHezuofangshi,x.fRatio
    into #temp_Supplier_Goods_Hezuofangshi0
    from #temp_supplier_Goods_IN c 
		left join #temp_Supplier_goods_eStop d 
		on c.cGoodsNo=d.cGoodsNo and  c.cSupNo=d.cSupNo
		left join 
		(
			select cSupNo=guizuno,fRatio=max(fRatio)
			from t_Supplier_Contract_Ratio
			group by guizuno
		) x on c.cSupNo=x.cSupNo
    where d.cSupNo is  null

		select	a.cGoodsNo,a.cSupNo,a.cHezuofangshi,a.fRatio
		into #temp_Supplier_Goods_Hezuofangshi
		from #temp_Supplier_Goods_Hezuofangshi0 a , #temp_Goods_supplier b
		where a.cGoodsNo=b.cGoodsNo

		update a	
		set a.fCostMoney=
				case when b.cHezuofangshi='租赁' 
									then a.fLastSettle
						 when isnull(b.fRatio,0)<>0 and  b.cHezuofangshi<>'租赁' 
									then a.fLastSettle*(1-isnull(b.fRatio,0)/100) 
						 else  a.fCostMoney
				end,
				a.cHezuofangshi=b.cHezuofangshi
		from #temp_SaleSheetDetail_perDay a,#temp_Supplier_Goods_Hezuofangshi b
		where a.cGoodsNo=b.cGoodsNo 

    update #temp_SaleSheetDetail_perDay set fCostMoney=fLastSettle
		where  cSupplierNo is null


		if(select object_id('tempdb..#temp_SaleSheet_day')) is not null
		begin
			drop table 	#temp_SaleSheet_day
		end 


	select a.dSaleDate,a.cGoodsNo,a.fQuantity,a.fLastSettle,
	fCostMoney=case when a.bStorage is not null and a.bStorage=1 then a.fQuantity*a.fCostPrice
									when isnull(a.bStorage,0)=0 and a.cSupplierNo is not null then a.fLastSettle
									else a.fLastSettle*(1-isnull(a.fProfitsRatio,0)/100)
						 end,
	b.cSupNo,b.cHezuofangshi
	into #temp_SaleSheet_day
	from t_SaleSheet_day a , #temp_Supplier_Goods_Hezuofangshi b

	where a.cGoodsNo=b.cGoodsNo and a.dSaleDate between @dBeginDate and @dEndDate

		if(select object_id('tempdb..#temp_Sales_Sum')) is not null
		begin
			drop table 	#temp_Sales_Sum
		end 
/*计算时段顾客退货*/
		if(select object_id('tempdb..#tempReturnGoods')) is not null
		begin
			drop table 	#tempReturnGoods
		end 
  select a.cGoodsNo,fQuantity=-a.fQuantity,fLastSettle=-a.fInMoney,cSupplierNo=c.cSupNo,dSaleDate=b.dDate,
  c.cHezuofangshi
	into #tempReturnGoods
  --into #t_SaleSheetDetail_shelf
  from WH_ReturnGoodsDetail a,WH_ReturnGoods b,#temp_Supplier_Goods_Hezuofangshi c
  where a.cSheetno=b.cSheetno and a.cGoodsNo=c.cGoodsNo and (b.dDate between @dBeginDate and @dEndDate)

		if(select object_id('tempdb..#temp_Salesheet_day_distinct_0')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct_0
		end 

		if(select object_id('tempdb..#temp_Salesheet_day_distinct')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct
		end 
	  
			select a.cGoodsNo,a.dSaleDate,a.fCostPrice,a.fProfitsRatio
			into #temp_Salesheet_day_distinct_0
			from t_salesheet_day a,#temp_Supplier_Goods_Hezuofangshi b
			where  a.dSaleDate  between @dBeginDate and @dEndDate and a.cGoodsNo=b.cGoodsNo
	
  select cGoodsNo,dSaleDate,fCostPrice=max(fCostPrice),fProfitsRatio=max(fProfitsRatio)
	into #temp_Salesheet_day_distinct
	from #temp_Salesheet_day_distinct_0
	group by dSaleDate,cGoodsNo
		if(select object_id('tempdb..#temp_Salesheet_day_distinct_0')) is not null
		begin
			drop table 	#temp_Salesheet_day_distinct_0
		end 
  
		if(select object_id('tempdb..#tempReturnGoods_result')) is not null
		begin
			drop table 	#tempReturnGoods_result
		end 
  select b.cGoodsNo,b.cSupplierNo,b.dSaleDate,b.fQuantity,b.fLastSettle,
	fCostMoney=(case when a.fProfitsRatio is null 
											 then b.fQuantity*a.fCostPrice 
									 else b.fLastSettle*(1-a.fProfitsRatio/100) 
							end),
	b.cHezuofangshi,tag_daily=0
	into #tempReturnGoods_result
  from #temp_Salesheet_day_distinct a,#tempReturnGoods b
	where a.dSaleDate  between @dBeginDate and @dEndDate and a.dSaleDate=b.dSaleDate and a.cGoodsNo=b.cGoodsNo 
    
/*以上计算时段顾客退货*/

	select cGoodsNo,cSupplierNo,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=0
	into #temp_Sales_Sum   -----------时段内销售收入、成本、及所属供应商
	from #temp_SaleSheetDetail_perDay
	union all
	select cGoodsNo,cSupplierNo=cSupno,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=1
	from #temp_SaleSheet_day
	union all
	select cGoodsNo,cSupplierNo,dSaleDate,fQuantity,fLastSettle,fCostMoney,cHezuofangshi,tag_daily=1
	from #tempReturnGoods_result

-----  释放临时表
		if(select object_id('tempdb..#temp_SaleSheetDetail_perDay')) is not null
		begin
			drop table 	#temp_SaleSheetDetail_perDay
		end 
		if(select object_id('tempdb..#tempReturnGoods_result')) is not null
		begin
			drop table 	#tempReturnGoods_result
		end 
		if(select object_id('tempdb..#temp_SaleSheet_day')) is not null
		begin
			drop table 	#temp_SaleSheet_day
		end 


		if(select object_id('tempdb..#temp_Sales_Sum_group')) is not null
		begin
			drop table 	#temp_Sales_Sum_group
		end 

  select cGoodsNo,cSupplierNo,cHezuofangshi,fQuantity=sum(isnull(fQuantity,0)),
	fLastSettle=sum(isnull(fLastSettle,0)),fCostMoney=sum(isnull(fCostMoney,0))
  into #temp_Sales_Sum_group
	from #temp_Sales_Sum
	group by cGoodsNo,cSupplierNo,cHezuofangshi

/*加工商品成本分摊比例列表*/
		if(select object_id('tempdb..#temp_Goods_Produncted')) is not null
		begin
			drop table 	#temp_Goods_Produncted
		end 
  select a.cGoodsNo,a.cGoodsName,a.cUnitedNo,a.cProductNo,a.cBarCode,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsName 
              else b.cGoodsName 
         end as GoodsName_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fBasePrice
         end as BasePrice,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.fNormalPrice 
              else b.fProductedPrice 
         end as ProductedPrice
  into #temp_Goods_Produncted 
  from t_Goods a left join t_GoodsProducted b
                 on a.cProductNo=b.cProductNo
	where a.bStorage=1 and b.cGoodsNo is not null and isnull(dbo.trim(a.cProductNo),'')<>''
  order by a.cGoodsNo

		if(select object_id('tempdb..#temp_Goods_Produncted_sum')) is not null
		begin
			drop table 	#temp_Goods_Produncted_sum
		end 
	select cGoodsNo,ProductedPrice_sum=sum(isnull(ProductedPrice,0))
	into #temp_Goods_Produncted_sum
	from #temp_Goods_Produncted
	group by cGoodsNo

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio
		end 
  select a.*,fRatio=round(a.ProductedPrice/case when b.ProductedPrice_sum=0 then null else  b.ProductedPrice_sum end *100,4),b.ProductedPrice_sum
	into #temp_Goods_Produncted_Ratio
	from #temp_Goods_Produncted a,#temp_Goods_Produncted_sum b
	where a.cGoodsNo=b.cGoodsNo
  --and (a.cGoodsNo='21030267' or a.cGoodsNo='25060266')

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio_1')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio_1
		end 
	select a.cGoodsNo,a.fRatio_total_loss
	into #temp_Goods_Produncted_Ratio_1
	from
	(
			select cGoodsNo,fRatio_total_loss=100-sum(isnull(fRatio,0))
			from #temp_Goods_Produncted_Ratio
			group by cGoodsNo
	) a
	where a.fRatio_total_loss<>0

		if(select object_id('tempdb..#temp_Goods_Produncted_Ratio_1_locate')) is not null
		begin
			drop table 	#temp_Goods_Produncted_Ratio_1_locate
		end 
	select distinct a.cGoodsNo,GoodsNo_Pdt_loss=(select top 1 GoodsNo_Pdt from #temp_Goods_Produncted where cGoodsNo=a.cGoodsNo ),
         b.fRatio_total_loss         
	into #temp_Goods_Produncted_Ratio_1_locate
	from #temp_Goods_Produncted a,#temp_Goods_Produncted_Ratio_1 b
	where a.cGoodsNo=b.cGoodsNo
  
  update a set a.fRatio=a.fRatio+b.fRatio_total_loss
	from #temp_Goods_Produncted_Ratio a,#temp_Goods_Produncted_Ratio_1_locate b
	where a.cGoodsNo=b.cGoodsNo and a.GoodsNo_Pdt=b.GoodsNo_Pdt_loss
/* 加工商品成本分摊比例列表处理完毕 */

/*下面按照 加工商品成本分摊比例列表 进行商品分类：非加工商品 、加工商品 */
		if(select object_id('tempdb..#temp_Sales_Sum_group_join')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join
		end 

  select a.cGoodsNo,a.cSupplierNo,a.cHezuofangshi,a.fQuantity,a.fLastSettle,a.fCostMoney,
	cGoodsNo_b=b.cGoodsNo
	into #temp_Sales_Sum_group_join
	from #temp_Sales_Sum_group a left join
	(  select distinct cGoodsNo
     from #temp_Goods_Produncted_Ratio 
	) b
	on a.cGoodsNo=b.cGoodsNo

		if(select object_id('tempdb..#temp_Sales_Sum_group_join_result_0')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join_result_0
		end 

	select cGoodsNo,cSupplierNo,cHezuofangshi,fQuantity,fLastSettle, fCostMoney ,fProfit=(fLastSettle-fCostMoney),
	fRatioAvg=(fLastSettle-fCostMoney)/case when fLastSettle=0 then null else fLastSettle end,iTag=0
	into #temp_Sales_Sum_group_join_result_0    --存在供应商的 商品
	from #temp_Sales_Sum_group_join  ---非加工商品
	where cGoodsNo_b is null
	union all
	SELECT cGoodsNo=b.GoodsNo_Pdt,a.cSupplierNo,a.cHezuofangshi,
	fQuantity=a.fQuantity*b.Qty,fLastSettle=a.fLastSettle*10000*b.fRatio/1000000,
	fCostMoney=a.fCostMoney*10000*b.fRatio/1000000 ,
	fProfit=((a.fLastSettle*10000*b.fRatio/1000000)-(a.fCostMoney*10000*b.fRatio/1000000)),
	fRatioAvg=(((a.fLastSettle*10000*b.fRatio/1000000)-(a.fCostMoney*10000*b.fRatio/1000000)))
						/case when a.fLastSettle*10000*b.fRatio/1000000=0 
											then null 
									else a.fLastSettle*10000*b.fRatio/1000000 
						 end,
	iTag=1             --加工商品
	FROM #temp_Sales_Sum_group_join a  , #temp_Goods_Produncted_Ratio b
	where a.cGoodsNo=b.cGoodsNo
	
/*以上计算 存在供应商的 商品 的销售和毛利#temp_Goods_ExistSupplier*/

/*以下计算 不存在供应商的 商品 的销售和毛利#temp_Goods_NotexistSupplier*/
		if(select object_id('tempdb..#temp_Sales_Sum_group_join_result_1')) is not null
		begin
			drop table 	#temp_Sales_Sum_group_join_result_1
		end 

		if(select object_id('tempdb..#temp_NotExistSupplier_sales')) is not null
		begin
			drop table 	#temp_NotExistSupplier_sales
		end 
	select b.cGoodsNo,cSupplierNo=null,fQuantity=sum(a.fQuantity),
	fLastSettle=sum(a.fLastSettle)
	into #temp_NotExistSupplier_sales
	from dbo.t_SaleSheet_Day a,#temp_Goods_NotexistSupplier b
	where a.dSaleDate between @dBeginDate and @dEndDate  and a.cGoodsNo=b.cGoodsNo
	group by b.cGoodsNo
  union all
	select b.cGoodsNo,cSupplierNo=null,fQuantity=sum(a.fQuantity),
	fLastSettle=sum(a.fLastSettle)
	from dbo.t_SaleSheetDetail a,#temp_Goods_NotexistSupplier b
	where a.dSaleDate between @dLastDaily and @dEndDate  and a.cGoodsNo=b.cGoodsNo
	group by b.cGoodsNo

  select cGoodsNo,cSupplierNo=null,fQuantity=sum(fQuantity),fLastSettle=sum(fLastSettle),
	fCostMoney=sum(fLastSettle),fProfit=0,fRatioAvg=0
	into #temp_Sales_Sum_group_join_result_1
	from #temp_NotExistSupplier_sales
	group by cGoodsNo
	union all
  select cGoodsNo,cSupplierNo,fQuantity,fLastSettle,
	fCostMoney,fProfit,fRatioAvg
	from #temp_Sales_Sum_group_join_result_0

	select x.cGoodsTypeNo,x.cPath,fLastSettle=sum(isnull(x.fLastSettle,0)),fCostMoney=sum(isnull(x.fCostMoney,0)),
	fProfit=cast(0.00 as money),fRatioAvg=cast(0.00 as money)
	into #tempSales_GoodsType
	from
	(
			select a.cGoodsNo,b.cGoodsTypeNo,c.cPath,
			a.cSupplierNo,a.fQuantity,a.fLastSettle,
			a.fCostMoney,a.fProfit,a.fRatioAvg 
			--into #tempSales_GoodsType
			from #temp_Sales_Sum_group_join_result_1 a,t_Goods b,#tempLevel c
			where a.cGoodsNo=b.cGoodsNo and b.cGoodsTypeNo=c.cGoodsTypeNo 
	)x
	group by x.cGoodsTypeNo,x.cPath

	update #tempSales_GoodsType set fProfit=isnull(fLastSettle,0)-isnull(fCostMoney,0),
	fRatioAvg=(isnull(fLastSettle,0)-isnull(fCostMoney,0))*100
						/case when fLastSettle=0 then null else fLastSettle end

 -- select * from #tempSales_GoodsType

	select b.cGoodsTypeNo,b.cPath,b.cPath_leaf,a.fLastSettle,a.fCostMoney,a.fProfit,a.fRatioAvg 
	into #tempSales_GoodsType_selected
	from #tempSales_GoodsType a right join #tempGoodsTypePath b
	on a.cPath=b.cPath_leaf
	where a.cGoodsTypeNo is not null
	order by b.cPath_leaf,b.cGoodsTypeNo

	select cGoodsTypeNo,cPath,cPath_leaf,fLastSettle,fCostMoney,fProfit,fRatioAvg
	from #tempSales_GoodsType_selected
/*
	select cGoodsTypeNo,cPath,cPath_leaf,fLastSettle,fCostMoney,fProfit,fRatioAvg
	from #tempSales_GoodsType_selected
	union all
*/
	select cGoodsTypeNo,cPath,cPath_leaf=null,fLastSettle=sum(fLastSettle),fCostMoney=sum(fCostMoney),
	fProfit=sum(fProfit),
	fRatioAvg=sum(fProfit)*100/case when sum(fLastSettle)=0 then null else sum(fLastSettle) end
	from #tempSales_GoodsType_selected
	group by cGoodsTypeNo,cPath
  order by cPath,cGoodsTypeNo



/*

  	select a.cGoodsTypeNo,b.cGoodsTypename,a.cPath,a.cPath_leaf,a.iLevel
		into #tempGoodsTypePath
	  from #tempPath a,t_GoodsType b
		where a.cGoodsTypeno=b.cGoodsTypeNo

*/
/*

		if(select object_id('tempdb..#temp_Goods')) is not null
		begin
			drop table 	#temp_Goods
		end 

		select cGoodsNo  into #temp_Goods from t_goods where cGoodsTypeNo='2402' or cGoodsTypeNo='2403'
		--select cGoodsNo  into #temp_Goods from t_goods where  cGoodsTypeNo='2403'
		go
		p_x_SalesProfitABC_byGoodsType_wind '2008-05-01','2008-09-20',1,1

*/

/*
select * from #temp_Sales_Sum_group_join_result_0

select * from t_goods where cGoodsNo='22010411'
  	select a.cGoodsTypeNo,b.cGoodsTypename,a.cPath,a.cPath_leaf,a.iLevel
		into #tempGoodsTypePath
	  from #tempPath a,t_GoodsType b
		where a.cGoodsTypeno=b.cGoodsTypeNo

*/

end


GO
