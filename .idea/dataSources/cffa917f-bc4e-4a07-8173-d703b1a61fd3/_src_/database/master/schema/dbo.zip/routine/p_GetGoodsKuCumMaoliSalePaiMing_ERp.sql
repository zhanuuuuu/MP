 

/*
  　1.高库存（购销，库存天数>标准天数+20天，库存金额>500元，库存数量≥4×订货倍数，已30日未进货。）
　　2.负库存（库存量<0）
　　3.负毛利（毛利<0）
　　4.应销未订货（库存0，且超过7天未销售，未订货；有无在途可选）
　　5.畅销缺货（0≤可销天数≤3天   DMS选择：百货≥1，杂货≥2）
　　6.0销售（库存>0，百货≥20天，杂货≥15天未销售）~~
　　7.150N (商品状态：0、正常商品，1、即将删除商品，2、已经删除商品，3、暂停进货商品，4、厂商缺货商品，5、过季商品。
            可销售状态：Y、可销售，N、不可销售。)
 
    if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
    select cGoodsNo into #temp_Goods from t_Goods 
    where cgoodstypeno like '2%'
    
  exec p_GetGoodsKuCumMaoliSalePaiMing_ERp '2015-04-1','2015-04-30','02' 
  
*/
--------------月结表中取。。。。。
create proc [dbo].[p_GetGoodsKuCumMaoliSalePaiMing_ERp]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32),
@key varchar(32) 
as
begin
   declare @dDate1 varchar(32)
   declare @dDate2 varchar(32)
   declare @DbName varchar(32)
   set @DbName=(select Pos_WH_Form from t_WareHouse where ISNULL(bMainSale,0)=1 and cWhNo=@cWhno)
   declare @BgnDate datetime
   set @BgnDate=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
   set @dDate1=dbo.getdaystr(DATEADD(MONTH,-1,@BgnDate))
   set @dDate2=dbo.getdaystr(CAST((cast(YEAR(@dDateEnd) as varchar(16))+'-'+cast(MONTH(@dDateEnd) as varchar(16))+'-01') AS DATETIME))
   
   --print dbo.getTimeStr(GETDATE())
   --print 1 
	--if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	--select distinct cGoodsNo into #tmpCostGoodsList 
	--from #temp_Goods
	
	--CREATE INDEX IX_tmp_tmpCostGoodsList  ON #tmpCostGoodsList(cGoodsNo)
/*_________根据类别获取基本信息____________*/
   
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
Create Table #temp_Goods (
cGoodsNo varchar(128),
cProductNo varchar(128),
cSupplierNo varchar(128)) 

if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null  drop table  #temp_GoodsTypeNo
create table #temp_GoodsTypeNo(cGoodsTypeno varchar(32))

 
insert into  #temp_Goods(cGoodsNo,cSupplierNo) 
exec(' 
if  (select object_id(''Temp_SupKey.dbo.temp_type'+@key+''')) is  null
select cGoodsTypeno into Temp_SupKey.dbo.temp_type'+@key+' from t_Goodstype where 1<>1

insert into #temp_GoodsTypeNo(cGoodsTypeno) select cGoodsTypeno from Temp_SupKey.dbo.temp_type'+@key+' 

select cGoodsNo,cSupplierNo=csupno from t_Goods where cGoodsTypeno in (select cGoodsTypeno from Temp_SupKey.dbo.temp_type'+@key+')

')
 



	if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	select distinct cGoodsNo into  #tmp_WhGoodsList  from (
	select distinct a.cGoodsNo  
	from #temp_Goods a,t_goods b
	where a.cgoodsno=b.cgoodsno 
	union all
	select distinct cGoodsNo=b.cGoodsNo_minPackage     ---有关联包装的 供应商不一致的。。 
	from #temp_Goods a,t_goods b
	where a.cgoodsno=b.cgoodsno and  isnull(b.cGoodsNo_minPackage,'')<>'' --dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
	) a

	CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

  	if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods
	select distinct cGoodsNo into #temp_WhFromGoods from #tmp_WhGoodsList

	CREATE INDEX IX_temp_WhFromGoods  ON #temp_WhFromGoods(cGoodsNo)
                                        
	if(select object_id('tempdb..#temp_WhFromheji_Month')) is not null drop table #temp_WhFromheji_Month
	CREATE TABLE #temp_WhFromheji_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(64) null,
	期初库存 money,期末库存 money,期末库存金额 money,当前库存 money,当前库存金额 money,在途数量 money,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money,
	会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money,
	库存状态 varchar(16),应销未订货 varchar(16),畅销状态 varchar(16),
	毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(16),最后销售日 datetime)
	
	if(select object_id('tempdb..#temp_WhFromendheji_Month')) is not null drop table #temp_WhFromendheji_Month
	CREATE TABLE #temp_WhFromendheji_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
	cSupplierNo varchar(32) null,cSupplier varchar(64) null,
	期初库存 money,期末库存 money,期末库存金额 money,当前库存 money,当前库存金额 money,在途数量 money,
	销售数量 money, 销售金额 money, 
	特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 
	fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money,
	会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money,
	库存状态 varchar(16),应销未订货 varchar(16),畅销状态 varchar(16),
	毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(16),最后销售日 datetime)
	
	------获取会员情况----
    if(select object_id('tempdb..#temp_WhFromVIP')) is not null drop table #temp_WhFromVIP
    CREATE TABLE #temp_WhFromVIP ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
--print dbo.getTimeStr(GETDATE())
--print 2   
     -------获取时间段内的进销存-------

exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_heji_month''))is not null  drop table #temp_Wh_Goods_heji_month
	select a.[cGoodsNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额,b.期末库存,b.期初库存
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_heji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	with(nolock)
	where dDateBgn='''+@dDate1+''' and a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_monthheji''))is not null  drop table #temp_SumWh_Goods_monthheji
	select cgoodsno,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),	
	期末库存=sum(期末库存),期初库存=sum(期初库存),
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goods_monthheji
	from  #temp_Wh_Goods_heji_month
	group by cgoodsno
				
	insert into #temp_WhFromheji_Month(
	       [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml)
 	select [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goods_monthheji    

')
 
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endheji_month''))is not null  drop table #temp_Wh_Goods_endheji_month
	select a.[cGoodsNo],b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额,b.期末库存,b.期初库存
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_endheji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate2+''' and a.cGoodsNo=b.cGoodsNo 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endmonthheji''))is not null  drop table #temp_SumWh_Goods_endmonthheji
	select cgoodsno,销售数量=sum(销售数量0), 销售金额=sum(销售金额0), 
	特价销售数量=sum(特价销售数量), 特价销售金额=sum(特价销售金额), 		
	正价销售数量=sum(正价销售数量), 正价销售金额=sum(正价销售金额),		
	期末库存=sum(期末库存),期初库存=sum(期初库存),	  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goods_endmonthheji
	from  #temp_Wh_Goods_endheji_month
	group by cgoodsno
				
	insert into #temp_WhFromendheji_Month(
	       [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml)
	select [cGoodsNo],销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,期末库存,期初库存,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goods_endmonthheji    

    ------------获取会员情况。     
      if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_vip_month''))is not null  drop table #temp_Wh_Goods_vip_month
      select distinct b.cgoodsno,b.当月会员销售数量,b.当月会员销售金额,b.当月会员来客数,b.来客数
      into #temp_Wh_Goods_vip_month
	  from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	  with(nolock)
	  where dDateBgn between '''+@BgnDate+''' and '''+@dDate2+''' and a.cGoodsNo=b.cGoodsNo 
	 
	  insert into #temp_WhFromVIP(cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数 )
	  select cgoodsno,会员销售数量=sum(当月会员销售数量),会员销售金额=sum(当月会员销售金额),会员来客数=sum(当月会员来客数),来客数=sum(来客数)
	  from #temp_Wh_Goods_vip_month   
	  group by cgoodsno
	  
') 

--print dbo.getTimeStr(GETDATE())
--print 3

update a
set a.销售数量=isnull(a.销售数量,0)-isnull(b.销售数量,0),a.销售金额=isnull(a.销售金额,0)-isnull(b.销售金额,0),
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0),a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0),
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0),a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
a.fMoney_cost=isnull(a.fMoney_cost,0)-isnull(b.fMoney_cost,0),a.fml=isnull(a.fml,0)-isnull(b.fml,0),
a.期初库存=ISNULL(b.期末库存,0),
a.期末库存=ISNULL(a.期末库存,0)
from #temp_WhFromendheji_Month a,#temp_WhFromheji_Month b
where a.cGoodsNo=b.cGoodsNo

--print dbo.getTimeStr(GETDATE())
--print 4
/*
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select a.cGoodsNo,a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,
a.fMoney_Cost,a.fml,a.fPrice_Avg,
a.期初库存,a.期末库存,当前库存=CAST(0 as money),当前库存金额=CAST(0 as money),在途数量=CAST(0 as money),
b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数,
a.库存状态,a.应销未订货,a.畅销状态,
a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日
into #temp_goodsKuCunml
from #temp_WhFromendheji_Month a,#temp_WhFromVIP b
where a.cGoodsNo=b.cGoodsNo
*/

if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select a.cGoodsNo,销售数量=sum(a.销售数量),销售金额=sum(a.销售金额),特价销售数量=sum(a.特价销售数量),特价销售金额=sum(a.特价销售金额),
正价销售数量=sum(a.正价销售数量),正价销售金额=sum(a.正价销售金额),
fMoney_Cost=sum(a.fMoney_Cost),fml=sum(a.fml),fPrice_Avg=AVG(a.fPrice_Avg),
期初库存=sum(a.期初库存),期末库存=sum(a.期末库存),当前库存=CAST(0 as money),当前库存金额=CAST(0 as money),在途数量=CAST(0 as money),
会员销售数量=sum(b.会员销售数量),会员销售金额=sum(b.会员销售金额),会员来客数=sum(b.会员来客数),来客数=sum(b.来客数),
a.库存状态,a.应销未订货,a.畅销状态,
a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日,
    上月销售金额=CAST(null as money),上月销售数量=CAST(null as money),上月成本金额=CAST(null as money) 
into #temp_goodsKuCunml
from #temp_WhFromendheji_Month a,#temp_WhFromVIP b
where a.cGoodsNo=b.cGoodsNo
group by a.cGoodsNo,a.库存状态,a.应销未订货,a.畅销状态,
a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日

CREATE INDEX IX_temp_goodsKuCunml  ON #temp_goodsKuCunml(cGoodsNo)

-----------获取当前库存-------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
declare @dDate date
set @dDate=CONVERT (date, GETDATE())


 exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDate,@dDate,@cWhno  
 
--print dbo.getTimeStr(GETDATE())
--print 5
 
CREATE INDEX IX_temp_goodsKuCurQty  ON #temp_goodsKuCurQty(cGoodsNo)


insert into #temp_goodsKuCunml(cGoodsNo)
select b.cGoodsNo from #temp_goodsKuCunml  a right join #temp_goodsKuCurQty b on a.cGoodsNo=b.cGoodsNo
where ISNULL(a.cGoodsNo,'')=''


---------获取上个月的正月销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cgoodsno varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fMoney_Cost money)
declare @ddatebgn1 datetime
declare @lastBgn1 datetime
declare @lastEnd1 datetime
set @ddatebgn1=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
set @lastBgn1=DATEADD(MONTH,-1,@ddatebgn1)
set @lastEnd1=DATEADD(DAY,-1,@ddatebgn1) 

declare @day int
set @day=DATEDIFF (DAY,@lastBgn1,@lastEnd1)+1

--  print '13002    '+dbo.getTimeStr(GETDATE())

exec p_GetLastMonthSale_wei @lastBgn1,@lastEnd1,@cWHno,@DbName

 -- print '13003    '+dbo.getTimeStr(GETDATE())

update a
set a.上月销售数量=b.xsQty,a.上月销售金额=b.xsMoney,上月成本金额=b.fMoney_Cost
from #temp_goodsKuCunml a,#temp_GetLastMonthSale_wei b
where a.cGoodsNo=b.cgoodsno
/*
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月销售数量,0)<>0 
then ISNULL(b.EndQty,0)*@day/ISNULL(a.上月销售数量,0) 
else case when ISNULL(a.上月销售数量,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_goodsKuCunml a left join #temp_goodsKuCurQty b
on a.cGoodsNo=b.cGoodsNo
*/
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月成本金额,0)<>0 
then ISNULL(b.Endmoney,0)*@day/ISNULL(a.上月成本金额,0) 
else case when ISNULL(a.上月成本金额,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_goodsKuCunml a left join #temp_goodsKuCurQty b
on a.cGoodsNo=b.cGoodsNo

 
--print dbo.getTimeStr(GETDATE())
--print 6
-----
update #temp_goodsKuCunml
set 畅销状态='畅销商品',库存状态='低库存',商品状态='正常'
where 可销天数>=0 and 可销天数<=5

update #temp_goodsKuCunml
set 畅销状态='一般商品',库存状态='正常',商品状态='正常'
where 可销天数>5 and 可销天数<=20

update #temp_goodsKuCunml
set 畅销状态='滞销商品',库存状态='高库存',商品状态='正常'
where 可销天数>20

update #temp_goodsKuCunml
set  库存状态='零库存',商品状态='待进货',畅销状态='一般商品'
where 当前库存=0

update #temp_goodsKuCunml
set 商品状态='待进货',库存状态='负库存',畅销状态='一般商品'
where 当前库存<0

--print dbo.getTimeStr(GETDATE())
--print 7

---------取最近一个月内商品的销售---------

  ---------取出大包装  
if (select object_id('tempdb..#temp_MaxPackGoods')) is not null
drop table #temp_MaxPackGoods
select a.cGoodsNo,cGoodsNo_minPackage,fQty_minPackage into #temp_MaxPackGoods 
from t_Goods a,#temp_WhFromGoods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(a.cGoodsNo_minPackage,'')<>''

if (select object_id('tempdb..#tmp_GoodsSale30'))is not null drop table #tmp_GoodsSale30
select a.cGoodsNo,dSaleDate=a.last_SaleDate into #tmp_GoodsSale30 from 
t_GetGoods_InOut a,#temp_WhFromGoods b
with (nolock) 
where a.cgoodsno=b.cgoodsno

insert into #tmp_GoodsSale30(cgoodsno,dSaleDate)
select b.cGoodsNo_minPackage,a.dSaleDate from #tmp_GoodsSale30 a,#temp_MaxPackGoods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


if (select object_id('tempdb..#tmp_MaxGoodsSale30'))is not null drop table #tmp_MaxGoodsSale30
select dSaleDate=MAX(dSaleDate),cGoodsNo
into #tmp_MaxGoodsSale30
from #tmp_GoodsSale30
group by cGoodsNo

CREATE INDEX IX_temp_MaxGoodsSale30  ON #tmp_MaxGoodsSale30(cGoodsNo)

--print dbo.getTimeStr(GETDATE())
--print 9
 
update a
set  a.最后销售日=b.dSaleDate
from #temp_goodsKuCunml a,#tmp_MaxGoodsSale30 b
where a.cGoodsNo=b.cGoodsNo


--print dbo.getTimeStr(GETDATE())
--print 10
/*
if (select object_id('tempdb..')) is not null
drop table #temp_MaxDatePackGoods1
select  a.cGoodsNo,a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,
a.fPrice_Avg,a.期初库存,a.期末库存,
a.当前库存,a.当前库存金额,a.会员销售数量,a.会员销售金额,a.会员来客数,a.来客数,a.库存状态,a.畅销状态,
a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,b.dSaleDate
into #temp_MaxDatePackGoods1
from #temp_goodsKuCunml a left join #tmp_MaxGoodsSale30 b
on a.cGoodsNo=b.cGoodsNo
*/
--print dbo.getTimeStr(GETDATE())
--print 11
--------获取在途数量----
if (select object_id('tempdb..#temp_WH_StockGoods')) is not null
drop table #temp_WH_StockGoods
select  cGoodsNo,fQuantity=sum(b.fQuantity) 
into #temp_WH_StockGoods
from posmanagement.dbo.WH_Stock a,posmanagement.dbo.WH_StockDetail b
with(nolock)
where a.dDate between (CONVERT (date, GETDATE()-7-iDays)) and dDeadLine and a.cSheetno=b.cSheetno
and isnull(a.bExamin,0)=1 and ISNULL(a.bReceive,0)=0
group by cGoodsNo

CREATE INDEX IX_temp_WH_StockGoods  ON #temp_WH_StockGoods(cGoodsNo)

update a
set a.cGoodsNo=b.cGoodsNo_minPackage,fQuantity=isnull(a.fQuantity,0)*isnull(b.fQty_minPackage,0)
from #temp_WH_StockGoods a,#temp_MaxPackGoods b
where a.cgoodsno=b.cGoodsNo

--print dbo.getTimeStr(GETDATE())
--print 12
----- 修改在途数量
update a
set  a.在途数量=b.fQuantity
from #temp_goodsKuCunml a,#temp_WH_StockGoods b
where a.cGoodsNo=b.cGoodsNo

-- print dbo.getTimeStr(GETDATE())
--print 13

---修改特价销售为负-----
update #temp_goodsKuCunml set 特价销售数量=0,特价销售金额=0,
正价销售数量=ISNULL(正价销售数量,0)+ISNULL(特价销售数量,0),正价销售金额=ISNULL(正价销售金额,0)+ISNULL(特价销售金额,0)
where ISNULL(特价销售金额,0)<0


if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
drop table #temp_GetKuCunMaoli_wei

Create Table #temp_GetKuCunMaoli_wei (
cGoodsNo varchar(32),cgoodsname varchar(64),cSpec  varchar(32),cUnit varchar(32),
iLine bigint IDENTITY(1,1) NOT NULL,
csupno varchar(32),cSupName varchar(64),
fNormalPrice money,fCKPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),
销售数量 money,销售金额 money,特价销售数量 money,特价销售金额 money,正价销售数量 money,正价销售金额 money,
fMoney_cost money,fml money,fPrice_Avg money,期初库存 money,期末库存 money,
当前库存 money,当前库存金额 money,在途数量 money,会员销售数量 money,会员销售金额 money,会员来客数 money,
来客数 money,库存状态 varchar(32),畅销状态 varchar(32),毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(32),
最后销售日 varchar(32))

if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
begin
 
    insert into #temp_GetKuCunMaoli_wei(cGoodsNo,cgoodsname,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
	cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,会员销售占比,商品状态,最后销售日)
	select a.cGoodsNo,b.cgoodsname,b.cSpec,b.cUnit,b.csupno,b.cSupName,b.fNormalPrice,b.fCKPrice,
	b.cGoodsTypeno,b.cGoodsTypename,
	a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,
	a.fPrice_Avg,a.期初库存,a.期末库存,
	a.当前库存,a.当前库存金额,a.在途数量,a.会员销售数量,a.会员销售金额,a.会员来客数,
	a.来客数,a.库存状态,a.畅销状态,a.毛利状态,a.可销天数,
	会员销售占比=case when isnull(a.销售金额,0)<>0 then (a.会员销售金额/a.销售金额)*100 else 0 end,a.商品状态,
	最后销售日=ISNULL(CONVERT(VARCHAR(100),a.最后销售日,23),'30日内未销售') from #temp_goodsKuCunml a,t_Goods b
	where a.cgoodsno=b.cgoodsno and isnull(a.销售金额,0)<>0
	order by cGoodsTypeno,a.销售金额 desc
	
	if  (select object_id('tempdb..#temp_GetMinLine')) is not null
    drop table #temp_GetMinLine
	select cGoodsTypeno,iLine=MIN(iLine) into #temp_GetMinLine from #temp_GetKuCunMaoli_wei
	group by cGoodsTypeno
	
	    exec('
  if (select object_id(''U_key.dbo.s_'+@Key+'''))is not null 
  drop table U_key.dbo.s_'+@Key+'

		  select iLine=a.iLine-b.iLine+1,a.cGoodsNo,a.cgoodsname,a.cSpec,a.cUnit,a.csupno,a.cSupName,a.fNormalPrice,a.fCKPrice,
	a.cGoodsTypeno,a.cGoodsTypename,
	a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,a.fPrice_Avg,a.期初库存,a.期末库存,
	a.当前库存,a.当前库存金额,a.在途数量,a.会员销售数量,a.会员销售金额,a.会员来客数,
	a.来客数,a.库存状态,a.畅销状态,a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日 
	into U_key.dbo.s_'+@Key+'
	from 
	#temp_GetKuCunMaoli_wei a,#temp_GetMinLine b
	where a.cGoodsTypeno=b.cGoodsTypeno and a.iLine between b.iLine and b.iLine+20-1
	union all
	 select iLine=999999,cGoodsNo=''合计:'',cgoodsname=null,cSpec=null,cUnit=null,csupno=null,cSupName=null,fNormalPrice=null,fCKPrice=null,
	cGoodsTypeno=null,cGoodsTypename=null,
	销售数量=SUM(a.销售数量),销售金额=SUM(a.销售金额),特价销售数量=SUM(a.特价销售数量),特价销售金额=SUM(a.特价销售金额),
    正价销售数量=SUM(a.正价销售数量),正价销售金额=SUM(a.正价销售金额),fMoney_cost=SUM(a.fMoney_cost),fml=SUM(a.fml),
    fPrice_Avg=null,期初库存=SUM(a.期初库存),期末库存=SUM(a.期末库存),
    当前库存=SUM(a.当前库存),当前库存金额=SUM(a.当前库存金额),在途数量=SUM(a.在途数量),会员销售数量=SUM(a.会员销售数量),会员销售金额=SUM(a.会员销售金额),会员来客数=sum(a.会员来客数),
    来客数=SUM(a.来客数),库存状态=null,畅销状态=null,毛利状态=null,可销天数=null,会员销售占比=case when SUM(a.销售金额)<>0 then (sum(a.会员销售金额)/sum(a.销售金额))*100 else 0 end,商品状态=null,最后销售日=null
	from 
	#temp_GetKuCunMaoli_wei a,#temp_GetMinLine b
	where a.cGoodsTypeno=b.cGoodsTypeno and a.iLine between b.iLine and b.iLine+20-1
	 
   ')
   
	 
end else
begin

   
   
    insert into #temp_GetKuCunMaoli_wei(cGoodsNo,cgoodsname,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
	cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,会员销售占比,商品状态,最后销售日)
    select a.cGoodsNo,b.cgoodsname,b.cSpec,b.cUnit,b.csupno,b.cSupName,b.fNormalPrice,b.fCKPrice,
	b.cGoodsTypeno,b.cGoodsTypename,
	a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,
	a.fPrice_Avg,a.期初库存,a.期末库存,
	a.当前库存,a.当前库存金额,a.在途数量,a.会员销售数量,a.会员销售金额,a.会员来客数,
	a.来客数,a.库存状态,a.畅销状态,a.毛利状态,a.可销天数,
	会员销售占比=case when isnull(a.销售金额,0)<>0 then (a.会员销售金额/a.销售金额)*100 else 0 end,a.商品状态,
	最后销售日=ISNULL(CONVERT(VARCHAR(100),a.最后销售日,23),'30日内未销售') from #temp_goodsKuCunml a,t_Goods b
	where a.cgoodsno=b.cgoodsno
	order by cGoodsTypeno,a.销售金额 desc
	
	if  (select object_id('tempdb..#temp_GetMinLine1')) is not null
    drop table #temp_GetMinLine1
	select cGoodsTypeno,iLine=MIN(iLine) into #temp_GetMinLine1 from #temp_GetKuCunMaoli_wei
	group by cGoodsTypeno
	
 
	select iLine=a.iLine-b.iLine+1,a.cGoodsNo,a.cgoodsname,a.cSpec,a.cUnit,a.csupno,a.cSupName,a.fNormalPrice,a.fCKPrice,
	a.cGoodsTypeno,a.cGoodsTypename,
	a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,a.fPrice_Avg,a.期初库存,a.期末库存,
	a.当前库存,a.当前库存金额,a.在途数量,a.会员销售数量,a.会员销售金额,a.会员来客数,
	a.来客数,a.库存状态,a.畅销状态,a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日 from 
	#temp_GetKuCunMaoli_wei a,#temp_GetMinLine1 b
	where a.cGoodsTypeno=b.cGoodsTypeno and a.iLine between b.iLine and b.iLine+20-1
	
end 
 
end
GO
