/*
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo into #temp_Goods from t_Goods where cGoodsNo='20003'
declare @bJiaGong bit
exec [P_x_SetCheckWh_byGoodsType]
'2012-10-1','2012-10-20','01',@bJiaGong
*/

/*按商品类别查库存[P_x_SetCheckWh_byGoodsType]*/
CREATE procedure [dbo].[p_NoSaleGoodsTypeStock_byGoodsType]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhNo varchar(32),/*是仓库No*/
@bJiaGong bit
as
--declare @cWhNo varchar(100)
--declare @dDateBgn datetime
--declare @dDateEnd datetime  --时段截止日期
--set @dDateBgn='2012-06-26' set @dDateEnd='2012-06-26' set @cWhNo='01' 
--if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
--select distinct cGoodsNo into #temp_Goods from t_goods where cGoodsNo='7100018'

if (select OBJECT_ID('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select * into #tmpCostGoodsList from #temp_Goods

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin ([dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[fQty_In] [money] NULL,[fMoney_In] [money] NULL,[fQty_TfrIn] [money] NULL,[fMoney_TfrIn] [money] NULL,[fQty_Return] [money] NULL,[fMoney_Return] [money] NULL,[fQty_Effusion] [money] NULL,[fMoney_Effusion] [money] NULL,[fQty_Divide] [money] NULL,[fMoney_Divide] [money] NULL,[fQty_Pack] [money] NULL,[fMoney_Pack] [money] NULL,[fQty_trf] [money] NULL,[fMoney_trf] [money] NULL,[fQty_Rbd] [money] NULL,[fMoney_Rbd] [money] NULL,[fQty_Loss] [money] NULL,[fMoney_Loss] [money] NULL,[fQty_out] [money] NULL,[fMoney_out] [money] NULL,[fQty_Check_Diff] [money] NULL,[fQty_pd] [money] NULL,[fMoney_pd] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_In] [money] NULL,[fMoney_In_all] [money] NULL,[total_TfrIn] [money] NULL,[fMoney_TfrIn_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[total_Effusion] [money] NULL,[fMoney_Effusion_all] [money] NULL,[total_Divide] [money] NULL,[fMoney_Divide_all] [money] NULL,[total_Pack] [money] NULL,[fMoney_Pack_all] [money] NULL,[total_trf] [money] NULL,[fMoney_trf_all] [money] NULL,[total_Rbd] [money] NULL,[fMoney_Rbd_all] [money] NULL,[total_Loss] [money] NULL,[fMoney_Loss_all] [money] NULL,[total_out] [money] NULL,[fMoney_out_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)
CREATE TABLE #temp_end   ([dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[fQty_In] [money] NULL,[fMoney_In] [money] NULL,[fQty_TfrIn] [money] NULL,[fMoney_TfrIn] [money] NULL,[fQty_Return] [money] NULL,[fMoney_Return] [money] NULL,[fQty_Effusion] [money] NULL,[fMoney_Effusion] [money] NULL,[fQty_Divide] [money] NULL,[fMoney_Divide] [money] NULL,[fQty_Pack] [money] NULL,[fMoney_Pack] [money] NULL,[fQty_trf] [money] NULL,[fMoney_trf] [money] NULL,[fQty_Rbd] [money] NULL,[fMoney_Rbd] [money] NULL,[fQty_Loss] [money] NULL,[fMoney_Loss] [money] NULL,[fQty_out] [money] NULL,[fMoney_out] [money] NULL,[fQty_Check_Diff] [money] NULL,[fQty_pd] [money] NULL,[fMoney_pd] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_In] [money] NULL,[fMoney_In_all] [money] NULL,[total_TfrIn] [money] NULL,[fMoney_TfrIn_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[total_Effusion] [money] NULL,[fMoney_Effusion_all] [money] NULL,[total_Divide] [money] NULL,[fMoney_Divide_all] [money] NULL,[total_Pack] [money] NULL,[fMoney_Pack_all] [money] NULL,[total_trf] [money] NULL,[fMoney_trf_all] [money] NULL,[total_Rbd] [money] NULL,[fMoney_Rbd_all] [money] NULL,[total_Loss] [money] NULL,[fMoney_Loss_all] [money] NULL,[total_out] [money] NULL,[fMoney_out_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL) 

if (select OBJECT_ID('tempdb..#FindGoodsList0'))is not null drop table #FindGoodsList0
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #FindGoodsList0
from t_goods a, #tmpCostGoodsList b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1
--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#FindGoodsList1'))is not null drop table #FindGoodsList1
select cGoodsNO
into #FindGoodsList1
from #tmpCostGoodsList
union all
select cGoodsNo_MinPackage
from #FindGoodsList0
where ISNULL(bIsPack,0)=1
union all
select b.cGoodsNo
from #FindGoodsList0 a,t_goods b
where ISNULL(a.bIsPack,0)=0
and a.cGoodsNo=b.cGoodsNo_minPackage

if (select OBJECT_ID('tempdb..#t_FindGoods'))is not null drop table #t_FindGoods
select distinct cGoodsNO,cSupNO,bStorage
into #t_FindGoods
from t_goods
where cGoodsNo in(select cgoodsno from #FindGoodsList1)

--取商品(管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
select distinct cGoodsNo,cSupNo
into #tmpPloyOfGoodsinfo
from #t_FindGoods 
where isnull(bStorage,0)=1

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='''+@cWHno+''''
insert into #temp_date exec (@SQLstr)
select @date=isnull(MaxDate,'2000-01-01') from #temp_date
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)
if(@date>=@dDateBgn-1)
	begin
		if (@date<@dDateEnd)    
			begin
					set @date1=@date+1
					set @date2=@dDateEnd
			end
		else
			begin
					set @date1=''
					set @date2=''
					set @date=@dDateEnd
			end
	end
else
	begin 
		set @date1=@date+1
		set @date2=@dDateEnd 
	end

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDateBgn,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
insert into #temp_end  ([dDateTime],[cGoodsNo],[cWHno]) select dDateTime=@dDateEnd,cGoodsNo,@cWhNo from #tmpPloyOfGoodsinfo
set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
              a.fQty_In=b.fQty_In,a.fMoney_In=b.fMoney_In,a.fQty_TfrIn=b.fQty_TfrIn,a.fMoney_TfrIn=b.fMoney_TfrIn,a.fQty_Return=b.fQty_Return,
              a.fMoney_Return=b.fMoney_Return,a.fQty_Effusion=b.fQty_Effusion,a.fMoney_Effusion=b.fMoney_Effusion,a.fQty_Divide=b.fQty_Divide,
              a.fMoney_Divide=b.fMoney_Divide,a.fQty_Pack=b.fQty_Pack,a.fMoney_Pack=b.fMoney_Pack,a.fQty_trf=b.fQty_trf,a.fMoney_trf=b.fMoney_trf,
              a.fQty_Rbd=b.fQty_Rbd,a.fMoney_Rbd=b.fMoney_Rbd,a.fQty_Loss=b.fQty_Loss,a.fMoney_Loss=b.fMoney_Loss,a.fQty_out=b.fQty_out,
              a.fMoney_out=b.fMoney_out,a.fQty_Check_Diff=b.fQty_Check_Diff,a.fQty_pd=b.fQty_pd,a.fMoney_pd=b.fMoney_pd,
				a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
				a.total_In=b.total_In,a.fMoney_In_all=b.fMoney_In_all,a.total_TfrIn=b.total_TfrIn,a.fMoney_TfrIn_all=b.fMoney_TfrIn_all,
				a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all,a.total_Effusion=b.total_Effusion,a.fMoney_Effusion_all=b.fMoney_Effusion_all,
				a.total_Divide=b.total_Divide,a.fMoney_Divide_all=b.fMoney_Divide_all,a.total_Pack=b.total_Pack,a.fMoney_Pack_all=b.fMoney_Pack_all,
				a.total_trf=b.total_trf,a.fMoney_trf_all=b.fMoney_trf_all,a.total_Rbd=b.total_Rbd,a.fMoney_Rbd_all=b.fMoney_Rbd_all,a.total_Loss=b.total_Loss,
				a.fMoney_Loss_all=b.fMoney_Loss_all,a.total_out=b.total_out,a.fMoney_out_all=b.fMoney_out_all,
				a.Ratio=b.Ratio,a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@dDateBgn-1)+''' and b.cWHno='''+@cWHno+'''
             '
set @SQLstr1=' update a
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
              a.fQty_In=b.fQty_In,a.fMoney_In=b.fMoney_In,a.fQty_TfrIn=b.fQty_TfrIn,a.fMoney_TfrIn=b.fMoney_TfrIn,a.fQty_Return=b.fQty_Return,
              a.fMoney_Return=b.fMoney_Return,a.fQty_Effusion=b.fQty_Effusion,a.fMoney_Effusion=b.fMoney_Effusion,a.fQty_Divide=b.fQty_Divide,
              a.fMoney_Divide=b.fMoney_Divide,a.fQty_Pack=b.fQty_Pack,a.fMoney_Pack=b.fMoney_Pack,a.fQty_trf=b.fQty_trf,a.fMoney_trf=b.fMoney_trf,
              a.fQty_Rbd=b.fQty_Rbd,a.fMoney_Rbd=b.fMoney_Rbd,a.fQty_Loss=b.fQty_Loss,a.fMoney_Loss=b.fMoney_Loss,a.fQty_out=b.fQty_out,
              a.fMoney_out=b.fMoney_out,a.fQty_Check_Diff=b.fQty_Check_Diff,a.fQty_pd=b.fQty_pd,a.fMoney_pd=b.fMoney_pd,
				a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
				a.total_In=b.total_In,a.fMoney_In_all=b.fMoney_In_all,a.total_TfrIn=b.total_TfrIn,a.fMoney_TfrIn_all=b.fMoney_TfrIn_all,
				a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all,a.total_Effusion=b.total_Effusion,a.fMoney_Effusion_all=b.fMoney_Effusion_all,
				a.total_Divide=b.total_Divide,a.fMoney_Divide_all=b.fMoney_Divide_all,a.total_Pack=b.total_Pack,a.fMoney_Pack_all=b.fMoney_Pack_all,
				a.total_trf=b.total_trf,a.fMoney_trf_all=b.fMoney_trf_all,a.total_Rbd=b.total_Rbd,a.fMoney_Rbd_all=b.fMoney_Rbd_all,a.total_Loss=b.total_Loss,
				a.fMoney_Loss_all=b.fMoney_Loss_all,a.total_out=b.total_out,a.fMoney_out_all=b.fMoney_out_all,
				a.Ratio=b.Ratio,a.Ratio_Money=b.Ratio_Money,a.Ratio_Money_all=b.Ratio_Money_all
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='''+@cWHno+'''
            '
exec (@SQLstr+@SQLstr1)

--以上计算期末库存

if (select OBJECT_ID('tempdb..#temp_ready'))is not null drop table #temp_ready
if (select OBJECT_ID('tempdb..#temp_ready1'))is not null drop table #temp_ready1
select 
GoodsNo_Pdt=a.cGoodsNo,cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,cGoodsTypeno=null,cGoodsTypename=null,
bProducted=null,cProductNo=null,cSupplierNo=null,cSupName=null,BeginDate=@dDateBgn,BeginQty=isnull(b.fQuantity,0),EndDate=@dDateEnd,
EndQty=isnull(a.fQuantity,0),
rkQty=isnull(a.total_In,0)-isnull(b.total_In,0),thrkQty=isnull(a.total_Return,0)-isnull(b.total_Return,0),
ckQty=-(isnull(a.total_out,0)-isnull(b.total_out,0)),fcQty=-(isnull(a.total_Rbd,0)-isnull(b.total_Rbd,0)),
dbQty=-(isnull(a.total_trf,0)-isnull(b.total_trf,0)),bsQty=(isnull(a.total_Loss,0)-isnull(b.total_Loss,0)),
byQty=isnull(a.total_Effusion,0)-isnull(b.total_Effusion,0),djQty=isnull(0,0),
xsQty=-(isnull(a.total_Sale0,0)-isnull(b.total_Sale0,0)+isnull(a.total_Sale1,0)-isnull(b.total_Sale1,0)),
ylckQty=-(isnull(a.total_Divide,0)-isnull(b.total_Divide,0)),cprkQty=isnull(a.total_Pack,0)-isnull(b.total_Pack,0),
dbrkQty=isnull(a.total_TfrIn,0)-isnull(b.total_TfrIn,0),
fCKPrice=CAST(0 as money),fNormalPrice=CAST(0 as money),avgInPrice=isnull(a.fPrice_Avg,0),
fCKPriceMoney=CAST(0 as money),
fNormalPriceMoney=CAST(0 as money),avgInPriceMoney=CAST(0 as money),
fEndQuantity_Diff=
(isnull(a.total_In,0)+isnull(a.total_Return,0)+isnull(a.total_out,0)+isnull(a.total_Rbd,0)+isnull(a.total_trf,0)+
 isnull(a.total_Loss,0)+isnull(a.total_Effusion,0)+isnull(a.total_Sale0,0)+isnull(a.total_Sale1,0)+ 
 isnull(a.total_Divide,0)+isnull(a.total_Pack,0)+isnull(a.total_TfrIn,0)-isnull(a.fQuantity,0)
)-(
  isnull(b.total_In,0)+isnull(b.total_Return,0)+isnull(b.total_out,0)+isnull(b.total_Rbd,0)+isnull(b.total_trf,0)+
  isnull(b.total_Loss,0)+isnull(b.total_Effusion,0)+isnull(b.total_Sale0,0)+isnull(b.total_Sale1,0)+
  isnull(b.total_Divide,0)+isnull(b.total_Pack,0)+isnull(b.total_TfrIn,0)-isnull(b.fQuantity,0)
)
into #temp_ready
from #temp_end a left join #temp_begin b 
on a.cGoodsNo=b.cGoodsNo


---包装转单品
if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
into #tmpPackGoodsList
from t_goods
where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

update a
set a.GoodsNo_Pdt=b.cGoodsNO_minPackage,
    a.BeginQty=a.BeginQty*b.fQty_minPackage,
    a.EndQty=a.EndQty*b.fQty_minPackage,
    a.rkQty=a.rkQty*b.fQty_minPackage,
    a.thrkQty=thrkQty*b.fQty_minPackage,
    a.ckQty=ckQty*b.fQty_minPackage,
    a.fcQty=fcQty*b.fQty_minPackage,
	a.dbQty=a.dbQty*b.fQty_minPackage,
	a.bsQty=a.bsQty*b.fQty_minPackage,
	a.byQty=a.byQty*b.fQty_minPackage,
	a.xsQty=a.xsQty*b.fQty_minPackage,
	a.ylckQty=a.ylckQty*b.fQty_minPackage,
	a.cprkQty=a.cprkQty*b.fQty_minPackage,
	a.dbrkQty=a.dbrkQty*b.fQty_minPackage,
	a.fEndQuantity_Diff=a.fEndQuantity_Diff*b.fQty_minPackage
from #temp_ready a,#tmpPackGoodsList b
where a.GoodsNo_Pdt=b.cGoodsNo

if (select OBJECT_ID('tempdb..#temp_readyFor1'))is not null drop table #temp_readyFor1
select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,BeginDate,
BeginQty=SUM(BeginQty),EndDate,EndQty=SUM(EndQty),rkQty=SUM(rkQty),thrkQty=SUM(thrkQty),ckQty=SUM(ckQty),fcQty=SUM(fcQty),
dbQty=SUM(dbQty),bsQty=SUM(bsQty),byQty=SUM(byQty),djQty=SUM(djQty),xsQty=SUM(xsQty),ylckQty=SUM(ylckQty),cprkQty=SUM(cprkQty),dbrkQty=SUM(dbrkQty),
fCKPrice,fNormalPrice,avgInPrice,fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
fEndQuantity_Diff=SUM(fEndQuantity_Diff) 
into #temp_readyFor1
from #temp_ready
group by GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,BeginDate,
EndDate,fCKPrice,fNormalPrice,avgInPrice,fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney

--select * from #temp_ready
select GoodsNo_Pdt=a.cGoodsNo,cUnitedNo=b.cUnitedNo,cGoodsName=b.cGoodsName,cBarcode=b.cBarcode,cUnit=b.cUnit,cSpec=b.cSpec,
cGoodsTypeno=b.cGoodsTypeno,cGoodsTypename=b.cGoodsTypename,bProducted=b.bProducted,cProductNo=b.cProductNo,cSupplierNo=b.cSupNo,
cSupName=b.cSupName,BeginDate,BeginQty,EndDate,EndQty,rkQty,thrkQty,ckQty,fcQty,dbQty,bsQty,byQty,djQty,xsQty,ylckQty,cprkQty,
dbrkQty,fCKPrice=b.fCKPrice,fNormalPrice=b.fNormalPrice,avgInPrice,
fCKPriceMoney=EndQty*ISNULL(b.fCKPrice,0),fNormalPriceMoney=EndQty*ISNULL(b.fNormalPrice,0),avgInPriceMoney=EndQty*ISNULL(c.avgInPrice,0),
fEndQuantity_Diff 
into #temp_ready1
from #tmpPloyOfGoodsinfo a left join #temp_readyFor1 c on c.GoodsNo_Pdt=a.cGoodsNo
,t_goods b 
where a.cGoodsNo=b.cGoodsNo
/*
select * from #tmpPloyOfGoodsinfo
select * from #temp_readyFor1
select * from #temp_ready
select * from #temp_ready1
*/
if(@date>=@date2)
begin
if(select object_id('tempdb..#temp_SaledateBaseForKuCun')) is not null 
begin 
		insert into #temp_SaledateBaseForKuCun
		(cGoodsNo,cGoodsTypeno,EndQty,XsQty)
		select GoodsNo_Pdt,cGoodsTypeno,EndQty=isnull(EndQty,0),XsQty=isnull(XsQty,0)
		from #temp_ready1 
end


end
if (@date<@dDateEnd )    
begin
--盘点信息
	-------期末前最新盘点日期-----------------------------------------------------
	if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
	select a.cGoodsNo,dDate=MAX(b.dDate)
	into #templast_pd0
	from wh_CheckWhDetail a left join wh_CheckWh b
	on a.cSheetno=b.cSheetno 
	where dDate between @date1 and @date2 
	and isnull(bExamin,0)=1 
	and b.cWhNo=@cWHno  
	and a.cGoodsNo in (select distinct cGoodsNo from #tmpPloyOfGoodsinfo)
	group by a.cGoodsNo order by a.cGoodsNo
	--select * from #templast_pd0
	-------期末前最新盘点日期+数量------------------------------------------------
	if(select object_id('tempdb..#templast_pd_num0')) is not null drop table #templast_pd_num0
	select a.cGoodsNO,a.dDate,fQuantity=sum(isnull(b.fQuantity,0)),fMoney=sum(isnull(b.fMoney,0))---wh_CheckWhDetail.fMoney在盘点单中为空，应该从成本分配表中取
	into #templast_pd_num0
	from #templast_pd0 a,
	(
		select x.cGoodsNO,x.fQuantity,x.fMoney,y.dDate
		from wh_CheckWhDetail x,wh_CheckWh y
		where x.cSheetno=y.cSheetno and y.cWhNo=@cWHno
	) b
	where a.dDate=b.dDate and a.cGoodsNo=b.cGoodsNo
	group by  a.cGoodsNO,a.dDate

	---日期、数量组合一起
	if(select object_id('tempdb..#templast_pd')) is not null drop table #templast_pd
	select a.*,fQuantity=isnull(b.fQuantity,0),dDateEnd=@date2,b.fMoney
	into #templast_pd
	from #templast_pd0 a left join #templast_pd_num0 b 
	on a.cGoodsNo=b.cGoodsNo and a.dDate=b.dDate

    declare @dMaxDailyDate datetime
    set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1
   -- if (@dMaxDailyDate-1)>=@date2 set @dMaxDailyDate=@date2+1

---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
--print  '01 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
/*	已日结商品t_SaleSheet_Day中取，未日结商品t_SaleSheetDetail中取*/

    -----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    
 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))


	 
	exec p_x_salesABC_bySupplier_chen_WH_Ref @date1,@date2,@dMaxDailyDate,@cWHno
----------------**************************--------------------	 
	
 		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,
		---t_SaleSheet_Day b 
		#temp_SaleSheet_Day b
		where b.dSaleDate between @date1 and @date2
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo
		union all
		select dSaleDate=isnull(b.dSaleDate,@date2),cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		--from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b
		from #tmpPloyOfGoodsinfo a,#temp_salesheetDetail b
		where b.dSaleDate between @dMaxDailyDate and @date2 
		      and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo

--print  '02 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		
		----正价销售iAttribute=20,特价21
		select dDateTime=b.dSaleDate,a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo
--select * from #temp_jiesuan_for_day

--print  '03 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' '+datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
--select * from #GoodsCurStorageList

		--入库单统计开始 select * from wh_InWarehouse
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno
		where c.dDate between @date1 and @date2  and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

	    union all
		select @date2,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
/*			select * from #GoodsCurStorageList where cGoodsNo='15525'
*/
--print  '04 '+datename(yyyy, getdate())+'-'+datename(mm, getdate())+'-'+datename(dd, getdate())+' ' +datename(hh, getdate())+':'+datename(n, getdate())+':'+datename(ss, getdate())
		--以上计算期末库存
/*---包装转单品*/
		--if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
		--select cGoodsNo,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
		--into #tmpPackGoodsList
		--from t_goods
		--where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money),
		cGoodsName=cast(null as varchar(64)),cUnitedNo=cast(null as varchar(32)),
		cBarcode=cast(null as varchar(32)),cUnit=cast(null as varchar(32)),
		cSpec=cast(null as varchar(32)),fNormalPrice=cast(null as money),
		cGoodsTypeno=cast(null as varchar(32)),cGoodsTypename=cast(null as varchar(100)),
		cSupName=cast(null as varchar(100)),
		BeginDate=cast(null as datetime),EndDate=cast(null as datetime),
		rkQty=cast(0 as money),thrkQty=cast(0 as money),
		ckQty=cast(0 as money),fcQty=cast(0 as money),dbQty=cast(0 as money),
		bsQty=cast(0 as money),byQty=cast(0 as money),djQty=cast(0 as money),
		xsQty=cast(0 as money),ylckQty=cast(0 as money),cprkQty=cast(0 as money),
		dbrkQty=cast(0 as money),fCKPrice=cast(0 as money),avgInPrice=cast(0 as money),
		fCKPriceMoney=cast(0 as money),fNormalPriceMoney=cast(0 as money),
		avgInPriceMoney=cast(0 as money),fEndQuantity_Diff=cast(0 as money)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by cGoodsNo,cWhNo

		update a
		set a.cSupNo=b.cSupNo
		from #GoodsCurStorageList a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(a.cSupNo,'-')='-'

		update a
		set a.cGoodsName=b.cGoodsName,a.cUnitedNo=b.cUnitedNo,a.cBarcode=b.cBarcode,a.cSupplierNo=b.cSupNo,
		a.cUnit=b.cUnit,a.cSpec=b.cSpec,a.fNormalPrice=b.fNormalPrice,
		a.cGoodsTypeno=b.cGoodsTypeno,
		a.cGoodsTypename=b.cGoodsTypename,a.EndDate=@date2,a.fCKPrice=b.fCKPrice
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo 

		update a
		set a.cSupName=b.cSupName
		from #tmpGoodsListInfo_1 a,t_supplier b
		where a.cSupplierNo=b.cSupNo

--end
/*
select * from #GoodsCurStorageList where iAttribute<>9999

select cGOodsNO,fQuantity=sum(fQuantity),iAttribute,fMoney=sum(fMoney) 
from #GoodsCurStorageList 
where iAttribute<>9999
group by cGoodsNo,iAttribute
order by cGoodsNo
*/
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 
		
		--更新期初库存
		update a
		set a.BeginQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
		  select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime <@dDateBgn
			group by cGoodsNo
		  
		)b
		where a.cGoodsNo=b.cGoodsNo
		
		--更新入库数量
		update a
		set a.rkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=0
			group by cGoodsNo,cWhNo,cSupNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		--更新客退数量
		update a
		set a.thrkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=3
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		--更新出库数量
		update a
		set a.ckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=1
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新返厂数量
		update a
		set a.fcQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=2
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新调拨数量
		update a
		set a.dbQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDateBgn and @date2 and (iAttribute=41 or iAttribute=40)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报损数量
		update a
		set a.bsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=5
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新报溢数量
		update a
		set a.byQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=6
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新销售数量
		update a
		set a.xsQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
				select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
				from #GoodsCurStorageList
				where dDateTime between @dDateBgn and @date2 and (iAttribute=20 or iAttribute=21)
				group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新原料出库数量
		update a
		set a.ylckQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=-sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=8
			group by cGoodsNo

		)b
		where a.cGoodsNo=b.cGoodsNo

		--更新成品入库数量
		update a
		set a.cprkQty=b.fQty
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			where dDateTime between @dDateBgn and @date2 and iAttribute=9
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo

--计算最新成本
        update a
	    set a.fMoney=a.fQuantity*b.fPrice_Avg
	    from #GoodsCurStorageList a,#temp_end b
	    where a.cGoodsNo=b.cGoodsNo

		update a
		set a.fMoney=ISNULL(a.fQuantity,0)*ISNULL(b.fCKPrice,0)
		from #GoodsCurStorageList a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and a.fMoney is null

		--平均进价
		if (select OBJECT_ID('tempdb..#tmpAvgCost'))is not null drop table #tmpAvgCost
		select cGoodsNo,cWhNo,avgCost=avg(fPrice_in)
		into #tmpAvgCost
		from t_wh_form
		where dDateTime <=@date2 and iAttribute=0
		group by cGoodsNo,cWhNo

		update a
		set a.avginPrice=b.avgCost
		from #tmpGoodsListInfo_1 a,#tmpAvgCost b
		where a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo

		update a
		set a.avginPrice=b.fckPrice
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(a.avginPrice,0)=0
		
		
if(@date<@dDateBgn-1)
	Begin
	    update a
		set a.BeginQty=ISNULL(a.BeginQty,0)+isnull(b.EndQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0),
		a.fEndQuantity_Diff=isnull(b.fEndQuantity_Diff,0)
		from #tmpGoodsListInfo_1 a,#temp_ready1 b
		where a.cGoodsNo=b.GoodsNo_Pdt 
				
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
			from (
				   select cGoodsNo,fQuantity from #templast_pd 
				   union all 
				   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
				   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
				 ) x
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		update #tmpGoodsListInfo_1
		set cWHno=@cWhNo,BeginDate=@dDateBgn,EndDate=@dDateEnd,BeginQty=ISNULL(BeginQty,0),
		    EndQty=isnull(EndQty,0),
		    fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
		
		update a
		set a.cGoodsName=b.cGoodsName,a.cUnitedNo=b.cUnitedNo,a.cBarcode=b.cBarcode,
		    a.cUnit=b.cUnit,a.cSpec=b.cSpec,
		    a.fNormalPrice=b.fNormalPrice,a.cGoodsTypeno=b.cGoodsTypeno,
		    a.cGoodsTypename=b.cGoodsName 
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and a.cGoodsName is null
	end
		else
			Begin
			  update a
				set a.BeginQty=ISNULL(a.BeginQty,0)+isnull(b.BeginQty,0),a.EndQty=isnull(a.EndQty,0)+isnull(b.EndQty,0),
				a.rkQty=isnull(a.rkQty,0)+isnull(b.rkQty,0),a.thrkQty=isnull(a.thrkQty,0)+isnull(b.thrkQty,0),a.ckQty=isnull(a.ckQty,0)+isnull(b.ckQty,0),
				a.fcQty=isnull(a.fcQty,0)+isnull(b.fcQty,0),a.dbQty=isnull(a.dbQty,0)+isnull(b.dbQty,0),a.bsQty=isnull(a.bsQty,0)+isnull(b.bsQty,0),
				a.byQty=isnull(a.byQty,0)+isnull(b.byQty,0),a.djQty=isnull(a.djQty,0)+isnull(b.djQty,0),a.xsQty=isnull(a.xsQty,0)+isnull(b.xsQty,0),
				a.ylckQty=isnull(a.ylckQty,0)+isnull(b.ylckQty,0),a.cprkQty=isnull(a.cprkQty,0)+isnull(b.cprkQty,0),a.dbrkQty=isnull(a.dbrkQty,0)+isnull(b.dbrkQty,0),
				a.avgInPrice=isnull(b.avgInPrice,0),a.fEndQuantity_Diff=isnull(a.fEndQuantity_Diff,0)+isnull(b.fEndQuantity_Diff,0)
				from #tmpGoodsListInfo_1 a,#temp_ready1 b
				where a.cGoodsNo=b.GoodsNo_Pdt 
				
						update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select x.cGoodsNo,fqty=sum(isnull(x.fQuantity,0))
			from (
				   select cGoodsNo,fQuantity from #templast_pd 
				   union all 
				   select a.cGoodsNo,a.fQuantity from #GoodsCurStorageList a,#templast_pd b
				   where a.cGoodsNo=b.cGoodsNo and a.dDateTime>b.dDate
				 ) x
			group by cGoodsNo
		)b
		where a.cGoodsNo=b.cGoodsNo 

		update #tmpGoodsListInfo_1
		set cWHno=@cWhNo,BeginDate=@dDateBgn,EndDate=@dDateEnd,BeginQty=ISNULL(BeginQty,0),
		    EndQty=isnull(EndQty,0),
		    fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
		
		update a
		set a.cGoodsName=b.cGoodsName,a.cUnitedNo=b.cUnitedNo,a.cBarcode=b.cBarcode,
		    a.cUnit=b.cUnit,a.cSpec=b.cSpec,
		    a.fNormalPrice=b.fNormalPrice,a.cGoodsTypeno=b.cGoodsTypeno,
		    a.cGoodsTypename=b.cGoodsName 
		from #tmpGoodsListInfo_1 a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and a.cGoodsName is null
			end
	
			update #tmpGoodsListInfo_1
			set fCkPriceMoney=isnull(EndQty,0)*isnull(fCkPrice,0),
				fNormalPriceMoney=isnull(EndQty,0)*isnull(fNormalPrice,0),
				avgInPriceMoney=isnull(EndQty,0)*isnull(avginPrice,0)
/*
select sum(beginqty),sum(endqty) from #tmpGoodsListInfo_1
*/
			

if(select object_id('tempdb..#temp_SaledateBaseForKuCun')) is not null 
begin 
		insert into #temp_SaledateBaseForKuCun
		(cGoodsNo,cGoodsTypeno,EndQty,XsQty)
		select cGoodsNo,cGoodsTypeno,EndQty=isnull(EndQty,0),XsQty=isnull(XsQty,0)
		from #tmpGoodsListInfo_1 
end

end
GO
