/*
select cGoodsNo into #temp_Goods from t_Goods
p_x_salesABC_byGoodsTypeGroup_WH_MainGoodsType '2011-12-17','2012-01-02',0,0,'01'

p_x_salesABC_byGoodsTypeGroup_WH '2011-12-15','2012-01-02',0,0,'01'
*/

create procedure [dbo].[p_x_salesABC_byGoodsTypeGroup_WH_MainGoodsType]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit,
@cWHno varchar(32)
as
begin
  select cGoodsNo into #t_Goods from #temp_Goods     --#temp_Goods 在delphi程序中已创建的临时表  
  
  declare @dMaxDailyDate datetime
  set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)  
  set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)  
  declare @dBeginDate_detail datetime
  set @dBeginDate_detail=case when @dMaxDailyDate>=@dBeginDate then @dMaxDailyDate+1 else  @dBeginDate end
  
--                销售单                 开始    
  select a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing,
         h0=0, h1=0, h2=0, h3=0, h4=0, h5=0, h6=0, h7=0, h8=0, h9=0, h10=0,h11=0,
         h12=0,h13=0,h14=0,h15=0,h16=0,h17=0,h18=0,h19=0,h20=0,h21=0,h22=0,h23=0,
         h0_q=0, h1_q=0, h2_q=0, h3_q=0, h4_q=0, h5_q=0, h6_q=0, h7_q=0, h8_q=0, h9_q=0, h10_q=0,h11_q=0,
         h12_q=0,h13_q=0,h14_q=0,h15_q=0,h16_q=0,h17_q=0,h18_q=0,h19_q=0,h20_q=0,h21_q=0,h22_q=0,h23_q=0
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      ,t_SaleSheetDetail b
        where a.cGoodsNo=b.cGoodsNo 
       and  (b.dSaleDate between @dBeginDate_detail and @dEndDate)
       and isnull(tag_daily,0)=0 and b.cWHno=@cWHno 
  union all
  select a.cGoodsNo,b.fQuantity,b.fLastSettle,b.bAuditing,
         b.h0, b.h1, b.h2, b.h3, b.h4, b.h5, b.h6, b.h7, b.h8, b.h9, b.h10,b.h11,
         b.h12,b.h13,b.h14,b.h15,b.h16,b.h17,b.h18,b.h19,b.h20,b.h21,b.h22,b.h23,
         b.h0_q, b.h1_q, b.h2_q, b.h3_q, b.h4_q, b.h5_q, b.h6_q, b.h7_q, b.h8_q, b.h9_q, b.h10_q,b.h11_q,
         b.h12_q,b.h13_q,b.h14_q,b.h15_q,b.h16_q,b.h17_q,b.h18_q,b.h19_q,b.h20_q,b.h21_q,b.h22_q,b.h23_q
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       t_SaleSheet_Day b
         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @dBeginDate and @dEndDate) and b.cWHno=@cWHno 
  union all
  select a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0',
         h0=0, h1=0, h2=0, h3=0, h4=0, h5=0, h6=0, h7=0, h8=0, h9=0, h10=0,h11=0,
         h12=0,h13=0,h14=0,h15=0,h16=0,h17=0,h18=0,h19=0,h20=0,h21=0,h22=0,h23=0,
         h0_q=0, h1_q=0, h2_q=0, h3_q=0, h4_q=0, h5_q=0, h6_q=0, h7_q=0, h8_q=0, h9_q=0, h10_q=0,h11_q=0,
         h12_q=0,h13_q=0,h14_q=0,h15_q=0,h16_q=0,h17_q=0,h18_q=0,h19_q=0,h20_q=0,h21_q=0,h22_q=0,h23_q=0
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c
         where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dBeginDate and @dEndDate)
          and c.cWHno=@cWHno 

  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney,bAuditing,
         case when (isnull(bAuditing,0)=0)
              then '正价' 
              else '特价' 
         end as Auditing,
         sum(isnull(h0,0)) as h0,   sum(isnull(h1,0)) as h1,   sum(isnull(h2,0)) as h2, 
         sum(isnull(h3,0)) as h3,   sum(isnull(h4,0)) as h4,   sum(isnull(h5,0)) as h5,
         sum(isnull(h6,0)) as h6,   sum(isnull(h7,0)) as h7,   sum(isnull(h8,0)) as h8,
         sum(isnull(h9,0)) as h9,   sum(isnull(h10,0)) as h10, sum(isnull(h11,0)) as h11,
         sum(isnull(h12,0)) as h12, sum(isnull(h13,0)) as h13, sum(isnull(h14,0)) as h14,
         sum(isnull(h15,0)) as h15, sum(isnull(h16,0)) as h16, sum(isnull(h17,0)) as h17,
         sum(isnull(h18,0)) as h18, sum(isnull(h19,0)) as h19,sum(isnull(h20,0)) as h20, 
         sum(isnull(h21,0)) as h21, sum(isnull(h22,0)) as h22,sum(isnull(h23,0)) as h23,
         sum(isnull(h0_q,0)) as h0_q,   sum(isnull(h1_q,0)) as h1_q,   sum(isnull(h2_q,0)) as h2_q, 
         sum(isnull(h3_q,0)) as h3_q,   sum(isnull(h4_q,0)) as h4_q,   sum(isnull(h5_q,0)) as h5_q,
         sum(isnull(h6_q,0)) as h6_q,   sum(isnull(h7_q,0)) as h7_q,   sum(isnull(h8_q,0)) as h8_q,
         sum(isnull(h9_q,0)) as h9_q,   sum(isnull(h10_q,0)) as h10_q, sum(isnull(h11_q,0)) as h11_q,
         sum(isnull(h12_q,0)) as h12_q, sum(isnull(h13_q,0)) as h13_q, sum(isnull(h14_q,0)) as h14_q,
         sum(isnull(h15_q,0)) as h15_q, sum(isnull(h16_q,0)) as h16_q, sum(isnull(h17_q,0)) as h17_q,
         sum(isnull(h18_q,0)) as h18_q, sum(isnull(h19_q,0)) as h19_q,sum(isnull(h20_q,0)) as h20_q, 
         sum(isnull(h21_q,0)) as h21_q, sum(isnull(h22_q,0)) as h22_q,sum(isnull(h23_q,0)) as h23_q
  into #t_SaleSheetDetail1  --销售单
  from #t_SaleSheetDetail_shelf
  group by cGoodsNo,bAuditing
--               销售单                 结束 

--合并  开始
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,m.Auditing,
                  m.h0, m.h1, m.h2, m.h3, m.h4, m.h5, m.h6, m.h7, m.h8, m.h9, m.h10,m.h11,
                  m.h12,m.h13,m.h14,m.h15,m.h16,m.h17,m.h18,m.h19,m.h20,m.h21,m.h22,m.h23,
                  m.h0_q, m.h1_q, m.h2_q, m.h3_q, m.h4_q, m.h5_q, m.h6_q, m.h7_q, m.h8_q, m.h9_q, m.h10_q,m.h11_q,
                  m.h12_q,m.h13_q,m.h14_q,m.h15_q,m.h16_q,m.h17_q,m.h18_q,m.h19_q,m.h20_q,m.h21_q,m.h22_q,m.h23_q,
                  xsQty=m.qty,xsMoney=m.fLastMoney,
                  cPath_main=SUBSTRING(cPath,1,patindex('%.%',SUBSTRING(cPath,4,1028))+2) 
      into #temp_goodsKuCun1_NoZero from #t_Goods a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , t_GoodsType s 
                             , #t_SaleSheetDetail1 m --on a.cGoodsNo=m.cGoodsNo
                             where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=m.cGoodsNo  and s.cGoodsTypeno=b.cGoodsTypeno
--合并  结束

		  select GoodsNo_Pdt='共计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cPath_main,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,Auditing,
             h0=sum(isnull(h0,0)),  h1=sum(isnull(h1,0)),  h2=sum(isnull(h2,0)),   h3=sum(isnull(h3,0)), 
             h4=sum(isnull(h4,0)),  h5=sum(isnull(h5,0)),  h6=sum(isnull(h6,0)),   h7=sum(isnull(h7,0)), 
             h8=sum(isnull(h8,0)),  h9=sum(isnull(h9,0)),  h10=sum(isnull(h10,0)), h11=sum(isnull(h11,0)),
             h12=sum(isnull(h12,0)),h13=sum(isnull(h13,0)),h14=sum(isnull(h14,0)), h15=sum(isnull(h15,0)),
             h16=sum(isnull(h16,0)),h17=sum(isnull(h17,0)),h18=sum(isnull(h18,0)), h19=sum(isnull(h19,0)),
             h20=sum(isnull(h20,0)),h21=sum(isnull(h21,0)),h22=sum(isnull(h22,0)), h23=sum(isnull(h23,0)),
             h0_q=sum(isnull(h0_q,0)),  h1_q=sum(isnull(h1_q,0)),  h2_q=sum(isnull(h2_q,0)),   h3_q=sum(isnull(h3_q,0)), 
             h4_q=sum(isnull(h4_q,0)),  h5_q=sum(isnull(h5_q,0)),  h6_q=sum(isnull(h6_q,0)),   h7_q=sum(isnull(h7_q,0)), 
             h8_q=sum(isnull(h8_q,0)),  h9_q=sum(isnull(h9_q,0)),  h10_q=sum(isnull(h10_q,0)), h11_q=sum(isnull(h11_q,0)),
             h12_q=sum(isnull(h12_q,0)),h13_q=sum(isnull(h13_q,0)),h14_q=sum(isnull(h14_q,0)), h15_q=sum(isnull(h15_q,0)),
             h16_q=sum(isnull(h16_q,0)),h17_q=sum(isnull(h17_q,0)),h18_q=sum(isnull(h18_q,0)), h19_q=sum(isnull(h19_q,0)),
             h20_q=sum(isnull(h20_q,0)),h21_q=sum(isnull(h21_q,0)),h22_q=sum(isnull(h22_q,0)), h23_q=sum(isnull(h23_q,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  into #temp_goodsKuCun1_NoZero_result
		  from #temp_goodsKuCun1_NoZero 
		  group by cPath_main,Auditing,BeginDate,EndDate
		  
		  
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cPath_main,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,Auditing='正特价',
             h0=sum(isnull(h0,0)),  h1=sum(isnull(h1,0)),  h2=sum(isnull(h2,0)),   h3=sum(isnull(h3,0)), 
             h4=sum(isnull(h4,0)),  h5=sum(isnull(h5,0)),  h6=sum(isnull(h6,0)),   h7=sum(isnull(h7,0)), 
             h8=sum(isnull(h8,0)),  h9=sum(isnull(h9,0)),  h10=sum(isnull(h10,0)), h11=sum(isnull(h11,0)),
             h12=sum(isnull(h12,0)),h13=sum(isnull(h13,0)),h14=sum(isnull(h14,0)), h15=sum(isnull(h15,0)),
             h16=sum(isnull(h16,0)),h17=sum(isnull(h17,0)),h18=sum(isnull(h18,0)), h19=sum(isnull(h19,0)),
             h20=sum(isnull(h20,0)),h21=sum(isnull(h21,0)),h22=sum(isnull(h22,0)), h23=sum(isnull(h23,0)),
             h0_q=sum(isnull(h0_q,0)),  h1_q=sum(isnull(h1_q,0)),  h2_q=sum(isnull(h2_q,0)),   h3_q=sum(isnull(h3_q,0)), 
             h4_q=sum(isnull(h4_q,0)),  h5_q=sum(isnull(h5_q,0)),  h6_q=sum(isnull(h6_q,0)),   h7_q=sum(isnull(h7_q,0)), 
             h8_q=sum(isnull(h8_q,0)),  h9_q=sum(isnull(h9_q,0)),  h10_q=sum(isnull(h10_q,0)), h11_q=sum(isnull(h11_q,0)),
             h12_q=sum(isnull(h12_q,0)),h13_q=sum(isnull(h13_q,0)),h14_q=sum(isnull(h14_q,0)), h15_q=sum(isnull(h15_q,0)),
             h16_q=sum(isnull(h16_q,0)),h17_q=sum(isnull(h17_q,0)),h18_q=sum(isnull(h18_q,0)), h19_q=sum(isnull(h19_q,0)),
             h20_q=sum(isnull(h20_q,0)),h21_q=sum(isnull(h21_q,0)),h22_q=sum(isnull(h22_q,0)), h23_q=sum(isnull(h23_q,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1_NoZero
		  group by cPath_main,BeginDate,EndDate
      union all
      select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cPath_main=null,cProductNo=null,
		         BeginDate,EndDate,Auditing=null,
             h0=sum(isnull(h0,0)),  h1=sum(isnull(h1,0)),  h2=sum(isnull(h2,0)),   h3=sum(isnull(h3,0)), 
             h4=sum(isnull(h4,0)),  h5=sum(isnull(h5,0)),  h6=sum(isnull(h6,0)),   h7=sum(isnull(h7,0)), 
             h8=sum(isnull(h8,0)),  h9=sum(isnull(h9,0)),  h10=sum(isnull(h10,0)), h11=sum(isnull(h11,0)),
             h12=sum(isnull(h12,0)),h13=sum(isnull(h13,0)),h14=sum(isnull(h14,0)), h15=sum(isnull(h15,0)),
             h16=sum(isnull(h16,0)),h17=sum(isnull(h17,0)),h18=sum(isnull(h18,0)), h19=sum(isnull(h19,0)),
             h20=sum(isnull(h20,0)),h21=sum(isnull(h21,0)),h22=sum(isnull(h22,0)), h23=sum(isnull(h23,0)),
             h0_q=sum(isnull(h0_q,0)),  h1_q=sum(isnull(h1_q,0)),  h2_q=sum(isnull(h2_q,0)),   h3_q=sum(isnull(h3_q,0)), 
             h4_q=sum(isnull(h4_q,0)),  h5_q=sum(isnull(h5_q,0)),  h6_q=sum(isnull(h6_q,0)),   h7_q=sum(isnull(h7_q,0)), 
             h8_q=sum(isnull(h8_q,0)),  h9_q=sum(isnull(h9_q,0)),  h10_q=sum(isnull(h10_q,0)), h11_q=sum(isnull(h11_q,0)),
             h12_q=sum(isnull(h12_q,0)),h13_q=sum(isnull(h13_q,0)),h14_q=sum(isnull(h14_q,0)), h15_q=sum(isnull(h15_q,0)),
             h16_q=sum(isnull(h16_q,0)),h17_q=sum(isnull(h17_q,0)),h18_q=sum(isnull(h18_q,0)), h19_q=sum(isnull(h19_q,0)),
             h20_q=sum(isnull(h20_q,0)),h21_q=sum(isnull(h21_q,0)),h22_q=sum(isnull(h22_q,0)), h23_q=sum(isnull(h23_q,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))
		  from #temp_goodsKuCun1_NoZero
		  group by BeginDate,EndDate

		  
		  select a.*,b.cGoodsTypeno,b.cGoodsTypename
		  from #temp_goodsKuCun1_NoZero_result a left join t_GoodsType b
		  on a.cPath_main=b.cPath
		  order by cGoodsTypeno,Auditing,GoodsNo_Pdt
end


GO
