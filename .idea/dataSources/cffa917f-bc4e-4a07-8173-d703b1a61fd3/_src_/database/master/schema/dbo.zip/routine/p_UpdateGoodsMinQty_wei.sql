create proc p_UpdateGoodsMinQty_wei
@PosWhName varchar(32),
@fQty_min money,
@cGoodsNo_min varchar(32),
@cGoodsNO varchar(32),
@fHeTRatio money,
@fRatio money
as
   
  exec('       
		update '+@PosWhName+'.dbo.t_WH_Form_log
		set fPrice_in=fPrice_in/'+@fQty_min+',fQty_in=fQty_in*'+@fQty_min+',
			fPrice_out=fPrice_out/'+@fQty_min+',fQty_Out=fQty_Out*'+@fQty_min+',
			fPrice_Left=fPrice_Left/'+@fQty_min+',fQty_Left= fQty_Left*'+@fQty_min+',
			cGoodsNo='+@cGoodsNo_min+',
			入库数量1=入库数量1*'+@fQty_min+',报溢数量1=报溢数量1*'+@fQty_min+',
			退货入库数量1=退货入库数量1*'+@fQty_min+',调拨入库数量1=调拨入库数量1*'+@fQty_min+',
			出库数量0=出库数量0*'+@fQty_min+',报损数量0=报损数量0*'+@fQty_min+',
			返厂数量0=返厂数量0*'+@fQty_min+',调拨出库数量0=调拨出库数量0*'+@fQty_min+',
			差价数量=差价数量*'+@fQty_min+',原料出库数量0=原料出库数量0*'+@fQty_min+',
			成品入库数量1=成品入库数量1*'+@fQty_min+',
			销售数量0=销售数量0*'+@fQty_min+',特价销售数量=特价销售数量*'+@fQty_min+',
			正价销售数量=正价销售数量*'+@fQty_min+',
			本日库存数量=本日库存数量*'+@fQty_min+',
			盘点数量=盘点数量*'+@fQty_min+',盘点单价=盘点单价/'+@fQty_min+',
			当日特价销售数量=当日特价销售数量*'+@fQty_min+',
			当日正价销售数量=当日正价销售数量*'+@fQty_min+',
			合同扣率='+@fHeTRatio+',
		    单品扣率='+@fRatio+',
		    特价扣率=0
		where cGoodsNO='''+@cGoodsNO+'''
		
		
		update '+@PosWhName+'.dbo.t_WH_Form_log_0
		set fPrice_in=fPrice_in/'+@fQty_min+',fQty_in=fQty_in*'+@fQty_min+',
			fPrice_out=fPrice_out/'+@fQty_min+',fQty_Out=fQty_Out*'+@fQty_min+',
			fPrice_Left=fPrice_Left/'+@fQty_min+',fQty_Left= fQty_Left*'+@fQty_min+',
			cGoodsNo='+@cGoodsNo_min+',
			入库数量1=入库数量1*'+@fQty_min+',报溢数量1=报溢数量1*'+@fQty_min+',
			退货入库数量1=退货入库数量1*'+@fQty_min+',调拨入库数量1=调拨入库数量1*'+@fQty_min+',
			出库数量0=出库数量0*'+@fQty_min+',报损数量0=报损数量0*'+@fQty_min+',
			返厂数量0=返厂数量0*'+@fQty_min+',调拨出库数量0=调拨出库数量0*'+@fQty_min+',
			差价数量=差价数量*'+@fQty_min+',原料出库数量0=原料出库数量0*'+@fQty_min+',
			成品入库数量1=成品入库数量1*'+@fQty_min+',
			销售数量0=销售数量0*'+@fQty_min+',特价销售数量=特价销售数量*'+@fQty_min+',
			正价销售数量=正价销售数量*'+@fQty_min+',
			本日库存数量=本日库存数量*'+@fQty_min+',
			盘点数量=盘点数量*'+@fQty_min+',盘点单价=盘点单价/'+@fQty_min+',
			当日特价销售数量=当日特价销售数量*'+@fQty_min+',
			当日正价销售数量=当日正价销售数量*'+@fQty_min+',
			合同扣率='+@fHeTRatio+',
		    单品扣率='+@fRatio+',
		    特价扣率=0
		where cGoodsNO='''+@cGoodsNO+'''
		')
GO
