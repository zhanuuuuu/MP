
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pGoodsDele]
	@cStoreNo [varchar](32),
	@cStoreName [varchar](64),
	@cGoodsNo [varchar](32),
	@UserNo [varchar](32),
	@UserName [varchar](64),
	@StationName [varchar](64)	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @StoreCount INT
	SELECT @StoreCount = Count(*) FROM t_cStoreGoods WHERE cGoodsNo = @cGoodsNo AND cStoreNo <> @cStoreNo
	
	IF @StoreCount <> 0 
	BEGIN
		RAISERROR ('商品编码:[%s]已经在%d家门店存在,不能删除!', 16 , 1,@cGoodsNo,@StoreCount)
		SET NOCOUNT OFF
		RETURN
	END
	
	IF EXISTS (SELECT TOP 1 cGoodsNo FROM t_SaleSheetDetail WHERE cGoodsNo = @cGoodsNo)
	BEGIN
		RAISERROR ('商品编码:[%s]已经产生销售,不能删除!', 16 , 1,@cGoodsNo)
		SET NOCOUNT OFF
		RETURN
	END
	
	--错误计数变量
	DECLARE @ErrorCount INT
	SET @ErrorCount = 0
	SET XACT_ABORT  ON
	BEGIN TRAN	
	DELETE FROM t_GoodsItems WHERE cGoodsNo = @cGoodsNo
	SET @ErrorCount = @ErrorCount + @@ERROR
		
	DELETE FROM t_Goods WHERE cGoodsNo = @cGoodsNo
	SET @ErrorCount = @ErrorCount + @@ERROR
	
	DELETE FROM t_cStoreGoods WHERE cGoodsNo = @cGoodsNo
	SET @ErrorCount = @ErrorCount + @@ERROR
	
	DELETE FROM t_Supplier_goods WHERE cGoodsNo = @cGoodsNo
    SET @ErrorCount = @ErrorCount + @@ERROR
    
    DELETE FROM t_zone_Goods WHERE cGoodsNo = @cGoodsNo
    SET @ErrorCount = @ErrorCount + @@ERROR
    
	IF (EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.tables WHERE TABLE_NAME ='t_Log'))
	BEGIN
		INSERT INTO t_Log
		(UserNo ,UserName,Operation,OperTime,StationName)
		VALUES
		(@UserNo ,@UserName,
		 '删除商品信息 编号:' + @cGoodsNo, GETDATE(),@StationName)
		 
		SET @ErrorCount = @ErrorCount + @@ERROR
	END
	
	IF @ErrorCount = 0
		COMMIT TRAN
	ELSE
	BEGIN
		RAISERROR ('商品信息删除失败,请检查后重试', 16 , 1)
		ROLLBACK TRAN
	END		
	SET NOCOUNT OFF
END

GO
