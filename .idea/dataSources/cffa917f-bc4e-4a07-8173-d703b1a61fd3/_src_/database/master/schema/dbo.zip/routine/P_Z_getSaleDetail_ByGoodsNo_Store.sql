
/*
drop table ##tempResult_ListSaleDetail
P_Z_getSaleDetail_ByGoodsNo_Store '001','900002','2014-12-22','2014-12-26'

select * from ##tempResult_ListSaleDetail
*/

CREATE procedure [dbo].[P_Z_getSaleDetail_ByGoodsNo_Store]
  @cStoreNo varchar(32),
  @cGoodsNo varchar(50),
  @date1 datetime,
  @date2 datetime	
as
begin

-----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    
  if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32),cSaleSheetno varchar(64),
	cOperatorno varchar(32),cSaleTime time,fPrice money,cOperatorName varchar(32),fVipPrice money,cStoreNo varchar(32),cStoreName varchar(64))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32),jiesuanno varchar(64),cStoreNo varchar(32),cStoreName varchar(64))
	
	declare @InfoName1 varchar(32)
	
	set @InfoName1=(select distinct Pos_Sale from t_WareHouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1)
	
	exec('
				insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
			cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
			cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName
				from '+@InfoName1+'.dbo.t_salesheetDetail 
				where dSaleDate between '''+@date1+''' and '''+@date2+''' and CgoodsNo='''+@cGoodsNo+'''
				and cStoreNo='''+@cStoreNo+'''
				  and isnull(bOnline,0)=0

				insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno ,cStoreNo,cStoreName
				from '+@InfoName1+'.dbo.t_SaleSheet_Day 
				where dSaleDate between '''+@date1+''' and '''+@date2+'''  and CgoodsNo='''+@cGoodsNo+'''
				and cStoreNo='''+@cStoreNo+'''

			  ')
	
/* 
      if exists (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date1)  -- 包含在时间断内
      begin
			if (select OBJECT_ID('tempdb..#temp_SaleSheetInfor'))is not null drop table #temp_SaleSheetInfor
			create table #temp_SaleSheetInfor(databasename varchar(64))
			declare @SalesheetDate datetime
			select @SalesheetDate=isnull(MAX(saleend),'2001-01-02') from t_SaleSheetInfor

			insert into #temp_SaleSheetInfor(databasename)
			select a.databasename from (
			select * from t_SaleSheetInfor
			where SaleEnd>=@date1 ) a,(
			select * from t_SaleSheetInfor
			where SaleBegin<=@date2) b
			where a.DataBaseName=b.DataBaseName


			declare SaleSheetInfor_cursor1 cursor
			for
			select databasename
			from #temp_SaleSheetInfor

			declare @InfoName1 varchar(32)

			open SaleSheetInfor_cursor1
			fetch next from SaleSheetInfor_cursor1
			into @InfoName1

			while @@fetch_status=0
			begin					
			exec('
				insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
			cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
			cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName
				from '+@InfoName1+'.dbo.t_salesheetDetail 
				where dSaleDate between '''+@date1+''' and '''+@date2+''' and CgoodsNo='''+@cGoodsNo+'''
				and cStoreNo='''+@cStoreNo+'''

				insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno ,cStoreNo,cStoreName
				from '+@InfoName1+'.dbo.t_SaleSheet_Day 
				where dSaleDate between '''+@date1+''' and '''+@date2+'''  and CgoodsNo='''+@cGoodsNo+'''
				and cStoreNo='''+@cStoreNo+'''

			  ')					  
			fetch next from SaleSheetInfor_cursor1
			into @InfoName1
			end

			close SaleSheetInfor_cursor1
			deallocate SaleSheetInfor_cursor1
			 if not exists  (select DataBaseName from t_SaleSheetInfor where SaleEnd>=@date2)
			 begin	  
				insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
				cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno ,cSaleSheetno,
				cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName
				from dbo.t_salesheetDetail 
				where dSaleDate between @date1 and @date2 and CgoodsNo=@cGoodsNo
				and cStoreNo=@cStoreNo
	 
	 
           		insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno ,jiesuanno,cStoreNo,cStoreName
				from dbo.t_SaleSheet_Day 
				where dSaleDate between @SalesheetDate and @date2 and CgoodsNo=@cGoodsNo
				and cStoreNo=@cStoreNo
            end
      end else
      begin
        insert into #temp_salesheetDetail(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,cSaleSheetno,
				cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno ,cSaleSheetno,
				cOperatorno,cSaleTime,fPrice,cOperatorName,fVipPrice,cStoreNo,cStoreName
				from dbo.t_salesheetDetail 
				where dSaleDate between @date1 and @date2 and CgoodsNo=@cGoodsNo
				and cStoreNo=@cStoreNo
	 
	 
           		insert into #temp_SaleSheet_Day(dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno,jiesuanno,cStoreNo,cStoreName)
				select dSaleDate,cGoodsNo,
				fQuantity,fLastSettle,bAuditing,cWHno ,jiesuanno,cStoreNo,cStoreName
				from dbo.t_SaleSheet_Day 
				where dSaleDate between @date1 and @date2 and CgoodsNo=@cGoodsNo
				and cStoreNo=@cStoreNo
      end
 
 */
-------------------------



  select ts.bAuditing,ts.cSaleSheetno,ts.cOperatorno,ts.dSaleDate,ts.cSaleTime,ts.fPrice,
         ts.cOperatorName,ts.fQuantity,ts.fVipPrice,ts.fLastSettle,
         ts.cGoodsNo,cStoreNo,cStoreName
				 --,t.cUnitedNo,t.cGoodsName,t.cGoodsTypeno,
         --t.cGoodsTypename,t.cBarcode,t.cUnit,t.cSpec
	into #temp_saleDetail_0
  from  ---t_SaleSheetDetail ts--, t_Goods t 
          #temp_salesheetDetail ts
  where  ts.dSaleDate between @date1 and @date2 and ts.cGoodsNo=@cGoodsNo
				 --and t.cGoodsNo=@cGoodsNo and ts.cGoodsNo=t.cGoodsNo
				 
 

	select dSaleDate,cGoodsNo,bBalance=case when isnull(max(jiesuanno),'')<>'' then 1 else 0 end,
					jiesuanno=max(jiesuanno),cStoreNo,cStoreName
	into #temp_saleDay_0
	--from t_salesheet_day
	from #temp_SaleSheet_Day
	where dSaleDate between @date1 and @date2 and cGoodsNo=@cGoodsNo
	group by dSaleDate,cGoodsNo,cStoreNo,cStoreName

 
  select a.bAuditing,a.cSaleSheetno,a.cOperatorno,a.dSaleDate,a.cSaleTime,a.fPrice,
         a.cOperatorName,a.fQuantity,a.fVipPrice,a.fLastSettle,a.cGoodsNo,
				 bBalance=case when isnull(b.bBalance,0)=0 then '未结算' else '已结算'end ,
				 b.jiesuanno,c.cUnitedNo,c.cGoodsName,c.cGoodsTypeno,
         c.cGoodsTypename,c.cBarcode,c.cUnit,c.cSpec,a.cStoreNo,a.cStoreName
	into #tempResult
	from #temp_saleDetail_0 a 
			left join #temp_saleDay_0 b on a.cGoodsNo=b.cGoodsNo and a.dSaleDate=b.dSaleDate
			left join t_goods c on a.cGoodsNo=c.cGoodsNo

  union all
  select x.bAuditing,x.cSaleSheetno,x.cOperatorno,
		x.dSaleDate,x.cSaleTime,x.fPrice,x.cOperatorName,
    x.fQuantity,x.fVipPrice,x.fLastSettle,
    x.cGoodsNo,x.bBalance,x.jiesuanno,x.cUnitedNo,x.cGoodsName,
    x.cGoodsTypeno,x.cGoodsTypename,x.cBarcode,x.cUnit,x.cSpec,x.cStoreNo,x.cStoreName
  from 
  (
    select bAuditing=a.bExamin,cSaleSheetno='客退'+a.cSheetno,cOperatorno=a.cFillEmpNo,
		dSaleDate=a.dDate,cSaleTime=a.cFillinTime,fPrice=b.fInPrice,cOperatorName=a.cFillEmp,
    fQuantity=-b.fQuantity,fVipPrice=b.fInPrice,fLastSettle=-b.fInMoney,
    b.cGoodsNo,bBalance=case when isnull(b.bBalance,0)=0 then '未结算' else '已结算'end ,jiesuanno=a.jiesuanno,c.cUnitedNo,c.cGoodsName,
    c.cGoodsTypeno,c.cGoodsTypename,c.cBarcode,c.cUnit,c.cSpec,a.cStoreNo,a.cStoreName
    from  dbo.WH_ReturnGoodsDetail b left join dbo.WH_ReturnGoods a
    on a.cSheetno=b.cSheetno left join t_Goods c on b.cGoodsNo=c.cGoodsNo
    where a.dDate between @date1 and @date2 and b.cGoodsNo=@cGoodsNo
    and a.cStoreNo=@cStoreNo
  ) x


  select bAuditing,cSaleSheetno,cOperatorno,dSaleDate,cSaleTime,fPrice,
         cOperatorName,bBalance,
         jiesuanno,fQuantity,fVipPrice,fLastSettle,
         cGoodsNo,cUnitedNo,cGoodsName,cGoodsTypeno,
         cGoodsTypename,cBarcode,cUnit,cSpec,cStoreNo,cStoreName
 -- into ##tempResult_ListSaleDetail
  from  #tempResult
	union all  
  select bAuditing=null,cSaleSheetno=null,cOperatorno=null,dSaleDate=null,cSaleTime=null,fPrice=null,
         cOperatorName=null,bBalance=null,
         jiesuanno=null,fQuantity=sum(fQuantity), fVipPrice=null,fLastSettle=sum(fLastSettle),
         cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cGoodsTypeno=null,
         cGoodsTypename=null,cBarcode=null,cUnit=null,cSpec=null,cStoreNo=null,cStoreName=null
  from  #tempResult
	order by cGoodsNo,dSaleDate,cSaleTime


/*
  select ts.bAuditing,ts.cSaleSheetno,ts.cOperatorno,ts.dSaleDate,ts.cSaleTime,ts.fPrice,
         ts.cOperatorName,bBalance=case when isnull(b.bBalance,0)=0 then '未结算' else '已结算'end ,
         b.jiesuanno,ts.fQuantity,ts.fVipPrice,ts.fLastSettle,
         ts.cGoodsNo,t.cUnitedNo,t.cGoodsName,t.cGoodsTypeno,
         t.cGoodsTypename,t.cBarcode,t.cUnit,t.cSpec
  from  t_SaleSheetDetail ts left join t_Goods t on  ts.cGoodsNo=t.cGoodsNo
                             left join t_salesheet_day b 
																	on ts.cGoodsNo=b.cGoodsNo and ts.dSaleDate=b.dSaleDate
  where  ts.cGoodsNo=@cGoodsNo and ts.dSaleDate between @date1 and @date2

	union all
  
  select bAuditing=null,cSaleSheetno=null,cOperatorno=null,dSaleDate=null,cSaleTime=null,fPrice=null,
         cOperatorName=null,bBalance=null,
         jiesuanno=null,fQuantity=sum(fQuantity), fVipPrice=null,fLastSettle=sum(fLastSettle),
         cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cGoodsTypeno=null,
         cGoodsTypename=null,cBarcode=null,cUnit=null,cSpec=null
  from  t_SaleSheetDetail ts left join t_Goods t
  on  ts.cGoodsNo=t.cGoodsNo
  where  ts.cGoodsNo=@cGoodsNo and ts.dFinanceDate between @date1 and @date2
*/
end


GO
