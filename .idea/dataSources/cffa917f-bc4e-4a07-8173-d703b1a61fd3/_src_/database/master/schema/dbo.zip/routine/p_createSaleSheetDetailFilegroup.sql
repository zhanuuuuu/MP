/*
exec p_createSaleSheetDetailFilegroup 'PosManagement'
*/
/*
存储过程作用：
为指定数据库创建文件组
*/
create proc p_createSaleSheetDetailFilegroup
@MyDatebaseName varchar(64)
as
begin
exec('
	use '+@MyDatebaseName+'
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_01]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_02]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_03]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_04]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_05]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_06]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_07]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_08]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_09]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_10]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_11]
	
	alter database '+@MyDatebaseName+' add filegroup [saleSheetDetail_12]
	
    alter database '+@MyDatebaseName+' add filegroup [FG_saleSheetDetail]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_01'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_01.ndf''
	)to filegroup [saleSheetDetail_01]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_02'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_02.ndf''
	)to filegroup [saleSheetDetail_02]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_03'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_03.ndf''
	)to filegroup [saleSheetDetail_03]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_04'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_04.ndf''
	)to filegroup [saleSheetDetail_04]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_05'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_05.ndf''
	)to filegroup [saleSheetDetail_05]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_06'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_06.ndf''
	)to filegroup [saleSheetDetail_06]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_07'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_07.ndf''
	)to filegroup [saleSheetDetail_07]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_08'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_08.ndf''
	)to filegroup [saleSheetDetail_08]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_09'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_09.ndf''
	)to filegroup [saleSheetDetail_09]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_10'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_10.ndf''
	)to filegroup [saleSheetDetail_10]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_11'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_11.ndf''
	)to filegroup [saleSheetDetail_11]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_12'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_12.ndf''
	)to filegroup [saleSheetDetail_12]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_a'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_a.ndf''
	)to filegroup [FG_saleSheetDetail]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_b'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_b.ndf''
		
	)to filegroup [FG_saleSheetDetail]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_c'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_c.ndf''
	)to filegroup [FG_saleSheetDetail]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''saleSheetDetail_d'',
		filename=''d:\SQL_saleSheetDetail\saleSheetDetail_d.ndf''
	)to filegroup [FG_saleSheetDetail]
	
')
end


GO
