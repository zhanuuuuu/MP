/*
	if (select OBJECT_ID('U_key.dbo.temp_GoodsList'))is not null drop table U_key.dbo.temp_GoodsList
	create table U_key.dbo.temp_GoodsList(cSheetno varchar(32),iLineNo int,cGoodsNo varchar(32),cGoodsName varchar(64),
	cBarcode varchar(32),cUnitedNo varchar(32),fQuantity money ,
	fInPrice money ,fInMoney money,cUnit varchar(32) ,cSpec varchar(32),fQty_Cur money,
	fQty_Avg money,fQty_3 money,fNormalPrice money,fDhRate money,fBhRate money,fLossRato money,fQty_Month money
	,fWeekXs money,fWeekBhRate money,fLossRato_Z money,ftjRatio money,fQtySaleZ money,fQty_Week money,fQty_Month0 money,
	fIn_Month money, fQty_MonthZ0 money,fIn_MonthZ money,fQuantity_Jy money)
	     
	if (select OBJECT_ID('U_key.dbo.temp_GoodsTypeNo'))is not null drop table U_key.dbo.temp_GoodsTypeNo
	select cGoodsTypeNo into U_key.dbo.temp_GoodsTypeNo from t_Goodstype where isnull(bFresh,0)=1
 
   exec [p_GetSaleCreateBhStock_Week_Sup_test]  '1001','路发万家-福新店', '2017-2-7','2017-3-7', '',2,28,1.0429,1.05,'1117' 
   
   select cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,
	     fInPrice,fInMoney,cUnit,cSpec,fQty_Cur,fQty_Avg,fQty_3,fNormalPrice,fDhRate,fBhRate,fLossRato,fQty_Month,
	     fWeekXs,fWeekBhRate,fLossRato_Z,ftjRatio,fQty_Week,fQty_Month0,fIn_Month,fQty_MonthZ0,fIn_MonthZ
   from U_key.dbo.temp_GoodsList
   where cGoodsNo='10019'
   order by fQuantity desc   
 
*/
CREATE proc [dbo].[p_GetSaleCreateBhStock_Week_Sup_test]
@cStoreNo varchar(32),
@cStoreName varchar(64),
@dDate1 datetime,
@dDate2 datetime,
@cTermID varchar(32),
@cOrderType int,
@dDay int , ------ 前30天平均销量
@fRatio money,
@fAddRatio money,
@cSupNo varchar(32)
as
begin 
    
    declare @dOpenDate datetime
    set @dOpenDate=(select a.dOpenDate from t_OpenDate a,t_WareHouse b where a.cStoreNo=b.cWhNo and b.cStoreNo=@cStoreNo)
    
    if @dDate1<@dOpenDate
    begin
        set @dDate1=@dOpenDate
    end
    
	if (select OBJECT_ID('tempdb..#temp_Goods_01'))is not null drop table #temp_Goods_01
	create table #temp_Goods_01(cGoodsNo varchar(32))
	
	exec('
	   insert into #temp_Goods_01(cGoodsNo)
	   select cGoodsNo 
	   from t_cStoreGoods a,U_key.dbo.temp_GoodsTypeNo'+@cTermID+' b
			where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 
			and ISNULL(a.bfresh,0)=1 
	  --select cGoodsNo from t_cStoreGoods where cStoreNo='''+@cStoreNo+'''
	  --and cGoodsNo=''10019''
	 ')
	 if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	 create table #temp_Goods(cGoodsNo varchar(32))
	 if @cSupNo='--'
	 begin
	     insert into #temp_Goods(cGoodsNo)
	     select cGoodsNo from #temp_Goods_01
	 end else
	 begin
	    insert into #temp_Goods(cGoodsNo)
	    select distinct a.cGoodsNo  
	    from #temp_Goods_01 a,t_Goods b
	    where a.cGoodsNo=b.cGoodsNo and b.cSupNo=@cSupNo
	 end
	  
    declare @cParentStoreNo varchar(32)
    set @cParentStoreNo=(select cParentNo from t_Store where cStoreNo=@cStoreNo)
 
    
	declare @Day int
	
	declare @dDate1_Month datetime
	declare @dDate2_Month datetime
 
  
	declare @d1 datetime
	set @d1=@dDate1 
	---和当前系统启用日期比较：取有效天数。
	if @d1<@dOpenDate
	begin
	   set @d1=@dOpenDate
	   set @dDay=(DATEDIFF ( DAY , @d1 , @dDate2 ))+1
	end
    --2017-02-11 调整
    
    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate_Day'))is not null  drop table #temp_cGoodsSaleDate_Day
	create table #temp_cGoodsSaleDate_Day(cGoodsno varchar(32),fQty money)
    
    
    /*获取商品28天内有效天数：有销售、有入库的才作为有效天数*/ 
	/*获取销售：含日期*/
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate_DayDay'))is not null  drop table #temp_cGoodsSaleDate_DayDay
	select a.dSaleDate,a.cGoodsNo,cStoreNo,fQty=SUM(a.fQuantity)
	into #temp_cGoodsSaleDate_DayDay
	from t_SaleSheetDetail a,#temp_Goods_01 b
	where --a.cStoreNo=@cStoreNo  and 
	a.dSaleDate between @d1 and @dDate2 
	and a.cGoodsNo=b.cGoodsNo
	group by a.dSaleDate,a.cGoodsNo,cStoreNo
	
	
	/*获取各门店入库：不包含总部*/
	
	if (select OBJECT_ID('tempdb..#temp_cGoodsIn_ListDay'))is not null  drop table #temp_cGoodsIn_ListDay
	select distinct a.dDate,c.cGoodsNo,a.cStoreNo,c.fQuantity
	into #temp_cGoodsIn_ListDay
	from wh_InWarehouse a,wh_InWarehouseDetail c,#temp_Goods_01 b
	where --a.cStoreNo=@cStoreNo and 
	a.cStoreNo<>@cParentStoreNo and
	a.dDate between @d1 and @dDate2
	and a.cSheetno=c.cSheetno 
	and c.cGoodsNo=b.cGoodsNo
	
	---生鲜包装转换     
    update a
	set a.cGoodsno=b.cGoodsNo_minPackage,a.fQty=ISNULL(a.fQty,0)*ISNULL(b.fQty_minPackage,1)
	from #temp_cGoodsSaleDate_DayDay a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
	update a
	set a.cGoodsno=b.cGoodsNo_minPackage
	from #temp_cGoodsIn_ListDay a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
 
	--获取当前门店销售
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate_StoreDay'))is not null  drop table #temp_cGoodsSaleDate_StoreDay
	select a.dSaleDate,a.cGoodsNo,fQty=SUM(a.fQty)
	into #temp_cGoodsSaleDate_StoreDay
	from #temp_cGoodsSaleDate_DayDay a
	where a.cStoreNo=@cStoreNo
	group by a.dSaleDate,a.cGoodsNo
 
	--插入销售:读取时段销售。
	insert into #temp_cGoodsSaleDate_Day(cGoodsno,fQty)
	select a.cGoodsNo,fQty=isnull(b.fQty,0) 
	from #temp_Goods a left join #temp_cGoodsSaleDate_StoreDay b
	on a.cGoodsNo=b.cGoodsno
    
    
	/*读取有效天数*/
	if (select OBJECT_ID('tempdb..#temp_cGoods_Day'))is not null  drop table #temp_cGoods_Day
	select distinct a.dSaleDate,a.cGoodsNo
	into #temp_cGoods_Day
	from #temp_cGoodsSaleDate_DayDay a,#temp_cGoodsIn_ListDay b
	where a.dSaleDate=b.dDate and a.cGoodsNo=b.cGoodsNo
	and a.cStoreNo=b.cStoreNo 
	and a.cStoreNo=@cStoreNo
	and ISNULL(a.fQty,0)>0
	
 --   select *
	--from #temp_cGoods_Day
	--where cGoodsNo in (select cGoodsNo from t_Goods where cGoodsNo='14479' or cGoodsNo_minPackage='14479')
	
    ---生鲜包装转换     
    update a
	set a.cGoodsno=b.cGoodsNo_minPackage,a.fQty=ISNULL(a.fQty,0)*ISNULL(b.fQty_minPackage,1)
	from #temp_cGoodsSaleDate_Day a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
	update a
	set a.cGoodsno=b.cGoodsNo_minPackage
	from #temp_cGoods_Day a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
	
	
    ---根据小包装 读取天数
    if (select OBJECT_ID('tempdb..#temp_cGoods_Day_Distinct'))is not null  drop table #temp_cGoods_Day_Distinct
	select distinct  dSaleDate, cGoodsNo
	into #temp_cGoods_Day_Distinct
	from #temp_cGoods_Day
	
    if (select OBJECT_ID('tempdb..#temp_cGoods_iDay'))is not null  drop table #temp_cGoods_iDay
	select cGoodsNo,iDay=COUNT(cGoodsNo) 
	into #temp_cGoods_iDay
	from #temp_cGoods_Day_Distinct
	group by cGoodsNo
	
 
 
	--获取前28天每日的平均值
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateAvgSum_Day'))is not null  drop table #temp_cGoodsSaleDateAvgSum_Day
	select cGoodsNo,fQty=SUM(fQty),fQtySale=SUM(fQty)
	into #temp_cGoodsSaleDateAvgSum_Day
	from #temp_cGoodsSaleDate_Day 
	group by cGoodsNo
	
 
	---当有效数天数为0时 默认采用时间段内天数
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateAvg_Day'))is not null  drop table #temp_cGoodsSaleDateAvg_Day
	select a.cGoodsNo,fQty=fQty*1.0/isnull(iDay,@dDay),fQtySale
	into #temp_cGoodsSaleDateAvg_Day
	from #temp_cGoodsSaleDateAvgSum_Day a left join #temp_cGoods_iDay b on 
	a.cGoodsno=b.cGoodsNo
 
     --- 单号
     declare @SheetNo varchar(32)
     --set @SheetNo=(select sheetno=dbo.f_GenBhsheetnoApply(YEAR(getdate()),@cStoreNo))
    
	  if (select OBJECT_ID('tempdb..#temp_GoodsList'))is not null  drop table #temp_GoodsList
	  create table #temp_GoodsList( cSheetno varchar(32),iLineNo [bigint] IDENTITY(1,1) NOT NULL,cGoodsNo varchar(32),
	  cGoodsName varchar(64),cBarcode varchar(32),cUnitedNo varchar(32),  
	  fQuantity money,fInPrice money,fInMoney money,cUnit varchar(32),cSpec varchar(32),fQty_Cur money,fLossRato money,fQtySale money,
	  fQty_Avg money,fQty_3 money,fNormalPrice money,fDhRate money,fBhRate money,fQty_Week money,fQty_Month money,
	  fWeekXs money,fWeekBhRate money,fLossRato_Z money,ftjRatio money,fQtySaleZ money,fIn_Month money,fIn_MonthZ money,
	  i3Day money,i7Day money)
	  
	  --declare @cWhNo varchar(32)
	  --declare @cWh varchar(32)
	  
	  --select top 1 @cWhNo=cwhNo,@cWh=cwh from t_WareHouse where cStoreNo=@cStoreNo
	  
	  --------获取前28天总销售 
	   insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,
	   cSpec,fQty_Cur,fQtySale,fQty_Avg,fNormalPrice,fQty_Month,i3Day,i7Day)
	   select @SheetNo,a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,
		  fCKPrice=case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end,
		  a.fQty*(case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end),
		  b.cUnit,b.cSpec,fQty_Cur=0,a.fQtySale,a.fQty,b.fNormalPrice,a.fQtySale,0,0
		  from #temp_cGoodsSaleDateAvg_Day a,t_cStoreGoods b
		  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
		  
       
        -- select 1,* from #temp_GoodsList where cGoodsNo in ('01001','10011','10012','10013','10019')
	    
	    if (select object_id('tempdb..#temp_GoodsFresh'))is not null drop table #temp_GoodsFresh
	   
	    select a.cGoodsNo,fCKPrice,cGoodsNo_minPackage into #temp_GoodsFresh 
	    from  t_Goods a,#temp_GoodsList b
	    where a.cGoodsNo=b.cGoodsNo and ISNULL(bfresh,0)=1 
	    
           
		 update a set a.fInPrice=b.fCKPrice
		 from #temp_GoodsList a,#temp_GoodsFresh b
		 where a.cGoodsNo=b.cGoodsNo_minPackage
      
      
	  --select * from t_cStoreGoods
	  --where cStoreNo='1001' and ISNULL(bfresh,0)=1
	  
	  update #temp_GoodsList set fQuantity=CEILING(fQuantity)
	  where cUnit not in ('kg','500g')	  
	  
	  declare @dDate varchar(32)
      set @dDate=dbo.getDayStr(GETDATE()-1)
 
 
      
      declare @dDate3 varchar(32)
      set @dDate3=dbo.getDayStr(GETDATE()-3) 
      
      if @dDate3<@dOpenDate 
      begin
        set @dDate3=@dOpenDate
      end
 
	  ---最近7天销量
 
	  declare @d7 int
	  declare @d3 int
 
      declare @dDate7 varchar(32)
      set @dDate7=dbo.getDayStr(GETDATE()-7) 
      
      if @dDate7<@dOpenDate 
      begin
        set @dDate7=@dOpenDate
      end
      
      set  @d7=(DATEDIFF ( DAY , @dDate7 , @dDate ))+1
      set  @d3=(DATEDIFF ( DAY , @dDate3 , @dDate ))+1 
      
    
		if (select OBJECT_ID('tempdb..#temp_GoodsSale7'))is not null  drop table #temp_GoodsSale7  
		select a.cGoodsNo,a.dSaleDate,fQty=SUM(fQty)
		into #temp_GoodsSale7
		from #temp_cGoodsSaleDate_DayDay  a
		where a.dSaleDate between @dDate7 and @dDate 
		and a.cStoreNo=@cStoreNo
		group by a.cGoodsNo,a.dSaleDate
		

		update a
		set a.cGoodsno=b.cGoodsNo_minPackage,a.fQty=a.fQty*ISNULL(b.fQty_minPackage,1)
		from #temp_GoodsSale7 a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''	
	  ---处理入库最新商品对应的日期
	    -- #temp_cGoodsIn_ListDay
	    
	    update a
		set a.cGoodsno=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*ISNULL(b.fQty_minPackage,1)
		from #temp_cGoodsIn_ListDay a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''	
		
	   if (select OBJECT_ID('tempdb..#temp_GoodsInDay'))is not null  drop table #temp_GoodsInDay
	   select distinct dDate,cGoodsNo
	   into #temp_GoodsInDay
	   from #temp_cGoodsIn_ListDay
	   where cStoreNo=@cStoreNo
	   
	   
	     ------前3天的有效天数：
	      /*获取前3天销售*/
	      if (select OBJECT_ID('tempdb..#temp_cGoods_3SaleDay'))is not null  drop table #temp_cGoods_3SaleDay
	      select dSaleDate,cGoodsno,fQty=SUM(fQty) 
	      into #temp_cGoods_3SaleDay
		  from #temp_GoodsSale7 
		  where dSaleDate between @dDate3 and @dDate 
		  group by cGoodsno,dSaleDate
		  
		  
		 
		  
		  /*获取时段商品 实际为销售有效天*/
		  --if (select OBJECT_ID('tempdb..#temp_cGoods_3CountDay'))is not null  drop table #temp_cGoods_3CountDay
		  --select cGoodsno,i3Day=COUNT(cGoodsno)
		  --into #temp_cGoods_3CountDay
		  --from #temp_cGoods_3SaleDay
		  --group by cGoodsno
		   
		  
		  --update a set i3Day=b.i3Day
		  --from #temp_GoodsList a,#temp_cGoods_3CountDay b
		  --where  a.cGoodsNo=b.cGoodsNo 
		  
		  
	      if (select OBJECT_ID('tempdb..#temp_cGoods_3iDay'))is not null  drop table #temp_cGoods_3iDay
		  select a.cGoodsNo,iDay=COUNT(a.cGoodsNo) 
		  into #temp_cGoods_3iDay
		  from #temp_GoodsInDay a, #temp_cGoods_3SaleDay b
		  where a.dDate=b.dSaleDate and a.cGoodsNo=b.cGoodsNo
		  group by a.cGoodsNo 
		  
		  
		  update a set i3Day=b.iDay
		  from #temp_GoodsList a,#temp_cGoods_3iDay b
		  where  a.cGoodsNo=b.cGoodsNo 
		  
		  ---情况：有销售，有效天数为0情况 
		  
		  update a set fQty_3=b.fQty
		  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) 
		  from #temp_cGoods_3SaleDay group by cGoodsno) b
		  where  a.cGoodsNo=b.cGoodsNo
	      
	      
		  --获取有效天数日均销
		  update #temp_GoodsList set fQty_3=case when ISNULL(i3Day,0)=0 then 0 else Round(fQty_3,2)*1.0/ISNULL(i3Day,@d3) end
	   
	  
	   ------前天天的有效天数：
	      /*获取前3天销售*/
	      if (select OBJECT_ID('tempdb..#temp_cGoods_7SaleDay'))is not null  drop table #temp_cGoods_7SaleDay
	      select dSaleDate,cGoodsno,fQty=SUM(fQty) 
	      into #temp_cGoods_7SaleDay
		  from #temp_GoodsSale7  
		  group by cGoodsno,dSaleDate
		  
		  /*获取时段商品 实际为销售有效天*/
		  --if (select OBJECT_ID('tempdb..#temp_cGoods_7CountDay'))is not null  drop table #temp_cGoods_7CountDay
		  --select cGoodsno,i7Day=COUNT(cGoodsno)
		  --into #temp_cGoods_7CountDay
		  --from #temp_cGoods_7SaleDay
		  --group by cGoodsno
		  
		  
		  
		  --update a set i7Day=b.i7Day
		  --from #temp_GoodsList a,#temp_cGoods_7CountDay b
		  --where  a.cGoodsNo=b.cGoodsNo 
		  
		  ------------和入库一样的有效天
		  
		  
	      if (select OBJECT_ID('tempdb..#temp_cGoods_7iDay'))is not null  drop table #temp_cGoods_7iDay
		  select a.cGoodsNo,iDay=COUNT(a.cGoodsNo) 
		  into #temp_cGoods_7iDay
		  from #temp_GoodsInDay a,#temp_cGoods_7SaleDay b
		  where a.dDate=b.dSaleDate and a.cGoodsNo=b.cGoodsNo
		  group by a.cGoodsNo 
		  
		  
		  
		  update a set i7Day=b.iDay
		  from #temp_GoodsList a,#temp_cGoods_7iDay b
		  where  a.cGoodsNo=b.cGoodsNo 
		  
		  
		  ---情况：有销售，有效天数为0情况 
		  
		  update a set fQty_Week=fQty
		  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) 
		  from #temp_cGoods_7SaleDay group by cGoodsno) b
		  where  a.cGoodsNo=b.cGoodsNo
 
		  
		  --获取有效天数日均销
		  update #temp_GoodsList set fQty_Week=case when ISNULL(i7Day,0)=0 then 0 else Round(fQty_Week,2)*1.0/ISNULL(i7Day,@d7) end
	  
     ----------------
	  
	  --上个月总销量   #temp_cGoodsSaleDate_DayDay 
	    update a
		set a.cGoodsno=b.cGoodsNo_minPackage,a.fQty=a.fQty*ISNULL(b.fQty_minPackage,1)
		from #temp_cGoodsSaleDate_DayDay a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
		
	  
		  update a		 
		  set a.fQtySaleZ=isnull(b.fQty,0)
		  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) from #temp_cGoodsSaleDate_DayDay group by cGoodsno) b
		  where a.cGoodsNo=b.cGoodsNo
	  
	  
	  --select cGoodsno,fQty=SUM(fQty) 
	  --from #temp_cGoodsSaleDate_DayDay
	  --where cGoodsNo='14479'
	  -- group by cGoodsno
	  
      --@dDate1,@dDate2_Month
      ---上个月入库 
		  if (select OBJECT_ID('tempdb..#temp_GoodsInWare'))is not null  drop table #temp_GoodsInWare
		  select a.cGoodsNo,cStoreNo,fQty=SUM(a.fQuantity) 
		  into #temp_GoodsInWare
		  from #temp_cGoodsIn_ListDay a
		  --where a.cStoreNo=@cStoreNo
		  group by a.cGoodsNo,cStoreNo
		  
	  --select * from #temp_GoodsInWare where cGoodsNo in ('10011','10012','01001')
	 
	    update a
		set a.cGoodsno=b.cGoodsNo_minPackage,a.fQty=a.fQty*ISNULL(b.fQty_minPackage,1)
		from #temp_GoodsInWare a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
  
		
		--- 当前门店入库 ：损耗率=(上个月入库-上个月销量)/上个月的入库
		if (select OBJECT_ID('tempdb..#temp_GoodsInWareMin'))is not null  drop table #temp_GoodsInWareMin
		select a.cGoodsNo,fQty=SUM(a.fQty),
		fLossRato=case when SUM(a.fQty)=0 then 0 else (SUM(a.fQty)-SUM(b.fQty_month))/SUM(a.fQty) end
		into #temp_GoodsInWareMin
		from #temp_GoodsInWare a,#temp_GoodsList b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=@cStoreNo   
		group by a.cGoodsNo,a.cStoreNo
		
 
        
		update a
		--set a.fLossRato=round(isnull(b.fLossRato,0),2)
		set a.fLossRato=isnull(b.fLossRato,0),a.fIn_Month=b.fQty
		from #temp_GoodsList a,#temp_GoodsInWareMin b
		where a.cGoodsNo=b.cGoodsNo
		
		
 
		---所有门店入库
		if (select OBJECT_ID('tempdb..#temp_GoodsInWareMinZ'))is not null  drop table #temp_GoodsInWareMinZ
		select a.cGoodsNo,fQty=SUM(a.fQty),
		fLossRato=case when SUM(a.fQty)=0 then 0 else (SUM(a.fQty)-SUM(b.fQtySaleZ))/SUM(a.fQty) end
		into #temp_GoodsInWareMinZ
		from (select cGoodsNo,fQty=SUM(fQty) from #temp_GoodsInWare group by cGoodsNo) a,#temp_GoodsList b
		where a.cGoodsNo=b.cGoodsNo 
		group by a.cGoodsNo		
	 
	 
		update a 
		set a.fLossRato_Z=isnull(b.fLossRato,0),a.fIn_MonthZ=b.fQty
		from #temp_GoodsList a,#temp_GoodsInWareMinZ b
		where a.cGoodsNo=b.cGoodsNo
 
        --select * from #temp_GoodsList
        --where cGoodsNo='11829'
 
	     ----门店损耗率 ：2017-03-03 注释 
	    --update #temp_GoodsList 
	    --set  fQuantity=case when (1-isnull(fLossRato,0))=0 then 0 else fQty_Avg/(1-isnull(fLossRato,0)) end,
	    --fQty_Avg=case when (1-isnull(fLossRato,0))=0 then 0 else fQty_Avg/(1-isnull(fLossRato,0)) end,  --前多少天平均销量
	    --fQty_3=case when (1-isnull(fLossRato,0))=0 then 0 else fQty_3/(1-isnull(fLossRato,0)) end, --- 前三条日均销
	    --fQtySale=case when (1-isnull(fLossRato,0))=0 then 0 else fQtySale/(1-isnull(fLossRato,0)) end, --- 前一个月
	    --fQty_Week=case when (1-isnull(fLossRato,0))=0 then 0 else fQty_Week/(1-isnull(fLossRato,0)) end --上周日均销售
	    ----总公司损耗率 ：2017-03-03 注释 
	    
	    
        update #temp_GoodsList 
	    set  fQuantity=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Avg/(1-isnull(fLossRato_Z,0)) end,
	    fQty_Avg=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Avg/(1-isnull(fLossRato_Z,0)) end,  --前多少天平均销量
	    fQty_3=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_3/(1-isnull(fLossRato_Z,0)) end, --- 前三条日均销
	    fQtySale=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQtySale/(1-isnull(fLossRato_Z,0)) end, --- 前一个月
	    fQty_Week=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Week/(1-isnull(fLossRato_Z,0)) end --上周日均销售
	    where isnull(fLossRato_Z,0)>0
	    ---- 损耗率 
	    update #temp_GoodsList 
	    set  fQuantity=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Avg/1 end,
	    fQty_Avg=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Avg/1 end,  --前多少天平均销量
	    fQty_3=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_3/1 end, --- 前三条日均销
	    fQtySale=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQtySale/1 end, --- 前一个月
	    fQty_Week=case when (1-isnull(fLossRato_Z,0))=0 then 0 else fQty_Week/1 end --上周日均销售
	    where isnull(fLossRato_Z,0)<=0
 
	  ---补货数量=加损耗之后的数量*补货权系数*订货系数  

	       update a set fQuantity=round(isnull(fQuantity,0)*isnull(@fRatio,1)*ISNULL(@fAddRatio,1),2),
	      a.fDhRate=isnull(b.fDhRate,1),a.fBhRate=isnull(b.fBhRate,1),
	      a.fWeekXs=isnull(@fRatio,1),a.fWeekBhRate=ISNULL(@fAddRatio,1),
	      a.ftjRatio=1,
	      a.fNormalPrice=b.fNormalPrice
		  from #temp_GoodsList a,t_cStoreGoods b
		  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo		
		  
		  update #temp_GoodsList set cGoodsName=REPLACE(cGoodsName,'采购.','')
 
	  exec('
	  	  
	     insert into U_key.dbo.temp_GoodsList'+@cTermID+'(cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,
	     fInPrice,fInMoney,cUnit,cSpec,fQty_Cur,fQty_Avg,fQty_3,fNormalPrice,fDhRate,fBhRate,fLossRato,fQty_Month,
	     fWeekXs,fWeekBhRate,fLossRato_Z,ftjRatio,fQty_Week,fQty_Month0,fIn_Month,fQty_MonthZ0,fIn_MonthZ,fQuantity_Jy)
	     
	     select cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity=Round(fQuantity,0),fInPrice=Round(fInPrice,1),
	     fInMoney=Round(fQuantity*fInPrice,1),cUnit,cSpec,fQty_Cur,fQty_Avg=Round(fQty_Avg,1),fQty_3=Round(fQty_3,1),fNormalPrice,fDhRate,
	     fBhRate,fLossRato=isnull(fLossRato,0),
	     fQtySale=Round(fQtySale,1),fWeekXs,fWeekBhRate,fLossRato_Z,ftjRatio,fQty_Week=Round(fQty_Week,1),
	     fQty_Month=Round(fQty_Month,1),fIn_Month=Round(fIn_Month,1),fQtySaleZ=Round(fQtySaleZ,1),
	     fIn_MonthZ=Round(fIn_MonthZ,1),Round(fQuantity,0)
         from #temp_GoodsList order by iLineNo
	  ')
 
end
GO
