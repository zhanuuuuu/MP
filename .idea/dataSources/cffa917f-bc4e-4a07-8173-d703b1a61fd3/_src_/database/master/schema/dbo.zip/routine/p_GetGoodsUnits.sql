Create Procedure p_GetGoodsUnits
as
begin
  select Unit=rtrim(ltrim(cUnit))
  from t_Goods
  group by rtrim(ltrim(cUnit))
end
GO
