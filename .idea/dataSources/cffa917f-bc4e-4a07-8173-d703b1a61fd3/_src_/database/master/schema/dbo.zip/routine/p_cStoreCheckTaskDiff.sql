/*
  p_cStoreCheckTaskDiff_test '20170220' 
  
*/
CREATE proc p_cStoreCheckTaskDiff
@cCheckTaskNo varchar(32)
as
SET  NOCOUNT ON
begin
   ---获取当前任务  
    
    declare @dDate datetime
    declare @cStoreNo varchar(32)
    select @dDate=dCheckTask,@cStoreNo=cStoreNo from t_CheckTast where cCheckTaskNo=@cCheckTaskNo 
    
    
    if (select OBJECT_ID('tempdb..#temp_CheckWhDetail')) is not null 
    drop table #temp_CheckWhDetail
	select a.cSheetno,a.cSupplierNo,a.cSupplier,cZoneNo,b.cGoodsNo,b.cGoodsName,b.fQuantity
	into #temp_CheckWhDetail
	from wh_CheckWh a,wh_CheckWhDetail b
	where dDate=@dDate
	and a.cSupplierNo=@cCheckTaskNo
	and a.cSheetno=b.cSheetno
	
	----大转小包装
	update a
	set  a.cGoodsNo=b.cGoodsNo_minPackage,
	a.fQuantity=case when isnull(b.fQty_minPackage,1)=0 then a.fQuantity else a.fQuantity*b.fQty_minPackage end
	from #temp_CheckWhDetail a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
	----合计。。。
	if (select OBJECT_ID('tempdb..#temp_SumCheckWhDetail')) is not null 
    drop table #temp_SumCheckWhDetail
	select cSupplierNo,cSupplier,a.cGoodsNo,fQty=SUM(fQuantity)
	into #temp_SumCheckWhDetail
	from #temp_CheckWhDetail a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo
	group by cSupplierNo,cSupplier,a.cGoodsNo 
	 
 
	----处理当前库存
	 
	  declare @dDate1 varchar(32)
	  declare @cWHno varchar(32)
	  
	  if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	   
	  
	  select cGoodsNo,cGoodsName,cUnit,cSpec,fQty_Sys=CAST(null as money),fQty_Check=CAST(null as money) 
	  into #temp_Goods
	  from t_cStoreGoods
	  where cStoreNo=@cStoreNo 
	  --and ISNULL(fPreservationDown,0)>0
	  and ISNULL(bfresh,0)=0
	
 
	  set @cWHno=(select cWhNo from t_WareHouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1)

      set @dDate1=dbo.getDayStr(GETDATE())
		 				
      exec P_x_SetCheckWh_byGoodsType_logCurQty @cStoreNo,@dDate1,@dDate1,@cWHno		  
	 		
	  
	  update a
	  set a.fQty_Sys=b.EndQty
	  from #temp_Goods a,t_goodsKuCurQty_wei b
	  where a.cGoodsNo=b.cGoodsNo 
	  and b.cStoreNo=@cStoreNo
	  
 
	  
	  update a
	  set a.fQty_Check=b.fQty
	  from #temp_Goods a,#temp_SumCheckWhDetail b
	  where a.cGoodsNo=b.cGoodsNo  
	 
	  ----大转小包装  
	  update a
	  set  a.cGoodsNo=b.cGoodsNo_minPackage,
	  a.fQty_Sys=case when isnull(b.fQty_minPackage,1)=0 then a.fQty_Sys else a.fQty_Sys*b.fQty_minPackage end,
	  a.fQty_Check=case when isnull(b.fQty_minPackage,1)=0 then a.fQty_Check else a.fQty_Check*b.fQty_minPackage end
	  from #temp_Goods a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''
	  
	  
		
	  select  cGoodsNo=b.cBarcode,b.cGoodsName,b.cUnit,b.cSpec,
	  a.fQty_Sys,fQty_Check=isnull(a.fQty_Check,0),
	  fQty_Diff=ISNULL(a.fQty_Check,0)-ISNULL(a.fQty_Sys,0),
	  b.cBarcode,fQuantity_Check=isnull(a.fQty_Check,0),
	  fQuantity_Sys=ISNULL(a.fQty_Sys,0),
	  fNormalPrice,cSupplierNo=b.cSupNo,cSupplier=b.cSupName,
	  fInPrice_Avg=b.fCKPrice,
	  fMoney_Diff=(ISNULL(a.fQty_Check,0)-ISNULL(a.fQty_Sys,0))*b.fCKPrice,
	  fQuantity_Diff=ISNULL(a.fQty_Check,0)-ISNULL(a.fQty_Sys,0)
	  from #temp_Goods a,t_Goods b
	  where a.cGoodsNo=b.cGoodsNo
	  and (ISNULL(a.fQty_Check,0)-ISNULL(a.fQty_Sys,0))<>0
      --and a.cGoodsNo in ('0110681','0110028','0110683','0110184')
	  order by b.cGoodsTypeno
	  
end
GO
