
CREATE  view v_wh_OutWarehouseDetail
as
 select a.cSheetno,iLineNo,a.cGoodsNo,c.cGoodsName,c.cUnitedNo,fQuantity,fPrice,b.fMoney,fTaxrate,bTax,
        fTaxPrice,fTaxMoney,dProduct,fTimes,cProductSerno,b.bPost,bChecked,cCheckNo,dCheck,cCustomerNo,
        cCustomer,cOperatorNo,cOperator,dFillin,cFillinTime,cProcureDptno,cProcureDpt,cManagerNo,cManager,
        bAgree,cExaminerNo,cExaminer,bExamin,cWhNo,cWh,dDate,cTime,cGoodsTypeno,cGoodsTypename,cBarcode,
        cUnit,cSpec,fNormalPrice,cProductUnit,cHelpCode,cTaxRate,fPreservationUp,fPreservationDown,cLevel,
        bSuspend,bDeling,bDeled,dSuspendDate1,dSuspendDate2,dDelingDate1,dDelingDate2,fVipScore,bProducted,
        cProductNo
 from wh_OutWarehouseDetail a left join wh_OutWarehouse b
                              on a.cSheetno=b.cSheetno
                              left join t_Goods c
                              on a.cGoodsNo=c.cGoodsNo

GO
