



CREATE    procedure p_CreateTableOfYear_Finance
@cStoreNo varchar(32),
@iYearth int
as
begin
	declare @cYear char(4)
	declare @cYearEnd char(4)
	declare @OpenDate datetime
	declare @OpenDate_last datetime
	declare @iWeek_first int
	declare @iWeek_old int
	declare @iWeekth int
	select top 1 @OpenDate=dOpenDate from dbo.t_OpenDate where cStoreNo=@cStoreNo
  if @OpenDate is null  return
	set @OpenDate_last=dateadd(year,@iYearth,@OpenDate)-1
	set @OpenDate=dateadd(year,@iYearth-1,@OpenDate)
  set @cYear=datename(year,@OpenDate)
  set @cYearEnd=datename(year,@OpenDate_last)

	set @iWeek_first=dbo.f_GetWeeks(@OpenDate)-1
--	set @iWeek_first=datepart(wk,@OpenDate)-1
	set @iWeek_old=0
  while @OpenDate<=@OpenDate_last
	begin
		if year(@OpenDate)<>year(@OpenDate-1)			
		begin
			if @iWeek_old=0 
			begin
				if datepart(dw,@OpenDate-1)=1
				begin	
					set @iWeek_old=dbo.f_GetWeeks(@OpenDate-1)
				end else
				begin
					set @iWeek_old=dbo.f_GetWeeks(@OpenDate-1)-1
				end
      end
		end 
  
		set @iWeekth=dbo.f_GetWeeks(@OpenDate)-@iWeek_first+@iWeek_old
    
		if not exists(select cYear from dbo.t_WeekOfYear_Finance
				where cYear=@cYear  and iWeekNo=@iWeekth
			 )
		begin
			insert into dbo.t_WeekOfYear_Finance(cYear,cYearEnd,iWeekNo,cWeekName1,cWeekName2,dDate1,dDate2)
			values(@cYear,@cYearEnd,
						 @iWeekth,	
						 DATENAME(dw,@OpenDate),DATENAME(dw,@OpenDate),@OpenDate,@OpenDate)

		end else
		begin
			update dbo.t_WeekOfYear_Finance set dDate2=@OpenDate,cWeekName2=DATENAME(dw,@OpenDate)
			where cYear=@cYear 
						and iWeekNo=@iWeekth
		end

		set @OpenDate=@OpenDate+1
	end
	

end

/*


p_CreateTableOfYear_Finance '01',2

select * from dbo.t_WeekOfYear_Finance

truncate table t_WeekOfYear_Finance
*/




GO
