
/*

p_Ploy_band_Execute '09200910260001','2009-10-26'

*/
/*

select * from t_Salesheetdetail where dSaleDate='2009-10-25'
--select * from pos_day.dbo.t_Salesheetdetail where dSaleDate='2009-10-26'
--update t_SaleSheetDetail set bPresent=0,bExchange=0 where cSaleSheetno='09200910250001'
--delete from t_Salesheetdetail where isnull(bPresent,0)=1   and  cSaleSheetno='09200910260001'

--update pos_day.dbo.t_Salesheetdetail set bPost=0 where cSaleSheetno='09200910250001'
select * from  dbo.t_Salesheetdetail where dSaleDate='2009-10-26'
cSaleSheetno
dFinanceDate

*/

CREATE procedure [dbo].[p_Ploy_band_Execute]
 @cSheetNo varchar(32),
 @dSaleDate datetime
as
	if (select object_id('tempdb..#temp_Ploy_band_Add'))is not null 
			drop table #temp_Ploy_band_Add
 
	if (select object_id('tempdb..#temp_SaleSheetDetailTemp'))is not null 
			drop table #temp_SaleSheetDetailTemp
	if (select object_id('tempdb..#temp_Ploy_band'))is not null 
			drop table #temp_Ploy_band

  declare @fLastSettle money
	select cSaleSheetno,iSeed,cGoodsNo,cGoodsName,cBarcode,fLastSettle0=fLastSettle0,
  dSaleDate,cSaleTime
  into #temp_SaleSheetDetailTemp
  from t_SaleSheetDetail
  where cSaleSheetno=@cSheetNo
  select @fLastSettle=sum(fLastSettle0) from #temp_SaleSheetDetailTemp

  declare	@strFieldWeek varchar(5)
	declare @strFieldHour varchar(6)
	declare @strWeek varchar(16)
	declare @iHour varchar(16)
  declare @dMinSaleDatetime datetime
	set @strWeek=rtrim(ltrim(dbo.getWeekDaystr(getdate(),0)))
	set @strFieldWeek=
			(case 
					when @strWeek='周一' then 'week1'
					when @strWeek='周二' then 'week2'
					when @strWeek='周三' then 'week3'
					when @strWeek='周四' then 'week4'
					when @strWeek='周五' then 'week5'
					when @strWeek='周六' then 'week6'
					else  'week7'
			 end	
			)
  set @dMinSaleDatetime  --以每单的最早时间为基准
			=(select dMinSaleDatetime
				=min(cast(dbo.getDaystr(dSaleDate)+' '+cSaleTime as datetime))
        from t_SaleSheetDetail
        where cSaleSheetno=@cSheetNo
        )
	set @iHour= DATEPART(hh,@dMinSaleDatetime)	
	set @strFieldHour=
			(case 
					when @iHour=0 then 'Hour0'
					when @iHour=1 then 'Hour1'
					when @iHour=2 then 'Hour2'
					when @iHour=3 then 'Hour3'
					when @iHour=4 then 'Hour4'
					when @iHour=5 then 'Hour5'
					when @iHour=6 then 'Hour6'
					when @iHour=7 then 'Hour7'
					when @iHour=8 then 'Hour8'
					when @iHour=9 then 'Hour9'
					when @iHour=10 then 'Hour10'
					when @iHour=11 then 'Hour11'
					when @iHour=12 then 'Hour12'
					when @iHour=13 then 'Hour13'
					when @iHour=14 then 'Hour14'
					when @iHour=15 then 'Hour15'
					when @iHour=16 then 'Hour16'
					when @iHour=17 then 'Hour17'
					when @iHour=18 then 'Hour18'
					when @iHour=19 then 'Hour19'
					when @iHour=20 then 'Hour20'
					when @iHour=21 then 'Hour21'
					when @iHour=22 then 'Hour22'
					else  'Hour23'
			 end	
			)

select *,iRatio=cast(0 as int),fQuantity_Ploy=cast(0.0000 as money) 
into #temp_Ploy_band_Add 
from t_SaleSheetDetail where dSaleDate='2000-01-01' and cSaleSheetno='zzzz'

alter table #temp_Ploy_band_Add add iLineNo  int identity(1,1)
declare @dSaledatestring varchar(32)
set @dSaledatestring=dbo.getDayStr(@dSaleDate)

exec('

	select cGoodsNo,fQuantity=sum(fQuantity),fLastSettle0=0 
	into #temp_salesheetdetail
	from dbo.t_SaleSheetDetail 
	where dSaleDate='''+@dSaledatestring+''' and cSaleSheetno='''+@cSheetNo+'''
  and isnull(bPresent,0)=0 and isnull(bSend,0)=0 
  group by cGoodsNo
	 
	select x.cPloyNo,iPresentTimes=isnull(sum(x.iPresentTimes),0)
  into #temp_salesheetdetail_Presented0
  from
  (
		select cPloyNo=cWorkerNo,cSaleTime,iPresentTimes=isnull(iPresentTimes,0)
		from dbo.t_SaleSheetDetail
		where dSaleDate='''+@dSaledatestring+''' and cSaleSheetno='''+@cSheetNo+'''
		and cWorkerNo is not null
		group by cWorkerNo,cSaleTime,iPresentTimes
  ) x 
  group by x.cPloyNo

--select * from   #temp_salesheetdetail_Presented0

  select x.cGoodsNo,fQtyPresented=sum(x.fQtyPresented)
  into  #temp_salesheetdetail_Presented
  from
  (
		select a.cPloyNo,b.cGoodsNo,fQtyPresented=a.iPresentTimes*b.fQuantity_Ploy
		from #temp_salesheetdetail_Presented0 a,dbo.t_Ploy_band b
		where a.cPloyNo=b.cPloyNo
	) x   
  group by x.cGoodsNo

--select * from #temp_salesheetdetail
  update a set a.fQuantity=a.fQuantity-b.fQtyPresented
  from #temp_salesheetdetail a, #temp_salesheetdetail_Presented b
  where a.cGoodsNo=b.cGoodsNo
--select * from #temp_salesheetdetail

	--select * from #temp_salesheetdetail
	
	select a.cPloyNo,a.cGoodsNo,a.fQuantity_Ploy
	into #temp_Ploy_band
	from t_Ploy_band a, dbo.t_PloyType b
  where isnull(a.bEnabled,0)=1 and  isnull(a.bPresent,0)=1 and a.cPloyTypeNo=b.cPloyTypeNo and
				getdate() between a.dDateStart and (a.dDateEnd+1)
				and a.'+@strFieldWeek+'=1 and a.'+@strFieldHour+'=1


	select a.cPloyNo,cGoodsNo_ploy=a.cGoodsNo,a.fQuantity_Ploy,
	b.cGoodsNo,b.fQuantity,b.fLastSettle0,
  iRatio=case when a.fQuantity_Ploy>0 then floor(b.fQuantity/a.fQuantity_Ploy) else 0 end
	into #temp_Ploy_band_list
	from #temp_Ploy_band a
	right join #temp_salesheetdetail b 
  on a.cGoodsNo=b.cGoodsNo

--select * from #temp_Ploy_band_list

/*
  create table #temp_Ploy_band_list_min
  (cPloyNo varchar(32),iRatio money,iLineNo int IDENTITY(1,1))

  insert into #temp_Ploy_band_list_min
  (cPloyNo ,iRatio)
*/

  select x.cPloyNo,x.iRatio
  into #temp_Ploy_band_list_min
  from
  (
	select  cPloyNo,iRatio=min(iRatio)
	from #temp_Ploy_band_list
  --where iRatio>0
  group by cPloyNo
  ) x
  where x.iRatio>0

  delete from #temp_Ploy_band_list_min
  where cPloyNo in
  (select e.cPloyNo
   from
		(
			select d.cPloyNo,c.cGoodsNo,fQuantity=isnull(c.fQuantity,0),d.fQty_limited
			from #temp_salesheetdetail c right join
			(
			select a.cPloyNo, a.iRatio,b.cGoodsNo,fQty_limited=a.iRatio*b.fQuantity_Ploy
			from #temp_Ploy_band_list_min a left join #temp_Ploy_band b on a.cPloyNo=b.cPloyNo
			) d
			on c.cGoodsNo=d.cGoodsNo
		) e
    where e.fQuantity<e.fQty_limited
  )


  declare @cOperatorno varchar(32)
  declare @cOperatorName varchar(32)
  declare @iSeedMax int

  select @iSeedMax=max(iSeed)
	from t_SaleSheetDetail 
  where cSaleSheetno='''+@cSheetNo+''' 
  select top 1 @cOperatorno=cOperatorno,@cOperatorName=cOperatorName 
	from t_SaleSheetDetail 
  where cSaleSheetno='''+@cSheetNo+''' and cOperatorno is not null
  
  insert into #temp_Ploy_band_Add
 (iSeed,cWorkerNo,iRatio,fQuantity_Ploy,cGoodsNo,cGoodsName,cBarcode,
     cSaleSheetno,fVipScore,fNormalVipScore,fPrice,
		 fNormalSettle,fVipPrice,bVipRate,fQuantity,fLastSettle0,
		 fLastSettle,dSaleDate,
		 cSaleTime,dFinanceDate,
     cOperatorno,cOperatorName,
     bHidePrice,bHideQty,bPresent)
  select iSeed=@iSeedMax+iLineNo,cWorkerNo=a.cPloyNo,a.iRatio,b.fQuantity_Ploy,b.cGoodsNo,c.cGoodsName,c.cBarcode,
     cSaleSheetno='''+@cSheetNo+''',fVipScore=0,fNormalVipScore=0,fPrice=0,
		 fNormalSettle=0,fVipPrice=0,bVipRate=0,fQuantity=a.iRatio*b.fQuantity_Ploy,fLastSettle0=0,
		 fLastSettle=0,dSaleDate=dbo.getdaystr(getdate()),
		 cSaleTime=dbo.gettimestr(getdate()),dFinanceDate=dbo.getdaystr(getdate()),
     cOperatorno=@cOperatorno,cOperatorName=@cOperatorName,
     c.bHidePrice,c.bHideQty,bPresent=1
  from #temp_Ploy_band_list_min a left join t_Ploy_Band_Goods b
  on a.cPloyNo=b.cPloyNo
  left join t_Goods c
  on b.cGoodsNo=c.cGoodsNo
  where a.cPloyNo is not null

--  update #temp_Ploy_band_Add set iSeedNo=iLine1

  update  #temp_Ploy_band_Add set iSeed=@iSeedMax+iLineNo

/* 

  insert into t_SaleSheetDetail
  (iseed,cWorkerNo,cGoodsNo,cGoodsName,cBarcode,
     cSaleSheetno,fVipScore,fNormalVipScore,fPrice,
		 fNormalSettle,fVipPrice,bVipRate,fQuantity,fLastSettle0,
		 fLastSettle,dSaleDate,
		 cSaleTime,dFinanceDate,
     cOperatorno,cOperatorName,
     bHidePrice,bHideQty,bPresent,bAuditing,iPresentTimes)

  select  iseed,cWorkerNo,cGoodsNo,cGoodsName,cBarcode,
     cSaleSheetno,fVipScore,fNormalVipScore,fPrice,
		 fNormalSettle,fVipPrice,bVipRate,fQuantity,fLastSettle0,
		 fLastSettle,dSaleDate,
		 cSaleTime,dFinanceDate,
     cOperatorno,cOperatorName,
     bHidePrice,bHideQty,bPresent,bAuditing=1,iPresentTimes=iRatio
  from #temp_Ploy_band_Add
	update t_SaleSheetDetail set bPresent=1 where cSaleSheetno='''+@cSheetNo+'''
*/  
/*     
  select  iseed,cWorkerNo,cGoodsNo,cGoodsName,cBarcode,
     cSaleSheetno,fVipScore,fNormalVipScore,fPrice,
		 fNormalSettle,fVipPrice,bVipRate,fQuantity,fLastSettle0,
		 fLastSettle,dSaleDate,
		 cSaleTime,dFinanceDate,
     cOperatorno,cOperatorName,
     bHidePrice,bHideQty,bPresent,bAuditing=1,iRatio
  from #temp_Ploy_band_Add
*/
  select distinct cPloyNo=a.cWorkerNo,b.cPloyTypeName,a.iRatio,bSelected=0,iRatio_res=a.iRatio
  from #temp_Ploy_band_Add a left join dbo.t_Ploy_band b
  on a.cWorkerNo=b.cPloyNo
  ')

GO
