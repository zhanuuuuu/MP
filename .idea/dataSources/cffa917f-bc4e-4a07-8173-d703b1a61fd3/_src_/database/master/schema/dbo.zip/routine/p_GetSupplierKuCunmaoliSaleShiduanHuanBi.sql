 
 
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsNo,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='11576' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
	drop table #temp_Goods
	Create Table #temp_Goods (
	cGoodsNo varchar(128),
	cProductNo varchar(128),
	cSupplierNo varchar(128))

if  (select object_id('tempdb..#tempSupNo')) is not null
drop table #tempSupNo
select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier

exec p_GetSupplierKuCunmaoliSaleShiduanHuanBi '001','2015-01-1','2015-01-31','01' 

*/
CREATE procedure [dbo].[p_GetSupplierKuCunmaoliSaleShiduanHuanBi]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as  --查询某时段 商品销售利润（含顾客退货） 

declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  
 
/*获取商品信息*/
if (select object_id('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select distinct cGoodsNo into #temp_Goods 
from #tempSupNo a,t_Goods b
where a.cSupplierNo=b.cSupNo

CREATE INDEX IX_tmp_WhFromGoods  ON #temp_Goods(cGoodsNo)

if (select object_id('tempdb..#temp_Goods_1'))is not null drop table #temp_Goods_1

select cGoodsNo,cSupplierNo  into #temp_Goods_1  from (
select distinct a.cGoodsNo,b.cSupplierNo  from wh_InWarehouseDetail a
right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
where a.cGoodsNo in (select cGoodsNo from #temp_Goods)
and a.cGoodsNo not in 
(select cGoodsNo from t_Supplier_goods_eStop where cGoodsNo in (select cGoodsNo from #temp_Goods))
union
select distinct a.cGoodsNo,a.cSupno from  t_goods a
where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)
) h,t_Supplier j
where h.cSupplierNo=j.cSupNo

if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cSupplierNo into  #tmp_WhGoodsList  
from (
select distinct a.cGoodsNo,a.cSupplierNo  
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno and isnull(b.cGoodsNo_minPackage,'')<>''
) a

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

if(select object_id('tempdb..#tmp_WhGoodsList_cGoodsno')) is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from #tmp_WhGoodsList

CREATE INDEX IX_temp_WhFromGoods  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--print '100   '+dbo.getTimeStr(GETDATE())
--print 2

/*修改主供应商-- 有入库、但是该商品为不管理库存、*/
 
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 
库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 库存标志 bit,期初库存 money,期末库存 money,
fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money)

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
 /*快照表中的最大日期。。。*/
 declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@dDateEnd)
set @Day1=day(@dDateEnd)
set @Y1=YEAR(@dDateEnd)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@dDateEnd) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@dDateEnd) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
    
	if(@bY1<>@eY1)
	begin 
	    set @tj='1' 

	end else
	begin
	  if @bM1=@eM1
	  begin
	   
	  exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	    fQty0=b.fQty_010131,fQtytj0=b.fQtytj_010131
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	    Sale0=b.Sale_010131, Saletj0=b.Saletj_010131  
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	    fQty0=sum(fQty0), fQtytj0=sum(fQtytj0) 
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),
		Sale0=sum(Sale0), Saletj0=sum(Saletj0)   
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0), 
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	')
	  exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		   fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131  					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),
			fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
			a.fPrice_Avg=case when (isnull(a.销售数量0,0))<>0 
			then (isnull(b.fMoney1,0)-isnull(b.fMoney0,0))/(isnull(a.销售数量0,0)) else 0 end,	 
			a.fml=(isnull(a.销售金额0,0))-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	  exec('
	----------期末库存	
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+',
			fQty0=b.fQty_010131,fMoney0=b.fMoney_010131 	 		
		into #temp_Wh_Goods_end
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), 
			fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno,cSupplierNo
		 
		update a 
		set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
			a.fmoney_left=b.fMoney1									
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
	 
	')
	  end else
	  begin
	    set @tj='1' 
	  end
	end
	if @tj='1'
	begin
	  
	 exec('
	 --------期初销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_beginQty
		from  #temp_Wh_Goods_beginQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_beginSale
		from  #temp_Wh_Goods_beginSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_beginQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期初成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_beginCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_beginCost
		from  #temp_Wh_Goods_beginCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	exec('
	-------期初库存
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_begin
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_begin
		from  #temp_Wh_Goods_begin
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.期初库存=b.fQty 			
		from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		
	 
	 
	')

	exec('
	 --------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	exec('
	----------期末库存	
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
		into #temp_Wh_Goods_end
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno,cSupplierNo
		 
		update a 
		set a.期末库存=b.fQty, 
		a.fmoney_left=b.fMoney			
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
	 
	 		
	 
	')

	update a 
	set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
	a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
	a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
	a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
	a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
	a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
	a.期初库存=isnull(b.期初库存,0), 
	a.期末库存=isnull(a.期末库存,0), 
	a.fPrice_Avg=case when (isnull(a.销售数量0,0)-isnull(b.销售数量0,0))<>0 
	then (isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) else 0 end,
	a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
	a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0)) 
	from #temp_WhFromend a,#temp_WhFrombegin b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	end
end else
begin
 
    if @M1=@M_1
    begin
    exec('
 --------期末销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
	select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
	    fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_endQty
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
	            
	select a.cgoodsno,cSupplierNo=b.cSupNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+',
	    Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'   
	into #temp_Wh_Goods_endSale					
	from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
	with (nolock) 
	where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
	select cgoodsno,cSupplierno,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1) ,
	    fQty0=sum(fQty0), fQtytj0=sum(fQtytj0) 
	into #temp_SumWh_Goods_endQty
	from  #temp_Wh_Goods_endQty
	group by cgoodsno,cSupplierNo
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
	select cgoodsno,cSupplierNo,Sale1=sum(Sale1), Saletj1=sum(Saletj1),
		Sale0=sum(Sale0), Saletj0=sum(Saletj0)   
	into #temp_SumWh_Goods_endSale
	from  #temp_Wh_Goods_endSale
	group by cgoodsno,cSupplierNo
	 
	 
	
	insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
	select cgoodsno,cSupplierNo,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))	
	from #temp_SumWh_Goods_endQty
 
	 
    update a 
	set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0), 
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))				
	from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
	where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
	')
	exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		   fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+'  					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),
			fQty0=sum(fQty0), fMoney0=sum(fMoney0) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
			a.fPrice_Avg=case when (isnull(a.销售数量0,0))<>0 
			then (isnull(b.fMoney1,0)-isnull(b.fMoney0,0))/(isnull(a.销售数量0,0)) else 0 end,	 
			a.fml=(isnull(a.销售金额0,0))-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	exec('
	----------期末库存	
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty1=b.fQty_'+@MMDAY1+',fMoney1=b.fMoney_'+@MMDAY1+',
			fQty0=b.fQty_'+@MMDAY_1+',fMoney0=b.fMoney_'+@MMDAY_1+' 	 		
		into #temp_Wh_Goods_end
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cgoodsno,cSupplierNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), 
			fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno,cSupplierNo
		 
		update a 
		set a.期末库存=b.fQty1,a.期初库存=b.fQty0, 
			a.fmoney_left=b.fMoney1									
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
	 
	')
    end else
    begin
    exec('
	 --------期初销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
		into #temp_Wh_Goods_beginSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_beginQty
		from  #temp_Wh_Goods_beginQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_beginSale
		from  #temp_Wh_Goods_beginSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_beginQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期初成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_beginCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_beginCost
		from  #temp_Wh_Goods_beginCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	exec('
	-------期初库存
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
		into #temp_Wh_Goods_begin
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M_1+' b
		with (nolock) 
		where b.cyear='''+@Y_1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_begin
		from  #temp_Wh_Goods_begin
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.期初库存=b.fQty 			
		from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		
	 
	 
	')

	exec('
	 --------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endQty
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
		            
		select a.cgoodsno,cSupplierNo=b.cSupNo,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
		into #temp_Wh_Goods_endSale					
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cgoodsno,cSupplierno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cgoodsno,cSupplierNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cgoodsno,cSupplierNo
		 
		 
		
		insert into #temp_WhFromend(cgoodsno,cSupplierNo,销售数量0,特价销售数量,正价销售数量)
		select cgoodsno,cSupplierNo,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
		from #temp_SumWh_Goods_endQty
	 
		 
		update a 
		set a.销售金额0=b.Sale, 
		a.特价销售金额=b.Saletj,
		a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo   and a.cSupplierNo=b.cSupplierNo
		')
	exec('
	----------期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
		into #temp_Wh_Goods_endCost
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cgoodsno,cSupplierNo
		

		update a 
		set a.fmoney_cost=b.fMoney		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo 
		')
	exec('
	----------期末库存	
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
		select a.cgoodsno,cSupplierNo=b.cSupNo,fQty=b.fQty_'+@MMDAY1+',fMoney=b.fMoney_'+@MMDAY1+' 		
		into #temp_Wh_Goods_end
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@M1+' b
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo='''+@cStoreNo+''' and  a.cGoodsNo=b.cGoodsNo 
	  
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
		select cgoodsno,cSupplierNo,fQty=sum(fQty), fMoney=sum(fMoney) 
		into #temp_SumWh_Goods_end
		from  #temp_Wh_Goods_end
		group by cgoodsno,cSupplierNo
		 
		update a 
		set a.期末库存=b.fQty, 
		a.fmoney_left=b.fMoney			
		from #temp_WhFromend a ,#temp_SumWh_Goods_end b
		where a.cGoodsNo=b.cGoodsNo  and a.cSupplierNo=b.cSupplierNo
	 
	 		
	 
	')

	update a 
	set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
	a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
	a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
	a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
	a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
	a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),
	a.期初库存=isnull(b.期初库存,0), 
	a.期末库存=isnull(a.期末库存,0), 
	a.fPrice_Avg=case when (isnull(a.销售数量0,0)-isnull(b.销售数量0,0))<>0 
	then (isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) else 0 end,
	a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
	a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0)) 
	from #temp_WhFromend a,#temp_WhFrombegin b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
    end
end
 
--print dbo.getTimeStr(GETDATE())
--print 4

if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select  cGoodsNo,cSupplierNo,cSupName=CAST(null as varchar(64)),
BeginDate=@dDateBgn,EndDate=@dDateEnd, 销售数量=sum(销售数量0),销售金额=sum(销售金额0),	 
fPrice_Avg=AVG(fPrice_Avg),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),i=0,
特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),
 fmoney_left=SUM(fmoney_left),期初库存=SUM(期初库存), 期末库存=SUM(期末库存), 
当前库存=CAST(null as money),当前库存金额=CAST(null as money),
最后销售日=CAST(null as date),可销天数=CAST(null as money) 
into  #temp_goodsKuCun
from #temp_WhFromend 
group by cGoodsNo, cSupplierNo 
order by  cGoodsNo

CREATE INDEX IX_temp_goodsKuCunml  ON #temp_goodsKuCun(cGoodsNo)



--print '600   '+dbo.getTimeStr(GETDATE())

---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)

--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
drop table #temp_wh_DiffGoodsNo
select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
where dSaleDate between @dDate1 and @dDate2 
and a.cStoreNo=@cStoreNo
and a.cGoodsno=b.cGoodsNo 
group by a.cGoodsno,a.cSupNo


CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1'))is not null  
drop table #temp_wh_DiffGoodsNo1
select b.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo1
from #temp_wh_DiffGoodsNo a,#temp_goodsKuCun b
where a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
group by b.cGoodsno,a.cSupNo

CREATE INDEX IX_temp_wh_wh_DiffGoodsNo1  ON #temp_wh_DiffGoodsNo1(cGoodsNo)

update a
set
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1 b
where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo


if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null'))is not null  
drop table #temp_wh_DiffGoodsNo1_Null
select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo1_Null
from #temp_wh_DiffGoodsNo a left join #temp_goodsKuCun b
on a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
where ISNULL(b.cGoodsNo,'')=''
group by a.cGoodsno,a.cSupNo

CREATE INDEX IX_temp_wh_DiffGoodsNo1_Null  ON #temp_wh_DiffGoodsNo1_Null(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null0'))is not null  
drop table #temp_wh_DiffGoodsNo1_Null0
select b.cGoodsNo,cSupNo=b.cSupplierNo,fqty_Sale=sum(a.fqty_Sale),fMoney_Diff=sum(a.fMoney_Diff),cRows=COUNT(b.cGoodsNo)
into #temp_wh_DiffGoodsNo1_Null0
from #temp_wh_DiffGoodsNo1_Null a,#temp_goodsKuCun b
where a.cGoodsno=b.cGoodsNo and a.cSupNo<>b.cSupplierNo
group by b.cGoodsNo,b.cSupplierNo
having COUNT(b.cGoodsNo)=1

update a
set 
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1_Null0 b
where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo


--print '700   '+dbo.getTimeStr(GETDATE())

/*
 2015-03-11 获取库存调整的商品
*/
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCun

--------获取期末前最新的毛利调整数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fDiffMoney=SUM(a.fDiffMoney)--,dDateTime=max(dDateTime),a.cSupNo
into #tmpGoodsRelationKucun_1
from  dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
where dDatetime between @dDateBgn and @dDateEnd and a.cgoodsno=b.cgoodsno  
group by a.cGoodsNo 
	
---------修改最近调整成本商品的毛利
--update a 
--set a.fMoney_Cost=ISNULL(a.销售数量,0)*ISNULL(b.fNewPrice,0),
--a.fML=isnull(a.销售金额,0)-ISNULL(a.销售数量,0)*ISNULL(b.fNewPrice,0),
--a.fPrice_Avg=b.fNewPrice
--from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
--where a.cGoodsNo=b.cGoodsNo ---and a.cSupplierNo=b.cSupNo
update a 
set a.fMoney_Cost=ISNULL(a.fMoney_Cost,0)-ISNULL(b.fDiffMoney,0),
a.fML=isnull(a.销售金额,0)-(ISNULL(a.fMoney_Cost,0)-ISNULL(b.fDiffMoney,0))
from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
where a.cGoodsNo=b.cGoodsNo  

--print '800   '+dbo.getTimeStr(GETDATE())

-----------获取当前库存------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
declare @dDate date

set @dDate=@dDate2
 
exec [P_x_SetCheckWh_byGoodsType_logCurQty]  @cStoreNo,@dDate,@dDate,@cWhno  
 
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQtySup'))is not null  drop table #temp_goodsKuCurQtySup
select a.cGoodsNo,a.EndQty,a.Endmoney,b.cSupNo into #temp_goodsKuCurQtySup from #temp_goodsKuCurQty  a,t_Goods b
where a.cGoodsNo=b.cGoodsNo   --- 28585

CREATE INDEX IX_temp_goodsKuCurQtySup  ON #temp_goodsKuCurQtySup(cGoodsNo)
 
---print '900   '+dbo.getTimeStr(GETDATE())

 if (select OBJECT_ID('tempdb..#temp_goodsKuCunGroupby'))is not null  drop table #temp_goodsKuCunGroupby
select cGoodsNo,cSupplierNo,cSupName,BeginDate,EndDate,xsQty=SUM(销售数量),xsMoney=SUM(销售金额),fML=SUM(fML),
fMoney_Cost=SUM(fMoney_Cost),
当前库存,当前库存金额
into #temp_goodsKuCunGroupby 
from #temp_goodsKuCun
group by cGoodsNo,cSupplierNo,cSupName,BeginDate,EndDate,当前库存,当前库存金额 
 
CREATE INDEX IX_temp_goodsKuCunGroupby  ON #temp_goodsKuCunGroupby(cGoodsNo)

insert into #temp_goodsKuCunGroupby(cGoodsNo,cSupplierNo,cSupName,BeginDate,EndDate)
select a1.cGoodsNo,a1.cSupNo,a1.cSupName,@dDateBgn,@dDateEnd from t_Goods a1,(
select b.cGoodsNo,b.EndQty,b.Endmoney,a.cSupplierNo 
from #temp_goodsKuCunGroupby  a right join #temp_goodsKuCurQtySup b on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo 
where ISNULL(a.cGoodsNo,'')='') b1
where a1.cGoodsNo=b1.cGoodsNo

--print '1000   '+dbo.getTimeStr(GETDATE())

insert into #temp_goodsKuCunGroupby(cGoodsNo,cSupplierNo,cSupName,BeginDate,EndDate)
select a1.cGoodsNo,a1.cSupNo,a1.cSupName,@dDateBgn,@dDateEnd from t_Goods a1,(
select b.cGoodsNo,b.EndQty,b.Endmoney,a.cSupplierNo 
from #temp_goodsKuCunGroupby  a right join #temp_goodsKuCurQtySup b on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo 
where ISNULL(a.cGoodsNo,'')='') b1
where a1.cGoodsNo=b1.cGoodsNo

 
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney
from #temp_goodsKuCunGroupby a,#temp_goodsKuCurQtySup b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupNo



if (select OBJECT_ID('tempdb..#temp_wh_UnionGoods'))is not null  
drop table #temp_wh_UnionGoods
select BeginDate,EndDate,a.cSupplierNo,a.cSupName,a.fML,a.fMoney_Cost, 
xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0), 
a.当前库存,a.当前库存金额 
into #temp_wh_UnionGoods 
from #temp_goodsKuCunGroupby a,t_Goods b
where a.cGoodsNo=b.cGoodsNo 

if (select OBJECT_ID('tempdb..#temp_wh_SumUnionGoods'))is not null  
drop table #temp_wh_SumUnionGoods
select BeginDate,EndDate,b.cSupNo,b.cSupName,fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost), 
 xsQty=SUM(xsQty),xsMoney=SUM(xsMoney), 
当前库存=SUM(当前库存),当前库存金额=SUM(当前库存金额),
上月销售金额=CAST(null as money),上月销售数量=CAST(null as money),上月毛利=CAST(null as money),
去年销售金额=CAST(null as money),去年销售数量=CAST(null as money),去年毛利=CAST(null as money)
into #temp_wh_SumUnionGoods
from #temp_wh_UnionGoods a,t_Supplier b
where a.cSupplierNo=b.cSupNo
group by BeginDate,EndDate,b.cSupNo,b.cSupName

--print '1100   '+dbo.getTimeStr(GETDATE())

 ---------获取上个月的整月销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cSupplierNo varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fml money,fMoney_Cost money)
declare @lastBgn1 datetime
declare @lastEnd1 datetime 
set @lastBgn1=DATEADD(MONTH,-1,@dDate1)
set @lastEnd1=DATEADD(MONTH,-1,@dDate2) 

exec p_GetSupplierSaleFmlHuanBi @cStoreNo,@lastBgn1,@lastEnd1,@cWHno,@cdbname


update a
set a.上月销售金额=b.xsMoney,a.上月销售数量=b.xsQty,上月毛利=b.fml
from #temp_wh_SumUnionGoods a,#temp_GetLastMonthSale_wei b
where a.cSupNo=b.cSupplierNo 

--print '1200   '+dbo.getTimeStr(GETDATE())

 ---------获取去年同期销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
truncate table #temp_GetLastMonthSale_wei 

declare @lastBgn2 datetime
declare @lastEnd2 datetime 
set @lastBgn2=DATEADD(YEAR,-1,@dDate1)
set @lastEnd2=DATEADD(YEAR,-1,@dDate2) 
 
exec p_GetSupplierSaleFmlHuanBi @cStoreNo,@lastBgn2,@lastEnd2,@cWHno,@cdbname


update a
set a.去年销售金额=b.xsMoney,a.去年销售数量=b.xsQty,去年毛利=b.fml
from #temp_wh_SumUnionGoods a,#temp_GetLastMonthSale_wei b
where a.cSupNo=b.cSupplierNo 

--print '1300   '+dbo.getTimeStr(GETDATE())
 
select BeginDate,EndDate,a.cSupNo,a.cSupName,a.fml,a.fMoney_Cost,a.xsQty,a.xsMoney,
本期毛利率=case when isnull(a.xsMoney,0)<>0 then (fml/a.xsMoney)*100 else 100 end,
a.当前库存,a.当前库存金额,
a.上月销售数量,a.上月销售金额,
本期环比销售=case when isnull(a.上月销售金额,0)<>0 then ((a.xsMoney-a.上月销售金额)/a.上月销售金额)*100 else 100 end,
a.上月毛利,
本期环比毛利=case when isnull(a.上月毛利,0)<>0 then ((a.fML-a.上月毛利)/a.上月毛利)*100 else 100 end,
上期毛利率=case when isnull(a.上月销售金额,0)<>0 then (a.上月毛利/a.上月销售金额)*100 else 100 end,
a.去年销售金额,
上年同比销售=case when isnull(a.去年销售金额,0)<>0 then ((a.xsMoney-a.去年销售金额)/a.去年销售金额)*100 else 100 end,
a.去年销售数量,
a.去年毛利,
上年毛利率=case when isnull(a.去年销售金额,0)<>0 then (a.去年毛利/a.去年销售金额)*100 else 100 end,
上年同比毛利=case when isnull(a.去年毛利,0)<>0 then ((a.fml-a.去年毛利)/a.去年毛利)*100 else 100 end,
  i=0
 from #temp_wh_SumUnionGoods a,#tempSupNo b
 where a.cSupNo=b.cSupplierNo
union all
select BeginDate=null,EndDate=null,cSupNo='ZZZZZZZ',cSupName='合计:',sum(a.fml),sum(a.fMoney_Cost),sum(a.xsQty),sum(a.xsMoney),
本期毛利率=null,
 sum(a.当前库存),sum(a.当前库存金额),
 sum(a.上月销售数量),sum(a.上月销售金额),  
 本期环比销售=case when isnull(sum(a.上月销售金额),0)<>0 then ((sum(a.xsMoney)-sum(a.上月销售金额))/sum(a.上月销售金额))*100 else 100 end,
 sum(a.上月毛利),
 本期环比毛利=case when isnull(sum(a.上月毛利),0)<>0 then ((sum(a.fML)-sum(a.上月毛利))/sum(a.上月毛利))*100 else 100 end,
 上期毛利率=null,
 sum(a.去年销售金额), 
 上年同比销售=case when isnull(sum(a.去年销售金额),0)<>0 then ((sum(a.xsMoney)-sum(a.去年销售金额))/sum(a.去年销售金额))*100 else 100 end,
 sum(a.去年销售数量), 
 sum(a.去年毛利),
 上年毛利率=null,
 上年同比毛利=case when isnull(sum(a.去年毛利),0)<>0 then ((sum(a.fml)-sum(a.去年毛利))/sum(a.去年毛利))*100 else 100 end,
 i=1
 from #temp_wh_SumUnionGoods a,#tempSupNo b
 where a.cSupNo=b.cSupplierNo
order by i,a.cSupNo

/*获取时间段的入库记录 日期以单据日期为判断。*/

/*删除临时表*/
if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
GO
