
/*
--原来毛利脚本

if(select object_id('tempdb..#temp_SupplierNo')) is not null drop table  #temp_SupplierNo 
select distinct cGoodsno,cSupplierNo=cSupNo into #temp_SupplierNo from t_goods  where cGoodsNo='115561' --or csupno='1001'

if (select object_id('tempdb..#temp_Goods')) is not null
		drop table #temp_Goods
		Create Table #temp_Goods (
		cGoodsNo varchar(128),
		cProductNo varchar(128),
		cSupplierNo varchar(128))
 
	if  (select object_id('tempdb..#tempSupNo')) is not null
	drop table #tempSupNo
	select distinct cSupplierNo=csupno into #tempSupNo from t_Supplier
	-- where cSupplierNo='1001'
    insert into #temp_Goods(cGoodsno,cSupplierNo)
    select distinct a.cGoodsno,b.cSupplierNo   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where b.cSupplierNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsno,cSupplierNo=a.cSupno from t_goods a left join t_goods b
    on a.cGoodsNo=b.cGoodsNo where  a.cSupNo in (select cSupplierNo from #tempSupNo)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_goods where cSupNo in (select cSupplierNo from #tempSupNo))
    union
    select distinct a.cGoodsno,a.cSupno from  t_goods a
    where  a.cSupNo in (select cSupplierNo from #tempSupNo)

if (select object_id('U_Key.dbo.temp_Goods'))is not null
drop table U_Key.dbo.temp_Goods
-- 取相应类别下的商品。。。 				
 select cGoodsNo into U_Key.dbo.temp_Goods from t_Goods
 where cGoodsTypeNo like '33%'
 
if (select object_id('U_Key.dbo.temp_cStore'))is not null
drop table U_Key.dbo.temp_cStore
-- 取相应类别下的商品。。。 				
 select cStoreNO into U_Key.dbo.temp_cStore from t_Store
 where cStoreNo='1001'
  
exec [p_FIFO_SalesProfit_MultGoods_log_Store_TermID_App_02] '000','2017-2-20','2017-2-20','00','','','1',''
go

exec [p_FIFO_SalesProfit_MultGoods_log_Store_TermID_App_02] '1001','2017-2-20','2017-2-20','01001','','','2',''
go

exec [p_FIFO_SalesProfit_MultGoods_log_TermID_App_03] '1001','2017-2-20','2017-2-20','01001','','10','4',''
go

http://192.168.50.99:1238/AppServer/GetSaleList.aspx?action=RQTYPESALEMLGROUP0&
d1=2017-02-20&d2=2017-02-20&cStoreNo=000&GroupNoMax=1&NoType=1&GroupNo=

1.@NoType=1 表示第一个界面 返回门店，@NoType=2 范围部组，@NoType=3 返回部组
2.GroupNoMax=0 第一个界面 ，GroupNoMax=1 第二个界面 ，GroupNoMax=1 第三个界面


*/              
create procedure [dbo].[p_FIFO_SalesProfit_MultGoods_log_TermID_App_03_test]
@cStoreNo varchar(32),
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@cTermID varchar(32),
@GroupNo varchar(32),
@NoType varchar(8),  -- @NoType=1 表示第一个界面 返回门店，@NoType=2范围部组，@NoType=3 返回部组
@GroupMax varchar(8)
as  --查询某时段 商品销售利润（含顾客退货）
 --print dbo.getTimeStr(GETDATE())+'  0000'	
 
if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
create table #tmpCostGoodsList(cGoodsNo varchar(32),bFresh bit)

if (select object_id('tempdb..#tmp_StoreNo'))is not null drop table #tmp_StoreNo
create table #tmp_StoreNo(cStoreNo varchar(32))

declare @cParentNo varchar(32)
set @cParentNo=(select cParentNo from t_Store where cStoreNo=@cStoreNo)

if @NoType='3' 
begin
        if (select object_id('tempdb..#tmpGroupType0'))is not null drop table #tmpGroupType0
		select cGroupTypeNo,cParentNo
		into #tmpGroupType0
		from T_GroupType where cPath+'.' like '%.'+@GroupNo+'.%'

		--if (select object_id('tempdb..#tmpGroupType1'))is not null drop table #tmpGroupType1
		--select cGroupTypeNo into #tmpGroupType1
		--from #tmpGroupType0 where cGroupTypeNo not in (select cParentNo from #tmpGroupType0)

		 
		if (select object_id('tempdb..#tmpGroupType2'))is not null drop table #tmpGroupType2
		select a.cGoodsTypeNo  into #tmpGroupType2
		from T_GroupType_GoodsType a,#tmpGroupType0 b
		where a.cGroupTypeNo=b.cGroupTypeNo
		
		insert into #tmpCostGoodsList(cGoodsno)
	    select distinct b.cGoodsno
	    from #tmpGroupType2  a,t_Goods b
	    where a.cGoodsTypeNo=b.cGoodsTypeno 
 
end else if @NoType='4' 
begin
        if (select object_id('tempdb..#tmpGroupType0_1'))is not null drop table #tmpGroupType0_1
		select cGroupTypeNo,cParentNo
		into #tmpGroupType0_1
		from T_GroupType where cPath+'.' like '%.'+@GroupNo+'.%'

		--if (select object_id('tempdb..#tmpGroupType1_1'))is not null drop table #tmpGroupType1_1

		--select cGroupTypeNo into #tmpGroupType1_1
		--from #tmpGroupType0_1 where cGroupTypeNo not in (select cParentNo from #tmpGroupType0_1)
    
		 
		if (select object_id('tempdb..#tmpGroupType2_1'))is not null drop table #tmpGroupType2_1
		select a.cGoodsTypeNo  into #tmpGroupType2_1
		from T_GroupType_GoodsType a,#tmpGroupType0_1 b
		where a.cGroupTypeNo=b.cGroupTypeNo
		
 
		
		insert into #tmpCostGoodsList(cGoodsno)
	    select distinct b.cGoodsno
	    from #tmpGroupType2_1  a,t_Goods b
	    where a.cGoodsTypeNo=b.cGoodsTypeno 
 
end else
begin
   if @GroupMax='0'
   begin
        if @GroupNo=''  
        begin
            insert into #tmpCostGoodsList(cGoodsno)
		   select distinct b.cGoodsno
		   from (select distinct cGoodsTypeNo from T_GroupType_GoodsType)  a,t_Goods b
		   where a.cGoodsTypeNo=b.cGoodsTypeno 
        end else
        begin
			if (select object_id('tempdb..#tmpGroupType01'))is not null drop table #tmpGroupType01
			select cGroupTypeNo,cParentNo
			into #tmpGroupType01
			from T_GroupType where cPath+'.' like '%.'+@GroupNo+'.%'

			if (select object_id('tempdb..#tmpGroupType11'))is not null drop table #tmpGroupType11

			select cGroupTypeNo into #tmpGroupType11
			from #tmpGroupType01 where cGroupTypeNo not in (select cParentNo from #tmpGroupType01)

			 
			if (select object_id('tempdb..#tmpGroupType21'))is not null drop table #tmpGroupType21
			select a.cGoodsTypeNo  into #tmpGroupType21
			from T_GroupType_GoodsType a,#tmpGroupType01 b
			where a.cGroupTypeNo=b.cGroupTypeNo
			
			insert into #tmpCostGoodsList(cGoodsno)
			select distinct b.cGoodsno
			from #tmpGroupType21  a,t_Goods b
			where a.cGoodsTypeNo=b.cGoodsTypeno 
			
	    end
   end else
   begin   
	   insert into #tmpCostGoodsList(cGoodsno)
	   select distinct b.cGoodsno
	   from (select distinct cGoodsTypeNo from T_GroupType_GoodsType)  a,t_Goods b
	   where a.cGoodsTypeNo=b.cGoodsTypeno 
	   
   end
end


if @cParentNo='--'
begin
   
   insert into #tmp_StoreNo(cStoreNo)
   select  cStoreNo 
   from  t_Store  
   where cStoreNo<>@cStoreNo and ISNULL(bOpen,0)=1
   
end else
begin
   
   insert into #tmp_StoreNo(cStoreNo) values(@cStoreNo)
   
end

-- where cGoodsNo='112187'
 --print dbo.getTimeStr(GETDATE())+'  00001'	
 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsno,bFresh,cStoreNo into  #tmp_WhGoodsList  from (
select distinct a.cGoodsno,bfresh=isnull(b.bfresh,0),b.cStoreNo
from #tmpCostGoodsList a,t_cStoreGoods b,#tmp_StoreNo c
where a.cgoodsno=b.cgoodsno and b.cStoreNo=c.cStoreNo
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsno,bfresh=isnull(b.bfresh,0),b.cStoreNo
from #tmpCostGoodsList a,t_cStoreGoods b,#tmp_StoreNo c
where a.cgoodsno=b.cgoodsno and b.cStoreNo=c.cStoreNo
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))=''
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,bfresh=isnull(b.bfresh,0),b.cStoreNo   ---有关联包装的 供应商不一致的。。 
from #tmpCostGoodsList a,t_cStoreGoods b,#tmp_StoreNo c
where a.cgoodsno=b.cgoodsno and b.cStoreNo=c.cStoreNo 
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
) a
 

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)

 --print dbo.getTimeStr(GETDATE())+'  00002'	
 
----print dbo.getTimeStr(GETDATE())
----print 2

/*修改主供应商-- 有入库、但是该商品为不管理库存、*/
 
declare @dDateBgn datetime,@dDateEnd datetime
set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  

declare  @cdbname varchar(32)
declare  @Rdbname varchar(32)
select distinct @cdbname=Pos_WH_Form,@Rdbname=cdbname from dbo.t_WareHouse --where cWhNo=@cWHno

--print dbo.getTimeStr(GETDATE())+'  0001'	

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cStoreNo] [varchar](32) NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money,bfresh money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cStoreNo] [varchar](32) NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null,
  销售数量0 money, 销售金额0 money, 特价销售数量 money, 特价销售金额 money, 
  正价销售数量 money, 正价销售金额 money, 本日库存数量 money,fmoney_koudian money,
  fPrice_Avg money,fml money,fmoney_cost money,bfresh money)
  
 /*快照表中的最大日期。。。*/
 
declare @maxWhdDate datetime
if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 a,#tmp_StoreNo b
where a.cStoreNo=b.cStoreNo  group by b.cStoreNo')
set @maxWhdDate=(select min(dDate) from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end

--print dbo.getTimeStr(GETDATE())+'   0002'	
-----查最大日结时间内信息@dDateBegin到@dDateEnd
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo,bfresh,cStoreNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn)
declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@dDateBgn-1)
set @M_1=MONTH(@dDateBgn-1)
set @Day_1=day(@dDateBgn-1)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1
if @Y1<>@Y_1
begin
    declare @bY1 varchar(8)
	declare @eY1  varchar(8)
	 
	set @bY1 =Year(@dDateBgn)
	set @eY1=Year(@maxWhdDate) 
	declare @bM1 varchar(8)
	declare @eM1  varchar(8)
	 
	set @bM1 =Month(@dDateBgn)
	set @eM1=Month(@maxWhdDate) 
	if LEN(@bM1)=1 
	begin
	   set @bM1='0'+@bM1
	end
	if LEN(@eM1)=1 
	begin
	   set @eM1='0'+@eM1
	end
	declare @tj varchar(8)
    set @tj='0'
	if(@bY1<>@eY1)
	begin
		set @tj='1'
    end else
    begin
      if @bM1=@eM1
      begin
      exec('
		--------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cGoodsno,b.cStoreNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
		fQty0=b.fQty_010131,fQtytj0=b.fQtytj_010131,a.bFresh
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo  and b.cStoreNo=a.cStoreNo
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale	            
		select a.cGoodsno,b.cStoreNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+' ,
		Sale0=b.Sale_010131, Saletj0=b.Saletj_010131,a.bFresh
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo and b.cStoreNo=a.cStoreNo 


		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cGoodsno,cStoreNo,bFresh,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1),
		fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cGoodsno,bFresh,cStoreNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cGoodsno,cStoreNo,bFresh,Sale1=sum(Sale1), 
		Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cGoodsno,bFresh,cStoreNo
		 
		 
		
		insert into #temp_WhFromend(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
		select cGoodsno,cStoreNo,bFresh,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))
		from #temp_SumWh_Goods_endQty
	 
		 
		update a  
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))     				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
						
	----------百货 期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,b.cStoreNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and  b.cGoodsNo=a.cGoodsNo  and b.cStoreNo=a.cStoreNo 
		and isnull(a.bFresh,0)=0
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno,cStoreNo
		

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
		
		----------生鲜入库
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostFresh''))is not null  drop table #temp_Wh_Goods_endCostFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endCostFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCostFresh''))is not null  drop table #temp_SumWh_Goods_endCostFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCostFresh
		from  #temp_Wh_Goods_endCostFresh
		group by cGoodsno,cStoreNo
		
		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)
		from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
		----------生鲜调拨入库
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrInFresh''))is not null  drop table #temp_Wh_Goods_endTfrInFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endTfrInFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrInFresh''))is not null  drop table #temp_SumWh_Goods_endTfrInFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endTfrInFresh
		from  #temp_Wh_Goods_endTfrInFresh
		group by cGoodsno,cStoreNo
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney1,0)-isnull(b.fMoney0,0)
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrInFresh b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
		----------生鲜调拨出
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrFresh''))is not null  drop table #temp_Wh_Goods_endTfrFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endTfrFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrFresh''))is not null  drop table #temp_SumWh_Goods_endTfrFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endTfrFresh
		from  #temp_Wh_Goods_endTfrFresh
		group by cGoodsno,cStoreNo
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrFresh b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
		
		----------生鲜退货出
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRetOutFresh''))is not null  drop table #temp_Wh_Goods_endRetOutFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_010131,fMoney0=b.fMoneyIn_010131 	 					 
		into #temp_Wh_Goods_endRetOutFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRetOutFresh''))is not null  drop table #temp_SumWh_Goods_endRetOutFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endRetOutFresh
		from  #temp_Wh_Goods_endRetOutFresh
		group by cGoodsno,cStoreNo
		
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))
		from #temp_WhFromend a ,#temp_SumWh_Goods_endRetOutFresh b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
		update a 
		set fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(a.fmoney_cost,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(a.fmoney_cost,0))		
		from #temp_WhFromend  a
		where isnull(bFresh,0)=1
		
        /*
		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		*/
		

		')
	  end else
	  begin
	    set @tj='1' 
	  end
    end
    if @tj='1'
    begin
         exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,bFresh,a.cStoreNo,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select a.cGoodsno,bFresh,a.cStoreNo,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,bFresh,cStoreNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cGoodsno,bFresh,cStoreNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,bFresh,cStoreNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cGoodsno,bFresh,cStoreNo
			 
			 
			
			insert into #temp_WhFrombegin(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
			select cGoodsno,cStoreNo,bFresh,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo  
							
		    ----------百货期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(a.bFresh,0)=0
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			 
			----------生鲜期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCostFresh''))is not null  drop table #temp_Wh_Goods_beginCostFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCostFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCostFresh''))is not null  drop table #temp_SumWh_Goods_beginCostFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCostFresh
			from  #temp_Wh_Goods_beginCostFresh
			group by cGoodsno,cStoreNo
			
            --print 1000
			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginCostFresh b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
            --print 1000000002
            
            ----------生鲜调拨入期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrInFresh''))is not null  drop table #temp_Wh_Goods_beginTfrInFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrInFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrInFresh''))is not null  drop table #temp_SumWh_Goods_beginTfrInFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrInFresh
			from  #temp_Wh_Goods_beginTfrInFresh
			group by cGoodsno,cStoreNo
			
            --print 1000
			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney,0)	
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrInFresh b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
            --print 1000000002
            
             ----------生鲜调拨出期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrFresh''))is not null  drop table #temp_Wh_Goods_beginTfrFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrFresh''))is not null  drop table #temp_SumWh_Goods_beginTfrFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrFresh
			from  #temp_Wh_Goods_beginTfrFresh
			group by cGoodsno,cStoreNo
			
			
            --print 1000
			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)	
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrFresh b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
            --print 1000000002
            
             ----------生鲜退货出期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginRetOutFresh''))is not null  drop table #temp_Wh_Goods_beginRetOutFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginRetOutFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginRetOutFresh''))is not null  drop table #temp_SumWh_Goods_beginRetOutFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginRetOutFresh
			from  #temp_Wh_Goods_beginRetOutFresh
			group by cGoodsno,cStoreNo
			
			
            --print 1000
			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)	
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginRetOutFresh b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
            --print 1000000002
            
            
            
            
			') 
       --print 1000000003
		exec('
		    --print 1001
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,a.cStoreNo,bFresh,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		   
		    --print 1002

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,a.cStoreNo,bFresh,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cStoreNo,bFresh,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cGoodsno,bFresh,cStoreNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,cStoreNo,bFresh,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cGoodsno,bFresh,cStoreNo
			 
			 
			
			insert into #temp_WhFromend(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
			select cGoodsno,cStoreNo,bFresh,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo   and a.cStoreNo=b.cStoreno
							
		----------百货期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(a.bFresh,0)=0
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
			
			----------生鲜期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostFresh''))is not null  drop table #temp_Wh_Goods_endCostFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCostFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCostFresh''))is not null  drop table #temp_SumWh_Goods_endCostFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCostFresh
			from  #temp_Wh_Goods_endCostFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
            ----------生鲜调拨入期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrInFresh''))is not null  drop table #temp_Wh_Goods_endTfrInFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrInFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrInFresh''))is not null  drop table #temp_SumWh_Goods_endTfrInFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrInFresh
			from  #temp_Wh_Goods_endTfrInFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrInFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜调拨出期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrFresh''))is not null  drop table #temp_Wh_Goods_endTfrFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrFresh''))is not null  drop table #temp_SumWh_Goods_endTfrFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrFresh
			from  #temp_Wh_Goods_endTfrFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜退货出期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRetOutFresh''))is not null  drop table #temp_Wh_Goods_endRetOutFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endRetOutFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRetOutFresh''))is not null  drop table #temp_SumWh_Goods_endRetOutFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endRetOutFresh
			from  #temp_Wh_Goods_endRetOutFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endRetOutFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			')

		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
		a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
		a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
		a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
		a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0),	 
		a.fPrice_Avg=case when isnull(a.销售数量0,0)-isnull(b.销售数量0,0)<>0 
		then (ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))
		from #temp_WhFromend a left join #temp_WhFrombegin b
		on a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
    end
end else
begin
    if @M1=@M_1
    begin
      --print dbo.getTimeStr(GETDATE())+'   0003'	
	exec('
		--------期末销售
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
		select a.cGoodsno,bFresh,a.cStoreNo,fQty1=b.fQty_'+@MMDAY1+',fQtytj1=b.fQtytj_'+@MMDAY1+',
		fQty0=b.fQty_'+@MMDAY_1+',fQtytj0=b.fQtytj_'+@MMDAY_1+'  
		into #temp_Wh_Goods_endQty
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
 
	 

		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale	            
		select a.cGoodsno,bFresh,a.cStoreNo,Sale1=b.Sale_'+@MMDAY1+', Saletj1=b.Saletj_'+@MMDAY1+' ,
		Sale0=b.Sale_'+@MMDAY_1+', Saletj0=b.Saletj_'+@MMDAY_1+'
		into #temp_Wh_Goods_endSale					
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo
 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
		select cGoodsno,bFresh,cStoreNo,fQty1=sum(fQty1), fQtytj1=sum(fQtytj1),
		fQty0=sum(fQty0), fQtytj0=sum(fQtytj0)  
		into #temp_SumWh_Goods_endQty
		from  #temp_Wh_Goods_endQty
		group by cGoodsno,bFresh,cStoreNo
		
		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
		select cGoodsno,bFresh,cStoreNo,Sale1=sum(Sale1), 
		Saletj1=sum(Saletj1),Sale0=sum(Sale0), Saletj0=sum(Saletj0) 
		into #temp_SumWh_Goods_endSale
		from  #temp_Wh_Goods_endSale
		group by cGoodsno,bFresh,cStoreNo 
		
		insert into #temp_WhFromend(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
		select cGoodsno,cStoreNo,bFresh,isnull(fQty1,0)-isnull(fQty0,0),
		isnull(fQtytj1,0)-isnull(fQtytj0,0),
		(isnull(fQty1,0)-isnull(fQtytj1,0))-(isnull(fQty0,0)-isnull(fQtytj0,0))
		from #temp_SumWh_Goods_endQty
	 
		 
		update a  
		set a.销售金额0=isnull(b.Sale1,0)-isnull(b.Sale0,0),
		a.特价销售金额=isnull(b.Saletj1,0)-isnull(b.Saletj0,0),
		a.正价销售金额=(isnull(b.Sale1,0)-isnull(b.Saletj1,0))-(isnull(b.Sale0,0)-isnull(b.Saletj0,0))     				
		from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
						
	----------百货期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endCost
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=0
	     
 
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCost
		from  #temp_Wh_Goods_endCost
		group by cGoodsno,cStoreNo
		
 

		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_SumWh_Goods_endCost b
		where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
		
 
		----------生鲜期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostFresh''))is not null  drop table #temp_Wh_Goods_endCostFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyInPc_'+@MMDAY_1+',fMoney0=b.fMoneyInPc_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endCostFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCostFresh''))is not null  drop table #temp_SumWh_Goods_endCostFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endCostFresh
		from  #temp_Wh_Goods_endCostFresh
		group by cGoodsno,cStoreNo
		
		
		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0)
		from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo 
		
		
		
        ----------生鲜调拨入期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrInFresh''))is not null  drop table #temp_Wh_Goods_endTfrInFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyInPc_'+@MMDAY_1+',fMoney0=b.fMoneyInPc_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endTfrInFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrInFresh''))is not null  drop table #temp_SumWh_Goods_endTfrInFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endTfrInFresh
		from  #temp_Wh_Goods_endTfrInFresh
		group by cGoodsno,cStoreNo
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney1,0)-isnull(b.fMoney0,0)
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrInFresh b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo 
		
		 ----------生鲜调拨出期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrFresh''))is not null  drop table #temp_Wh_Goods_endTfrFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyInPc_'+@MMDAY1+',fMoney1=b.fMoneyInPc_'+@MMDAY1+',
		fQty0=b.fQtyInPc_'+@MMDAY_1+',fMoney0=b.fMoneyInPc_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endTfrFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrFresh''))is not null  drop table #temp_SumWh_Goods_endTfrFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endTfrFresh
		from  #temp_Wh_Goods_endTfrFresh
		group by cGoodsno,cStoreNo
		
		
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))
		from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrFresh b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo 
		
		
         ----------生鲜退货出期末成本
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRetOutFresh''))is not null  drop table #temp_Wh_Goods_endRetOutFresh
		select a.cGoodsno,a.cStoreNo,fQty1=b.fQtyIn_'+@MMDAY1+',fMoney1=b.fMoneyIn_'+@MMDAY1+',
		fQty0=b.fQtyIn_'+@MMDAY_1+',fMoney0=b.fMoneyIn_'+@MMDAY_1+' 	 					 
		into #temp_Wh_Goods_endRetOutFresh
		from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
		with (nolock) 
		where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		and isnull(bFresh,0)=1
	 

		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRetOutFresh''))is not null  drop table #temp_SumWh_Goods_endRetOutFresh
		select cGoodsno,cStoreNo,fQty1=sum(fQty1), fMoney1=sum(fMoney1),fQty0=sum(fQty0), fMoney0=sum(fMoney0)  
		into #temp_SumWh_Goods_endRetOutFresh
		from  #temp_Wh_Goods_endRetOutFresh
		group by cGoodsno,cStoreNo
		
		
		
		update a 
		set a.fmoney_cost=isnull(a.fmoney_cost,0)-(isnull(b.fMoney1,0)-isnull(b.fMoney0,0))
		from #temp_WhFromend a ,#temp_SumWh_Goods_endRetOutFresh b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo 
		
		update a 
		set  
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(a.fmoney_cost,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(a.fmoney_cost,0))		
		from #temp_WhFromend a 
		where isnull(bFresh,0)=1 
		
        /*
		update a 
		set a.fmoney_cost=isnull(b.fMoney1,0)-isnull(b.fMoney0,0),
		a.fPrice_Avg=case when isnull(a.销售数量0,0)<>0 
		then (ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))/(isnull(a.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0))-(ISNULL(b.fMoney1,0)-ISNULL(b.fMoney0,0))		
		from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo 
		*/

		')
	--print dbo.getTimeStr(GETDATE())+'   0004'		
	end else
	begin
	  exec('
		 
		--------期初销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cGoodsno,a.cStoreNo,bFresh,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select a.cGoodsno,a.cStoreNo,bFresh,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cGoodsno,cStoreNo,bFresh,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cGoodsno,bFresh,cStoreNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cGoodsno,cStoreNo,bFresh,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cGoodsno,bFresh,cStoreNo
			 
			 
			
			insert into #temp_WhFrombegin(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
			select cGoodsno,cStoreNo,bFresh,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
			from #temp_SumWh_Goods_beginQty
		 
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
							
		----------百货期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=0
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCost
			from  #temp_Wh_Goods_beginCost
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginCost b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			
			----------生鲜期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCostFresh''))is not null  drop table #temp_Wh_Goods_beginCostFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginCostFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_IN_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCostFresh''))is not null  drop table #temp_SumWh_Goods_beginCostFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginCostFresh
			from  #temp_Wh_Goods_beginCostFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginCostFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
            ----------生鲜调拨入期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrInFresh''))is not null  drop table #temp_Wh_Goods_beginTfrInFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrInFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrInFresh''))is not null  drop table #temp_SumWh_Goods_beginTfrInFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrInFresh
			from  #temp_Wh_Goods_beginTfrInFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney,0)		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrInFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜调拨出期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginTfrFresh''))is not null  drop table #temp_Wh_Goods_beginTfrFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY_1+',fMoney=b.fMoneyInPc_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginTfrFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginTfrFresh''))is not null  drop table #temp_SumWh_Goods_beginTfrFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginTfrFresh
			from  #temp_Wh_Goods_beginTfrFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginTfrFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜退货出期初成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginRetOutFresh''))is not null  drop table #temp_Wh_Goods_beginRetOutFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
			into #temp_Wh_Goods_beginRetOutFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M_1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y_1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			and isnull(bFresh,0)=1
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginRetOutFresh''))is not null  drop table #temp_SumWh_Goods_beginRetOutFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_beginRetOutFresh
			from  #temp_Wh_Goods_beginRetOutFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginRetOutFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			
			') 

		exec('
			--------期末销售
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cGoodsno,a.cStoreNo,bFresh,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo 
			 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cGoodsno,a.cStoreNo,bFresh,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  b.cGoodsNo=a.cGoodsNo


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cGoodsno,cStoreNo,bFresh,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cGoodsno,bFresh,cStoreNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cGoodsno,cStoreNo,bFresh,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cGoodsno,bFresh,cStoreNo
			 
			 
			
			insert into #temp_WhFromend(cGoodsno,cStoreNo,bFresh,销售数量0,特价销售数量,正价销售数量)
			select cGoodsno,cStoreNo,bFresh,fQty,fQtytj,isnull(fQty,0)-isnull(fQtytj,0)	
			from #temp_SumWh_Goods_endQty
		 
			 
			update a 
			set a.销售金额0=b.Sale, 
			a.特价销售金额=b.Saletj,
			a.正价销售金额=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
							
		----------百货期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCost
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
			and isnull(a.bFresh,0)=0
		 

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCost
			from  #temp_Wh_Goods_endCost
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endCost b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCostFresh''))is not null  drop table #temp_Wh_Goods_endCostFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endCostFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_In_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
		    and isnull(bFresh,0)=1
		   

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCostFresh''))is not null  drop table #temp_SumWh_Goods_endCostFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endCostFresh
			from  #temp_Wh_Goods_endCostFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=b.fMoney		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endCostFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo

            ----------生鲜调拨入期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrInFresh''))is not null  drop table #temp_Wh_Goods_endTfrInFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrInFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_TfrIn_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
		    and isnull(bFresh,0)=1
		   

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrInFresh''))is not null  drop table #temp_SumWh_Goods_endTfrInFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrInFresh
			from  #temp_Wh_Goods_endTfrInFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)+isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrInFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜调拨出期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endTfrFresh''))is not null  drop table #temp_Wh_Goods_endTfrFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyInPc_'+@MMDAY1+',fMoney=b.fMoneyInPc_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endTfrFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_Tfr_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
		    and isnull(bFresh,0)=1
		   

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endTfrFresh''))is not null  drop table #temp_SumWh_Goods_endTfrFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endTfrFresh
			from  #temp_Wh_Goods_endTfrFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endTfrFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			----------生鲜退货出期末成本
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endRetOutFresh''))is not null  drop table #temp_Wh_Goods_endRetOutFresh
			select a.cGoodsno,a.cStoreNo,fQty=b.fQtyIn_'+@MMDAY1+',fMoney=b.fMoneyIn_'+@MMDAY1+' 					 
			into #temp_Wh_Goods_endRetOutFresh
			from '+@cdbname+'.dbo.t_WH_Form_Log_Day_RetOut_'+@M1+' b,#tmp_WhGoodsList_cGoodsno a
			with (nolock) 
			where b.cyear='''+@Y1+''' and b.cStoreNo=a.cStoreNo and  a.cGoodsNo=b.cGoodsNo 
		    and isnull(bFresh,0)=1
		   

			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endRetOutFresh''))is not null  drop table #temp_SumWh_Goods_endRetOutFresh
			select cGoodsno,cStoreNo,fQty=sum(fQty), fMoney=sum(fMoney) 
			into #temp_SumWh_Goods_endRetOutFresh
			from  #temp_Wh_Goods_endRetOutFresh
			group by cGoodsno,cStoreNo
			

			update a 
			set a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fMoney,0)		
			from #temp_WhFromend a ,#temp_SumWh_Goods_endRetOutFresh b
			where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
			
			
			')

		update a 
		set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
		a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
		a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
		a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
		a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
		a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),	
		a.fmoney_cost=ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0),	 
		a.fPrice_Avg=case when isnull(a.销售数量0,0)-isnull(b.销售数量0,0)<>0 
		then (ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))/(isnull(a.销售数量0,0)-isnull(b.销售数量0,0)) end,
		a.fml=(isnull(a.销售金额0,0)-isnull(b.销售金额0,0))-(ISNULL(a.fmoney_cost,0)-ISNULL(b.fmoney_cost,0))
		from #temp_WhFromend a left join #temp_WhFrombegin b
		on a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo
	end   
end


/*注意一品多商的情况*/
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cStoreNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,--销售数量
   fLastSettle money,--卖价
   fMoneyCost money,--进价
   fMoneyRatio money,--毛利
   fRatio money, --毛利率
   bAuditing int,
   fAvg_price money
)

insert into #GetGoodsListFormBase
(	cGoodsno,cStoreNo )
select distinct cGoodsno,cStoreNo  from #tmp_WhGoodsList

	--- 取记账之前的数据... 
 if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
        create table #temp_ReadyKucun(
		cGoodsNo varchar(32),cStoreNo varchar(32),cUnitedNo varchar(32), csupno varchar(32),csuplierno varchar(32), 
		cGoodsName varchar(64),cBarcode varchar(32),cUnit varchar(32),cSpec varchar(32),
		fNormalPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),bProducted bit ,cProductNo  varchar(32),
		fMoney_Cost money,fProfitRatio money,fMoney_Profit_sum money,
		fProfitRatio_avg money,xsQty money,xsMoney money,fCostPrice money,fML money
)
--print dbo.getTimeStr(GETDATE())+'  0005'	 
if 	@maxWhdDate<@dDateEnd
begin
	 --select '2',@dDate_1,@dDate_2
	  --exec p_FIFO_SalesProfit_GoodsType_log_wei @dDate_1,@dDate_2,@cWHno
	  
	  if (select OBJECT_ID('tempdb..#temp_goodsForSelect'))is not null drop table #temp_goodsForSelect
      if (select OBJECT_ID('tempdb..#t_SaleSheetDetail_shelf'))is not null drop table #t_SaleSheetDetail_shelf
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_p'))is not null drop table #GetGoodsListFormBase_p
      if (select OBJECT_ID('tempdb..#GetGoodsListFormBase_R'))is not null drop table #GetGoodsListFormBase_R
      --select distinct cGoodsNo  into #temp_goodsForSelect from #tmpCostGoodsList
      --#tmp_WhGoodsList
      select distinct cGoodsNo,cStoreNo  into #temp_goodsForSelect from #tmp_WhGoodsList
      
	  select dSaleTime=b.dSaleDate,a.cGoodsno,b.fQuantity,b.fLastSettle,bAuditing='0',a.cStoreNo
      into #t_SaleSheetDetail_shelf
      from #temp_goodsForSelect a, t_SaleSheetDetail b
      where (b.dSaleDate between @dDate_1 and @dDate_2) and a.cGoodsNo=b.cGoodsNo 
      and b.cStoreNo=a.cStoreNo --and b.cWHno=@cWHno 
      union all
      select c.dDate,a.cGoodsno,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney,bAuditing='0',a.cStoreNo
      from #temp_goodsForSelect a,WH_ReturnGoodsDetail b,WH_ReturnGoods c
      where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between @dDate_1 and @dDate_2)
      and c.cStoreNo=a.cStoreNo and c.cWHno=@cWHno 
            
          
            
      /*---包装转单品*/
			if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null 		drop table #tmpPackGoodsList
			select cGoodsno,cGoodsNo_MinPackage,fQty_minPackage=isnull(fQty_minPackage,1)
			into #tmpPackGoodsList
			from t_goods
			where cGoodsNO<>isnull(cGoodsNo_MinPackage,cGoodsNo)

			update a
			set a.cGoodsNo=b.cGoodsNo_MinPackage,
					a.fQuantity=a.fQuantity*b.fQty_minPackage
			from #t_SaleSheetDetail_shelf a, #tmpPackGoodsList b
			where a.cGoodsNO=b.cGoodsNO
---销售数量

      select dSaleTime=@dDate1,a.cGoodsno,a.cStoreNo,a.bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
             fMoneyCost=cast(0 as money),fMoneyRatio=cast(0 as money),fRatio=cast(0 as money),
             cSupno=CAST(null as varchar(32))
      into #GetGoodsListFormBase_p 
      from (
						select cGoodsno,bAuditing,cStoreNo,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0))
						from #t_SaleSheetDetail_shelf 
						where dSaleTime between @dDate_1 and @dDate_2
						group by cGoodsno,bAuditing,cStoreNo
           ) a
      group by a.cGoodsno,a.bAuditing,a.cStoreNo
  
 
	  select cGoodsno,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fLastSettle=sum(isnull(fLastSettle,0)),
		   fMoneyCost=sum(isnull(fMoneyCost,0)),
		   fMoneyRatio=sum(isnull(fMoneyRatio,0)),fRatio=avg(isnull(fRatio,0)),cStoreNo
	  into #GetGoodsListFormBase_R
	  from #GetGoodsListFormBase_p 
	  group by cGoodsno,bAuditing,cStoreNo
	  
	  
	  
	  drop table #GetGoodsListFormBase_p
--销售成本 
/*
	  select cGoodsno,fPrice_Avg from #temp_end
*/			
      ---平均价
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg0'))is not null drop table #temp_fPrice_Avg0
      if (select OBJECT_ID('tempdb..#temp_fPrice_Avg'))is not null drop table #temp_fPrice_Avg
      select a.cGoodsno,a.cStoreNo,fPrice_Avg=case when ISNULL(c.fCKPrice,0)=0 
      --then c.fNormalPrice
      then c.fPrice_Contract  
      else c.fCKPrice end
      into #temp_fPrice_Avg
      from #GetGoodsListFormBase a left join t_cStoreGoods c
      on a.cGoodsNo=c.cGoodsNo
      where c.cStoreNo=a.cStoreNo 
      and ISNULL(c.bfresh,0)=0
  
  
     
	  update a
	  set a.fMoneyCost=isnull(a.fQuantity,0)*b.fPrice_Avg	  
	  from #GetGoodsListFormBase_R a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
	  
	  
	  update a
	  set a.fAvg_price=b.fPrice_Avg	  
	  from #GetGoodsListFormBase a,#temp_fPrice_Avg b
	  where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
	  
	  
	  update a
	  set a.fQuantity=isnull(b.fQuantity,0),a.fLastSettle=isnull(b.fLastSettle,0),
		a.fMoneyCost=isnull(b.fMoneyCost,0),
		a.fMoneyRatio=isnull(b.fLastSettle,0)-isnull(b.fMoneyCost,0),a.fRatio=isnull(b.fRatio,0)
	  from #GetGoodsListFormBase a,#GetGoodsListFormBase_R b
	  where a.cGoodsNo=b.cGoodsNo
	  and a.cStoreNo=b.cStoreNo  
	  
	  
      --- 获取百货时间段入库金额
		  if (select OBJECT_ID('tempdb..#temp_fPrice_InFresh'))is not null drop table #temp_fPrice_InFresh
		  select b.cGoodsNo,b.fQuantity,b.fInMoney,a.cStoreNo into #temp_fPrice_InFresh 
		  from wh_InWarehouse a,wh_InWarehouseDetail b
		  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
		  and ISNULL(a.bExamin,0)=1
	  --and  a.cStoreNo=@cStoreNo 
	  --and ISNULL(a.bfresh,0)=1
	  
		if (select OBJECT_ID('tempdb..#temp_fPrice_InFreshGoodsSum'))is not null drop table #temp_fPrice_InFreshGoodsSum
		select b.cGoodsNo,a.cStoreNo,fQtyIn=sum(isnull(fQuantity,0)),fInMoney=sum(isnull(fInMoney,0)) into #temp_fPrice_InFreshGoodsSum
		from #temp_fPrice_InFresh b,#tmp_WhGoodsList a
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		and ISNULL(a.bfresh,0)=1
		group by b.cGoodsno,a.cStoreNo


		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,
		a.fQtyIn=a.fQtyIn*b.fQty_minPackage
		from #temp_fPrice_InFreshGoodsSum a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO 
		
		
		update a
		set 
		a.fMoneyCost=isnull(b.fInMoney,0)
		from #GetGoodsListFormBase a,
		(select cGoodsNo,cStoreNo,fQtyIn=SUM(fQtyIn),fInMoney=SUM(fInMoney) from #temp_fPrice_InFreshGoodsSum group by cGoodsNo,cStoreNo ) b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		
        
          --- 获取时间段调拨入库金额
		  if (select OBJECT_ID('tempdb..#temp_fPrice_TfrInFresh'))is not null drop table #temp_fPrice_TfrInFresh
		  select b.cGoodsNo,b.fQuantity,b.fInMoney,a.cStoreNo into #temp_fPrice_TfrInFresh 
		  from wh_TfrInWarehouse a,wh_TfrInWarehouseDetail b
		  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
		  and ISNULL(a.bExamin,0)=1
	     
	  
		if (select OBJECT_ID('tempdb..#temp_fPrice_TfrInFreshGoodsSum'))is not null drop table #temp_fPrice_TfrInFreshGoodsSum
		select b.cGoodsNo,a.cStoreNo,fQtyIn=sum(isnull(fQuantity,0)),fInMoney=sum(isnull(fInMoney,0)) into #temp_fPrice_TfrInFreshGoodsSum
		from #temp_fPrice_TfrInFresh b,#tmp_WhGoodsList a
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		and ISNULL(a.bfresh,0)=1
		group by b.cGoodsno,a.cStoreNo


		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,
		a.fQtyIn=a.fQtyIn*b.fQty_minPackage
		from #temp_fPrice_TfrInFreshGoodsSum a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO 
		
		update a
		set 
		a.fMoneyCost=isnull(a.fMoneyCost,0)+isnull(b.fInMoney,0)
		from #GetGoodsListFormBase a,
		(select cGoodsNo,cStoreNo,fQtyIn=SUM(fQtyIn),fInMoney=SUM(fInMoney) from #temp_fPrice_TfrInFreshGoodsSum group by cGoodsNo,cStoreNo ) b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		
		--- 获取时间段调拨出库金额
		  if (select OBJECT_ID('tempdb..#temp_fPrice_TfrFresh'))is not null drop table #temp_fPrice_TfrFresh
		  select b.cGoodsNo,b.fQuantity,b.fInMoney,a.cStoreNo into #temp_fPrice_TfrFresh 
		  from wh_TfrWarehouse a,wh_TfrWarehouseDetail b
		  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
		  and ISNULL(a.bExamin,0)=1
	     
 
	  
		if (select OBJECT_ID('tempdb..#temp_fPrice_TfrFreshGoodsSum'))is not null drop table #temp_fPrice_TfrFreshGoodsSum
		select b.cGoodsNo,a.cStoreNo,fQtyIn=sum(isnull(fQuantity,0)),fInMoney=sum(isnull(fInMoney,0)) into #temp_fPrice_TfrFreshGoodsSum
		from #temp_fPrice_TfrFresh b,#tmp_WhGoodsList a
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		and ISNULL(a.bfresh,0)=1
		group by b.cGoodsno,a.cStoreNo


		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,
		a.fQtyIn=a.fQtyIn*b.fQty_minPackage
		from #temp_fPrice_TfrFreshGoodsSum a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO 
		
		update a
		set 
		a.fMoneyCost=isnull(a.fMoneyCost,0)-isnull(b.fInMoney,0)
		from #GetGoodsListFormBase a,
		(select cGoodsNo,cStoreNo,fQtyIn=SUM(fQtyIn),fInMoney=SUM(fInMoney) from #temp_fPrice_TfrFreshGoodsSum group by cGoodsNo,cStoreNo ) b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		
		--- 获取时间段退货出库金额
		  if (select OBJECT_ID('tempdb..#temp_fPrice_RetOutFresh'))is not null drop table #temp_fPrice_RetOutFresh
		  select b.cGoodsNo,b.fQuantity,b.fInMoney,a.cStoreNo into #temp_fPrice_RetOutFresh 
		  from WH_cStoreReturnGoods a,WH_cStoreReturnGoodsDetail b
		  where a.dDate between @dDate_1 and @dDate_2 and a.cSheetno=b.cSheetno
		  and ISNULL(a.bExamin,0)=1
	     
	  
		if (select OBJECT_ID('tempdb..#temp_fPrice_RetOutFreshGoodsSum'))is not null drop table #temp_fPrice_RetOutFreshGoodsSum
		select b.cGoodsNo,a.cStoreNo,fQtyIn=sum(isnull(fQuantity,0)),fInMoney=sum(isnull(fInMoney,0)) 
		into #temp_fPrice_RetOutFreshGoodsSum
		from #temp_fPrice_RetOutFresh b,#tmp_WhGoodsList a
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		and ISNULL(a.bfresh,0)=1
		group by b.cGoodsno,a.cStoreNo


		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,
		a.fQtyIn=a.fQtyIn*b.fQty_minPackage
		from #temp_fPrice_RetOutFreshGoodsSum a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO 
		
		
		
		update a
		set 
		a.fMoneyCost=isnull(a.fMoneyCost,0)-isnull(b.fInMoney,0)
		from #GetGoodsListFormBase a,
		(select cGoodsNo,cStoreNo,fQtyIn=SUM(fQtyIn),fInMoney=SUM(fInMoney) from #temp_fPrice_RetOutFreshGoodsSum group by cGoodsNo,cStoreNo ) b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		
		

		update a
		set  
		a.fMoneyRatio=ISNULL(a.fLastSettle,0)-ISNULL(a.fMoneyCost,0),
		a.fAvg_price=case when ISNULL(a.fQuantity,0)=0 then 0 else isnull(a.fMoneyCost,0)/a.fQuantity end
		from #GetGoodsListFormBase  a,t_cStoreGoods b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
		and ISNULL(b.bfresh,0)=1
 
	   
 	    drop table #GetGoodsListFormBase_R
  
 
		insert into #temp_ReadyKucun(cGoodsno,cStoreNo,xsQty,xsMoney,fMoney_Cost,fML,fCostPrice)
		select cGoodsno,cStoreNo,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle),
		fMoneyCost=SUM(fMoneyCost),fMoneyRatio=SUM(fMoneyRatio),fAvg_price from #GetGoodsListFormBase
		group by cGoodsno,fAvg_price,cStoreNo
	
end

 

--print dbo.getTimeStr(GETDATE())+'   0006'	
if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsno,cStoreNo,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,fml,fPrice_Avg
into #temp_goodsKuCunml
from #temp_WhFromend   
union all
select cGoodsno,cStoreNo,xsQty,xsMoney,fMoney_Cost,fML,fCostPrice
from #temp_ReadyKucun 



if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
select cGoodsno,cStoreNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
fPrice_Avg=AVG(fPrice_Avg)
into #temp_SumgoodsKuCunml
from #temp_goodsKuCunml
group by cGoodsno,cStoreNo

CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)


if (select OBJECT_ID('tempdb..#temp_goodsKuCun1'))is not null  drop table #temp_goodsKuCun1
select a.cGoodsno,a.cStoreNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo=b.cSupNo,b.cSupName,
BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost 
into  #temp_goodsKuCun1
from #temp_SumgoodsKuCunml a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=a.cStoreNo
order by a.cGoodsNo,a.cStoreNo

--print dbo.getTimeStr(GETDATE())+'  0007'	 

if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select cGoodsno,cStoreNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate, xsQty=SUM(xsQty), xsMoney=SUM(xsMoney), 	 
fCostPrice=avg(fCostPrice),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost),i=0
into  #temp_goodsKuCun
from #temp_goodsKuCun1
group by cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,
cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,cSupplierNo,cSupName,
BeginDate,EndDate,cStoreNo
order by cGoodsNo
	  
--print dbo.getTimeStr(GETDATE())+'  0008'	
 
---------获取时间段内的差价表。。---------
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsno,cWhNo=@cWhNo,销售数量0=CAST(0 as money),cStoreNo into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)
--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
drop table #temp_wh_DiffGoodsNo
select b.cGoodsno,a.cStoreNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
where dSaleDate between @dDate1 and @dDate2 
and a.cGoodsno=b.cGoodsNo and a.cStoreNo=b.cStoreNo
group by b.cGoodsno,a.cStoreNo

CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

update a
set 
a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo b
where a.cGoodsNo=b.cGoodsNo  and a.cStoreNo=b.cStoreNo

--print dbo.getTimeStr(GETDATE())+'  0009'	
 
 
 update  a
 set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*isnull(b.fQty_minPackage,1)
 from #temp_goodsKuCun a,t_cStoreGoods b
 where a.cgoodsno=b.cgoodsno and b.cStoreNo=a.cStoreNo and isnull(b.cGoodsNo_minPackage,'')<>''


 ---生鲜成本处理。。
 update a
 set a.fML=ISNULL(a.xsMoney,0)-ISNULL(a.fMoney_Cost,0)
 from #temp_goodsKuCun a,t_Goods b
 where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bfresh,0)=1
 
 insert into t_Log(userno,username,operation,operTime)
 select  '内置账号','内置账号',@cStoreNo+'店商品编号'+cgoodsno+'毛利异常：成本金额：'+cast(fMoney_Cost as varchar)
 +',销售金额：'+cast(xsMoney as varchar),GETDATE()
 from #temp_goodsKuCun 
 where ISNULL(fML,0)<>ISNULL(xsMoney,0)-ISNULL(fMoney_Cost,0)
 
  if(select object_id('tempdb..#temp_goodsKuCun_last_hebing')) is not null  drop table #temp_goodsKuCun_last_hebing
  
 select  cgoodsno,cStoreNo,fMoney_Cost,xsQty,xsMoney,fML=ISNULL(xsMoney,0)-ISNULL(fMoney_Cost,0),i,cSupplierNo 
 into #temp_goodsKuCun_last_hebing
 from #temp_goodsKuCun
 
 
/* 
 --------------------以上获取百货商品毛利---------

------ 获取生鲜。。
truncate table #tmpCostGoodsList
 
exec('
   insert into #tmpCostGoodsList(cGoodsno)
   select distinct a.cGoodsno
   from U_Key.dbo.temp_Goods'+@cTermID+'  a,t_Goods b
   where a.cGoodsNo=b.cGoodsNo and isnull(b.bFresh,0)=1
      
')
 
 
-------数据插入到#temp_goodsKuCun_last_hebing
exec p_FreShFIFO_SalesProfit_MultGoods_log_TermID_hebing @cStoreNo,@dDate1,@dDate2,@cWHno,@cTermID

 
*/
 if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last0
 select a.cGoodsno,a.cStoreNo,cStoreName=replace(b.cStoreName,'路发万家',a.cStoreNo),b.cUnitedNo,
 b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,
 b.cGoodsTypename,b.bProducted,b.cProductNo,
 BeginDate=@dDate1,EndDate=@dDate2,cSupplierNo,b.cSupName,fMoney_Cost=sum(fMoney_Cost),
 fCostPrice=0,
 xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),
 fML=sum(isnull(fML,0)),i
 into #temp_goodsKuCun_last0
from #temp_goodsKuCun_last_hebing a,t_cStoreGoods b
where a.cgoodsno=b.cgoodsno and b.cStoreNo=a.cStoreNo
and (ISNULL(xsQty,0)<>0 or ISNULL(fMoney_Cost,0)<>0)
group by a.cGoodsno,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo,b.cSupName,i,a.cStoreNo,b.cStoreName

 
  
if @NoType=1  --返回所有门店
begin
 
 select cStoreNo,cStoreName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last0
  group by cStoreNo,cStoreName
     
  union all
  select cStoreNo='zzzzzz',cStoreName='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last0  
  order by cStoreNo
 
end else if @NoType=2  --返回根据部组 
begin 
 
     if (select object_id('tempdb..#tmp_GoodsGroupType'))is not null drop table #tmp_GoodsGroupType
     select distinct b.cGoodsTypeNo,b.cGroupTypeNo,b.cPath
     into #tmp_GoodsGroupType
     from #temp_goodsKuCun_last0 a,T_GroupType_GoodsType b
     where a.cGoodsTypeno=b.cGoodsTypeNo
 
	 if (select object_id('tempdb..#tmpGroupType'))is not null drop table #tmpGroupType	
     select a.cGroupTypeNo,a.cGroupTypeName,b.cGoodsTypeNo   
     into #tmpGroupType
     from T_GroupType a,#tmp_GoodsGroupType b
     where b.cPath+'.' like '%.'+a.cGroupTypeNo+'.%'
     and ISNULL(a.cParentNo,'')='--'
     
     if (select object_id('tempdb..#tmpGroupType_Cost'))is not null drop table #tmpGroupType_Cost	
     select  cGoodsTypeNo=b.cGroupTypeNo,cGoodsTypename=b.cGroupTypeName,
    fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0))
         into #tmpGroupType_Cost
     from #temp_goodsKuCun_last0 a,#tmpGroupType b
     where a.cGoodsTypeno=b.cGoodsTypeNo
     group by b.cGroupTypeNo,b.cGroupTypeName
     
     select cGoodsTypeNo,cGoodsTypename,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #tmpGroupType_Cost
  group by  cGoodsTypeNo,cGoodsTypename
  union all
  select cGoodsTypeNo='zzzzzz',cGoodsTypename='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #tmpGroupType_Cost
  order by cGoodsTypeNo
  
end else if @NoType=4  --返回所有二级部组
begin
     if (select object_id('tempdb..#tmp_GoodsGroupType_01'))is not null drop table #tmp_GoodsGroupType_01
     select distinct b.cGoodsTypeNo,b.cGroupTypeNo,b.cGroupTypeName,b.cPath
     into #tmp_GoodsGroupType_01
     from #temp_goodsKuCun_last0 a,T_GroupType_GoodsType b
     where a.cGoodsTypeno=b.cGoodsTypeNo
  
     
     if (select object_id('tempdb..#tmpGroupType_Cost_01'))is not null drop table #tmpGroupType_Cost_01	
     select  cGoodsTypeNo=b.cGroupTypeNo,cGoodsTypename=b.cGroupTypeName,
    fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0))
         into #tmpGroupType_Cost_01
     from #temp_goodsKuCun_last0 a,#tmp_GoodsGroupType_01 b
     where a.cGoodsTypeno=b.cGoodsTypeNo
     group by b.cGroupTypeNo,b.cGroupTypeName
     
     
     select cGoodsTypeNo,cGoodsTypename,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #tmpGroupType_Cost_01
  group by  cGoodsTypeNo,cGoodsTypename
  union all
  select cGoodsTypeNo='zzzzzz',cGoodsTypename='合计:',fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #tmpGroupType_Cost_01
  order by cGoodsTypeNo
  
end else  --根据部组返回商品
begin
  select cGoodsno,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when  isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i,xsQty_tj=null,xsMoney_tj=null
  from #temp_goodsKuCun_last0  
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName='总计:',cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='总计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
         ,xsQty_tj=null,xsMoney_tj=null
  from #temp_goodsKuCun_last0 
  group by BeginDate,EndDate
  order by cGoodsTypeno,cGoodsno,i
  
end
 
 
	 /*删除临时表*/
	if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
	if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  drop table #temp_wh_DiffPriceWarehouseDetail
	if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null   drop table #temp_wh_DiffPricecGoodsNo


GO
