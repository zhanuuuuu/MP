CREATE proc [dbo].[bao_yi_no]
@Year  varchar(20),
@cStoreNo varchar(20)
as  
select dbo.f_GenSunYiSheetno (@Year,@cStoreNo) as bao_yi_no
GO
