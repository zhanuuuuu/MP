

CREATE       procedure [dbo].[P_Z_getRdbWareHouse_wind]
  @cSupplierNo varchar(16),
  @EndDate datetime,
--  @cWhNo varchar(32),
	@station varchar(64)
as
begin
	 declare @strtmp varchar(32)
	 set @strtmp=dbo.getDayStr(@EndDate)
   exec('
   if(select object_id(''tempdb..##TempRbdWareHouse_'+@cSupplierNo+'''))is not null
   drop table ##TempRbdWareHouse_'+@cSupplierNo+'
    select cStation='''+@station+''',cSheetno,cSupplierNo,cSupplier,
          cOperatorNo,cOperator,
          cExaminerNo,cExaminer,
          cWhNo,cWh,
          fMoney,
          dDate=dbo.getDayStr(dDate),

       bFoot=case when bExamin=1 and  isnull(bBalance,0)=0 then 1
               else 0
           end,
        
            bExamin=case when isnull(bExamin,0)=1 then 1
                        else 0
                   end,
        bBalance=case when bBalance=1 then 1
                   else 0
                   end,
        cDetail=''返厂单''
                 
    into ##TempRbdWareHouse_'+@cSupplierNo+'
    from wh_RbdWareHouse
    where  cSupplierNo='''+@cSupplierNo+''' 
         and (isnull(bBalance,0)<>1)
         and (isnull(bAccount,0)=1)

         
    union all     

    select cStation='''+@station+''',cSheetno,cSupplierNo,cSupplier,
          cOperatorNo,cOperator,
          cExaminerNo,cExaminer,
          cWhNo,cWh,
          fMoney=fMoney_diff,
          dDate=dbo.getDayStr(dDate),

       bFoot=case when bExamin=1 and  isnull(bBalance,0)=0 then 1
               else 0
           end,
        
            bExamin=case when isnull(bExamin,0)=1 then 1
                        else 0
                   end,
        bBalance=case when bBalance=1 then 1
                   else 0
                   end,
        cDetail=''差价单''
                 
    from wh_DiffPriceWarehouse
    where  cSupplierNo='''+@cSupplierNo+''' 
         and (isnull(bBalance,0)<>1)
         and ISNULL(bExamin,0)=1
         --and (isnull(bAccount,0)=1)
		')
end


GO
