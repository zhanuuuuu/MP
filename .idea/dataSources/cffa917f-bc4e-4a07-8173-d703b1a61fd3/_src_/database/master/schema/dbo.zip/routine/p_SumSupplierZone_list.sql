create  procedure p_SumSupplierZone_list
@supNo varchar(64),
@date1 datetime,
@date2 datetime
as
begin
	/*计算商户的货区租赁费用*/
	select cContractNo,cZoneNo,cZoneName,fMoney=fHirePriceSum,date1=dContractDate,date2=dUnContractDate 
	from dbo.t_Zone_Contract_History
				where isnull(jiesuanover,0)=0 and cSupNo=@supNo and dUnContractDate between @date1 and @date2
	union all
	select cContractNo,cZoneNo,cZoneName,
				 fMoney=fHirePriceSum/DATEDIFF(day,dContractDate,dEndDate)
												*dbo.f_getPeriodDays(@date1,@date2,dContractDate,dEndDate),
				 date1=dContractDate,date2=dEndDate 
	from dbo.t_Zone_Contract
	where  isnull(jiesuanover,0)=0 and cSupNo=@supNo	
	
end
GO
