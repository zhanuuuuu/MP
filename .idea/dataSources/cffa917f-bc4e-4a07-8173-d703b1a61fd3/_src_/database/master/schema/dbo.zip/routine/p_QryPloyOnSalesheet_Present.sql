


CREATE    procedure p_QryPloyOnSalesheet_Present
/*
  查询销售赠品
*/
as
begin
  select cGoodsNo,Quantity_sale=sum(isnull(fQuantity,0))
  into #t_SaleSheetDetail
  from t_SaleSheetDetail
  group by cGoodsNo

  select t_PloyOfSale.cPloyNo as PloyNo,t_PloyOfSale.cGoodsNo as GoodsNo,t_PloyOfSale.fQuantity_Ploy as Qty_Ploy,
         t_PloyOfSale.fPrice_SO as Price,t_PloyOfSale.cPresentPloyNo as PresentPloyNo,
         t_PloyOfSale.cPloyTypeNo as PloyTypeNo,t_PloyOfSale.cPloyTypeName as PloyTypeName,
         #t_SaleSheetDetail.Quantity_sale as Qty_sale,
         (case when #t_SaleSheetDetail.Quantity_sale>=t_PloyOfSale.fQuantity_Ploy then 1 else 0 end) as iflag
  into #t_PloyOfSale_SaleSheetDetail
  from t_PloyOfSale
       left join #t_SaleSheetDetail
            on t_PloyOfSale.cGoodsNo=#t_SaleSheetDetail.cGoodsNo
             --  and #t_SaleSheetDetail.Quantity_sale>=t_PloyOfSale.fQuantity_Ploy
  where t_PloyOfSale.bEnabled=1 and getdate() between t_PloyOfSale.dDateStart and (t_PloyOfSale.dDateEnd+1)
        and t_PloyOfSale.bSO=0 and t_PloyOfSale.bPresent=1
  
  select PloyNo,sum(iflag-1) as iflag
  into #t_notAccord
  from #t_PloyOfSale_SaleSheetDetail
  group by PloyNo
  
  select PloyNo,GoodsNo,Qty_sale,Qty_Ploy,Price,PresentPloyNo,PloyTypeNo,PloyTypeName
  into #t_PloyNo_implement
  from #t_PloyOfSale_SaleSheetDetail
  where ployNo in (select distinct PloyNo from #t_notAccord where iflag=0 )

  select PresentPloyNo,PloyDegree=min(ceiling(Qty_sale/Qty_ploy))
  into #t_PloyNo_PloyDegree
  from #t_PloyNo_implement
  group by PresentPloyNo

  Select a.PresentPloyNo,GoodsNo=b.cGoodsNo,GoodsName=b.cGoodsName,
         Qty_ploy=b.fQuantity_Present*a.PloyDegree
  from #t_PloyNo_PloyDegree a left join  T_PloyOfSalePresent b
       on a.PresentPloyNo=b.cPresentPloyNo   

end


GO
