 

/*
    注册返回状态：1表示当前设备存在商品信息不允许删除；           
            2表示删除； 
*/
 
CREATE  proc [dbo].[p_DeleteMerchantDevice]
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@name varchar(64),    --           
@return int output        --返回值
as
begin   
   if exists (select a.cGoodsNo from t_cStoreGoods a,t_posstation b 
   where a.cStoreNo=@Merchantid and a.cStoreNo=b.cStoreNo 
   and a.PosID=b.posid and b.posname=@name )  -- 该设备下存在商品列表：不能删除
   begin
      SET @return=1
   end else
   BEGIN
      delete t_posstation
      where cStoreNo=@Merchantid  and posname=@name 
      IF @@rowcount=1
      BEGIN
        set @return=2
      end else
      begin
        set @return=3
      end
   end      
end
 

--201512081042459907426
--2016031852549-10007
GO
