

create  procedure [dbo].[p_GetPath_GroupType_GoodsType_Caiwu]
as
begin
  exec p_GetPath_GroupType_Caiwu
  update a
  set a.cPath=b.cPath+'.'+cGoodsTypeNo
  from t_GroupType_GoodsType_Caiwu a,t_GroupType_Caiwu b
  where a.cGroupTypeNo=b.cGroupTypeNo

end


GO
