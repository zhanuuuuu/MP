
CREATE             procedure [dbo].[P_Z_getInWareHouse_wind]
  @cSupplierNo varchar(16),
  @EndDate datetime,
--  @cWhNo varchar(32),
	@station varchar(64)
as
begin
	declare @strtmp varchar(32)
	set @strtmp=dbo.getDayStr(@EndDate)
exec('
	if  (select object_id(''tempdb..##TempInRbd_'+@cSupplierNo+''')) is not null 
	drop table ##TempInRbd_'+@cSupplierNo+'
	select cStation='''+@station+''' into ##TempInRbd_'+@cSupplierNo+' 

	if  (select object_id(''tempdb..##TempInWareHouse_'+@cSupplierNo+''')) is not null 
	drop table ##TempInWareHouse_'+@cSupplierNo+'

	select cStaion='''+@station+''',cSheetno,cSupplierNo,cSupplier,
          cOperatorNo,cOperator,
          cExaminerNo,cExaminer,
          cWhNo,cWh,
          fMoney,
          dDate=dbo.getDayStr(dDate),
/*          
          bFoot=case when bExamin=1 and isnull(bPresent,0)=0 and isnull(bBalance,0)=0 then 1
               			 else 0
                end,
*/
         -- bFoot=0,
          bFoot=case when isnull(bInWhBalance,0)=1 then 1 else 0 end, 
          bBalance=case when isnull(bBalance,0)=1 then 1
                        else 0
                   end,
          bExamin=case when isnull(bExamin,0)=1 then 1
                       else 0
                  end,
          bPresent=case when isnull(bPresent,0)=1 then 1
                        else 0
                   end,bInWhBalance=isnull(bInWhBalance,0)
	into ##TempInWareHouse_'+@cSupplierNo+'
	from wh_InWareHouse
	where dbo.getDayStr(dDate)<='''+@strtmp+'''
        and cSupplierNo='''+@cSupplierNo+''' and isnull(bBalance,0)<>1
        and (isnull(bAccount,0)=1)
        
  ')

end


GO
