 
/*

 declare @return int 
 exec  [p_MerchantAddDevice] '2016031916515465095992','1234561',1,'','','自动售货机 TSO001-北京-001',@return output
 select @return
  
*/

/*
    注册返回状态：1表示当前设备名称已存在；           
            0表示添加异常； 
            5是添加成功
*/
 
create  proc [dbo].[p_MerchantAddDevice]
@Merchantid varchar(64),  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
@Name varchar(64), --设备名称。同一个 merchantID 拥有的不同 设备不能有同样的设备名称 deviceName，
                   --其格式应符合一定的规则，比如无特殊字 符、方便查询、不能太长或太短等 
@type  int,            --类型：设备类型，其取值由运营商而非商家来确 定。参考取值如下： 
                       --1：先付钱后取货自动售货机 
                       --2：先开门取货后付钱自动售货机 
                       --3：开放式货架 
                       --4：无人值守便利店 
@cAddRess varchar(64),    --设备投放地址   
@cmapLocation varchar(32),--设备投放地址的地图定位，建议采用格式为 (经度,纬度,海拔高度)。若未知海拔高度， 可取 0    
@description  varchar(128),--设备描述，包括用途、规格等                  
@return varchar(32) output        --返回值
as
begin
  begin try 
  begin tran
	if exists (select posname from t_posstation where cStoreNo=@Merchantid AND posname=@Name)  -- 判定UesrName是否已经被使用过
	begin
		set @return='1'
	end else
	begin	
	  declare @PosID varchar(32)
	  set @PosID=DateName(year,GetDate())+DateName(month,GetDate())+DateName(day,GetDate())+
      DateName(hour,GetDate())+DateName(minute,GetDate())+DateName(second,GetDate())+'_'+cast(cast( floor(rand()*100) as int) AS varchar)

	  insert into t_posstation(posname,posid,cWHno,posip,cStoreNo,iType,cAddRess,cMapLocation,cDescription,dCreateDate)
	  VALUES(@Name,@PosID,'','',@Merchantid,@type,@cAddRess,@cmapLocation,@description,getdate())    
	  
	  set @return=@PosID
	 
	end  	
	commit tran
    
	end try
	begin catch  
	   rollback  
	  set @return='0'
	end catch
  
end
 
--201512081042459907426
--2016031852549-10007
GO
