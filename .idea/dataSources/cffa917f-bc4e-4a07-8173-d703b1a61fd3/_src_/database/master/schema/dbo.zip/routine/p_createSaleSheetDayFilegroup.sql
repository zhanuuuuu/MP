/*
exec p_createSaleSheetDayFilegroup 'PosManagement'
*/
/*
存储过程作用：
为指定数据库创建文件组
*/
create proc p_createSaleSheetDayFilegroup
@MyDatebaseName varchar(64)
as
begin
exec('
	use '+@MyDatebaseName+'
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_01]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_02]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_03]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_04]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_05]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_06]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_07]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_08]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_09]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_10]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_11]
	
	alter database '+@MyDatebaseName+' add filegroup [SaleSheetDay_12]
	
    alter database '+@MyDatebaseName+' add filegroup [FG_SaleSheetDay]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_01'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_01.ndf''
	)to filegroup [SaleSheetDay_01]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_02'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_02.ndf''
	)to filegroup [SaleSheetDay_02]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_03'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_03.ndf''
	)to filegroup [SaleSheetDay_03]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_04'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_04.ndf''
	)to filegroup [SaleSheetDay_04]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_05'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_05.ndf''
	)to filegroup [SaleSheetDay_05]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_06'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_06.ndf''
	)to filegroup [SaleSheetDay_06]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_07'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_07.ndf''
	)to filegroup [SaleSheetDay_07]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_08'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_08.ndf''
	)to filegroup [SaleSheetDay_08]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_09'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_09.ndf''
	)to filegroup [SaleSheetDay_09]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_10'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_10.ndf''
	)to filegroup [SaleSheetDay_10]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_11'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_11.ndf''
	)to filegroup [SaleSheetDay_11]
	
	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_12'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_12.ndf''
	)to filegroup [SaleSheetDay_12]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_a'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_a.ndf''
	)to filegroup [FG_SaleSheetDay]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_b'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_b.ndf''
	)to filegroup [FG_SaleSheetDay]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_c'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_c.ndf''
	)to filegroup [FG_SaleSheetDay]

	alter database '+@MyDatebaseName+'
	add file 
	(
		Name=''SaleSheetDay_d'',
		filename=''e:\SQL_SaleSheetDay\SaleSheetDay_d.ndf''
	)to filegroup [FG_SaleSheetDay]
	
')
end

/*
exec p_createSaleSheetDayFilegroup 'PosManagement_chain'
*/







GO
