
 
Create proc [dbo].[p_AppGetFreshSale1]
@cStoreNo varchar(32),  --门店号
@dDate1 datetime,   --开始日期2
@dDate2 datetime,   --结束日期2
@cWhNo varchar(32),  -- 门店仓库号
@GroupTypeNo varchar(32) 
as
SET NOCOUNT ON
begin
    if (select object_id('tempdb..#temp_Goods'))is not null
    drop table #temp_Goods

	--- 构造查询的基本信息到临时实表
	--- 注意表明中的：201610051149222 
 
	select cGoodsNo into #temp_Goods
	from t_cStoreGoods
	where cStoreNo=@cStoreNo and cGoodsTypeno
	in
	(
	select x.cGroupTypeNo
	from
	(
		select cGroupTypeNo=cGoodsTypeNo,cGroupTypeName=cGoodsTypeName,cParentNo=cGroupTypeNo, cPath
		from dbo.T_GroupType_GoodsType
	) x,(select cPath from T_GroupType where PATINDEX('%,'+cGroupTypeNo+',%',@GroupTypeNo)>0 or @GroupTypeNo='--') y
	where PATINDEX(y.cPath+'%',x.cPath)=1 
	)
	and isnull(bDeled,0)=0 
	--and isnull(bStock,0)=0  
	and isnull(bSuspend,0)=0
	and ISNULL(bStop,0)=0   
	order by cGoodsTypeno
	
    
 
	---调用过程
	exec [p_x_salesABC_byGoods_log_TermID_Tmp] @cStoreNo,@dDate1,@dDate2,@cWhNo
	

	if (select object_id('tempdb..#temp_Goods'))is not null
    drop table #temp_Goods
	
end
GO
