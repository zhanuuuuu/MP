/*
  if (select OBJECT_ID('U_key.dbo.temp_GoodsList'))is not null drop table U_key.dbo.temp_GoodsList
   create table U_key.dbo.temp_GoodsList(cSheetno varchar(32),iLineNo int,cGoodsNo varchar(32),cGoodsName varchar(64),
   cBarcode varchar(32),cUnitedNo varchar(32),fQuantity money ,
	     fInPrice money ,fInMoney money,cUnit varchar(32) ,cSpec varchar(32),fQty_Cur money,
	     fQty_Avg money,fQty_3 money,fNormalPrice money,fDhRate money,fBhRate money,fLossRato money,fQty_Month money
	     ,fWeekXs money,fWeekBhRate money,fLossRato_Z money,ftjRatio money,fQtySaleZ money)
	     
	if (select OBJECT_ID('U_key.dbo.temp_GoodsTypeNo'))is not null drop table U_key.dbo.temp_GoodsTypeNo
	select cGoodsTypeNo into U_key.dbo.temp_GoodsTypeNo from t_Goodstype where isnull(bFresh,0)=1
	
   exec p_GetSaleCreateBhStock_Week_test '1001','','2016-11-29','2016-12-28','',2,28,1.4699,1.05
   
*/
CREATE proc p_GetSaleCreateBhStock_Week
@cStoreNo varchar(32),
@cStoreName varchar(64),
@dDate1 datetime,
@dDate2 datetime,
@cTermID varchar(32),
@cOrderType int,
@dDay int , ------ 前30天平均销量
@fRatio money,
@fAddRatio money
as
begin 
    
    declare @dOpenDate datetime
    set @dOpenDate=(select a.dOpenDate from t_OpenDate a,t_WareHouse b where a.cStoreNo=b.cWhNo and b.cStoreNo=@cStoreNo)
    
    if @dDate1<@dOpenDate
    begin
        set @dDate1=@dOpenDate
    end
    
	if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
	create table #temp_Goods(cGoodsNo varchar(32))
	
	exec('
	   insert into #temp_Goods(cGoodsNo)
	   select cGoodsNo 
	   from t_cStoreGoods a,U_key.dbo.temp_GoodsTypeNo'+@cTermID+' b
			where a.cStoreNo='''+@cStoreNo+''' and a.cGoodsTypeNo=b.cGoodsTypeNo 
			and ISNULL(a.bfresh,0)=1 
	  --select cGoodsNo from t_cStoreGoods where cStoreNo='''+@cStoreNo+'''
	  --and cGoodsNo=''10019''
	 ')
	
	declare @Day int

	set @Day=(DATEDIFF ( DAY , @dDate1 , @dDate2 ))+1
    declare @Pos_Sale varchar(16)
    set @Pos_Sale=(select top 1 Pos_Sale from t_WareHouse where cStoreNo=@cStoreNo)
    
    ---------前一个月销量
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate1'))is not null  drop table #temp_cGoodsSaleDate1
	create table #temp_cGoodsSaleDate1(cGoodsno varchar(32),fQty money,fQty_zj money,fQty_tj money)
	
    --exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate1,@dDate2,''
    
    declare @dMaxDaily datetime
    set @dMaxDaily=(select isnull(MAX(dDate),'2000-01-01') from t_Daily_history where cStoreNo=@cStoreNo)
    if @dMaxDaily>@dDate2
    begin
      set @dMaxDaily=@dDate2
    end
    
    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate_Day0'))is not null  drop table #temp_cGoodsSaleDate_Day0
    select a.cGoodsNo,a.cStoreNo,fQty=SUM(a.fQuantity) 
    into #temp_cGoodsSaleDate_Day0
    from t_SaleSheet_Day a,#temp_Goods b
    where a.dSaleDate between @dDate1 and @dMaxDaily and a.cGoodsNo=b.cGoodsNo
    group by  a.cGoodsNo,a.cStoreNo
    union all
    select a.cGoodsNo,a.cStoreNo,fQty=SUM(a.fQuantity) 
    from t_SaleSheetDetail a,#temp_Goods b
    where dSaleDate>=@dDate1 and dSaleDate between (@dMaxDaily+1) and @dDate2 and a.cGoodsNo=b.cGoodsNo
    group by  a.cGoodsNo,a.cStoreNo 
    
  
    ---生鲜包装转换
    
    update a
	set a.cGoodsno=b.cGoodsNo_minPackage
	from #temp_cGoodsSaleDate_Day0 a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	  
	  
 
	  
    insert into #temp_cGoodsSaleDate1(cGoodsno,fQty)
    select cGoodsNo,fQty=SUM(fQty)
    from #temp_cGoodsSaleDate_Day0
    where cStoreNo=@cStoreNo
    group by cGoodsNo
    
 
    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
	create table #temp_cGoodsSaleDate(cGoodsno varchar(32),fQty money)
	insert into #temp_cGoodsSaleDate(cGoodsno,fQty)
	select a.cGoodsNo,fQty=isnull(b.fQty,0) 
	from #temp_Goods a left join #temp_cGoodsSaleDate1 b
	on a.cGoodsNo=b.cGoodsno
    
    
    
	--获取每日的平均值
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateAvg'))is not null  drop table #temp_cGoodsSaleDateAvg
	select cGoodsNo,fQtySale=SUM(fQty)
	into #temp_cGoodsSaleDateAvg
	from #temp_cGoodsSaleDate
	group by cGoodsNo
	
	
    ---------前 30天平均下来
    truncate table #temp_cGoodsSaleDate1
    
	declare @d1 datetime
	set @d1=@dDate1-@dDay
	
	if @d1<@dOpenDate
	begin
	   set @d1=@dOpenDate
	   set @dDay=(DATEDIFF ( DAY , @d1 , @dDate2 ))+1
	end
	
    exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@d1,@dDate2,''
    
	
    if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate_Day'))is not null  drop table #temp_cGoodsSaleDate_Day
	create table #temp_cGoodsSaleDate_Day(cGoodsno varchar(32),fQty money)
	insert into #temp_cGoodsSaleDate_Day(cGoodsno,fQty)
	select a.cGoodsNo,fQty=isnull(b.fQty,0) 
	from #temp_Goods a left join #temp_cGoodsSaleDate1 b
	on a.cGoodsNo=b.cGoodsno
    
    
    ---生鲜包装转换
    
    update a
	set a.cGoodsno=b.cGoodsNo_minPackage
	from #temp_cGoodsSaleDate_Day a,t_Goods b
	where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
	
 
	--获取每日的平均值
	if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDateAvg_Day'))is not null  drop table #temp_cGoodsSaleDateAvg_Day
	select cGoodsNo,fQty=SUM(fQty)/@dDay,fQtySale=SUM(fQty)
	into #temp_cGoodsSaleDateAvg_Day
	from #temp_cGoodsSaleDate_Day
	group by cGoodsNo
	

	
    --- 单号
    declare @SheetNo varchar(32)
    set @SheetNo=(select sheetno=dbo.f_GenBhsheetnoApply(YEAR(getdate()),@cStoreNo))
    
	  if (select OBJECT_ID('tempdb..#temp_GoodsList'))is not null  drop table #temp_GoodsList
	  create table #temp_GoodsList( cSheetno varchar(32),iLineNo [bigint] IDENTITY(1,1) NOT NULL,cGoodsNo varchar(32),
	  cGoodsName varchar(64),cBarcode varchar(32),cUnitedNo varchar(32),  
	  fQuantity money,fInPrice money,fInMoney money,cUnit varchar(32),cSpec varchar(32),fQty_Cur money,fLossRato money,fQtySale money,
	  fQty_Avg money,fQty_3 money,fNormalPrice money,fDhRate money,fBhRate money,fQty_Week money,fQty_Month money,
	  fWeekXs money,fWeekBhRate money,fLossRato_Z money,ftjRatio money,fQtySaleZ money)
	  
	  declare @cWhNo varchar(32)
	  declare @cWh varchar(32)
	  
	  select top 1 @cWhNo=cwhNo,@cWh=cwh from t_WareHouse where cStoreNo=@cStoreNo
 
	  --insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,cSpec)
	  --select @SheetNo,a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,b.fCKPrice,a.fQty*b.fCKPrice,b.cUnit,b.cSpec
	  --from #temp_cGoodsSaleDateAvg a,t_Goods b
	  --where a.cGoodsNo=b.cGoodsNo
	  
	  if (select OBJECT_ID('tempdb..#temp_GoodsList_0'))is not null  drop table #temp_GoodsList_0
	  select sheetno=@SheetNo,a.cGoodsNo,fQty=0,b.fQtySale
	  into #temp_GoodsList_0
	  from #temp_Goods a,#temp_cGoodsSaleDateAvg b
	  where a.cGoodsNo=b.cGoodsno
	  
 
	  
	   insert into #temp_GoodsList(cSheetno,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,fInPrice,fInMoney,cUnit,
	   cSpec,fQty_Cur,fQtySale,fQty_Avg,fNormalPrice)
	  select @SheetNo,a.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnitedNo,a.fQty,
	  fCKPrice=case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end,
	  a.fQty*(case when isnull(b.fCKPrice,0)=0 then isnull(b.fPrice_Contract,0) else isnull(b.fCKPrice,0) end),
	  b.cUnit,b.cSpec,fQty_Cur=0,a.fQtySale,a.fQty,b.fNormalPrice
	  from #temp_GoodsList_0 a,t_cStoreGoods b
	  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
	  
	  update a
	  set  a.fQty_Avg=round(b.fQty,2)
	  from #temp_GoodsList a,#temp_cGoodsSaleDateAvg_Day  b
	  where a.cGoodsNo=b.cGoodsno
	  
	  
	  
	    if (select object_id('tempdb..#temp_GoodsFresh'))is not null drop table #temp_GoodsFresh
	   
	    select a.cGoodsNo,fCKPrice,cGoodsNo_minPackage into #temp1 
	    from  t_Goods a,#temp_GoodsList b
	    where a.cGoodsNo=b.cGoodsNo and ISNULL(bfresh,0)=1 
	    
  
		 update a set a.fInPrice=b.fCKPrice
		 from #temp_GoodsList a,#temp1 b
		 where a.cGoodsNo=b.cGoodsNo_minPackage
 
 
	  --select * from t_cStoreGoods
	  --where cStoreNo='1001' and ISNULL(bfresh,0)=1
	  
	  update #temp_GoodsList set fQuantity=CEILING(fQuantity)
	  where cUnit not in ('kg','500g')
	  
	  
	  declare @dDate varchar(32)
 
	  set @cWHno=(select cWhNo from t_WareHouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1)

      set @dDate=dbo.getDayStr(GETDATE()-1)
		 				
   --   exec [P_x_SetCheckWh_byGoodsType_logCurQty] @cStoreNo,@dDate,@dDate,@cWHno		  
   --   update a
	  --set a.fQty_Cur=b.EndQty
	  --from #temp_GoodsList a,t_goodsKuCurQty_wei b
	  --where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo
	  -----
      ---最近3天销量 
      
      delete #temp_cGoodsSaleDate1
      
      declare @dDate3 varchar(32)
      set @dDate3=dbo.getDayStr(GETDATE()-3) 
      
      if @dDate3<@dOpenDate 
      begin
        set @dDate3=@dOpenDate
      end
      
      /*
      exec [p_x_salesABC_byGoods_log_TermID_Bh] @cStoreNo,@dDate3,@dDate,''
       */
       /*
       insert into #temp_cGoodsSaleDate1(cGoodsno,fQty)
       select a.cGoodsNo,fQty=SUM(fQuantity)
       from t_SaleSheetDetail a,#temp_Goods b
       where a.dSaleDate between @dDate3 and @dDate and a.cStoreNo=@cStoreNo
       and a.cGoodsNo=b.cGoodsNo
       group by a.cGoodsNo
       
	 
		update a
		set a.cGoodsno=b.cGoodsNo_minPackage
		from #temp_cGoodsSaleDate1 a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''		  
	  
	  update a set fQty_3=Round(b.fQty,2)
	  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) from #temp_cGoodsSaleDate1 group by cGoodsno) b
	  where  a.cGoodsNo=b.cGoodsNo
	  */
	  ---最近7天销量
	  
	  delete #temp_cGoodsSaleDate1
	  
 
      declare @dDate7 varchar(32)
      set @dDate7=dbo.getDayStr(GETDATE()-7) 
      
      if @dDate7<@dOpenDate 
      begin
        set @dDate7=@dOpenDate
      end
      
    
       if (select OBJECT_ID('tempdb..#temp_GoodsSale7'))is not null  drop table #temp_GoodsSale7  
       select a.cGoodsNo,a.dSaleDate,fQty=SUM(fQuantity)
       into #temp_GoodsSale7
       from t_SaleSheetDetail a,#temp_Goods b
       where a.dSaleDate between @dDate7 and @dDate and a.cStoreNo=@cStoreNo
       and a.cGoodsNo=b.cGoodsNo
       group by a.cGoodsNo,a.dSaleDate
 
		update a
		set a.cGoodsno=b.cGoodsNo_minPackage
		from #temp_GoodsSale7 a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''	
	
	  ---3天销量
	  update a set fQty_3=Round(b.fQty,2)
	  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) 
	  from #temp_GoodsSale7 where dSaleDate between @dDate3 and @dDate group by cGoodsno) b
	  where  a.cGoodsNo=b.cGoodsNo
	  
	  ---7天销量
	  update a set fQty_Week=Round(b.fQty,2)
	  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) from #temp_GoodsSale7 group by cGoodsno) b
	  where  a.cGoodsNo=b.cGoodsNo
	  
     ----------------
	  
	  update a		 
	  set a.fQtySaleZ=isnull(b.fQty,0)
	  from #temp_GoodsList a,(select cGoodsno,fQty=SUM(fQty) from #temp_cGoodsSaleDate_Day0 group by cGoodsno) b
	  where a.cGoodsNo=b.cGoodsNo
	  
 
	  if (select OBJECT_ID('tempdb..#temp_GoodsInWare'))is not null  drop table #temp_GoodsInWare
	  select b.cGoodsNo,a.cStoreNo,fQty=SUM(b.fQuantity) 
	  into #temp_GoodsInWare
	  from wh_InWarehouse a,wh_InWarehouseDetail b
	  where a.dDate between @dDate1 and @dDate2
	  and a.cSheetno=b.cSheetno 
	  group by b.cGoodsNo,a.cStoreNo
	  
	  --select * from #temp_GoodsInWare where cGoodsNo in ('10011','10012','01001')
	 
	    update a
		set a.cGoodsno=b.cGoodsNo_minPackage
		from #temp_GoodsInWare a,t_Goods b
		where a.cGoodsno=b.cGoodsno and ISNULL(b.cGoodsNo_minPackage,'')<>''
		
		 
		--- 当前门店入库
		if (select OBJECT_ID('tempdb..#temp_GoodsInWareMin'))is not null  drop table #temp_GoodsInWareMin
		select a.cGoodsNo,fQty=SUM(fQty),
		fLossRato=case when SUM(fQty)=0 then 0 else (SUM(fQty)-SUM(b.fQtySale))/SUM(fQty) end
		into #temp_GoodsInWareMin
		from #temp_GoodsInWare a,#temp_GoodsList b
		where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=@cStoreNo   
		group by a.cGoodsNo,a.cStoreNo
		
 
        
		update a
		--set a.fLossRato=round(isnull(b.fLossRato,0),2)
		set a.fLossRato=isnull(b.fLossRato,0)
		from #temp_GoodsList a,#temp_GoodsInWareMin b
		where a.cGoodsNo=b.cGoodsNo
		
		
		---所有门店入库
		if (select OBJECT_ID('tempdb..#temp_GoodsInWareMinZ'))is not null  drop table #temp_GoodsInWareMinZ
		select a.cGoodsNo,fQty=SUM(fQty),
		fLossRato=case when SUM(fQty)=0 then 0 else (SUM(fQty)-SUM(b.fQtySaleZ))/SUM(fQty) end
		into #temp_GoodsInWareMinZ
		from #temp_GoodsInWare a,#temp_GoodsList b
		where a.cGoodsNo=b.cGoodsNo 
		group by a.cGoodsNo
		
		
        
		update a 
		set a.fLossRato_Z=isnull(b.fLossRato,0)
		from #temp_GoodsList a,#temp_GoodsInWareMinZ b
		where a.cGoodsNo=b.cGoodsNo
		
       
        
	    update #temp_GoodsList 
	    set  fQuantity=case when (1-isnull(fLossRato,0))=0 then 0 else fQty_Avg/(1-isnull(fLossRato,0)) end
	    
	  
         
	  ---补货数量=加损耗之后的数量*补货权系数*订货系数  

	       update a set fQuantity=round(isnull(fQuantity,0)*isnull(@fRatio,1)*ISNULL(@fAddRatio,1),2),
	      a.fDhRate=isnull(b.fDhRate,1),a.fBhRate=isnull(b.fBhRate,1),
	      a.fWeekXs=isnull(@fRatio,1),a.fWeekBhRate=ISNULL(@fAddRatio,1),
	      a.ftjRatio=1
		  from #temp_GoodsList a,t_cStoreGoods b
		  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo		
 
	  exec('
	     insert into U_key.dbo.temp_GoodsList'+@cTermID+'(cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity,
	     fInPrice,fInMoney,cUnit,cSpec,fQty_Cur,fQty_Avg,fQty_3,fNormalPrice,fDhRate,fBhRate,fLossRato,fQty_Month,
	     fWeekXs,fWeekBhRate,fLossRato_Z,ftjRatio,fQty_Week)
	     select cSheetno,iLineNo,cGoodsNo,cGoodsName,cBarcode,cUnitedNo,fQuantity=Round(fQuantity,0),fInPrice,
	     fInMoney=Round(fQuantity,0)*fInPrice,cUnit,cSpec,fQty_Cur,fQty_Avg,fQty_3=Round(fQty_3,1),fNormalPrice,fDhRate,
	     fBhRate,fLossRato=isnull(fLossRato,0),
	     fQtySale=Round(fQtySale,1),fWeekXs,fWeekBhRate,fLossRato_Z,ftjRatio,fQty_Week
         from #temp_GoodsList order by iLineNo
	  ')
 
end
GO
