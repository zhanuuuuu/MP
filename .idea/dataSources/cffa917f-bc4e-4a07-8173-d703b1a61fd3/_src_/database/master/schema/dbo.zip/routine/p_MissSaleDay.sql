
CREATE proc p_MissSaleDay
@dDate datetime,
@cStoreNo varchar(32),
@cStoreName varchar(32),
@WHno varchar(32),
@return int output
as
begin

	-----首先判断当前日期是否日结
	if not exists(select dDate from t_Daily_history where dDate=@dDate and cStoreNo=@cStoreNo)
	begin
	    set @return=0  --表示当前日期当前门店没进行日结
	end else
	begin
	    
		declare @Pos_Sale varchar(32)	  
		      
		 select top 1 @Pos_Sale=Pos_Sale,@WHno=cWhNo from t_Warehouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1 
		
		if(select object_id('tempdb..#temp_Return')) is not null
			begin
				drop table 	#temp_Return
			end
		create table #temp_Return(iReturn int)
	    begin try
	    exec('    
		declare @SaleDetail money
		declare @SaleDay money
		select @SaleDetail=sum(fLastSettle) from '+@Pos_Sale+'.dbo.t_SaleSheetDetail
		where dSaleDate='''+@dDate+'''  and cStoreNo='''+@cStoreNo+'''

		select @SaleDay=sum(fLastSettle) from '+@Pos_Sale+'.dbo.t_SaleSheet_Day
		where dSaleDate='''+@dDate+'''  and cStoreNo='''+@cStoreNo+'''
		 
		
	    
		
		if @SaleDetail=@SaleDay
		begin
		  insert into #temp_Return(iReturn)
		  values(1)
		  --set @return=1 ------ 表示当前数据正常  无漏掉日结。
		end else
		begin
		    
		    if(select object_id(''tempdb..#temp_SaleSheetDetail'')) is not null
			begin
				drop table 	#temp_SaleSheetDetail
			end
			
			if(select object_id(''tempdb..#temp_SaleSheet_Day'')) is not null
			begin
				drop table 	#temp_SaleSheet_Day
			end
			
			
            select cSaleSheetno,iSeed,cGoodsNo,bAuditing,fVipScore,fQuantity,fLastSettle,dSaleDate,
			fPrice,bVipPrice,fVipPrice,cSaleTime,cVipNo,Tag_daily
			into #temp_SaleSheetDetail
			from  '+@Pos_Sale+'.dbo.t_SaleSheetDetail
			where dSaleDate='''+@dDate+'''  and cStoreNo='''+@cStoreNo+''' and ISNULL(Tag_daily,0)=0  -- 表示没有参与日结的。
			and  cWHno='''+@WhNo+'''
			
			
			---获取日结表中已存在数据
            select cGoodsNo,bAuditing
			into #temp_SaleSheet_Day
			from  '+@Pos_Sale+'.dbo.t_SaleSheet_Day
			where dSaleDate='''+@dDate+'''  and cStoreNo='''+@cStoreNo+'''  -- 表示已经参与日结的商品
			and  cWHno='''+@WhNo+'''
			
			----插入日结掉数据表
			insert into '+@Pos_Sale+'.dbo.t_SaleSheet_Day_Miss
			(cWHno,cStoreNo,cStoreName,cGoodsNo,bAuditing,fVipScore,fQuantity_Total,fQuantity,fLastSettle,dFinanceDate,dSaleDate,cSaleTime,
			 H0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,H17,H18,H19,H20,H21,H22,H23,
			 H0_Q,H1_Q,H2_Q,H3_Q,H4_Q,H5_Q,H6_Q,H7_Q,H8_Q,H9_Q,H10_Q,H11_Q,H12_Q,H13_Q,H14_Q,H15_Q,H16_Q,H17_Q,H18_Q,H19_Q,H20_Q,H21_Q,H22_Q,H23_Q 	         
			)
			select '''+@WHno+''','''+@cStoreNo+''','''+@cStoreName+''',cGoodsNo,bAuditing,fVipScore=round(sum((fVipScore*fQuantity)),0),
							fQuantity_Total=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate),					
							fQuantity=sum(fQuantity),
							fLastSettle=sum(fLastSettle),dFinanceDate=dSaleDate,dSaleDate,cSaleTime=dbo.getTimeStr(getdate()),
							H0=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H1=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H2=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H3=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H4=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H5=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					

							H6=(select sum(fLastSettle) from #temp_SaleSheetDetail 

								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H7=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H8=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H9=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H10=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H11=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H12=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H13=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H14=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H15=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H16=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H17=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H18=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H19=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H20=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H21=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H22=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H23=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
								
							H0_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H1_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H2_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H3_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H4_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H5_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H6_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H7_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H8_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H9_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H10_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H11_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H12_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H13_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H14_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H15_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H16_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H17_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H18_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 

								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H19_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H20_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H21_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H22_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H23_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing )

					from 	#temp_SaleSheetDetail a
					where  a.dSaleDate='''+@dDate+'''
					group by a.cGoodsNo,a.dSaleDate,a.bAuditing			
					
					
					--- 修改日结表中已存在数据
					update a
					set a.fQuantity=ISNULL(a.fQuantity,0)+b.fQuantity,
					a.fLastSettle=ISNULL(a.fLastSettle,0)+ISNULL(b.fLastSettle,0)
					from t_SaleSheet_Day a,(select cGoodsNo,bAuditing,fQuantity=SUM(fQuantity),fLastSettle=SUM(fLastSettle) 
					from #temp_SaleSheetDetail group by cGoodsNo,bAuditing) b
					where a.cStoreNo='''+@cStoreNo+''' and a.cWHno='''+@WHno+''' 
					and a.cGoodsNo=b.cGoodsNo and a.bAuditing=b.bAuditing
			
						  
			----插入日结表中不存在商品		
			insert into dbo.t_SaleSheet_Day
			(cWHno,cStoreNo,cStoreName,cGoodsNo,bAuditing,fVipScore,fQuantity_Total,fQuantity,fLastSettle,dFinanceDate,dSaleDate,cSaleTime,
			 H0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,H17,H18,H19,H20,H21,H22,H23,
			 H0_Q,H1_Q,H2_Q,H3_Q,H4_Q,H5_Q,H6_Q,H7_Q,H8_Q,H9_Q,H10_Q,H11_Q,H12_Q,H13_Q,H14_Q,H15_Q,H16_Q,H17_Q,H18_Q,H19_Q,H20_Q,H21_Q,H22_Q,H23_Q 	         
			)
			select '''+@WHno+''','''+@cStoreNo+''','''+@cStoreName+''',a.cGoodsNo,a.bAuditing,fVipScore=round(sum((fVipScore*fQuantity)),0),
							fQuantity_Total=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate),					
							fQuantity=sum(fQuantity),
							fLastSettle=sum(fLastSettle),dFinanceDate=dSaleDate,dSaleDate,cSaleTime=dbo.getTimeStr(getdate()),
							H0=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H1=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H2=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H3=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H4=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H5=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					

							H6=(select sum(fLastSettle) from #temp_SaleSheetDetail 

								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H7=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H8=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H9=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H10=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H11=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H12=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H13=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H14=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H15=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H16=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H17=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H18=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H19=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H20=(select sum(fLastSettle) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H21=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H22=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H23=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
								
							H0_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H1_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H2_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H3_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H4_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H5_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H6_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H7_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H8_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H9_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H10_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H11_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H12_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H13_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H14_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H15_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H16_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H17_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H18_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H19_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H20_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H21_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
							H22_Q=(select sum(fQuantity) from #temp_SaleSheetDetail
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
							H23_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast(''2000-01-01 ''+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing )

					from 	#temp_SaleSheetDetail a left join #temp_SaleSheet_Day b
					on a.cGoodsNo=b.cGoodsNo and a.bAuditing=b.bAuditing
					where  a.dSaleDate='''+@dDate+''' and ISNULL(b.cGoodsNo,'''')=''''
					group by a.cGoodsNo,a.dSaleDate,a.bAuditing		
					
					
					update a set a.Tag_daily=1
					from  dbo.t_SaleSheetDetail a,#temp_SaleSheetDetail b
					where isnull(a.Tag_daily,0)=0 and a.dSaleDate='''+@dDate+''' and a.cSaleSheetno=b.cSaleSheetno
					and a.cStoreNo='''+@cStoreNo+'''
					and a.cWHno='''+@WhNo+'''
						  
					insert into #temp_Return(iReturn)
		           values(2)  
		          -- set @return=2   --- 表示日结掉数据 重新日结成功
		    
		end
		
		')
		set @return=(
		select * from #temp_Return)
		end try
		begin catch		 
		 set @Return=-99  
		end catch
	end
end
GO
