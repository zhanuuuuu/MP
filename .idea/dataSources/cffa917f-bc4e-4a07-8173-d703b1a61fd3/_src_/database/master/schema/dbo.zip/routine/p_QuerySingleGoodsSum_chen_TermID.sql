CREATE proc [dbo].[p_QuerySingleGoodsSum_chen_TermID]
@dDate datetime, --截止日期
@cGoodsNo varchar(100), --查询商品
@cTermID varchar(32),
@cStoreNo varchar(32)
as

if (select object_id('tempdb..#tmpQuerySingleGoods')) is not null
drop table #tmpQuerySingleGoods
select top 1 cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName,
cSupNo,cSupName,
fNormalPrice,fCkPrice,bStorage=isnull(bStorage,0),
fQtyIn_Account=cast(0 as money),fQtyOut_Account=cast(0 as money),
fQtyIn_NoAccount=cast(0 as money),fQtyOut_NoAccount=cast(0 as money),
fQty=cast(0 as money)
into #tmpQuerySingleGoods
from t_goods
where cGoodsNo=@cGoodsNo

 -----------获取当前库存------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
 
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null  drop table #temp_Goods
select a.cGoodsNo into #temp_Goods
from t_Goods a,#tmpQuerySingleGoods b
where a.cGoodsNo=b.cGoodsNo

declare @cWhno varchar(32) 
 
 --exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDate,@dDate,@cWhno  
 
 ---获取当前的库存。。
declare @dDate1 varchar(32)

set @cWHno=(select cWhNo from t_WareHouse where cStoreNo=@cStoreNo and ISNULL(bMainSale,0)=1)

set @dDate1=dbo.getDayStr(GETDATE())
 			
exec [P_x_SetCheckWh_byGoodsType_logCurQty] @cStoreNo,@dDate1,@dDate1,@cWHno	
      
 
/*----------------*/

/*------------*/ 
update a
set a.fQty=b.EndQty
from #tmpQuerySingleGoods a,#temp_goodsKuCurQty b
where a.cGoodsNo=b.cGoodsNo 

exec('
  if(select object_id(''U_key.dbo.tmpGoodsList'+@cTermID+''')) is not null
begin
		 insert into U_key.dbo.tmpGoodsList'+@cTermID+' 
		 ( 
		  cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName, 
		  cSupNo,cSupName,fNormalPrice,fCkPrice,fQty 
		 ) 
		select cGoodsNo,cBarCode,cGoodsName,cGoodsTypeNo,cGoodsTypeName,cSupNo,cSupName,
		fNormalPrice,fCkPrice,fQty
		from #tmpQuerySingleGoods
end

')
GO
