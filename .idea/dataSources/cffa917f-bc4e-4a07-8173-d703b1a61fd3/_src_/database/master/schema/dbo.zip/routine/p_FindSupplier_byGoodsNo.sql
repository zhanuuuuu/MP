




CREATE      procedure p_FindSupplier_byGoodsNo
@cGoodsNo varchar(64)
as
begin
		  select f.cGoodsNo,f.cGoodsName,f.cBarcode,f.cUnit,
					f.cSpec,f.cProductUnit,f.fVipScore,f.fNormalPrice,f.fVipPrice,
					f.cSupNo,f.cSupName,f.fInMoney  
			into #Result
		  from 
		  (
					select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
					a.cSpec,a.cProductUnit,a.fVipScore,a.fNormalPrice,a.fVipPrice,
					b.cSupNo,b.cSupName,b.fInMoney 
					from  t_Goods a 
					left join t_Supplier_goods b on a.cGoodsNo=b.cGoodsNo
					where a.cGoodsNo =@cGoodsNo
					
					union 
					
					select e.cGoodsNo,e.cGoodsName,e.cBarcode,e.cUnit,
					e.cSpec,e.cProductUnit,e.fVipScore,e.fNormalPrice,e.fVipPrice,
					e.cSupNo,e.cSupName,e.fInMoney 
					from  
					(select distinct c.cGoodsNo,c.cGoodsName,
									c.cBarcode,c.fInPrice as fInMoney,c.cUnit,c.cSpec,c.cProductUnit,c.fVipPrice,c.fVipScore,c.fNormalPrice,
									wh_InWarehouse.cSupplierNo as cSupNo,wh_InWarehouse.cSupplier as cSupName,c.cHelpCode
						from 
								(
									select distinct wh_InWarehouseDetail.cSheetno,
									wh_InWarehouseDetail.cGoodsNo,wh_InWarehouseDetail.cGoodsName,
									wh_InWarehouseDetail.cBarcode,wh_InWarehouseDetail.fInPrice,
									t_Goods.cHelpCode,t_Goods.cUnit,t_Goods.cSpec,t_Goods.cProductUnit,t_Goods.fVipPrice,t_Goods.fVipScore,t_Goods.fNormalPrice
									from wh_InWarehouseDetail 
					 				left join t_Goods  on wh_InWarehouseDetail.cGoodsNo=t_Goods.cGoodsNo
									where wh_InWarehouseDetail.cGoodsNo =@cGoodsNo
								) c
						left join wh_InWarehouse on wh_InWarehouse.cSheetno=c.cSheetno
					  where c.cGoodsNo  =@cGoodsNo
						--or c.cHelpCode like '%' + @Condition + '%'
					) e 

			)f		
			--where f.cSupNo is not null


select x.*
from
(
			select a.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,
					a.cSpec,a.cProductUnit,a.fVipScore,a.fNormalPrice,a.fVipPrice,
					a.cSupNo,a.cSupName,a.fInMoney 
      from #Result a 
			where a.cSupNo is not null

			union all

			select b.cGoodsNo,b.cGoodsName,b.cBarcode,b.cUnit,
					b.cSpec,b.cProductUnit,b.fVipScore,b.fNormalPrice,b.fVipPrice,
					b.cSupNo,b.cSupName,b.fInMoney 
      from #Result b 
			where b.cSupNo is  null and b.cGoodsNo not in (select cGoodsNo from #Result where cSupNo is not null )
) x
where cGoodsNo is not null
order by x.cSupNo desc,x.cGoodsNo 

end


GO
