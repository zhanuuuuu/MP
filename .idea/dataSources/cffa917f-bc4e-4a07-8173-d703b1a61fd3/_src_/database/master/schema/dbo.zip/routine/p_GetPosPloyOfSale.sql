create proc p_GetPosPloyOfSale  
as
select fVipValue,cPloyNo,cGoodsNo,cGoodsName,fQuantity_Ploy,fPrice_SO, 
dDateStart,cTimeStart,dDateEnd,cTimeEnd,iPriority,bSO,bPresent, 
 cPresentPloyNo,cPloyTypeNo,cPloyTypeName,bEnabled, bLimitQty,fLimitQty,
 week1,week2,week3,week4,week5,week6,week7,hour0,hour1,hour2,hour3,hour4,  
 hour5,hour6,hour7,hour8,hour9,hour10,hour11,hour12,hour13,hour14,hour15,hour16,
 hour17,hour18,hour19,hour20,hour21,hour22,hour23,bJiOu ,fQty_Ji ,fPrice_ji ,fQty_Ou ,fPrice_Ou,fRatio_JiOu
from PosManagement.dbo.t_PloyOfSale                       
where dbo.getDayStr(getdate())>=dbo.getDayStr(dDateStart) and dbo.getDayStr(getdate())<=dbo.getDayStr(dDateEnd)  and isnull(bEnabled,0)=1 and isnull(bSuspend,0)=0 
and cGoodsNo  not in                
(select cGoodsNo from PosManagement.dbo.t_PloyOfSale_Mult 
 where cPloyNo in                            
   (select distinct cPloyNo from PosManagement.dbo.t_PloyOfSale      
   where dbo.getDayStr(getdate())>=dbo.getDayStr(dDateStart) and dbo.getDayStr(getdate())<=dbo.getDayStr(dDateEnd)  and isnull(bSuspend,0)=0 
   )  
)  
union all                                                 
select b.fVipValue,b.cPloyNo,b.cGoodsNo,b.cGoodsName,a.fQuantity_Ploy,a.fPrice_SO, 
b.dDateStart,b.cTimeStart,b.dDateEnd,b.cTimeEnd,b.iPriority,b.bSO,b.bPresent, 
 b.cPresentPloyNo,b.cPloyTypeNo,b.cPloyTypeName,b.bEnabled,b.bLimitQty,b.fLimitQty,
 b.week1,b.week2,b.week3,b.week4,b.week5,b.week6,b.week7,b.hour0,b.hour1,b.hour2,  
 b.hour3,b.hour4,b.hour5,b.hour6,b.hour7,b.hour8,b.hour9,b.hour10,b.hour11,b.hour12,
 b.hour13,b.hour14,b.hour15,b.hour16,        
 b.hour17,b.hour18,b.hour19,b.hour20,b.hour21,b.hour22,b.hour23,b.bJiOu ,b.fQty_Ji ,b.fPrice_ji ,b.fQty_Ou ,b.fPrice_Ou,b.fRatio_JiOu 
from                                          
(select cPloyNo,cGoodsName,cGoodsNo,fQuantity_Ploy,fPrice_SO 
 from PosManagement.dbo.t_PloyOfSale_Mult      
 where cPloyNo in                
   (select distinct cPloyNo from PosManagement.dbo.t_PloyOfSale    
   where dbo.getDayStr(getdate())>=dbo.getDayStr(dDateStart) and dbo.getDayStr(getdate())<=dbo.getDayStr(dDateEnd)  and isnull(bSuspend,0)=0 
   )          
) a,PosManagement.dbo.t_PloyOfSale b  
where   isnull(b.bEnabled,0)=1 and isnull(b.bSuspend,0)=0  and a.cPloyNo=b.cPloyNo and a.cGoodsNo=b.cGoodsNo

GO
