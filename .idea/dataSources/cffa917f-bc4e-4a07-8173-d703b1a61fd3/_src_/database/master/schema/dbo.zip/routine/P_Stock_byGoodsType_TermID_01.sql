
CREATE    procedure [dbo].[P_Stock_byGoodsType_TermID_01] ----智能采购系统 采购辅助系统
@dBeginDate datetime,
@dEndDate datetime,
@WHno varchar(32),/*是仓库No*/
@bJiaGong bit,
@cTermID varchar(32),
@cStoreNo varchar(32)
as
begin 
  --select * into #temp_Goods from t_goods where bStorage=1
  
   if (select object_id('tempdb..#temp_Goods')) is not null 
 drop table #temp_Goods
 create table #temp_Goods(cGoodsNo varchar(32)) 
 exec('
   insert into #temp_Goods(cGoodsNo)
   select cGoodsNo from U_Key.dbo.temp_Goods'+@cTermID+'
 ')
--               生成本类型商品的关联信息                                           
  select cGoodsNo into #temp_goods1 from #temp_Goods     --#temp_Goods 在delphi程序中已创建的临时表
  union
  select cGoodsNo from t_goods where cProductNo in 
  (select cProductNo from t_GoodsProducted where cGoodsNo in (select cGoodsNo from #temp_Goods))
  union
  select cGoodsNo from t_GoodsProducted 
  where cProductNo in (select cProductNo from t_Goods where cGoodsNo in (select cGoodsNo from #temp_Goods))  
  union
  select cGoodsNo from t_goods where cProductNo in
  (
    select cProductNo from t_goodsProducted where cGoodsNo in
    (
    select cGoodsNo from t_GoodsProducted where cProductNo in (select cProductNo from t_Goods where cGoodsNo in (select cGoodsNo from #temp_Goods))
    )
  ) 
  select a.cGoodsNo,b.cProductNo,b.fPreservationUp,b.fPreservationDown,b.fPreservation_soft 
  into #temp_goods2 from #temp_goods1 a,t_goods b where a.cGoodsNo=b.cGoodsNo
  
  select a.cGoodsNo,a.cProductNo,a.fPreservationUp,a.fPreservationDown,a.fPreservation_soft,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then a.cGoodsNo 
              else b.cGoodsNo 
         end as GoodsNo_Pdt,
         case when (a.cProductNo is null) or ltrim(a.cProductNo)=''
              then 1
              else isnull(b.fQuantity,0) 
         end as Qty
  into #t_Goods0 
  from #temp_goods2 a left join t_GoodsProducted b  
                 on a.cProductNo=b.cProductNo
  
  select a.cGoodsNo,a.cProductNo,b.cUnitedNo,a.GoodsNo_Pdt,a.Qty,a.fPreservationUp,a.fPreservationDown,
  a.fPreservation_soft into #t_Goods from #t_Goods0 a left join t_Goods b on a.cGoodsNo=b.cGoodsNo
                  where a.GoodsNo_Pdt is not null

--                 入库单                 开始    
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_InWarehouseDetail_shelf 
  from #t_goods a, 
      wh_InWarehouseDetail b,wh_InWarehouse c
  where  a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (c.cWhNo=@WHno and c.dDate between @dBeginDate and @dEndDate and c.bExamin=1)

  select a.cGoodsNo,avgInPrice=avg(b.fInPrice)
  into #temp_avgInPrice
  from #t_goods a,
       wh_InWarehouseDetail b,wh_InWarehouse c
  where  a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (c.cWhNo=@WHno and c.dDate<=@dEndDate and c.bExamin=1)
  group by a.cGoodsNo  

  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_InWarehouseDetail1  --入库单
  from #wh_InWarehouseDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_InWarehouseDetail    --所有商品的入库数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_InWarehouseDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by t.GoodsNo
--                 入库单                 结束    

--                 退货入库单                 开始     
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #WH_ReturnGoodsDetail_shelf 
  from t_goods a, 
      WH_ReturnGoodsDetail b,WH_ReturnGoods c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno  and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #WH_ReturnGoodsDetail1  --退货入库单
  from #WH_ReturnGoodsDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #WH_ReturnGoodsDetail    --所有商品的退货入库数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #WH_ReturnGoodsDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo

--                 退货入库单                 结束    

--                出库单                 开始   
/*
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_OutWarehouseDetail_shelf 
  from #t_goods a, 
      wh_OutWarehouseDetail b,wh_OutWarehouse c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)
                        */
    select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_OutWarehouseDetail_shelf 
  from #t_goods a, 
      wh_cStoreOutWarehouseDetail b,wh_cStoreOutWarehouse c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1 and isnull(c.bShip,0)=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_OutWarehouseDetail1  --出库单
  from #wh_OutWarehouseDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_OutWarehouseDetail    --所有商品的出库数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_OutWarehouseDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo

 --               出库单                 结束   

--               返厂单                 开始   
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_RbdWarehouseDetail_shelf 
  from #t_goods a, 
      wh_RbdWarehouseDetail b,wh_RbdWarehouse c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno  and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_RbdWarehouseDetail1  --返厂单
  from #wh_RbdWarehouseDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_RbdWarehouseDetail    --所有商品的返厂数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_RbdWarehouseDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--                返厂单                 结束  

--               调拨单                 开始   
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_TfrWarehouseDetail_shelf 
  from #t_goods a, 
      wh_TfrWarehouseDetail b,wh_TfrWarehouse c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)

  
  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_TfrWarehouseDetail1  --调拨单
  from #wh_TfrWarehouseDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_TfrWarehouseDetail    --所有商品的调拨数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_TfrWarehouseDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--               调拨单                 结束    

--                报损单                 开始  
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_LossWarehouseDetail_shelf 
  from #t_goods a, 
      wh_LossWarehouseDetail b,wh_LossWarehouse c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_LossWarehouseDetail1  --报损单
  from #wh_LossWarehouseDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_LossWarehouseDetail    --所有商品的报损数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_LossWarehouseDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--                 报损单                 结束    

--               溢出单                 开始    
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_EffusionWhDetail_shelf 
  from #t_goods a, 
      wh_EffusionWhDetail b,wh_EffusionWh c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_EffusionWhDetail1  --溢出单
  from #wh_EffusionWhDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_EffusionWhDetail    --所有商品的溢出数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_EffusionWhDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--                溢出单                 结束   

--               兑奖单                 开始    
  select a.cGoodsNo,b.fQuantity,fLastSettle=b.fMoney,b.cSheetno,
         b.cProductSerno,b.fPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_ExchangeDetail_shelf 
  from #t_goods a, 
      wh_ExchangeDetail b,wh_Exchange c
        where a.cGoodsNo=b.cGoodsNo
  and  b.cSheetno=c.cSheetno and c.cStoreNo=@cStoreNo
                        and (cWhNo=@WHno and dDate between @dBeginDate and @dEndDate and c.bExamin=1)


  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_ExchangeDetail1  --兑奖单
  from #wh_ExchangeDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #wh_ExchangeDetail    --所有商品的兑奖数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #wh_ExchangeDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--                 兑奖单                 结束   
/*                 拆分单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_DivideWhDetail_shelf 
  from #t_goods a 
      left join dbo.wh_DivideWhDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 and b.cSheetno in (select cSheetno from dbo.wh_Divide where cWhNo=@WHno and dDate between @dBeginDate and @dEndDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fInPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_DivideWhDetail0  --拆分单０
  from #wh_DivideWhDetail_shelf a  
       left join wh_Divide b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1  and b.cStoreNo=@cStoreNo

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_DivideWhDetail1  --拆分单
  from #wh_DivideWhDetail0
  where isnull(bChecked,0)<>1 --and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_DivideWhDetail    
	from
	  (select b.GoodsNo_Pdt as GoodsNo,
         a.qty*b.qty as Qty
		from #wh_DivideWhDetail1 a
  	     left join #t_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo
  
/*                 包装单                     */ 
  select a.cGoodsNo,a.cUnitedNo,b.fQuantity,fLastSettle=b.fInMoney,b.cSheetno,
         b.cProductSerno,b.fInPrice,b.fTaxrate,b.fTaxPrice,b.dProduct,b.bChecked
  into #wh_PackDetail_shelf 
  from #t_goods a 
      left join dbo.wh_PackDetail b
        on  isnull(b.bChecked,0)<>1 and a.cGoodsNo=b.cGoodsNo
  where  isnull(b.bChecked,0)<>1 and b.cSheetno in (select cSheetno from dbo.wh_Pack where cWhNo=@WHno and dDate between @dBeginDate and @dEndDate)

  select a.cGoodsNo,a.cUnitedNo,a.fQuantity,a.cProductSerno,a.fInPrice,a.fTaxrate,
         a.fTaxPrice,a.dProduct,a.bChecked,
         b.cWhNo,b.cWh,b.dDate,b.cTime
  into #wh_PackDetail0  --包装单０
  from #wh_PackDetail_shelf a  
       left join wh_Pack b
            on  a.cSheetno =b.cSheetno   
  where isnull(a.bChecked,0)<>1 and b.cStoreNo=@cStoreNo

  select cGoodsNo,cUnitedNo,sum(isnull(fQuantity,0)) as Qty
  into #wh_PackDetail1  --包装单
  from #wh_PackDetail0
  where bChecked<>1-- and dDate<=@dCheckDate
  group by cGoodsNo,cUnitedNo 

  select t.GoodsNo,qty=sum(t.Qty)
  into #wh_PackDetail    
	from
	  (select b.GoodsNo_Pdt as GoodsNo,
         a.qty*b.qty as Qty
		from #wh_PackDetail1 a
  	     left join #t_Goods b
    	        on a.cGoodsNo=b.cGoodsNo 
		) t
	group by GoodsNo
 

--                销售单                 开始    
  select a.cGoodsNo,b.fQuantity
  into #t_SaleSheetDetail_shelf 
  from #t_goods a 
      , t_SaleSheetDetail b
        where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo
  and  (b.dSaleDate between @dBeginDate and @dEndDate)
  and isnull(tag_daily,0)=0
  union all
  select a.cGoodsNo,b.fQuantity
  --into #t_SaleSheetDetail_shelf
  from #t_goods a,
       t_SaleSheet_Day b
         where a.cGoodsNo=b.cGoodsNo and b.cStoreNo=@cStoreNo
  and  b.dSaleDate between @dBeginDate and @dEndDate

  select cGoodsNo,sum(isnull(fQuantity,0)) as Qty
  into #t_SaleSheetDetail1  --销售单
  from #t_SaleSheetDetail_shelf
  group by cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,qty=sum(t.Qty)
	  into #t_SaleSheetDetail    --所有商品的销售数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,
	         a.qty*b.qty as Qty
			from #t_SaleSheetDetail1 a
	  	     , #t_Goods b
	    	        where a.cGoodsNo=b.cGoodsNo 
			) t
		group by GoodsNo
--               销售单                 结束 

--期初库存状态
  select distinct a.cgoodsno,dsaledate=max(a.dsaledate) into #temp_tableRiJieBegin0
  from t_saleSheet_day a right join #t_Goods b on a.cGoodsNo=b.cGoodsNo--a.cGoodsNo=b.GoodsNo_Pdt
   where a.dsaledate<@dBeginDate and a.cStoreNo=@cStoreNo
  group by a.cgoodsNo
  order by a.cgoodsno 

  select distinct a.cgoodsNo,dsaledate=@dBeginDate,b.fQty_BeginWH,b.fQty_CurWH into #temp_tableRiJieBegin1
  from #temp_tableRiJieBegin0 a left join t_saleSheet_day b on a.cgoodsno=b.cgoodsno and a.dsaledate=b.dsaledate
  where  b.cStoreNo=@cStoreNo

  select a.cGoodsNo,fBeginQuantity_Diff=sum(isnull(b.fQuantity_Diff,0)) into #BeginQuantity_Diff
  from #t_Goods a left join t_ChecKTast_GoodsDetail b on a.cGoodsNo=b.cGoodsNo
                                left join t_CheckTast c on b.cCheckTaskNo=c.cCheckTaskNo
                                left join t_goods d on a.cGoodsNo=d.cGoodsNo
  where c.dCheckTask<=@dBeginDate and (c.bChecked is not null) and d.bProducted<>1
  and c.cStoreNo=@cStoreNo
  group by a.cGoodsNo

  select a.cGoodsNo,fEndQuantity_Diff=sum(isnull(b.fQuantity_Diff,0)) into #EndQuantity_Diff
  from #t_Goods a left join t_ChecKTast_GoodsDetail b on a.cGoodsNo=b.cGoodsNo
                                left join t_CheckTast c on b.cCheckTaskNo=c.cCheckTaskNo
                                left join t_goods d on a.cGoodsNo=d.cGoodsNo
  where (c.dCheckTask>@dBeginDate and c.dCheckTask<=@dEndDate) and (c.bChecked is not null) and d.bProducted<>1 
  and c.cStoreNo=@cStoreNo
  group by a.cGoodsNo

  if @bJiaGong=1
	  select t.GoodsNo,fQty_BeginWH=sum(isnull(t.fQty_BeginWH,0)),fQty_CurWH=sum(isnull(fQty_CurWH,0)),t.dsaledate
	  into #temp_tableRiJieBegin    --所有商品的期初库存数量（含加工）
		from
		  (select b.GoodsNo_Pdt as GoodsNo,a.dsaledate,
	         a.fQty_BeginWH*b.qty as fQty_BeginWH,
	         a.fQty_CurWH*b.qty as fQty_CurWH
			from #temp_tableRiJieBegin1 a
	  	     left join #t_Goods b
	    	        on a.cGoodsNo=b.cGoodsNo 
			) t
		group by t.GoodsNo,t.dsaledate 

--合并  开始
  if @bJiaGong=1
    select distinct a.GoodsNo_Pdt,b.fCKPrice,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,BeginQty=isnull(c.fQty_CurWH,0)+isnull(p.fBeginQuantity_Diff,0),EndDate=@dEndDate,/*EndQty=d.fQty_CurWH,*/
                  EndQty=isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                               -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0),/*调拨单未算进来*/
                  avgInPrice=n.avgInPrice,rkQty=e.qty,thrkQty=f.qty,ckQty=g.qty,fcQty=h.qty,dbQty=i.qty,bsQty=j.qty,byQty=k.qty,djQty=l.qty,xsQty=m.qty,
                  DivideQty=Divide.Qty,PackQty=Pack.Qty,
					
					avgInPriceMoney=n.avgInPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                               -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fCKPriceMoney=b.fCKPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                             -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fNormalPriceMoney=b.fNormalPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                             -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fEndQuantity_Diff=isnull(q.fEndQuantity_Diff,0)
		,a.fPreservationUp,a.fPreservationDown,a.fPreservation_soft

    into #temp_goodsKuCun from #t_Goods a 
                             left join t_goods b on a.GoodsNo_Pdt=b.cGoodsNo
                             left join #temp_avgInPrice n on a.GoodsNo_Pdt=n.cGoodsNo
                             left join #temp_tableRiJieBegin c on a.GoodsNo_Pdt=c.GoodsNo
                             --left join #temp_tableRiJieEnd d on a.GoodsNo_Pdt=d.GoodsNo
                             left join #wh_InWarehouseDetail e on a.GoodsNo_Pdt=e.GoodsNo
                             left join #WH_ReturnGoodsDetail f on a.GoodsNo_Pdt=f.GoodsNo
                             left join #wh_OutWarehouseDetail g on a.GoodsNo_Pdt=g.GoodsNo
                             left join #wh_RbdWarehouseDetail h on a.GoodsNo_Pdt=h.GoodsNo
                             left join #wh_TfrWarehouseDetail i on a.GoodsNo_Pdt=i.GoodsNo
                             left join #wh_LossWarehouseDetail j on a.GoodsNo_Pdt=j.GoodsNo
                             left join #wh_EffusionWhDetail k on a.GoodsNo_Pdt=k.GoodsNo
                             left join #wh_ExchangeDetail l on a.GoodsNo_Pdt=l.GoodsNo
                             left join #t_SaleSheetDetail m on a.GoodsNo_Pdt=m.GoodsNo
                             left join #BeginQuantity_Diff p on a.GoodsNo_Pdt=p.cGoodsNo
                             left join #EndQuantity_Diff q on a.GoodsNo_Pdt=q.cGoodsNo
				     left join #wh_DivideWhDetail Divide  on a.GoodsNo_Pdt=Divide.GoodsNo--期间拆分数量
				     left join #wh_PackDetail Pack  on a.GoodsNo_Pdt=Pack.GoodsNo--期间包装数量
  else
    select distinct GoodsNo_Pdt=a.cGoodsNo,b.fCKPrice,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,BeginQty=isnull(c.fQty_CurWH,0)+isnull(p.fBeginQuantity_Diff,0),EndDate=@dEndDate,/*EndQty=d.fQty_CurWH,*/
                  EndQty=isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                          -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0),/*调拨单未算进来*/
                  avgInPrice=n.avgInPrice,rkQty=e.qty,thrkQty=f.qty,ckQty=g.qty,fcQty=h.qty,dbQty=i.qty,bsQty=j.qty,byQty=k.qty,djQty=l.qty,xsQty=m.qty,
                  DivideQty=Divide.Qty,PackQty=Pack.Qty,

                  avgInPriceMoney=n.avgInPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                                       -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fCKPriceMoney=b.fCKPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                                       -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fNormalPriceMoney=b.fNormalPrice * (isnull(c.fQty_CurWH,0)+isnull(e.qty,0)+isnull(f.qty,0)
                                                       -isnull(Divide.Qty,0)+isnull(Pack.Qty,0)-isnull(g.qty,0)-isnull(h.qty,0)-isnull(j.qty,0)+isnull(k.qty,0)-isnull(l.qty,0)-isnull(m.qty,0)+isnull(q.fEndQuantity_Diff,0)),
                  fEndQuantity_Diff=isnull(q.fEndQuantity_Diff,0)
		,a.fPreservationUp,a.fPreservationDown,a.fPreservation_soft

    into #temp_goodsKuCun1 from #t_Goods a 
                             left join t_goods b on a.cGoodsNo=b.cGoodsNo
                             left join #temp_avgInPrice n on a.cGoodsNo=n.cGoodsNo
                             left join #temp_tableRiJieBegin1 c on a.cGoodsNo=c.cGoodsNo
                             --left join #temp_tableRiJieEnd1 d on a.cGoodsNo=d.cGoodsNo
                             left join #wh_InWarehouseDetail1 e on a.cGoodsNo=e.cGoodsNo
                             left join #WH_ReturnGoodsDetail1 f on a.cGoodsNo=f.cGoodsNo
                             left join #wh_OutWarehouseDetail1 g on a.cGoodsNo=g.cGoodsNo
                             left join #wh_RbdWarehouseDetail1 h on a.cGoodsNo=h.cGoodsNo
                             left join #wh_TfrWarehouseDetail1 i on a.cGoodsNo=i.cGoodsNo
                             left join #wh_LossWarehouseDetail1 j on a.cGoodsNo=j.cGoodsNo
                             left join #wh_EffusionWhDetail1 k on a.cGoodsNo=k.cGoodsNo
                             left join #wh_ExchangeDetail1 l on a.cGoodsNo=l.cGoodsNo
                             left join #t_SaleSheetDetail1 m on a.cGoodsNo=m.cGoodsNo
                             left join #BeginQuantity_Diff p on a.GoodsNo_Pdt=p.cGoodsNo
                             left join #EndQuantity_Diff q on a.GoodsNo_Pdt=q.cGoodsNo
				     left join #wh_DivideWhDetail Divide  on a.GoodsNo_Pdt=Divide.GoodsNo--期间拆分数量
				     left join #wh_PackDetail Pack  on a.GoodsNo_Pdt=Pack.GoodsNo--期间包装数量

--合并  结束

 if (select object_id('tempdb..#temp_result')) is not null 
   drop table #temp_result
   create table #temp_result (iLineNo int identity(1,1),bStocking bit DEFAULT ((0)),bSelected bit DEFAULT ((0)),
   cGoodsNo varchar(32),cUnitedNo varchar(32),cGoodsName varchar(64), cBarcode  varchar(32),cUnit  varchar(32)
   ,cSpec  varchar(32),cGoodsTypeno  varchar(32),  cGoodsTypename  varchar(64),bProducted bit,cProductNo  varchar(32), 
   BeginDate datetime,BeginQty money,EndDate datetime,EndQty money, rkQty money,thrkQty money,ckQty money,fcQty money,  
   dbQty money,bsQty money,byQty money,djQty money,xsQty money,DivideQty money,PackQty money, fCKPrice money,
   fNormalPrice money,avgInPrice money,  fCKPriceMoney money,fNormalPriceMoney money,avgInPriceMoney money, 
   fEndQuantity_Diff money,fPreservationUp money ,fPreservationDown money , fPreservation_soft money,fPrice_lowest money,
   fPrice_Highest money,fPrice_Last money, fQty_Adv money,fQty_Exe Money,fPrice_Exe money,cSupplierNo varchar(32),
   cSupplier varchar(64),fPrice_Contract money ,fPackRatio money)  
   
   

  if @bJiaGong=1
  begin
 
    insert into #temp_result 
    (cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff
    )
   
	  select cGoodsNo=GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
	         BeginDate,BeginQty=isnull(BeginQty,0),EndDate,EndQty=isnull(EndQty,0),
	         rkQty=isnull(rkQty,0),thrkQty=isnull(thrkQty,0),ckQty=isnull(ckQty,0),fcQty=isnull(fcQty,0),
	         dbQty=isnull(dbQty,0),bsQty=isnull(bsQty,0),byQty=isnull(byQty,0),djQty=isnull(djQty,0),xsQty=isnull(xsQty,0),
           DivideQty=isnull(DivideQty,0) ,PackQty=isnull(PackQty,0) ,
           fCKPrice=isnull(fCKPrice,0),fNormalPrice=isnull(fNormalPrice,0),avgInPrice=isnull(avgInPrice,0),
           fCKPriceMoney=isnull(fCKPriceMoney,0),fNormalPriceMoney=isnull(fNormalPriceMoney,0),avgInPriceMoney=isnull(avgInPriceMoney,0),
           fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
	--	,fPreservationUp,fPreservationDown,fPreservation_soft
	  from #temp_goodsKuCun
	  order by cGoodsTypeno,GoodsNo_Pdt
	   
  end
  else
  begin
 
    insert into #temp_result 
    (cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff
    )
   select cGoodsNo=GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
	         BeginDate,BeginQty=isnull(BeginQty,0),EndDate,EndQty=isnull(EndQty,0),
	         rkQty=isnull(rkQty,0),thrkQty=isnull(thrkQty,0),ckQty=isnull(ckQty,0),fcQty=isnull(fcQty,0),
	         dbQty=isnull(dbQty,0),bsQty=isnull(bsQty,0),byQty=isnull(byQty,0),djQty=isnull(djQty,0),xsQty=isnull(xsQty,0),
           DivideQty=isnull(DivideQty,0) ,PackQty=isnull(PackQty,0) ,
           fCKPrice=isnull(fCKPrice,0),fNormalPrice=isnull(fNormalPrice,0),avgInPrice=isnull(avgInPrice,0),
           fCKPriceMoney=isnull(fCKPriceMoney,0),fNormalPriceMoney=isnull(fNormalPriceMoney,0),avgInPriceMoney=isnull(avgInPriceMoney,0),
           fEndQuantity_Diff=isnull(fEndQuantity_Diff,0)
		--,fPreservationUp ,fPreservationDown ,fPreservation_soft 
	  from #temp_goodsKuCun1
	  order by cGoodsTypeno,GoodsNo_Pdt
  
    
  end
  
  --重构当前库存
  
  update  a
  set a.EndQty=b.EndQty
  from #temp_result a ,t_goodsKuCurQty_wei b
  where b.cStoreNo=@cStoreNo and a.cGoodsNo=b.cGoodsNo
  
  
  update  a
  set a.fPreservationUp=b.fPreservationUp ,a.fPreservationDown=b.fPreservationDown ,
      a.fPreservation_soft =b.fPreservation_soft
  from #temp_result a ,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
/*最优库存fPreservation_soft*/
  update #temp_result
  set fQty_Adv=fPreservation_soft-EndQty  
  where isnull(fPreservation_soft,0)>0 and isnull(fPreservation_soft,0)>EndQty
  
  update a set a.fPrice_Highest=b.fPrice_In
  from #temp_result a,(select cGoodsNo,fPrice_In=max(fInPrice) from dbo.wh_InWarehouseDetail  group by cGoodsNo )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.fPrice_lowest=b.fPrice_In
  from #temp_result a,(select cGoodsNo,fPrice_In=min(fInPrice) from  dbo.wh_InWarehouseDetail where fInPrice>0 group by cGoodsNo )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.fPrice_Last=b.fPrice_In
  from #temp_result a,
  (select distinct c.cGoodsNo,fPrice_In=c.fInPrice 
   	from  
		( select p.cGoodsNo,p.fInPrice,dDateTime=q.dDate
      from 
			 dbo.wh_InWarehouseDetail p, wh_InWarehouse q
      where p.cSheetno=q.cSheetno and q.cStoreNo=@cStoreNo
		)c,

		(select x.cGoodsNo,dDateTime=max(x.dDateTime) 
	 		from 
   		( select distinct n.cGoodsNo,dDateTime=m.dDate
   		 	 from dbo.wh_InWarehouse m,dbo.wh_InWarehouseDetail n
     		where m.cSheetno=n.cSheetno and m.cStoreNo=@cStoreNo
     
   		)x  group by x.cGoodsNo
		) d
   where c.fInPrice>0  and c.cGoodsNo=d.cGoodsNo and c.dDateTime=d.dDateTime
  )b
  where a.cGoodsNo=b.cGoodsNo

  update a set a.cSupplierNo=b.cSupNo,a.cSupplier=b.cSupName,a.bStocking=b.bStocking
  from #temp_result a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo
   

  exec('
     insert into U_key.dbo.temp_result'+@cTermID+' 
    (bStocking,bSelected,cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff,fPreservationUp ,fPreservationDown , fPreservation_soft,fPrice_lowest,
   fPrice_Highest,fPrice_Last, fQty_Adv,fQty_Exe,fPrice_Exe,cSupplierNo,
   cSupplier,fPrice_Contract ,fPackRatio
    )
    select bStocking,bSelected,cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,cGoodsTypeno,
     cGoodsTypename,bProducted,cProductNo,BeginDate,BeginQty,EndDate,EndQty,
	         rkQty,thrkQty,ckQty,fcQty,
	         dbQty,bsQty,byQty,djQty,xsQty,DivideQty ,PackQty ,
           fCKPrice,fNormalPrice,avgInPrice,
           fCKPriceMoney,fNormalPriceMoney,avgInPriceMoney,
           fEndQuantity_Diff,fPreservationUp ,fPreservationDown , fPreservation_soft,fPrice_lowest,
   fPrice_Highest,fPrice_Last, fQty_Adv,fQty_Exe,fPrice_Exe,cSupplierNo,
   cSupplier,fPrice_Contract ,fPackRatio
           from  #temp_result
           
  ')

/*
   fPrice_adv,fPrice_Exe,fPrice_lowest,fPrice_Highest,fPrice_last
*/
end

--[P_Stock_byGoodsType] '2008-11-23','2009-11-24','01'

GO
