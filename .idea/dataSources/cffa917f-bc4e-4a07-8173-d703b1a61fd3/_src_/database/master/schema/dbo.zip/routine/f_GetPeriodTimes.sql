create function f_GetPeriodTimes
(@iDay int,@dDate1 datetime,@dDate2 datetime) returns int
as
begin
  declare @iPeriodTimes int
  
	set @iPeriodTimes=DATEDIFF("mm",@dDate1,@dDate2)  
  if @iPeriodTimes=0 
  begin
    if @iDay between DATEPART(dd,@dDate1) and DATEPART(dd,@dDate2)
    begin
      set @iPeriodTimes=1
    end
  end else
  if @iPeriodTimes>0
  begin
    if @iDay between DATEPART(dd,@dDate1) and DATEPART(dd,@dDate2)
    begin
      set @iPeriodTimes=@iPeriodTimes+1
    end 
    if (@iDay>DATEPART(dd,@dDate2)) and (@iDay<DATEPART(dd,@dDate1))
    begin
      set @iPeriodTimes=@iPeriodTimes-1
    end else
    begin
      set @iPeriodTimes=@iPeriodTimes
    end

  end else
  begin
    set @iPeriodTimes=0
  end

  return @iPeriodTimes
end
GO
