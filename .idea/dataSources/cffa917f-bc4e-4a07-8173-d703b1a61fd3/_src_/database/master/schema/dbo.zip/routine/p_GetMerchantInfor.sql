
create proc p_GetMerchantInfor
@Merchantid varchar(64)  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
as
begin 
   select 
   cStoreNo as merchantID,  --商家的唯一标识符，可以是手机号、邮箱、 身份证号、微信 openID、QQ 号
   cStoreName as realName,--商家名称
   image_path,--商家图片路径
   cStoreAbbName as nickName,--商家简称
   dOpenDate as registerDate,  --注册时间
   cManager,   --负责人
   cTel,       --固定电话
   cMobilPhone, --手机号
   cAddRess     --商家地址
   from t_Store
   where cStoreNo=@Merchantid
   
end


GO
