/*
   exec p_UpGoodsPSPrice'340101',10,1
*/
CREATE proc [dbo].[p_UpGoodsPsPrice]
@cGoodsTypeNo varchar(32),
@fPsRate money,
@fPSType varchar(16)
as
begin
   --合同价
   --update t_Goods set fPsprice=case when ISNULL(fPrice_Contract,0)=0 
   --                                 then 
   --                                     case when ISNULL(fCKPrice,0)=0 
   --                                     then ISNULL(fNormalPrice,0)*(1+@fPsRate*1.00/100) 
   --                                     else ISNULL(fCKPrice,0)*(1+@fPsRate*1.00/100)  
   --                                     end 
   --                                 else ISNULL(fPrice_Contract,0)*(1+@fPsRate*1.00/100)  
   --                                 end
   --where cGoodsTypeNo=@cGoodsTypeNo and ISNULL(bOnePSPrice,0)=0
   --- 最新价
      update t_Goods set fPsprice=case when ISNULL(fCKPrice,0)=0 
                                    then 
                                        case when ISNULL(fCKPrice,0)=0 
                                        then ISNULL(fCKPrice,0)*(1+@fPsRate*1.00/100) 
                                        else ISNULL(fCKPrice,0)*(1+@fPsRate*1.00/100)  
                                        end 
                                    else ISNULL(fCKPrice,0)*(1+@fPsRate*1.00/100)  
                                    end
   where cGoodsTypeNo=@cGoodsTypeNo and ISNULL(bOnePSPrice,0)=0
     
 --    select fCKPrice,ISNULL(fCKPrice,0)*(1+10.00/100),fPsprice=case when ISNULL(fCKPrice,0)=0 
 --                                   then 
 --                                       case 
 --                                       when ISNULL(fPrice_Contract,0)=0 
 --                                       then ISNULL(fNormalPrice,0)*(1+10/100) 
 --                                       else ISNULL(fPrice_Contract,0)*(1+10/100)  
 --                                       end 
 --                                   else 
 --                                     ISNULL(fCKPrice,0)*(1+10/100)  
 --                                   end
 --                                   from t_Goods
 --  where cGoodsNo='04004' and ISNULL(bOnePSPrice,0)=0
   
 --select round(10.00/100,3) 
 
 
 
 
end
GO
