


create    function [dbo].[f_GencStoreOutsheetno_Diff]
(@cYear varchar(4),@cCustomerNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.wh_cStoreOutVerifySheet_Diff
/*
                  where cCustomerNo=@cCustomerNo
                        and datename(yyyy,dDate)=@cYear
*/
                  where (cCustomerNo=@cCustomerNo
                        and datename(yyyy,dDate)=@cYear)
												or
												(substring(cSheetno,7,PatIndex('%-%',cSheetno)-7)=@cCustomerNo
												 and datename(yyyy,dDate)=@cYear	
												)
                 )
   if @cMaxSerno is null 
   begin
     return  'CYYH'+@cYear+@cCustomerNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'CYYH'+@cYear+@cCustomerNo+'-'+@cMaxSerno 
   end

  return '' 
end


GO
