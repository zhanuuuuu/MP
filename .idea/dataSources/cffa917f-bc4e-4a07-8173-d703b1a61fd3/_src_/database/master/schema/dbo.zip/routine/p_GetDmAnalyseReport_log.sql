 
 /*
 
if (select object_id('tempdb..#tmpSupList'))is not null drop table #tmpSupList
create table #tmpSupList(supno varchar(32))
insert into #tmpSupList(supno)select cGoodsTypeno from t_GoodsType where cGoodsTypeno like '2%'

 exec  p_GetDmAnalyseReport_log '2014-12-27','2015-01-04','20140005','01'
 go
 exec  p_GetDmAnalyseReport_log_Day '2014-12-27','2015-01-04','20140005','01'
 
 
 */
CREATE proc [dbo].[p_GetDmAnalyseReport_log]
@dDateBgn datetime,
@dDateEnd datetime,
@cPloyNo varchar(32),
@cWhno varchar(32)
as
begin 
 
if @dDateEnd>CONVERT (date, GETDATE())
begin
  set @dDateEnd=CONVERT (date, GETDATE())
end
 
declare @day int
set @day=DATEDIFF(DAY,@dDateBgn,@dDateEnd)+1 


if (select object_id('tempdb..#temp_Goods'))is not null
drop table #temp_Goods
-- 取相应类别下的商品。。。 				
select cGoodsNo into #temp_Goods from t_PloyOfSale  
where cPloyNo=@cPloyNo --and cGoodsNo='113493'

if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
select distinct cGoodsNo,cWHno=@cWhno into #tmpCostGoodsList 
from #temp_Goods 

 
if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo=b.cGoodsNo_minPackage,cWHno=@cWhno  into  #tmp_WhGoodsList  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsNo,cWHno=@cWhno   
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
 
CREATE INDEX IX_tmp_WhGoodsList ON #tmp_WhGoodsList(cGoodsNo)

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

declare  @cdbname varchar(32)

select distinct @cdbname=Pos_WH_Form,@cWhNo=cWhNo from t_WareHouse where ISNULL(bMainSale,0)=1

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin(业务日期 datetime,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money,fqtyleft money,fml money)
CREATE TABLE #temp_WhFromend(业务日期 datetime,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
  销售数量0 money, 销售金额0 money,fqtyleft money,fml money)
  
 /*快照表中的最大日期。。。*/
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)
insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
 
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
declare @BgndDate1 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
					set @BgndDate1=@dDate_1
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
					set @BgndDate1=@dDate_1
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd 
		--set @maxWhdDate=@dDateBgn-1
		set @BgndDate1=@maxWhdDate+1
	end 

-----查最大日结时间内信息@dDateBegin到@dDateEnd
 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
 
	--销售数量0, 销售金额0, 
	--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
	-------取记账部分：快照数据。
	
    declare @strDateBgn datetime
	declare @strDateEnd datetime
    declare @strBgn varchar(32)
    set @strDateBgn= @dDateBgn
    set @strDateEnd=@maxWhdDate
    set @strBgn=dbo.getdaystr(@dDateBgn)  
    
	    declare @date1 datetime
	    declare @a int  
	    declare @daylog int
	    set @daylog=DATEDIFF (DAY,@strDateBgn,@strDateEnd)+1 
	  
		set @a=0
		while @a<@daylog 
		begin		  
		    declare @d1 datetime
		    declare @dY1 varchar(8)
			declare @dM1  varchar(8)
			declare @dDay1  varchar(8)
			declare @MMDAY_1 varchar(8)
			set @dM1=MONTH(@strDateBgn-1+@a)
			set @dDay1=day(@strDateBgn-1+@a)
			set @dY1=YEAR(@strDateBgn-1+@a)
			if LEN(@dM1)=1 
			begin
			   set @dM1='0'+@dM1
			end
			if LEN(@dDay1)=1 
			begin
			   set @dDay1='0'+@dDay1
			end
			set @MMDAY_1=@dM1+@dDay1
			set @SQLstr='
			
			--------期初销售
    if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
	select a.cgoodsno, fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginQty
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@dM1+' b
	with (nolock) 
	where b.cyear='''+@dY1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
	            
	select a.cgoodsno, Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
	into #temp_Wh_Goods_beginSale					
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@dM1+' b
	with (nolock) 
	where b.cyear='''+@dY1+''' and  a.cGoodsNo=b.cGoodsNo


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
	select cgoodsno, fQty=sum(fQty), fQtytj=sum(fQtytj) 
	into #temp_SumWh_Goods_beginQty
	from  #temp_Wh_Goods_beginQty
	group by cgoodsno
	
	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
	select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
	into #temp_SumWh_Goods_beginSale
	from  #temp_Wh_Goods_beginSale
	group by cgoodsno
	 
	 
	
	insert into #temp_WhFrombegin(业务日期,cgoodsno,销售数量0)
	select '''+dbo.getdaystr(@strDateBgn-1+@a)+''',cgoodsno,fQty 
	from #temp_SumWh_Goods_beginQty
 
	 
    update a 
	set a.销售金额0=b.Sale 	
	from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
	where a.cGoodsNo=b.cGoodsNo and a.业务日期='''+dbo.getdaystr(@strDateBgn-1+@a)+'''
 
-------期初库存
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
	select a.cgoodsno,fQty=b.fQty_'+@MMDAY_1+',fMoney=b.fMoney_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_begin
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@dM1+' b
	with (nolock) 
	where b.cyear='''+@dY1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
	select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_begin
	from  #temp_Wh_Goods_begin
	group by cgoodsno
	

    update a 
	set a.fqtyleft=b.fQty 			
	from #temp_WhFrombegin a ,#temp_SumWh_Goods_begin b
	where a.cGoodsNo=b.cGoodsNo  and a.业务日期='''+dbo.getdaystr(@strDateBgn-1+@a)+'''
	
	----------期初成本
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginCost''))is not null  drop table #temp_Wh_Goods_beginCost
	select a.cgoodsno,fQty=b.fQtyIn_'+@MMDAY_1+',fMoney=b.fMoneyIn_'+@MMDAY_1+' 					 
	into #temp_Wh_Goods_beginCost
	from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@dM1+' b
	with (nolock) 
	where b.cyear='''+@dY1+''' and  a.cGoodsNo=b.cGoodsNo 
 

	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginCost''))is not null  drop table #temp_SumWh_Goods_beginCost
	select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
	into #temp_SumWh_Goods_beginCost
	from  #temp_Wh_Goods_beginCost
	group by cgoodsno
	

    update a 
	set a.fml=isnull(a.销售金额0,0)-isnull(b.fMoney,0)		
	from #temp_WhFrombegin a ,#temp_Wh_Goods_beginCost b
	where a.cGoodsNo=b.cGoodsNo  and a.业务日期='''+dbo.getdaystr(@strDateBgn-1+@a)+'''
	
	 '
	 
	 
			declare @d2 datetime
			declare @dY2 varchar(8)
			declare @dM2  varchar(8)
			declare @dDay2  varchar(8)
			declare @MMDAY_2 varchar(8)
			set @dM2=MONTH(@strDateBgn+@a)
			set @dDay2=day(@strDateBgn+@a)
			set @dY2=YEAR(@strDateBgn+@a)
			if LEN(@dM2)=1 
			begin
			set @dM2='0'+@dM2
			end
			if LEN(@dDay2)=1 
			begin
			set @dDay2='0'+@dDay2
			end
			set @MMDAY_2=@dM2+@dDay2

			set @SQLstr1='
						 --------期末销售
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
				select a.cgoodsno,fQty=b.fQty_'+@MMDAY_2+',fQtytj=b.fQtytj_'+@MMDAY_2+' 
				into #temp_Wh_Goods_endQty
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			 

				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale	            
				select a.cgoodsno,Sale=b.Sale_'+@MMDAY_2+', Saletj=b.Saletj_'+@MMDAY_2+' 
				into #temp_Wh_Goods_endSale					
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo


				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
				select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
				into #temp_SumWh_Goods_endQty
				from  #temp_Wh_Goods_endQty
				group by cgoodsno
				
				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
				select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
				into #temp_SumWh_Goods_endSale
				from  #temp_Wh_Goods_endSale
				group by cgoodsno
				 
				 
				
				insert into #temp_WhFromend(业务日期,cgoodsno,销售数量0)
				select '''+dbo.getdaystr(@strDateBgn+@a)+''',cgoodsno,fQty
				from #temp_SumWh_Goods_endQty 
				 
				update a 
				set a.销售金额0=b.Sale 	
				from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
				where a.cGoodsNo=b.cGoodsNo   and a.业务日期='''+dbo.getdaystr(@strDateBgn+@a)+'''
								
			----------期末成本
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
				select a.cgoodsno,fQty=b.fQtyIn_'+@MMDAY_2+',fMoney=b.fMoneyIn_'+@MMDAY_2+' 					 
				into #temp_Wh_Goods_endCost
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			 

				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
				select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
				into #temp_SumWh_Goods_endCost
				from  #temp_Wh_Goods_endCost
				group by cgoodsno
				

				update a 
				set a.fml=isnull(a.销售金额0,0)-isnull(b.fMoney,0)		
				from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
				where a.cGoodsNo=b.cGoodsNo   and a.业务日期='''+dbo.getdaystr(@strDateBgn+@a)+'''
				
			 
			----------期末库存	
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
				select a.cgoodsno,fQty=b.fQty_'+@MMDAY_2+',fMoney=b.fMoney_'+@MMDAY_2+' 		
				into #temp_Wh_Goods_end
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			  
				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
				select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
				into #temp_SumWh_Goods_end
				from  #temp_Wh_Goods_end
				group by cgoodsno
				 
				update a 
				set a.fqtyleft=b.fQty 		
				from #temp_WhFromend a ,#temp_SumWh_Goods_end b
				where a.cGoodsNo=b.cGoodsNo   and a.业务日期='''+dbo.getdaystr(@strDateBgn+@a)+'''
						 
				 ' 
				
			exec (@SQLstr+@SQLstr1)
			      
			set @a=@a+1
		end
	   	
	   	---表示开始日期超出最大的记账日期  
 
	    if @daylog<=0 
	    begin	      
			set @dM2=MONTH(@strDateEnd)
			set @dDay2=day(@strDateEnd)
			set @dY2=YEAR(@strDateEnd)
			if LEN(@dM2)=1 
			begin
			   set @dM2='0'+@dM2
			end
			if LEN(@dDay2)=1 
			begin
			   set @dDay2='0'+@dDay2
			end
			set @MMDAY_2=@dM2+@dDay2
		     
			set @SQLstr1='
			 --------期末销售
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
				select a.cgoodsno,fQty=b.fQty_'+@MMDAY_2+',fQtytj=b.fQtytj_'+@MMDAY_2+' 
				into #temp_Wh_Goods_endQty
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			 

				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale	            
				select a.cgoodsno,Sale=b.Sale_'+@MMDAY_2+', Saletj=b.Saletj_'+@MMDAY_2+' 
				into #temp_Wh_Goods_endSale					
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo


				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
				select cgoodsno,fQty=sum(fQty), fQtytj=sum(fQtytj) 
				into #temp_SumWh_Goods_endQty
				from  #temp_Wh_Goods_endQty
				group by cgoodsno
				
				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
				select cgoodsno,Sale=sum(Sale), Saletj=sum(Saletj) 
				into #temp_SumWh_Goods_endSale
				from  #temp_Wh_Goods_endSale
				group by cgoodsno
				  
				insert into #temp_WhFromend(业务日期,cgoodsno,销售数量0)
				select '''+dbo.getdaystr(@strDateEnd)+''',cgoodsno,fQty
				from #temp_SumWh_Goods_endQty 
				 
				update a 
				set a.销售金额0=b.Sale 	
				from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
				where a.cGoodsNo=b.cGoodsNo    and a.业务日期='''+dbo.getdaystr(@strDateBgn+@a)+'''
								
			----------期末成本
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endCost''))is not null  drop table #temp_Wh_Goods_endCost
				select a.cgoodsno,fQty=b.fQtyIn_'+@MMDAY_2+',fMoney=b.fMoneyIn_'+@MMDAY_2+' 					 
				into #temp_Wh_Goods_endCost
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Cost_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			 

				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endCost''))is not null  drop table #temp_SumWh_Goods_endCost
				select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
				into #temp_SumWh_Goods_endCost
				from  #temp_Wh_Goods_endCost
				group by cgoodsno				

				update a 
				set a.fml=0	
				from #temp_WhFromend a ,#temp_Wh_Goods_endCost b
				where a.cGoodsNo=b.cGoodsNo   and a.业务日期='''+dbo.getdaystr(@strDateEnd)+'''
				
			 
			----------期末库存	
				if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
				select a.cgoodsno,fQty=b.fQty_'+@MMDAY_2+',fMoney=b.fMoney_'+@MMDAY_2+' 		
				into #temp_Wh_Goods_end
				from #tmp_WhGoodsList a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Left_'+@dM2+' b
				with (nolock) 
				where b.cyear='''+@dY2+''' and  a.cGoodsNo=b.cGoodsNo 
			  
				if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
				select cgoodsno,fQty=sum(fQty), fMoney=sum(fMoney) 
				into #temp_SumWh_Goods_end
				from  #temp_Wh_Goods_end
				group by cgoodsno 
				 
				update a 
				set a.fqtyleft=b.fQty 		
				from #temp_WhFromend a ,#temp_SumWh_Goods_end b
				where a.cGoodsNo=b.cGoodsNo   and a.业务日期='''+dbo.getdaystr(@strDateEnd)+'''
                ' 
	        
			exec (@SQLstr+@SQLstr1)
			      
	    end

-------取未记账部分。------

---取记账之前的数据... 
	if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	create table #temp_ReadyKucun(
	cGoodsNo varchar(32),cUnitedNo varchar(32),endQtyOld money,EndQty money,
			xsQty money, xsMoney money,dDatetime datetime,fml money			
	)
	
if @maxWhdDate<@dDateEnd
begin  
    declare @dDateend1 date
    set @dDateend1=CONVERT (date, GETDATE())
    if @dDate_2>@dDateend1
    begin
      set @dDate_2=@dDateend1
    end
    
    if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null drop table #tmpPloyOfGoodsinfo
	select distinct b.cGoodsNo,b.cSupNo into #tmpPloyOfGoodsinfo  
	from #tmp_WhGoodsList a,t_goods b
	where a.cgoodsno=b.cgoodsno
	and ISNULL(b.bStorage,0)=1
	and a.cGoodsNo is not null

    declare @dMaxDailyDate datetime
    
	set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)
	
    if @dMaxDailyDate>@dDate_2
    begin
      set @dMaxDailyDate=@dDate_2
    end

    ---查@date1--@date2商品流水
    if (select OBJECT_ID('tempdb..#temp_jiesuan_for_day'))is not null drop table #temp_jiesuan_for_day
	if (select OBJECT_ID('tempdb..#temp_SaleSheet_day1'))is not null drop table #temp_SaleSheet_day1
	
	    select b.dSaleDate,cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
 		fQuantity=(isnull(b.fQuantity,0)),fMoney=isnull(b.fLastSettle,0)
		into #temp_SaleSheet_day1
		from #tmpPloyOfGoodsinfo a,t_SaleSheet_Day b 
		with (nolock) 
		where b.dSaleDate between @BgndDate1 and @dDate_2 and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo 
		union all
		select b.dSaleDate,cWHno=isnull(b.cWHno,@cWHno),a.cGoodsNo,b.bAuditing,
		fQuantity=isnull(b.fQuantity,0),fMoney=isnull(b.fLastSettle,0)
		from #tmpPloyOfGoodsinfo a,t_SaleSheetDetail b		
		where b.dSaleDate>=@BgndDate1 and b.dSaleDate between (@dMaxDailyDate+1) and @dDate_2 
		and a.cGoodsNo=b.cGoodsNo and ISNULL(b.cWhNo,'')=@cWhNo	
		
		
		select dDateTime=isnull(b.dSaleDate,@BgndDate1),a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=20+isnull(b.bAuditing,0),fMoney=isnull(-b.fMoney,0)
		into #temp_jiesuan_for_day   
		from #tmpPloyOfGoodsinfo a left join 
					(
						select dSaleDate,cWHno,cGoodsNo,bAuditing,fQuantity=sum(isnull(fQuantity,0)),fMoney=sum(isnull(fMoney,0))
						from #temp_SaleSheet_day1
						group by dSaleDate,cWHno,cGoodsNo,bAuditing
					) b
		on  a.cGoodsNo=b.cGoodsNo 
		
		--------------------------------所有商品流水计算
		if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null drop table #GoodsCurStorageList
		select dDateTime,cGoodsNo,cWHno,cSupNo='',fQuantity,iAttribute,fMoney
		into #GoodsCurStorageList
		from #temp_jiesuan_for_day
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=0,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_InWarehouse c on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2 and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		
		--入库单统计结束

		--出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=1,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_OutWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--出库单统计结束


		--报损单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=5,fMoney=-b.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_LossWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报损单统计结束

		--报溢单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=6,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_EffusionWh c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--报溢单统计结束


		--返厂单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,c.cSupplierNo,fQuantity=isnull(-b.fQuantity,0),
		iAttribute=2,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_RbdWarehouse c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		  
		--返厂单统计结束

		--客退单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,a.cSupNo,fQuantity=isnull(b.fQuantity,0),
		iAttribute=3,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join WH_ReturnGoods c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo

		--客退单统计结束


		--原料出库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(-b.fQuantity,0),
		iAttribute=8,fMoney=-b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Pack c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
		--原料出库单统计结束

		--成品入库单统计开始 
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=isnull(b.fQuantity,0),
		iAttribute=9,fMoney=b.fInMoney
		from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
		on  a.cGoodsNo=b.cGoodsNo
		left join wh_Divide c
		on b.cSheetNo=c.cSheetNo
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo


	--成品入库单统计结束
	--调拨入库单统计开始
		union all 
		select c.dDate,a.cGoodsNo,c.cInWhNo,'-',fQuantity=ISNULL(b.fQuantity,0),
		iAttribute=40,fMoney=c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrInWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo 
		left join Wh_TfrInWarehouse c
		on b.cSheetno=c.cSheetno
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cInWhNo,'')=@cWhNo

	--调拨出库单统计开始
		union all
		select c.dDate,a.cGoodsNo,c.cWhNo,'-',fQuantity=ISNULL(-b.fQuantity,0),
		iAttribute=41,fMoney=-c.fMoney
		from #tmpPloyOfGoodsinfo a left join wh_TfrWarehouseDetail b
		on a.cGoodsNo=b.cGoodsNo
		left join wh_TfrWarehouse c 
		on b.cSheetno=c.cSheetno
		where c.dDate between @BgndDate1 and @dDate_2   and isnull(c.bExamin,0)=1
		and ISNULL(c.cWhNo,'')=@cWhNo
	    union all
		select @BgndDate1,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo
        
		if (select object_id('tempdb..#tmpPackGoodsList'))is not null drop table #tmpPackGoodsList
		select distinct a.cGoodsNO,b.cGoodsNo_minPackage,b.fQty_minPackage into  #tmpPackGoodsList  
		from #tmpPloyOfGoodsinfo a,t_goods b
		where a.cGoodsNo=b.cGoodsNo and isnull(b.cGoodsNo_minPackage,'')<>''
		and ISNULL(b.bStorage,0)=1
		
		
		alter table #GoodsCurStorageList add fInPrice money,fCostmoney money
		
		
		    --更新销售数量       
        if(select object_id('tempdb..#temp_DmGoodsPrice')) is not null drop table #temp_DmGoodsPrice
        select a.cGoodsno,fInPrice=
         case when ISNULL(a.fInPrice,0)=0 
             then 
               case when isnull(b.fckprice,0)=0 
               then case when isnull(b.fPrice_Contract,0)=0  then fNormalPrice else b.fPrice_Contract end
               else b.fckprice end 
             else a.fInPrice end 
             into #temp_DmGoodsPrice
        from t_PloyOfSale a,t_Goods b
        where cPloyNo=@cPloyNo and a.cGoodsNo=b.cGoodsNo
        
        
        
        update a
		set a.fCostmoney=-isnull(a.fQuantity,0)*b.fInPrice,a.fInPrice=b.fInPrice
		from #GoodsCurStorageList a, #temp_DmGoodsPrice b
		where a.cGoodsNO=b.cGoodsNO and (iAttribute=20 or iAttribute=21)
		
		
		update a
		set a.fCostmoney=-isnull(a.fQuantity,0)*(
         case when ISNULL(a.fInPrice,0)=0 
             then 
               case when isnull(b.fckprice,0)=0 
               then case when isnull(b.fPrice_Contract,0)=0  then fNormalPrice else b.fPrice_Contract end
               else b.fckprice end 
             else a.fInPrice end )             
		from #GoodsCurStorageList a, t_Goods b
		where a.cGoodsNO=b.cGoodsNO and (iAttribute=20 or iAttribute=21)
  
 
		update a
		set a.cGoodsNo=b.cGoodsNo_MinPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage
		from #GoodsCurStorageList a, #tmpPackGoodsList b
		where a.cGoodsNO=b.cGoodsNO
		
 
		if (select OBJECT_ID('tempdb..#tmpGoodsListInfo_1'))is not null drop table #tmpGoodsListInfo_1
		select distinct cGoodsNo,cWhNo=@cWhNo,dDateTime,
		cSupplierNo=cast(null as varchar(32)),BeginQty=cast(null as money),EndQty=cast(null as money),		
		--xsQty=cast(0 as money),xsmoney=cast(0 as money),fml=cast(0 as money)
		xsQty=cast(0 as money),xsmoney=cast(0 as money),fml=cast(0 as money),fCostmoney=sum(fCostmoney)
		into #tmpGoodsListInfo_1
		from #GoodsCurStorageList
		group by dDateTime,cGoodsNo,cWhNo

 
		--更新期末库存
		update a
		set a.EndQty=isnull(b.fqty,0)
		from #tmpGoodsListInfo_1 a,
		(
			select cGoodsNo,dDateTime,fqty=sum(isnull(fQuantity,0))
			from #GoodsCurStorageList
			group by cGoodsNo,dDateTime
		)b
		where a.cGoodsNo=b.cGoodsNo and a.dDateTime=b.dDateTime
 
		--更新销售数量
update a
set a.xsQty=b.fQty,a.xsmoney=b.xsmoney,a.fml=isnull(b.xsmoney,0)-isnull(b.fCostmoney,0)
from #tmpGoodsListInfo_1 a,
(
	select cGoodsNo,dDateTime,fqty=-sum(isnull(fQuantity,0)),xsmoney=-sum(fMoney),fCostmoney=sum(fCostmoney)
	from #GoodsCurStorageList
	where (iAttribute=20 or iAttribute=21)
	group by cGoodsNo,dDateTime
)b
where a.cGoodsNo=b.cGoodsNo  and a.dDateTime=b.dDateTime

insert into  #temp_ReadyKucun(cGoodsNo, EndQty, xsQty,xsMoney,dDatetime,fml)
select cGoodsNo, EndQty, xsQty,xsmoney,dDatetime,fml from #tmpGoodsListInfo_1   

   end 
if(select object_id('tempdb..#temp_WhFrombeginDm')) is not null drop table #temp_WhFrombeginDm
if(select object_id('tempdb..#temp_WhFromendDm')) is not null drop table #temp_WhFromendDm




 -------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.销售数量0=a.销售数量0*ISNULL(b.fQty_minPackage,1),
a.fqtyleft=a.fqtyleft*ISNULL(b.fQty_minPackage,1)
from #temp_WhFrombegin a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.销售数量0=a.销售数量0*ISNULL(b.fQty_minPackage,1),
a.fqtyleft=a.fqtyleft*ISNULL(b.fQty_minPackage,1)
from #temp_WhFromend a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


-----取出相应的前一天数据
select 业务日期,cGoodsNo,cWHno,销售数量0=sum(销售数量0),销售金额0=sum(销售金额0),fqtyleft=sum(fqtyleft),fml=sum(fml) 
into #temp_WhFrombeginDm from #temp_WhFrombegin
where 业务日期<@dDateEnd
group by 业务日期,cGoodsNo,cWHno

select 业务日期,cGoodsNo,cWHno,销售数量0=sum(销售数量0),销售金额0=sum(销售金额0),fml=SUM(fml),
销售数量=CAST(null as money),销售金额=CAST(null as money),---fqtyleft=CAST(null as money) 
fqtyleft=sum(fqtyleft)
 into #temp_WhFromendDm from #temp_WhFromend
where 业务日期>=@dDateBgn
group by 业务日期,cGoodsNo,cWHno


 
if(select object_id('tempdb..#temp_WhFromend1')) is not null drop table #temp_WhFromend1
select 业务日期,cGoodsNo,cWHno,销售数量0=sum(销售数量0),销售金额0=sum(销售金额0),fqtyleft=sum(fqtyleft),fml=sum(fml)
 into #temp_WhFromend1 from #temp_WhFromend
 where 业务日期=@maxWhdDate
group by 业务日期,cGoodsNo,cWHno

update a
set a.销售数量=isnull(a.销售数量0,0)-isnull(b.销售数量0,0),a.销售金额=isnull(a.销售金额0,0)-isnull(b.销售金额0,0),
--a.fqtyleft=b.fqtyleft,
a.fml=isnull(a.fml,0)-isnull(b.fml,0)
from #temp_WhFromendDm a,#temp_WhFrombeginDm b
where a.业务日期=b.业务日期+1 and a.cGoodsNo=b.cGoodsNo
 

----------往#temp_ReadyKucun填充每一天。
 

if @maxWhdDate<@dDateEnd
begin   
		declare @i0_1 int 
		set @i0_1=1
		while @i0_1<=DATEDIFF(DAY,@BgndDate1,@dDate_2)+1  
		begin 
			   insert into   #temp_ReadyKucun(cGoodsNo, EndQty, xsQty,xsMoney,dDatetime,fml)
			   select a.cGoodsNo, 0, 0,0,dDatetime=a.业务日期+@i0_1,0        
			   from #temp_WhFromend1 a left join  #temp_ReadyKucun b
			   on a.cGoodsNo=b.cGoodsNo and b.dDatetime=a.业务日期+@i0_1
			   where isnull(b.cGoodsNo,'')=''
		       
			  set @i0_1=@i0_1+1            
		end
end

------处理未记账商品库存------
         --判断游标是否存在
     	if exists(select cursor_name from MASTER.dbo.syscursors where cursor_name='Cur_ReadyKucun')
  		begin
  		  close Cur_ReadyKucun
          deallocate Cur_ReadyKucun
  		end 
		declare Cur_ReadyKucun cursor for
		select distinct dDatetime
		from #temp_ReadyKucun
		order by dDatetime 
        
        declare @dDatetime1 datetime 

		open Cur_ReadyKucun
	     
		fetch next from Cur_ReadyKucun into @dDatetime1 

		while @@fetch_status=0
		begin  --Cur begin 
		  
		       
			    update a
				set a.EndQty=isnull(a.EndQty,0)+isnull(b.fqtyleft,0),
				a.endQtyOld=isnull(a.EndQty,0)+isnull(b.fqtyleft,0)
				from #temp_ReadyKucun a,#temp_WhFromend1 b
				where a.cGoodsNo=b.cGoodsNo and b.业务日期=@maxWhdDate and a.dDatetime=@dDatetime1
				
		 
				
			    update b
				set b.fqtyleft=a.endQtyOld
				from #temp_ReadyKucun a,#temp_WhFromend1 b
				where a.cGoodsNo=b.cGoodsNo and b.业务日期=@maxWhdDate and a.dDatetime=@dDatetime1
 
           
               
			 fetch next from Cur_ReadyKucun into @dDatetime1
		       
		end --Cur end

		close Cur_ReadyKucun
		deallocate Cur_ReadyKucun
 
insert into #temp_WhFromendDm(业务日期,cGoodsNo,cWHno,销售数量,销售金额,fqtyleft,fml)
select a.dDatetime,a.cGoodsNo,@cWhno, a.xsQty,a.xsMoney,a.EndQty,a.fml
from #temp_ReadyKucun a left join #temp_WhFromendDm b on a.cGoodsNo=b.cGoodsNo 
and a.dDatetime=b.业务日期
where isnull(b.业务日期 ,'')='' 
 
 
-------合计
if(select object_id('tempdb..#temp_WhFromendDmHeji')) is not null drop table #temp_WhFromendDmHeji
select 业务日期,cGoodsNo,销售数量=SUM(销售数量),销售金额=SUM(销售金额),fqtyleft=sum(fqtyleft),fml=SUM(fml)
into #temp_WhFromendDmHeji  from #temp_WhFromendDm
where 业务日期>=@dDateBgn
group by cGoodsNo,业务日期
order by 业务日期

 

---------------取盘点差异
if(select object_id('tempdb..#templast_pd01')) is not null drop table #templast_pd01
select b.dCheckTask,a.cGoodsNo,fQuantity_Diff=sum(a.fQuantity_Diff),fmoney_Diff=sum(a.fMoney_Diff)
into #templast_pd01
from t_CheckTast_GoodsDetail_log a left join t_CheckTast b
on a.cCheckTaskNo=b.cCheckTaskNo 
where b.dCheckTask<=@dDateEnd  
and b.cWhNo=@cWHno  
group by  b.dCheckTask,a.cGoodsNo

if(select object_id('tempdb..#templast_pd0')) is not null drop table #templast_pd0
select a.dCheckTask,a.cGoodsNo,a.fQuantity_Diff,a.fmoney_Diff into #templast_pd0 
from #templast_pd01 a,#tmp_WhGoodsList b
where a.cGoodsNo=b.cGoodsNo
	
 
	
-------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity_Diff=a.fQuantity_Diff*ISNULL(b.fQty_minPackage,1) 
from #templast_pd0 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

if(select object_id('tempdb..#templast_pdheji0')) is not null drop table #templast_pdheji0

select dCheckTask,cGoodsNo,fQuantity_Diff=SUM(fQuantity_Diff),fmoney_Diff=SUM(fmoney_Diff) 
into #templast_pdheji0
from #templast_pd0
group by dCheckTask,cGoodsNo


 
--------获取期初前调整库存数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select dDatetime,a.cGoodsNo,fQty=sum(a.fQty),fMoney=sum(a.fMoney)
into #tmpGoodsRelationKucun_1
from posmanagement_Relation01.dbo.t_GoodsUpdateKucunDetail a,(select distinct cgoodsno from #temp_WhFromend) b
where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno
group by dDatetime,a.cGoodsNo

 
-------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQty=a.fQty*ISNULL(b.fQty_minPackage,1) 
from #tmpGoodsRelationKucun_1 a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


 
 
--------取改时间段的差价单分配情况。。。 
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
drop table #tmp_WhGoodsList_begin_1
select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)

--------表示当前分配的差价单的供应商在当前的列表中存在
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
drop table #temp_wh_DiffGoodsNo
select dSaleDate,a.cGoodsno,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
into #temp_wh_DiffGoodsNo
from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
where dSaleDate between @dDateBgn and @dDateEnd 
and a.cGoodsno=b.cGoodsNo 
group by a.cGoodsno,dSaleDate

CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

 -------2015-05-16----包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fqty_Sale=a.fqty_Sale*ISNULL(b.fQty_minPackage,1) 
from #temp_wh_DiffGoodsNo a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

-----------合计。
if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNoHeji'))is not null  
drop table #temp_wh_DiffGoodsNoHeji
select dSaleDate,cGoodsno,fMoney_Diff=SUM(fMoney_Diff) 
into #temp_wh_DiffGoodsNoHeji
from #temp_wh_DiffGoodsNo 
group by dSaleDate,cGoodsno
 
if(select object_id('tempdb..#temp_GoodsSaleDm')) is not null drop table #temp_GoodsSaleDm
select distinct cGoodsNo into #temp_GoodsSaleDm from #temp_WhFromendDmHeji


-----------------构造横表
declare @i int
declare @AddFile varchar(8000)
declare @LoodFile varchar(8000)
declare @HejiLoodFile varchar(8000)
set @AddFile='alter table #temp_GoodsSaleDm add '
set @LoodFile=''
set @HejiLoodFile=''
set @i=1
while @i<=@day 
begin
  set @AddFile=@AddFile+'第'+CAST(@i as varchar)+'天数量 money, 第'+CAST(@i as varchar)+'天金额 money, 第'+CAST(@i as varchar)+'天库存 money,第'+CAST(@i as varchar)+'天毛利 money,'
  set @LoodFile=@LoodFile+'第'+CAST(@i as varchar)+'天数量,'+'第'+CAST(@i as varchar)+'天金额,'+'第'+CAST(@i as varchar)+'天库存,'+'第'+CAST(@i as varchar)+'天毛利,'
  set @HejiLoodFile=@HejiLoodFile+'sum(第'+CAST(@i as varchar)+'天数量),'+'sum(第'+CAST(@i as varchar)+'天金额),'+'sum(第'+CAST(@i as varchar)+'天库存),'+'sum(第'+CAST(@i as varchar)+'天毛利),'
  set @i=@i+1
end

set @AddFile=@AddFile+'合计数量 money, 合计金额 money, 合计毛利 money'
set @LoodFile=@LoodFile+'合计数量, 合计金额, 合计毛利'
 set @HejiLoodFile=@HejiLoodFile+'sum(合计数量), sum(合计金额), sum(合计毛利) '
exec(@AddFile)
 
set @i=0
declare @upFileheji varchar(8000)
set @upFileheji=''
 
while @i<@day 
begin
	   declare @i0 varchar(32) 
	   set @i0=CAST((1+@i) as varchar)
	   declare @dDate varchar(32)
	   set @dDate= dbo.getdaystr(@dDateBgn+@i)
  
		exec('
	  
		     
			update a set a.第'+@i0+'天数量=b.销售数量,a.第'+@i0+'天金额=b.销售金额,
			a.第'+@i0+'天库存=isnull(b.fqtyleft,0),第'+@i0+'天毛利=b.fml,
			a.合计数量=isnull(a.合计数量,0)+isnull(b.销售数量,0),
			a.合计金额=isnull(a.合计金额,0)+isnull(b.销售金额,0),
			a.合计毛利=isnull(a.合计毛利,0)+isnull(b.fml,0)		  
			from #temp_GoodsSaleDm a,#temp_WhFromendDmHeji b
			where a.cGoodsNo=b.cGoodsNo and b.业务日期='''+@dDate+'''


          

			if(select object_id(''tempdb..#templast_pdheji1'')) is not null drop table #templast_pdheji1
			select cGoodsNo,fQty_diff=SUM(fQuantity_Diff)  into #templast_pdheji1 
			from #templast_pdheji0
			where dCheckTask<='''+@dDate+'''
			group by cGoodsNo

			update a set a.第'+@i0+'天库存=isnull(第'+@i0+'天库存,0)+isnull(b.fQty_diff,0) 
			from #temp_GoodsSaleDm a,#templast_pdheji1 b
			where a.cGoodsNo=b.cGoodsNo
			
			
			if(select object_id(''tempdb..#tmpGoodsRelationKucun_hebing'')) is not null 
			drop table #tmpGoodsRelationKucun_hebing
			select  cGoodsNo,fQty=sum(fqty) 
			into #tmpGoodsRelationKucun_hebing 
			from  #tmpGoodsRelationKucun_1
			where  dDatetime<='''+@dDate+'''
			group by  cGoodsNo
			
			
			update a set a.第'+@i0+'天库存=isnull(第'+@i0+'天库存,0)+isnull(b.fQty,0) 
			from #temp_GoodsSaleDm a,#tmpGoodsRelationKucun_hebing b
			where a.cGoodsNo=b.cGoodsNo
			
 

			update a set a.第'+@i0+'天毛利=isnull(第'+@i0+'天毛利,0)+isnull(b.fMoney_Diff,0),
			a.合计毛利=isnull(a.合计毛利,0)+isnull(b.fMoney_Diff,0)		  
			from #temp_GoodsSaleDm a,#temp_wh_DiffGoodsNoHeji b
			where a.cGoodsNo=b.cGoodsNo and b.dSaleDate='''+@dDate+'''
					 		  
		')	 
       set @i=@i+1
end

exec('
   select ROW_NUMBER() OVER(order by a.cgoodsno desc) AS 序号,商品编码=a.cGoodsNo,商品名称=b.cGoodsName,条形码=b.cBarcode,类别编号=b.cGoodsTypeno,类别名称=b.cGoodsTypename,
   供应商编号=cSupNo,供应商名称=cSupName,'+@LoodFile+'  
   from #temp_GoodsSaleDm a,t_Goods b
   where a.cgoodsno=b.cgoodsno
   union all
   select i=9999,商品编码=''合计：'',商品名称=null,条形码=null,类别编号=null,类别名称=null,
   供应商编号=null,供应商名称=null,'+@HejiLoodFile+'  
   from #temp_GoodsSaleDm
   
   ')
 
end
 GO
