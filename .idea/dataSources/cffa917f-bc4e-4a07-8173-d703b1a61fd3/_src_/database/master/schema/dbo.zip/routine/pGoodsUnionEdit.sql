
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[pGoodsUnionEdit]
	-- Add the parameters for the stored procedure here
	@ModifyID [tinyint],  --1:添加 3:删除
	@cGoodsNo [varchar](32),
	@cBarcode [varchar](32),
	@UserNo [varchar](32),
	@UserName [varchar](64),
	@StationName [varchar](64)		
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @cLog [varchar] (64)

	IF (@ModifyID = 1) AND (EXISTS (SELECT TOP (1) 1 FROM t_Goods WHERE(cGoodsNo = @cBarcode) OR (cUnitedNo = @cBarcode) OR (cBarcode = @cBarcode)
									UNION
									SELECT 1 FROM t_Goods_Union WHERE (cBarcode = @cBarcode)))
	BEGIN
		RAISERROR ('条码:[%s]已经在商品信息或附属条码中存在,不能新增!', 16 , 1,@cBarcode)
		SET NOCOUNT OFF
		RETURN
	END
	
	--错误计数变量
	DECLARE @ErrorCount INT
	SET @ErrorCount = 0
	SET XACT_ABORT  ON
	BEGIN TRAN
	
	IF @ModifyID = 1
	BEGIN
		INSERT INTO t_Goods_Union (cBarcode, cGoodsNo_parent) VALUES (@cBarcode, @cGoodsNo)
		SET @cLog = '新增附属条码'
		SET @ErrorCount = @ErrorCount + @@ERROR
	END
	ELSE
	BEGIN
		DELETE FROM t_Goods_Union WHERE (cBarcode = @cBarcode) AND (cGoodsNo_parent = @cGoodsNo)
		SET @cLog = '删除附属条码'
		SET @ErrorCount = @ErrorCount + @@ERROR
	END
	
	IF (EXISTS (SELECT TABLE_NAME FROM INFORMATION_SCHEMA.tables WHERE TABLE_NAME ='t_Log'))
	BEGIN
		INSERT INTO t_Log
		(UserNo ,UserName,Operation,OperTime,StationName)
		VALUES
		(@UserNo ,@UserName,
		 @cLog + ':商品编号:' + @cGoodsNo + ',附属条码:' + @cBarcode, GETDATE(),@StationName)
		SET @ErrorCount = @ErrorCount + @@ERROR
	END
		
	IF @ErrorCount = 0
		COMMIT TRAN
	ELSE
	BEGIN
		RAISERROR ('商品附属条码编辑失败,请检查后重试', 16 , 1)
		ROLLBACK TRAN
	END	
	SET NOCOUNT OFF		
	
END

GO
