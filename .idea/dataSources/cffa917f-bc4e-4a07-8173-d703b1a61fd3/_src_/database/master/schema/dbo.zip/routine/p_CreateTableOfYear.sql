

CREATE  procedure p_CreateTableOfYear
@cStoreNo varchar(32),
@iYears int
as
begin
  --dbo.t_MonthsOfYearSerno
	declare @i int
	declare @j int

	declare @date1 datetime
	declare @date2 datetime
	declare @OpenDate datetime
	declare @OpenDays int
	declare @OpenMonths int
	declare @OpenYears int
	select top 1 @OpenDate=dOpenDate from dbo.t_OpenDate where cStoreNo=@cStoreNo
  if @OpenDate is null  return

	set @OpenDays=day(@OpenDate)
	set @OpenMonths=month(@OpenDate)
	set @OpenYears=year(@OpenDate)+@iYears-1

	set @date1 =dateadd(year,@iYears-1,@OpenDate)
	set @date2 =dateadd(month,1,@date1)-1
  set @i=1
	while @i<13 
	begin
		if not exists(select cYear from dbo.t_MonthsOfYearSerno 
							where cYear=cast(@OpenYears as char(4)) and cMonth=(case when len(cast(@i as char(2)))=1 
																																			then '0'+dbo.trim(cast(@i as char(2)))
																																			else cast(@i as char(2))
																																 end)	
						 )
		begin
			insert into dbo.t_MonthsOfYearSerno(cYear,cMonth,dDate1,dDate2) 
			values (cast(@OpenYears as char(4)),
							case when len(cast(@i as char(2)))=1 
									 then '0'+dbo.trim(cast(@i as char(2)))
									 else cast(@i as char(2))
							end,
							@date1,
							@date2	
							)
		end				
    
	  set @i=@i+1
		set @date1 =@date2+1
		set @date2 =dateadd(month,1,@date1)-1
	end
	update a set a.iDays=dateDiff(day,a.dDate1,a.dDate2)+1,
	a.cYearEnd=(select top 1 datename(Year,dDate2) from t_MonthsOfYearSerno where cYear=a.cYear and cMonth='12')
	from t_MonthsOfYearSerno a
end

/*
exec p_CreateTableOfYear '01',1
select * from t_MonthsOfYearSerno

--truncate table t_MonthsOfYearSerno
*/


GO
