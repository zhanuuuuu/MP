--   p_List_UserGoodsTypeRight '888'

CREATE procedure [dbo].[p_List_UserGoodsTypeRight_TermID]
@userno varchar(32),
@cTerminateID varchar(32)
as
begin



			if(select object_id('tempdb..#temp_UserGoodsType')) is not null
			begin
				drop table 	#temp_UserGoodsType
			end 
		declare @cDeptNo varchar(32)
		declare @bLimited bit
		select @cDeptNo=BumenNo
		--into #temp_UserGoodsType
		from t_pass
		where [user]=@userno

		if (select count(*) from dbo.t_GoodsType
		where dbo.trim(isnull(@cDeptNo,'')) in (select distinct cDeptNo from t_GoodsType))>1
		begin
			set @bLimited=1
		end else
		begin
			set @bLimited=0
		end

		select BumenNo
		into #temp_UserGoodsType
		from t_pass
		where [user]=@userno

			if(select object_id('tempdb..#temp_Path')) is not null
			begin
				drop table 	#temp_Path
			end 

		create table #temp_Path
		(diquno varchar(32),diqumc varchar(128),cParentNo varchar(32),cPath varchar(512))

		insert into #temp_Path
		(diquno,diqumc,cParentNo,cPath)
		exec p_GetPath_GoodsType



			if(select object_id('tempdb..#temp_Path_last')) is not null
			begin
				drop table 	#temp_Path_last
			end 

		select *
		into #temp_Path_last
		from #temp_Path
		where cPath in (select cPath
		from #temp_Path
		where diquno in
		(select cGoodsTypeno from dbo.t_GoodsType where cDeptNo=@cDeptNo)
		or @bLimited=0 )
exec('
	  insert into U_key.dbo.tmpGoodstype_list'+@cTerminateID+'
    (cGoodsTypeno,cGoodsTypename,cParentNo,cDeptNo,cDept)
		select cGoodsTypeno,cGoodsTypename,cParentNo,cDeptNo,cDept
		from dbo.t_GoodsType 
		where cGoodsTypeno in (select diquno from #temp_Path_last)
	')
end
GO
