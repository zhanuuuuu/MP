
/*
 exec p_GetSales_byReceiverPos '001','2016-06-02','2016-06-02','posidno asc'
*/

CREATE    procedure [dbo].[p_GetSales_byReceiverPos]
@cStoreNo varchar(32),
@datetime1 datetime,
@datetime2 datetime,
@orderbyField varchar(32)
as
begin
  ------**********从p_Account_Ref 获取结算信息***********-----
  if (select OBJECT_ID('tempdb..#temp_Jiesuan'))is not null drop table #temp_Jiesuan
    create table #temp_Jiesuan(zdriqi datetime,detail varchar(32),theyear varchar(32),themonth varchar(32),
	mianzhi money,zhaoling money,shishou money,
	shouyinyuanno varchar(32),shouyinyuanmc varchar(32),sheetno varchar(32),jiaozhang money,jstime datetime,cStoreNo varchar(32))
	declare @date1 datetime
	declare @date2 datetime
	set @date1=@datetime1-1
	set @date2=@datetime2+1
	 
     
     insert into #temp_Jiesuan(zdriqi,theyear,themonth,detail,
	mianzhi,zhaoling,shishou,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo)
		select zdriqi,theyear=cast(year(zdriqi) as varchar(4)),themonth=cast(month(zdriqi) as varchar(2)),detail,
	sum(mianzhi),sum(zhaoling),sum(shishou),shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo
	from jiesuan
	where zdriqi between @date1 and @date2  and (cStoreNo=@cStoreNo)
	 and isnull(bOnline,0)=0
	group by  cast(year(zdriqi) as varchar(4)),cast(month(zdriqi) as varchar(2)),detail,
	zdriqi,shouyinyuanno,shouyinyuanmc,sheetno,jiaozhang,jstime,cStoreNo
 
  


    select lsdno=sheetno,shishou=sum(isnull(shishou,0)),zdriqi,cStoreNo
	into #jiesuan
	--from jiesuan
	from #temp_Jiesuan
	where zdriqi between @datetime1-1 and @datetime2+1
	group by sheetno, zdriqi ,cStoreNo

 
	select a.lsdno ,a.shishou ,a.zdriqi,PosID=b.PosName,posidNo=b.posid
	into #lsd_temp 
	from #jiesuan a left join dbo.t_posstation b
							 on substring(a.lsdno,1,2)=b.posid
	where a.zdriqi between dbo.getDaystr(@datetime1) and dbo.getDaystr(@datetime2)
	and b.cStoreNo=@cStoreNo and a.cStoreNo=b.cStoreNo

	select  posidNo,PosID,shishou=sum(shishou),TotalSales=cast(0.0 as money)
	into #lsd_temp_1
	from #lsd_temp
	group by posidNo,PosID 

  update #lsd_temp_1 set TotalSales=isnull((select sum(isnull(shishou,0)) from #lsd_temp_1),0)

  exec(' select * from  #lsd_temp_1 order by '+@orderbyField)

end


GO
