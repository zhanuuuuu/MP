create procedure p_Goods_Pack_ReUpdate
@cGoodsNo varchar(32),--商品编号
@cGoodsNo_child varchar(32),--关联的最小商品编号
@fPackRatio money---单位商品中含有【关联的最小商品编号】的数量
as
begin
    if @fPackRatio<=0 begin return 0 end  --@fPackRatio<=0则中断执行
		if exists
		(
					select cGoodsNo 
					from t_wh_form 
					where cGoodsNo=@cGoodsNo
		)
		begin
			update t_wh_form
			set fPrice_in=fPrice_in/@fPackRatio,fQty_in=fQty_in*@fPackRatio,
								 fPrice_out=fPrice_out/@fPackRatio,fQty_Out=fQty_Out*@fPackRatio,
								 fPrice_Left=fPrice_Left/@fPackRatio,fQty_Left= fQty_Left*@fPackRatio,
								 cGoodsNo=@cGoodsNo_child
			where cGoodsNO=@cGoodsNo
		end

		if exists
		(
					select cGoodsNo 
					from t_Cost_distribute 
					where cGoodsNo=@cGoodsNo
		)
		begin
		update t_Cost_distribute
		set fPrice_Cost=fPrice_Cost/@fPackRatio,
		fQty_Cost=fQty_Cost*@fPackRatio,
		fQty=fQty*@fPackRatio,
		cGoodsNo=@cGoodsNo_child
		where cGoodsNO=@cGoodsNo
		end
end
GO
