
--  p_GetVip_PFrate_byScore '9009'


create      procedure [dbo].[p_GetVip_PFrate_byScore_按积分标准自动折率]
  @cVipno varchar(32)
as
begin

--if (select OBJECT_ID('tempdb..#t_Vip_PFrate_byScore0'))is not null
--drop table #t_Vip_PFrate_byScore0 
--create table #t_Vip_PFrate_byScore0(cVipno varchar(32),cVipName varchar(32),fCurValue money,
--dValidEnd datetime,dValidStart datetime)
--insert into #t_Vip_PFrate_byScore0(cVipno,cVipName,fCurValue,dValidEnd,dValidStart)
--select cVipno,cVipName,fCurValue,dValidEnd,dValidStart   from t_Vip where cVipno=@cVipno
--select * from #t_Vip_PFrate_byScore0
 
  if (select OBJECT_ID('tempdb..#t_Vip_PFrate_byScore0'))is not null
     drop table #t_Vip_PFrate_byScore0 
  select a.fCurValue as fCurValue_0,
       b.fCurValue as fCurValue_1,
       a.fPFrate
  into #t_Vip_PFrate_byScore0  
  from t_Vip_PFrate_byScore a   left join t_Vip_PFrate_byScore b
       on a.fCurValue<b.fCurValue

  if (select OBJECT_ID('tempdb..#t_Vip_PFrate_byScore1'))is not null
     drop table #t_Vip_PFrate_byScore1
  select  fCurValue_0,min(fCurValue_1) as fCurValue_1
  into #t_Vip_PFrate_byScore1
  from #t_Vip_PFrate_byScore0
  group by fCurValue_0
--  order by fCurValue_0
--drop table#t_Vip_PFrate_byScore0

--select * from #t_Vip_PFrate_byScore0
--select * from #t_Vip_PFrate_byScore1

  if (select OBJECT_ID('tempdb..#t_Vip_PFrate_byScore2'))is not null
     drop table #t_Vip_PFrate_byScore2
     
  select  a.fCurValue_0,a.fCurValue_1,b.fPFrate
  into #t_Vip_PFrate_byScore2
  from #t_Vip_PFrate_byScore1 a left join #t_Vip_PFrate_byScore0 b
    on (a.fCurValue_0=b.fCurValue_0 and a.fCurValue_1=b.fCurValue_1 and a.fCurValue_1 is not null)
       or (a.fCurValue_1 is null and a.fCurValue_0=b.fCurValue_0)
 
--select * from #t_Vip_PFrate_byScore2
  if (select OBJECT_ID('tempdb..#t_Vip_PFrate_byScore'))is not null
     drop table #t_Vip_PFrate_byScore
  select  fCurValue_0,fCurValue_1,fPFrate
  into #t_Vip_PFrate_byScore
  from #t_Vip_PFrate_byScore2
  union all
  select  min(fCurValue_0) as fCurValue_0,fCurValue_1=null,100
  from  #t_Vip_PFrate_byScore2
--  order by fCurValue_0,fCurValue_1

--select * from #t_Vip_PFrate_byScore


  if (select OBJECT_ID('tempdb..#t0'))is not null
     drop table #t0
  SELECT MIN(fCurValue_0) AS MinValue
  INTO #t0
  FROM #t_Vip_PFrate_byScore

--select * from #t0

  UPDATE #t_Vip_PFrate_byScore
  SET #t_Vip_PFrate_byScore.fCurValue_1=fCurValue_0,  
      #t_Vip_PFrate_byScore.fCurValue_0=-9999999
  FROM #t0 
  WHERE #t0.MinValue=#t_Vip_PFrate_byScore.fCurValue_0 
       AND #t_Vip_PFrate_byScore.fCurValue_1 IS NULL

--  update #t_Vip_PFrate_byScore set fCurValue_1=isnull(fCurValue_1,0),fCurValue_0=isnull(fCurValue_0,-99999)
	
    

--select * from #t_Vip_PFrate_byScore

  SELECT  a.bConsumeOnVipScore,a.cVipNo,a.fCurValue,fCurValue_Pos=isnull(a.fCurValue_Pos,0),
  b.fCurValue_0,b.fCurValue_1,
  --b.fPFrate,
  fPFrate=case when isnull(b.fPFrate,0)<80 then 100 else b.fPFrate end,
          a.cVipName,a.cSex,a.dValidStart,a.dValidEnd,a.bVipPrice,a.cStoreNo,a.bSuspend,a.bDel,
					fMoney_sum=isnull(a.fMoney_sum,0),fMoney_used=isnull(a.fMoney_used,0),
					fMoney_Left=isnull(a.fMoney_Left,0),
		fMoneyLimit_Init=case when dbo.getdaystr(getdate()) between a.dMoneyLimit1 and a.dMoneyLimit2  
		                 then ISNULL(a.fMoneyLimit_Init,0)
		                 else 0
		                 end,
		dMoneyLimit1=case when a.dMoneyLimit1>'2001-01-01' then dbo.getDayStr(a.dMoneyLimit1) else '' end,
		dMoneyLimit2=case when a.dMoneyLimit2>'2001-01-01' then dbo.getDayStr(a.dMoneyLimit2) else '' end
					
  FROM t_Vip a
     LEFT JOIN  #t_Vip_PFrate_byScore b
     ON 
        (b.fCurValue_1 IS NOT NULL
         and a.fCurValue>=b.fCurValue_0
         and a.fCurValue<b.fCurValue_1
        ) OR
        (b.fCurValue_1 IS NULL
         and a.fCurValue>=isnull(b.fCurValue_0,0)
        )
  WHERE (a.cVipNo=@cVipno or a.cTel=@cVipno)and  getdate() between a.dValidStart and a.dValidEnd
            and isnull(a.bSuspend,0)=0 and isnull(a.bDel,0)=0
        
END


GO
