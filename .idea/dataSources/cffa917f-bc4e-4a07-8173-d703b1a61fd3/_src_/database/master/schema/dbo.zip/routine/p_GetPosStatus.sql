/*
  返回：1 成功
        2 状态同步失败
        0 状态同步异常
*/
create proc p_GetPosStatus
@posID varchar(32) ,  --是 终端身份标识 
@posTime datetime,-- 是 终端时间 
@posStatus int --- 终端状态 1：open，表示终端上线，终 端程序启动后只需要发出一 次
  -- 2：close，表示终端下线，终 端程序退出前发出一次 
  ---3： live，表示终端在线，可以 每 5 秒、每 10 秒或其他周期 发出一次 
  ---4：其他情况，若出现异常信 息，及时上报问题描述
,
@return int output ,       --返回值
@ServerTime datetime output
as
begin
   begin try 
   begin tran
   
       update t_posstation
       SET posStatus=@posStatus,posTime=@posTime
       where posid=@posID
       
       IF @@rowcount=1
       BEGIN
          set @return=1  
          set @ServerTime=getdate()
       end else
       BEGIN
          set @return=2 
          set @ServerTime=getdate()
       end
       
	   commit tran
	 
	
	end try
	begin catch  
	   rollback  
	  set @return=0
      set @ServerTime=getdate()
	end catch
end
GO
