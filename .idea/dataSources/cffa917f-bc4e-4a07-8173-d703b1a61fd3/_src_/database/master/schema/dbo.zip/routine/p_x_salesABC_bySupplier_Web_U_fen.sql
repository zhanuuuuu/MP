/*
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods 
select distinct cGoodsNo,cSupplierNo=cSupNo into #temp_Goods from t_goods
exec [p_x_salesABC_bySupplier_Web_U_fen]
'2012-03-1','2012-05-22',0,0,'01','55cbb7ddfe32996'
*/
CREATE procedure [dbo].[p_x_salesABC_bySupplier_Web_U_fen]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit,
@cWHno varchar(32),
@Key varchar(32)
as
--declare @dBeginDate datetime,@dEndDate datetime,@bJiaGong bit,@bZero bit,@cWHno varchar(32)
--select @dBeginDate='2012-03-27',@dEndDate='2012-03-27',@bJiaGong=0,@bZero=0,@cWHno='01'
if  (select object_id('tempdb..#temp_SupplierNo')) is not null
 drop table #temp_SupplierNo
Create Table #temp_SupplierNo (cSupplierNo varchar(128))
insert into #temp_SupplierNo (cSupplierNo)
exec('
select cSupplierNo=cSupNo from  t_Supplier where cSupNo in 
(select cSupNo from Temp_SupKey.dbo.temp_Sup'+@key+')')

	

if (select object_id('tempdb..#temp_Goods')) is not null
 drop table #temp_Goods
Create Table #temp_Goods (
cGoodsNo varchar(128),
cProductNo varchar(128),
cSupplierNo varchar(128))

if  (select object_id('tempdb..#tempSupNo')) is not null
 drop table #tempSupNo
select distinct cSupplierNo into #tempSupNo from #temp_SupplierNo
insert into  #temp_Goods  (cGoodsNo,cSupplierNo) 
select distinct a.cGoodsNo,a.cSupNo
from t_goods a,#tempSupNo b
where a.cSupNo=b.cSupplierNo
update a set a.cProductNo=b.cProductNo
from #temp_Goods a,t_goods b where a.cGoodsNo=b.cGoodsNo



if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo 
if(select object_id('tempdb..#t_SaleSheetDetail_shelf_ready')) is not null drop table #t_SaleSheetDetail_shelf_ready
if(select object_id('tempdb..#t_SaleSheetDetail_shelf')) is not null drop table #t_SaleSheetDetail_shelf
if(select object_id('tempdb..#t_SaleSheetDetail1')) is not null drop table #t_SaleSheetDetail1
if(select object_id('tempdb..#temp_goodsKuCun1')) is not null drop table #temp_goodsKuCun1
if(select object_id('tempdb..#temp_kusun')) is not null drop table #temp_kusun
if(select object_id('tempdb..#temp_goodsKuCun1_NoZero')) is not null drop table #temp_goodsKuCun1_NoZero


select cGoodsNo,cSupplierNo into  #temp_GoodsNo  from #temp_Goods
where cGoodsNo is not null
  
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL)
CREATE TABLE #temp_end   (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL) 

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime,@date_ForBgn datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='+@cWHno+''
insert into #temp_date
exec (@SQLstr)
select @date=MaxDate from #temp_date
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)
if(@date>=@dBeginDate-1)
	begin
		if (@date<@dEndDate)    
			begin
					set @date1=@date+1
					set @date2=@dEndDate
			end
		else
			begin
					set @date1='2000-01-01'
					set @date2='2000-01-01'
					set @date=@dEndDate
			end
	end
else
	begin 
		set @date1=@dBeginDate
		set @date2=@dEndDate 
	end
set @date_ForBgn=@dBeginDate-1
if @date_ForBgn>@date set @date_ForBgn=@date

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin(ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='Bgn',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 
insert into #temp_end  (ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='End',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 

set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
              a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date_ForBgn)+''' and b.cWHno='+@cWHno+'
             '
set @SQLstr1='update a
              set a.fQuantity=b.fQuantity,a.fMoney=b.fMoney,a.fMoney_all=b.fMoney_all,
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
              a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='+@cWHno+'
            '
exec (@SQLstr+@SQLstr1)

declare @dMaxDailyDate datetime
set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1
if @dBeginDate>@dMaxDailyDate
set @dMaxDailyDate=@dBeginDate

/*
select MAX(dDate) from t_Daily_history
select max(dSaleDate) from t_SaleSheet_Day

delete from t_Daily_history where dDate>'2012-03-25' 
delete from t_SaleSheet_Day where dSaleDate>'2012-03-25' 
*/
---------------*************************  获取分库数据****************

--------========================	 

 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
	 
	exec p_x_salesABC_bySupplier_chen_WH_Ref @date1,@date2,@dMaxDailyDate,@cWHno

---------=================***********************

--------------------------------已结转   开始  
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0)+isnull(total_Sale1,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0)+isnull(fMoney_Sale1_all,0))-ISNULL(fMoney_Return_all,0)
  into #t_SaleSheetDetail_shelf 
  from #temp_begin 
  union all
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0)+isnull(total_Sale1,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0)+isnull(fMoney_Sale1_all,0))-ISNULL(fMoney_Return_all,0)
  from #temp_end
--------------------------------未结转   开始
--                销售单                 开始    
  union all  
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle
  from  #temp_GoodsNo  a,
       --t_SaleSheet_Day b         where a.cGoodsNo=b.cGoodsNo
       #temp_SaleSheet_Day b         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @date1 and @date2) and b.cWHno=@cWHno 
  union all
  select 'X',c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney
  from  #temp_GoodsNo  a,
       WH_ReturnGoodsDetail b,WH_ReturnGoods c where a.cGoodsNo=b.cGoodsNo 
        and b.cSheetno=c.cSheetno and (c.dDate between @date1 and @date2) and c.cWHno=@cWHno 

  union all   ---未日结
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle
  from  #temp_GoodsNo  a,
       --t_SaleSheetDetail b         where a.cGoodsNo=b.cGoodsNo
        #temp_salesheetDetail b         where a.cGoodsNo=b.cGoodsNo
  and  (b.dSaleDate between @dMaxDailyDate and @date2) and b.cWHno=@cWHno 
---销售数量
  select a.cGoodsNo,Qty=a.Qty-b.Qty,fLastMoney=a.fLastMoney-b.fLastMoney
  into #t_SaleSheetDetail1  --销售单
  from 
      (  
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
         from #t_SaleSheetDetail_shelf 
         where dSaleTime between @date1 and @dEndDate or ForSign='End' 
         group by cGoodsNo
      ) a left join 
      (
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
         from #t_SaleSheetDetail_shelf 
         where dSaleTime<@dBeginDate or ForSign='Bgn' group by cGoodsNo
      )b on a.cGoodsNo=b.cGoodsNo 
--               销售单                 结束 
----当前库存
--select a.cGoodsNo,fQuantity=ISNULL(a.fQuantity,0)-ISNULL(b.fQuantity,0) 
--into #temp_kusun
--from #temp_end a left join
--(
--     select cGoodsNo,fQuantity=SUM(ISNULL(fQuantity,0)) 
--     from #t_SaleSheetDetail_shelf 
--     where ForSign='X'
--     group by cGoodsNo
--) b
--on a.cGoodsNo=b.cGoodsNo 

/*
select * from #temp_kusun
select * from #t_SaleSheetDetail_shelf where dSaleTime between @date and @dEndDate
select * from #t_SaleSheetDetail_shelf  where dSaleTime<@dBeginDate 
select * from #t_SaleSheetDetail1
*/

--合并  开始
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,a.cSupplierNo,o.cSupName,
                  xsQty=m.qty,xsMoney=m.fLastMoney,y.fQty_CurWH
      into #temp_goodsKuCun1_NoZero from #temp_GoodsNo a 
                             , t_goods b --on a.cGoodsNo=b.cGoodsNo
                             , t_Supplier o --on a.cSupplierNo=o.cSupNo
                             , #t_SaleSheetDetail1 m --on a.GoodsNo_Pdt=m.GoodsNo
												     , t_Goods_CurWH y 		
                             where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=y.cGoodsNo and a.cGoodsNo=m.cGoodsNo and a.cSupplierNo=o.cSupNo
                                     and y.cWHno=@cWHno
 --合并  结束
 exec('
   if (select object_id(''U_key.dbo.s_'+@Key+'''))is not null 
   drop table U_key.dbo.s_'+@Key+'
   
      select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,cSupplierNo,cSupName,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fQty_CurWH=isnull(fQty_CurWH,0)
		   into U_key.dbo.s_'+@Key+'  from #temp_goodsKuCun1_NoZero
		  union all
		  select GoodsNo_Pdt=''合计:'',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=''合计:'',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo,cSupName,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fQty_CurWH=sum(isnull(fQty_CurWH,0))
		  from #temp_goodsKuCun1_NoZero 
		  group by cSupplierNo,cSupName,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt=''总计:'',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo=''总计:'',cSupName=null,
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fQty_CurWH=sum(isnull(fQty_CurWH,0))
		  from #temp_goodsKuCun1_NoZero
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
')


GO
