 

create    function [dbo].[f_GetStoreUpdatefPriceSheetno]
(@cYear varchar(4),@cWhNo varchar(16)) returns varchar(32)
as
begin
   declare @MM varchar(16)
   set @MM=DATENAME(MM,GETDATE())
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from dbo.t_StoreGoodsUpdate
                  where datename(yyyy,dDate)=@cYear and DATENAME(MM,dDate)=@MM
                 )
   if @cMaxSerno is null 
   begin
     return  'UP'+@cYear+@MM+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'UP'+@cYear+@MM+'-'+@cMaxSerno 
   end

  return '' 
end


GO
