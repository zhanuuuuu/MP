 
 
/*
--原来毛利脚本

if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods   where  cgoodsno='33341'
 
 
exec p_x_salesABC_bySupplier_chen_WH_log_Day '2014-12-31','2014-12-31',0,0,'01'
go
exec p_x_salesABC_bySupplier_chen_WH_log '2014-12-31','2014-12-31',0,0,'01'
 
*/
CREATE procedure [dbo].[p_x_salesABC_bySupplier_chen_WH_log_Day]
@dBeginDate datetime,
@dEndDate datetime,
@bJiaGong bit,
@bZero bit,
@cWHno varchar(32)
as  --查询某时段商品销售利润（含顾客退货）

if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo 
 
select distinct a.cGoodsNo,a.cSupplierNo into  #temp_GoodsNo  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno
and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''
union all
select distinct a.cGoodsNo,a.cSupplierNo  
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))=''
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
from #temp_Goods a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''

 CREATE INDEX IX_temp_GoodsNo  ON #temp_GoodsNo(cGoodsNo)
 
 /*修改主供应商-- 有入库、但是该商品为不管理库存、*/
update a
set a.cSupplierNo=b.cSupNo
from #temp_GoodsNo a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=0

declare  @cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno


declare @SQLstr varchar(8000),@SQLstr1 varchar(8000) 

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([cGoodsNo] [varchar](32) NOT NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
[cWHno] [varchar](32)  NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,
[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,
[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL,xsQty money,xsMoney money)
CREATE TABLE #temp_WhFromend   ([cGoodsNo] [varchar](32) NOT NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
[cWHno] [varchar](32)  NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,
[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,
[total_Return] [Money] NULL,[fMoney_Return_all] [Money] NULL,xsQty money,xsMoney money) 

------判断查询截止日期是否超出
declare @maxWhdDate datetime,@date1 datetime,@date2 datetime,@date_ForBgn datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1 with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)

 ---select isnull(max(业务日期),'2000-01-01') from Pos_Wh_Form.dbo.t_WH_Form_Log_1 
 
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)

if(@maxWhdDate>=@dBeginDate)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dEndDate)      --- 当记账日期小于结束日期时..
			begin
					set @date1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @date2=@dEndDate      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @date1='2000-01-01'
					set @date2='2000-01-01'
					set @maxWhdDate=@dEndDate    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @date1=@dBeginDate
		set @date2=@dEndDate 
		set @maxWhdDate=@dBeginDate-1
	end
	
	set @date_ForBgn=@dBeginDate-1
  


declare @Y1 varchar(8)
declare @M1  varchar(8)
declare @Day1  varchar(8)
set @M1=MONTH(@maxWhdDate)
set @Day1=day(@maxWhdDate)
set @Y1=YEAR(@maxWhdDate)
if LEN(@M1)=1 
begin
   set @M1='0'+@M1
end
if LEN(@Day1)=1 
begin
   set @Day1='0'+@Day1
end
declare @Y_1 varchar(8)
declare @M_1  varchar(8)
declare @Day_1  varchar(8)
set @Y_1=YEAR(@date_ForBgn)
set @M_1=MONTH(@date_ForBgn)
set @Day_1=day(@date_ForBgn)
if LEN(@M_1)=1 
begin
   set @M_1='0'+@M_1
end
if LEN(@Day_1)=1 
begin
   set @Day_1='0'+@Day_1
end

declare @MMDAY1 varchar(8)
set @MMDAY1=@M1+@Day1
declare @MMDAY_1 varchar(8)
set @MMDAY_1=@M_1+@Day_1

--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #temp_GoodsNo 

--insert into #temp_WhFrombegin([cGoodsNo],cSupplierNo) 
--select cGoodsNo,cSupplierNo from  #tmp_WhGoodsList_cGoodsno 
--insert into #temp_WhFromend  ([cGoodsNo],cSupplierNo) 
--select cGoodsNo,cSupplierNo from  #tmp_WhGoodsList_cGoodsno 
--CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
--CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)

set @SQLstr= '
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginQty''))is not null  drop table #temp_Wh_Goods_beginQty
			select a.cgoodsno,cSupplierNo=b.cSupno,fQty=b.fQty_'+@MMDAY_1+',fQtytj=b.fQtytj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
			with (nolock) 
			where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
			--and a.cSupplierNo=b.cSupno 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_beginSale''))is not null  drop table #temp_Wh_Goods_beginSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupno,Sale=b.Sale_'+@MMDAY_1+', Saletj=b.Saletj_'+@MMDAY_1+' 
			into #temp_Wh_Goods_beginSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
			with (nolock) 
			where b.cyear='''+@Y_1+''' and  a.cGoodsNo=b.cGoodsNo 
			--and a.cSupplierNo=b.cSupno 


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginQty''))is not null  drop table #temp_SumWh_Goods_beginQty
			select cgoodsno,cSupplierNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_beginQty
			from  #temp_Wh_Goods_beginQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_beginSale''))is not null  drop table #temp_SumWh_Goods_beginSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_beginSale
			from  #temp_Wh_Goods_beginSale
			group by cgoodsno,cSupplierNo
			
			

			--update a 
			--set a.fQuantity=b.fQty, 
			--a.total_Sale1=b.fQtytj,
			--a.total_Sale0=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			--from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginQty b
			--where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
			
			insert into #temp_WhFrombegin(cgoodsno,cSupplierNo,fQuantity,total_Sale0,total_Sale1)
			select cgoodsno,cSupplierNo,fQty,isnull(fQty,0)-isnull(fQtytj,0),fQtytj
			from #temp_SumWh_Goods_beginQty 
				 
		    update a 
			set a.fMoney=b.Sale, 
			a.fMoney_Sale1_all=b.Saletj,
			a.fMoney_Sale0_all=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFrombegin a ,#temp_SumWh_Goods_beginSale b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
			 
			' 

set @SQLstr1=' 
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endQty''))is not null  drop table #temp_Wh_Goods_endQty
			select a.cgoodsno,cSupplierNo=b.cSupno,fQty=b.fQty_'+@MMDAY1+',fQtytj=b.fQtytj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endQty
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Qty b
			with (nolock) 
			where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo  
			--and a.cSupplierNo=b.cSupno 
		 

			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_endSale''))is not null  drop table #temp_Wh_Goods_endSale
			            
			select a.cgoodsno,cSupplierNo=b.cSupno,Sale=b.Sale_'+@MMDAY1+', Saletj=b.Saletj_'+@MMDAY1+' 
			into #temp_Wh_Goods_endSale					
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_Log_Day_Sale b
			with (nolock) 
			where b.cyear='''+@Y1+''' and  a.cGoodsNo=b.cGoodsNo  
			--and a.cSupplierNo=b.cSupno 


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endQty''))is not null  drop table #temp_SumWh_Goods_endQty
			select cgoodsno,cSupplierNo,fQty=sum(fQty), fQtytj=sum(fQtytj) 
			into #temp_SumWh_Goods_endQty
			from  #temp_Wh_Goods_endQty
			group by cgoodsno,cSupplierNo
			
			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_endSale''))is not null  drop table #temp_SumWh_Goods_endSale
			select cgoodsno,cSupplierNo,Sale=sum(Sale), Saletj=sum(Saletj) 
			into #temp_SumWh_Goods_endSale
			from  #temp_Wh_Goods_endSale
			group by cgoodsno,cSupplierNo
			
			
          
				 
		    --update a 
			--set a.fQuantity=b.fQty, 
			--a.total_Sale1=b.fQtytj,
			--a.total_Sale0=isnull(b.fQty,0)-isnull(b.fQtytj,0)				
			--from #temp_WhFromend a ,#temp_SumWh_Goods_endQty b
			--where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
			
			insert into #temp_WhFromend(cgoodsno,cSupplierNo,fQuantity,total_Sale0,total_Sale1)
			select cgoodsno,cSupplierNo,fQty,isnull(fQty,0)-isnull(fQtytj,0),fQtytj
			from #temp_SumWh_Goods_endQty  
		 
		    update a 
			set a.fMoney=b.Sale, 
			a.fMoney_Sale1_all=b.Saletj,
			a.fMoney_Sale0_all=isnull(b.Sale,0)-isnull(b.Saletj,0)				
			from #temp_WhFromend a ,#temp_SumWh_Goods_endSale b
			where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo		  
  
	'
exec (@SQLstr+@SQLstr1)

 --- 结束日期数据-（开始日期-1）数据 得出时间段数据
     
---------------取联营调商品：调整供应商
if (select OBJECT_ID('tempdb..#temp_cGoodsnoLianying'))is not null drop table #temp_cGoodsnoLianying
select distinct a.cGoodsNo,b.cSupNo into #temp_cGoodsnoLianying
from #temp_WhFromend a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=0

update a set a.cSupplierNo=b.cSupNo
from #temp_WhFromend a,#temp_cGoodsnoLianying b
where a.cGoodsNo=b.cGoodsNo

update a set a.cSupplierNo=b.cSupNo
from #temp_WhFrombegin a,#temp_cGoodsnoLianying b
where a.cGoodsNo=b.cGoodsNo 

if (select OBJECT_ID('tempdb..#temp_cGoodsnoEndlianying'))is not null drop table #temp_cGoodsnoEndlianying
select cGoodsNo,cSupplierNo,fQuantity=SUM(fQuantity), fMoney=SUM(fMoney), 
				  total_Sale1=SUM(total_Sale1), fMoney_Sale1_all=SUM(fMoney_Sale1_all), 
				  total_Sale0=SUM(total_Sale0), fMoney_Sale0_all=SUM(fMoney_Sale0_all),
				  fMoney_Return_all=SUM(fMoney_Return_all),xsQty=SUM(xsQty),xsMoney=SUM(xsMoney)
				  into #temp_cGoodsnoEndlianying
from #temp_WhFromend 
group by cGoodsNo,cSupplierNo

if (select OBJECT_ID('tempdb..#temp_cGoodsnoBgnlianying'))is not null drop table #temp_cGoodsnoBgnlianying
select  cGoodsNo,cSupplierNo,fQuantity=SUM(fQuantity), fMoney=SUM(fMoney), 
				  total_Sale1=SUM(total_Sale1), fMoney_Sale1_all=SUM(fMoney_Sale1_all), 
				  total_Sale0=SUM(total_Sale0), fMoney_Sale0_all=SUM(fMoney_Sale0_all),
				  fMoney_Return_all=SUM(fMoney_Return_all) ,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney) 
				  into #temp_cGoodsnoBgnlianying
from #temp_WhFrombegin 
group by  cGoodsNo,cSupplierNo


update a set a.fQuantity=isnull(a.fQuantity,0)-isnull(b.fQuantity,0),
a.fMoney=isnull(a.fMoney,0)-isnull(b.fMoney,0),
a.total_Sale0=isnull(a.total_Sale0,0)-isnull(b.total_Sale0,0),
a.fMoney_Sale0_all=isnull(a.fMoney_Sale0_all,0)-isnull(b.fMoney_Sale0_all,0),
a.total_Sale1=isnull(a.total_Sale1,0)-isnull(b.total_Sale1,0),
a.fMoney_Sale1_all=isnull(a.fMoney_Sale1_all,0)-isnull(b.fMoney_Sale1_all,0),
a.fMoney_Return_all=isnull(a.fMoney_Return_all,0)-isnull(b.fMoney_Return_all,0)
from #temp_cGoodsnoEndlianying a,#temp_cGoodsnoBgnlianying b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo


 
if (select OBJECT_ID('tempdb..#temp_cSupXsdate'))is not null drop table #temp_cSupXsdate
if (select OBJECT_ID('tempdb..#temp_SalesABCbySupplier'))is not null drop table  #temp_SalesABCbySupplier 
CREATE TABLE #temp_SalesABCbySupplier   (cGoodsNo [varchar](32) NOT NULL,
cUnitedNo varchar(32),cGoodsName varchar(64),cBarcode varchar(64),cUnit varchar(32),cSpec varchar(32),
fNormalPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),
BeginDate datetime,EndDate datetime,xsQty money,xsMoney money,fQty_CurWH money,
[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,
cSupplierNo varchar(32) null,cSupName varchar(64) null,[cWHno] [varchar](32) NULL,bAuditing bit) 

	  
if @maxWhdDate<@dEndDate  --查询的结束日期》最大的结转日期时、 从销售明细表中取数据。。。 
begin    --- 调用之前算法。
 
		declare @dMaxDailyDate datetime
		set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)
		if @dMaxDailyDate>@date2
		begin
		set @dMaxDailyDate=@date2
		end
		if (select OBJECT_ID('tempdb..#temp_Goods_Cos'))is not null  drop table #temp_Goods_Cos
		select distinct cGoodsNo into #temp_Goods_Cos from #temp_Goods

		if (select OBJECT_ID('tempdb..#temp_cGoodsSaleDate'))is not null  drop table #temp_cGoodsSaleDate
		select dSaleDate,cWHno,a.cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing,cSupplierNo=null
		into #temp_cGoodsSaleDate from t_SaleSheet_Day a,#temp_Goods_Cos b
		with (nolock) 
		where dSaleDate between @date1 and @dMaxDailyDate and a.cGoodsNo=b.cGoodsNo
		union all
		select dSaleDate,cWHno,a.cGoodsNo,iSeed,fQuantity,fLastSettle,bAuditing,cSupplierNo=null
		from t_SaleSheetDetail a,#temp_Goods_Cos b
		with (nolock) 
		where dSaleDate>=@date1 and dSaleDate between (@dMaxDailyDate+1) and @date2 and a.cGoodsNo=b.cGoodsNo   
     
 
		update a set 
		a.cSupplierNo=b.cSupNo
		from #temp_cGoodsSaleDate a,t_Goods b
		where a.cGoodsNo=b.cGoodsNo 
		--- 没记账的取主供应商    
		if (select OBJECT_ID('tempdb..#tmpPackGoodsList'))is not null  drop table #tmpPackGoodsList
		select a.cGoodsNo,a.cGoodsNo_MinPackage,fQty_minPackage=isnull(a.fQty_minPackage,1),a.cSupNo
		into #tmpPackGoodsList
		from t_goods a,#temp_cGoodsSaleDate b
		where a.cGoodsNo=b.cGoodsNO and a.cGoodsNo<>isnull(a.cGoodsNo_minPackage,a.cGoodsNo) 

		update a set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*b.fQty_minPackage,
		a.cSupplierNo=b.cSupNo
		from #temp_cGoodsSaleDate a,#tmpPackGoodsList b
		where a.cGoodsNo=b.cGoodsNo

		if (select OBJECT_ID('tempdb..#temp01'))is not null  drop table #temp01
		select cGoodsNo,fqty=SUM(fQuantity),fmoney=SUM(fLastSettle),cSupplierNo,bAuditing into #temp01 from #temp_cGoodsSaleDate 
		group by cGoodsNo,cSupplierNo,bAuditing

		insert into #temp_SalesABCbySupplier(
		cGoodsNo,cGoodsName,xsQty,xsMoney,cSupplierNo,cWHno)
		select cGoodsNo,null,fqty=sum(fqty),fmoney=SUM(fmoney),cSupplierNo,@cWHno from #temp01 
		group by cGoodsNo,cSupplierNo
	    
	 update a  set a.total_Sale0=b.fqty,a.fMoney_Sale0_all=b.fmoney
    from #temp_SalesABCbySupplier a,#temp01 b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and ISNULL(b.bAuditing,0)=0
    
   	 update a  set a.total_Sale1=b.fqty,a.fMoney_Sale1_all=b.fmoney
    from #temp_SalesABCbySupplier a,#temp01 b
    where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo and ISNULL(b.bAuditing,0)=1
	    
end

if (select OBJECT_ID('tempdb..#temp_cGoodsSaleSheetdate'))is not null drop table #temp_cGoodsSaleSheetdate
select cGoodsNo,fQuantity,fMoney,
total_Sale0,fMoney_Sale0_all,
total_Sale1,fMoney_Sale1_all,
cSupplierNo,
xsQty,xsMoney
into #temp_cGoodsSaleSheetdate
from #temp_cGoodsnoEndlianying
union all
select cGoodsNo,fQuantity=null,fMoney=null,
total_Sale0,fMoney_Sale0_all,total_Sale1
,fMoney_Sale1_all,cSupplierNo ,
xsQty,xsMoney
from #temp_SalesABCbySupplier




/*2015-05-16
 一品多商情况当前供应商根据分配超出、再次新入库入其他供应商、销售分配到新入库上、
 造成查销售时之前分配超出相应供应商的商品时销售造成负数：统一修改称主供应商
*/
---获取销售为负的商品
 
if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSalCount'))is not null drop table #temp_cGoodsSale_FuSalCount
select cGoodsNo,a=COUNT(cGoodsNo) into #temp_cGoodsSale_FuSalCount from #temp_cGoodsSaleSheetdate
group by cGoodsNo
having COUNT(cGoodsNo)>1

CREATE INDEX IX_temp_cGoodsSale_FuSalCount  ON #temp_cGoodsSale_FuSalCount(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSal'))is not null drop table #temp_cGoodsSale_FuSal
select b.cGoodsNo,c.cSupNo,c.cSupName into #temp_cGoodsSale_FuSal
from #temp_cGoodsSaleSheetdate a,#temp_cGoodsSale_FuSalCount b,t_Goods c
where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=c.cGoodsNo and ISNULL(a.fMoney,0)<0

CREATE INDEX IX_temp_cGoodsSale_FuSal  ON #temp_cGoodsSale_FuSal(cGoodsNo)

update a
set a.cSupplierNo=b.cSupNo
from #temp_cGoodsSaleSheetdate a,#temp_cGoodsSale_FuSal b
where a.cGoodsNo=b.cGoodsNo


--------2015-05-16---包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.fQuantity=a.fQuantity*ISNULL(b.fQty_minPackage,1),
a.total_Sale0=a.total_Sale0*ISNULL(b.fQty_minPackage,1),
a.total_Sale1=a.total_Sale1*ISNULL(b.fQty_minPackage,1),
a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1)
from #temp_cGoodsSaleSheetdate a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

 
------------ 合计以上数据
if (select OBJECT_ID('tempdb..#temp_cGoodsSaleSheetdate_heji'))is not null drop table #temp_cGoodsSaleSheetdate_heji
select cGoodsNo,fQuantity=SUM(ISNULL(fQuantity,0)),fMoney=SUM(ISNULL(fMoney,0)),
total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
xsQty=SUM(ISNULL(xsQty,0)),xsMoney=SUM(ISNULL(xsMoney,0)),cSupplierNo ,cSupplier=b.cSupName
into #temp_cGoodsSaleSheetdate_heji
from #temp_cGoodsSaleSheetdate a,t_Supplier b
where a.cSupplierNo=b.cSupNo
group by cGoodsNo,cSupplierNo,b.cSupName


select GoodsNo_Pdt=a.cGoodsNo,a.fQuantity,a.fMoney,--- 表示已记账销售数量、金额
	a.total_Sale0,a.fMoney_Sale0_all,
	a.total_Sale1,a.fMoney_Sale1_all,
	b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
	b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
	BeginDate=@dBeginDate,EndDate=@dEndDate,a.cSupplierNo,cSupName=a.cSupplier ,
	xsQty,xsMoney,  --- 表示未记账销售数量、金额
	hejiQty=isnull(fQuantity,0)+isnull(xsQty,0),hejiMoney=isnull(fMoney,0)+isnull(xsMoney,0),
	fPrice_Contract=isnull(b.fPrice_Contract,0),
	fMoney_Contract=isnull(b.fPrice_Contract,0)*(isnull(fQuantity,0)+isnull(xsQty,0)),
	fMoney_Diff=(isnull(fMoney,0)+isnull(xsMoney,0))-(isnull(b.fPrice_Contract,0)*(isnull(fQuantity,0)+isnull(xsQty,0)))	
    into #temp_cSupXsdate
	from #temp_cGoodsSaleSheetdate_heji a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo
 
 
if(select object_id('tempdb..#temp_SupplierNo')) is not null 
begin
   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.GoodsNo_Pdt,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
		         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,fQuantity=ISNULL(a.fQuantity,0),fMoney=ISNULL(a.fMoney,0),
		         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(a.hejiQty,0),hejiMoney=isnull(a.hejiMoney,0),a.total_Sale0,a.fMoney_Sale0_all,
	a.total_Sale1,a.fMoney_Sale1_all,a.fPrice_Contract,a.fMoney_Contract,a.fMoney_Diff
	into #temp_goodsKuCun_last
	from #temp_cSupXsdate a,#temp_SupplierNo b
    where a.cSupplierNo=b.cSupplierNo 
    and isnull(hejiMoney,0)<>0
    
       if(select object_id('tempdb..##temp_SupSale')) is not null  drop table ##temp_SupSale
    select cGoodsNo=GoodsNo_Pdt,xsMoney=hejiMoney into ##temp_SupSale from 
    #temp_goodsKuCun_last
    
    select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=ISNULL(fQuantity,0),fMoney=ISNULL(fMoney,0),
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(hejiQty,0),hejiMoney=isnull(hejiMoney,0),total_Sale0,fMoney_Sale0_all,
	total_Sale1,fMoney_Sale1_all,fPrice_Contract,fMoney_Contract,fMoney_Diff
		  from #temp_goodsKuCun_last where isnull(hejiMoney,0)<>0
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),
		         total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)
		  from #temp_goodsKuCun_last  where isnull(hejiMoney,0)<>0
		  group by cSupplierNo,cSupName,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)		         
		  from #temp_goodsKuCun_last where isnull(hejiMoney,0)<>0
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
		  
end else
begin 
     select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=ISNULL(fQuantity,0),fMoney=ISNULL(fMoney,0),
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)--,fQty_CurWH=isnull(fQty_CurWH,0)
		         ,hejiQty=isnull(hejiQty,0),hejiMoney=isnull(hejiMoney,0),total_Sale0,fMoney_Sale0_all,
	total_Sale1,fMoney_Sale1_all,fPrice_Contract,fMoney_Contract,fMoney_Diff
		  from #temp_cSupXsdate where isnull(hejiMoney,0)<>0
		  union all
		  select GoodsNo_Pdt='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo,cSupName,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),
		         total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)
		  from #temp_cSupXsdate  where isnull(hejiMoney,0)<>0
		  group by cSupplierNo,cSupName,BeginDate,EndDate
		  union all
		  select GoodsNo_Pdt='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,
		  cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
		         BeginDate,EndDate,cSupplierNo='总计:',cSupName=null,fQuantity=sum(ISNULL(fQuantity,0)),fMoney=sum(ISNULL(fMoney,0)),
		         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0))--,fQty_CurWH=sum(isnull(fQty_CurWH,0))
		         ,hejiQty=sum(isnull(hejiQty,0)),hejiMoney=sum(isnull(hejiMoney,0)),total_Sale0=SUM(ISNULL(total_Sale0,0)),fMoney_Sale0_all=SUM(ISNULL(fMoney_Sale0_all,0)),
total_Sale1=SUM(ISNULL(total_Sale1,0)),fMoney_Sale1_all=SUM(ISNULL(fMoney_Sale1_all,0)),
fPrice_Contract=null,fMoney_Contract=SUM(fMoney_Contract),fMoney_Diff=SUM(fMoney_Diff)		         
		  from #temp_cSupXsdate where isnull(hejiMoney,0)<>0
		  group by BeginDate,EndDate
		  order by cSupplierNo,cGoodsTypeno,GoodsNo_Pdt
end
GO
