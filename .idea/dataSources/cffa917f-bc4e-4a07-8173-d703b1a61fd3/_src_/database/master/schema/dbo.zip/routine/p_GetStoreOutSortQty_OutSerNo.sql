/*
   exec [p_GetStoreOutSortQty] 
  
   delete U_key.dbo.TempQty_11221346340340 
   
   exec [p_GetStoreOutSortQty_OutSerNo] '2016-11-25','1011','TP201611-000009','201611251011-001',''
   
   select iLineNo,cSheetNo,cGoodsNo,cGoodsName,cProductSerno,fQty_Out,fQty_Sort 
   from U_key.dbo.TempQty_11221346340340
   
*/
   create proc [dbo].[p_GetStoreOutSortQty_OutSerNo]
   @dDate datetime,
   @cStoreNo varchar(32),
   @cPalletNo varchar(32),
   @cOutSerNo varchar(32),   
   @cTermID varchar(32)
   as
   
   if (select object_id('tempdb..#temp_PalletBoxNo'))is not null
    drop table #temp_PalletBoxNo

   select  cDistBoxNo_SortSheetNo,a.cSheetno into #temp_PalletBoxNo
   from wh_PalletSheet a,wh_PalletSheetDetail b 
   where a.dDate=@dDate and a.cSheetno=b.cSheetno  
   --and a.cSheetno=@cPalletNo
   and a.cCustomerNo=@cStoreNo and isnull(a.bExamin,0)=1
   and ISNULL(a.bReceive,0)=0
    order by a.dDate
   
   if (select object_id('tempdb..#temp_StoreOutSort'))is not null
   drop table #temp_StoreOutSort
    
   select iLIneNo=IDENTITY(int,1,1),cSheetno=a.cOutSerNo,b.cGoodsNo,b.cProductSerno,fqt=SUM(b.fQuantity),fQty_Sort=sum(b.fPrice_SO),
   b.cOutiLineNo,cSheetno_Pallet=c.cSheetno
   into #temp_StoreOutSort
   from wh_cStoreOutWarehouse_Sort a,wh_cStoreOutWarehouseDetail_Sort b,#temp_PalletBoxNo c
   where a.cSheetno=b.cSheetno and a.cSheetno=c.cDistBoxNo_SortSheetNo
   and a.cOutSerNo=@cOutSerNo  ----指定批次
   group by a.cOutSerNo,b.cGoodsNo,b.cProductSerno,b.cOutiLineNo,c.cSheetno
   
 
   exec('
   delete U_key.dbo.TempQty_'+@cTermID+' 
   insert into U_key.dbo.TempQty_'+@cTermID+'(iLIneNo,cSheetNo,cGoodsNo,cProductSerno,cGoodsName,fQty_Out,fQty_Sort,cOutiLineNo,cSheetno_Pallet) 
   select iLIneNo,cSheetno,a.cGoodsNo,a.cProductSerno,b.cGoodsName,fQty_Sort,fQty_Out=fqt,cOutiLineNo,cSheetno_Pallet
   from #temp_StoreOutSort a,t_Goods b
   where a.cGoodsNo=b.cGoodsNo
   ')


GO
