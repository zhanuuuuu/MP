/*

p_Get_ScalDateCenter_ScaleList '00','1001'

*/
CREATE procedure p_Get_ScalDateCenter_ScaleList
@cStoreNo varchar(32),
@cComputerNo varchar(32)
as
begin
  select a.cStoreNo, a.cScaleNo, a.cPort, a.cComputerName, a.cComputerNo,
  b.cSheetno, b.iLineNo, b.cGoodsNo, b.cGoodsName, 
  iStatus=isnull(a.iStatus,0), cUnit='斤',b.fQty_Net,b.fQty_Mass,b.fQty_Tare,
   b.dDatetime_Ready, b.dDatetime_Scale, 
  b.cPort, b.cStoreName, b.cComputerName,
  b.cComputerNo,iStatus_Qty=isnull(a.iStatus_Qty,1),
  cStatus=case isnull(a.iStatus,0) 
               when 0 then cast('空闲' as varchar(16))
               when 1 then cast('正在使用' as varchar(16))
               when 2 then cast('使用完毕' as varchar(16))
               else cast('维修中...' as varchar(16))
          end      
  from 
  dbo.t_ScaleDataCenter_ScaleList a left join dbo.t_ScaleDataCenter b
       on a.cStoreNo=b.cStoreNo and a.cScaleNo=b.cScaleNo
  where a.cStoreNo=@cStoreNo and a.cComputerNo=@cComputerNo 
end
GO
