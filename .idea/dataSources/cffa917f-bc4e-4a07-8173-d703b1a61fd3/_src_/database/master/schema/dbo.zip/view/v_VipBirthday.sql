

CREATE view [dbo].[v_VipBirthday]
	as
	select 
		cVipNo,
		yourbirthday=

		case when (datepart(month,dBirthday)<datepart(month,getdate()))
		then
			dbo.trim(cast((datepart(year, getdate())+1) as varchar(16)))+'-'+datename(month, dBirthday)+'-'+datename(day, dBirthday)
		else
		  case when (datepart(month,dBirthday)=datepart(month,getdate())) and datepart(day, dBirthday)<datepart(day, getdate())
		  then
				dbo.trim(cast((datepart(year, getdate())+1) as varchar(16)))+'-'+datename(month, dBirthday)+'-'+datename(day, dBirthday)
		  else
				dbo.trim(cast((datepart(year, getdate())) as varchar(16)))+'-'+datename(month, dBirthday)+'-'+datename(day, dBirthday)
		  end
		end

		from dbo.t_Vip
		where ISDATE(dBirthday)=1 and (dBirthday is not null)


GO
