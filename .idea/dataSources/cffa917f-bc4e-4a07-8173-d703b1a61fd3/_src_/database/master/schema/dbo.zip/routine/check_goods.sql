create proc [dbo].[check_goods]
as

declare @cZoneNo varchar(32),@cSupplierNo varchar(32),@cSheetNO varchar(32) 
set @cZoneNo=(select distinct cZoneNo from #temp_CheckList) 

  set @cSupplierNo=(select distinct cSupplierNo from #temp_CheckList) 
  set @cSheetNO=(select dbo.f_CheckWhSheetNo(@cZoneNo,@cSupplierNo)) 
  
update #temp_CheckList set cSheetNO=@cSheetNO,cSupplierNo=@cSupplierNo,cZoneNo=@cZoneNo

if (select OBJECT_ID('tempdb..#temp_CheckList0'))is not null drop table #temp_CheckList0
select a.cSheetNO,a.cGoodsNo,b.cGoodsName,b.cUnitedNo,a.fQuantity,b.fNormalPrice 
into #temp_CheckList0 
from #temp_CheckList a,t_Goods b where a.cGoodsNo=b.cGoodsNo and 1<>1


insert into #temp_CheckList0(cSheetNO,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fNormalPrice) 
select a.cSheetno,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fTimes 
from wh_CheckWhDetail a,(select distinct cSheetNO,cSupplierNo from #temp_CheckList) b where a.cSheetno=b.cSheetNO


alter table #temp_CheckList0 add iLineNo  int IDENTITY(1,1)  

insert into #temp_CheckList0(cSheetno,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fNormalPrice) 
select a.cSheetNO,a.cGoodsNo,b.cGoodsName,b.cUnitedNo,a.fQuantity,b.fNormalPrice 
from #temp_CheckList a,t_Goods b where a.cGoodsNo=b.cGoodsNo


delete a from wh_CheckWhDetail a,(select distinct cSheetNO,cSupplierNo from #temp_CheckList) b where a.cSheetno=b.cSheetNO
delete a from wh_CheckWh a,(select distinct cSheetNO,cSupplierNo from #temp_CheckList) b where a.cSheetno=b.cSheetNO and a.cSupplierNo=b.cSupplierNo


insert into wh_CheckWh(dDate,cSheetno,cSupplier,cSupplierNo,cOperator,cOperatorNo,dFillin,cWh,cWhNo,cZoneNo,cZone,cTime,cFillEmp,cFillEmpNo)
  select distinct b.dCheckTask,a.cSheetNO,b.cCheckTask,b.cCheckTaskNo,a.cOperator,a.cOperatorNo,convert(varchar(10),getdate(),120),b.cWhName,b.cWhNo,
  c.cZoneNo,c.cZoneName,cTime=convert(varchar,getdate(),8),a.cOperator,a.cOperatorNo 
  from #temp_CheckList a,t_CheckTast b,t_CheckTast_zone c 
  where a.cSupplierNo=b.cCheckTaskNo and b.cCheckTaskNo=c.cCheckTaskNo and a.cZoneNo=c.cZoneNo
insert into wh_CheckWhDetail(cSheetno,iLineNo,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fTimes) 
  select cSheetno,iLineNo,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fNormalPrice from #temp_CheckList0
  
insert into U_key.dbo.wh_CheckWhDetail_Back(dPiCiDate,cSupplierNo,cZoneNo,cSheetno,iLineNo,cGoodsNo,cGoodsName,cUnitedNo,fQuantity,fTimes) 
select dPiCiDate=GETDATE(),a.cSupplierNo,a.cZoneNo,a.cSheetNO,a.iLineNo,a.cGoodsNo,b.cGoodsName,b.cUnitedNo,a.fQuantity,
b.fNormalPrice from #temp_CheckList a,t_Goods b where a.cGoodsNo=b.cGoodsNo
GO
