

create      function [dbo].[f_GenBaoSunSheetno_daystr] --报损单号生成
(@cYear varchar(8),@cSupplierNo varchar(16),@daystr varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(cSheetno) from wh_LossWarehouse
                  where cSupplierNo=@cSupplierNo
                        and datename(yyyy,dDate)=@cYear
                 )
   if @cMaxSerno is null 
   begin
     return  'LS'+@daystr+'.'+@cSupplierNo+'-'+'000001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,6) as int)+1 as varchar(10))))
     --set @i=0 
     while len(@cMaxSerno)<6 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     return  'LS'+@daystr+'.'+@cSupplierNo+'-'+@cMaxSerno 
   end

  return ''
end

GO
