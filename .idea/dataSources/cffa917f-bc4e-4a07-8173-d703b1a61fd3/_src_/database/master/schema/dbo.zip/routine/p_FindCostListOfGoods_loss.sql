


CREATE          procedure p_FindCostListOfGoods_loss
@bMainSale bit,/*1-主卖场；0－一般仓库*/
@cWHno varchar(32),
@fProfitsRatio_Set money
as
begin
--  select cGoodsNo into #t_Goods_selected from t_Goods
	declare @Date2 datetime
  set @Date2=dbo.getDayStr(getdate())
	select distinct cGoodsno
  into #t_Goods_selected_onlyGoodsno 
	from t_goods

--select * from #t_Goods_selected_onlyGoodsno
/*计算商品的购买成本*/

/*查询联营商品信息，联营扣点即为毛利率*/

	select distinct cSupNo=guizuno  
	into #tempSupplier_cSupNo 
	from dbo.t_Supplier_Contract_Ratio

	select a.cGoodsNo,a.cSupNo
	into #tempSupplier_cSupNo_cGoodsNo
	from (select e.cGoodsNo, e.cSupNo 
				from dbo.t_Supplier_goods e
				right join #t_Goods_selected_onlyGoodsno f
				on e.cGoodsNo=f.cGoodsNo
				where e.cGoodsNo is not null 
			 ) a 
	left join #tempSupplier_cSupNo b
	on a.cSupNo=b.cSupNo
	where b.cSupNo is not null

	union all  	

  select a.cGoodsNo,b.cSupNo
--	from dbo.wh_InWarehouseDetail a 
	from (select f.cGoodsNo, cSupNo=e.cSupplierNo,e.cSheetno 
				from (select g.cGoodsNo,h.cSupplierNo,g.cSheetno from dbo.wh_InWarehouseDetail g
							left join wh_InWarehouse h on g.cSheetno=h.cSheetno	
							where h.cWHno=@cWHno		
							) e
				right join #t_Goods_selected_onlyGoodsno f
				on e.cGoodsNo=f.cGoodsNo
				where e.cSheetno is not null 
			 ) a 
	left join ( select c.cSheetno,d.cSupNo 
							from wh_InWarehouse c left join #tempSupplier_cSupNo d
							on c.cSupplierNo=d.cSupNo
							where d.cSupNo is not null and c.cSheetNo is not null 
							      and c.cWHno=@cWHno		
						) b
	on a.cSheetno=b.cSheetno
	where b.cSupNo is not null

--select * from #tempSupplier_cSupNo_cGoodsNo

  select a.cGoodsNo,a.cSupNo
  into #tempSupplier_cSupNo_cGoodsNo_withoutEstop_0
	from #tempSupplier_cSupNo_cGoodsNo a
	left join dbo.t_Supplier_goods_eStop b 
	on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
	where b.cGoodsNo is null and b.cSupNo is null
	
  select fRatio=max(fRatio),cSupNo=guizuno
	into #t_Supplier_Contract_Ratio
	from t_Supplier_Contract_Ratio
	group by guizuno


	select distinct a.cGoodsNo,a.cSupNo,b.fRatio,cSupName=b.cSupNo 
  into #tempSupplier_cSupNo_cGoodsNo_withoutEstop	
	from #tempSupplier_cSupNo_cGoodsNo_withoutEstop_0 a
	left join #t_Supplier_Contract_Ratio b
	on a.cSupNo=b.cSupNo

/*以上是查询联营商品*/



/* 将商品分成两部分1)供货2)联营扣点*/
  select a.cGoodsNo  --1)供货
	into #tempSale_BySupply
  from #t_Goods_selected_onlyGoodsno a
	left join #tempSupplier_cSupNo_cGoodsNo_withoutEstop b
	on a.cGoodsNo=b.cGoodsNo
	where b.cGoodsNo is null		

  select distinct a.cGoodsNo  --2)联营扣点
	into #tempSale_ByRatio
  from #tempSupplier_cSupNo_cGoodsNo_withoutEstop a

--select * from #tempSale_BySupply

/* 以上将商品分成两部分1)供货2)联营扣点*/
--select * from #tempSale_BySupply

--select * from #tempSale_ByRatio
	/*计算供货的毛利*/
  select a.cSheetno,a.iLineNo,a.cGoodsNo,a.fQuantity,a.fInMoney,b.cWhNo,b.cWh,b.dDate,
	b.cSupplierNo,b.cSupplier
  into #wh_InWarehouseDetail_temp0
	from ( select c.cSheetno,c.iLineNo,c.cGoodsNo,c.fQuantity,c.fInMoney 
				 from dbo.wh_InWarehouseDetail c
				 right join #tempSale_BySupply d
				 on c.cGoodsNo=d.cGoodsNo
				 where c.cGoodsNo is not null		
			 ) a	
	left join dbo.wh_InWarehouse b
	on a.cSheetno=b.cSheetno
	where a.cSheetno is not null 
	union all
  select a.cSheetno,a.iLineNo,a.cGoodsNo,-a.fQuantity,-a.fInMoney,b.cWhNo,b.cWh,b.dDate,
	b.cSupplierNo,b.cSupplier
	from ( select c.cSheetno,c.iLineNo,c.cGoodsNo,c.fQuantity,c.fInMoney 
				 from dbo.wh_RbdWarehouseDetail c
				 right join #tempSale_BySupply d
				 on c.cGoodsNo=d.cGoodsNo
				 where c.cGoodsNo is not null		
			 ) a	
	left join dbo.wh_RbdWarehouse b
	on a.cSheetno=b.cSheetno
	where a.cSheetno is not null 
/*
select * from #wh_InWarehouseDetail_temp0
where cGoodsNo='21030087'
*/
  select cGoodsNo,sumInMoney=isnull(sum(isnull(fInMoney,0)),0),
									sumfQuantity= isnull(sum(isnull(fQuantity,0)),1),avgCostPrice=cast(0.00 as money)
																		 

	into #avgCostPrice
	from #wh_InWarehouseDetail_temp0
	where cWhNo=@cWhNo and dDate <=@date2
	group by cGoodsNo


  update #avgCostPrice set avgCostPrice=round(sumInMoney*case when sumfQuantity<>0 then 1.00/sumfQuantity
																									      else null
																									 end,	
                                              3)

  select f.cGoodsNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,f.fProfitsRatio,f.fCurSalePrice,f.fCurCostPrice, dDate=@Date2,f.cCooperate
	from
  (
	  select a.cGoodsNo, fProfitsRatio=a.fRatio,
					fCurSalePrice=b.fNormalPrice,fCurCostPrice=b.fNormalPrice*(100-a.fRatio)/100.00,
					cCooperate='联营扣点'
	  from #tempSupplier_cSupNo_cGoodsNo_withoutEstop a
		left join t_Goods b on a.cGoodsNo=b.cGoodsNo
		union all
	  select a.cGoodsNo, fProfitsRatio=(b.fNormalPrice-a.avgCostPrice)/b.fNormalPrice*100.00,
					fCurSalePrice=b.fNormalPrice,fCurCostPrice=a.avgCostPrice,cCooperate='供货'
	  from #avgCostPrice a
		left join t_Goods b on a.cGoodsNo=b.cGoodsNo
		where isnull(b.fNormalPrice,0)<>0
	) f left join t_goods a on a.cGoodsNo=f.cGoodsNo
  where f.fProfitsRatio is not null and f.fProfitsRatio<=@fProfitsRatio_Set 


  return 1


	
end


GO
