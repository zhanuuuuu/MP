CREATE proc [dbo].[yi_shen_yan_huo_dan_goods1]
  as
  --查询已经审核没有装车的验货单的商品
  
   if (select object_id('tempdb..#temp_yan_huo_dan_goods'))is not null
  drop table #temp_yan_huo_dan_goods
  
  select a.cSheetno,a.cCustomerNo,a.cCustomer,a.cStoreNo,a.cStoreName,a.cWhNo,a.cwh,a.dDate,a.cSheetNo_Pallet  ,
         b.cGoodsNo,b.cGoodsName,b.cBarcode ,b.cUnitedNo,b.fQuantity,b.fInPrice,b.fInMoney,b.cUnit,b.dProduct
         into #temp_yan_huo_dan_goods 
         from wh_cStoreOutVerifySheet a ,wh_cStoreOutVerifySheetDetail b where a.cSheetno=b.cSheetno 
         and ISNULL(a.bExamin,0)=1 and ISNULL(a.bReceive,0)=0
        
        --查询已经审核的配送出库验货单对应的托盘单单号
    if(select object_id('tempdb..#temp_StoreOutVerifySheet_Pallet_no'))    is not null
     drop table #temp_StoreOutVerifySheet_Pallet_no
     select a.cSheetno
     into #temp_StoreOutVerifySheet_Pallet_no
     from wh_PalletSheet   a,  wh_cStoreOutVerifySheet b  
     where b.cSheetNo_Pallet=a.cSheetno  and  ISNULL(b.bExamin,0)=1 and ISNULL(b.bReceive,0)=0 
     
     --查询托盘单对应的分拣单号
     
    if(select object_id('tempdb..#temp_Store_Pallet_no_below_fenjian_no'))    is not null 
      drop table #temp_Store_Pallet_no_below_fenjian_no
      select a.cPalletNo,a.cDistBoxNo, a.cDistBoxNo_SortSheetNo
      into #temp_Store_Pallet_no_below_fenjian_no
      from wh_PalletSheetDetail a,#temp_StoreOutVerifySheet_Pallet_no b
       where a.cSheetno=b.cSheetno
       
       
     --查询分拣单对应的商品信息
     
     if(select object_id('tempdb..#temp_Store_fen_jian_dan_goods')) is not null
      drop table #temp_Store_fen_jian_dan_goods
      select  a.cPalletNo,a.cDistBoxNo, a.cDistBoxNo_SortSheetNo, b.cGoodsNo,b.cBarcode,b.jiesuanno
      into #temp_Store_fen_jian_dan_goods
      from #temp_Store_Pallet_no_below_fenjian_no a, wh_cStoreOutWarehouseDetail_Sort b
      
      where  a.cDistBoxNo_SortSheetNo=b.cSheetno
      
      
      --分拣单对应的商品信息和 已经审核没有装车的验货单的商品进行关联

      
      select  a.cSheetno,a.cCustomerNo,a.cCustomer,a.cStoreNo,a.cStoreName,a.cWhNo,a.cwh,a.dDate,a.cSheetNo_Pallet  ,
         a.cGoodsNo,a.cGoodsName,a.cBarcode ,a.cUnitedNo,a.fQuantity,a.fInPrice,a.fInMoney,a.cUnit,a.dProduct, 
          b.cPalletNo,b.cDistBoxNo, b.cDistBoxNo_SortSheetNo,b.jiesuanno
      
      from  #temp_yan_huo_dan_goods a, #temp_Store_fen_jian_dan_goods b
      where a.cGoodsNo=b.cGoodsNo
GO
