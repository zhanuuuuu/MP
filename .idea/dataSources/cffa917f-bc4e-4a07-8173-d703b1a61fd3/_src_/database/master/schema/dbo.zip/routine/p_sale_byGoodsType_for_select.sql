/*
select cGoodsNo into #temp_Goods from t_Goods

[p_sale_byGoodsType_for_select]
'2012-02-01','2012-02-29','01'
*/
CREATE procedure [dbo].[p_sale_byGoodsType_for_select]
@dBeginDate datetime,
@dEndDate datetime,
@cWHno varchar(32)
as

if(select object_id('tempdb..#temp_GoodsNo')) is not null drop table  #temp_GoodsNo 
if(select object_id('tempdb..#t_SaleSheetDetail_shelf_ready')) is not null drop table #t_SaleSheetDetail_shelf_ready
if(select object_id('tempdb..#t_SaleSheetDetail_shelf')) is not null drop table #t_SaleSheetDetail_shelf
if(select object_id('tempdb..#t_SaleSheetDetail1')) is not null drop table #t_SaleSheetDetail1
if(select object_id('tempdb..#temp_goodsKuCun1')) is not null drop table #temp_goodsKuCun1
if(select object_id('tempdb..#temp_kusun')) is not null drop table #temp_kusun
if(select object_id('tempdb..#temp_goodsKuCun1_NoZero')) is not null drop table #temp_goodsKuCun1_NoZero

select distinct cGoodsNo into #temp_GoodsNo from #temp_Goods--t_Goods 

declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=cdbname from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_begin')) is not null drop table #temp_begin
if(select object_id('tempdb..#temp_end')) is not null drop table #temp_end
CREATE TABLE #temp_begin (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[fQty_In] [money] NULL,[fMoney_In] [money] NULL,[fQty_TfrIn] [money] NULL,[fMoney_TfrIn] [money] NULL,[fQty_Return] [money] NULL,[fMoney_Return] [money] NULL,[fQty_Effusion] [money] NULL,[fMoney_Effusion] [money] NULL,[fQty_Divide] [money] NULL,[fMoney_Divide] [money] NULL,[fQty_Pack] [money] NULL,[fMoney_Pack] [money] NULL,[fQty_trf] [money] NULL,[fMoney_trf] [money] NULL,[fQty_Rbd] [money] NULL,[fMoney_Rbd] [money] NULL,[fQty_Loss] [money] NULL,[fMoney_Loss] [money] NULL,[fQty_out] [money] NULL,[fMoney_out] [money] NULL,[fQty_Check_Diff] [money] NULL,[fQty_pd] [money] NULL,[fMoney_pd] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_In] [money] NULL,[fMoney_In_all] [money] NULL,[total_TfrIn] [money] NULL,[fMoney_TfrIn_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[total_Effusion] [money] NULL,[fMoney_Effusion_all] [money] NULL,[total_Divide] [money] NULL,[fMoney_Divide_all] [money] NULL,[total_Pack] [money] NULL,[fMoney_Pack_all] [money] NULL,[total_trf] [money] NULL,[fMoney_trf_all] [money] NULL,[total_Rbd] [money] NULL,[fMoney_Rbd_all] [money] NULL,[total_Loss] [money] NULL,[fMoney_Loss_all] [money] NULL,[total_out] [money] NULL,[fMoney_out_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL)
CREATE TABLE #temp_end   (ForSign varchar(32),[dDateTime] [datetime] NOT NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32) NOT NULL,[fQuantity] [money] NULL,[fMoney] [money] NULL,[fMoney_all] [money] NULL,[cSupNo] [varchar](32) NULL,[fQty_Sale_0] [money] NULL,[fMoney_Sale_0] [money] NULL,[fQty_Sale_1] [money] NULL,[fMoney_Sale_1] [money] NULL,[fQty_In] [money] NULL,[fMoney_In] [money] NULL,[fQty_TfrIn] [money] NULL,[fMoney_TfrIn] [money] NULL,[fQty_Return] [money] NULL,[fMoney_Return] [money] NULL,[fQty_Effusion] [money] NULL,[fMoney_Effusion] [money] NULL,[fQty_Divide] [money] NULL,[fMoney_Divide] [money] NULL,[fQty_Pack] [money] NULL,[fMoney_Pack] [money] NULL,[fQty_trf] [money] NULL,[fMoney_trf] [money] NULL,[fQty_Rbd] [money] NULL,[fMoney_Rbd] [money] NULL,[fQty_Loss] [money] NULL,[fMoney_Loss] [money] NULL,[fQty_out] [money] NULL,[fMoney_out] [money] NULL,[fQty_Check_Diff] [money] NULL,[fQty_pd] [money] NULL,[fMoney_pd] [money] NULL,[total_Sale0] [money] NULL,[fMoney_Sale0_all] [money] NULL,[total_Sale1] [money] NULL,[fMoney_Sale1_all] [money] NULL,[total_In] [money] NULL,[fMoney_In_all] [money] NULL,[total_TfrIn] [money] NULL,[fMoney_TfrIn_all] [money] NULL,[total_Return] [money] NULL,[fMoney_Return_all] [money] NULL,[total_Effusion] [money] NULL,[fMoney_Effusion_all] [money] NULL,[total_Divide] [money] NULL,[fMoney_Divide_all] [money] NULL,[total_Pack] [money] NULL,[fMoney_Pack_all] [money] NULL,[total_trf] [money] NULL,[fMoney_trf_all] [money] NULL,[total_Rbd] [money] NULL,[fMoney_Rbd_all] [money] NULL,[total_Loss] [money] NULL,[fMoney_Loss_all] [money] NULL,[total_out] [money] NULL,[fMoney_out_all] [money] NULL,[fPrice_Avg] [money] NULL,[Ratio] [money] NULL,[Ratio_Money] [money] NULL,[Ratio_Money_all] [money] NULL) 

------判断查询截止日期是否超出
declare @date datetime,@date1 datetime,@date2 datetime,@date_ForBgn datetime
if (select OBJECT_ID('tempdb..#temp_date'))is not null drop table #temp_date
create table #temp_date (MaxDate datetime)
set @SQLstr='select max(dDateTime) from ['+@cdbname+'].dbo.t_Goods_CurWH_relation where cWHno='+@cWHno+''
insert into #temp_date
exec (@SQLstr)
select @date=MaxDate from #temp_date
--如果超出，则分段查询@dDateBegin---@date(MaxDate),   @date1--@date2(@dDateEnd)
if(@date>=@dBeginDate-1)
	begin
		if (@date<@dEndDate)    
			begin
					set @date1=@date+1
					set @date2=@dEndDate
			end
		else
			begin
					set @date1='2000-01-01'
					set @date2='2000-01-01'
					set @date=@dEndDate
			end
	end
else
	begin 
		set @date1=@dBeginDate
		set @date2=@dEndDate 
	end
set @date_ForBgn=@dBeginDate-1
if @date_ForBgn>@date set @date_ForBgn=@date

-----查最大日结时间内信息@dDateBegin到@dDateEnd
insert into #temp_begin(ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='Bgn',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 
insert into #temp_end  (ForSign,[dDateTime],[cGoodsNo],[cWHno]) select ForSign='End',dDateTime=(@dEndDate+1),cGoodsNo,@cWhNo from  #temp_GoodsNo 

set @SQLstr= 'update a 
              set a.fQuantity=b.fQuantity,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,
              a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
              a.fQty_Return=b.fQty_Return,a.fMoney_Return=b.fMoney_Return,
              
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
			  a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
			  
              from #temp_begin a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date_ForBgn)+''' and b.cWHno='+@cWHno+'
             '
set @SQLstr1='update a
              set a.fQuantity=b.fQuantity,a.cSupNo=b.cSupNo,
              a.fQty_Sale_0=b.fQty_Sale_0,a.fMoney_Sale_0=b.fMoney_Sale_0,
              a.fQty_Sale_1=b.fQty_Sale_1,a.fMoney_Sale_1=b.fMoney_Sale_1,
              a.fQty_Return=b.fQty_Return,a.fMoney_Return=b.fMoney_Return,
              
              a.total_Sale0=b.total_Sale0,a.fMoney_Sale0_all=b.fMoney_Sale0_all,
              a.total_Sale1=b.total_Sale1,a.fMoney_Sale1_all=b.fMoney_Sale1_all,
			  a.total_Return=b.total_Return,a.fMoney_Return_all=b.fMoney_Return_all
			  
              from #temp_end a ,['+@cdbname+'].dbo.t_Goods_CurWH_relation b
              where a.cGoodsNo=b.cGoodsNo and b.dDateTime='''+dbo.getdaystr(@date)+''' and b.cWHno='''+@cWHno+'''
            '
exec (@SQLstr+@SQLstr1)
declare @dMaxDailyDate datetime
set @dMaxDailyDate=(select MAX(dDate) from t_Daily_history where cWHno=@cWHno)+1

-----------------------------------------  从各个数据库中取日销售
  ------2012-10-15  销售结转---------------------------------------------------------------    
  if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
  

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,fLastSettle money ,bAuditing bit,cWHno varchar(32))


	 
	exec p_x_salesABC_bySupplier_chen_WH_Ref @date1,@date2,@dMaxDailyDate,@cWHno  
	 
-----------------------------------------

--------------------------------已结转
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0)+isnull(total_Sale1,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0)+isnull(fMoney_Sale1_all,0))-ISNULL(fMoney_Return_all,0)
  into #t_SaleSheetDetail_shelf 
  from #temp_begin 
  union all
  select ForSign,dSaleTime=dDateTime,cGoodsNo,
         fQuantity=-(isnull(total_Sale0,0)+isnull(total_Sale1,0))-ISNULL(total_Return,0),
         fLastSettle=-(isnull(fMoney_Sale0_all,0)+isnull(fMoney_Sale1_all,0))-ISNULL(fMoney_Return_all,0)
  from #temp_end
--------------------------------未结转
  union all  
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle
 -- from  #temp_GoodsNo a,t_SaleSheet_Day b       
 from #temp_GoodsNo a,#temp_SaleSheet_Day b  
  where a.cGoodsNo=b.cGoodsNo and (b.dSaleDate between (@date+1) and @date2) and b.cWHno=@cWHno 
  union all
  select 'X',c.dDate,a.cGoodsNo,fQuantity=-b.fQuantity,fLastSettle=-b.fInMoney
  from  #temp_GoodsNo a,WH_ReturnGoodsDetail b,WH_ReturnGoods c 
  where a.cGoodsNo=b.cGoodsNo and b.cSheetno=c.cSheetno and (c.dDate between (@date+1) and @date2) and c.cWHno=@cWHno 
  union all   ---未日结
  select 'X',b.dSaleDate,a.cGoodsNo,b.fQuantity,b.fLastSettle
  --from  #temp_GoodsNo a,t_SaleSheetDetail b  
  from  #temp_GoodsNo a,#temp_salesheetDetail b        
  where a.cGoodsNo=b.cGoodsNo and (b.dSaleDate between @dMaxDailyDate and @date2) and b.cWHno=@cWHno 
  
---销售数量
  select a.cGoodsNo,Qty=a.Qty-b.Qty,fLastMoney=a.fLastMoney-b.fLastMoney
  into #t_SaleSheetDetail1  --销售单
  from 
      (  
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
         from #t_SaleSheetDetail_shelf 
         where ForSign='End' or (ForSign='X' and dSaleTime between @dBeginDate and @dEndDate)
         group by cGoodsNo
      ) a left join 
      (
         select cGoodsNo,sum(isnull(fQuantity,0)) as Qty,sum(isnull(fLastSettle,0)) as fLastMoney
         from #t_SaleSheetDetail_shelf 
         where ForSign='Bgn' group by cGoodsNo
      )b on a.cGoodsNo=b.cGoodsNo 
--合并  开始
      select distinct GoodsNo_Pdt=a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,s.cGoodsTypename,b.bProducted,b.cProductNo, 
                  BeginDate=@dBeginDate,EndDate=@dEndDate,
                  xsQty=m.qty,xsMoney=m.fLastMoney
      into #temp_goodsKuCun1_NoZero 
      from  #temp_GoodsNo a,t_goods b,t_GoodsType s,#t_SaleSheetDetail1 m 
      where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=m.cGoodsNo and s.cGoodsTypeno=b.cGoodsTypeno 
--合并  结束
/*      
      select GoodsNo_Pdt,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
		         BeginDate,EndDate,
		         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0)
	  from #temp_goodsKuCun1_NoZero
*/
if(select object_id('tempdb..#temp_dateBase')) is not null 
begin 
		insert into #temp_dateBase
		(GoodsNo_Pdt ,cUnitedNo ,cGoodsName ,cBarcode ,cUnit ,cSpec ,
		fNormalPrice ,cGoodsTypeno ,cGoodsTypename ,bProducted ,cProductNo ,
		BeginDate ,EndDate ,xsQty ,xsMoney )

		select GoodsNo_Pdt ,cUnitedNo ,cGoodsName ,cBarcode ,cUnit ,cSpec ,
		fNormalPrice ,cGoodsTypeno ,cGoodsTypename ,bProducted ,cProductNo ,
		BeginDate ,EndDate ,xsQty ,xsMoney 
		from #temp_goodsKuCun1_NoZero
end
--select * from #temp_goodsKuCun1_NoZero
--select sum(xsMoney) 
--from #temp_goodsKuCun1_NoZero
GO
