/*
--select * from t_MonthOfYearReportChen
生成月报表
declare @iPrevious_Year1 int
declare @iPrevious_Month1 int
declare @iPrevious_Year2 int
declare @iPrevious_Month2 int
declare @iPrevious_Year3 int
declare @iPrevious_Month3 int
declare @iPrevious_Year4 int
declare @iPrevious_Month4 int
declare @iPrevious_Year5 int
declare @iPrevious_Month5 int

exec P_MonthOfYearReportChen @iPrevious_Year1 output,@iPrevious_Month1 output,@iPrevious_Year2 output,@iPrevious_Month2 output,
                       @iPrevious_Year3 output,@iPrevious_Month3 output,@iPrevious_Year4 output,@iPrevious_Month4 output,
                       @iPrevious_Year5 output,@iPrevious_Month5 output
select @iPrevious_Year1,@iPrevious_Month1,@iPrevious_Year2,@iPrevious_Month2,
                       @iPrevious_Year3,@iPrevious_Month3,@iPrevious_Year4,@iPrevious_Month4,
                       @iPrevious_Year5,@iPrevious_Month5

*/
create proc P_MonthOfYearReportChen
@iPrevious_Year1 int output,
@iPrevious_Month1 int output,
@iPrevious_Year2 int output,
@iPrevious_Month2 int output,
@iPrevious_Year3 int output,
@iPrevious_Month3 int output,
@iPrevious_Year4 int output,
@iPrevious_Month4 int output,
@iPrevious_Year5 int output,
@iPrevious_Month5 int output
as
set dateFirst 1
declare @iYear int
declare @iMonth int
set @iYear=year(getdate())
set @iMonth=datepart(mm,getdate())
--select @iYear,@iMonth
--declare @iPrevious_Year1 int
--declare @iPrevious_Month1 int
--declare @iPrevious_Year2 int
--declare @iPrevious_Month2 int
--declare @iPrevious_Year3 int
--declare @iPrevious_Month3 int
--declare @iPrevious_Year4 int
--declare @iPrevious_Month4 int
--declare @iPrevious_Year5 int
--declare @iPrevious_Month5 int
if @iMonth>=6 
begin
  set @iPrevious_Year1=@iYear
  set @iPrevious_Month1=@iMonth-1

  set @iPrevious_Year2=@iYear
  set @iPrevious_Month2=@iMonth-2

  set @iPrevious_Year3=@iYear
  set @iPrevious_Month3=@iMonth-3

  set @iPrevious_Year4=@iYear
  set @iPrevious_Month4=@iMonth-4

  set @iPrevious_Year5=@iYear
  set @iPrevious_Month5=@iMonth-5

end else
begin
  if @iMonth=5 
  begin
    set @iPrevious_Year1=@iYear
    set @iPrevious_Month1=4

    set @iPrevious_Year2=@iYear
    set @iPrevious_Month2=3

    set @iPrevious_Year3=@iYear
    set @iPrevious_Month3=2

    set @iPrevious_Year4=@iYear
    set @iPrevious_Month4=1

    set @iPrevious_Year5=@iYear-1
    set @iPrevious_Month5=12
  end
  if @iMonth=4 
  begin
    set @iPrevious_Year1=@iYear
    set @iPrevious_Month1=3

    set @iPrevious_Year2=@iYear
    set @iPrevious_Month2=2

    set @iPrevious_Year3=@iYear
    set @iPrevious_Month3=1

    set @iPrevious_Year4=@iYear-1
    set @iPrevious_Month4=12

    set @iPrevious_Year5=@iYear-1
    set @iPrevious_Month5=11
  end
  if @iMonth=3 
  begin
    set @iPrevious_Year1=@iYear
    set @iPrevious_Month1=2

    set @iPrevious_Year2=@iYear
    set @iPrevious_Month2=1

    set @iPrevious_Year3=@iYear-1
    set @iPrevious_Month3=12

    set @iPrevious_Year4=@iYear-1
    set @iPrevious_Month4=11

    set @iPrevious_Year5=@iYear-1
    set @iPrevious_Month5=10
  end
  if @iMonth=2 
  begin
    set @iPrevious_Year1=@iYear
    set @iPrevious_Month1=1

    set @iPrevious_Year2=@iYear
    set @iPrevious_Month2=12

    set @iPrevious_Year3=@iYear-1
    set @iPrevious_Month3=11

    set @iPrevious_Year4=@iYear-1
    set @iPrevious_Month4=10

    set @iPrevious_Year5=@iYear-1
    set @iPrevious_Month5=9
  end
 if @iMonth=1
  begin
    set @iPrevious_Year1=@iYear-1
    set @iPrevious_Month1=12

    set @iPrevious_Year2=@iYear-1
    set @iPrevious_Month2=11

    set @iPrevious_Year3=@iYear-1
    set @iPrevious_Month3=10

    set @iPrevious_Year4=@iYear-1
    set @iPrevious_Month4=9

    set @iPrevious_Year5=@iYear-1
    set @iPrevious_Month5=8
  end
end
/*
select @iPrevious_Year1,@iPrevious_Month1
select @iPrevious_Year2,@iPrevious_Month2
select @iPrevious_Year3,@iPrevious_Month3
select @iPrevious_Year4,@iPrevious_Month4
select @iPrevious_Year5,@iPrevious_Month5
*/
if (select object_id('tempdb..#tmpGoodsCurWh')) is not null
drop table #tmpGoodsCurWh
select a.cGoodsNo,b.cSupNo,a.fQty_CurWh
into #tmpGoodsCurWh
from 
(
  select cGoodsNo,fQty_CurWh=sum(isnull(fQty_CurWh,0))
  from t_Goods_CurWH
  group by cGoodsNo
)a left join t_goods b
on a.cGoodsNO=b.cGoodsNO
where a.cGoodsNo is not null 

if (select object_id('tempdb..#tmpGoods_Report1')) is not null
drop table #tmpGoods_Report1
select a.iYear,a.iMonth,a.cGoodsNo,a.cSupNo,a.fPeriod_Stock_Qty,a.fPeriod_Verify_Qty,
b.fQty_CurWh
into #tmpGoods_Report1
from t_MonthOfYearReportChen a left join #tmpGoodsCurWh b
on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
and a.iYear=@iYear and a.iMonth=@iMonth
where  a.iYear=@iYear and a.iMonth=@iMonth and a.cGoodsNo is not null



if (select object_id('tempdb..#tmpGoods_Report2')) is not null
drop table #tmpGoods_Report2
select a.iYear,a.iMonth,a.cGoodsNo,b.cGoodsName,b.cBarCode,b.cUnit,b.cSpec,b.fNormalPrice,a.cSupNo,
b.cSupName,a.fPeriod_Stock_Qty,a.fPeriod_Verify_Qty,a.fQty_CurWh,
fSaleQty_FiveMonthAvg=cast(null as money),fSaleQty_Month1=cast(null as money),
fSaleQty_Month2=cast(null as money),fSaleQty_Month3=cast(null as money),
fSaleQty_Month4=cast(null as money),fSaleQty_Month5=cast(null as money),
fNewXh=cast(null as money),
fAdvQty=cast(null as money),
fNewDh=cast(null as money)
into #tmpGoods_Report2
from #tmpGoods_Report1 a left join t_goods b
on a.cGoodsNo=b.cGoodsNo
where a.cGoodsNo is not null

--------------------------------fAdvQty建议订货量
update a
set a.fAdvQty=isnull(b.fPreservationUp,0)-isnull(a.fPeriod_Stock_Qty,0)
from #tmpGoods_Report2 a left join t_goods b
on a.cGoodsNo=b.cGoodsNo 
--------------------------------

update a
set a.fSaleQty_Month1=fPeriod_Sale_Qty
from #tmpGoods_Report2 a,t_MonthOfYearReportChen b
where a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo
and b.iYear=@iPrevious_Year1  and b.iMonth=@iPrevious_Month1
update a
set a.fSaleQty_Month2=fPeriod_Sale_Qty
from #tmpGoods_Report2 a,t_MonthOfYearReportChen b
where a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo
and b.iYear=@iPrevious_Year2  and b.iMonth=@iPrevious_Month2
update a
set a.fSaleQty_Month3=fPeriod_Sale_Qty
from #tmpGoods_Report2 a,t_MonthOfYearReportChen b
where a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo
and b.iYear=@iPrevious_Year3  and b.iMonth=@iPrevious_Month3
update a
set a.fSaleQty_Month4=fPeriod_Sale_Qty
from #tmpGoods_Report2 a,t_MonthOfYearReportChen b
where a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo
and b.iYear=@iPrevious_Year4  and b.iMonth=@iPrevious_Month4
update a
set a.fSaleQty_Month5=fPeriod_Sale_Qty
from #tmpGoods_Report2 a,t_MonthOfYearReportChen b
where a.cGoodsNO=b.cGoodsNo and a.cSupNo=b.cSupNo
and b.iYear=@iPrevious_Year5  and b.iMonth=@iPrevious_Month5

update #tmpGoods_Report2
set fSaleQty_FiveMonthAvg=(isnull(fSaleQty_Month1,0)+isnull(fSaleQty_Month2,0)
                         +isnull(fSaleQty_Month3,0)+isnull(fSaleQty_Month4,0)+isnull(fSaleQty_Month5,0))/5

--select * from #tmpGoods_Report2
--select * from t_MonthOfYearReportChen order by iyear,iMonth
--select * from t_goods
if (select object_id('tempdb..##tmpinfo'))is not null
drop table ##tmpinfo
select cSupNo,cSupName,iYear,iMonth,cGoodsNo,cGoodsName,cBarCode,cUnit,cSpec,fNormalPrice,
fPeriod_Stock_Qty,fPeriod_Verify_Qty,fQty_CurWh,
fSaleQty_FiveMonthAvg,fSaleQty_Month1,fSaleQty_Month2,fSaleQty_Month3,
fSaleQty_Month4,fSaleQty_Month5,fNewXh,fAdvQty,fNewDh,iSerNo=1
into ##tmpInfo
from #tmpGoods_Report2
union all
select distinct cSupNo,cSupName,iYear,iMonth,cGoodsNo=null,cGoodsName=null,cBarCode=null,cUnit=null,cSpec=null,fNormalPrice=null,
fPeriod_Stock_Qty=null,fPeriod_Verify_Qty=null,fQty_CurWh=null,
fSaleQty_FiveMonthAvg=null,fSaleQty_Month1=null,fSaleQty_Month2=null,fSaleQty_Month3=null,
fSaleQty_Month4=null,fSaleQty_Month5=null,fNewXh=null,fAdvQty=null,fNewDh=null,iSerNo=0
from #tmpGoods_Report2

--order by cSupNo,iSerNo,cGoodsNo
GO
