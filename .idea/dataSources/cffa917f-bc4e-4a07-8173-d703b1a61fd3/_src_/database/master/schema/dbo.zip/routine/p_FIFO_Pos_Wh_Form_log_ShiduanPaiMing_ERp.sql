
 
/*
--原来毛利脚本
 
 
if (select OBJECT_ID('tempdb..#temp_Goods'))is not null drop table #temp_Goods
select cGoodsNo,cSupplierNo=csupno into #temp_Goods from t_Goods  

 
exec p_FIFO_Pos_Wh_Form_log_ShiduanPaiMing '2015-4-1','2015-4-30','02'


*/
CREATE procedure [dbo].[p_FIFO_Pos_Wh_Form_log_ShiduanPaiMing_ERp]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32),
@key varchar(32) 
as  --查询某时段 商品销售利润（含顾客退货） 

	declare @dDateBgn datetime,@dDateEnd datetime
	set @dDateBgn=@dDate1 set @dDateEnd=@dDate2  
 
  /*_________根据类别获取基本信息____________*/
   
if(select object_id('tempdb..#temp_Goods')) is not null drop table  #temp_Goods
Create Table #temp_Goods (
cGoodsNo varchar(128),
cProductNo varchar(128),
cSupplierNo varchar(128)) 

if(select object_id('tempdb..#temp_GoodsTypeNo')) is not null  drop table  #temp_GoodsTypeNo
create table #temp_GoodsTypeNo(cGoodsTypeno varchar(32))

 
insert into  #temp_Goods(cGoodsNo,cSupplierNo) 
exec(' 
if  (select object_id(''Temp_SupKey.dbo.temp_type'+@key+''')) is  null
select cGoodsTypeno into Temp_SupKey.dbo.temp_type'+@key+' from t_Goodstype where 1<>1

insert into #temp_GoodsTypeNo(cGoodsTypeno) select cGoodsTypeno from Temp_SupKey.dbo.temp_type'+@key+' 

select cGoodsNo,cSupplierNo=csupno from t_Goods where cGoodsTypeno in (select cGoodsTypeno from Temp_SupKey.dbo.temp_type'+@key+')

')
 
 
    /*获取商品信息*/ 
    if (select object_id('tempdb..#temp_Goods_1'))is not null drop table #temp_Goods_1

    select distinct a.cGoodsNo,b.cSupplierNo into #temp_Goods_1   from wh_InWarehouseDetail a
    right join wh_InWarehouse b on a.cSheetno=b.cSheetno 
    where a.cGoodsNo in (select cGoodsNo from #temp_Goods)
    and a.cGoodsNo not in 
    (select cGoodsNo from t_Supplier_goods_eStop where cGoodsNo in (select cGoodsNo from #temp_Goods))
    union
    select distinct a.cGoodsNo,a.cSupno from  t_goods a
    where  a.cGoodsNo in (select cGoodsNo from #temp_Goods)  


if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
select distinct cGoodsNo,cSupplierNo into  #tmp_WhGoodsList  from (
select distinct a.cGoodsNo,a.cSupplierNo  
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno   
union all
select distinct cGoodsNo=b.cGoodsNo_minPackage,a.cSupplierNo    ---有关联包装的 供应商不一致的。。 
from #temp_Goods_1 a,t_goods b
where a.cgoodsno=b.cgoodsno and dbo.trim(isnull(b.cGoodsNo_minPackage,''))<>''  
) a

CREATE INDEX IX_tmp_WhGoodsList  ON #tmp_WhGoodsList(cGoodsNo)


if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods
select distinct cGoodsNo into #temp_WhFromGoods from #tmp_WhGoodsList

CREATE INDEX IX_temp_WhFromGoods  ON #temp_WhFromGoods(cGoodsNo)

--print dbo.getTimeStr(GETDATE())
--print 2

/*修改主供应商-- 有入库、但是该商品为不管理库存、*/
 
declare @SQLstr varchar(8000),@SQLstr1 varchar(8000),@cdbname varchar(32)
select distinct @cdbname=Pos_WH_Form from dbo.t_WareHouse where cWhNo=@cWHno

if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
CREATE TABLE #temp_WhFrombegin ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
 cSupplierNo varchar(32) null,cSupplier varchar(64) null, 
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money,
  会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
CREATE TABLE #temp_WhFromend   ([dDateTime] [datetime]  NULL,[cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null, 
  销售数量0 money, 销售金额0 money, 
  特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money, 本日库存数量 money, 盘点数量 money, 
  盘点单价 money, 库存标志 bit,期初库存 money,期末库存 money,fmoney_koudian money,fPrice_Avg money,fml money,fmoney_cost money,fmoney_left money,
  会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
 -----------创建会员销售和来客数量
if(select object_id('tempdb..#temp_WhFrombeginVIP')) is not null drop table #temp_WhFrombeginVIP
if(select object_id('tempdb..#temp_WhFromendVIP')) is not null drop table #temp_WhFromendVIP
CREATE TABLE #temp_WhFrombeginVIP ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
CREATE TABLE #temp_WhFromendVIP   ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
   
 /*快照表中的最大日期。。。*/

--set @maxWhdDate=(select isnull(max(dDate),'2000-01-01') from t_Daily_history where ISNULL(bAccount_log,0)=1 and cWHno=@cWHno)
 declare @maxWhdDate datetime
 if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
 create table #temp_maxWhdDate(dDate datetime)

insert into #temp_maxWhdDate(dDate)
exec('select isnull(max(业务日期),''2000-01-01'') from '+@cdbname+'.dbo.t_WH_Form_Log_1  with (nolock) ')
set @maxWhdDate=(select dDate from #temp_maxWhdDate)
/*结转表中取数据*/

declare @dDate_1 datetime
declare @dDate_2 datetime
if(@maxWhdDate>=@dDateBgn)  -- 当记账日期大于等于开始日期时.
	begin
		if (@maxWhdDate<@dDateEnd)      --- 当记账日期小于结束日期时..
			begin
					set @dDate_1=@maxWhdDate+1  ----------  记账时间段为@dDateBgn between @maxWhdDate
					set @dDate_2=@dDateEnd      ----------  未记账时间段 @maxWhdDate+1 between @dDate2
			end
		else
			begin             ---- 当记账日期大于等于结束日期时.
					set @dDate_1='2000-01-01'
					set @dDate_2='2000-01-01'
					set @maxWhdDate=@dDateEnd    ---   
			end
	end
else  ------ 当最大记账日期不在查询的范围内时... 
	begin 
		set @dDate_1=@dDateBgn
		set @dDate_2=@dDateEnd
		set @maxWhdDate=@dDateBgn-1  
	end 

-----查最大日结时间内信息@dDateBegin到@dDateEnd
if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_cGoodsno'))is not null drop table #tmp_WhGoodsList_cGoodsno
select distinct cGoodsNo into #tmp_WhGoodsList_cGoodsno from  #tmp_WhGoodsList 

CREATE INDEX IX_temp_WhFrombegin  ON #temp_WhFrombegin(cGoodsNo)
CREATE INDEX IX_temp_WhFromend  ON #temp_WhFromend(cGoodsNo)
CREATE INDEX IX_tmp_WhGoodsList_cGoodsno  ON #tmp_WhGoodsList_cGoodsno(cGoodsNo)
--销售数量0, 销售金额0, 
--  特价销售数量, 特价销售金额, 正价销售数量, 正价销售金额
declare @strDateBgn varchar(32)
declare @strDateEnd varchar(32)
declare @strBgn varchar(32)
set @strDateBgn=dbo.getdaystr(@dDateBgn-1)
set @strDateEnd=dbo.getdaystr(@maxWhdDate)
set @strBgn=dbo.getdaystr(@dDateBgn) 
exec('
		if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_begin''))is not null  drop table #temp_Wh_Goods_begin
		select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
		b.特价销售数量, b.特价销售金额, 
		b.正价销售数量, b.正价销售金额,		 
		b.本日库存数量, b.盘点数量,
		b.fPrice_In,
		fmoney_cost=b.fPrice_In*b.销售数量0,
		fml=b.销售金额0-b.fPrice_In*b.销售数量0 
		,b.fmoney_left,
		b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数
		into #temp_Wh_Goods_begin 
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
		with (nolock) 
		where b.业务日期='''+@strDateBgn+'''  and a.cGoodsNo=b.cGoodsNo 
		and b.cWHno='+@cWHno+' 			 
		union all             
		select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.销售数量0, b.销售金额0, 
		b.特价销售数量, b.特价销售金额, 
		b.正价销售数量, b.正价销售金额,

		b.本日库存数量, b.盘点数量,
		b.fPrice_In,
		fmoney_cost=b.fPrice_In*b.销售数量0,
		fml=b.销售金额0-b.fPrice_In*b.销售数量0 
		,b.fmoney_left,
		会员销售数量=0,会员销售金额=0,会员来客数=0,来客数=0
		from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
		with (nolock) 
		where b.业务日期='''+@strDateBgn+'''  and  a.cGoodsNo=b.cGoodsNo 
		and b.cWHno='+@cWHno+' and  b.iAttribute<>20				  


		insert into #temp_WhFrombeginVIP(cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数 )
		select distinct cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数
		from #temp_Wh_Goods_begin
		where isnull(来客数,0)<>0



		if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_begin''))is not null  drop table #temp_SumWh_Goods_begin
		select cgoodsno,cWHno,cSupplierNo,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
		正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),	 
		本日库存数量=SUM(isnull(本日库存数量,0)), 
		盘点数量=SUM(isnull(盘点数量,0)),
		fPrice_Avg=AVG(fPrice_In),
		fmoney_cost=sum(fmoney_cost),
		fml=SUM(fml),
		fmoney_left=sum(fmoney_left),
		会员销售数量=sum(会员销售数量),会员销售金额=sum(会员销售金额),会员来客数=sum(会员来客数),来客数=sum(来客数)
		into #temp_SumWh_Goods_begin
		from #temp_Wh_Goods_begin
		group by cgoodsno,cSupplierNo,cWHno		



		insert into #temp_WhFrombegin(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
		本日库存数量,盘点数量,期初库存,fPrice_Avg,fmoney_cost,fml,fmoney_left,会员销售数量,会员销售金额,会员来客数,来客数 )
		select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,
		本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml,fmoney_left,会员销售数量,会员销售金额,会员来客数,来客数
		from #temp_SumWh_Goods_begin
			 
				 ')
--print dbo.getTimeStr(GETDATE())
--print 3 
exec('
			if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_end''))is not null  drop table #temp_Wh_Goods_end
			select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
			b.特价销售数量, b.特价销售金额, 
			b.正价销售数量, b.正价销售金额,			 
			b.本日库存数量, b.盘点数量,
			b.fPrice_In,
			fmoney_cost=b.fPrice_In*b.销售数量0,
			fml=b.销售金额0-b.fPrice_In*b.销售数量0 ,b.fmoney_left,
			b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数
			into #temp_Wh_Goods_end 
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_1 b
			with (nolock) 
			where b.业务日期='''+@strDateEnd+'''  and  a.cGoodsNo=b.cGoodsNo 
			and b.cWHno='+@cWHno+' 
			union all             
			select 业务日期,a.cgoodsno,b.cSupplierNo,b.cWHno,b.dDatetime,b.销售数量0, b.销售金额0, 
			b.特价销售数量, b.特价销售金额, 
			b.正价销售数量, b.正价销售金额,			 
			b.本日库存数量, b.盘点数量,
			b.fPrice_In,
			fmoney_cost=b.fPrice_In*b.销售数量0,
			fml=b.销售金额0-b.fPrice_In*b.销售数量0 
			,b.fmoney_left,
			会员销售数量=0,会员销售金额=0,会员来客数=0,来客数=0
			from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			with (nolock) 
			where  b.业务日期 between '''+@strDateBgn+'''  and '''+@strDateEnd+'''  and a.cGoodsNo=b.cGoodsNo 
			and b.cWHno='+@cWHno+' and  b.iAttribute<>20


			insert into #temp_WhFromendVIP(cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数 )
			select distinct cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数
			from #temp_Wh_Goods_end
			where isnull(来客数,0)<>0


			if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_end''))is not null  drop table #temp_SumWh_Goods_end
			select cgoodsno,cSupplierNo,cWHno,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
			特价销售数量=SUM(isnull(特价销售数量,0)), 特价销售金额=SUM(isnull(特价销售金额,0)), 
			正价销售数量=SUM(isnull(正价销售数量,0)), 正价销售金额=SUM(isnull(正价销售金额,0)),

			本日库存数量=SUM(isnull(本日库存数量,0)), 盘点数量=SUM(isnull(盘点数量,0)),
			fPrice_Avg=AVG(fPrice_In),
			fmoney_cost=sum(fmoney_cost),
			fml=SUM(fml),
			fmoney_left=sum(fmoney_left),
			会员销售数量=sum(会员销售数量),会员销售金额=sum(会员销售金额),会员来客数=sum(会员来客数),来客数=sum(来客数)					   
			into #temp_SumWh_Goods_end
			from #temp_Wh_Goods_end
			group by cgoodsno,cSupplierNo,cWHno	


			insert into #temp_WhFromend(cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
			本日库存数量,盘点数量,期末库存,fPrice_Avg,fmoney_cost,fml,fmoney_left,会员销售数量,会员销售金额,会员来客数,来客数)
			select cgoodsno,cWHno,cSupplierNo,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,				
			本日库存数量,盘点数量,本日库存数量,fPrice_Avg,fmoney_cost,fml,fmoney_left,会员销售数量,会员销售金额,会员来客数,来客数
			from #temp_SumWh_Goods_end

			')
---exec (@SQLstr+@SQLstr1)
insert into   #temp_WhFromend(cgoodsno,cWhno,cSupplierno)
select a.cgoodsno,a.cWhno,a.cSupplierno from #temp_WhFrombegin a left join #temp_WhFromend b
on a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
where isnull(b.cGoodsNo,'')='' 

-------------获取当天的来客数

update a 
set  
a.会员销售数量=isnull(a.会员销售数量,0)-isnull(b.会员销售数量,0),
a.会员销售金额=isnull(a.会员销售金额,0)-isnull(b.会员销售金额,0),
a.会员来客数=a.会员来客数-b.会员来客数,
a.来客数=a.来客数-b.来客数
from #temp_WhFromendVIP a,#temp_WhFrombeginVIP b
where a.cGoodsNo=b.cGoodsNo  

--	print dbo.getTimeStr(GETDATE())
--print 4
-- 最大的记账日期@date大于等于查询的结束日期 则直接从t_WH_Form_log 快照表中取数据。。。
--- 结束日期数据-（开始日期-1）数据 得出时间段数据    
 
update a 
set a.销售数量0=isnull(a.销售数量0,0)-isnull(b.销售数量0,0), 
a.销售金额0=isnull(a.销售金额0,0)-isnull(b.销售金额0,0), 
a.特价销售数量=isnull(a.特价销售数量,0)-isnull(b.特价销售数量,0), 
a.特价销售金额=isnull(a.特价销售金额,0)-isnull(b.特价销售金额,0), 
a.正价销售数量=isnull(a.正价销售数量,0)-isnull(b.正价销售数量,0), 
a.正价销售金额=isnull(a.正价销售金额,0)-isnull(b.正价销售金额,0),				
a.期初库存=isnull(b.期初库存,0), 
a.期末库存=isnull(a.期末库存,0), 
a.盘点数量=isnull(a.盘点数量,0)-isnull(b.盘点数量,0),
a.fPrice_Avg=a.fPrice_Avg,
a.fmoney_cost=isnull(a.fmoney_cost,0)-isnull(b.fmoney_cost,0),
a.fml=isnull(a.fml,0)-isnull(b.fml,0) 
from #temp_WhFromend a,#temp_WhFrombegin b
where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo

------联营的数据------获取联营供应商的扣点	

if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
CREATE TABLE #temp_WhKouDian ([cGoodsNo] [varchar](32) NOT NULL,
cSupplierNo varchar(32) null,cSupplier varchar(32) null,销售数量0 money, 销售金额0 money, 
特价销售数量 money, 特价销售金额 money, 正价销售数量 money, 正价销售金额 money,fPrice_Avg money,
fmoney_koudian money,fMoney_cost money,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)
--print dbo.getTimeStr(GETDATE())
--print 5
if(select object_id('tempdb..#temp_WhKouDianVIP')) is not null drop table #temp_WhKouDianVIP
CREATE TABLE #temp_WhKouDianVIP ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)

if(select object_id('tempdb..#temp_WhKouDianEndVIP')) is not null drop table #temp_WhKouDianEndVIP
CREATE TABLE #temp_WhKouDianEndVIP ([cGoodsNo] [varchar](32) NOT NULL,会员销售数量 money,会员销售金额 money,会员来客数 money,来客数 money)


exec('
          if (select OBJECT_ID(''tempdb..#temp_WhForm0_Goods_end''))is not null  drop table #temp_WhForm0_Goods_end
          select a.cgoodsno,b.cSupplierNo,b.cSupplier,销售数量0=isnull(b.当日正价销售数量,0)+isnull(b.当日特价销售数量,0), 
          销售金额0=isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0), 
		  特价销售数量=b.当日特价销售数量, 特价销售金额=b.当日特价销售金额, 
		  正价销售数量=b.当日正价销售数量, 正价销售金额=b.当日正价销售金额,
		  koudian=b.扣率金额,fMoney_cost=(isnull(b.当日正价销售金额,0)+isnull(b.当日特价销售金额,0)-isnull(b.扣率金额,0))	
		  into #temp_WhForm0_Goods_end				 
		  from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where  b.业务日期 between '''+@strBgn+''' and '''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo  
		  and b.cWHno='+@cWHno+' and  b.iAttribute=20
		  
          insert into #temp_WhKouDian
          ([cGoodsNo],cSupplierNo,cSupplier,销售数量0,销售金额0,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fmoney_koudian,fMoney_cost)          
          select cgoodsno,cSupplierNo,cSupplier,销售数量0=SUM(isnull(销售数量0,0)), 销售金额0=SUM(isnull(销售金额0,0)), 
		  特价销售数量=SUM(特价销售数量), 特价销售金额=SUM(特价销售金额), 正价销售数量=SUM(正价销售数量), 
		  正价销售金额=SUM(正价销售金额),koudian=sum(koudian),fMoney_cost=SUM(isnull(fMoney_cost,0))					 
		  from #temp_WhForm0_Goods_end	
		  group by cgoodsno,cSupplierNo,cSupplier
		  
         insert into #temp_WhKouDianEndVIP(cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数)
         select distinct a.cgoodsno,b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数		
		  from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
	     with (nolock) 
		  where  b.业务日期='''+@strDateBgn+''' and a.cGoodsNo=b.cGoodsNo  
		  and b.cWHno='+@cWHno+' and  b.iAttribute=20
		 
 
		 insert into #temp_WhKouDianVIP(cgoodsno,会员销售数量,会员销售金额,会员来客数,来客数)
         select distinct a.cgoodsno,b.会员销售数量,b.会员销售金额,b.会员来客数,b.来客数		
		  from #tmp_WhGoodsList_cGoodsno a ,'+@cdbname+'.dbo.t_WH_Form_log_0 b
			 with (nolock) 
		  where  b.业务日期='''+@strDateEnd+''' and a.cGoodsNo=b.cGoodsNo  
		  and b.cWHno='+@cWHno+' and  b.iAttribute=20
		  
		    
		 
')	
 
--print dbo.getTimeStr(GETDATE())
--print 6
update a 
set  
a.会员销售数量=isnull(a.会员销售数量,0)-isnull(b.会员销售数量,0),
a.会员销售金额=isnull(a.会员销售金额,0)-isnull(b.会员销售金额,0),
a.会员来客数=a.会员来客数-b.会员来客数,
a.来客数=a.来客数-b.来客数
from #temp_WhKouDianVIP a,#temp_WhKouDianEndVIP b
where a.cGoodsNo=b.cGoodsNo  



if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
select cGoodsNo,xsQty=销售数量0, xsMoney=销售金额0,fMoney_Cost,fml,cSupplierNo,cSupplier,fPrice_Avg,
 特价销售数量,特价销售金额,正价销售数量,正价销售金额, 
fmoney_left,期初库存, 期末库存,会员销售数量,会员销售金额,会员来客数,来客数
into #temp_goodsKuCunml
from #temp_WhFromend  --where  isnull(fml,0)<>0
union all
select  cGoodsNo,销售数量0, 销售金额0,fMoney_Cost,fmoney_koudian,cSupplierNo,cSupplier,fPrice_Avg, 
特价销售数量,特价销售金额,正价销售数量,正价销售金额, 
CAST(0 as money),CAST(0 as money),CAST(0 as money),会员销售数量,会员销售金额,会员来客数,来客数
from #temp_WhKouDian --where 销售数量0<>0
 
 

if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
select cGoodsNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
cSupplierNo,fCostPrice=AVG(fPrice_Avg),
特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),
fmoney_left=SUM(fmoney_left),期初库存=SUM(期初库存), 期末库存=SUM(期末库存),
会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),来客数=SUM(来客数)
into #temp_goodsKuCun
from #temp_goodsKuCunml
group by cGoodsNo,cSupplierNo 


--print dbo.getTimeStr(GETDATE())
--print 7
---------获取时间段内的差价表。。---------
       if (select OBJECT_ID('tempdb..#tmp_WhGoodsList_begin_1'))is not null  
       drop table #tmp_WhGoodsList_begin_1
       select distinct cGoodsNo,cWhNo=@cWhNo,销售数量0=CAST(0 as money) into #tmp_WhGoodsList_begin_1 from  #tmp_WhGoodsList 

       CREATE INDEX IX_temp_WhGoodsList_begin_1  ON #tmp_WhGoodsList_begin_1(cGoodsNo)

		--------表示当前分配的差价单的供应商在当前的列表中存在
		if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo'))is not null  
		drop table #temp_wh_DiffGoodsNo
		select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo
		from t_dDateDiffFqty a,#tmp_WhGoodsList_begin_1 b
		where dSaleDate between @dDate1 and @dDate2 
		and a.cGoodsno=b.cGoodsNo 
		group by a.cGoodsno,a.cSupNo
		
 
		CREATE INDEX IX_temp_wh_DiffGoodsNo  ON #temp_wh_DiffGoodsNo(cGoodsNo)

		if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1'))is not null  
		drop table #temp_wh_DiffGoodsNo1
		select b.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo1
		from #temp_wh_DiffGoodsNo a,#temp_goodsKuCun b
		where a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
		group by b.cGoodsno,a.cSupNo
		
        CREATE INDEX IX_temp_wh_wh_DiffGoodsNo1  ON #temp_wh_DiffGoodsNo1(cGoodsNo)
        
		update a
		set 
		a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
		a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
		from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1 b
		where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo


        if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null'))is not null  
		drop table #temp_wh_DiffGoodsNo1_Null
		select a.cGoodsno,a.cSupNo,fqty_Sale=SUM(fqty_Sale),fMoney_Diff=SUM(fMoney_Diff)
		into #temp_wh_DiffGoodsNo1_Null
		from #temp_wh_DiffGoodsNo a left join #temp_goodsKuCun b
		on a.cGoodsno=b.cGoodsNo  and a.cSupNo=b.cSupplierNo
		where ISNULL(b.cGoodsNo,'')=''
        group by a.cGoodsno,a.cSupNo
        
        CREATE INDEX IX_temp_wh_DiffGoodsNo1_Null  ON #temp_wh_DiffGoodsNo1_Null(cGoodsNo)
        
        if (select OBJECT_ID('tempdb..#temp_wh_DiffGoodsNo1_Null0'))is not null  
		drop table #temp_wh_DiffGoodsNo1_Null0
        select b.cGoodsNo,cSupNo=b.cSupplierNo,fqty_Sale=sum(a.fqty_Sale),fMoney_Diff=sum(a.fMoney_Diff),cRows=COUNT(b.cGoodsNo)
        into #temp_wh_DiffGoodsNo1_Null0
        from #temp_wh_DiffGoodsNo1_Null a,#temp_goodsKuCun b
        where a.cGoodsno=b.cGoodsNo and a.cSupNo<>b.cSupplierNo
        group by b.cGoodsNo,b.cSupplierNo
        having COUNT(b.cGoodsNo)=1
 
       update a
	   set 
	   a.fML=ISNULL(fMoney_Diff,0)+isnull(a.fML,0),
	   a.fMoney_Cost=a.fMoney_Cost-ISNULL(fMoney_Diff,0)   
	   from #temp_goodsKuCun a,#temp_wh_DiffGoodsNo1_Null0 b
	   where a.cGoodsNo=b.cGoodsNo and  a.cSupplierNo=b.cSupNo

/*
 2015-03-11 获取库存调整的商品
*/
if(select object_id('tempdb..#tmpGoodsRelationKucun_0')) is not null 
drop table #tmpGoodsRelationKucun_0
select distinct cGoodsno,cSupplierNo into #tmpGoodsRelationKucun_0 from #temp_goodsKuCun

--------获取期末前最新的调整数
if(select object_id('tempdb..#tmpGoodsRelationKucun_1')) is not null 
drop table #tmpGoodsRelationKucun_1
select a.cGoodsNo,fNewPrice=a.NewFckprice,dDateTime=max(dDateTime)--,a.cSupNo
into #tmpGoodsRelationKucun_1
from posmanagement_Relation01.dbo.t_GoodsUpdatePrice a,#tmpGoodsRelationKucun_0 b
where dDatetime<=@dDateEnd and a.cgoodsno=b.cgoodsno  
group by a.cGoodsNo,a.NewFckprice 
	
---------修改最近调整成本商品的毛利
update a 
set a.fMoney_Cost=ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fML=isnull(a.xsMoney,0)-ISNULL(a.xsQty,0)*ISNULL(b.fNewPrice,0),
a.fCostPrice=b.fNewPrice
from #temp_goodsKuCun a,#tmpGoodsRelationKucun_1 b
where a.cGoodsNo=b.cGoodsNo ---and a.cSupplierNo=b.cSupNo
 

 
 if (select OBJECT_ID('tempdb..#temp_wh_SumUnionGoods'))is not null  
drop table #temp_wh_SumUnionGoods
select BeginDate=@dDate1,EndDate=@dDate2,cGoodsTypeno,cGoodsTypename,a.cGoodsNo,cGoodsName,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
    fQty_left=SUM(期末库存),
	fprice_left=case when ISNULL(sum(期末库存),0)<>0 then sum(fmoney_left)/sum(期末库存) else 0 end,fmoney_left=SUM(fmoney_left),
	期初库存=SUM(期初库存),期末库存=SUM(期末库存),fML=SUM(fML),fMoney_Cost=SUM(fMoney_Cost), 
	销售数量=SUM(xsQty),销售金额=SUM(xsMoney),
	特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),
	会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=SUM(会员来客数),来客数=SUM(来客数)	,
	当前库存=CAST(0 as money),当前库存金额=CAST(0 as money),在途数量=CAST(0 as money),
	库存状态=CAST(null as varchar(32)),应销未订货=CAST(null as varchar(32)),畅销状态=CAST(null as varchar(32)),
    毛利状态=CAST(null as varchar(32)),可销天数=CAST(null as money),会员销售占比=CAST(null as varchar(32)),
    商品状态=CAST(null as varchar(32)),最后销售日=CAST(null as varchar(32)),
    上月销售金额=CAST(null as money),上月销售数量=CAST(null as money),上月成本金额=CAST(null as money) 
	into #temp_wh_SumUnionGoods
	from #temp_goodsKuCun a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo 
    group by  cGoodsTypeno,cGoodsTypename , 
    cGoodsTypeno,cGoodsTypename,a.cGoodsNo,cGoodsName,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice
       
-----------获取当前库存-------------
if (select OBJECT_ID('tempdb..#temp_goodsKuCurQty'))is not null  drop table #temp_goodsKuCurQty
create table #temp_goodsKuCurQty(cGoodsNo varchar(32), EndQty money, Endmoney money)
declare @dDate date
set @dDate=CONVERT (date, GETDATE())

 exec [P_x_SetCheckWh_byGoodsType_logCurQty] @dDate,@dDate,@cWhno  

--print dbo.getTimeStr(GETDATE())
--print 5
 
CREATE INDEX IX_temp_goodsKuCurQty  ON #temp_goodsKuCurQty(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_goodsKuCurQtySup'))is not null  drop table #temp_goodsKuCurQtySup
select a.cGoodsNo,a.EndQty,a.Endmoney,b.cSupNo into #temp_goodsKuCurQtySup from #temp_goodsKuCurQty  a,t_Goods b
where a.cGoodsNo=b.cGoodsNo   --- 28585
 
insert into #temp_wh_SumUnionGoods(BeginDate,EndDate,cGoodsTypeno,cGoodsTypename,cGoodsNo,cGoodsName,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice)
select @dDateBgn,@dDateEnd,a1.cGoodsTypeno,a1.cGoodsTypename,a1.cGoodsNo,a1.cGoodsName,a1.cSpec,a1.cUnit,a1.cSupNo,a1.cSupName,a1.fNormalPrice,a1.fCKPrice from t_Goods a1,(
select b.cGoodsNo,b.EndQty,b.Endmoney from #temp_wh_SumUnionGoods  a right join #temp_goodsKuCurQtySup b on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
where ISNULL(a.cGoodsNo,'')='') b1
where a1.cGoodsNo=b1.cGoodsNo

---------获取上个月的正月销售
if (select object_id('tempdb..#temp_GetLastMonthSale_wei')) is not null
drop table #temp_GetLastMonthSale_wei
create table #temp_GetLastMonthSale_wei(cgoodsno varchar(32),[cWHno] varchar(32),xsQty money,xsMoney money,fmoney_cost money)
declare @ddatebgn1 datetime
declare @lastBgn1 datetime
declare @lastEnd1 datetime
set @ddatebgn1=CAST((cast(YEAR(@dDateBgn) as varchar(16))+'-'+cast(MONTH(@dDateBgn) as varchar(16))+'-01') AS DATETIME)
set @lastBgn1=DATEADD(MONTH,-1,@ddatebgn1)
set @lastEnd1=DATEADD(DAY,-1,@ddatebgn1) 

declare @day int
set @day=DATEDIFF (DAY,@lastBgn1,@lastEnd1)+1

--  print '13002    '+dbo.getTimeStr(GETDATE())

exec p_GetLastMonthSale_wei @lastBgn1,@lastEnd1,@cWHno,@cdbname

 -- print '13003    '+dbo.getTimeStr(GETDATE())

update a
set a.上月销售数量=b.xsQty,a.上月销售金额=b.xsMoney,上月成本金额=b.fmoney_cost
from #temp_wh_SumUnionGoods a,#temp_GetLastMonthSale_wei b
where a.cGoodsNo=b.cgoodsno

/*
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月销售数量,0)<>0 
then ISNULL(b.EndQty,0)*@day/ISNULL(a.上月销售数量,0) 
else case when ISNULL(a.上月销售数量,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_wh_SumUnionGoods a left join #temp_goodsKuCurQtySup b
on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo

*/
update a
set a.当前库存=b.EndQty,a.当前库存金额=b.Endmoney,
a.可销天数=case when ISNULL(a.上月成本金额,0)<>0 
then ISNULL(b.Endmoney,0)*@day/ISNULL(a.上月成本金额,0) 
else case when ISNULL(a.上月成本金额,0)=0 then case when isnull(b.EndQty,0)=0 then 0 else 99999 end end end,
a.毛利状态=case when ISNULL(a.fml,0)<0 then '负毛利' else case when ISNULL(a.fml,0)=0 then '零毛利' else '正常' end end
from #temp_wh_SumUnionGoods a left join #temp_goodsKuCurQtySup b
on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo




update #temp_wh_SumUnionGoods
set 畅销状态='畅销商品',库存状态='低库存',商品状态='正常'
where 可销天数>=0 and 可销天数<=5

update #temp_wh_SumUnionGoods
set 畅销状态='一般商品',库存状态='正常',商品状态='正常'
where 可销天数>5 and 可销天数<=20

update #temp_wh_SumUnionGoods
set 畅销状态='滞销商品',库存状态='高库存',商品状态='正常'
where 可销天数>20

update #temp_wh_SumUnionGoods
set  库存状态='零库存',商品状态='待进货',畅销状态='一般商品'
where 当前库存=0

update #temp_wh_SumUnionGoods
set 商品状态='待进货',库存状态='负库存',畅销状态='一般商品'
where 当前库存<0



  ---------取出大包装  
if (select object_id('tempdb..#temp_MaxPackGoods')) is not null
drop table #temp_MaxPackGoods
select a.cGoodsNo,cGoodsNo_minPackage,fQty_minPackage into #temp_MaxPackGoods 
from t_Goods a,#temp_WhFromGoods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(a.cGoodsNo_minPackage,'')<>''

if (select object_id('tempdb..#tmp_GoodsSale30'))is not null drop table #tmp_GoodsSale30
select a.cGoodsNo,dSaleDate=a.last_SaleDate into #tmp_GoodsSale30 
from t_GetGoods_InOut a,#temp_WhFromGoods b
with (nolock) 
where a.cgoodsno=b.cgoodsno

insert into #tmp_GoodsSale30(cgoodsno,dSaleDate)
select b.cGoodsNo_minPackage,a.dSaleDate from #tmp_GoodsSale30 a,#temp_MaxPackGoods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''


if (select object_id('tempdb..#tmp_MaxGoodsSale30'))is not null drop table #tmp_MaxGoodsSale30
select dSaleDate=MAX(dSaleDate),cGoodsNo
into #tmp_MaxGoodsSale30
from #tmp_GoodsSale30
group by cGoodsNo

CREATE INDEX IX_temp_MaxGoodsSale30  ON #tmp_MaxGoodsSale30(cGoodsNo)

--print dbo.getTimeStr(GETDATE())
--print 9

 
update a
set  a.最后销售日=b.dSaleDate
from #temp_wh_SumUnionGoods a,#tmp_MaxGoodsSale30 b
where a.cGoodsNo=b.cGoodsNo



--------修改会员情况 

update a 
set  
a.会员销售数量=isnull(b.会员销售数量,0),
a.会员销售金额=isnull(b.会员销售金额,0),
a.会员来客数=b.会员来客数,
a.来客数=b.来客数
from #temp_wh_SumUnionGoods a,#temp_WhFromendVIP b
where a.cGoodsNo=b.cGoodsNo  
 

--------修改会员情况
update a 
set  
a.会员销售数量=isnull(b.会员销售数量,0),
a.会员销售金额=isnull(b.会员销售金额,0),
a.会员来客数=b.会员来客数,
a.来客数=b.来客数
from #temp_wh_SumUnionGoods a,#temp_WhKouDianEndVIP b
where a.cGoodsNo=b.cGoodsNo  
 
 
if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
drop table #temp_GetKuCunMaoli_wei

Create Table #temp_GetKuCunMaoli_wei (
cGoodsNo varchar(32),cgoodsname varchar(64),cSpec  varchar(32),cUnit varchar(32),
iLine bigint IDENTITY(1,1) NOT NULL,
csupno varchar(32),cSupName varchar(64),
fNormalPrice money,fCKPrice money,cGoodsTypeno varchar(32),cGoodsTypename varchar(32),
销售数量 money,销售金额 money,特价销售数量 money,特价销售金额 money,正价销售数量 money,正价销售金额 money,
fMoney_cost money,fml money,fPrice_Avg money,期初库存 money,期末库存 money,
当前库存 money,当前库存金额 money,在途数量 money,会员销售数量 money,会员销售金额 money,会员来客数 money,
来客数 money,库存状态 varchar(32),畅销状态 varchar(32),毛利状态 varchar(32),可销天数 money,会员销售占比 money,商品状态 varchar(32),
最后销售日 varchar(32))
 
if  (select object_id('tempdb..#temp_GetKuCunMaoli_wei')) is not null
begin
    insert into #temp_GetKuCunMaoli_wei(cGoodsNo,cgoodsname,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
	cGoodsTypeno,cGoodsTypename,
	销售数量,销售金额,特价销售数量,特价销售金额,正价销售数量,正价销售金额,fMoney_cost,fml,fPrice_Avg,期初库存,期末库存,
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,会员销售占比,商品状态,最后销售日)
	select  cGoodsNo,cgoodsname,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
	cGoodsTypeno,cGoodsTypename, 
	销售数量=isnull(销售数量,0),销售金额=isnull(销售金额,0),
	特价销售数量,特价销售金额,正价销售数量,正价销售金额, 
	fMoney_Cost,fML,fPrice_Avg=case when isnull(销售数量,0)<>0 then fMoney_Cost/isnull(销售数量,0) else 0 end,
	期初库存,期末库存,	
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,
	会员销售占比=case when isnull(销售金额,0)<>0 then (会员销售金额/销售金额)*100 else 0 end,商品状态,
	最后销售日=ISNULL(CONVERT(VARCHAR(100),最后销售日,23),'30日内未销售')
	from #temp_wh_SumUnionGoods
	where isnull(销售金额,0)<>0
    --order by cGoodsTypeno,销售金额 desc
    
    
    if  (select object_id('tempdb..#temp_GetMinLine')) is not null
    drop table #temp_GetMinLine
	select cGoodsTypeno,iLine=MIN(iLine) into #temp_GetMinLine from #temp_GetKuCunMaoli_wei
	group by cGoodsTypeno
	
   exec('
  if (select object_id(''U_key.dbo.s_'+@Key+'''))is not null 
  drop table U_key.dbo.s_'+@Key+'

		  select iLine=a.iLine-b.iLine+1,a.cGoodsNo,a.cgoodsname,a.cSpec,a.cUnit,a.csupno,a.cSupName,a.fNormalPrice,a.fCKPrice,
	a.cGoodsTypeno,a.cGoodsTypename,
	a.销售数量,a.销售金额,a.特价销售数量,a.特价销售金额,a.正价销售数量,a.正价销售金额,a.fMoney_cost,a.fml,a.fPrice_Avg,a.期初库存,a.期末库存,
	a.当前库存,a.当前库存金额,a.在途数量,a.会员销售数量,a.会员销售金额,a.会员来客数,
	a.来客数,a.库存状态,a.畅销状态,a.毛利状态,a.可销天数,a.会员销售占比,a.商品状态,a.最后销售日 
	into U_key.dbo.s_'+@Key+'
	from 
	#temp_GetKuCunMaoli_wei a,#temp_GetMinLine b
	where a.cGoodsTypeno=b.cGoodsTypeno and a.iLine between b.iLine and b.iLine+20-1
	union all
	 select iLine=999999,cGoodsNo=''合计:'',cgoodsname=null,cSpec=null,cUnit=null,csupno=null,cSupName=null,fNormalPrice=null,fCKPrice=null,
	cGoodsTypeno=null,cGoodsTypename=null,
	销售数量=SUM(a.销售数量),销售金额=SUM(a.销售金额),特价销售数量=SUM(a.特价销售数量),特价销售金额=SUM(a.特价销售金额),
    正价销售数量=SUM(a.正价销售数量),正价销售金额=SUM(a.正价销售金额),fMoney_cost=SUM(a.fMoney_cost),fml=SUM(a.fml),
    fPrice_Avg=null,期初库存=SUM(a.期初库存),期末库存=SUM(a.期末库存),
    当前库存=SUM(a.当前库存),当前库存金额=SUM(a.当前库存金额),在途数量=SUM(a.在途数量),会员销售数量=SUM(a.会员销售数量),会员销售金额=SUM(a.会员销售金额),会员来客数=sum(a.会员来客数),
    来客数=SUM(a.来客数),库存状态=null,畅销状态=null,毛利状态=null,可销天数=null,会员销售占比=case when SUM(a.销售金额)<>0 then (sum(a.会员销售金额)/sum(a.销售金额))*100 else 0 end,商品状态=null,最后销售日=null
	from 
	#temp_GetKuCunMaoli_wei a,#temp_GetMinLine b
	where a.cGoodsTypeno=b.cGoodsTypeno and a.iLine between b.iLine and b.iLine+20-1
	 
   ')
    
end else
begin	
select  cGoodsNo,cgoodsname,cSpec,cUnit,csupno,cSupName,fNormalPrice,fCKPrice,
	cGoodsTypeno,cGoodsTypename, 
	销售数量=isnull(销售数量,0),销售金额=isnull(销售金额,0),
	特价销售数量,特价销售金额,正价销售数量,正价销售金额, 
	fMoney_Cost,fML,fPrice_Avg=case when isnull(销售数量,0)<>0 then fMoney_Cost/isnull(销售数量,0) else 0 end,
	期初库存,期末库存,	
	当前库存,当前库存金额,在途数量,会员销售数量,会员销售金额,会员来客数,
	来客数,库存状态,畅销状态,毛利状态,可销天数,
	会员销售占比=case when isnull(销售金额,0)<>0 then (会员销售金额/销售金额)*100 else 0 end,商品状态,
	最后销售日=ISNULL(CONVERT(VARCHAR(100),最后销售日,23),'30日内未销售')
	from #temp_wh_SumUnionGoods
	union all
	select  cGoodsNo='合计：',cgoodsname=null,cSpec=null,cUnit=null,csupno=null,cSupName=null,fNormalPrice=null,fCKPrice=null,
	cGoodsTypeno=null,cGoodsTypename=null,
	销售数量=SUM(销售数量),销售金额=SUM(销售金额),特价销售数量=SUM(特价销售数量),特价销售金额=SUM(特价销售金额),
	正价销售数量=SUM(正价销售数量),正价销售金额=SUM(正价销售金额),fMoney_cost=SUM(fMoney_cost),fml=SUM(fml),
	 fPrice_Avg=null,期初库存=SUM(期初库存),期末库存=SUM(期末库存),
	当前库存=SUM(当前库存),当前库存金额=SUM(当前库存金额),在途数量=SUM(在途数量),
	会员销售数量=SUM(会员销售数量),会员销售金额=SUM(会员销售金额),会员来客数=sum(会员来客数),
	来客数=SUM(来客数),库存状态=null,畅销状态=null,毛利状态=null,可销天数=null,
	会员销售占比=case when SUM(销售金额)<>0 then (sum(会员销售金额)/sum(销售金额))*100 else 0 end,商品状态=null,
	最后销售日=null from #temp_wh_SumUnionGoods 
    order by cGoodsNo
end 
 
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	   if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	    if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	    if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
        if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  drop table #temp_wh_DiffPriceWarehouseDetail
		  if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null   drop table #temp_wh_DiffPricecGoodsNo

GO
