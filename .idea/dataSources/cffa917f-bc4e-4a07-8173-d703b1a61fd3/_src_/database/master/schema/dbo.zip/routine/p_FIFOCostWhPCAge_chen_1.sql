

create proc [dbo].[p_FIFOCostWhPCAge_chen_1]
@dDate datetime,
@cWhNo varchar(32),
@Type int --0:按商品列表查，1：商品类别 2：供应商
as
--declare @dDate datetime
--declare @Type int
--  set @dDate='2009-11-24'
--set @Type=0

if (select object_id('tempdb..#tmpLeftZeroQty'))is not null
drop table #tmpLeftZeroQty
if (select object_id('tempdb..#tmp_TWhForm0'))is not null
drop table #tmp_TWhForm0
if (select object_id('tempdb..#tmp_TWhForm1'))is not null
drop table #tmp_TWhForm1
if (select object_id('tempdb..#t_WH_Form0'))is not null
drop table #t_WH_Form0
if (select object_id('tempdb..#t_WH_Form'))is not null
drop table #t_WH_Form
if (select object_id('tempdb..#tmp_TWhForm0'))is not null
drop table #tmp_TWhForm0
if (select object_id('tempdb..#tmpLeftZeroQty0'))is not null
drop table #tmpLeftZeroQty0

select a.cGoodsNo,b.cGoodsName,a.dDateTime,a.cSheetNo,iSerno=a.iSerno,a.iLineNo,a.cSummary,
--select a.cGoodsNo,b.cGoodsName,a.dDateTime,a.cSheetNo,iSerno=a.iMyIdentity,a.iLineNo,a.cSummary,
a.fPrice_In,a.fQty_In,a.fMoney_In,a.fPrice_Out,a.fQty_Out,a.fMoney_Out,
a.fQty_Left,a.fPrice_Left,a.fMoney_Left,a.cWhNo,a.bJiecun,a.dJiecunDate,
a.cSupplierNo,a.cSupplier,a.cReason,a.iAttribute,
b.cUnit,b.cspec,b.cGoodsTypeNO,b.cGoodsTypeName,b.pinpaino,b.pinpai,
bStorage=isnull(b.bStorage,0),bPiCi=isnull(b.bPiCi,0)
into #t_WH_Form
from T_wh_form a , t_goods b

where a.cGoodsNo=b.cGoodsNo and
(
     ( 
        ( @Type=0 )and a.cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)
      )
      or
     ( 
        (@Type=1)and b.cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
     )
     or
     ( 
        (@Type=2)and a.cSupplierNo in(select distinct cSupNo from #tmpCostSupList)
     )
) and a.dDateTime<=@dDate
and a.cWhNo=@cWhNo

--select * from #t_WH_Form0
/*
select *
into #t_WH_Form
from #t_WH_Form0
where ( 
        ( @Type=0 )and cGoodsNo in(select distinct cGoodsNo from #tmpCostGoodsList)
      )
      or
     ( 
        (@Type=1)and cGoodsTypeNO in(select distinct cTypeNo from #tmpCostTypeList)
     )
     or
     ( 
        (@Type=2)and cSupplierNo in(select distinct cSupNo from #tmpCostSupList)
     )
*/

--入库单
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
into #tmp_TWhForm0
from #t_WH_Form a left join wh_InWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo
where  a.dDateTime<=@dDate and a.iAttribute=0 --and c.dProduct is not null
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,--调拨入库单
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
from #t_WH_Form a left join wh_TfrInWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo
where  a.dDateTime<=@dDate and a.iAttribute=31 --and c.dProduct is not null

union all --报溢单
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
from #t_WH_Form a left join wh_EffusionWhDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where  a.dDateTime<=@dDate and a.iAttribute=6 --and c.dProduct is not null
union all --客退单
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
from #t_WH_Form a left join WH_ReturnGoodsDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where  a.dDateTime<=@dDate  and a.iAttribute=3 --and c.dProduct is not null
union all--盘点溢出单
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=null,
dTimes=null,dOverdueDate=null,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=null,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
from #t_WH_Form a left join t_CheckTast_GoodsDetail c
on a.cSheetNo=c.cCheckTaskNo and a.iLineNo=0
and a.cGoodsNo=c.cGoodsNo 
where  a.dDateTime<=@dDate 
and a.iLineNo=0 and a.iAttribute in(11,12)
union all --成品入库
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(0 as bit)
from #t_WH_Form a left join wh_DivideWhDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where  a.dDateTime<=@dDate  and a.iAttribute=9 --and c.dProduct is not null

--以下是补充商品
--出库单(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a left join wh_OutWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where a.iAttribute=1 and isnull(a.fQty_in,0)=0 and a.dDateTime<=@dDate --and c.dProduct is not null

--返厂单(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a left join wh_RbdWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where a.iAttribute=2 and isnull(a.fQty_in,0)=0 and a.dDateTime<=@dDate --and c.dProduct is not null

--调拨单(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a left join wh_TfrWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where a.iAttribute=4 and isnull(a.fQty_in,0)=0 and a.dDateTime<=@dDate --and c.dProduct is not null

--报损单(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a left join wh_LossWarehouseDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where a.iAttribute=5 and isnull(a.fQty_in,0)=0 and a.dDateTime<=@dDate --and c.dProduct is not null

--原料出库(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=c.dProduct,
dTimes=c.fTimes,dOverdueDate=case when c.dProduct is not null then dateadd(dd,isnull(c.fTimes,0),c.dProduct) else null end,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=case when (isnull(fQty_in,0)>isnull(fQty_Out,0))and(c.dProduct is not null) then datediff(dd,@dDate, dateadd(dd,isnull(c.fTimes,0),c.dProduct) )
                 else null end,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a left join wh_PackDetail c
on a.cSheetNo=c.cSheetNo and a.iLineNo=c.iLineNo
and a.cGoodsNo=c.cGoodsNo 
where a.iAttribute=8 and isnull(a.fQty_in,0)=0 and a.dDateTime<=@dDate --and c.dProduct is not null

--日结(补充)
union all
select a.cGoodsNo,a.cGoodsName,a.iSerNo,a.cUnit,a.cspec,a.cGoodsTypeNO,a.cGoodsTypeName,
a.pinpaino,a.pinpai,a.bStorage,a.bPiCi,a.cSupplierNo,a.cSupplier,a.iAttribute,
a.cSheetNo,a.iLineNo,a.cSummary,a.fPrice_in,a.fQty_in,a.fMoney_in,
a.fPrice_Out,a.fQty_Out,a.fMoney_Out,a.fPrice_Left,a.fQty_Left,a.fMoney_Left,
a.dDateTime,dProductDate=null,
dTimes=null,dOverdueDate=null,
fWHAge=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then datediff(dd,a.dDateTime,@dDate)
                 else null end,
fRemainDays=null,
dZeroNumDate=cast(null as datetime),
bZeroNum=case when isnull(fQty_in,0)>isnull(fQty_Out,0) then 0 else 1 end,
a.cWhNo,bUpdate=cast(1 as bit)
from #t_WH_Form a 
where a.iAttribute in(10,13) and a.dDateTime<=@dDate
order by a.cGoodsNo

/*
select distinct cGoodsNo,iserNo=min(iSerNo)
into #tmpLeftZeroQty0
from t_Cost_distribute
where fQty<=fQty_Cost
and cWhNo=@cWhNo
and iserNo in(select distinct iSerNo from #t_wh_form)
group by cGoodsNo

select distinct a.cGoodsNo,a.iserNo,a.iAttribute,a.cSheetNo,a.fQty,a.fQty_cost,a.iLineNo,a.dDate_Sheet
into #tmpLeftZeroQty
from t_Cost_distribute a,#tmpLeftZeroQty0 b
where a.cGoodsNo=b.cGoodsNo and a.iSerNo=b.iSerNo
and a.cWhNo=@cWhNo

update a
set a.dZeroNumDate=b.dDate_Sheet,
a.fWHAge=datediff(dd,a.dDateTime,b.dDate_Sheet)
from #tmp_TWhForm0 a,#tmpLeftZeroQty b
where a.cGoodsNo=b.cGoodsNo and a.iserNo=b.iSerNo and isnull(a.bZeroNum,0)=1
*/

update #tmp_TWhForm0
set dZeroNumDate=dDateTime,fWHAge=0
where isnull(fQty_left,0)<=0 and  isnull(bZeroNum,0)=1
and dZeroNumDate is null

select cGoodsNo,cGoodsName,iSerNo,cUnit,cspec,cGoodsTypeNO,cGoodsTypeName,
pinpaino,pinpai,bStorage,bPiCi,cSupplierNo,cSupplier,iAttribute,
cSheetNo,iLineNo,cSummary,fPrice_in,fQty_in,fMoney_in,
fPrice_Out,fQty_Out,fMoney_Out,fPrice_Left,fQty_Left,fMoney_Left,
dDateTime,dProductDate,dTimes,dOverdueDate,fWHAge,
fRemainDays,dZeroNumDate,bZeroNum,cWhNo,iLineIdNo=0,bUpdate
from #tmp_TWhForm0
union all
select cGoodsNo,cGoodsName='小计:',iSerNo=null,cUnit=null,cspec=null,cGoodsTypeNO=null,cGoodsTypeName=null,
pinpaino=null,pinpai=null,bStorage=null,bPiCi=null,cSupplierNo=null,cSupplier=null,iAttribute=-99,
cSheetNo=null,iLineNo=null,cSummary=null,fPrice_in=null,fQty_in=sum(fQty_in),fMoney_in=sum(fMoney_in),
fPrice_Out=null,fQty_Out=sum(fQty_Out),fMoney_Out=sum(fMoney_Out),
fPrice_Left=null,fQty_Left=sum(fQty_Left),fMoney_Left=sum(fMoney_Left),
dDateTime=null,dProductDate=null,dTimes=null,dOverdueDate=null,fWHAge=null,
fRemainDays=null,dZeroNumDate=null,bZeroNum=null,cWhNo=null,iLineIdNo=9,bUpdate=cast(0 as bit)
from #tmp_TWhForm0
group by cGoodsNo
order by cGoodsNo,iLineIdNo,iSerno
GO
