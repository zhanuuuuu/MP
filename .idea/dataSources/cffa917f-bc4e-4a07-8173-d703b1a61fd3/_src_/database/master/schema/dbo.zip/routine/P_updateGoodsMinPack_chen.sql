
/*
declare @i int
exec P_updateGoodsMinPack_chen '31814','31754',24.00,'','',@i output
select @i
*/
CREATE proc [dbo].[P_updateGoodsMinPack_chen]
@cGoodsNO varchar(32),
@cGoodsNo_min varchar(32),
@fQty_min money,
@cOperNo varchar(32),
@cOperName varchar(32),
@Ret int output
as

if isnull(@fQty_min,0)=0
begin
  set @Ret=-1
  return
end
if isnull(@cGoodsNO,'')=''
begin
  set @Ret=-1
  return
end
if isnull(@cGoodsNo_min,'')=''
begin
  set @Ret=-1
  return
end

begin try
  begin tran

    update t_goods
    set cGoodsNo_minpackage=cGoodsNo_minpackage_tmp
    where cGoodsNo=@cGoodsNO
    
    update a
    set cGoodsNo_minpackage=b.cGoodsNo_minpackage_tmp,
    a.cGoodsNo_minPackage_tmp=b.cGoodsNo_minPackage_tmp,
    a.fQty_minPackage=b.fQty_minPackage
    from t_cStoreGoods a,t_Goods b
    where a.cGoodsNo=b.cGoodsNo and b.cGoodsNo=@cGoodsNO

	if exists
	(
		  select cGoodsNo 
		  from t_wh_form_log 
		  where cGoodsNo=@cGoodsNO
	)
	begin
 
		 declare @PosWhName varchar(32)
       select @PosWhName=Pos_WH_Form from t_WareHouse where bMainSale=1
       
       declare @fRatio money
       set @fRatio=0
        select @fRatio=fRatio from t_Goods
        where cGoodsNo=@cGoodsNo_min
        
        declare @fHeTRatio money
        set @fHeTRatio=0
		select @fHeTRatio=a.fRatio from 
		t_Supplier_Contract_Ratio a,t_Goods b
        where a.guizuno=b.cSupNo and  b.cGoodsNo=@cGoodsNo_min
        
		
		update t_wh_form_log
		set fPrice_in=fPrice_in/@fQty_min,fQty_in=fQty_in*@fQty_min,
			fPrice_out=fPrice_out/@fQty_min,fQty_Out=fQty_Out*@fQty_min,
			fPrice_Left=fPrice_Left/@fQty_min,fQty_Left= fQty_Left*@fQty_min,
			cGoodsNo=@cGoodsNo_min,
			入库数量1=入库数量1*@fQty_min,报溢数量1=报溢数量1*@fQty_min,
			退货入库数量1=退货入库数量1*@fQty_min,调拨入库数量1=调拨入库数量1*@fQty_min,
			出库数量0=出库数量0*@fQty_min,报损数量0=报损数量0*@fQty_min,
			返厂数量0=返厂数量0*@fQty_min,调拨出库数量0=调拨出库数量0*@fQty_min,
			差价数量=差价数量*@fQty_min,原料出库数量0=原料出库数量0*@fQty_min,
			成品入库数量1=成品入库数量1*@fQty_min,
			销售数量0=销售数量0*@fQty_min,特价销售数量=特价销售数量*@fQty_min,
			正价销售数量=正价销售数量*@fQty_min,
			本日库存数量=本日库存数量*@fQty_min,
			盘点数量=盘点数量*@fQty_min,盘点单价=盘点单价/@fQty_min,
			当日特价销售数量=当日特价销售数量*@fQty_min,
			当日正价销售数量=当日正价销售数量*@fQty_min,
			合同扣率=0,
		    单品扣率=0,
		    特价扣率=0
		where cGoodsNO=@cGoodsNO
		/*修改中转服务器上的t_wh_form_log*/
	end

  
   declare @cGoodsName varchar(100)
   declare @cGoodsName_min varchar(100)
   select @cGoodsName=cGoodsName 
   from t_goods
   where cGoodsNO=@cGoodsNO
   select @cGoodsName_min=cGoodsName 
   from t_goods
   where cGoodsNO=@cGoodsNo_min
    
    insert into dbo.T_GoodsMinPackUpdateHis
    (
      dDate, cTime,cGoodsNo, cGoodsName, cGoodsNO_min, cGoodsName_min, 
      cOperNO, cOperName
    )
    values
    (
      convert(varchar(100),getdate(),23),convert(varchar(100),getdate(),108),@cGoodsNO,@cGoodsName,@cGoodsNo_min,@cGoodsName_min,
      @cOperNo,@cOperName
    )
  commit tran
  ---- 事物不支持... 远程修改..
  -- exec p_UpdateGoodsMinQty_wei @PosWhName,@fQty_min,@cGoodsNo_min,@cGoodsNO,@fHeTRatio,@fRatio
   set @Ret=1
  
end try
begin catch
  rollback tran
  set @Ret=-2
  select ERROR_MESSAGE()
end catch

GO
