


/*
select * into #tempGoodsSupplier from dbo.f_Goods_GoodsType_Supplier()


if  (select object_id('tempdb..#tempPeriodList')) is not null
 drop table #tempPeriodList
select cPeriodNo=cPeriodBelongNo,cPeriodName=cPeriodBelongName,
dDate1,dDate2,cPeriodBelongNo,iHolidays,fRight,iDays,bBaseCompare 
into #tempPeriodList
 from  t_PeriodDefine_Belong 
where cPeriodBelongNo=001
union all
select cPeriodNo,cPeriodName,dDate1,dDate2,cPeriodBelongNo,iHolidays,fRight,iDays,bBaseCompare 
 from  t_PeriodDefine 
where cPeriodBelongNo='001'

select cGoodsTypeNo  into #tempSelectedGoodsType from dbo.t_GoodsType

exec p_CompareByPeriod_GoodsType

drop table #tempSelectedGoodsType


drop table	#tempGoodsSupplier

*/







CREATE procedure [dbo].[p_CompareByPeriod_All]
as
begin

	create table #Temp_Period
	(
		cYear varchar(32),cYearEnd varchar(64),iSerno int identity,
		dDate1 datetime,dDate2 datetime,iHolidays int,fRight int,iDays int ,bBaseCompare bit
	)
	insert into #Temp_Period
	(
	 cYear,cYearEnd,dDate1,dDate2,iHolidays,fRight,iDays,bBaseCompare
	)
	select cYear=cPeriodBelongNo,cYearEnd=cPeriodName,dDate1,dDate2,iHolidays,fRight,iDays,bBaseCompare
	from #tempPeriodList
	order by	bBaseCompare,dDate1,dDate2 desc 

	declare @cYear char(4)
	set @cYear=(select top 1 cYear from #Temp_Period)

	select cYear,cYearEnd,cMonth=dbo.trim(cast(iSerno as char(4))) ,dDate1,dDate2,iHolidays,fRight,iDays,bBaseCompare
	into #tempWeekOfMonth_Finance
	from #Temp_Period
	order by iSerno

  
  declare @cMonth char(2)
  declare	@cYear_prior char(4)
  declare	@cMonth_prior char(2)
  declare	@dDate1_prior datetime
  declare	@dDate2_prior datetime
  declare	@dDate1_now datetime
  declare	@dDate2_now datetime

	set @cYear_prior=@cYear
	set @cMonth_prior='1'

  
	select @dDate1_prior=min(dDate1),@dDate2_prior=max(dDate2)
	from #tempWeekOfMonth_Finance
	where cYear=@cYear_prior and cMonth=@cMonth_prior

	select @dDate1_now=min(dDate1),@dDate2_now=max(dDate2)
	from #tempWeekOfMonth_Finance



	select cYear,cYearEnd,cMonth,dDate1,dDate2,iHolidays,fRight,iDays,
				 fRight_now=isnull(fRight,0)*isnull(iDays,0)*(1+isnull(iHolidays,0))
	into #tempWeekOfMonth_Finance_prior 
	from #tempWeekOfMonth_Finance
	where cYear=@cYear_prior and cMonth=@cMonth_prior

	declare @fSales_prior money--上月销售
	declare @fProfits_prior money--上月毛利

	declare @fRight_Prior money--上月加权系数
	declare @fRight_now money--本月加权系数
	declare @fRight_Hope money--本月指标系数@fRight_now/@fRight_Prior

/*
  select @fRight_Prior=fRight_now
	from #tempWeekOfMonth_Finance_prior


	select a.dSaleDate,a.iSeed,a.cGoodsNo,a.bAuditing,a.fQuantity,a.fLastSettle,a.fCostPrice,a.cCooperate,
					b.cYear,b.cYearEnd,b.cMonth,iWeekNo=null,b.fRight,b.iDays,b.iHolidays,iDw=dbo.f_GetDayOfWeek(a.dSaleDate),
					dw=datename(dw,a.dSaleDate)
	into #tempSalesFinance_Prior
	from  dbo.t_SaleSheet_Day  a ,#tempWeekOfMonth_Finance_prior b
--	from dbo.t_SaleSheet_Day a,#tempWeekOfMonth_Finance_prior b
	where  a.dSaleDate between b.dDate1 and b.dDate2 
	create index idx_cGoodsNo on #tempSalesFinance_Prior(cGoodsNo)

	select a.dSaleDate,a.iSeed,a.cGoodsNo,a.bAuditing,a.fQuantity,a.fLastSettle,a.fCostPrice,a.cCooperate,
				 a.cYear,a.cYearEnd,a.cMonth,a.iWeekNo,a.fRight,a.iDays,a.iHolidays,a.iDw,a.dw,b.cGoodsTypeno,b.cGoodsTypename,
				 b.cSupNo,b.cSupName,fProfitsRatio=cast(0.00 as money),fProfits=cast(0.00 as money),
				 bPrior=0
	into #tempSalesFinance_supplier_type_Prior
  from  #tempSalesFinance_Prior a left join #tempGoodsSupplier b on a.cGoodsNo=b.cGoodsNo
	create index idx_cGoodsNo on #tempSalesFinance_supplier_type_Prior(cGoodsNo,dSaleDate)

	drop table #tempSalesFinance_Prior

	update a set a.fProfitsRatio=b.fProfitsRatio
	from #tempSalesFinance_supplier_type_Prior a ,dbo.t_Goods_PRatio b
	where isnull(a.bAuditing,0)=0
  and a.cGoodsNo=b.cGoodsNo and a.dSaleDate=b.dDate

	update a set a.fProfitsRatio=b.fSupRatio
	from #tempSalesFinance_supplier_type_Prior a , dbo.t_PloyOfSale b
	where a.bAuditing=1 and a.cGoodsNo=b.cGoodsNo and a.dSaleDate between dDateStart and dDateEnd

	update a set a.fProfits=round(a.fLastSettle*a.fProfitsRatio/100.00,2)
	from #tempSalesFinance_supplier_type_Prior a 

*/
 	
	select a.dSaleDate,a.iSeed,a.cGoodsNo,a.bAuditing,a.fQuantity,a.fLastSettle,a.fCostPrice,a.cCooperate,
					b.cYear,b.cYearEnd,b.cMonth,iWeekNo=null,b.fRight,b.iDays,b.iHolidays,iDw=dbo.f_GetDayOfWeek(a.dSaleDate),
					dw=datename(dw,a.dSaleDate)
	into #tempSalesFinance
	from   dbo.t_SaleSheet_Day  a ,#tempWeekOfMonth_Finance b
--	from dbo.t_SaleSheet_Day a,#tempWeekOfMonth_Finance b
	where (a.dSaleDate between @dDate1_now and @dDate2_now) and  (a.dSaleDate between b.dDate1 and b.dDate2) 
	create index idx_cGoodsNo on #tempSalesFinance(cGoodsNo)

	select a.dSaleDate,a.iSeed,a.cGoodsNo,a.bAuditing,a.fQuantity,a.fLastSettle,a.fCostPrice,a.cCooperate,
				 a.cYear,a.cYearEnd,a.cMonth,a.iWeekNo,a.fRight,a.iDays,a.iHolidays,a.iDw,a.dw,b.cGoodsTypeno,b.cGoodsTypename,
				 b.cSupNo,b.cSupName,fProfitsRatio=cast(0.00 as money),fProfits=cast(0.00 as money),
				 bPrior=0
	into #tempSalesFinance_supplier_type
  from  #tempSalesFinance a left join #tempGoodsSupplier b on a.cGoodsNo=b.cGoodsNo
	create index idx_cGoodsNo_dSaleleDate on #tempSalesFinance_supplier_type(cGoodsNo,dSaleDate)

/*
	update a set a.fProfitsRatio=b.fProfitsRatio
	from #tempSalesFinance_supplier_type a ,dbo.t_Goods_PRatio b
	where isnull(a.bAuditing,0)=0
  and a.dSaleDate=b.dDate and a.cGoodsNo=b.cGoodsNo 
*/
	update a set a.fProfitsRatio=
	case when isnull(a.fLastSettle,0)<>0 then (a.fLastSettle-a.fCostPrice)/isnull(a.fLastSettle,0)
			 else 0
	end
	from dbo.#tempSalesFinance_supplier_type a 
	where isnull(a.bAuditing,0)=0

	update a set a.fProfitsRatio=b.fSupRatio
	from #tempSalesFinance_supplier_type a , dbo.t_PloyOfSale b
	where a.bAuditing=1 and a.cGoodsNo=b.cGoodsNo and a.dSaleDate between b.dDateStart and b.dDateEnd

	update a set a.fProfits=round(a.fLastSettle*a.fProfitsRatio/100.00,2)
	from #tempSalesFinance_supplier_type a 

	select @fSales_prior=sum(fLastSettle),
 				@fProfits_prior=sum(round(isnull(fLastSettle,0)*isnull(fProfitsRatio,0)/100.00,2))
 	from #tempSalesFinance_supplier_type
	where cMonth=1

	select cYear,cYearEnd,cMonth,iWeekNo=null,
	fSales_now=round(sum(fLastSettle),2) ,
	fSales1_now=round(sum(case when bAuditing=1  then fLastSettle else 0 end) ,2),
	fSales0_now=round(sum(case when isnull(bAuditing,0)=0  then fLastSettle else 0 end),2) ,
	fProfits_now=sum(round(fLastSettle*fProfitsRatio/100.00,2)),
	fProfits1_now =sum(case when bAuditing=1  then round(fLastSettle*fProfitsRatio/100.00,2) else 0 end),
	fProfits0_now=sum(case when isnull(bAuditing,0)=0  then round(fLastSettle*fProfitsRatio/100.00,2) else 0 end) ,
  fRight=sum(fRight)/count(1),
	iDays=sum(iDays)/count(1),
	iHolidays=sum(iHolidays)/count(1),
	fRight_month=cast(1.00 as money), 
	fRight_Hope=cast(1.00 as money),

	fRatio_sale_complete=cast(0.00 as money), 
	fRatio_profit_complete=cast(0.00 as money), 

	RingRatio_sale=cast(0.00 as money), 
	RingRatio_profit=cast(0.00 as money), 

	fSales_Hope=cast(0.00 as money), 
	fProfits_Hope=cast(0.00 as money)

	into #tempSales_sum0
	from #tempSalesFinance_supplier_type
	group by cYear,cYearEnd,cMonth
	
  update #tempSales_sum0 set fRight_month=fRight*iDays*(1+iHolidays)

 

	select a.*,period=dbo.getDayStr(b.dDate1) +'至'+dbo.getDayStr(b.dDate2 ) 
	into #tempSales_sum1
	from #tempSales_sum0 a left join #tempWeekOfMonth_Finance b 
	on a.cYear=b.cYear and a.cYearEnd=b.cYearEnd and a.cMonth=b.cMonth

	select cYear,cYearEnd,cMonth,iWeekNo=null,period,fRight,iDays,iHolidays,fRight_month,fRight_Hope,
	fSales_now,	fSales1_now,fSales0_now,
	fProfits_now,fProfits1_now,fProfits0_now ,
	iWeekNo_serno=cast(cMonth as int)
	into #tempSales_sum
	from #tempSales_sum1

	update a set a.cYearEnd=b.cYearEnd from #tempSales_sum a ,#Temp_Period b where a.cMonth=b.iSerno
/*
	union all
	select cYear='合计',cYearEnd=null,cMonth=null,iWeekNo=null,period='合计',fRight=null,iDays=null,iHolidays=null,fRight_month=null,fRight_Hope=null,  
	fSales_now=sum(fSales_now),	fSales1_now=sum(fSales1_now),fSales0_now=sum(fSales0_now),
	fProfits_now=sum(fProfits_now),
	fProfits1_now=sum(fProfits1_now),fProfits0_now=sum(fProfits0_now) ,
	iWeekNo_serno=9999
	from #tempSales_sum1
	group by cYear
*/
/*
	declare @fRight_Prior money--上月加权系数
	declare @fRight_now money--本月加权系数
	declare @fRight_Hope money--本月指标系数@fRight_now/@fRight_Prior
	declare @fSales_prior money--上月销售
	declare @fProfits_prior money--上月销售
*/
	select top 1 @fSales_prior= fSales_now,@fProfits_prior=fProfits_now,@fRight_Prior=fRight_month  
	from #tempSales_sum where cMonth=1	
	declare @fSales_Total money--上月销售
	declare @fProfits_Total money--上月毛利
	select  @fSales_Total= sum(fSales_now),@fProfits_Total=sum(fProfits_now)  
	from #tempSales_sum 


  update #tempSales_sum set cYear=' '
	where iWeekNo_serno<>1 and iWeekNo_serno<>9999

	select cYear,cYearEnd,cMonth,iWeekNo=null,period,fRight,iDays,iHolidays,fRight_month,fRight_Hope,  
	fSales_now,	fSales1_now,fSales0_now,
	fProfits_now,fProfits1_now,fProfits0_now ,
	fSale_Ratio=round(fSales_now/case when @fSales_Total=0 then null else @fSales_Total end*100,2),
	fProfits_Ratio=round(fProfits_now/case when @fProfits_Total=0 then null else @fProfits_Total end*100 ,2),
	fSales_Hope=round(@fSales_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,0),
	fProfits_Hope=round(@fProfits_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,0),

	fSales_CompleteRatio=round(fSales_now/
				case 
					when
					round(@fSales_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,2)<>0
					then round(@fSales_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,2)
					else null
				end*100,2),
	fProfits_CompleteRatio=round(fProfits_now/
				case 
					when
					round(@fProfits_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,2)<>0
					then round(@fProfits_prior*fRight_month/case when @fRight_Prior<>0 then @fRight_Prior else null end,2)
					else null
				end*100,2),

	iWeekNo_serno
	into #tempSales_sum_last
  from  #tempSales_sum
	
	update #tempSales_sum_last 
	set fSale_Ratio=100-(select sum(fSale_Ratio) from #tempSales_sum_last where cMonth<>1),
	fProfits_Ratio=100-(select sum(fProfits_Ratio) from #tempSales_sum_last where cMonth<>1 ) 
	where cMonth=1
	
	select * from #tempSales_sum_last order by cMonth

end


/*
select * into #tempGoodsSupplier from dbo.f_Goods_GoodsType_Supplier()

exec p_report_Month '2006'

drop table	#tempGoodsSupplier
*/













GO
