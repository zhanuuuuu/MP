



CREATE   function f_GenJiesuanNo
(@cYear varchar(4),@cSupNo varchar(16)) returns varchar(32)
as
begin
   declare @iMaxSerno int 
	 declare @strRet varchar(32)
   --declare @i int
   declare @cMaxSerno varchar(32)
   set @cMaxSerno=(select max(jiesuanno) from t_Supplier_jiesuan
/*
                  where cSupNo=@cSupNo
                        and datename(yyyy,jiesuanriqi)=@cYear
*/
                  where (cSupNo=@cSupNo
                        and datename(yyyy,jiesuanriqi)=@cYear)
												or
												(substring(jiesuanno,7,PatIndex('%-%',jiesuanno)-7)=@cSupNo
												 and datename(yyyy,jiesuanriqi)=@cYear	
												)

                 )
   if @cMaxSerno is null 
   begin
     set @strRet=  'JS'+@cYear+@cSupNo+'-'+'0001' 
   end else
   begin
     set @cMaxSerno=ltrim(rtrim(cast(cast(RIGHT(@cMaxSerno,4) as int)+1 as varchar(10))))
     while len(@cMaxSerno)<4 
     begin
       set @cMaxSerno='0'+@cMaxSerno     
     end
     set @strRet=    'JS'+@cYear+@cSupNo+'-'+@cMaxSerno 
   end

   return @strRet
end


GO
