
/*
  时段库存(只有管理库存的商品)
  select * from wh_CheckWh
  
 create table #tmpCostGoodsList  --drop table #tmpCostGoodsList
(
 cGoodsNO varchar(100)
)
insert into #tmpCostGoodsList select Cgoodsno from t_goods where cgoodsno='11001001'
select * from #tmpCostGoodsList
select * from t_goods where bstorage=0

drop table #tmpCostGoodsList
p_CheckWh_chen_Pre '001'
*/
create proc [dbo].[p_CheckWh_chen_Pre]
@cTaskNo varchar(100)
as

declare @cTaskName varchar(100)
declare @cWhNo varchar(100)
declare @dDateBgn datetime
declare @dDateEnd datetime  --时段截止日期
declare @dDate_daily datetime  --日结日期
declare @dDate_account datetime  --记账日期

select @dDateBgn='2000-01-01'
select @cWhNo=cWhNo,@dDateEnd=dCheckTask,@cTaskName=cCheckTask
from t_CheckTast
where cCheckTaskNo=@cTaskNo

if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null
drop table #tmpPloyOfGoodsinfo
select a.cGoodsNo,fQty_Check=sum(a.fQuantity),cSupNo=c.cSupNo,cWhNo=@cWhNo
into #tmpPloyOfGoodsinfo
from wh_CheckWhDetail a,wh_CheckWh b,t_goods c
where a.cSheetno=b.cSheetno and a.cGoodsNo=c.cGoodsNo
and b.cSupplierNo=@cTaskNo
group by a.cGoodsNo,c.cSupNo


select @dDate_daily=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history 
where ISNULL(cWhNo,'')=@cWhNo

select @dDate_account=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history 
where ISNULL(bAccount,0)=1 and ISNULL(cWhNo,'')=@cWhNo

--#tmpCostGoodsList 待查询的商品
--查询供应商商品

if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null
drop table #GoodsCurStorageList
--成本表中 【接收数量、发出数量】
	select b.dDateTime,a.cGoodsNo,b.cWhNo,cSupNo=isnull(b.cSupplierNo,'-'),
	fQuantity=isnull(b.fQty_in,0),b.iAttribute,fMoney_sys=ISNULL(b.fMoney_In,0)
	into #GoodsCurStorageList
	from #tmpPloyOfGoodsinfo a left join t_wh_Form b
	on a.cGoodsNO=b.cGoodsNO
	where b.dDateTime<=@dDateEnd 
	and ISNULL(b.cWhNo,'')=@cWhNo
	union all
	select a.dDate_Sheet,a.cGoodsNo,b.cWhNo,cSupNo=isnull(b.cSupplierNo,'-'),fQuantity=-isnull(a.fQty_cost,0),
    a.iAttribute,fMoney_sys=-ISNULL(a.fMoney_Cost,0)
    from #tmpPloyOfGoodsinfo c,t_Cost_distribute a,T_WH_Form b
    where a.cGoodsNo=c.cGoodsNo and a.dDate_Sheet<=@dDateEnd 
    and ISNULL(a.bdone,0)=0
    and a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno 
    and a.cWhNo=b.cWhNo  and ISNULL(b.cWhNo,'')=@cWhNo 
	union all
			select dDate_Sheet=b.dDate,a.cGoodsNo,b.cWhNo,cSupNo=b.cCustomerNo,fQuantity=-a.fQuantity,
			iAttribute=1,fMoney_sys=-a.fInMoney
			from wh_OutWarehouseDetail a,wh_OutWarehouse b,t_goods c
			where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dDate<=@dDateEnd
			and isnull(b.bAccount,0)<>1
	union all
			select dDate_Sheet=b.dDate,a.cGoodsNo,b.cWhNo,cSupNo=b.cSupplierNo,fQuantity=-a.fQuantity,
			iAttribute=2,fMoney_sys=-a.fInMoney
			from wh_RbdWarehouseDetail a,wh_RbdWarehouse b,t_goods c
			where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dDate<=@dDateEnd
			and isnull(b.bAccount,0)<>1

	union all
			select dDate_Sheet=b.dDate,a.cGoodsNo,b.cWhNo,cSupNo=b.cSupplierNo,fQuantity=-a.fQuantity,
			iAttribute=5,fMoney_sys=-a.fMoney
			from wh_LossWarehouseDetail a,wh_LossWarehouse b,t_goods c
			where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dDate<=@dDateEnd
			and isnull(b.bAccount,0)<>1
	union all
			select dDate_Sheet=b.dDate,a.cGoodsNo,b.cWhNo,cSupNo=b.cSupplierNo,fQuantity=-a.fQuantity,
			iAttribute=4,fMoney_sys=-a.fInMoney
			from wh_TfrWarehouseDetail a,wh_TfrWarehouse b,t_goods c
			where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dDate<=@dDateEnd
			and isnull(b.bAccount,0)<>1
	union all
			select dDate_Sheet=b.dDate,a.cGoodsNo,b.cWhNo,cSupNo=b.cSupplierNo,fQuantity=-a.fQuantity,
			iAttribute=8,fMoney_sys=-a.fInMoney
			from dbo.wh_PackDetail a,dbo.wh_Pack b,t_goods c
			where a.cSheetNO=b.cSheetNo and a.cgoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dDate<=@dDateEnd
			and isnull(b.bAccount,0)<>1
	union all
			select dDate_Sheet=a.dSaleDate,
			a.cGoodsNo,a.cWhNo,cSupNo=c.cSupNo,fQuantity=-a.fQuantity,
			iAttribute=8,fMoney_sys=-a.fLastSettle
			from t_saleSheet_day a,t_Daily_history b,t_goods c
			where a.dSaleDate>@dDate_account and a.dSaleDate<=@dDateEnd
			and a.dSaleDate=b.dDate and a.cWhNO=b.cWHno and a.cWHno=@cWhNo and a.cGoodsNo=c.cGoodsNo
			and isnull(b.bAccount,0)<>1
			union all
			--盘点报损
			select distinct dDate_Sheet=b.dCheckTask,a.cGoodsNo,b.cWhNo,cSupNo=c.cSupNo,fQuantity=a.fQuantity_diff,
			iAttribute=12,fMoney_sys=a.fMoney_Diff
			from t_CheckTast_GoodsDetail a,t_CheckTast b,t_goods c
			where a.cCheckTaskNo=b.cCheckTaskNo
			and a.cGoodsNo=c.cGoodsNo and b.cWhNo=@cWhNo and b.dCheckTask<=@dDateEnd
			and isnull(b.bAccount,0)<>1 and isnull(a.fQuantity_diff,0)<0
			and b.bchecked in(0,1)	

union all
select @dDateBgn,cGoodsNo,@cWhNo,cSupNo,fQuantity=0,iAttribute=9999,0 from #tmpPloyOfGoodsinfo

--select * from #GoodsCurStorageList order by cGoodsNo
--以上计算期末库存

if (select OBJECT_ID('tempdb..#tmpLast0'))is not null
drop table #tmpLast0
select cGoodsNo,cWhNo,fQty_sys=SUM(ISNULL(fQuantity,0)),fMoney_sys=SUM(isnull(fMoney_sys,0))
into #tmpLast0
from #GoodsCurStorageList
group by cGoodsNo,cWhNo

--select * from #tmpLast0
--select * from #tmpPloyOfGoodsinfo
if (select OBJECT_ID('tempdb..#tmpLast1'))is not null
drop table #tmpLast1
select a.cGoodsNo,a.cSupNo,a.cWhNo,a.fQty_check,b.fQty_sys,b.fMoney_sys,fCkPrice=cast(null as money)
into #tmpLast1
from #tmpPloyOfGoodsinfo a left join #tmpLast0 b
on a.cGoodsNo=b.cGoodsNo and a.cWhNo=b.cWhNo


update x
set x.fCkPrice=k.fPrice_In
from #tmpLast1 x,
(
        select a.cGoodsNo,a.dDateTime,a.cSupplierNo,a.cSupplier,a.fPrice_In,a.cSheetNo
		from t_WH_Form	a,
		(
			select cGoodsNo,iSerno=max(iSerno)
			from t_WH_Form
			where dDateTime<=@dDateEnd and isnull(iAttribute,999)=0 and cWhNo=@cWhNo and fPrice_In>0
			group by cGoodsNo
		) b
		where a.dDateTime<=@dDateEnd and a.cWhNo=@cWhNo and a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno
	
)k
where x.cgoodsno=k.cgoodsno

update a
set a.fCkPrice=b.fCKPrice
from #tmpLast1 a,t_goods b
where a.cgoodsno=b.cGoodsNo
and ISNULL(a.fCkPrice,0)=0





begin try 
   begin tran

		
		select cCheckTaskNo=@cTaskNo,cCheckTask=@cTaskName,cWhNo=@cWhNo,a.cGoodsNo,
		b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,
		fQuantity_Check=isnull(a.fqty_check,0),
		fQuantity_Sys=isnull(a.fqty_sys,0),
		fQuantity_Diff=isnull(a.fqty_check,0)-ISNULL(a.fqty_sys,0),
		cSupplierNo=b.cSupNo,cSupplier=b.cSupName,fInPrice_Avg=a.fCKPrice,b.fNormalPrice,
		--fMoney_Diff=(isnull(a.fqty_check,0)-ISNULL(a.fqty_sys,0))*a.fCKPrice,
		fMoney_Diff=isnull(a.fqty_check,0)*a.fCKPrice-ISNULL(fMoney_sys,0),
		fMoney_sys,
		fMoney_Sale_Diff=(isnull(a.fqty_check,0)-ISNULL(a.fqty_sys,0))*b.fNormalPrice,
		dCheckTask=@dDateEnd,b.fQty_minPackage,b.cGoodsNo_minPackage
		into #tmpLast1_minPackage
		from #tmpLast1 a ,t_goods b
		where a.cGoodsNo=b.cGoodsNo
		
		select 
  		 a.cCheckTaskNo,a.cCheckTask,a.cWhNo,a.cGoodsNo,a.fQuantity_Check,a.fQuantity_Sys,a.fQuantity_Diff,
  		 a.fMoney_Diff,a.fMoney_sys,a.fMoney_Sale_Diff,
  		 b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,fInPrice_Avg=b.fCKPrice,b.fNormalPrice,
  		 cSupplierNo=b.cSupNo,cSupplier=b.cSupName
		from
		(
      select x.cCheckTaskNo,x.cCheckTask,x.cWhNo,
  			 x.cGoodsNo,
  			 fQuantity_Check=SUM(x.fQuantity_Check),
  			 fQuantity_Sys=SUM(x.fQuantity_Sys),
  			 fQuantity_Diff=SUM(x.fQuantity_Diff),
  			 fMoney_Diff=sum(x.fMoney_Diff),
  			 fMoney_sys=sum(x.fMoney_sys),
   			 fMoney_Sale_Diff=sum(x.fMoney_Sale_Diff)
      
      from
      (
				select cCheckTaskNo,cCheckTask,cWhNo,
  			 cGoodsNo=case when ISNULL(fQty_minPackage,0)>0 and ISNULL(dbo.trim(cGoodsNo_minPackage),'')<>'' 
  										 then cGoodsNo_minPackage 
  										 else cGoodsNo end,
  			 fQuantity_Check=case when ISNULL(fQty_minPackage,0)>0 and ISNULL(dbo.trim(cGoodsNo_minPackage),'')<>'' 
  										 then fQuantity_Check*fQty_minPackage 
  										 else fQuantity_Check end,
  			 fQuantity_Sys=case when ISNULL(fQty_minPackage,0)>0 and ISNULL(dbo.trim(cGoodsNo_minPackage),'')<>'' 
  										 then fQuantity_Sys*fQty_minPackage 
  										 else fQuantity_Sys end,
  			 fQuantity_Diff=case when ISNULL(fQty_minPackage,0)>0 and ISNULL(dbo.trim(cGoodsNo_minPackage),'')<>'' 
  										 then fQuantity_Diff*fQty_minPackage 
  										 else fQuantity_Diff end,
  			 fMoney_Diff=fMoney_Diff,
  			 fMoney_sys=fMoney_sys,
   			 fMoney_Sale_Diff=fMoney_Sale_Diff
				 from #tmpLast1_minPackage
			) x group by x.cCheckTaskNo,x.cCheckTask,x.cWhNo,x.cGoodsNo
		) a,t_Goods b
		where a.cGoodsNo=b.cGoodsNo
		
  commit tran
  
 end try
 begin catch
    rollback
 end catch


GO
