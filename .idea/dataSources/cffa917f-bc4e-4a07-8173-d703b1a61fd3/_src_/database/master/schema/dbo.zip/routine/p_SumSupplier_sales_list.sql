






CREATE      procedure p_SumSupplier_sales_list
@supNo varchar(64),
--@jiesuanNo varchar(64),
@date1 datetime,
@date2 datetime
as
begin
  /*在执行此存储过程前，必须检查是否有商品同一时间段内，同时参加两次或两次活动以上，如果有就不能执行此存储过程*/
	/*计算商户的特供商品的销售额*/
	/*主要特供表dbo.t_supplier_Goods_spec*/
	
  select distinct a.cGoodsno,a.cGoodsName,a.cBarcode,a.cUnitedNo,a.cSpec
	into #t_supplier_Goods_spec
	from dbo.wh_InWarehouseDetail a
  where a.cSheetno in (select cSheetno from dbo.wh_InWarehouse where cSupplierNo=@supNo)
  union
	select cGoodsNo,cGoodsName,cBarcode,cUnitedNo,cSpec
--	from dbo.t_supplier_Goods_spec
	from dbo.t_supplier_Goods
	where cSupNo=@supNo
	
	select cGoodsno 
	into #t_supplier_Goods_eStop_supNo 
	from t_supplier_Goods_eStop
  where  cSupNo=@supNo
	
	select distinct cGoodsno
  into #t_supplier_Goods_spec_onlyGoodsno 
	from #t_supplier_Goods_spec 
	where cGoodsNo not in (select cGoodsno from #t_supplier_Goods_eStop_supNo)

--	select distinct cGoodsno into #t_supplier_Goods_spec_onlyGoodsno from #t_supplier_Goods_spec
	

	select  a.cGoodsNo, a.cGoodsName,a.cBarCode,a.fQuantity,
	fLastSettle=case when isnull(a.bAuditing,0)=0 then a.fNormalSettle
							     else a.fLastSettle
							end,a.dSaleDate,a.bAuditing
	into #t_SaleSheetDetail
	from dbo.t_SaleSheetDetail a,#t_supplier_Goods_spec_onlyGoodsno b
	where a.cGoodsNo=b.cGoodsno 
	and isnull( a.bBalance,0)=0 and  a.dSaleDate between @date1 and @date2 /*没有结算，并且销售日期在@date and @date2之间*/

  union all  	

	select c.cGoodsNo,c.cGoodsName,c.cBarCode,fQuantity=-c.fQuantity,fLastSettle=-c.fInMoney,dSaleDate=d.dDate,bAuditing=0
	from dbo.WH_ReturnGoodsDetail c
			 left join 	dbo.WH_ReturnGoods d on c.cSheetno=d.cSheetno
	where c.cGoodsNo in (select cGoodsNo from #t_supplier_Goods_spec_onlyGoodsno) 
	and isnull(c.bBalance,0)=0 and d.dDate between @date1 and @date2 /*没有结算，并且销售日期在@date and @date2之间*/

	select  cGoodsNo,cGoodsName,cBarcode,dSaleDate,fLastSettle=sum(isnull(fLastSettle,0)),
					fQuantity=sum(isnull(fQuantity,0)),bAuditing
	into #t_SaleSheetDetail_bybAuditing
	from #t_SaleSheetDetail
	group by cGoodsNo,cGoodsName,cBarcode,dSaleDate,bAuditing

	
	select  cAuditing='特价销售', cGoodsNo,cGoodsName,cBarcode,dSaleDate,fLastSettle,
					fQuantity,bAuditing
	into #t_SaleSheetDetail_prior
	from #t_SaleSheetDetail_bybAuditing
	where isnull(bAuditing,0)=1 
	union all
	select  cAuditing='特价销售合计:', cGoodsNo='-',cGoodsName=null,cBarcode=null,dSaleDate=null,fLastSettle=sum(isnull(fLastSettle,0)),
					fQuantity=sum(isnull(fQuantity,0)),bAuditing=0
	from #t_SaleSheetDetail_bybAuditing
	where isnull(bAuditing,0)=1 
--	group by cGoodsNo,cGoodsName	/*特价销售金额商品清单，带有销售日期*/ 	
  union all
	select  cAuditing='正价销售:', cGoodsNo,cGoodsName,cBarcode,dSaleDate,fLastSettle,
					fQuantity,bAuditing
--	into #t_SaleSheetDetail_bybAuditing_0
	from #t_SaleSheetDetail_bybAuditing
	where isnull(bAuditing,0)=0  
	union all
	select  cAuditing='正价销售合计:', cGoodsNo='-',cGoodsName=null,cBarcode=null,dSaleDate=null,fLastSettle=sum(isnull(fLastSettle,0)),
					fQuantity=sum(isnull(fQuantity,0)),bAuditing=0
	from #t_SaleSheetDetail_bybAuditing
	where isnull(bAuditing,0)=0 
--	group by cGoodsNo,cGoodsName	/*正价销售金额商品清单，时间段汇总*/
	union all
	select  cAuditing='总计:', cGoodsNo='-',cGoodsName=null,cBarcode=null,dSaleDate=null,fLastSettle=sum(isnull(fLastSettle,0)),
					fQuantity=sum(isnull(fQuantity,0)),bAuditing=0
	from #t_SaleSheetDetail_bybAuditing
--	group by cGoodsNo,cGoodsName	/*销售金额商品清单，时间段汇总*/
--	select 
	
	select a.cAuditing,a.cGoodsNo,a.cGoodsName,b.cBarCode,a.dSaleDate,a.fLastSettle,
				 a.fQuantity,a.bAuditing,b.cUnit,b.cSpec
	from #t_SaleSheetDetail_prior a left join t_Goods b
	on a.cGoodsNo=b.cGoodsno
	order by a.cGoodsNo desc,a.cAuditing,a.dSaleDate 


  return 1


	
end


GO
