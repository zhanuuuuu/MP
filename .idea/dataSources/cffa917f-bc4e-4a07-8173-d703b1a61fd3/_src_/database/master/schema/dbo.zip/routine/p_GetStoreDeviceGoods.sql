 
CREATE proc p_GetStoreDeviceGoods
@PosID varchar(32),
@cGoodsNoList varchar(8000)
as
begin
   if (select object_id('tempdb..#tmp_GoodsList'))is not null
   begin
	  drop table #tmp_GoodsList
   end 
   select F1 as cGoodsNo into #tmp_GoodsList from dbo.SplitStr(@cGoodsNoList,',')
  
   
   if (select object_id('tempdb..#tmp_GoodsList1'))is not null
   begin
	  drop table #tmp_GoodsList1
   end 
   
   SELECT a.cGoodsNo,a.cStoreNo
   into #tmp_GoodsList1
   from t_StoreGoodsDevice a,#tmp_GoodsList b
   where a.PosID=@PosID and a.cGoodsNo=b.cGoodsNo
   
   select a.cGoodsNo as goodsID,a.cGoodsName as name,a.fNormalPrice as price
   from t_cStoreGoods a,#tmp_GoodsList1 b
   where a.cGoodsNo=b.cGoodsNo and a.cStoreNo=b.cStoreNo
   
end
GO
