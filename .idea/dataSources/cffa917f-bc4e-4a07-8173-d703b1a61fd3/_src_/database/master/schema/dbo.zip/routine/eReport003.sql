CREATE procedure [dbo].[eReport003]
@dDate1 datetime,
@dDate2 datetime,
@cWHno varchar(32)
as  
/*
eReport003
@dDate1='2012-07-20',@dDate2='2012-08-28',@cWHno='01'
*/
--查询某时段 商品销售利润（含顾客退货）
--declare @dDate1 datetime 
--declare @dDate2 datetime 
--declare @cWHno varchar(32)
--select @dDate1='2011-08-28',@dDate2='2011-09-28',@cWHno='01'
begin
declare @date3 datetime
set @date3=DateAdd(d,-7, @dDate2)
--select @date3
--     when a.iAttribute=1 then '出库'
--     when a.iAttribute=2 then '返厂'
--     when a.iAttribute=3 then '客退'
--     when a.iAttribute=4 then '调拨'
--     when a.iAttribute=5 then '报损'
--     when a.iAttribute=6 then '报溢'
--     when a.iAttribute=7 then '差价'
--     when a.iAttribute=8 then '原料出库'
--     when a.iAttribute=9 then '加工入库'
--     when a.iAttribute=10 then '日结'
--     when a.iAttribute=11 then '盘点溢出'
--     when a.iAttribute=12 then '盘点报损'
--     when a.iAttribute=13 then 'POS客退

	/*注意一品多商的情况*/
if (select object_id('tempdb..#t_goods'))is not null
drop table #t_goods

select cGoodsNo into #t_goods from t_goods where bStorage=1
if (select object_id('tempdb..#GetGoodsListFormBase'))is not null
drop table #GetGoodsListFormBase
create table #GetGoodsListFormBase
(
   cGoodsNo varchar(32),
   cSupNO varchar(32),
   cGoodsTypeNo varchar(32),
   cGoodsTypeName varchar(100),
   fQuantity money,
   fLastSettle money,
   fMoneyCost money,
   fMoneyRatio money,
   fRatio money,
   bAuditing int
)
insert into #GetGoodsListFormBase
(
  cGoodsNo,cSupNO,cGoodsTypeNo,cGoodsTypeName,bAuditing,fQuantity,fLastSettle,fMoneyCost,fMoneyRatio,fRatio
)
-----------------
exec p_BaseFIFOGoodsListBy_Sale_Cost_Ratio @dDate1,@dDate2,@cWHno
---------------
if (select object_id('tempdb..#temp_Sale_Cost99'))is not null
drop table #temp_Sale_Cost99
  select a.cGoodsNo,cSupplierNo=a.cSupNO,cSupplier=b.cSupName,fQty_Cost=sum(isnull(a.fQuantity,0)),
  fMoney_sale_distribute=sum(isnull(a.fLastSettle,0)),
  fProfitRatio=null,
  fProfitRatio_avg=case when sum(isnull(a.fLastSettle,0))<>0
											  then sum(isnull(a.fMoneyRatio,0))/sum(isnull(a.fLastSettle,0))*100 
									 else null end,
  fMoney_Profit_sum=sum(isnull(a.fMoneyRatio,0)),
  fCostPrice=case when sum(isnull(a.fQuantity,0))<>0
											  then sum(isnull(a.fMoneyCost,0))/sum(isnull(a.fQuantity,0))
									 else null end,
  fMoney_Cost=sum(isnull(a.fMoneyCost,0)),fML=sum(isnull(fMoneyRatio,0))
  into #temp_Sale_Cost99
  from #GetGoodsListFormBase a,t_goods b
  where a.cGoodsNo=b.cGoodsNo
  group by a.cGoodsNo,a.cSupNO,b.cSupName

if (select object_id('tempdb..#temp_goodsKuCun'))is not null
drop table #temp_goodsKuCun
  select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
				b.cGoodsTypeno,b.cGoodsTypename,bProducted=null,cProductNo=null,
        BeginDate=@dDate1,EndDate=@dDate2,a.cSupplierNo,cSupName=a.cSupplier,
        xsQty=isnull(a.fQty_Cost,0),xsMoney=isnull(a.fMoney_sale_distribute,0),
				a.fProfitRatio,a.fProfitRatio_avg,a.fMoney_Profit_sum,
				fCostPrice=case when isnull(a.fQty_Cost,0)<>0 
									      then a.fMoney_Cost/a.fQty_Cost else null end,
        a.fMoney_Cost,
				fML=a.fMoney_Profit_sum
  into #temp_goodsKuCun
  from #temp_Sale_Cost99 a,t_Goods b
  where a.cGoodsNo=b.cGoodsNo

if (select OBJECT_ID('tempdb..#cgoods_kucun'))is not null
drop table #cgoods_kucun
 select cGoodsNo,cGoodsName,cUnit,fNormalPrice,fCostPrice=isnull(fCostPrice,0),c_kun=cast(null as varchar(10)),
        c_maoli=cast(null as varchar(10)),cGoodsTypeno,cGoodsTypename,cSupplierNo,cSupName,fMoney_Cost,fMoney_Profit_sum,
        fProfitRatio_avg,xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fML=isnull(xsMoney,0)-isnull(fMoney_Cost,0),BeginDate,EndDate
 into #cgoods_kucun
 from #temp_goodsKuCun
 
 --------------库存
 declare @dDate_daily datetime  --日结日期
declare @dDate_account datetime  --日结日期

select @dDate_daily=isnull(MAX(dDate),'1900-01-01') 
from t_Daily_history
where isnull(cWhNo,'')=@cWhNo

select @dDate_account=isnull(MAX(dDate),'1900-01-01')  -- 记账的最大日期
from t_Daily_history 
where ISNULL(bAccount,0)=1 and isnull(cWhNo,'')=@cWhNo

if (select OBJECT_ID('tempdb..#tmpCostGoodsList'))is not null
drop table #tmpCostGoodsList
 create table #tmpCostGoodsList  --drop table #tmpCostGoodsList
( cGoodsNO varchar(100))
insert into #tmpCostGoodsList select Cgoodsno from t_goods where bstorage=1

if (select OBJECT_ID('tempdb..#FindGoodsList0'))is not null
drop table #FindGoodsList0
select b.cGoodsNO,cGoodsNo_minPackage=ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo),
bIsPack=case when a.cGoodsNo<>ISNULL(a.cGoodsNo_minPackage,a.cGoodsNo) then 1 else 0 end  --（包装=1）
into #FindGoodsList0
from t_goods a, #tmpCostGoodsList b
where a.cGoodsNo=b.cGoodsNo
and ISNULL(a.bStorage,0)=1
--关联相关商品（包装+单品）
if (select OBJECT_ID('tempdb..#FindGoodsList1'))is not null
drop table #FindGoodsList1
select cGoodsNO
into #FindGoodsList1
from #tmpCostGoodsList
union all
select cGoodsNo_MinPackage
from #FindGoodsList0
where ISNULL(bIsPack,0)=1
union all
select b.cGoodsNo
from #FindGoodsList0 a,t_goods b
where ISNULL(a.bIsPack,0)=0
and a.cGoodsNo=b.cGoodsNo_minPackage

if (select OBJECT_ID('tempdb..#t_FindGoods'))is not null
drop table #t_FindGoods
select distinct cGoodsNO,cSupNO,bStorage
into #t_FindGoods
from t_goods
where cGoodsNo in(select cgoodsno from #FindGoodsList1)

--取商品(管理库存)
if (select OBJECT_ID('tempdb..#tmpPloyOfGoodsinfo'))is not null
drop table #tmpPloyOfGoodsinfo
select distinct cGoodsNo,cSupNo
into #tmpPloyOfGoodsinfo
from #t_FindGoods 
where isnull(bStorage,0)=1

-----------------------------------------
------*********从各个分开中取数据*********--------
----- 销售表
 if(select object_id('tempdb..#temp_salesheetDetail ')) is not null drop table #temp_salesheetDetail
	create table #temp_salesheetDetail(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fPrice money,fLastSettle money ,bAuditing bit,cWHno varchar(32))
     
 ------  日结表 

    if(select object_id('tempdb..#temp_SaleSheet_Day')) is not null drop table #temp_SaleSheet_Day
	create table #temp_SaleSheet_Day(dSaleDate datetime,cGoodsNo varchar(32),
	fQuantity money ,iSeed int,fNormalPrice money,fLastSettle money ,bauditing bit,bStorage bit,cWHno varchar(32))
declare @dddate1 datetime
set @dddate1=@dDate_account+1

exec p_SaleDetail_Ref @dddate1,@dDate2,@cWhNo


if (select OBJECT_ID('tempdb..#GoodsCurStorageList'))is not null
drop table #GoodsCurStorageList
--成本表中 【接收数量、发出数量】
	select a.cGoodsNo,b.cWhNo,fQuantity=isnull(b.fQty_in,0)
	into #GoodsCurStorageList
	from #tmpPloyOfGoodsinfo a left join t_wh_Form b
	on a.cGoodsNO=b.cGoodsNO
	where b.dDateTime<=@dDate2 
	and ISNULL(b.cWhNo,'')=01
	union all
	select a.cGoodsNo,b.cWhNo,fQuantity=-isnull(a.fQty_cost,0)
	from #tmpPloyOfGoodsinfo c,
	-- t_Cost_distribute a,T_WH_Form b
	dbo.t_Cost_distribute a,T_WH_Form b
    where a.cGoodsNo=c.cGoodsNo and a.dDate_Sheet<=@dDate2 
    and ISNULL(a.bdone,0)=0
    and a.cGoodsNo=b.cGoodsNo and a.iSerno=b.iSerno 
    and a.cWhNo=b.cWhNo  and ISNULL(b.cWhNo,'')=@cWhNo 
--销售情况统计开始
	--日结但未记账的商品(销售)
	--管理库存
	union all
	select a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join ---t_SaleSheet_Day b
	#temp_SaleSheet_Day b
	on  a.cGoodsNo=b.cGoodsNo
	where isnull(b.fQuantity,0)<>0
	--and b.dSaleDate<=@dDate2 
	--and b.dSaleDate>=@dDate_account+1  -- 记账的最大日期 小
	--and b.dSaleDate<=@dDate_daily      -- 日结的最大日期 大
	--and ISNULL(b.cWhNo,'')=@cWhNo
	and b.dSaleDate between @dDate_account+1 and @dDate2
	and b.dSaleDate<=@dDate_daily      -- 日结的最大日期 大
	and ISNULL(b.cWhNo,'')=@cWhNo
	union all
	--未日结的商品从销售单中取
	select a.cGoodsNo,b.cWHno,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join --t_SaleSheetDetail b
	#temp_salesheetDetail b
	on  a.cGoodsNo=b.cGoodsNo
--	where b.dSaleDate<=@dDate2 and b.dSaleDate>=@dDate_daily+1
    where b.dSaleDate between @dDate_daily+1 and @dDate2  
	and ISNULL(b.cWhNo,'')=@cWhNo
--销售情况统计结束
--入库单统计开始 
    /* 
      select top 1* from dbo.wh_InWarehouse
      select top 1* from dbo.wh_InWarehouseDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_InWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_InWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
	and ISNULL(c.cWhNo,'')=@cWhNo
--入库单统计结束
--出库单统计开始 
    /* 
      select top 1* from dbo.wh_OutWarehouse
      select top 1* from dbo.wh_OutWarehouseDetail
      select * from #tmpPloyOfGoodsinfo
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_OutWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_OutWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
	and ISNULL(c.cWhNo,'')=@cWhNo
--出库单统计结束
--报损单统计开始 
    /* 
      select top 1* from dbo.wh_LossWarehouse
      select * from dbo.wh_LossWarehouseDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_LossWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_LossWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
	and ISNULL(c.cWhNo,'')=@cWhNo
--报损单统计结束
--报溢单统计开始 
    /* 
      select top 1* from dbo.wh_EffusionWh
      select top 1* from dbo.wh_EffusionWhDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
    from #tmpPloyOfGoodsinfo a left join wh_EffusionWhDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_EffusionWh c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
	and ISNULL(c.cWhNo,'')=@cWhNo
--报溢单统计结束
--返厂单统计开始 
    /* 
      select top 1* from dbo.wh_RbdWarehouse
      select top 1* from dbo.wh_RbdWarehouseDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_RbdWarehouseDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_RbdWarehouse c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
    and ISNULL(c.cWhNo,'')=@cWhNo
--返厂单统计结束
--客退单统计开始 
    /* 
      select top 1* from dbo.WH_ReturnGoods
      select top 1* from dbo.WH_ReturnGoodsDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join WH_ReturnGoodsDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join WH_ReturnGoods c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
    and ISNULL(c.cWhNo,'')=@cWhNo
--客退单统计结束
--原料出库单统计开始 
    /* 
      select top 1* from dbo.wh_Pack
      select top 1* from dbo.wh_PackDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(-b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_PackDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_Pack c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
    and ISNULL(c.cWhNo,'')=@cWhNo
--原料出库单统计结束
--成品入库单统计开始 
    /* 
      select top 1* from dbo.wh_Divide
      select top 1* from dbo.wh_DivideWhDetail
    */
    --管理库存
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity=isnull(b.fQuantity,0)
	from #tmpPloyOfGoodsinfo a left join wh_DivideWhDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join wh_Divide c
	on b.cSheetNo=c.cSheetNo
	where c.dDate<=@dDate2 and isnull(c.baccount,0)=0
    and ISNULL(c.cWhNo,'')=@cWhNo
--成品入库单统计结束
--盘点统计开始 
    /* 
      select top 1* from dbo.wh_RbdWarehouse
      select top 1* from dbo.wh_RbdWarehouseDetail
    */
    union all
    select a.cGoodsNo,c.cWhNo,fQuantity_Diff=isnull(b.fQuantity_Diff,0)
	from #tmpPloyOfGoodsinfo a left join t_CheckTast_GoodsDetail b
	on  a.cGoodsNo=b.cGoodsNo
	left join t_CheckTast c
	on b.cCheckTaskNo=c.cCheckTaskNo
	where c.dCheckTask<=@dDate2 
	and isnull(b.fQuantity_Diff,0)<>0 and c.bChecked in(0,1) and ISNULL(c.bAccount,0)=0
	and ISNULL(c.cWhNo,'')=@cWhNo

--盘点统计结束-------------------------------------------------------------------------------------------
union all
select cGoodsNo,@cWhNo,fQuantity=0 from #tmpPloyOfGoodsinfo
 
 --select cGoodsNo,cWhNo,fQuantity=SUM(fQuantity) 
 --from #GoodsCurStorageList
 --group by cGoodsNo,cWhNo
 
if (select object_id('tempdb..#ready'))is not null
drop table #ready
 select a.*,b.fQuantity,sale_days=CAST(null as real)
 into #ready 
 from #cgoods_kucun a left join (select cGoodsNo,cWhNo,fQuantity=SUM(fQuantity) 
 from #GoodsCurStorageList
 group by cGoodsNo,cWhNo) b
 on a.cGoodsNo=b.cGoodsNo
 --left join t_goods c on a.cGoodsNo=c.cGoodsNo 
 --where c.bStorage=1 and b.fQuantity is null

--select * from #ready

update a
set c_kun='负库存'
from #ready a
where fQuantity<0

update a
set c_maoli='负毛利'
from #ready a
where fNormalPrice<fCostPrice

update #ready
set sale_days=
case when fQuantity<0 then null else fQuantity end/
case when xsQty=0 then null else xsQty end * 
case when DateDiff(d,@dDate1,@dDate2)=0 then 1 else DateDiff(d,@dDate1,@dDate2) end

if (select object_id('tempdb..#ready_1'))is not null drop table #ready_1
select cGoodsNo,cGoodsName,cUnit,fNormalPrice=round(fNormalPrice,2),fCostPrice=round(fCostPrice,2),
c_kun,c_maoli,c_type=cast(null as varchar(10)),xsQty=round(xsQty,2),xsMoney=round(xsMoney,2),
cGoodsTypeno,cGoodsTypename,BeginDate,EndDate,fQuantity=round(fQuantity,2),sale_days=ROUND(sale_days,1)
into #ready_1 from #ready 

if (select object_id('tempdb..#temp_ready'))is not null drop table #temp_ready
select identity(int)id,* into #temp_ready 
from #ready_1 order by sale_days asc ,xsQty desc
--select * from #temp_ready

declare @count int
declare @count_20 int
declare @count_80 int
select @count=COUNT(*) from #ready
set @count_20=@count*0.2
set @count_80=@count*0.8
--select @count,@count_20,@count_80,@count_20+@count_80
update #temp_ready 
set c_type='畅销商品'
where id<=@count_20

update #temp_ready 
set c_type='一般商品'
where id<=@count_80 and id>@count_20

update #temp_ready 
set c_type='滞销商品'
where id>@count_80 

update #temp_ready
set c_kun='高库存'
where sale_days>20

update #temp_ready
set c_kun='低库存'
where sale_days<7

update #temp_ready
set c_kun='正常库存'
where c_kun is null

select a.cGoodsNo as 商品NO,b.cBarcode as 商品条码,a.cGoodsName as 商品名称,a.cUnit as 规格,
       a.fCostPrice as 进价,a.fNormalPrice as 售价,a.c_maoli as 毛利状态,a.xsQty as 销售数量,
       a.xsMoney as 销售金额,a.fQuantity as 库存数量,a.c_kun as 库存状态,a.sale_days as 库存周转天数,
       a.c_type as 销售状态,a.cGoodsTypeno as 类别NO,a.cGoodsTypename as 类别名称,
       a.BeginDate as 期初日期,a.EndDate as 期末日期
from #temp_ready a,t_goods b
where a.cGoodsNo=b.cGoodsNo

end
GO
