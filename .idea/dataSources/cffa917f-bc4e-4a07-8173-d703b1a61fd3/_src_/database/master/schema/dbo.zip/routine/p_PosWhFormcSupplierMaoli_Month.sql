/*

  p_PosWhFormcGooodsMaoli_Month '2013-08-01','2013-09-30','01','Pos_Wh_Form'

*/
CREATE proc [dbo].[p_PosWhFormcSupplierMaoli_Month]
@dDateBgn datetime,
@dDateEnd datetime,
@cWhno varchar(32),
@DbName varchar(32)
as
begin
declare @dDate1 varchar(32)
declare @dDate2 varchar(32)
declare @dDate1_1 varchar(32)
set @dDate1=dbo.getdaystr(DATEADD(MONTH,-1,@dDateBgn))
set @dDate2=dbo.getdaystr(CAST((cast(YEAR(@dDateEnd) as varchar(16))+'-'+cast(MONTH(@dDateEnd) as varchar(16))+'-01') AS DATETIME))


if(select object_id('tempdb..#temp_WhFromGoods')) is not null drop table #temp_WhFromGoods

select distinct cGoodsNo into #temp_WhFromGoods from #tmp_WhGoodsList

CREATE INDEX IX_temp_WhFromGoods  ON #temp_WhFromGoods(cGoodsNo)

if(select object_id('tempdb..#temp_WhFromheji_Month')) is not null drop table #temp_WhFromheji_Month
CREATE TABLE #temp_WhFromheji_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
当月销售数量 money, 当月销售金额 money, 当月特价销售数量 money,当月特价销售金额 money,当月正价销售数量 money,当月正价销售金额 money, 
fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money)

if(select object_id('tempdb..#temp_WhFromhejiend_Month')) is not null drop table #temp_WhFromhejiend_Month
CREATE TABLE #temp_WhFromhejiend_Month ([cGoodsNo] [varchar](32) NOT NULL,[cWHno] [varchar](32)  NULL,
cSupplierNo varchar(32) null,cSupplier varchar(64) null,
当月销售数量 money,当月销售金额 money,当月特价销售数量 money,当月特价销售金额 money,当月正价销售数量 money,当月正价销售金额 money, 
fMoney_left money,fPrice_Avg money,fMoney_cost money,fml money)
 ------获取基础的库存-----

-------获取时间段内的进销存-------
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_heji_month''))is not null  drop table #temp_Wh_Goods_heji_month
	select a.[cGoodsNo],b.cSupplierNo,b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_heji_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate1+''' and a.cGoodsNo=b.cGoodsNo 
	and b.cWHno='+@cWHno+' 


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goods_monthheji''))is not null  drop table #temp_SumWh_Goods_monthheji
	select cgoodsno,cSupplierNo,当月销售数量=sum(销售数量0), 当月销售金额=sum(销售金额0), 
	当月特价销售数量=sum(特价销售数量), 当月特价销售金额=sum(特价销售金额), 		
	当月正价销售数量=sum(正价销售数量), 当月正价销售金额=sum(正价销售金额),			  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goods_monthheji
	from  #temp_Wh_Goods_heji_month
	group by cgoodsno,cSupplierNo

	insert into #temp_WhFromheji_Month
	([cGoodsNo],cSupplierNo,当月销售数量,当月销售金额,当月特价销售数量,当月特价销售金额,当月正价销售数量,当月正价销售金额,
	fMoney_cost,fPrice_Avg,fml)
	select [cGoodsNo],cSupplierNo,当月销售数量,当月销售金额,当月特价销售数量,当月特价销售金额,当月正价销售数量,当月正价销售金额,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goods_monthheji          
')
exec('
	if (select OBJECT_ID(''tempdb..#temp_Wh_Goods_hejiend_month''))is not null  drop table #temp_Wh_Goods_hejiend_month
	select a.[cGoodsNo],b.cSupplierNo,b.销售数量0,b.销售金额0,b.特价销售数量,b.特价销售金额,b.正价销售数量,b.正价销售金额
	,b.fMoney_cost,b.fPrice_in,b.fml
	into #temp_Wh_Goods_hejiend_month
	from #temp_WhFromGoods a,'+@DbName+'.dbo.t_WH_Form_Log_Month b
	where dDateBgn='''+@dDate2+''' and a.cGoodsNo=b.cGoodsNo 
	and b.cWHno='+@cWHno+' 


	if (select OBJECT_ID(''tempdb..#temp_SumWh_Goodsend_monthheji''))is not null  drop table #temp_SumWh_Goodsend_monthheji
	select cgoodsno,cSupplierNo,当月销售数量=sum(销售数量0), 当月销售金额=sum(销售金额0), 
	当月特价销售数量=sum(特价销售数量), 当月特价销售金额=sum(特价销售金额), 		
	当月正价销售数量=sum(正价销售数量), 当月正价销售金额=sum(正价销售金额),			  
	fMoney_cost=sum(fMoney_cost), fml=sum(fml),fPrice_Avg=avg(fPrice_in)
	into #temp_SumWh_Goodsend_monthheji
	from  #temp_Wh_Goods_hejiend_month
	group by cgoodsno,cSupplierNo

	insert into #temp_WhFromhejiend_Month([cGoodsNo],cSupplierNo,当月销售数量,当月销售金额,当月特价销售数量,当月特价销售金额,当月正价销售数量,当月正价销售金额,
	fMoney_cost,fPrice_Avg,fml)
	select [cGoodsNo],cSupplierNo,当月销售数量,当月销售金额,当月特价销售数量,当月特价销售金额,当月正价销售数量,当月正价销售金额,
	fMoney_cost,fPrice_Avg,fml
	from #temp_SumWh_Goodsend_monthheji          
')

	update a
	set a.当月销售数量=isnull(a.当月销售数量,0)-isnull(b.当月销售数量,0),
	a.当月销售金额=isnull(a.当月销售金额,0)-isnull(b.当月销售金额,0),
	a.当月特价销售数量=isnull(a.当月特价销售数量,0)-isnull(b.当月特价销售数量,0),
	a.当月特价销售金额=isnull(a.当月特价销售金额,0)-isnull(b.当月特价销售金额,0),
	a.当月正价销售数量=isnull(a.当月正价销售数量,0)-isnull(b.当月正价销售数量,0),
	a.当月正价销售金额=isnull(a.当月正价销售金额,0)-isnull(b.当月正价销售金额,0),
	a.fMoney_cost=isnull(a.fMoney_cost,0)-isnull(b.fMoney_cost,0),
	a.fml=isnull(a.fml,0)-isnull(b.fml,0)
	from #temp_WhFromhejiend_Month a,#temp_WhFromheji_Month b
	where a.cGoodsNo=b.cGoodsNo and a.cSupplierNo=b.cSupplierNo
	
	select * from #temp_WhFromhejiend_Month
	
select * from #temp_WhFromheji_Month

	if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml     
	select cGoodsNo,xsQty=当月销售数量, xsMoney=当月销售金额,fMoney_Cost,fml,cSupplierNo,cSupplier,fPrice_Avg
	into #temp_goodsKuCunml
	from #temp_WhFromhejiend_Month  --where  isnull(fml,0)<>0


	update a set a.cSupplier=b.cSupName
	from #temp_goodsKuCunml a,t_supplier b
	where a.cSupplierNo=b.cSupNo


	if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	select cGoodsNo,xsQty=SUM(xsQty),xsMoney=SUM(xsMoney),fMoney_Cost=SUM(fMoney_Cost),fML=SUM(fML),
	cSupplierNo,cSupplier,fPrice_Avg=AVG(fPrice_Avg)
	into #temp_SumgoodsKuCunml
	from #temp_goodsKuCunml
	group by cGoodsNo,cSupplierNo,cSupplier

	CREATE INDEX IX_temp_SumgoodsKuCunml  ON #temp_SumgoodsKuCunml(cGoodsNo)


	if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
	select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,
	b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,cSupplierNo,cSupName=cSupplier,
	BeginDate=@dDateBgn,EndDate=@dDateEnd, xsQty, xsMoney, 	 
	fCostPrice=a.fPrice_Avg,a.fML,a.fMoney_Cost,i=0
	into  #temp_goodsKuCun
	from #temp_SumgoodsKuCunml a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo  ---and isnull(xsQty,0)<>0
	-- and  isnull(fml,0)<>0
	order by a.cGoodsNo

	/*------------------*/

	---------修改联营直接修改供应商：把商品结果的供应商修改成当前的供应商 
	update a
	set a.cSupplierNo=b.cSupNo,a.cSupName=b.cSupName
	from #temp_goodsKuCun a,t_Goods b
	where a.cGoodsNo=b.cGoodsNo and ISNULL(b.bStorage,0)=0
	
	/*2015-05-16
 一品多商情况当前供应商根据分配超出、再次新入库入其他供应商、销售分配到新入库上、
 造成查销售时之前分配超出相应供应商的商品时销售造成负数：统一修改称主供应商
*/
---获取销售为负的商品
 
if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSalCount'))is not null drop table #temp_cGoodsSale_FuSalCount
select cGoodsNo,a=COUNT(cGoodsNo) into #temp_cGoodsSale_FuSalCount from #temp_goodsKuCun
--where ISNULL(fMoney,0)<0
group by cGoodsNo
having COUNT(cGoodsNo)>1

CREATE INDEX IX_temp_cGoodsSale_FuSalCount  ON #temp_cGoodsSale_FuSalCount(cGoodsNo)

if (select OBJECT_ID('tempdb..#temp_cGoodsSale_FuSal'))is not null drop table #temp_cGoodsSale_FuSal
select b.cGoodsNo,c.cSupNo,c.cSupName into #temp_cGoodsSale_FuSal
from #temp_goodsKuCun a,#temp_cGoodsSale_FuSalCount b,t_Goods c
where a.cGoodsNo=b.cGoodsNo and a.cGoodsNo=c.cGoodsNo and ISNULL(a.xsMoney,0)<0

CREATE INDEX IX_temp_cGoodsSale_FuSal  ON #temp_cGoodsSale_FuSal(cGoodsNo)

update a
set a.cSupName=b.cSupName,a.cSupplierNo=b.cSupNo
from #temp_goodsKuCun a,#temp_cGoodsSale_FuSal b
where a.cGoodsNo=b.cGoodsNo


--------2015-05-16---包装转换-------
update a
set a.cGoodsNo=b.cGoodsNo_minPackage,a.xsQty=a.xsQty*ISNULL(b.fQty_minPackage,1)
from #temp_goodsKuCun a,t_Goods b
where a.cGoodsNo=b.cGoodsNo and ISNULL(b.cGoodsNo_minPackage,'')<>''

   if(select object_id('tempdb..#temp_goodsKuCun_Over')) is not null  drop table #temp_goodsKuCun_Over
select a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
         BeginDate,EndDate,cSupplierNo,b.cSupName,fMoney_Cost=SUM(fMoney_Cost),
         fProfitRatio=null,
         xsQty=sum(xsQty),xsMoney=sum(xsMoney),
         fCostPrice=AVG(fCostPrice),
         fML=sum(fML),i=0
         into #temp_goodsKuCun_Over
  from #temp_goodsKuCun  a,t_Goods b
  where a.cgoodsno=b.cGoodsNo
group by a.cGoodsNo,b.cUnitedNo,b.cGoodsName,b.cBarcode,b.cUnit,b.cSpec,b.fNormalPrice,b.cGoodsTypeno,b.cGoodsTypename,b.bProducted,b.cProductNo,
         BeginDate,EndDate,cSupplierNo,b.cSupName

 
if(select object_id('tempdb..#temp_SupplierNo')) is not null 
begin




   if(select object_id('tempdb..#temp_goodsKuCun_last')) is not null  drop table #temp_goodsKuCun_last
   select a.cGoodsNo,a.cUnitedNo,a.cGoodsName,a.cBarcode,a.cUnit,a.cSpec,a.fNormalPrice,a.cGoodsTypeno,a.cGoodsTypename,a.bProducted,a.cProductNo,
         a.BeginDate,a.EndDate,a.cSupplierNo,a.cSupName,a.fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(a.xsMoney,0)<>0 
         then (isnull(a.xsMoney,0)-isnull(a.fMoney_Cost,0))/isnull(a.xsMoney,0)*100 
         else null end ,
         xsQty=isnull(a.xsQty,0),xsMoney=isnull(a.xsMoney,0),
         --fCostPrice=isnull(a.fCostPrice,0),
         fCostPrice=case when isnull(a.xsQty,0)<>0
         then isnull(a.fMoney_Cost,0)/isnull(a.xsQty,0)
         else isnull(a.fCostPrice,0) end,
         fML=isnull(a.fML,0),a.i
      into    #temp_goodsKuCun_last
  --from #temp_goodsKuCun a,#temp_SupplierNo b
  from #temp_goodsKuCun_Over a,#temp_SupplierNo b
  where a.cSupplierNo=b.cSupplierNo
 
  
  select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),fCostPrice=isnull(fCostPrice,0),
         fML,i
  from #temp_goodsKuCun_last 
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
  from #temp_goodsKuCun_last  
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
  from #temp_goodsKuCun_last 
  group by BeginDate,EndDate
  order by cSupplierNo,cGoodsTypeno,cGoodsNo,i
  
end else
begin
   select cGoodsNo,cUnitedNo,cGoodsName,cBarcode,cUnit,cSpec,fNormalPrice,cGoodsTypeno,cGoodsTypename,bProducted,cProductNo,
         BeginDate,EndDate,cSupplierNo,cSupName,fMoney_Cost,
         fProfitRatio=null,fMoney_Profit_sum=isnull(xsMoney,0)-isnull(fMoney_Cost,0),
         fProfitRatio_avg=case 
         when isnull(xsMoney,0)<>0 
         then (isnull(xsMoney,0)-isnull(fMoney_Cost,0))/isnull(xsMoney,0)*100 
         else null end ,
         xsQty=isnull(xsQty,0),xsMoney=isnull(xsMoney,0),
        -- fCostPrice=isnull(fCostPrice,0),          
         fCostPrice=case when isnull(xsQty,0)<>0
         then isnull(fMoney_Cost,0)/isnull(xsQty,0)
         else isnull(fCostPrice,0) end,
         fML=ISNULL(fML,0),i
     --from #temp_goodsKuCun 
  from #temp_goodsKuCun_Over
  union all
  select cGoodsNo='合计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno='合计:',cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo,cSupName,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
         fProfitRatio_avg=case 
         when sum(isnull(xsMoney,0))<>0 
         then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 
         else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=2
      --from #temp_goodsKuCun 
  from #temp_goodsKuCun_Over
  group by cSupplierNo,cSupName,BeginDate,EndDate
  union all
  select cGoodsNo='总计:',cUnitedNo=null,cGoodsName=null,cBarcode=null,cUnit=null,cSpec=null,fNormalPrice=null,cGoodsTypeno=null,cGoodsTypename=null,bProducted=null,cProductNo=null,
         @dDateBgn,@dDateEnd,cSupplierNo='总计:',cSupName=null,fMoney_Cost=sum(isnull(fMoney_Cost,0)),
         fProfitRatio=null,fMoney_Profit_sum=SUM(isnull(xsMoney,0)-isnull(fMoney_Cost,0)),
          fProfitRatio_avg=case when sum(isnull(xsMoney,0))<>0 then (sum(isnull(xsMoney,0))-SUM(isnull(fMoney_Cost,0)))/sum(isnull(xsMoney,0))*100 else null end ,
         xsQty=sum(isnull(xsQty,0)),xsMoney=sum(isnull(xsMoney,0)),fCostPrice=null,fML=sum(isnull(fML,0)),i=3
      --from #temp_goodsKuCun 
  from #temp_goodsKuCun_Over
  group by BeginDate,EndDate
  order by cSupplierNo,cGoodsTypeno,cGoodsNo,i
end    

  

	/*获取时间段的入库记录 日期以单据日期为判断。*/

	 /*删除临时表*/
	  if (select object_id('tempdb..#tmpCostGoodsList'))is not null drop table #tmpCostGoodsList
	  if (select object_id('tempdb..#tmp_WhGoodsList'))is not null drop table #tmp_WhGoodsList
	  if(select object_id('tempdb..#temp_WhFrombegin')) is not null drop table #temp_WhFrombegin
      if(select object_id('tempdb..#temp_WhFromend')) is not null drop table #temp_WhFromend
	   if (select OBJECT_ID('tempdb..#temp_maxWhdDate'))is not null drop table #temp_maxWhdDate
	   if (select OBJECT_ID('tempdb..#temp_ReadyKucun'))is not null drop table #temp_ReadyKucun
	    if(select object_id('tempdb..#temp_WhKouDian')) is not null drop table #temp_WhKouDian
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCunml'))is not null  drop table #temp_goodsKuCunml    
	    if (select OBJECT_ID('tempdb..#temp_SumgoodsKuCunml'))is not null  drop table #temp_SumgoodsKuCunml
	    if (select OBJECT_ID('tempdb..#temp_goodsKuCun'))is not null  drop table #temp_goodsKuCun
        if (select OBJECT_ID('tempdb..#temp_wh_DiffPriceWarehouseDetail'))is not null  drop table #temp_wh_DiffPriceWarehouseDetail
		  if (select OBJECT_ID('tempdb..#temp_wh_DiffPricecGoodsNo'))is not null   drop table #temp_wh_DiffPricecGoodsNo

    
end
GO
