create proc [dbo].[fen_dian_tui_huo_dan_no]
        
        @year varchar(20),
        @storeno varchar(20)
        as
        
        select   dbo.f_cStoreRTSheetno (@year,@storeno) as fen_dian_tui_huo_no
GO
