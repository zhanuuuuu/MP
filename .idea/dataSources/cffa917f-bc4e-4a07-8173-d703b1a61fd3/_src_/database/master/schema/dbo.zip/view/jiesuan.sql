








CREATE view [dbo].[jiesuan]
as
select  zdriqi, sheetno, jstype, cStoreNo, mianzhi, zhekou, zhaoling, 
shishou, jstime, jiaozhang, jiaozhangtime, jiaozhangdate, shouyinyuanno, 
shouyinyuanmc, jiaokuantime, shoukuanno, shoukuanname, netjiecun, orientmoney, 
leftmoney, storevalue, detail, bPost, tag_daily, bGroupSale, 
cWhNo, bSent, b_ftp, cStoreName, invoiceNo,cBanci,cBanci_ID,iLineNo_Banci,dUpTime,bonline,posID
from Pos_Sale.dbo.jiesuan with (nolock)


GO
