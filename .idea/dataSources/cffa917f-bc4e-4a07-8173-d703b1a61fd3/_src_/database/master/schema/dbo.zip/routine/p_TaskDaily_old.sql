




/*
dbo.wh_CheckWh
dbo.wh_CheckWhDetail

dbo.wh_EffusionWh
dbo.wh_EffusionWhDetail

dbo.wh_Exchange
dbo.wh_ExchangeDetail

dbo.wh_InWarehouse
dbo.wh_InWarehouseDetail

dbo.wh_LossWarehouse
dbo.wh_LossWarehouseDetail

dbo.wh_OutWarehouse
dbo.wh_OutWarehouseDetail

dbo.wh_RbdWarehouse
dbo.wh_RbdWarehouseDetail

dbo.WH_ReturnGoods
dbo.WH_ReturnGoodsDetail

dbo.wh_TfrWarehouse
dbo.wh_TfrWarehouseDetail

dbo.t_SaleSheet
dbo.t_SaleSheetDetail
*/

/*


declare @dDate datetime

set @dDate='2008-05-17'
while @dDate<='2008-05-17'
begin
  exec p_TaskDaily @dDate,@dDate,@dDate
  set @dDate=@dDate+1
end

*/

create procedure [dbo].[p_TaskDaily_old]  /*参照p_SaleSheetPerDay  p_job_Yesterday*/
@dDateStart datetime,  /*@dDateStart,@dDateEnd参照时间段*/
@dDateEnd datetime,

@dDate datetime  /*当前日结日期   @dDate between @dDateStart and @dDateEnd参照时间段*/
as
begin
	set nocount on
/*
  set xact_abort on
  begin tran 
*/
		declare @today datetime
		set @today=dbo.getDayStr(@dDate)

		/* 取出需要做日结的销售纪录 放入#temp_SaleSheetDetail  */
		update a set a.Tag_daily=0
		from t_SaleSheetDetail a
		where dSaleDate=@today and isnull(a.Tag_daily,0)=1

		select cSaleSheetno,iSeed,cGoodsNo,bAuditing,fVipScore,fQuantity,fLastSettle,dSaleDate,
		fPrice,bVipPrice,fVipPrice,cSaleTime,cVipNo,Tag_daily
		into #temp_SaleSheetDetail
		from dbo.t_SaleSheetDetail
--		where isnull(Tag_daily,0)=0 and dSaleDate between @dDateStart	and @dDateEnd
		where dSaleDate=@dDate and isnull(Tag_daily,0)=0


/*处理非当天的销售（当时没有日结原因（断网销售、隔日退货等原因）） 
收款员在交账的时候打印最后一笔交易的流水号，系统管理员在日结的时候比对最后一笔交易的流水号
在程序中加以处理*/ 

/*处理当天的销售*/


		select cGoodsNo into #tempBalance 
		from dbo.t_SaleSheet_Day 
		where dSaleDate=@today and isnull(bBalance,0)=1

		select cGoodsNo into #tempChecked 
		from dbo.t_SaleSheet_Day 
		where dSaleDate=@today and isnull(bChecked,0)=1

    delete from dbo.t_SaleSheet_Day where dSaleDate=@today


	  insert into dbo.t_SaleSheet_Day
		(cGoodsNo,bAuditing,fVipScore,fQuantity_Total,fQuantity,fLastSettle,dFinanceDate,dSaleDate,cSaleTime,
		 H0,H1,H2,H3,H4,H5,H6,H7,H8,H9,H10,H11,H12,H13,H14,H15,H16,H17,H18,H19,H20,H21,H22,H23,
		 H0_Q,H1_Q,H2_Q,H3_Q,H4_Q,H5_Q,H6_Q,H7_Q,H8_Q,H9_Q,H10_Q,H11_Q,H12_Q,H13_Q,H14_Q,H15_Q,H16_Q,H17_Q,H18_Q,H19_Q,H20_Q,H21_Q,H22_Q,H23_Q

		)
		select  cGoodsNo,bAuditing,fVipScore=round(sum((fVipScore*fQuantity)),0),
						fQuantity_Total=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate),					
						fQuantity=sum(fQuantity),
						fLastSettle=sum(fLastSettle),dFinanceDate=dSaleDate,dSaleDate,cSaleTime=dbo.getTimeStr(getdate()),
						H0=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H1=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H2=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H3=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H4=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H5=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					

						H6=(select sum(fLastSettle) from #temp_SaleSheetDetail 

								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H7=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H8=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H9=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H10=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H11=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H12=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H13=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H14=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H15=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H16=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H17=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H18=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H19=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H20=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H21=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H22=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H23=(select sum(fLastSettle) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),
					
						H0_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=0 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H1_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=1 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H2_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=2 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H3_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=3 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H4_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=4 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H5_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=5 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H6_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=6 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H7_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=7 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H8_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=8 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H9_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=9 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H10_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=10 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H11_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=11 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H12_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=12 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H13_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=13 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H14_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=14 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H15_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=15 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H16_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=16 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H17_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=17 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H18_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 

								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=18 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H19_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=19 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H20_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=20 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H21_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=21 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H22_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=22 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing ),					
						H23_Q=(select sum(fQuantity) from #temp_SaleSheetDetail 
								where datepart(hh,cast('2000-01-01 '+cSaleTime as datetime))=23 and cGoodsNo=a.cGoodsNo and dSaleDate=a.dSaleDate and bAuditing=a.bAuditing )					

		from 	#temp_SaleSheetDetail a
		where  a.dSaleDate=@today
	  group by a.cGoodsNo,a.dSaleDate,a.bAuditing

		update a set a.bChecked=1
		from t_SaleSheet_Day a,#tempChecked b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo

    delete from dbo.t_Vip_ConsumeDaily where dSaleDate=@today
		insert into t_Vip_ConsumeDaily(	cVipno,cGoodsNo,fQuantity,fLastSettle	,bAuditing,
		fPrice,bVipPrice,fVipPrice,dSaleDate,cSaleTime,	cSaleSheetno,iSeed)
		select cVipno,cGoodsNo,fQuantity,fLastSettle,bAuditing,fPrice,bVipPrice,fVipPrice,
		dSaleDate,cSaleTime,	cSaleSheetno,iSeed 
		from #temp_SaleSheetDetail
		where dSaleDate=@today and dbo.trim(cVipNo)<>'' and cVipNo is not null
					

		declare @WHno varchar(32)
		select @WHno=cWHno from t_WareHouse where isnull(bMainSale,0)=1

		create table #tempCurWH
		(
			cGoodsNo varchar(32),Qty_End money,dDateTime_CurWH datetime,
			dDateTime_gen datetime,cWHno varchar(32)    
		)

		insert into #tempCurWH (cGoodsNo,Qty_End,dDateTime_CurWH,dDateTime_gen,cWHno)
		exec p_TaskDaily_GenGoods_CurWh @dDate,@WHno,1,1
/*
dbo.wh_CheckWh
dbo.wh_CheckWhDetail

dbo.wh_EffusionWh
dbo.wh_EffusionWhDetail

dbo.wh_Exchange
dbo.wh_ExchangeDetail

dbo.wh_InWarehouse
dbo.wh_InWarehouseDetail

dbo.wh_LossWarehouse
dbo.wh_LossWarehouseDetail

dbo.wh_OutWarehouse
dbo.wh_OutWarehouseDetail

dbo.wh_RbdWarehouse
dbo.wh_RbdWarehouseDetail

dbo.WH_ReturnGoods
dbo.WH_ReturnGoodsDetail

dbo.wh_TfrWarehouse
dbo.wh_TfrWarehouseDetail

dbo.t_SaleSheet
dbo.t_SaleSheetDetail
*/
/*下面提取没有发生销售但有库存变动的商品*/

	  insert into dbo.t_SaleSheet_Day
		(cGoodsNo,fQuantity,fLastSettle,dFinanceDate,dSaleDate,cSaleTime
		)
		select distinct f.cGoodsNo,f.fQuantity,f.fLastSettle,f.dFinanceDate,f.dSaleDate,f.cSaleTime
		from
		(
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_InWarehouseDetail a,wh_InWarehouse b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from WH_ReturnGoodsDetail a,WH_ReturnGoods b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_EffusionWhDetail a,wh_EffusionWh b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_ExchangeDetail a,wh_Exchange b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_LossWarehouseDetail a,wh_LossWarehouse b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_OutWarehouseDetail a,wh_OutWarehouse b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_RbdWarehouseDetail a,wh_RbdWarehouse b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
					union all
					select a.cGoodsNo,fQuantity=0,fLastSettle=0,dFinanceDate=@dDate,dSaleDate=@dDate,cSaleTime=dbo.gettimestr(getdate())
					from wh_TfrWarehouseDetail a,wh_TfrWarehouse b
					where b.dDate=@dDate and b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
		) f left join #temp_SaleSheetDetail g on f.cGoodsNo=g.cGoodsNo
		where g.cGoodsNo is null

		

--		select * from #tempCurWH
		update a set a.fQty_CurWH=b.Qty_End
		from t_SaleSheet_Day a,#tempCurWH b 
		where a.dSaleDate=@dDate and a.dSaleDate=dbo.getdaystr(b.dDateTime_CurWH) 
					and a.cGoodsNo=b.cGoodsNo

		update a set a.bStorage=b.bStorage
		from t_SaleSheet_Day a,t_goods b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo

/*计算期初库存*/		
		select distinct cGoodsNo,dSaleDate=max(dSaleDate)
		into #tempLastInfor
		from t_SaleSheet_Day
		where dSaleDate<@dDate
		group by cGoodsNo

		select cGoodsNo,dSaleDate,
					 fQty_CurWH=sum(fQty_CurWH)/count(*),
					 fMoney_WH=sum(fMoney_WH)/count(*),
--					 fMoney_WH=sum(fMoney_WH_end)/count(*),
--					 fMoney_WH_last=sum(fMoney_WH_end)/count(*),
					 fMoney_WH_Begin=sum(fMoney_WH_Begin)/count(*),
					 fMoney_WH_Sale_Begin=sum(fMoney_WH_Sale_Begin)/count(*),
					 fMoney_WH_end=sum(fMoney_WH_end)/count(*),
					 fMoney_WH_Sale_end=sum(fMoney_WH_Sale_end)/count(*),
					 fInPrice_avg=sum(fInPrice_avg)/count(*),
					 fQuantity=sum(fQuantity)
		into #tempSaleSheet_Day_unique
		from t_SaleSheet_Day 
		where dSaleDate<=@dDate
		group by cGoodsNo,dSaleDate

		select distinct a.cGoodsNo,a.dSaleDate,fQty_CurWH=b.fQty_CurWH,
					 fMoney_WH=b.fMoney_WH,fMoney_WH_Begin=b.fMoney_WH_Begin,fMoney_WH_Sale_Begin=b.fMoney_WH_Sale_Begin,
					 fMoney_WH_end=b.fMoney_WH_end,fMoney_WH_Sale_end=b.fMoney_WH_Sale_end,
					 fQuantity_sale=b.fQuantity,fInPrice_avg=b.fInPrice_avg
		into #tempLastWH
		from #tempLastInfor a,#tempSaleSheet_Day_unique b
		where a.dSaleDate=b.dSaleDate and a.cGoodsNo=b.cGoodsNo
	
		update 	a set 	a.fQty_BeginWH=	b.fQty_CurWH
		from t_SaleSheet_Day a,#tempLastWH b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo
/*计算期初库存over! 2007-06-10测试通过*/		

/*计算上次日结到本次日结间的商品入库情况*/

		select distinct a.cGoodsNo,a.fQty_CurWH,fMoney_WH_last=b.fMoney_WH_end,fInPrice_avg_last=b.fInPrice_avg,
		fQuantity_sale_last=b.fQuantity_sale,date2=a.dSaleDate,date1=cast(isnull(b.dSaleDate,'1900-01-01') as datetime)+1
		into #tempPeriod
		from #tempSaleSheet_Day_unique a left join #tempLastWH b on a.cGoodsNo=b.cGoodsNo
		where a.dSaleDate=@dDate
--select * from #tempLastInfor  where cgoodsno='10565'

--select * from #tempSaleSheet_Day_unique  where cgoodsno='10565'

--select * from #tempLastWH  where cgoodsno='10565'
--select * from #tempPeriod  where cgoodsno='10565'


				select f.cSheetno,f.iLineNo,k.cGoodsNo,f.fInMoney,f.fInPrice,f.fQuantity,f.dDate,f.bCost,
				k.fMoney_WH_last,k.fInPrice_avg_last,k.fQuantity_sale_last
				into #tempInOutPeriod
				from 
				(
						select a.cSheetno,a.iLineNo,a.cGoodsNo,a.fInMoney,a.fInPrice,a.fQuantity,b.dDate,bCost=1
						from wh_InWarehouseDetail a,wh_InWarehouse b
						where b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
						union all
						select a.cSheetno,a.iLineNo,a.cGoodsNo,fInMoney=-a.fInMoney,a.fInPrice,fQuantity=-a.fQuantity,b.dDate,bCost=1
						from wh_RbdWarehouseDetail a,wh_RbdWarehouse b
						where b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
						union all
						select a.cSheetno,a.iLineNo,a.cGoodsNo,a.fInMoney,a.fInPrice,a.fQuantity,b.dDate,bCost=0
						from WH_ReturnGoodsDetail a,WH_ReturnGoods b
						where b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
						union all
						select a.cSheetno,a.iLineNo,a.cGoodsNo,fInMoney=-a.fInMoney,a.fInPrice,fQuantity=-a.fQuantity,b.dDate,bCost=0
						from dbo.wh_OutWarehouseDetail a,dbo.wh_OutWarehouse b
						where b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
						union all
						select a.cSheetno,a.iLineNo,a.cGoodsNo,fInMoney=-a.fInMoney,a.fInPrice,fQuantity=-a.fQuantity,b.dDate,bCost=0
						from dbo.wh_TfrWarehouseDetail a,dbo.wh_TfrWarehouse b
						where b.cWhNo=@WHno and a.cSheetno=b.cSheetno 
				) f right join #tempPeriod k
				on f.cGoodsNo=k.cGoodsNo 
				and f.dDate between k.date1 and k.date2

drop table #tempPeriod

		select s.cGoodsNo,fInMoneyPeriod=sum(isnull(s.fInMoney,0)),fInQtyPeriod=sum(isnull(s.fQuantity,0)),
					 fInQtyPeriod_Cost=sum(case when bCost=1 then isnull(s.fQuantity,0) else 0 end),
					 fInQtyPeriod_NoCost=sum(case when bCost=0 then isnull(s.fQuantity,0) else 0 end),

					 fMoney_WH_last=isnull(sum(isnull(s.fMoney_WH_last,0)),0)/isnull(count(*),1.00),--sum(s.fMoney_WH_last),
					 fInPrice_avg_last=isnull(sum(isnull(s.fInPrice_avg_last,0)),0)/isnull(count(*),1.00),
					 fQuantity_sale_last=isnull(sum(isnull(s.fQuantity_sale_last,0)),0)/isnull(count(*),1.00)
		into #tempPeriodGoods
		from
		#tempInOutPeriod s
		group by s.cGoodsNo

drop table #tempInOutPeriod


--select  tablename='t_SaleSheet_Day',a.* from t_SaleSheet_Day a where a.cgoodsno='15010054'

		update t_SaleSheet_Day set fQuantity_total=0,fQty_BeginWH=0 
		where dSaleDate=@dDate and (abs(fQuantity_total)>99999999 or abs(fQty_BeginWH)>99999999)

		update #tempPeriodGoods set fMoney_WH_last=0,fInMoneyPeriod=0,fInPrice_avg_last=0,fInQtyPeriod=0,
					 fInQtyPeriod_NoCost=0 
		where (abs(fMoney_WH_last)>99999999 or abs(fInMoneyPeriod)>99999999 or abs(fInPrice_avg_last)>99999999 
					 or abs(fInQtyPeriod)>99999999 or  abs(fInQtyPeriod_NoCost)>99999999 )

		update a 
		set a.fMoney_WH=isnull(b.fMoney_WH_last,0)+isnull(b.fInMoneyPeriod,0)-isnull(b.fInPrice_avg_last*b.fInQtyPeriod_NoCost,0),--期初库存
--				a.fMoney_WH_Begin=isnull(b.fMoney_WH_last,0)-isnull(b.fInPrice_avg_last*b.fQuantity_sale_last,0),
				a.fMoney_WH_Begin=isnull(b.fMoney_WH_last,0),
				a.fInPrice_avg=(isnull(b.fMoney_WH_last,0)+isnull(b.fInMoneyPeriod,0)
										-isnull(b.fInPrice_avg_last*b.fInQtyPeriod_NoCost,0)
										-isnull(b.fInPrice_avg_last*a.fQuantity_total,0))

--											/case when abs(round(isnull(isnull(a.fQty_BeginWH,0)+isnull(b.fInQtyPeriod,0),0),4)-isnull(a.fQuantity_total,0))=0 
											/case when abs(round(isnull(isnull(a.fQty_BeginWH,0)+isnull(b.fInQtyPeriod,0),0),4)-isnull(a.fQuantity_total,0))<0.0001 
														then null 
														else round(isnull(isnull(a.fQty_BeginWH,0)+isnull(b.fInQtyPeriod,0),0),4)-isnull(a.fQuantity_total,0)
											 end
		from t_SaleSheet_Day a,#tempPeriodGoods b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo

drop table #tempPeriodGoods


/*
declare @dDate datetime
set @dDate='2008-08-15'
exec p_TaskDaily @dDate,@dDate,@dDate
*/

--select  tablename='t_SaleSheet_Day',a.* from #tempPeriodGoods a where a.cgoodsno='15010054'

--select  tablename='t_SaleSheet_Day',a.* from t_SaleSheet_Day a where a.cgoodsno='15010054'

		update a 
		set a.fInPrice_avg=b.fCKPrice
		from t_SaleSheet_Day a,t_Goods b
		where a.fInPrice_avg is null and a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo and isnull(a.bStorage,0)=1

		update a 
		set a.fInPrice_H=b.fCKPrice,a.fInPrice_L=b.fCKPrice,
				a.fNormalPrice=b.fNormalPrice,a.fVipPrice=b.fVipPrice,
--				a.cCooperate=b.cHezuoFangshi,
				a.fMoney_WH_end=isnull(a.fMoney_WH,0)-isnull(a.fInPrice_avg*a.fQuantity_Total,0),
				a.fMoney_WH_Sale_Begin=(a.fQty_BeginWH)*b.fNormalPrice,
				a.fMoney_WH_Sale_End=fQty_CurWH*b.fNormalPrice
		from t_SaleSheet_Day a,t_Goods b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo and isnull(b.bStorage,0)=1
		
		update a set a.bBalance=1,a.fCostPrice=a.fInPrice_avg
		from t_SaleSheet_Day a,#tempBalance b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo

		update a set a.bChecked=1,a.fCostPrice=a.fInPrice_avg
		from t_SaleSheet_Day a,#tempChecked b
		where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo


drop table #tempBalance
drop table #tempChecked


/*
		select distinct cGoodsNo,dSaleDate=max(dSaleDate)
		into #tempLastInfor
		from t_SaleSheet_Day
		where dSaleDate<@dDate
		group by cGoodsNo
*/

/*
select tablename='#tempLastInfor',dDate1=@dDate,a.* from #tempLastInfor a where a.cgoodsno='10619'

select tablename='#tempLastInfor_t_SaleSheet_Day',dDate1=@dDate,b.cGoodsNo,b.dSaleDate,c.fCostPrice
from #tempLastInfor b,t_SaleSheet_Day c
where b.dSaleDate=c.dSaleDate and  b.cGoodsNo=c.cGoodsNo and b.cgoodsno='10619'
*/
		select distinct b.cGoodsNo,b.dSaleDate,c.fCostPrice
		into #tempLastInfor_fCostPrice
		from #tempLastInfor b,t_SaleSheet_Day c
		where b.dSaleDate=c.dSaleDate and  b.cGoodsNo=c.cGoodsNo-- and b.cgoodsno='10619'



--print '12345678'

/*计算上次日结到本次日结间的商品入库情况over!  2007-06-13*/
/*以上处理t_SaleSheet_Day over!  2007-06-13*/

/*处理jiesuan*/

	select 	a.sheetno,a.jstype,a.detail,a.shishou,a.zdriqi,a.shouyinyuanno,a.shouyinyuanmc,a.bPost
	into #tempJiesuan
	from jiesuan a,(select distinct sheetno=cSaleSheetno from #temp_SaleSheetDetail) b
--	where isnull(a.tag_daily,0)=0 and  a.sheetno=b.sheetno
	where a.zdriqi=@dDate and a.sheetno=b.sheetno

		
	delete from jiesuan_Daily_operator where zdriqi=@dDate
	insert into dbo.jiesuan_Daily_operator
	(zdriqi,shouyinyuanno,shouyinyuanmc,detail,shishou)
	select zdriqi,shouyinyuanno,shouyinyuanmc,detail,shishou=sum(shishou)
	from #tempJiesuan
	group by zdriqi,shouyinyuanno,shouyinyuanmc,detail

	select a.sheetno,a.zdriqi,a.detail,shishou=sum(a.shishou)
	into #tempJiesuan_merg
	from #tempJiesuan a
	group by a.sheetno,a.zdriqi,a.detail

	select a.sheetno,shishou_sum=sum(a.shishou)
	into #tempJiesuan_sumBYsheetno
	from #tempJiesuan a
	group by a.sheetno

	select cSaleSheetno,cGoodsNo,fLastSettle=sum(fLastSettle)
	into #temp_SaleSheetDetail_groupGoodsNo
	from #temp_SaleSheetDetail
	group by cSaleSheetno,cGoodsNo

	select a.sheetno,a.zdriqi,a.detail,a.shishou,b.cGoodsNo,b.fLastSettle
	into #tempJiesuan_SaleSheetDetail
	from #tempJiesuan_merg a,#temp_SaleSheetDetail_groupGoodsNo b
	where a.sheetno=b.cSaleSheetno


--drop table #temp_SaleSheetDetail

	select a.sheetno,a.zdriqi,a.detail,a.shishou,a.cGoodsNo,
				 shishou_detail=a.shishou*(a.fLastSettle/case when round(b.shishou_sum,4)=0 then 1.0 else b.shishou_sum end ),a.fLastSettle,b.shishou_sum
	into #tempJiesuan_SaleSheetDetail_merg
	from #tempJiesuan_SaleSheetDetail a,#tempJiesuan_sumBYsheetno b
	where a.sheetno=b.sheetno and b.shishou_sum<>0

	delete from jiesuan_daily where dDate=@dDate
	insert into dbo.jiesuan_daily(dDate,cGoodsNo,detail,shishou)
	select dDate=zdriqi,cGoodsNo,detail,shishou=sum(shishou_detail)
	from #tempJiesuan_SaleSheetDetail_merg
	group by zdriqi,cGoodsNo,detail

	update a set a.tag_daily=1
	from jiesuan a,#tempJiesuan b
	where a.zdriqi=@dDate and a.sheetno=b.sheetno
drop table #tempJiesuan
drop table #tempJiesuan_SaleSheetDetail_merg
drop table #tempJiesuan_sumBYsheetno
drop table #temp_SaleSheetDetail_groupGoodsNo

/*以上处理jiesuan*/

/*以下处理联营扣率*/
/*
	declare @cWHno varchar(32)
	select @cWHno=cWHno 
	from dbo.t_WareHouse  
	where bMainSale=1
*/
	select distinct cGoodsno
  into #t_Goods_selected_onlyGoodsno 
	from t_Salesheet_day where dSaleDate=@dDate/*在控制窗体中传递过来的临时表*/
	--where cGoodsNo not in (select cGoodsno from #t_supplier_Goods_eStop_supNo)
	/*计算商品的购买成本*/

	/*查询联营商品信息，联营扣点即为毛利率*/

	select distinct cSupNo=guizuno  
	into #tempSupplier_cSupNo 
	from dbo.t_Supplier_Contract_Ratio

	select a.cGoodsNo,a.cSupNo
	into #tempSupplier_cSupNo_cGoodsNo
	from (select e.cGoodsNo, e.cSupNo 
				from dbo.t_Supplier_goods e
				right join #t_Goods_selected_onlyGoodsno f
				on e.cGoodsNo=f.cGoodsNo
				where e.cGoodsNo is not null 
			 ) a 
	left join #tempSupplier_cSupNo b
	on a.cSupNo=b.cSupNo
	where b.cSupNo is not null

	union all  	

  select a.cGoodsNo,b.cSupNo
--	from dbo.wh_InWarehouseDetail a 
	from (select f.cGoodsNo, cSupNo=e.cSupplierNo,e.cSheetno 
				from (select g.cGoodsNo,h.cSupplierNo,g.cSheetno from dbo.wh_InWarehouseDetail g
							left join wh_InWarehouse h on g.cSheetno=h.cSheetno	
							where h.cWHno=@WHno		
							) e
				right join #t_Goods_selected_onlyGoodsno f
				on e.cGoodsNo=f.cGoodsNo
				where e.cSheetno is not null 
			 ) a 
	left join ( select c.cSheetno,d.cSupNo 
							from wh_InWarehouse c left join #tempSupplier_cSupNo d
							on c.cSupplierNo=d.cSupNo
							where d.cSupNo is not null and c.cSheetNo is not null 
							      and c.cWHno=@WHno		
						) b
	on a.cSheetno=b.cSheetno
	where b.cSupNo is not null

  select a.cGoodsNo,a.cSupNo
  into #tempSupplier_cSupNo_cGoodsNo_withoutEstop_0
	from #tempSupplier_cSupNo_cGoodsNo a
	left join dbo.t_Supplier_goods_eStop b 
	on a.cGoodsNo=b.cGoodsNo and a.cSupNo=b.cSupNo
	where b.cGoodsNo is null and b.cSupNo is null
	
  select fRatio=min(fRatio),cSupNo=guizuno
	into #t_Supplier_Contract_Ratio
	from t_Supplier_Contract_Ratio
	group by guizuno


	select distinct a.cGoodsNo,a.cSupNo,b.fRatio,cSupName=b.cSupNo 
  into #tempSupplier_cSupNo_cGoodsNo_withoutEstop	
	from #tempSupplier_cSupNo_cGoodsNo_withoutEstop_0 a
	left join #t_Supplier_Contract_Ratio b
	on a.cSupNo=b.cSupNo
	
	update a set a.fNormalPrice=b.fNormalPrice,
	a.fCostPrice=a.fInPrice_avg
  from t_SaleSheet_Day a,t_Goods b
	where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo   

	update a set a.fProfitsRatio=b.fRatio,
	a.fCostPrice=a.fNormalPrice*(100.00-b.fRatio)/100.00
	from dbo.t_SaleSheet_Day a,#tempSupplier_cSupNo_cGoodsNo_withoutEstop b
	where a.dSaleDate=@dDate and a.cGoodsNo=b.cGoodsNo and b.fRatio is not null


/*以上处理联营扣率*/

/*
	select  a.cGoodsNo,a.dSaleDate,a.fLastSettle,
					a.fQuantity,a.bAuditing,b.dDateStart,b.dDateEnd,b.cPloyNo,fSupRatio=isnull(b.fSupRatio,0)
	into #t_SaleSheetDetail_bybAuditing_1_0
*/
	update a set a.fProfitsRatio=b.fSupRatio,a.fCostPrice=a.fNormalPrice*(100.00-b.fSupRatio)/100.00
	from t_SaleSheet_Day a,t_PloyOfSale b
	where a.dSaleDate=@dDate and a.dSaleDate between b.dDateStart and b.dDateEnd
	     and b.cGoodsNo=a.cGoodsNo and a.bAuditing=1 and b.fSupRatio is not null

		update a set a.fCostPrice_History=a.fCostPrice,a.fCostPrice=d.fCostPrice
		from t_SaleSheet_Day a,#tempLastInfor_fCostPrice d
		where a.dSaleDate=@dDate and a.fMoney_WH_end<0 and a.cGoodsNo=d.cGoodsNo


		update a set a.fCostPrice_History=a.fCostPrice,a.fCostPrice=b.fCKPrice
		from t_SaleSheet_Day a,
		 t_goods b
		where a.dSaleDate=@dDate and a.fMoney_WH_end<0 and a.fCostPrice_History is null and a.cGoodsNo=b.cGoodsNo


		update a set a.Tag_daily=1
		from t_SaleSheetDetail a,#temp_SaleSheetDetail b
		where a.dSaleDate=@dDate and isnull(a.Tag_daily,0)=0 and a.cSaleSheetno=b.cSaleSheetno

drop table 	#temp_SaleSheetDetail

drop table 	#tempLastInfor_fCostPrice



	/*	
	commit tran
  set xact_abort off
	*/
	set nocount off
end


GO
